# راهنمای راه‌اندازی فرامن — ویندوز ۱۰ و سرور ایران

> این فایل دو بخش دارد:
> **بخش الف** — بالا آوردن پروژه روی کامپیوتر خودت (ویندوز ۱۰) برای کار روزمره.
> **بخش ب** — بالا آوردن پروژه از صفر روی یک سرور داخل ایران برای محصول واقعی.
>
> 🚫 **بخش هوش مصنوعی در این راهنما لازم نیست.** پروژه سه کلید خاموش‌کننده دارد که به‌جای فراخوانی واقعی مدل، پاسخ نمونه می‌دهند. با آن‌ها **نه کلید OpenAI لازم داری، نه هزینه‌ای می‌دهی، نه منتظر جواب می‌مانی.** در طول راهنما با 🔑 نشان داده شده‌اند.

---

# بخش الف — راه‌اندازی روی ویندوز ۱۰

## ۰. تصمیم اول: چه چیزی کجا اجرا شود؟

پیشنهاد قطعی من:

| چه چیزی | کجا اجرا شود | چرا |
|---|---|---|
| **بک‌اند** (Django + دیتابیس + Redis + صف) | داخل **Docker** | فقط این‌طور «همان چیزی که روی سرور است» را می‌بینی |
| **فرانت‌اند** (Next.js) | **مستقیم روی ویندوز** با `npm run dev` | تغییر کد فوری دیده می‌شود، بدون rebuild |

> ⚠️ **چرا بک‌اند را نative روی ویندوز بالا نیاوریم؟**
> یک دلیل قطعی دارد: کد گزارش‌گیری از کتابخانهٔ ساخت PDF استفاده می‌کند که **در ویندوز بدون نصب GTK از پیش باز نمی‌شود** و چون در بالای فایل import شده، **کل برنامه بالا نمی‌آید** (نه فقط ارسال ایمیل). به‌علاوه سرور وب و صف کارها (gunicorn / gevent) در ویندوز اجرا نمی‌شوند و Celery نیاز به تنظیم خاص دارد.
> اگر اصرار داری بدون Docker بروی، انتهای همین بخش یک مسیر جایگزین با هشدارهایش نوشته شده.

---

## ۱. پیش‌نیازها — نصب یک‌بار برای همیشه

### ۱.۱ ویندوز ۱۰ آخرین نسخه + WSL2

داخل **PowerShell به‌عنوان Administrator**:

```powershell
wsl --install
```

بعد از اتمام، **کامپیوتر را ری‌استارت کن**. سپس بررسی کن:

```powershell
wsl --status
```

باید بنویسد WSL نسخهٔ ۲ است. اگر نوشت نسخهٔ ۱:

```powershell
wsl --set-default-version 2
```

### ۱.۲ Docker Desktop

1. از `docker.com/products/docker-desktop` نسخهٔ **Windows** را دانلود و نصب کن.
2. در زمان نصب، گزینهٔ **Use WSL 2 instead of Hyper-V** را انتخاب کن.
3. بعد از نصب و ری‌استارت، Docker Desktop را باز کن.
4. برو به **Settings → General** و مطمئن شو **Use the WSL 2 based engine** تیک دارد.
5. برو به **Settings → Resources → WSL Integration** و آن را روشن کن.
6. برو به **Settings → Resources** و اگر رم کم داری، حافظه را روی حداقل **۴ گیگ** بگذار.

بررسی نهایی (در PowerShell):

```powershell
docker version
docker compose version
```

باید بدون خطا نسخه را نشان بدهند. اگر `docker` را نمی‌شناسد، یک‌بار کامپیوتر را ری‌استارت کن.

### ۱.۳ Git for Windows

از `git-scm.com/download/win` نصب کن. بررسی:

```powershell
git --version
```

### ۱.۴ Node.js نسخهٔ ۲۲ (برای فرانت‌اند)

از `nodejs.org` نسخهٔ **LTS 22** را نصب کن. بررسی:

```powershell
node -v
npm -v
```

---

## ۲. گرفتن کدها

یک پوشهٔ تمیز بساز. **مسیر بدون فاصله و بدون کاراکتر فارسی انتخاب کن** (مثلاً `C:\dev`).

```powershell
mkdir C:\dev
cd C:\dev
git clone https://github.com/NovaGamerAHx/Our-front-and-backend-source-code.git source
cd source
Expand-Archive -Path .\back-main.zip  -DestinationPath C:\dev
Expand-Archive -Path .\front-main.zip -DestinationPath C:\dev
```

حالا باید این‌ها را داشته باشی:

```
C:\dev\
├── back-main\      ← بک‌اند Django
├── front-main\     ← فرانت‌اند Next.js
└── source\         ← مخزن کلون‌شده (فقط برای نگه‌داشتن زیپ‌ها)
```

---

## ۳. سه آماده‌سازی که اگر رد کنی، همه‌چیز خراب می‌شود

### ۳.۱ ساخت شبکهٔ مشترک

```powershell
docker network create delyar-front_default
```

**چرا؟** فایل تنظیمات بک‌اند یک شبکهٔ «بیرونی» به این نام انتظار دارد (برای اینکه بعداً گواهی HTTPS روی دامنه بگیرد). اگر وجود نداشته باشد، `docker compose up` با خطای `network ... declared as external, but could not be found` متوقف می‌شود.

### ۳.۲ ساخت یک فایل خالی Firebase

در `C:\dev\back-main` یک فایل به نام `firebase-service-account.json` بساز و داخلش فقط بنویس:

```json
{}
```

**چرا؟** تنظیمات داکر این فایل را داخل کانتینر mount می‌کند. اگر فایل نباشد، Docker به‌جای آن یک **پوشه** می‌سازد و بعداً خطاهای عجیب می‌گیری. با این فایل خالی همه‌چیز بالا می‌آید؛ فقط **نوتیفیکیشن پوش کار نمی‌کند** (که در کار محلی مشکلی نیست). برای فعال‌کردنش بعداً فایل واقعی Firebase را جایگزین کن.

### ۳.۳ فایل تنظیمات بک‌اند

```powershell
cd C:\dev\back-main
Copy-Item .env.example .env
notepad .env
```

حالا این خطوط را در فایل پیدا کن و مقدارشان را **دقیقاً** به این تغییر بده (بقیه را دست نزن):

```env
DEBUG=True
DJANGO_SECRET_KEY=local-dev-only-change-me
DJANGO_ALLOWED_HOSTS=localhost,127.0.0.1
CSRF_TRUSTED_ORIGINS=http://localhost,http://localhost:81,http://127.0.0.1:81
CORS_ALLOWED_ORIGINS=http://localhost:3000

DB_HOST=db
DB_PORT=5432
REDIS_HOST=redis
REDIS_PASSWORD=local-redis-pass
GUNICORN_WORKERS=2

DJANGO_SUPERUSER_PHONE_NUMBER=09120000000
DJANGO_SUPERUSER_PASSWORD=admin12345

TEST_OTP_PHONE_NUMBERS=09120000000
TEST_OTP_CODE=12345

ZARINPAL_SANDBOX=True
FRONTEND_URL=http://localhost:3000
BACKEND_PUBLIC_URL=http://localhost:81

# 🔑 خاموش‌کردن کامل هوش مصنوعی
REPORT_AI_ENABLED=false
DEEP_REPORT_AI_ENABLED=false
CHAT_AI_ENABLED=false
REPORT_INITIAL_VERSION=report_v1
```

نکته‌های ریز اما مهم:

- **نشانهٔ نقل‌قول نگذار.** `DEBUG="True"` غلط است، `DEBUG=True` درست است.
- `09120000000` یک شمارهٔ تست است. با این شماره **پیامک واقعی فرستاده نمی‌شود** و کد ورود همیشه `12345` است.
- `REDIS_PASSWORD` هر چه باشد فرقی ندارد، ولی باید **خالی نباشد** (Redis با همین رمز بالا می‌آید).
- `DEBUG=True` را حتماً بگذار، وگرنه Django استاتیک پنل ادمین را نشان نمی‌دهد و با نبودِ مقادیر امنیتی بالا نمی‌آید.

---

## ۴. بالا آوردن بک‌اند

```powershell
cd C:\dev\back-main
docker compose up -d --build
```

**بار اول ۵ تا ۱۵ دقیقه طول می‌کشد** (نصب پکیج‌های پایتون و کتابخانه‌های سیستمی). دفعات بعد چند ثانیه.

وقتی تمام شد، وضعیت را ببین:

```powershell
docker compose ps
```

باید ۹ سرویس ببینی: `postgres`, `db`, `redis`, `web`, `web2`, `celery`, `celery2`, `celery-beat`, `nginx`.

- برای `postgres`, `db`, `redis`, `web`, `web2` باید ستون STATUS بنویسد **healthy**.
- `celery-beat` فقط **running** است (healthcheck ندارد، طبیعی است).

اگر چیزی بالا نیامد:

```powershell
docker compose logs --tail=80 web
```

(ادامهٔ رفع اشکال در بخش ۹)

---

## ۵. ساخت ساختار دیتابیس و داده‌های اولیه

این چهار دستور را به ترتیب بزن:

```powershell
docker compose exec web python manage.py migrate
docker compose exec web python manage.py seed_test_assessment
docker compose exec web python manage.py seed_deep_assessment
docker compose exec web python manage.py create_default_superuser
```

هر کدام چه می‌کند:

| دستور | کار |
|---|---|
| `migrate` | همهٔ جدول‌های دیتابیس را می‌سازد |
| `seed_test_assessment` | آزمون رایگان ۳۰ سؤالی («تست شخصیت») را وارد می‌کند |
| `seed_deep_assessment` | آزمون عمیق ۱۵۰ سؤالی + محصول پرداختی (۱۹۹٬۰۰۰ تومان) را وارد می‌کند |
| `create_default_superuser` | کاربر ادمین را از روی مقادیر `.env` می‌سازد |

برای اجرای تست‌های خودکار پروژه:

```powershell
docker compose run --rm --entrypoint python -e DB_HOST=postgres -v "${PWD}:/app" web manage.py test
```

> چرا `DB_HOST=postgres`؟ چون ابزار تست یک دیتابیس موقت می‌سازد و لایهٔ واسط اتصال (pgbouncer) آن را نمی‌شناسد. این دستور مستقیم به خود Postgres وصل می‌شود. (روی PowerShell از `${PWD}` استفاده می‌کنیم؛ در CMD باید مسیر را کامل بنویسی.)

---

## ۶. بررسی اینکه بک‌اند سالم است

| آدرس | چه باید ببینی |
|---|---|
| `http://localhost:81/health/` | `{"status": "ok"}` |
| `http://localhost:81/api/docs/` | صفحهٔ مستندات Swagger با همهٔ APIها |
| `http://localhost:81/admin/` | فرم ورود پنل مدیریت |

در پنل ادمین با این‌ها وارد شو:

- **شماره موبایل:** `09120000000`
- **رمز عبور:** `admin12345`

> نکته: مدل کاربر در این پروژه با **شماره موبایل** شناسایی می‌شود، نه نام کاربری. پس در فرم ادمین هم شماره را وارد کن.
>
> **چرا پورت ۸۱؟** کانتینرهای اصلی پورتشان را روی ویندوز باز نمی‌کنند؛ فقط nginx روی پورت ۸۱ در دسترس است. اگر پورت ۸۱ روی سیستمت اشغال است، در فایل `docker-compose.yml` خط `"81:80"` را به `"8081:80"` تغییر بده و همه‌جا `81` را با `8081` عوض کن.

---

## ۷. بالا آوردن فرانت‌اند

### ۷.۱ نصب پکیج‌ها

```powershell
cd C:\dev\front-main
npm ci
```

(بار اول ۲ تا ۵ دقیقه)

### ۷.۲ فایل تنظیمات فرانت

فایل `.env.local` را در `C:\dev\front-main` بساز:

```env
NEXT_PUBLIC_API_BASE_URL=http://localhost:81
APP_URL=http://localhost:3000
PAYWALL_DISCOUNT_PERCENT=0
```

- `NEXT_PUBLIC_API_BASE_URL` **باید پورت ۸۱ باشد**، نه ۸۰۰۰. چون فرانت از سمت سرور Node به بک‌اند وصل می‌شود و تنها درِ باز بک‌اند روی ویندوز همان ۸۱ است.
- `PAYWALL_DISCOUNT_PERCENT=0` یعنی نشان تخفیف روی صفحهٔ فروش نمایش داده نشود (برای کار محلی ساده‌تر است).
- کلیدهای Firebase لازم نیست؛ فقط نوتیفیکیشن پوش کار نمی‌کند.

### ۷.۳ اجرا

```powershell
npm run dev
```

سپس مرورگر: **`http://localhost:3000`**

---

## ۸. یک بار کل مسیر را امتحان کن

این تست ۵ دقیقه‌ای به تو می‌گوید همه‌چیز درست است:

1. **`http://localhost:3000/login`** → شماره `09120000000` → دکمهٔ دریافت کد → کد `12345` → ورود.
2. **`http://localhost:3000/test`** → شروع آزمون → ۳۰ سؤال را جواب بده → صفحهٔ «در حال تحلیل».
3. چند ثانیه صبر کن → **گزارش** باز می‌شود (با 🔑 متن نمونه، چون هوش مصنوعی خاموش است).
4. روی «قدم اول» بزن → یک قدم عملی ساخته می‌شود.
5. **`http://localhost:3000/chat`** → یک پیام بفرست → پاسخ نمونه استریم می‌شود.
6. **`http://localhost:3000/dashboard`** → باید قدم ساخته‌شده را ببینی.
7. **`http://localhost:3000/explore`** → هر دو آزمون را ببین.

### 🔑 اگر خواستی گزارش «عمیق» را هم بدون پرداخت ببینی

آزمون عمیق طوری طراحی شده که **بعد از تست، برای دیدن گزارش باید پرداخت کنی**. برای کار محلی، این قفل را یک‌بار بردار:

```powershell
docker compose exec web python manage.py shell -c "from apps.assessment.models import Assessment; Assessment.objects.filter(slug='deep-150-v1').update(report_requires_purchase=False)"
```

اگر خواستی برگردانی، همان دستور را با `True` بزن. (اگر می‌خواهی مسیر پرداخت واقعی را هم ببینی، `ZARINPAL_SANDBOX=True` است و پول واقعی جابه‌جا نمی‌شود.)

---

## ۹. دستورهای روزمره

چون `make` روی ویندوز نصب نیست، از خود Docker Compose استفاده کن:

| کار | دستور |
|---|---|
| بالا آوردن همه‌چیز | `docker compose up -d` |
| خاموش کردن | `docker compose down` |
| دیدن لاگ همه | `docker compose logs -f` |
| لاگ یک سرویس | `docker compose logs -f web` |
| ری‌استارت | `docker compose restart` |
| بازسازی بعد از تغییر کد پایتون | `docker compose up -d --build web web2 celery celery2` |
| ری‌استارت سریع (بدون build) | `docker compose restart web web2 celery celery2` |
| اجرای migration جدید | `docker compose exec web python manage.py migrate` |
| ساخت migration جدید | `docker compose exec web python manage.py makemigrations` |
| شل جنگو | `docker compose exec web python manage.py shell` |
| پاک کردن کامل (با داده‌ها!) | `docker compose down -v` ⚠️ |

> **مهم:** تغییر در فایل‌های پایتون **نیاز به build مجدد ندارد** — کد داخل کانتینر mount شده و با `restart` کافی است. فقط تغییر `requirements.txt` یا `Dockerfile` نیاز به `--build` دارد.

---

## ۱۰. رفع اشکال — خطاهای رایج ویندوز

| خطا | علت | راه‌حل |
|---|---|---|
| `network delyar-front_default ... could not be found` | شبکه ساخته نشده | `docker network create delyar-front_default` |
| `port is already allocated` روی ۸۱ | پورت اشغال است | `"81:80"` را به `"8081:80"` تغییر بده و `NEXT_PUBLIC_API_BASE_URL` را هم عوض کن |
| `web` مدام restart می‌شود | خطای تنظیمات یا import | `docker compose logs --tail=100 web` |
| `DisallowedHost` | هدر Host در لیست مجاز نیست | `DJANGO_ALLOWED_HOSTS` را کامل کن |
| `firebase-service-account.json` پوشه شده | فایل قبل از بالا آمدن نبود | `docker compose down`، پوشه را پاک کن، فایل `{}` بساز، دوباره `up` |
| `docker compose exec web` می‌گوید سرویس اجرا نیست | سرویس بالا نیامده | `docker compose ps` و بعد `docker compose up -d` |
| نصب پکیج پایتون timeout می‌خورد | اینترنت کند/فیلتر | در `Dockerfile` قبل از `pip install` یک میرور ایرانی اضافه کن: `pip install -i https://mirror-pypi.runflare.com/simple ...` |
| `npm ci` خیلی کند است | رجیستری npm | `npm config set registry https://registry.npmmirror.com` و دوباره `npm ci` |
| همه‌چیز کند است | منابع Docker Desktop | Settings → Resources: حداقل ۴ گیگ رم و ۲ CPU |
| صفحهٔ ادمین بدون استایل است | `DEBUG=False` است | `DEBUG=True` بگذار و `restart` کن |

**دستور طلایی وقتی چیزی کار نمی‌کند:**

```powershell
docker compose ps
docker compose logs --tail=100
```

تقریباً همیشه جواب در همین دو خروجی است.

---

## ۱۱. (اختیاری) مسیر بدون Docker روی ویندوز

اگر واقعاً Docker نمی‌خواهی، این مسیر **کار می‌کند ولی دردسر دارد**. اول سه هشدار را بخوان:

> ⚠️ **هشدار ۱ — برنامه بالا نمی‌آید.** کتابخانهٔ ساخت PDF در ویندوز بدون GTK3 باز نمی‌شود و چون در بالای فایل import شده، کل Django کرش می‌کند. راه‌حل: بستهٔ GTK3 Runtime for Windows را نصب کن و پوشهٔ `bin` آن را به `PATH` اضافه کن، یا در `apps/report/services/pdf_service.py` ایمپورت را داخل تابع ببر (تغییر کد موقت).
> ⚠️ **هشدار ۲ — gunicorn و gevent روی ویندوز اجرا نمی‌شوند.** باید از `python manage.py runserver` استفاده کنی.
> ⚠️ **هشدار ۳ — Celery روی ویندوز باید `--pool=solo` داشته باشد**، وگرنه با خطا می‌خوابد.

مراحل کوتاه:

1. **Python 3.10** نصب کن (همان نسخهٔ ایمیج تولیدی) — تیک `Add to PATH` را بزن.
2. **PostgreSQL 16** نصب کن؛ یک دیتابیس `faraman` و کاربر `faraman` بساز.
3. **Redis** روی ویندوز نیست. از **Memurai** یا WSL استفاده کن.
4. نصب پکیج‌ها:
   ```powershell
   cd C:\dev\back-main
   py -3.10 -m venv venv
   .\venv\Scripts\activate
   pip install -r requirements.txt
   ```
5. در `.env` مقادیر اتصال را به `localhost` تغییر بده: `DB_HOST=localhost`, `DB_PORT=5432`, `REDIS_HOST=localhost`.
6. `python manage.py migrate` و کامندهای seed.
7. `python manage.py runserver`
8. صف در ترمینال دوم (اختیاری): `celery -A faraman_back worker -l info --pool=solo`

---

# بخش ب — راه‌اندازی روی سرور داخل ایران

این بخش فرض می‌کند **همه‌چیز از صفر** است: سرور خالی، هیچ داکر و کدی نصب نیست.

## ۰. چه چیزی لازم داری

| مورد | حداقل | پیشنهاد |
|---|---|---|
| سرور | Ubuntu 22.04 یا 24.04، ۲ CPU، ۴ گیگ رم | **۴ CPU، ۸ گیگ رم، ۸۰ گیگ SSD** |
| دسترسی | کاربر root یا sudo | — |
| دامنه | کنترل پنل DNS | `faraman.ai` و زیردامنه‌ها |
| پورت‌های باز | ۲۲، ۸۰، ۴۴۳ | — |

> **چرا حداقل ۴ هستهٔ CPU؟** در تست بار واقعی این پروژه مشخص شد گلوگاه اصلی **CPU** است، نه رم. روی ۲ هسته، چت و تولید گزارش همدیگر را کند می‌کنند.

---

## ۱. آماده‌سازی سیستم‌عامل

با `ssh root@SERVER_IP` وصل شو و بزن:

```bash
apt update && apt upgrade -y
apt install -y curl git ca-certificates ufw htop nano

# ساعت را روی وقت ایران بگذار (برای محاسبهٔ موعد قدم‌ها و لاگ‌ها)
timedatectl set-timezone Asia/Tehran

# فایروال
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 81/tcp        # پورت آزمایشی بک‌اند (بعداً می‌توانی ببندی)
ufw --force enable

# اگر رم ۴ گیگ یا کمتر است، swap بساز
fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
echo '/swapfile none swap sw 0 0' >> /etc/fstab
```

---

## ۲. نصب Docker

```bash
curl -fsSL https://get.docker.com | sh
docker --version
docker compose version
```

اگر `get.docker.com` باز نشد (در ایران گاهی مسدود/کند است):

```bash
apt install -y docker.io docker-compose-v2
docker --version
docker compose version
```

> ⚠️ **نکتهٔ مهم دربارهٔ دانلود ایمیج‌ها در ایران**
> دسترسی مستقیم به Docker Hub (`registry-1.docker.io`) از ایران معمولاً ۴۰۳ یا مسدود است. به همین دلیل این پروژه از قبل تنظیم شده که ایمیج‌ها را از **میرورهای ایرانی** بگیرد: `docker.arvancloud.ir` و `docker-mirror.liara.ir`. **دست به این خطوط نزن**، وگرنه build شکست می‌خورد.
> همچنین ایمیج pgbouncer با **digest** پین شده (نه با تگ نسخه) چون میرور آروان یک کش است و تگ‌هایی که قبلاً از آن درخواست نشده‌اند را ۴۰۴ می‌دهد.

---

## ۳. گرفتن کدها

ساختار پوشه‌ها **عمداً** این‌طور است — نام پوشهٔ فرانت مهم است (پایین توضیح داده شده):

```bash
mkdir -p /opt/faraman
cd /opt/faraman

git clone https://github.com/NovaGamerAHx/Our-front-and-backend-source-code.git src
cd src
apt install -y unzip
unzip -q back-main.zip  -d /opt/faraman/back
unzip -q front-main.zip -d /opt/faraman/

# نام پوشهٔ فرانت باید delyar-front باشد
mv /opt/faraman/front-main /opt/faraman/delyar-front

ls /opt/faraman
# → back  delyar-front  src
```

> ### چرا نام پوشهٔ فرانت باید `delyar-front` باشد؟
> سه فایل تنظیمات به یک **شبکهٔ داکر مشترک** به نام `delyar-front_default` وصل می‌شوند. Docker نام شبکهٔ پیش‌فرض هر پروژه را از **نام پوشه** می‌سازد. اگر پوشه `front-main` باشد، شبکه `front-main_default` می‌شود و **هیچ‌کدام از سه پروژه همدیگر را پیدا نمی‌کنند** → گواهی HTTPS گرفته نمی‌شود و گرافانا به بک‌اند نمی‌رسد.
>
> **راه جایگزین (اگر نمی‌خواهی پوشه را تغییر نام بدهی):** در ابتدای فایل `docker-compose.yml` فرانت، یک خط اضافه کن:
> ```yaml
> name: delyar-front
> services:
>   ...
> ```

---

## ۴. رکوردهای DNS

در پنل دامنه، این رکوردها را بساز (همه از نوع **A** و به IP سرور):

| نام | مقدار |
|---|---|
| `faraman.ai` | IP سرور |
| `www.faraman.ai` | IP سرور |
| `api.faraman.ai` | IP سرور |
| `grafana.faraman.ai` | IP سرور |
| `metabase.faraman.ai` | IP سرور |

قبل از ادامه، از اعمال شدن DNS مطمئن شو:

```bash
ping -c 2 api.faraman.ai
```

اگر IP سرور را جواب نداد، **همین‌جا بایست**. ادامه‌دادن بی‌فایده است.

---

## ۵. تنظیمات فرانت‌اند

```bash
cd /opt/faraman/delyar-front
cp .env.example .env
nano .env
```

مقادیر لازم:

```env
NEXT_PUBLIC_API_BASE_URL=https://api.faraman.ai
APP_URL=https://faraman.ai
PAYWALL_DISCOUNT_PERCENT=50
ACME_EMAIL=admin@faraman.ai

# کلیدهای Firebase (اگر پوش لازم داری)
NEXT_PUBLIC_FIREBASE_API_KEY=
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=
NEXT_PUBLIC_FIREBASE_PROJECT_ID=
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=
NEXT_PUBLIC_FIREBASE_APP_ID=
NEXT_PUBLIC_FCM_VAPID_KEY=
```

> ⚠️ **مهم‌ترین نکتهٔ فرانت:** مقادیری که با `NEXT_PUBLIC_` شروع می‌شوند **در زمان build داخل کد دوخته می‌شوند**، نه در زمان اجرا. یعنی اگر بعداً `NEXT_PUBLIC_API_BASE_URL` را عوض کنی، باید **دوباره build کنی**، فقط restart کافی نیست. پس `.env` را **قبل از** build آماده کن.

---

## ۶. بالا آوردن فرانت‌اند (اول فرانت، بعد بک‌اند)

```bash
cd /opt/faraman/delyar-front
docker compose up -d --build
```

این کار سه چیز می‌سازد: `nginx-proxy` (پورت ۸۰ و ۴۴۳)، `acme-companion` (گواهی HTTPS) و `web` (خود سایت).

**گواهی HTTPS معمولاً ۳۰ تا ۹۰ ثانیه بعد** از بالا آمدن صادر می‌شود. بررسی:

```bash
docker compose logs -f acme-companion
```

دنبال پیامی بگرد که می‌گوید گواهی برای `faraman.ai` صادر شد.

> **چرا اول فرانت؟** چون گواهی HTTPS و ورودی ترافیک از این پروژه می‌آید. بک‌اند و مانیتورینگ خودشان را به شبکهٔ همین پروژه وصل می‌کنند تا گواهی بگیرند.

---

## ۷. تنظیمات بک‌اند

```bash
cd /opt/faraman/back
cp .env.example .env
nano .env
```

مقادیر حیاتی — این‌ها را **حتماً** پر کن:

```env
# ─── امنیت (بدون این‌ها برنامه بالا نمی‌آید) ───
DEBUG=False
DJANGO_SECRET_KEY=<یک رشتهٔ تصادفی ۶۴ کاراکتری>
DJANGO_ALLOWED_HOSTS=api.faraman.ai,185.84.158.234,localhost,127.0.0.1
CSRF_TRUSTED_ORIGINS=https://api.faraman.ai,https://faraman.ai,http://185.84.158.234:81
CORS_ALLOWED_ORIGINS=https://faraman.ai,https://www.faraman.ai

# ─── دیتابیس (دست نزن، داخل شبکهٔ داکر کار می‌کند) ───
DB_NAME=faraman
DB_USERNAME=faraman
DB_PASSWORD=<یک رمز قوی>
DB_HOST=db
DB_PORT=5432
DB_CONN_MAX_AGE=0

# ─── Redis ───
REDIS_HOST=redis
REDIS_PORT=6379
REDIS_DB=0
REDIS_PASSWORD=<یک رمز قوی>

# ─── دامنه‌ها ───
FRONTEND_URL=https://faraman.ai
BACKEND_PUBLIC_URL=https://api.faraman.ai
ACME_EMAIL=admin@faraman.ai

# ─── ادمین ───
DJANGO_SUPERUSER_PHONE_NUMBER=0912xxxxxxx
DJANGO_SUPERUSER_PASSWORD=<رمز قوی>

# ─── پرداخت ───
ZARINPAL_MERCHANT_ID=<مرچنت زرین‌پال>
ZARINPAL_SANDBOX=False        # ← در محصول واقعی باید False باشد

# ─── پنل‌های مانیتورینگ ───
GRAFANA_ADMIN_PASSWORD=<رمز قوی>
GRAFANA_DOMAIN=grafana.faraman.ai
METABASE_DOMAIN=metabase.faraman.ai
METABASE_DB_PASSWORD=<رمز قوی>
METABASE_RO_PASSWORD=<رمز قوی>
GRAFANA_WEBHOOK_SECRET=<یک رشتهٔ تصادفی>
```

ساخت `DJANGO_SECRET_KEY`:

```bash
openssl rand -hex 32
```

### 🔑 اگر فعلاً هوش مصنوعی نمی‌خواهی

```env
REPORT_AI_ENABLED=false
DEEP_REPORT_AI_ENABLED=false
CHAT_AI_ENABLED=false
REPORT_INITIAL_VERSION=report_v1
```

با این سه، **نه کلید OpenAI لازم است و نه هزینه‌ای می‌دهی** — کاربر متن نمونه می‌گیرد. (بعداً که خواستی روشن کنی، `OPENAI_API_KEY`/`AVALAI_API_KEY` و مدل‌ها را پر کن و این سه را `true` کن. یادت باشد مدل تولید گزارش در Celery اجرا می‌شود، پس باید `celery`/`celery2` را ری‌استارت کنی.)

### 🔑 پیامک (اگر فعلاً نمی‌خواهی هزینه بدی)

```env
TEST_OTP_PHONE_NUMBERS=09120000000,09120000001
TEST_OTP_CODE=12345
```

این شماره‌ها پیامک واقعی نمی‌گیرند و با `12345` وارد می‌شوند. برای تست خودت کافی است.

### چند تلهٔ مهم در این فایل

- **خط‌هایی که خالی می‌گذاری مشکلی ندارند** — ولی مقدارشان خالی می‌ماند. مثلاً اگر `LIARA_SMTP_HOST` خالی باشد، ارسال ایمیل گزارش خطای تنظیمات می‌دهد (بقیهٔ برنامه سالم است).
- **`DEBUG=False` را با `DJANGO_SECRET_KEY` و `DJANGO_ALLOWED_HOSTS` خالی نگذار** — برنامه عمداً بالا نمی‌آید. این محافظت است، نه باگ.
- **`DJANGO_ALLOWED_HOSTS` باید IP سرور را هم داشته باشد**، وگرنه وقتی با `http://IP:81` تست می‌کنی خطای `DisallowedHost` می‌گیری.
- **اگر از CI/CD استفاده می‌کنی، `.env` را دستی نساز.** اسکریپت `scripts/render_env.sh` آن را از متغیرهای GitLab می‌سازد و برای **هر** کلیدِ `.env.example` یک خط می‌نویسد، حتی اگر متغیر تعریف نشده باشد (خط با مقدار خالی). به همین دلیل این پروژه هرگز از `os.getenv("X", default)` استفاده نمی‌کند.

---

## ۸. بالا آوردن بک‌اند

```bash
cd /opt/faraman/back
docker compose up -d --build --remove-orphans
```

`--remove-orphans` مهم است: کانتینرهای قدیمی که سرویسشان از فایل حذف/تغییر نام داده شده را پاک می‌کند (وگرنه ممکن است روی volume مشترک قفل بمانند).

بررسی:

```bash
docker compose ps
docker compose logs --tail=50 web
```

---

## ۹. ساخت دیتابیس و داده‌های اولیه

```bash
cd /opt/faraman/back

docker compose exec web python manage.py migrate
docker compose exec web python manage.py seed_test_assessment
docker compose exec web python manage.py seed_deep_assessment
docker compose exec web python manage.py create_default_superuser
```

سپس بررسی سالم بودن:

```bash
# از داخل خود سرور
curl -s http://localhost:81/health/
# → {"status": "ok"}

# از طریق دامنهٔ HTTPS (بعد از صدور گواهی)
curl -s https://api.faraman.ai/health/
```

و در مرورگر از بیرون:

| آدرس | نتیجهٔ درست |
|---|---|
| `https://faraman.ai` | صفحهٔ اصلی سایت |
| `https://api.faraman.ai/api/docs/` | مستندات API |
| `https://api.faraman.ai/admin/` | پنل مدیریت |
| `https://api.faraman.ai/health/` | `{"status":"ok"}` |

اگر دامنه جواب نداد ولی `http://localhost:81` جواب داد، مشکل در **گواهی یا DNS** است، نه در برنامه.

---

## ۱۰. بالا آوردن پنل‌های مانیتورینگ (اختیاری ولی توصیه‌شده)

اول دیتابیس و نقش فقط-خواندنی متابیس را بساز. این کار باید **فقط یک‌بار و قبل از اولین اجرای متابیس** انجام شود، وگرنه متابیس بالا نمی‌آید:

```bash
apt install -y make        # اگر make نداری
cd /opt/faraman/back
make metabase-init-db
```

> این کامند یک اسکریپت SQL داخل کانتینر Postgres اجرا می‌کند و دیتابیس متابیس، کاربر آن، و نقش **فقط-خواندنی** `metabase_ro` را می‌سازد. تکرارش هم بی‌خطر است. رمزهایش را از `METABASE_DB_PASSWORD` و `METABASE_RO_PASSWORD` در `.env` می‌خواند، پس اگر این دو خالی باشند کامند با پیام خطا متوقف می‌شود.

بعد استک مانیتورینگ را بالا بیاور:

```bash
docker compose --env-file .env -f monitoring/docker-compose.yml up -d
```

معادلش با make: `make monitoring-up`

بررسی:

```bash
docker compose --env-file .env -f monitoring/docker-compose.yml ps
```

پنل‌ها:

| آدرس | برای چه |
|---|---|
| `https://grafana.faraman.ai` | متریک‌ها، لاگ‌ها، هشدارها |
| `https://metabase.faraman.ai` | داشبورد محصول و کسب‌وکار |

ورود گرافانا با `GRAFANA_ADMIN_USER` / `GRAFANA_ADMIN_PASSWORD` از `.env`.

> **نکته:** گرافانا و متابیس **هیچ پورتی روی سرور باز نمی‌کنند**؛ فقط از طریق HTTPS در دسترس‌اند. دلیلش این است که داده‌شان شماره موبایل کاربران را دارد.

---

## ۱۱. پشتیبان‌گیری از دیتابیس

**این بخش در پروژه وجود ندارد و باید خودت اضافه کنی.** بدون آن، خرابی سرور یا volume یعنی از دست رفتن کامل داده.

فایل `/opt/faraman/backup.sh` را بساز:

```bash
cat > /opt/faraman/backup.sh <<'EOF'
#!/bin/bash
set -e
STAMP=$(date +%Y%m%d-%H%M)
DIR=/opt/backups
mkdir -p "$DIR"
cd /opt/faraman/back
docker compose exec -T postgres pg_dump -U faraman faraman | gzip > "$DIR/faraman-$STAMP.sql.gz"
find "$DIR" -name 'faraman-*.sql.gz' -mtime +14 -delete
EOF
chmod +x /opt/faraman/backup.sh
```

> نام کاربر و دیتابیس (`faraman` / `faraman`) همان `DB_USERNAME` و `DB_NAME` در `.env` است. اگر عوضشان کردی، در اسکریپت هم عوض کن.
> از `docker compose exec` استفاده می‌کنیم نه نام کانتینر، چون نام کانتینرها به نام پوشهٔ پروژه بستگی دارد و شکننده است.

زمان‌بندی روزانه ساعت ۳ بامداد:

```bash
crontab -e
# این خط را اضافه کن:
0 3 * * * /opt/faraman/backup.sh >> /var/log/faraman-backup.log 2>&1
```

**مهم:** این بکاپ روی همان سرور است. حتماً یک کپی هم **بیرون از سرور** ببر (مثلاً با `scp` یا یک فضای ابری).

بازگردانی:

```bash
cd /opt/faraman/back
gunzip -c /opt/backups/faraman-20260101-0300.sql.gz | docker compose exec -T postgres psql -U faraman -d faraman
```

---

## ۱۲. استقرار خودکار با GitLab (اختیاری)

پروژه از قبل تنظیم شده: یک runner از نوع **shell** روی خود سرور، و merge به `main` بلافاصله دیپلوی می‌کند.

```bash
# نصب GitLab Runner روی سرور
curl -L https://packages.gitlab.com/install/repositories/runner/gitlab-runner/script.deb.sh | bash
apt install -y gitlab-runner

# ثبت runner با تگ‌های مشخص‌شده در .gitlab-ci.yml
gitlab-runner register \
  --url https://hamgit.ir \
  --registration-token <TOKEN> \
  --executor shell \
  --tag-list "faraman-backend,faraman-frontend"
```

بعد در GitLab → **Settings → CI/CD → Variables** این‌ها را تعریف کن:

- **همهٔ** کلیدهای `.env.example` (بک‌اند و فرانت) به‌عنوان متغیر.
- سه متغیر مخصوص ساخت APK اندروید: `ANDROID_KEYSTORE_BASE64`, `BUBBLEWRAP_KEYSTORE_PASSWORD`, `BUBBLEWRAP_KEY_PASSWORD`.

> ⚠️ **تلهٔ اصلی:** اگر یک کلید در `.env.example` باشد ولی متغیر GitLab آن تعریف نشده باشد، `render_env.sh` آن را **خالی** می‌نویسد (خط را حذف نمی‌کند). این دقیقاً چیزی است که یک‌بار باعث کرش همهٔ workerها در محصول واقعی شد. برای همین همیشه هر کلید جدید را در **هر دو جا** اضافه کن.

---

## ۱۳. مشکلات رایج مخصوص ایران

| مشکل | چه اتفاقی می‌افتد | راه‌حل |
|---|---|---|
| **Docker Hub مسدود** | `docker pull` روی `registry-1.docker.io` با ۴۰۳ می‌خورد | همهٔ ایمیج‌ها از قبل از میرور آروان/لیارا کشیده می‌شوند؛ دست نزن |
| **تگ ایمیج در میرور پیدا نمی‌شود** | ۴۰۴ روی تگ نسخه | pgbouncer عمداً با digest پین شده. برای بقیه، از تگ‌هایی که قبلاً استفاده شده اند استفاده کن |
| **PyPI کند/مسدود** | build بک‌اند در مرحلهٔ pip گیر می‌کند | در `Dockerfile` یک `-i https://mirror-pypi.runflare.com/simple` به `pip install` اضافه کن |
| **npm کند** | build فرانت گیر می‌کند | در `Dockerfile` فرانت `npm config set registry https://registry.npmmirror.com` را قبل از `npm ci` اضافه کن |
| **`dl.google.com` مسدود** | فقط ساخت APK اندروید شکست می‌خورد | پروژه از قبل یک SOCKS proxy محلی برای این job تنظیم کرده؛ بدون آن، job اندروید را اجرا نکن |
| **OpenAI در دسترس نیست** | تولید گزارش/چت خطا می‌دهد | به همین دلیل این پروژه AvalAI را به‌عنوان مسیر جایگزین دارد. تا فعال‌شدنش، سه فلگ 🔑 را `false` بگذار |
| **FCM ناپایدار** | نوتیفیکیشن پوش دیر می‌رسد یا نمی‌رسد | طبیعی است؛ اعلان‌ها در DB ثبت می‌شوند و با `failure_reason` قابل بررسی‌اند |
| **Let's Encrypt** | معمولاً مشکلی ندارد | فقط پورت ۸۰ باید از بیرون باز و DNS درست باشد |

---

## ۱۴. چک‌لیست نهایی — وقتی همه‌چیز بالا آمد

این‌ها را یک‌بار از بیرون (نه از خود سرور) امتحان کن:

- [ ] `https://faraman.ai` باز می‌شود و قفل HTTPS درست است
- [ ] `https://www.faraman.ai` هم باز می‌شود
- [ ] `https://api.faraman.ai/health/` می‌دهد `{"status":"ok"}`
- [ ] `https://api.faraman.ai/api/docs/` همهٔ APIها را نشان می‌دهد
- [ ] ورود با شمارهٔ ادمین در `api/admin` کار می‌کند
- [ ] یک آزمون کامل تا گزارش انجام می‌شود
- [ ] صفحهٔ «کاوش» هر دو آزمون را نشان می‌دهد
- [ ] بعد از ۲ دقیقه، `https://grafana.faraman.ai` بالا می‌آید
- [ ] در گرافانا متریک‌های `faraman_*` دیده می‌شوند
- [ ] `docker compose ps` هیچ سرویس unhealthy ندارد
- [ ] فایل بکاپ در `/opt/backups` ساخته می‌شود
- [ ] یک `docker compose restart` بدون خطا انجام می‌شود

---

## ۱۵. کارهایی که بعد از راه‌اندازی باید انجام شود

| اولویت | کار | چرا |
|---|---|---|
| 🔴 فوری | انتقال بکاپ به بیرون سرور | الان بکاپ هم روی همان سرور است |
| 🔴 فوری | بستن پورت ۸۱ در فایروال (وقتی دیگر لازم نیست) | سطح حمله کمتر |
| 🔴 فوری | بستن پورت‌های ۹۰۹۰ گرافانا/پروومتئوس اگر باز شدند | فقط از طریق HTTPS دیده شوند |
| 🟠 مهم | اضافه‌کردن تنظیمات امنیتی HTTPS (HSTS، کوکی امن، ریدایرکت) | `manage.py check --deploy` این‌ها را لیست می‌کند |
| 🟠 مهم | روشن‌کردن مرحلهٔ تست در CI | بدون آن، هر deploy بدون تست به محصول می‌رود |
| 🟠 مهم | ساختن یک محیط آزمایشی (staging) | الان هیچ جایی برای امتحان‌کردن قبل از محصول نیست |
| 🟡 خوب | افزونگی دیتابیس (replica) و Redis | الان هر دو تک‌نسخه‌ای‌اند |
| 🟡 خوب | صف جدا برای گزارش عمیق + محدودیت زمانی تسک‌ها | تا یک گزارش طولانی بقیه را عقب نیندازد |

---

## جمع‌بندی در سه خط

1. **روی ویندوز:** Docker Desktop + یک شبکهٔ مشترک + `.env` با سه فلگ خاموشِ هوش مصنوعی = بک‌اند بالا. فرانت را با `npm run dev` جدا اجرا کن و از `http://localhost:81` به بک‌اند وصل شو.
2. **روی سرور:** اول فرانت (چون HTTPS و شبکه از آن می‌آید)، بعد بک‌اند، بعد migrate و seed، بعد مانیتورینگ. پوشهٔ فرانت باید `delyar-front` نام داشته باشد.
3. **دو چیزی که همیشه یادت بماند:** `.env` را قبل از build آماده کن (کلیدهای فرانت دوخته می‌شوند)، و هر کلید جدید را هم در `.env.example` و هم در متغیرهای GitLab اضافه کن.
