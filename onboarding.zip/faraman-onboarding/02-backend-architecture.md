# معماری و ساختار بک‌اند — فرامن (`faraman_back`)

> این سند جزئیات فنی بک‌اند است: تکنولوژی‌ها، لایه‌بندی، هر اپ، لایهٔ AI، مدل داده، API، تسک‌های آسنکرون، زیرساخت و بدهی فنی.
> برای نمای کلی محصول و وضعیت پروژه، سند `01-project-overview.md` را ببین.

---

## ۱. معرفی و نقش

بک‌اند فرامن یک **مونولیت Django** است که همهٔ منطق کسب‌وکار، داده، هوش مصنوعی، پرداخت و اعلان را در خود دارد. فرانت‌اند فقط یک **مصرف‌کنندهٔ HTTP** است — هیچ دسترسی مستقیمی به دیتابیس، Redis، کلید OpenAI، SMTP یا درگاه پرداخت ندارد.

- نام پکیج پروژه: `faraman_back`
- ریشهٔ کد: `back-main/`
- پوشهٔ اپ‌ها: `apps/` (۱۱ اپ دامنه)
- دامنهٔ عمومی در prod: `api.faraman.ai`
- مسیر مستندات زندهٔ API: `/api/docs/` (Swagger UI)، `/api/redoc/`، `/api/schema/`

---

## ۲. تکنولوژی‌ها و نسخه‌ها

### هستهٔ فریم‌ورک

| مورد | نسخه / انتخاب | نقش |
|---|---|---|
| Python | ۳.۱۰ (ایمیج `python:3.10-slim`) | زبان |
| Django | `5.2.4` | فریم‌ورک |
| Django REST Framework | `3.16.1` | لایهٔ API |
| drf-spectacular | `0.28.0` + sidecar | تولید OpenAPI و Swagger/ReDoc |
| SimpleJWT | `5.5.1` + `token_blacklist` | احراز هویت |
| django-cors-headers | `4.9.0` | CORS برای کوکی `anonymous_id` |
| python-dotenv | `1.0.0` | بارگذاری `.env` |
| gunicorn | `21.2.0` | سرور WSGI |
| gevent + psycogreen | `26.8.0` / `1.0.2` | کانکارنسی سبک + پچ‌کردن psycopg2 |
| WhiteNoise | `>=6.0.0` | سرو فایل‌های استاتیک در prod |

### داده و صف

| مورد | نسخه | نقش |
|---|---|---|
| PostgreSQL | `postgres:16-alpine` | دیتابیس اصلی |
| pgbouncer | `edoburu/pgbouncer` (digest-pinned) | pooler با `pool_mode=transaction` — سرویس `db` |
| psycopg2-binary | `2.9.10` | درایور |
| redis | `redis:7-alpine` + `redis 6.4.0` (کلاینت) | OTP، throttleها، broker/result بک‌اند Celery |
| Celery | `5.5.3` | صف کار آسنکرون |

### سرویس‌های خارجی

| سرویس | کاربرد | محل استفاده |
|---|---|---|
| **OpenAI** (SDK `openai==2.48.0`) | تولید گزارش و چت | `apps/ai/openai_client.py` |
| **AvalAI** | fallback سازگار با OpenAI (همان شناسه‌های مدل، مسیر infra متفاوت) | همان فایل، `PROVIDERS` |
| **Melipayamak** | ارسال پیامک OTP | `apps/account/services/sms_service.py` |
| **Liara SMTP** | ارسال ایمیل گزارش | `apps/report/services/email_service.py` |
| **WeasyPrint** `70.0` | تبدیل HTML گزارش به PDF برای ضمیمهٔ ایمیل | `apps/report/services/pdf_service.py` |
| **Zarinpal** (REST v4) | درگاه پرداخت | `apps/payment/services/zarinpal_client.py` |
| **Firebase Admin (FCM)** | پوش نوتیفیکیشن | `apps/notifications/services/push_sender.py` |
| **Bale Bot API** | ارسال آلرت‌های Grafana به پیام‌رسان بله | `apps/alerting/services/bale_service.py` |

### مانیتورینگ و ابزار

`django-prometheus==2.3.1`، `prometheus-client==0.21.1`، + استک جدا: Prometheus، Grafana، Loki، Promtail، node/postgres/redis/celery-exporter، Metabase. تست بار: **Locust**.

### پکیج‌های Pydantic

`pydantic==2.9.2` — **فقط در مرز AI** استفاده می‌شود (اعتبارسنجی payload ورودی به سرویس AI و اعتبارسنجی خروجی JSON مدل). در لایهٔ API از DRF Serializer استفاده می‌شود، نه Pydantic.

> ⚠️ **`requirements.txt` تمیز نیست.** یک استک قدیمی کامل (Flask 3, SQLAlchemy 1.4, Alembic, Flask-Migrate, zeep, suds-community, pyfcm, APScheduler, django-emoji, `google-cloud-*`, `google-api-python-client` و…) هنوز نصب می‌شود، در حالی که هیچ‌جای `apps/` و `faraman_back/` از آن‌ها import نمی‌کند. ایمپورت‌های واقعی third-party در کل کد این‌ها هستند: `django`, `rest_framework`, `rest_framework_simplejwt`, `drf_spectacular`, `celery`, `redis`, `requests`, `pydantic`, `prometheus_client`, `melipayamak`, `dotenv`, `weasyprint`, `openai` (lazy)، `firebase_admin` (lazy)، `httpx`. پاک‌سازی این فایل یک کار کم‌ریسک و پرارزش برای شروع است.

---

## ۳. ساختار پوشه‌ها

```
back-main/
├── manage.py
├── requirements.txt
├── Dockerfile                  # python:3.10-slim + deps سيستمی WeasyPrint + collectstatic
├── entrypoint.sh               # پاک‌سازی multiproc dir + exec gunicorn (gevent)
├── gunicorn.conf.py            # post_fork → psycogreen patch + child_exit hook
├── docker-compose.yml          # postgres, db(pgbouncer), redis, web, web2, celery, celery2, celery-beat, nginx
├── Makefile                    # up/down/migrate/test/worker/beat/monitoring/loadtest/seed...
├── .env.example                # فهرست کامل متغیرها (مرجع render_env.sh)
├── .gitlab-ci.yml              # build → (test کامنت‌شده) → deploy → monitoring
│
├── faraman_back/               # «هستهٔ مشترک» — infra، نه دامنه
│   ├── settings.py             # تمام تنظیمات، با کامنت‌های مفصل برای هر تصمیم
│   ├── urls.py                 # نقشهٔ URL کل (api/*)
│   ├── middleware.py           # HealthCheckMiddleware + AnonymousIdMiddleware
│   ├── celery.py               # app + import celery_metrics
│   ├── wsgi.py / asgi.py
│   ├── utils/
│   │   ├── responses.py        # ApiResponse (envelope)
│   │   ├── exceptions.py       # AppException
│   │   ├── exception_handler.py# app_exception_handler (global DRF handler)
│   │   └── schema.py           # error_responses() برای drf-spectacular
│   ├── lang/
│   │   ├── utils.py            # get_message(key, **kwargs)
│   │   └── fa/messages.py      # همهٔ رشته‌های کاربرپسند
│   └── observability/
│       ├── metrics.py          # متریک‌های faraman_* + @observe + observe_block
│       ├── celery_metrics.py   # سرو متریک‌های pool روی :9809
│       └── testing.py          # read_metric (دلتا-محور برای تست)
│
├── apps/                       # ۱۱ اپ دامنه، همه با لایه‌بندی یکسان
│   ├── account/                # کاربر، OTP، JWT، پروفایل، جمعیت‌شناسی
│   ├── assessment/             # آزمون، سؤال، attempt، پاسخ
│   ├── report/                 # گزارش، امتیازدهی، حافظه، PDF، ایمیل، تسک‌ها
│   ├── chat/                   # نشست و پیام چت، SSE، فیدبک/بوکمارک
│   ├── action_steps/           # قدم‌های عملی، deadline، بازتاب
│   ├── notifications/          # اعلان زمان‌بندی‌شده + پوش FCM
│   ├── payment/                # محصول، کوپن، پرداخت، خرید، entitlement
│   ├── events/                 # ردیابی رویداد محصول + UTM
│   ├── feedback/               # فیدبک محصول
│   ├── alerting/               # رلهٔ وب‌هوک Grafana → بله
│   └── ai/                     # لایهٔ مدل: پرامپت، فراخوانی، اسکیما، قیمت‌گذاری
│
├── docs/                       # specهای محصول + database-design + infrastructure
├── nginx/                      # nginx.conf + Dockerfile
├── monitoring/                 # استک مانیتورینگ مستقل (compose جدا)
├── loadtest/                   # Locust (compose و Dockerfile جدا)
└── scripts/render_env.sh       # ساخت .env از متغیرهای CI/CD
```

---

## ۴. معماری لایه‌ای — مهم‌ترین چیزی که باید یاد بگیری

هر اپ دامنه **دقیقاً** همین ساختار را دارد و هر لایه فقط با لایهٔ پایین‌تر خودش حرف می‌زند:

```
apps/<app>/
├── models.py                      # مدل‌های ORM
├── repositories/*_repository.py   # تنها جایی که Model.objects / redis / هر storage لمس می‌شود
├── services/*_service.py          # منطق کسب‌وکار؛ repositoryها را ارکستر می‌کند
├── services/exceptions.py         # زیرکلاس‌های AppException برای خطاهای دامنه
├── serializers/*_serializer.py    # فقط اعتبارسنجی ورودی و شکل‌دهی خروجی
├── views/*_view.py                # کنترلرهای نازک APIView
├── urls.py  admin.py  apps.py
├── migrations/
└── tests.py
```

**جریان داده:**

```
HTTP request
   │
   ▼
view            ← serializer داده را validate می‌کند، request.user را می‌گیرد
   │               (بدون هیچ منطقی؛ دقیقاً یک متد سرویس صدا می‌زند)
   ▼
service         ← تمام منطق؛ چند repository را ترکیب می‌کند؛
   │               خطای دامنه raise می‌کند (AppException)
   ▼
repository      ← تنها لایه‌ای که ORM/Redis را می‌شناسد
   │
   ▼
ApiResponse.success(data)  →  { code, message, data }
```

### قواعد سخت (غیرقابل مذاکره)

1. **view باید نازک بماند.** فقط: validate سریالایزر، استخراج دادهٔ درخواست، صدا زدن **یک** متد سرویس، برگرداندن `ApiResponse`. بدون منطق، بدون دسترسی مستقیم به مدل/repository.
2. **repository تنها نقطهٔ دسترسی به storage است.** هیچ سرویس یا viewی `Model.objects.*` یا کلاینت Redis را مستقیم صدا نمی‌زند. اگر سرویس کوئری جدید می‌خواهد، متد جدید در repository اضافه کن.
3. **خطاها همیشه `AppException` هستند، نه استثنای خام.** سرویس‌ها از `services/exceptions.py` raise می‌کنند (هر کدام با `status_code` و `message_key`). هندلر global (`app_exception_handler`) آن را به envelope تبدیل می‌کند — پس view هرگز نباید try/except کند.
4. **همهٔ importها بالای ماژول.** import داخل تابع فقط برای شکستن یک چرخهٔ واقعی و با کامنت توضیحی مجاز است. (استثنای مستند: `apps/report/tasks.py` برای چرخهٔ `tasks ↔ report_service`، و lazy-init عمدی در `push_sender.py`.)
5. **همهٔ رشته‌های کاربرپسند از `get_message(key)` می‌آیند**، نه هاردکد.

### الگوی Dependency Injection

سرویس‌ها همکارانشان را به‌صورت kwarg اختیاری می‌گیرند و به یک نمونهٔ واقعی default می‌دهند:

```python
class EventService:
    def __init__(self, event_repository=None):
        self.event_repository = event_repository or EventRepository()
```

هدف **فقط تست‌پذیری** است: تست‌ها `MagicMock()` تزریق می‌کنند و به DB/Redis دست نمی‌زنند. این یک فریم‌ورک DI نیست و نباید یکی اضافه شود.

### الگوهای تکمیلی که در کد می‌بینی

- **Lazy property برای سرویس‌های خارجی**: `OtpService.sms_service`، `ReportService.email_service`، `AlertService.bale_service` به‌صورت property ساخته می‌شوند. **دلیل مهم:** DRF فقط بدنهٔ متد هندلر (`post()`) را در try/except می‌پیچد، نه `__init__` ویو را. اگر `SMSService()` در `__init__` ویو ساخته شود و کانفیگش ناقص باشد، خطا از هندلر global عبور می‌کند و ۵۰۰ خام می‌دهد.
- **Throttle repositoryها**: `OtpRepository`, `EventThrottleRepository`, `AttemptThrottleRepository`, `ChatMessageThrottleRepository`, `ReportEmailThrottleRepository` — همه یک الگو: کلید Redis + `INCR` + `EXPIRE`، و **fail-open** در خطای Redis (یعنی اگر Redis بخوابد، کاربر بلاک نمی‌شود).
- **ایندکس denormalized برای خواندن‌های داغ**: `ChatSession.title` و `ChatSession.last_message_at` در `ChatMessageRepository.create` نگه‌داری می‌شوند تا لیست نشست‌ها یک کوئری باشد (قبلاً ۱۰۰۱ کوئری برای ۵۰۰ نشست).

---

## ۵. زیرساخت مشترک (`faraman_back/`)

### ۵.۱ `utils/responses.py` — `ApiResponse`

```python
ApiResponse.success(data)                    # { code:1, message:..., data:... }
ApiResponse.error(message, status_code, code=0, message_key=None)
ApiResponse.validation_error(data)           # 406
ApiResponse.error_404()
```

**همهٔ پاسخ‌ها این envelope را دارند.** `message_key` (که در نسخه‌های اخیر اضافه شد) یک شناسهٔ ماشین‌خوانِ پایدار است تا فرانت‌اند بدون پارس کردن متن فارسی بتواند علت را تشخیص دهد (مثلاً `otp_request_throttled`, `sms_send_failed`).

### ۵.۲ `utils/exceptions.py` — `AppException`

```python
class AppException(Exception):
    status_code = 500
    code = 0
    message_key = 'system_error'
    # message → get_message(message_key, **format_kwargs)
```

هر اپ زیرکلاس‌های خودش را در `services/exceptions.py` دارد، مثلاً:

- `OtpRequestThrottledException` (429)، `InvalidOTPException` (400)، `SmsDeliveryError` (502)
- `ReportNotReadyException`، `ReportAccessDeniedException`، `ScoreOutOfRangeException` (500 — چون یعنی داده خراب است)
- `ChatMessageLimitExceededException` (429)، `RegenerateNotAllowedException`
- `PaymentCancelledException`، `PaymentVerificationFailedException`، `PaymentGatewayException`

### ۵.۳ `utils/exception_handler.py`

```python
def app_exception_handler(exc, context):
    if isinstance(exc, AppException):
        return ApiResponse.error(message=exc.message, status_code=exc.status_code, ...)
    return drf_exception_handler(exc, context)   # بقیه به DRF واگذار می‌شود
```

ثبت‌شده در `REST_FRAMEWORK['EXCEPTION_HANDLER']`.

> **تنها استثنای عمدی در کل کدبیس:** `PaymentCallbackAPIView.get`. caller آن مرورگر خود خریدار است (از ریدایرکت زرین‌پال)، نه یک کلاینت JSON. لذا خودش استثناها را می‌گیرد و `HttpResponseRedirect` با پارامتر `status=` برمی‌گرداند. envelope JSON آنجا بی‌فایده بود.

### ۵.۴ `lang/` — i18n با message key

```python
# faraman_back/lang/utils.py
def get_message(key, **kwargs): ...   # از lang/<LANGUAGE_CODE>/messages.py
```

`LANGUAGE_CODE = 'fa'`، `LANGUAGES = [('fa',...), ('en',...)]`. اضافه‌کردن زبان جدید = اضافه‌کردن یک پکیج `lang/<code>/`.

### ۵.۵ `middleware.py`

| میدل‌ور | کار |
|---|---|
| `HealthCheckMiddleware` | `GET /health` و `/health/` → `{"status":"ok"}` با ۲۰۰. **اولین** عضو زنجیره است تا قبل از host validation و قبل از histogram پرومتئوس جواب بدهد. عمداً dependency-free (DB/Redis را لمس نمی‌کند) چون یک healthcheck که با یک blip دیتابیس unhealthy شود، هر دو رپلیکای web را از rotation خارج می‌کند. |
| `AnonymousIdMiddleware` | کوکی پایدار `anonymous_id` (UUID hex، httponly، ۲ سال) می‌سازد و روی `request.anonymous_id` می‌گذارد. این کلید هویت کاربر پیش از لاگین است (آزمون و رویدادها). |

### ۵.۶ `observability/` — متریک‌های اپلیکیشن

متریک‌ها با پیشوند `faraman_` تعریف می‌شوند تا با متریک‌های `django_*` ناشی از django-prometheus قاطی نشوند.

| متریک | برچسب‌ها | چه چیزی را می‌گوید |
|---|---|---|
| `faraman_report_generation_duration_seconds` | `report_type`, `outcome` | زمان کل تولید گزارش (ok/error/noop) |
| `faraman_report_generation_in_progress` | `report_type` | تعداد تولیدهای جاری |
| `faraman_chat_answer_duration_seconds` | `kind`, `outcome` | زمان پاسخ چت (شامل `client_disconnect`) |
| `faraman_chat_answer_ttft_seconds` | `kind` | Time-To-First-Token |
| `faraman_chat_answer_in_progress` | `kind` | چت‌های جاری |
| `faraman_ai_call_duration_seconds` | `purpose`, `call`, `provider`, `outcome` | **هر پله از نردبان تلاش** — دقیق‌ترین متریک هزینه/کیفیت |
| `faraman_throttle_rejected_total` | `scope` | تنها Counter ماژول: `otp_request`, `otp_verify_lockout`, `chat_message`, `report_email`, `assessment_attempt` |
| `faraman_notification_send_duration_seconds` | `kind`, `outcome` | نتیجهٔ ارسال پوش (`sent`/`no_subscriptions`/`all_tokens_invalid`/`send_error`) |
| `faraman_report_email_delivery_duration_seconds` | `outcome` | ارسال SMTP |
| `faraman_report_pdf_render_duration_seconds` | `outcome` | رندر WeasyPrint |
| `faraman_alert_delivery_duration_seconds` | `outcome` | ارسال به بله |

الگوی استفاده:

```python
@observe(REPORT_GENERATION_DURATION, in_progress=REPORT_GENERATION_IN_PROGRESS,
         labels={"report_type": "initial"}, outcome=report_generation_outcome)
def generate_initial(self, attempt_id): ...
```

`@observe` و `observe_block` در `metrics.py` هستند تا در محل استفاده یک خط باشند، نه boilerplate زمان‌سنجی همه‌جا.

**جزئیات مهم عملیاتی:**

- `PROMETHEUS_MULTIPROC_DIR` فقط روی `web`/`web2`/`celery`/`celery2` در `docker-compose.yml` ست می‌شود (**نه** در `.env.example` — چون `render_env.sh` آن را به‌صورت خالی می‌نویسد و prometheus_client با مقدار خالی نیمه‌خراب می‌شود).
- `entrypoint.sh` این پوشه را در هر استارت پاک و بازسازی می‌کند (workerهای OOM/KILL شده فایل‌های کهنه جا می‌گذارند که تا ابد در counterها جمع می‌شوند). `gunicorn.conf.py` در `child_exit` فایل‌های pid را retire می‌کند.
- در حالت multiprocess، `/metrics` دیگر `process_*`/`python_gc_*`/`python_info` را ندارد (این‌ها per-worker هستند و در ۳ worker بی‌معنا). پوشش container/host کار node-exporter است.
- یک سری `faraman_*` تا اولین مشاهده در `/metrics` ظاهر نمی‌شود → در داشبورد از `rate()`/`sum()` استفاده کن، نه متریک خام.
- در تست‌ها (`manage.py test`) این env var حذف می‌شود و assertionها باید **دلتا**محور باشند (`observability/testing.py::read_metric`).

---

## ۶. تحلیل `settings.py`

فایل تنظیمات این پروژه غیرمعمول است چون **هر تصمیم کامنت دارد**. مهم‌ترین‌ها:

### امنیت و boot guard

```python
DEBUG = os.getenv('DEBUG', 'False') == 'True'      # پیش‌فرض False (خلاف قالب خود Django)
SECRET_KEY = os.getenv('DJANGO_SECRET_KEY') or ('django-insecure-dev-only-key' if DEBUG else None)
if not DEBUG:
    if not SECRET_KEY: raise ImproperlyConfigured(...)
    if not ALLOWED_HOSTS: raise ImproperlyConfigured(...)
```

دلیل: `SIMPLE_JWT` هیچ `SIGNING_KEY` ست نمی‌کند، پس از `SECRET_KEY` استفاده می‌کند. یک مقدار پیش‌فرض شناخته‌شده یعنی هر کسی می‌تواند توکن هر کاربری را جعل کند. حالا یک deploy ناقص **بالا نمی‌آید** به‌جای اینکه بی‌صدا traceback لو بدهد.

`ALLOWED_HOSTS` همیشه `web` و `web2` را هم دارد (تا scrape پرومتئوس روی `web2:8000/metrics` خطای DisallowedHost نگیرد).

### ترتیب `MIDDLEWARE`

```
HealthCheckMiddleware                 ← قبل از همه چیز
PrometheusBeforeMiddleware
CorsMiddleware
AnonymousIdMiddleware
SecurityMiddleware
WhiteNoiseMiddleware
SessionMiddleware
CommonMiddleware
CsrfViewMiddleware
AuthenticationMiddleware
MessageMiddleware
XFrameOptionsMiddleware
PrometheusAfterMiddleware             ← آخر از همه
```

`Before` اول و `After` آخر است تا histogram کل استک واقعی را بپوشاند.

### دیتابیس

```python
'ENGINE': 'django_prometheus.db.backends.postgresql'   # شمارش کوئری/تاخیر
'CONN_MAX_AGE': int(os.getenv('DB_CONN_MAX_AGE') or '0')   # ← صفر، عمدی
'CONN_HEALTH_CHECKS': True
```

`CONN_MAX_AGE=0` یعنی اتصال در پایان هر request بسته می‌شود. **این ضدشهودی است ولی درست است:** pgbouncer در حالت transaction خودش اتصال backend را گرم نگه می‌دارد؛ نگه‌داشتن اتصال سمت Django فقط بودجهٔ `MAX_CLIENT_CONN` pgbouncer را می‌سوزاند. با `CONN_MAX_AGE=60` در تست بار، `cl_active` به ۸۳ رسید و در ۲۰۰ کاربر `MAX_CLIENT_CONN=1000` تمام شد.

### Redis و Celery

```python
_redis_url = f"redis://{_redis_auth}{REDIS_HOST}:{REDIS_PORT}/{REDIS_DB}"
CELERY_BROKER_URL = os.getenv('CELERY_BROKER_URL', _redis_url)
CELERY_RESULT_BACKEND = os.getenv('CELERY_RESULT_BACKEND', _redis_url)
CELERY_TIMEZONE = "UTC"
CELERY_WORKER_SEND_TASK_EVENTS = True
CELERY_TASK_SEND_SENT_EVENT = True        # لازم برای celery-exporter
CELERY_BEAT_SCHEDULE = {
    "send-due-notifications": {"task": "notifications.send_due_notifications",
                               "schedule": timedelta(minutes=5)},
}
```

`CELERY_WORKER_CONCURRENCY` (پیش‌فرض ۴) در `.env.example` است و در `docker-compose.yml` با `${VAR:-4}` به `--concurrency` پاس می‌شود — یعنی سقف مصرف اتصال Celery معلوم است و pgbouncer بر اساس آن sizing شده.

### استاتیک

```python
STATIC_URL = "/static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
STORAGES = {"staticfiles": {"BACKEND": "whitenoise.storage.CompressedStaticFilesStorage"}}
```

`CompressedStaticFilesStorage` (نسخهٔ **بدون** manifest) عمدی است: بدون staging، یک پکیج ثالث که در CSSاش `url()` به فایل ناموجود اشاره کند، `collectstatic` را با manifest سخت‌شکست می‌کند. Dockerfile با `DEBUG=True python manage.py collectstatic --noinput` این را در زمان build انجام می‌دهد.

### DRF و JWT

```python
REST_FRAMEWORK = {
  'DEFAULT_SCHEMA_CLASS': 'drf_spectacular.openapi.AutoSchema',
  'EXCEPTION_HANDLER': 'faraman_back.utils.exception_handler.app_exception_handler',
  'DEFAULT_AUTHENTICATION_CLASSES': ('rest_framework_simplejwt.authentication.JWTAuthentication',),
  'DEFAULT_PERMISSION_CLASSES': ('rest_framework.permissions.IsAuthenticated',),   # پیش‌فرض: بسته
}
SIMPLE_JWT = {"ACCESS_TOKEN_LIFETIME": 30m, "REFRESH_TOKEN_LIFETIME": 7d}
```

**پیش‌فرض `IsAuthenticated` است** — یعنی هر endpoint بسته است مگر اینکه صریحاً `AllowAny` بگذاری. لیست endpointهای عمومی: OTP send/verify، token refresh، schema/docs، track event، payment products، payment callback، grafana webhook، assessment detail و pre-start (بخشی) و گزارش برای مالک ناشناس.

### بقیهٔ تنظیمات مهم

| تنظیم | مقدار پیش‌فرض | معنی |
|---|---|---|
| `AUTH_USER_MODEL` | `account.User` | مدل کاربر سفارشی |
| `LANGUAGE_CODE` / `TIME_ZONE` | `fa` / `UTC` | UTC در DB، تهران در محاسبهٔ deadline (با `zoneinfo`) |
| `TERMS_VERSION` | `v1` | نسخهٔ قوانین؛ با تغییر باید bump شود |
| `OTP_MAX_VERIFY_ATTEMPTS` | `5` | آستانهٔ قفل OTP |
| `CHAT_MESSAGE_LIMIT_COUNT` | `50` | سقف پیام چت در ۲۴ ساعت (send+regenerate مشترک)، عمداً خارج از `.env.example` |
| `ACTION_STEP_REMIND_HOUR` | `9` | ساعت پیش‌فرض یادآور به وقت تهران |
| `DEEP_LEVEL_LOW_MAX` / `HIGH_MIN` | `35` / `65` | مرزهای سطح در گزارش عمیق (چون norming نشده، config است نه literal) |
| `TEST_OTP_PHONE_NUMBERS` / `TEST_OTP_CODE` | — / `12345` | بای‌پس OTP برای اکانت تست |
| `ZARINPAL_SANDBOX` | `True` | پیش‌فرض sandbox |
| `BACKEND_PUBLIC_URL` / `FRONTEND_URL` | `localhost:8000` / `localhost:3000` | ساخت callback و ریدایرکت |
| `CORS_ALLOWED_ORIGINS` + `CORS_ALLOW_CREDENTIALS` | از `FRONTEND_URL` | برای کوکی `anonymous_id` |
| `LOGGING` | root → console, INFO | بدون این، `logging.getLogger(__name__)` در `apps/*` هیچ handlerی نداشت و لاگ‌ها می‌رفتند. |

### ⚠️ قاعدهٔ حیاتی env

`scripts/render_env.sh` برای **هر کلید موجود در `.env.example`** یک خط در `.env` می‌نویسد، حتی اگر متغیر CI تنظیم نشده باشد (مقدار خالی). پس:

```python
os.getenv('X', 'default')     # ❌ default هرگز fire نمی‌شود → int('') → کرش
os.getenv('X') or 'default'   # ✅
```

این دقیقاً یک incident واقعی روی production ساخته است. برای هر متغیر جدید (خصوصاً عددی/بولین) از idiom دوم استفاده کن، و آن را هم در `.env.example` و هم در متغیرهای GitLab ثبت کن.

---

## ۷. اپ‌ها یکی‌یکی

### ۷.۱ `apps/account` — هویت

**مدل:** `User` (زیرکلاس `AbstractBaseUser` + `PermissionsMixin`، `USERNAME_FIELD = phone_number`)، `AnonymousDemographics`.

`User` علاوه بر فیلدهای استاندارد: `reference_code` (کد ۱۰ کاراکتری یکتا برای معرفی)، `used_reference_code`، `gender`, `age`, `education`, `job`, `disorder`, `birth_year`, `life_situation`, `goal` (هر دو enum)، `terms_version`/`terms_accepted_at`، `utm_source`/`utm_campaign`، `is_deleted`/`deleted_at`.

**جریان OTP** (`services/otp_service.py`):

```
request_otp(phone)
 ├─ اگر شماره در TEST_OTP_PHONE_NUMBERS → فقط user را get_or_create کن، Redis/SMS نه
 ├─ اگر otp_repository.exists(phone) → OtpRequestThrottledException (429) + متریک
 ├─ user_repository.get_or_create_by_phone(phone, utm_source, utm_campaign)   ← اینجا User ساخته می‌شود
 │     (utm فقط داخل defaults → first-touch؛ کاربر قدیمی هرگز overwrite نمی‌شود)
 ├─ code = 5 رقم تصادفی
 ├─ otp_repository.save(phone, sha256(code)) با TTL ۵ دقیقه
 └─ sms_service.send_single(phone, code)   (اگر False → SmsDeliveryError)

verify_otp(phone, code)
 ├─ تطبیق hash
 ├─ اشتباه → otp_repository.increment_attempts (همان TTL)
 │            و اگر >= OTP_MAX_VERIFY_ATTEMPTS → OTP باطل + InvalidOTPException
 ├─ درست → user.last_login_at
 ├─ attempt_service.claim_anonymous_attempts(...)   ← آزمون‌های ناشناس به حساب می‌چسبند
 ├─ demographics_service.claim_for_user(...)       ← فرم جمعیت‌شناسی ناشناس هم
 └─ token_repository.issue_pair(user)              ← access/refresh
```

`token_repository.blacklist_all_for_user` برای logout، با یک `bulk_create(ignore_conflicts=True)` روی `OutstandingToken`ها (قبلاً برای هر توکن یک `get_or_create` بود).

**خروجی‌ها:** `/api/account/otp/send/`, `otp/verify/`, `token/refresh/`, `logout/`, `profile/`, `profile/demographics/`, `terms/accept/`, `delete/`.

**تست‌پذیری:** `apps/account/tests.py` الگوی مرجع است — repositoryها با `MagicMock` جایگزین می‌شوند.

---

### ۷.۲ `apps/assessment` — آزمون‌ها

**مدل‌ها:**

```
Assessment ─┬─ AssessmentSection ─── Question
            └─ Attempt ─── Answer
```

`Assessment` فیلدهای کلیدی: `slug`, `kind` (initial/supplementary)، **`scoring_profile`** (`big_five_30` یا `facet_150`)، `requires_purchase`، `report_requires_purchase`.

`Question.scoring` (JSONField) در آزمون عمیق کلید امتیازدهی را نگه می‌دارد؛ در آزمون کوتاه، dimension از **عنوان section** می‌آید. `reverse_scored` یعنی مقدار معکوس (`6 - value`).

`Attempt` هم `user` و هم `anonymous_id` دارد (هر دو nullable) + `source` (UTM) + `current_section`.

**سرویس‌ها:** `assessment_service` (خواندن ساختار آزمون)، `attempt_service` (start/submit/undo/complete + claim ناشناس + throttle)، `attempt_throttle_repository` (سقف تلاش روزانه، کلید روی شماره موبایل).

**مسیر حساس:** `AttemptService.complete_attempt` باید از **`ScoringRouter`** استفاده کند، نه `ScoringService` مستقیم. اگر اشتباه route شود، یک آزمون ۱۵۰ سؤالی کاملاً پاسخ‌داده «ناتمام» گزارش می‌شود.

**دادهٔ آزمون عمیق:** `apps/assessment/data/deep_150.py` — ترنسکرایپ `docs/Personality_150_Test_Scoring_Manual_FA_Ravi_v1.2.docx`. با `make seed-deep-assessment` (کامند `payment/management/commands/seed_deep_assessment.py`) به DB می‌رود؛ آزمون کوتاه با `seed_test_assessment`.

---

### ۷.۳ `apps/report` — قلب محصول

**مدل‌ها:**

| مدل | جدول | نقش |
|---|---|---|
| `Report` | `reports` | یک گزارش برای یک `Attempt` (OneToOne). `report_type` = initial/deep. |
| `Memory` | `user_memories` | حافظهٔ بلندمدت؛ یکتا روی `(user, memory_type, source)` |
| `GenerationLog` | `report_generation_logs` | یک ردیف **به ازای هر فراخوانی AI** (موفق یا ناموفق) + tokens + cost |
| `ReportEmailDelivery` | `report_email_deliveries` | یک ردیف به ازای هر تلاش ارسال ایمیل (sent/failed) |

`Report.status`:

```
generating ──► ok
     │
     ├──► awaiting_payment ──(پرداخت)──► generating ──► ok
     └──► error  ──(retry دستی)──► generating
```

`report_data` / `system_data` / `memory_candidates` = پاسخ مدل **دست‌نخورده**. `dimension_scores` / `facet_scores` / `domain_scores` / `quality_metrics` / `active_patterns` = محاسبهٔ deterministic خودمان.

`generation_started_at` با یک `UPDATE ... WHERE generation_started_at IS NULL` اتمیک ست می‌شود تا redelivery آت‌لیست‌وانس Celery باعث دو بار پرداخت برای یک گزارش نشود.

**سرویس‌ها:**

| فایل | کار |
|---|---|
| `report_service.py` (۹۸۰ خط) | orchestration گزارش اولیه + خواندن/پیش‌نمایش/تاریخچه/ایمیل/accept step |
| `deep_report_service.py` (۱۸۳ خط) | تولید گزارش عمیق (۸ فراخوانی) + persist حافظه + لاگ |
| `scoring_service.py` | امتیازدهی ۳۰ سؤالی → ۵ dimension + ۵ سطح (`very_low`…`high`) |
| `deep_scoring_service.py` | ۳۰ facet + ۵ domain index + core cross-check؛ فقط سه سطح `low/mid/high` |
| `scoring_router.py` | انتخاب scorer بر اساس `Assessment.scoring_profile` |
| `deep_patterns.py` | تشخیص الگوهای ترکیبی (کد، نه AI) |
| `report_presentation.py` | شکل‌دهی خروجی برای API |
| `ai_report_client.py` / `deep_ai_report_client.py` | آداپتور بک‌اند → لایهٔ `apps/ai` |
| `email_service.py` | SMTP لیارا (`EmailMultiAlternatives` + ضمیمهٔ PDF) |
| `pdf_service.py` | WeasyPrint؛ فونت وزیرمتن به‌صورت base64 داخل `pdf_base.html` |
| `exceptions.py` | خطاهای دامنهٔ گزارش |

**شکل‌دهی خروجی (`_shape`)**: بسته به نقشِ بیننده سه حالت دارد:

- کاربر مهمان و مالک ناشناس → `stage: "preview"` (تیزر)
- مالک لاگین‌کرده → `stage: "full"`
- گزارش deep → ساختار متفاوت، **بدون** فیلد `stage` (فرانت با نبودِ `stage` تشخیص می‌دهد)

**ایمنی داده در گزارش عمیق — سه قاعدهٔ غیرقابل نقض:**

1. هیچ نمرهٔ خامی به کلاینت نمی‌رسد؛ فقط `low`/`mid`/`high`.
2. مرزهای سطح (`DEEP_LEVEL_LOW_MAX`/`HIGH_MIN`) تنظیمات هستند نه literal — چون norming نشده.
3. `Core Domain Raw` ذخیره می‌شود ولی **هرگز نمایش داده نمی‌شود و هرگز به AI نمی‌رود**.

**تولید اولیه (آسنکرون):**

```
AttemptService.complete_attempt
   └─ ReportService.generate_for_attempt
        ├─ scoring (deterministic)
        ├─ Report(status=generating) را می‌نویسد
        └─ transaction.on_commit( → report.generate_initial_report.delay(attempt_id) )

Celery worker:
   ReportService.generate_initial(attempt_id)
        ├─ claim اتمیک روی generation_started_at
        ├─ AiReportClient → apps.ai.report_generation.generate_report(...)
        ├─ persist: report_data, system_data, memory_candidates, dimension_scores
        ├─ GenerationLog (tokens/model/cost)
        ├─ persist_memories  → Memory
        └─ report.mark_ok(...) یا mark_error(...)
```

**تولید عمیق:** `DeepReportService.generate` — امتیازدهی قبل از ساخت ردیف انجام می‌شود تا حتی اگر تولید شکست بخورد، امتیازها برای کار norming باقی بمانند.

**ایمیل گزارش:** `email_report()` از `_get_owned_ready_report` (همان preamble مالکیت + `status==OK`) استفاده می‌کند، بعد throttle سه‌بار در ساعت به ازای user+attempt (چون آدرس دلخواه پذیرفته می‌شود و بدون سقف یک ابزار اسپم است)، بعد رندر → PDF → SMTP → ثبت `ReportEmailDelivery`. هیچ Celery task ندارد چون سریع است.

---

### ۷.۴ `apps/chat` — دستیار

**مدل‌ها:**

- `ChatSession`: `UUID` PK، `user`, `entry_source`, `report` (nullable), `context_action_step`, `context_suggested_step`, `title` (denormalized), `last_message_at` (denormalized + ایندکس `(user, -last_message_at)`).
- `ChatMessage`: `role` (user/assistant), `content`, `proposed_action` (JSON), `quick_replies` (JSON), `prompt_version`, `generation_meta`, `action_accepted_at`.
- `MessageFeedback`, `MessageBookmark`, `ChatGenerationLog`.

**`ChatService` (۶۷۰ خط) — مهم‌ترین فایل چت:**

- `create_session` — اعتبارسنجی `entry_source` با regex؛ برای منابع گزارش‌محور وجود و نوع و نسخهٔ گزارش را چک می‌کند؛ برای منابع قدم‌محور وضعیت قدم را.
- `_build_payload` — می‌سازد: `history` (۳۰ پیام آخر)، `user_memory` (فقط ۴ نوع مجاز)، `action_context.current` + `.recent` (۳ قدم آخر)، `report` کامل یا متمرکز، `report_version`.
- `_stream` — ژنراتور SSE؛ سه نوع event: `delta`, `done`, `error`. کارهای مهم:
  - متریک TTFT را در لحظهٔ اولین delta ثبت می‌کند.
  - روی `GeneratorExit` (کاربر قطع کرد) `outcome=client_disconnect` و متن تولیدشده تا آن لحظه **ذخیره می‌شود** (`accumulated`) — کار کاربر دور ریخته نمی‌شود.
  - روی خطا `event: error` می‌فرستد و پیام را به‌عنوان assistant ذخیره می‌کند.
- `send_message` / `regenerate_message` — **تمام اعتبارسنجی‌ها eager** انجام می‌شود (طول پیام، مالکیت، throttle) تا خطاها **قبل از** اولین بایت به‌صورت envelope معمولی برگردند. فقط خطاهای زمان تولید به `event: error` تبدیل می‌شوند. regenerate فقط روی **آخرین** پیام مجاز است و پیام قبلی را حذف می‌کند.
- `accept_action` — کارت پیشنهادی را به `ActionStepService.create_step` می‌دهد.

**SSE wire format:**

```
event: delta
data: {"text": "..."}

event: done
data: {"status":"ok","prompt_version":"chat_v3","message_id":123,
       "message":"...","proposed_action":null,"quick_replies":[...],"generation_meta":{...}}

event: error
data: {"status":"error","code":"generation_failed","user_message":"..."}
```

> این فرمت **envelope `ApiResponse` نیست** — عمدی است. `message_id` و `quick_replies` هم افزودهٔ همین بک‌اند است (در قرارداد سرویس AI نیست) تا فرانت بتواند `accept-action` را هدف بگیرد.

**محدودیت‌ها:** `MAX_MESSAGE_LENGTH = 4000`، `CHAT_MESSAGE_LIMIT_COUNT = 50` در ۲۴ ساعت (send+regenerate یک شمارندهٔ مشترک)، صفحه‌بندی لیست نشست‌ها ۳۰ (حداکثر ۱۰۰).

---

### ۷.۵ `apps/action_steps` — قدم‌های عملی

**مدل‌ها:** `ActionStep` (UUID PK) + `ActionStepResponse`.

`ActionStep`: `source` (regex-validated: `chat`, `initial_report:rec_n`, `deep_report:action_n`)، `step_text`، `substeps` (JSON)، `deadline_type`/`deadline_at`/`remind_at`/`followup_at`، `status` (pending/done/partial/not_done)، `reflection`، `obstacle`، `edit_count`، timestamps.

`deadline_calculator.py` — منطق مهم به وقت **Asia/Tehran**:

- `tonight` → امروز ۲۳:۵۹
- `tomorrow_morning` → فردا ۱۲:۰۰
- `tomorrow_evening` → فردا ۲۳:۵۹
- `within_24h` → الان + ۲۴ ساعت
- اگر لحظهٔ محاسبه‌شده گذشته باشد (مثلاً «امشب» ساعت ۲۳:۵۹ انتخاب شود) → خودکار به `within_24h` سقوط می‌کند. **این تصحیح در بک‌اند انجام می‌شود، هرگز در پرامپت** (چون مدل نباید ساعت داشته باشد؛ این prompt caching را می‌شکند).
- `remind_at` = همان روز deadline ساعت `ACTION_STEP_REMIND_HOUR` (پیش‌فرض ۹)، اگر گذشته باشد → فوری.

---

### ۷.۶ `apps/notifications` — اعلان و پوش

**مدل‌ها:** `PushSubscription` (توکن یکتا، `is_active`)، `Notification` (`kind`: reminder/followup، `scheduled_for`، `status`: scheduled/sent/failed، `failure_reason`).

- `schedule_for_step` هنگام ساخت/ویرایش قدم، دو نوتیفیکیشن می‌سازد (reminder + followup).
- `send_due` توسط Celery beat هر ۵ دقیقه اجرا می‌شود.
- `_send_one` با `@observe` پوشیده شده و یکی از `sent` / `no_subscriptions` / `all_tokens_invalid` / `send_error` را برمی‌گرداند. **قبلاً دو مسیر از سه مسیر شکست، هیچ لاگی نداشتند** — یعنی ردیف‌های `failed` در DB بدون هیچ سرنخی. این رفع شد.
- `push_sender.py` با `firebase_admin` (lazy init) و پوشش **data-only** ارسال می‌کند. عمدی: اگر پیام فیلد `notification` داشته باشد، خود SDK مرورگر یک نوتیف بومی نشان می‌دهد و `onBackgroundMessage` در service worker هم یکی دیگر → دو نوتیف. data-only باعث می‌شود `showNotification()` تنها منبع حقیقت باشد.
- توکن باطل (`UnregisteredError`) → `PushTokenInvalidException` → subscription غیرفعال می‌شود.

---

### ۷.۷ `apps/payment` — پرداخت و دسترسی

**مدل‌ها:** `Product`, `Coupon`, `Payment`, `Purchase`.

- `Product`: `sku`, `kind`, `price` (تومان)، `assessment` (PROTECT).
- `Coupon`: درصدی (۱..۱۰۰)، `max_redemptions`، `redemptions_count`، `expires_at`. اعتبارسنجی و مصرف با `select_for_update` داخل یک `transaction.atomic` (تنها `select_for_update` کل پروژه — و همین یکی هم با `pool_mode=transaction` سازگار است چون در یک request اسکوپ شده).
- `Payment`: `status` (pending/paid/cancelled/failed)، `authority`, `ref_id`, `gateway_response` (payload خام برای audit)، `amount` (snapshot قیمت پس از کوپن).
- `Purchase`: OneToOne با `Payment`؛ `consumed_at` برای مدل «هر آزمون یک خرید».

**`EntitlementService` تنها منبع حقیقت دسترسی است:** `has_access`, `has_access_to_assessment`, `consume_for_assessment`, `list_product_prices`. هیچ سرویس یا view دیگری نباید `Purchase` را مستقیم query کند.

**جریان زرین‌پال:**

```
POST /api/payment/initiate/  → PaymentService.initiate_payment
   ├─ محصول فعال برای assessment
   ├─ کوپن (اختیاری) → محاسبهٔ مبلغ
   ├─ ZarinpalClient.request_payment(amount, callback_url=BACKEND_PUBLIC_URL/api/payment/callback/,
   │                                 metadata={"mobile": user.phone_number})
   └─ Payment(pending, authority)

GET /api/payment/callback/?Authority=..&Status=..
   ├─ verify_payment → Zarinpal verify
   ├─ موفق → Purchase (grant_or_reactivate) + اگر گزارش awaiting_payment بود → unlock + dispatch تولید
   ├─ لغو → 302 به FRONTEND_URL/payment/result?status=cancelled&attempt_id=..
   └─ خطا → 302 با status=failed
```

> ⚠️ نکتهٔ ظریف: `mobile` باید داخل `metadata` باشد. نسخهٔ قبلی آن را در ریشهٔ payload می‌فرستاد؛ زرین‌پال آن را می‌پذیرد ولی نادیده می‌گیرد، پس قابلیت «کارت‌های ذخیره‌شده» هرگز فعال نمی‌شد.

---

### ۷.۸ `apps/events` — تحلیل و قیف

**مدل:** `Event` با ~۲۷ نام رویداد (landing_viewed، test_started، test_completed، report_generated، paywall_*، auth_*، chat_opened، deep_*، …) و فیلدهای `properties` (JSON)، `utm_source`, `utm_campaign`, `occurred_at`.

**دو لایهٔ محافظت:**

1. **Allowlist پراپرتی به ازای هر رویداد** (`TrackEventSerializer.ALLOWED_PROPERTY_KEYS`) — فرانت نمی‌تواند داده دلخواه (و بالقوه حساس) در رویداد بریزد. کلیدهای `utm_source`/`utm_campaign` روی **همهٔ** رویدادهای محدودشده مجازند (`ATTRIBUTION_KEYS`) تا قیف هر کمپین در Metabase بدون رویداد جدید قابل فیلتر باشد.
2. **ستون‌های واقعی UTM** — `Event.utm_source`/`utm_campaign` در زمان نوشتن از `properties` کپی می‌شوند، چون هیچ ایندکسی روی JSON نیست و `properties->>'utm_campaign'` کل جدول را اسکن می‌کند. ایندکس partial: `(utm_campaign, event_name, created_at) WHERE utm_campaign <> ''`.

`EventThrottleRepository` هم نرخ ارسال رویداد را محدود می‌کند (fail-open).

---

### ۷.۹ `apps/feedback`

مدل `Feedback`: `target_type` (چند نوع مثل report/message/app)، `target_id`، `rate` (0..5)، `reason`، `comment` + soft delete. یک serializer + service + view.

---

### ۷.۱۰ `apps/alerting` — رلهٔ Grafana → بله

اپ **بدون مدل**: `serializer → service → view`. Grafana یک وب‌هوک عمومی به `POST /api/alerting/grafana-webhook/<secret>/` می‌زند؛ `GrafanaWebhookSerializer` فقط `status`/`title`/`message` را می‌گیرد; `AlertService._format_message` ایموجی وضعیت را اضافه می‌کند و `BaleService` به `tapi.bale.ai` می‌فرستد.

**احراز هویت با secret داخل URL است، نه هدر.** دو دلیل مستند:

1. این endpoint زیر `DEFAULT_AUTHENTICATION_CLASSES = (JWTAuthentication,)` است؛ اگر `Authorization: Bearer <secret>` بفرستی، JWT آن را به‌عنوان توکن decode می‌کند و با ۴۰۱ رد می‌کند.
2. اسکیمای provisioning گروفانا برای هدر احراز هویت نسخه‌حساس است، ولی `url` پایدار است (همان الگویی که Slack/Discord استفاده می‌کنند).

مقایسه با `hmac.compare_digest` انجام می‌شود. rate limit ندارد چون secret خودش کنترل دسترسی است و فقط Grafana آن را دارد.

---

## ۸. لایهٔ AI (`apps/ai`) — جزئی‌ترین بخش

این اپ **هیچ مدل دامنه‌ای به‌جز `ModelPricing` ندارد**. یک «کتابخانهٔ درونی» است که دو مصرف‌کننده دارد: `apps/report` و `apps/chat`.

```
apps/ai/
├── openai_client.py            # کلاینت مشترک OpenAI/AvalAI (cached per provider)
├── pricing.py                  # calculate_cost از جدول ModelPricing
├── models.py                   # ModelPricing
├── prompts/                    # قواعد مشترک
│   ├── safety_rules.md
│   ├── punctuation_rules.md
│   └── step_quality_rules.md
├── chat_generation/
│   ├── chat_input.py           # Pydantic — anti-corruption layer ورودی
│   ├── prompt.py (695 خط)      # ساخت messages سیستم/کاربر + knowledge base
│   ├── knowledge_base.md
│   ├── safety_rules_chat_extension.md
│   ├── action_step_prompt.py   # ساختار کارت قدم پیشنهادی
│   ├── generate.py (312 خط)    # استریم + نردبان تلاش + پارس مارکر
│   ├── schema.py               # ProposedAction
│   └── client.py               # ChatGenerationClient (مرز عمومی)
├── report_generation/
│   ├── profile_input.py        # Pydantic ورودی گزارش
│   ├── prompt.py / prompt_v2.py
│   ├── schema.py / schema_v2.py
│   ├── fewshot/ / fewshot_v2/  # مثال‌های طلایی
│   ├── memory_candidates.py
│   ├── generate.py             # نردبان تلاش مشترک بین v1 و v2
│   └── client.py               # ReportGenerationClient
└── deep_report_generation/
    ├── prompt.py, structure.py, schema.py
    ├── facet_vocabulary.py
    ├── fewshot/example_deep_A.json, B.json
    ├── memory_candidates.py
    ├── generate.py             # ۵+۲ موازی، بعد closing
    ├── client.py               # mock را از mock/deep_report_mock.json می‌خواند
    └── examples.py
```

### ۸.۱ کلاینت مشترک — `openai_client.py`

این فایل کوچک (۶۰ خط) اما **بحرانی** است. دو تنظیم آن عمداً از پیش‌فرض SDK فاصله دارد:

- **`connect=30s`** (پیش‌فرض SDK ۵ ثانیه). یک handshake سرد TLS به `api.openai.com` از این شبکه ~۲۱ ثانیه اندازه‌گیری شده. با بودجهٔ ۵ ثانیه، هر بار که اتصال pooled بیکار بسته می‌شد، تلاش سقوط می‌کرد — همان علامتِ «پیام اول کار می‌کند، بقیه تایم‌اوت می‌دهند».
- **`max_retries=0`** (پیش‌فرض SDK ۲). retryهای SDK در نردبان تلاش خودمان ضرب می‌شد: ۳ × ۳-۴ = تا ۱۲ درخواست و ~۴۵ ثانیه انتظار کاربر. retry باید فقط در **یک** جا باشد.
- کلاینت‌ها با `@lru_cache` به ازای هر provider کش می‌شوند (هر کلاینت pool اتصال خودش را دارد؛ ساخت مجدد یعنی پرداخت هزینهٔ connect سرد در هر پیام).
- `base_url` همیشه به‌صورت رشتهٔ مشخص پاس می‌شود، چون SDK خودش هم متغیرهای `*_BASE_URL` را می‌خواند و «موجود ولی خالی» را متفاوت از «غایب» رفتار می‌کند.

`PROVIDERS = {"openai": (key_env, base_env, default), "avalai": (...)}`

### ۸.۲ نردبان تلاش (Attempt Ladder)

نردبان گزارش اولیه (بدترین حالت = `REPORT_MAX_PRIMARY_ATTEMPTS + 2` فراخوانی پولی):

```
۱..N     مدل primary روی OpenAI        (N = REPORT_MAX_PRIMARY_ATTEMPTS، پیش‌فرض ۲)
N+1      مدل backup  روی OpenAI        (tier دیگر، اگر primary degraded باشد)
N+2      مدل backup  روی AvalAI        (همان مدل، مسیر infra متفاوت — اگر خودِ OpenAI مشکل داشته باشد)
→ همه شکست خورد: ReportResponse(status="error", code="generation_failed")
```

نکات طراحی:

- **JSON با پرامپت درخواست می‌شود، نه Structured Outputs.** چون چند provider در حال مقایسه‌اند و JSON سطح پرامپت provider-independent است. تصمیم مستند: وقتی مدل نهایی شد، Structured Outputs یک تغییر محدود در همین فایل است و retry را کم می‌کند.
- **Code fence ها strip می‌شوند** (` ```json `) — هزینهٔ صفر، جلوگیری از یک retry پولی برای یک ایراد فرمتی.
- وقتی پاسخ اعتبارسنجی نشد، **خطا به پیام بعدی تزریق می‌شود** (`messages + [assistant: raw, user: "That response failed schema validation: ..."]`) — وگرنه هر پلهٔ نردبان همان خطا را تکرار می‌کند چون پرامپت یکسان است.
- `generate_report` **هرگز raise نمی‌کند** — همیشه یک `ReportResponse` برمی‌گرداند.
- `soft_check` (طول، کلمات ممنوع، ارقام) فقط warning لاگ می‌کند، خطا نمی‌دهد.

### ۸.۳ گزارش اولیه — v1 و v2

`_Variant` شامل `build_messages`, `output_model`, `soft_check`, `build_memory`, `response_model` است. **نردبان بین دو نسخه مشترک است**؛ فقط variant عوض می‌شود.

`initial_report_version()` از `REPORT_INITIAL_VERSION` می‌خواند؛ خالی → `DEFAULT_INITIAL_VERSION = "report_v1"`.

ساختار v2 (طبق `docs/report_spec_v2_0.md`): ~۲۹۰ کلمه — `hook`, یک `strength`, `findings_heading`, دقیقاً ۲ `finding` (هر کدام با `what`/`cost`/`curiosity`), `open_question`, `exit.{bridge, root_question}`.

قواعد سخت v2 (`schema_v2.py`): تعداد آیتم‌ها، اینکه دو finding در «حوزه» متفاوت باشند، `findings[0].suggested_step` اجباری و `findings[1]` باید null باشد، `substeps` null.

### ۸.۴ گزارش عمیق — ۸ فراخوانی

```
5 × "domain_<N|E|O|A|C>"   ┐
1 × "topics_a"             ├── ThreadPoolExecutor موازی (max_workers = len(jobs))
1 × "topics_b"             ┘
        │
        ▼
1 × "closing"      ← ترتیبی، چون به خروجی همهٔ بالا نیاز دارد
```

سپس `_enforce_levels(profile, domains, closing)` اجرا می‌شود: هر جا مدل سطحی متفاوت از سطح deterministic ما برگردانده باشد، **با سطح واقعی overwrite می‌شود**. این تضمین می‌کند AI هیچ عدد/سطحی را تغییر ندهد.

هر فراخوانی `_call_with_ladder` مستقل خودش را دارد (پس یک domain شکست‌خورده کل گزارش را نمی‌کشد، ولی اگر `closing` نیاید گزارش error می‌شود). هر فراخوانی یک `GenerationLog` جدا با `call_key` خودش می‌سازد.

### ۸.۵ چت — خط تولید استریم

```
ChatService._build_payload
        ▼
ChatGenerationClient.generate_stream(payload)
        ├─ ChatRequest.model_validate(payload)      ← Pydantic؛ payload بد اینجا می‌شکند نه در پرامپت
        └─ generate_chat_stream(request)
              ├─ build_messages(...)   (ROLE + safety + knowledge base + action block + history + memory)
              ├─ client_for(provider).chat.completions.create(stream=True, prompt_cache_key=PROMPT_VERSION)
              ├─ delta → yield {"type":"delta","text":...}
              ├─ انباشت متن، پارس مارکر <<<ACTION>>> → ProposedAction
              └─ yield {"type":"done","message":..., "proposed_action":..., "quick_replies":...}
```

تفاوت‌های مهم با گزارش:

1. خروجی متن آزاد است → اسکیمایی برای validate نیست → نردبان فقط برای خطای شبکه/provider است.
2. **retry فقط قبل از اولین delta مجاز است.** بعد از آن، retry یعنی دوباره فرستادن متنی که کاربر خوانده است.
3. مارکر `<<<ACTION>>>` در اینجا strip می‌شود و هرگز به caller نمی‌رسد؛ deltaها فقط متن نمایشی دارند.
4. `PROMPT_CACHE_KEY = PROMPT_VERSION` است، **نه `session_id`** — کلید به ازای هر نشست یعنی هر نشست bucket جدا و کش پرامپت بی‌فایده. ترتیب ثابت بلوک‌ها در پرامپت برای همین است: پیشوند ثابت مشترک بین نشست‌های همزمان گرم بماند.

### ۸.۶ لایهٔ ضد-فساد (anti-corruption) — `chat_input.py`

این فایل نقش مهمی دارد: payload بد باید با خطای واضح **همین‌جا** بشکند، نه اینکه به پرامپت برسد و یک مکالمهٔ ظاهراً درست ولی دربارهٔ موضوع اشتباه تولید کند.

نمونه‌هایی از قواعد:

- `extra="forbid"` روی `MemoryRow`: فیلدهای `confidence` و `sensitivity_level` در DB هستند ولی **هرگز نباید** به سرویس AI برسند (برای strength/growth_edge مقدار placeholder دارند؛ اگر لو بروند کسی روزی آن‌ها را واقعی فرض می‌کند).
- `action_context.recent` با `max_length=3`.
- `entry_source` با regex محدود می‌شود (`report_finding_focus:[01]`، `deep_report_focus:<section>` از لیست ۱۳ بخش مجاز).
- `report_type` فقط `initial|deep`.

### ۸.۷ فلگ‌های mock (برای تست و لود‌تست)

| فلگ | اثر |
|---|---|
| `REPORT_AI_ENABLED=false` | گزارش ثابت mock، بدون فراخوانی واقعی |
| `DEEP_REPORT_AI_ENABLED=false` | گزارش عمیق mock از `mock/deep_report_mock.json` |
| `CHAT_AI_ENABLED=false` | پاسخ چت ثابت |
| `CHAT_MOCK_STREAM_DELAY_MS` / `_CHUNK_COUNT` / `_CHUNK_INTERVAL_MS` | شبیه‌سازی TTFT و ریتم استریم مدل واقعی |
| `REPORT_MOCK_DELAY_MS` / `DEEP_REPORT_MOCK_DELAY_MS` | تاخیر مصنوعی |

این‌ها **global** هستند — یعنی نمی‌توان روی production فقط ترافیک تست را mock کرد (این یک بدهی شناخته‌شده است).

### ۸.۸ قیمت‌گذاری

`calculate_cost(model_used, input_tokens, output_tokens, cached_input_tokens)`:
- `None` اگر مدلی استفاده نشده یا قیمتی برایش ثبت نشده (**هرگز عدد حدسی**).
- `cached_input_tokens` بخشی از ورودی است که provider از prompt cache سرو کرده — با نرخ cached قیمت می‌خورد، بقیه با نرخ کامل.
- قیمت‌ها در جدول `ModelPricing` هستند تا تغییر قیمت یک ویرایش در admin باشد، نه یک deploy.

---

## ۹. مدل داده و دیتابیس

### ۹.۱ فهرست جدول‌ها (۲۵+)

| اپ | جدول‌ها |
|---|---|
| account | `users`, `anonymous_demographics` |
| assessment | `assessments`, `assessment_sections`, `assessment_questions`, `assessment_attempts`, `assessment_answers` |
| report | `reports`, `user_memories`, `report_generation_logs`, `report_email_deliveries` |
| chat | `chat_sessions`, `chat_messages`, `message_feedbacks`, `message_bookmarks`, `chat_generation_logs` |
| action_steps | `action_steps`, `action_step_responses` |
| notifications | `push_subscriptions`, `notifications` |
| payment | `payment_products`, `payment_coupons`, `payments`, `purchases` |
| events | `events` |
| feedback | `feedbacks` |
| ai | `ai_model_pricing` |
| سوم‌شخص | `blacklisted_tokens`, `outstanding_tokens` (SimpleJWT)، جدول‌های Django admin/session |

`docs/database-design.md` (۶۰۷ خط) سند مرجع طراحی دیتابیس است.

### ۹.۲ اصول و الگوها

1. **Soft delete** با جفت `is_deleted` + `deleted_at` برای دادهٔ شخصی و لاگ‌ها. حذف حساب کاربر همه را cascade می‌کند (حذف نرم).
2. **`on_delete` آگاهانه انتخاب شده:** `PROTECT` برای دادهٔ مالی/مرجع (`payments.product`, `purchases.payment`, `attempts.assessment`) تا تاریخچهٔ مالی هرگز از دست نرود؛ `CASCADE` برای دادهٔ متعلق به کاربر؛ `SET_NULL` برای ارجاع‌های اختیاری (`chat_sessions.report`, `events.user`).
3. **UUID** برای `ChatSession` و `ActionStep` (قابل شمارش نباشند). `Attempt`/`Report` عددی هستند.
4. **JSONField** برای هر چیزی که شکلش با نسخهٔ پرامپت/گزارش تغییر می‌کند.
5. **ایندکس‌های هدفمند:** `(user, -last_message_at)` روی نشست‌ها؛ `events_campaign_funnel_idx` به‌صورت **partial**؛ ایندکس روی `email` و `(user, -created_at)` در `report_email_deliveries`. ایندکس‌های تکراری روی `users.phone_number` عمداً حذف شدند (چون `unique=True` از قبل یکی می‌سازد).
6. **Denormalization آگاهانه:** `ChatSession.title` و `last_message_at` — با یک `UPDATE` در `ChatMessageRepository.create`. نتیجه: خواندن لیست ۵۰۰ نشست از ۱۰۰۱ کوئری به ۱ کوئری.
7. **`select_for_update` فقط یک جا** — و همان هم داخل یک `transaction.atomic` اسکوپ‌شده در یک request، چون با `pool_mode=transaction` در pgbouncer هیچ تضمینی برای ماندگاری lock بین تراکنش‌ها نیست.

### ۹.۳ صفر raw SQL

هیچ `cursor.execute`، هیچ advisory lock، هیچ `LISTEN/NOTIFY`، هیچ `SET` سطح session. این خودش دلیل فنی است که چرا `pool_mode=transaction` در pgbouncer بی‌خطر بود.

---

## ۱۰. نقشهٔ API

همه زیر `/api/`، همه با envelope `{code, message, data}`.

### احراز هویت و حساب

| متد | مسیر | دسترسی | توضیح |
|---|---|---|---|
| POST | `/api/account/otp/send/` | عمومی | ساخت/یافتن کاربر + ارسال OTP؛ `utm_source`/`utm_campaign` اختیاری (first-touch) |
| POST | `/api/account/otp/verify/` | عمومی | ورود؛ claim آزمون ناشناس؛ برمی‌گرداند `{access, refresh}` |
| POST | `/api/account/token/refresh/` | عمومی | `{refresh}` → رشتهٔ access |
| POST | `/api/account/logout/` | JWT | blacklist همهٔ توکن‌ها |
| GET/PATCH | `/api/account/profile/` | JWT | پروفایل |
| GET/PATCH | `/api/account/profile/demographics/` | JWT | جمعیت‌شناسی |
| POST | `/api/account/terms/accept/` | JWT | پذیرش نسخهٔ قوانین |
| DELETE | `/api/account/delete/` | JWT | حذف حساب |

### آزمون

| متد | مسیر | توضیح |
|---|---|---|
| GET | `/api/assessments/<slug>/` | ساختار آزمون با سکشن‌ها و سؤالات |
| GET | `/api/assessments/<slug>/pre-start/` | آیا می‌توان شروع کرد؟ تلاش‌های باقی‌مانده؟ |
| POST | `/api/assessments/attempts/` | شروع یا ادامهٔ attempt (با گیت پرداخت اگر لازم باشد) |
| POST | `/api/assessments/attempts/<id>/answers/` | ثبت پاسخ |
| DELETE | `/api/assessments/attempts/<id>/answers/<qid>/` | حذف پاسخ (undo) |
| POST | `/api/assessments/attempts/<id>/complete/` | اتمام + امتیازدهی + dispatch تولید گزارش |

### گزارش

| متد | مسیر | توضیح |
|---|---|---|
| GET | `/api/reports/history/` | تاریخچهٔ گزارش‌ها |
| GET | `/api/reports/attempts-history/` | تاریخچهٔ attemptها (شامل generating/error) |
| GET | `/api/reports/attempts/<id>/` | گزارش (preview / full / deep) |
| POST | `/api/reports/attempts/<id>/retry/` | تولید مجدد |
| POST | `/api/reports/attempts/<id>/steps/<index>/accept/` | پذیرش قدم پیشنهادی → ActionStep |
| POST | `/api/reports/attempts/<id>/email/` | ارسال با ایمیل + PDF |

### چت

| متد | مسیر | توضیح |
|---|---|---|
| GET/POST | `/api/chat/sessions/` | لیست (limit/offset) / ساخت نشست |
| GET/DELETE | `/api/chat/sessions/<uuid>/` | جزئیات / حذف |
| GET | `/api/chat/sessions/<uuid>/messages/` | ترنسکریپت |
| POST | `/api/chat/sessions/<uuid>/messages/` | **SSE** ارسال پیام |
| POST | `/api/chat/sessions/<uuid>/messages/<mid>/regenerate/` | **SSE** تولید مجدد |
| POST | `/api/chat/messages/<mid>/accept-action/` | پذیرش کارت قدم |
| GET | `/api/messages/bookmarked/` | پیام‌های ذخیره‌شده |
| POST/DELETE | `/api/messages/<mid>/feedback/` | فیدبک پیام |
| POST/DELETE | `/api/messages/<mid>/bookmark/` | بوکمارک |

### قدم‌های عملی

| متد | مسیر |
|---|---|
| GET | `/api/action-steps/?source=` |
| GET | `/api/action-steps/history/` |
| GET/PATCH | `/api/action-steps/<uuid>/` |
| POST | `/api/action-steps/<uuid>/complete/` |
| POST | `/api/action-steps/<uuid>/reflection/` |
| POST | `/api/action-steps/<uuid>/followup/` |
| POST | `/api/action-steps/<uuid>/reactivate/` |

### پرداخت و بقیه

| متد | مسیر | توضیح |
|---|---|---|
| POST | `/api/payment/initiate/` | شروع پرداخت |
| GET | `/api/payment/products/` | قیمت‌های عمومی (بدون لاگین) |
| GET | `/api/payment/callback/` | callback زرین‌پال → ۳۰۲ به فرانت |
| GET | `/api/users/me/entitlements/` | دسترسی‌های کاربر |
| POST | `/api/events/track/` | ردیابی رویداد |
| POST | `/api/feedback/` | فیدبک محصول |
| GET/POST | `/api/notifications/push-subscriptions/` | ثبت/حذف توکن پوش |
| POST | `/api/alerting/grafana-webhook/<secret>/` | رله Grafana |
| GET | `/health`, `/health/` | liveness |
| GET | `/metrics` | پرومتئوس (در nginx از بیرون بلاک است) |
| GET | `/api/docs/`, `/api/redoc/`, `/api/schema/` | مستندات |

---

## ۱۱. تسک‌های آسنکرون

| تسک | نوع | چه‌وقت | چرا آسنکرون |
|---|---|---|---|
| `report.generate_initial_report(attempt_id)` | on-demand | اتمام آزمون ۳۰ سؤالی | یک فراخوانی مدل ~۷۰ ثانیه |
| `report.generate_deep_report(attempt_id)` | on-demand | اتمام آزمون ۱۵۰ سؤالی | ۸ فراخوانی مدل، چند دقیقه |
| `notifications.send_due_notifications` | beat هر ۵ دقیقه | همیشه | ارسال نوتیفیکیشن‌های رسیده |

اصول مشترک:

- هر task فقط یک خط است: بدنه‌اش یک متد سرویس را صدا می‌زند. **منطق در سرویس است تا بدون broker قابل تست باشد.**
- **هیچ‌کدام `autoretry_for` ندارند.** دلیل: هر دو سرویس گزارش، شکست را به یک گزارش `error` تبدیل می‌کنند و فراخوانی‌های زیرین نردبان خودشان را دارند؛ retry کل تسک یعنی دوباره پرداخت برای فراخوانی‌هایی که موفق شده‌اند.
- `transaction.on_commit` قبل از `.delay()` استفاده می‌شود تا در صورت rollback، تسکی روی دادهٔ ناموجود اجرا نشود (و همین با pooler سازگار است).
- Tracking `celery-exporter` از طریق `CELERY_WORKER_SEND_TASK_EVENTS` + `CELERY_TASK_SEND_SENT_EVENT`.

---

## ۱۲. زیرساخت و استقرار

### ۱۲.۱ سرویس‌های `docker-compose.yml`

| سرویس | تعداد | نقش |
|---|---|---|
| `postgres` | ۱ | `postgres:16-alpine` با `max_connections=75` (کاهش از ۲۰۰ بعد از آمدن pgbouncer) |
| `db` | ۱ | **pgbouncer** — `pool_mode=transaction`, `DEFAULT_POOL_SIZE=20`, `RESERVE_POOL_SIZE=10`, `MAX_DB_CONNECTIONS=40`, `MAX_CLIENT_CONN=1000`, `AUTH_TYPE=scram-sha-256`, `IGNORE_STARTUP_PARAMETERS=extra_float_digits` |
| `redis` | ۱ | `redis:7-alpine` با `--requirepass` و `--save 60 1` |
| `web` / `web2` | ۲ | gunicorn + gevent: `--workers 3 --worker-class gevent --worker-connections 100 --timeout 300` |
| `celery` / `celery2` | ۲ | `celery -A faraman_back worker -l info --concurrency=4` |
| `celery-beat` | **۱، هرگز بیشتر** | `celery beat` |
| `nginx` | ۱ | `81:80` روی هاست، `upstream web` با `web`/`web2` و `max_fails=3 fail_timeout=10s` |

نکات مهم:

- **چرا pgbouncer نام `db` را گرفته؟** تا `DB_HOST`/`DB_PORT` و همهٔ `depends_on: db:` در پنج مصرف‌کننده بدون تغییر کار کند. عارضهٔ جانبی: `make up` حالا `--remove-orphans` می‌دهد، وگرنه کانتینر postgres قدیمی روی volume مشترک قفل می‌ماند.
- **`make test` با `-e DB_HOST=postgres`** اجرا می‌شود، چون Django یک دیتابیس `test_<DB_NAME>` می‌سازد که pgbouncer با routing تک‌دیتابیسی نمی‌تواند پروکسی کند.
- **`PROMETHEUS_MULTIPROC_DIR`** فقط روی web/celery و در compose ست می‌شود.
- `FCM_CREDENTIAL_HOST_PATH` فایل اعتبارنامهٔ Firebase را به‌صورت read-only به همهٔ کانتینرها mount می‌کند. فایل واقعی هرگز داخل مخزن نیست.

### ۱۲.۲ nginx (`nginx/nginx.conf`)

```
upstream web {
    server web:8000  max_fails=3 fail_timeout=10s;
    server web2:8000 max_fails=3 fail_timeout=10s;
}
server {
    listen 80;
    location /metrics { deny all; return 403; }     # فقط داخل شبکهٔ داخلی
    location = /health { return 200 '{"status":"ok"}'; }   # nginx خودش جواب می‌دهد
    location / { proxy_pass http://web; ... }
}
```

- `max_fails`/`fail_timeout` = **failover غیرفعال**: کانتینر کرش‌کرده یا در حال ری‌استارت، از rotation خارج می‌شود.
- `/health` (بدون اسلش) را nginx خودش جواب می‌دهد → حتی اگر هر دو web خواب باشند، edge زنده است. `/health/` (با اسلش) به Django می‌رسد → تست end-to-end.
- **`keepalive` ندارد** (بدهی شناخته‌شده). به همین دلیل هر درخواست یک اتصال TCP و یک greenlet تازه می‌گیرد.

### ۱۲.۳ TLS و دامنه‌ها

TLS در این پروژه **داخل مخزن بک‌اند نیست**. استک `faraman-front` (که `nginx-proxy` + `acme-companion` دارد) هر کانتینری با `VIRTUAL_HOST`/`LETSENCRYPT_HOST` روی شبکهٔ مشترک را کشف و گواهی‌دار می‌کند. به همین دلیل سرویس `nginx` بک‌اند به شبکهٔ `delyar-front_default` (با alias `proxy`) وصل می‌شود و `VIRTUAL_HOST=api.faraman.ai` / `VIRTUAL_PORT=80` دارد.

### ۱۲.۴ CI/CD

`.gitlab-ci.yml` روی **hamgit.ir**:

```
build   → make build (روی MR و main)
test    → ❌ کامنت‌شده
deploy  → فقط main، runner از نوع shell روی خود سرور production:
          source scripts/render_env.sh
          make up
          make metabase-init-db
          make migrate
          make ensure-superuser
          make seed-deep-assessment
monitoring → فقط وقتی monitoring/**/* تغییر کند
```

`environment.url` در CI خودش آدرس IP سرور را لو می‌دهد (`http://185.84.158.234:81`) — یک نکتهٔ امنیتی/تمیزی.

### ۱۲.۵ استک مانیتورینگ (`monitoring/docker-compose.yml`)

سرویس‌ها: `prometheus`, `node-exporter`, `postgres-exporter`, `redis-exporter`, `celery-exporter`, `loki`, `promtail`, `grafana`, `metabase`.

- شبکه‌ها: `monitoring` + `app` (`faraman_net`) + `proxy`.
- `postgres-exporter` مستقیم به `postgres:5432` می‌رود (**نه** `db`) — چون باید اتصال‌های backend واقعی را بسنجد؛ همان متریکی که مشکل pgbouncer را زنده پیدا کرد.
- `grafana` و `metabase` هیچ port روی هاست publish نمی‌کنند (`expose` فقط) — تنها راه ورود، HTTPS proxy است. دلیل: داده شامل شماره موبایل است.
- Metabase از نقش **SELECT-only** (`metabase_ro`) برای خواندن DB محصول استفاده می‌کند و جدول‌های توکن/سشن/پوش revoked شده‌اند (`monitoring/metabase/init-readonly.sql` با `make metabase-init-db`).
- آلرتینگ: `contactpoints.yml` یک contact point از نوع webhook به `http://web:8000/api/alerting/grafana-webhook/${GRAFANA_WEBHOOK_SECRET}/` می‌سازد با template سفارشی (`title` = `alertname · rulename`، `message` = annotation + لینک panel). **routing rule که آلرت‌ها را به این contact point بفرستد هنوز ساخته نشده.**

### ۱۲.۶ لود تست (`loadtest/`)

- Locust با `Dockerfile`/`requirements.txt`/`compose` مستقل تا وابستگی‌هایش به ایمیج اپ نرسد.
- `compose.override.app.yml` با `-f` دوم به استک تزریق می‌شود (`environment:` بین فایل‌ها merge می‌شود) — `docker-compose.yml` اصلی صفر تغییر.
- سناریوها با وزن: browsing ۴۰٪، chat SSE ۳۰٪، assessment flow ۱۵٪، report email ۵٪، payment ۲٪ (تگ `payment`، به‌صورت پیش‌فرض حذف).
- **یافته‌های واقعی:** ۵۰ کاربر تمیز (۹۷.۹٪)؛ ۲۰۰ کاربر فاجعه (۵۱٪ خطا، `too many clients already`) → pgbouncer اضافه شد → دوباره ۲۰۰ کاربر: ۲۱٬۹۶۱ درخواست، **صفر خطا**، اتصال‌های Postgres ثابت روی ۲۶. بعد `CONN_MAX_AGE=60` به‌عنوان یک باگ دوم ظاهر شد. با تاخیر مصنوعی ۱۲–۳۲ ثانیه برای چت: ۱۱٬۲۲۸ درخواست، یک خطای گذرا.
- **گلوگاه واقعی CPU است، نه RAM** (`web`/`web2` هر کدام ۲۰۰–۳۱۵٪ CPU در حالی که کل حافظه ~۱.۶ گیگ از ۴.۸).

---

## ۱۳. تست‌ها

- الگو: **mock در مرز سرویس**. repositoryها/همکاران با `unittest.mock.MagicMock` جایگزین می‌شوند تا به DB/Redis نیاز نباشد. این دلیل وجود الگوی constructor DI است.
- تست‌های معنادار موجود: `apps/account/tests.py` (OTP، throttling، DI)، `apps/report/tests/test_report.py` (`ScoringServiceTests`)، `test_deep.py`، `test_pdf_service.py`، `apps/payment/tests.py` (`ZarinpalClientRequestPaymentTests`)، `apps/notifications/tests.py` (`NotificationSendMetricsTests`)، `apps/alerting/tests.py`، `apps/chat/tests.py`، `apps/assessment/tests.py`، `apps/events/tests.py`، `faraman_back/tests.py` (health probe) و `observability/tests.py`.
- اجرا: `make test` (داخل Docker، با `DB_HOST=postgres`).
- ⚠️ **این تست‌ها در CI اجرا نمی‌شوند** (stage کامنت است).

---

## ۱۴. «چطور یک فیچر جدید اضافه کنم» — چک‌لیست

1. `python manage.py startapp <name>` داخل `apps/`، بعد به ساختار لایه‌ای بازسازی کن (`repositories/`, `services/`, `serializers/`, `views/`).
2. اپ را به `INSTALLED_APPS` در `settings.py` اضافه کن.
3. `apps/<name>/urls.py` را در `faraman_back/urls.py` وصل کن.
4. از `apps/events/` به‌عنوان قالب کوچک‌ترین اپ کامل استفاده کن.
5. خطاهای دامنه در `services/exceptions.py` به‌صورت زیرکلاس `AppException` با `status_code` و `message_key`.
6. هر رشتهٔ کاربرپسند → کلید در `faraman_back/lang/fa/messages.py` + `get_message(...)`.
7. هر کوئری جدید → متد در repository، نه inline.
8. هر متغیر محیطی جدید → `os.getenv(x) or default` + `.env.example` + متغیر GitLab.
9. اگر تسک سنگین است → `@shared_task` که فقط یک متد سرویس را صدا می‌زند.
10. اگر endpoint عمومی است → `permission_classes = [AllowAny]` صریح (پیش‌فرض `IsAuthenticated` است).
11. متریک: اگر endpoint/task مهمی است، `@observe(...)` اضافه کن.
12. `error_responses(...)` در `@extend_schema` تا OpenAPI خطاهای ممکن را نشان دهد.
13. تست: سرویس را با `MagicMock` بپوشان.

**چیزهایی که «نکن»:**

- ❌ `Model.objects.*` در سرویس یا view
- ❌ `Response(...)` خام در view (همیشه `ApiResponse`)
- ❌ `raise ValueError` در سرویس (همیشه `AppException` subclass)
- ❌ `os.getenv('X', default)` برای هر کلید `.env.example`
- ❌ import داخل تابع بدون دلیل چرخه‌ای مستند
- ❌ ساخت سرویس خارجی در `__init__` ویو (از lazy property استفاده کن)
- ❌ فراخوانی `ScoringService` مستقیم (از `ScoringRouter`)
- ❌ فرستادن عدد خام به کلاینت در گزارش عمیق
- ❌ اجرای `migrate` بدون در نظر گرفتن اینکه بلافاصله روی production است

---

## ۱۵. «کجا چه چیزی را پیدا کنم» — نقشهٔ سریع

| می‌خواهم بدانم… | برو به |
|---|---|
| تصمیم‌های معماری و تاریخچهٔ باگ‌ها | `CLAUDE.md` |
| توپولوژی/دیپلوی/plan افزونگی | `docs/infrastructure.md` |
| طراحی دیتابیس | `docs/database-design.md` |
| قرارداد گزارش عمیق | `docs/deep_report_spec_v1_2.md` + `docs/Personality_150_Test_Scoring_Manual_FA_Ravi_v1.2.docx` |
| قرارداد گزارش v2 | `docs/report_spec_v2_0.md` |
| قرارداد چت | `docs/chat_spec_v3_1.md` |
| قرارداد قدم‌های عملی | `docs/action_steps_spec_v2_2.md` |
| OTP و JWT | `apps/account/services/otp_service.py` + `repositories/otp_repository.py` |
| امتیازدهی | `apps/report/services/scoring_router.py` → `scoring_service.py` / `deep_scoring_service.py` |
| تولید گزارش | `apps/report/services/report_service.py` + `apps/ai/report_generation/generate.py` |
| گزارش عمیق | `apps/report/services/deep_report_service.py` + `apps/ai/deep_report_generation/generate.py` |
| پرامپت‌ها | `apps/ai/*/prompt*.py` + `apps/ai/prompts/*.md` + `*/fewshot*/` |
| چت SSE | `apps/chat/services/chat_service.py::_stream` + `apps/chat/views/chat_view.py::_sse_response` |
| معیارهای کیفیت چت | `apps/ai/chat_generation/knowledge_base.md` + `safety_rules*.md` |
| پرداخت | `apps/payment/services/payment_service.py` + `zarinpal_client.py` |
| دسترسی | `apps/payment/services/entitlement_service.py` |
| پوش | `apps/notifications/services/push_sender.py` + `notification_service.py` |
| متریک‌ها | `faraman_back/observability/metrics.py` |
| پاسخ/خطای استاندارد | `faraman_back/utils/{responses,exceptions,exception_handler}.py` |
| همهٔ تنظیمات و دلیل هرکدام | `faraman_back/settings.py` (کامنت‌ها را بخوان) |
| اسرار و متغیرها | `.env.example` |
