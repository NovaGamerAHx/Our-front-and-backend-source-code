# معماری و ساختار فرانت‌اند — فرامن (`faraman-front`)

> این سند جزئیات فنی فرانت‌اند است: تکنولوژی‌ها، مدل معماری، لایهٔ API، مسیرها، جریان داده، استریم، طراحی و استقرار.
> برای نمای کلی محصول، سند `01-project-overview.md` و برای بک‌اند، `02-backend-architecture.md` را ببین.

---

## ۱. معرفی و نقش

فرانت‌اند یک اپ **Next.js با App Router** است که کل تجربهٔ کاربری «فرامن» را می‌سازد: لندینگ، آزمون، گزارش، چت، داشبورد، پروفایل و پرداخت.

**اصل معماری که کل این پروژه بر آن بنا شده:** مرورگر *هرگز* با بک‌اند Django حرف نمی‌زند. همهٔ تماس‌ها **server-to-server** از پروسهٔ Node انجام می‌شود، به‌جز دو استثنا:

1. **ردیف‌های SSE چت** — که از یک Route Handler پروکسی می‌شوند (دوباره: سرور به سرور، بدنه به مرورگر pipe می‌شود).
2. **مسیر `/firebase-messaging-sw.js`** که یک فایل استاتیک سرو‌شده است.

دلیل این انتخاب: JWT در **کوکی httpOnly** زندگی می‌کند، پس جاوااسکریپت مرورگر اصلاً به آن دسترسی ندارد. هیچ‌جا `localStorage` برای توکن استفاده نمی‌شود.

- نام پکیج: `faraman-front`
- ریشهٔ کد: `front-main/`
- دامنه: `faraman.ai` (+ `www`)
- محیط اجرا: Node 22 Alpine، ایمیج runtime از نوع **standalone**

---

## ۲. تکنولوژی‌ها

### هسته

| مورد | نسخه | نقش |
|---|---|---|
| **Next.js** | `16.2.10` | فریم‌ورک (App Router، RSC، Server Actions، Route Handlers) |
| **React** | `19.2.4` | UI |
| **TypeScript** | `^5` | زبان |
| **Tailwind CSS** | `^4` (با `@tailwindcss/postcss`) | استایل — نسخهٔ ۴: کانفیگ داخل CSS است، نه `tailwind.config.js` |
| **shadcn** | `^4.13.0` | تولید کامپوننت‌های UI (style: `base-nova`) |
| **@base-ui/react** | `^1.6.0` | primitiveهای کامپوننت (به‌جای Radix — انتخاب این نسخهٔ shadcn) |
| **zod** | `^4.4.3` | اعتبارسنجی و پارس همهٔ پاسخ‌های API |

> ⚠️ **نکتهٔ مهم نسخه:** این پروژه روی **Next.js 16** است. فایل `AGENTS.md` هشدار می‌دهد: «این همان Next.js که می‌شناسی نیست — APIها، کنوانسیون‌ها و ساختار فایل ممکن است با دادهٔ آموزشی تو متفاوت باشد؛ قبل از نوشتن کد، راهنمای مربوطه در `node_modules/next/dist/docs/` را بخوان.»
>
> نمونهٔ عینی این تفاوت: **میدل‌ور در Next 16 به `proxy.ts` تغییر نام داده** و فایل ریشهٔ این پروژه دقیقاً `proxy.ts` است، نه `middleware.ts`.

### UI و رفتار

| مورد | نسخه | کاربرد واقعی در کد |
|---|---|---|
| `lucide-react` | `^1.23.0` | آیکون‌ها (۳۰+ فایل) |
| `sonner` | `^2.0.7` | توست (`<Toaster dir="rtl" position="top-center">`) |
| `class-variance-authority` | `^0.7.1` | واریانت‌های کامپوننت (`buttonVariants`) |
| `clsx` + `tailwind-merge` | — | ابزار `cn()` در `lib/utils.ts` |
| `react-hook-form` + `@hookform/resolvers` | `^7.81` / `^5.4` | فقط در فرم ورود (`login-form.tsx`) |
| `tw-animate-css` | `^1.4` | انیمیشن‌های utility در CSS |
| `server-only` | `^0.0.1` | گارد کامپایل‌تایم روی ماژول‌های سروری |

### داده، تاریخ، پوش

| مورد | نسخه | کاربرد |
|---|---|---|
| `dayjs` + `jalaliday` | `^1.11` / `^3.1` | تاریخ **شمسی** با ارقام فارسی |
| `firebase` | `^12.17` | FCM (dynamic import، خارج از باندل اصلی) |

### وابستگی‌های نصب‌شده ولی **استفاده‌نشده** ⚠️

با grep روی `app/`, `components/`, `lib/`, `proxy.ts` هیچ importی برای این‌ها پیدا نمی‌شود:

- `zustand` (`^5.0.14`) — هیچ store‌ای وجود ندارد؛ کل state با `useState` و URL و کوکی مدیریت می‌شود.
- `motion` (`^12.42.2`) — هیچ `motion.div`ی نیست؛ انیمیشن‌ها با CSS (`animate-fm-in`).
- `recharts` (`^3.9.2`) — هیچ نموداری با recharts رسم نمی‌شود (نمودارهای گزارش با SVG/HTML دستی ساخته شده‌اند).

حذف این سه، باندل نصب و سطح حمله را کم می‌کند. (کاندید خوبی برای اولین PR.)

---

## ۳. ساختار پوشه‌ها

```
front-main/
├── proxy.ts                    # «middleware» نسخهٔ ۱۶ — refresh شفاف توکن + گیت /login
├── next.config.ts              # output: "standalone" + ریدایرکت لینک‌های کوتاه کمپین
├── package.json
├── tsconfig.json
├── eslint.config.mjs / postcss.config.mjs / .prettierrc.json
├── components.json             # کانفیگ shadcn
├── Dockerfile                  # سه مرحله: deps → builder → runner (standalone)
├── docker-compose.yml          # nginx-proxy + acme-companion + web
├── .gitlab-ci.yml              # build → (test کامنت) → deploy → android-apk (دستی)
│
├── app/                        # App Router
│   ├── layout.tsx              # <html lang="fa" dir="rtl">، فونت، SiteChrome، Toaster، SW، UTM
│   ├── globals.css             # tailwind + توکن‌های دیزاین سیستم
│   ├── page.tsx                # لندینگ / اپ‌هوم
│   ├── font/ manifest.ts robots.ts sitemap.ts opengraph-image.tsx icon/apple-icon/favicon
│   │
│   ├── (auth)/login/           # فرم ورود + Server Actions (OTP)
│   ├── (auth)/terms/           # قوانین و حریم خصوصی
│   ├── about/  blog/
│   │
│   ├── test/                   # آزمون رایگان ۳۰ سؤالی
│   │   ├── page.tsx            # معرفی
│   │   ├── demographic/        # فرم جمعیت‌شناسی (اختیاری، پیش از آزمون)
│   │   ├── questions/          # ۳۰ سؤال + actions
│   │   ├── analysis/           # AnalysisLoader (polling تولید گزارش)
│   │   └── resume/             # ادامهٔ آزمون نیمه‌کاره
│   │
│   ├── deep-test/              # آزمون عمیق ۱۵۰ سؤالی (پرداختی)
│   │   ├── page.tsx / questions/ / analysis/
│   │
│   ├── preview/                # تیزر گزارش برای کاربر مهمان (v1 + v2)
│   ├── report/                 # گزارش کامل (v1 + v2) + feedback/
│   ├── deep-report/            # گزارش عمیق
│   ├── paywall/                # صفحهٔ فروش آزمون عمیق
│   ├── payment/result/         # نتیجهٔ بازگشت از درگاه
│   │
│   ├── chat/                   # چت (Client Component بزرگ + actions)
│   ├── dashboard/              # داشبورد + history/ (تاریخچهٔ قدم‌ها)
│   ├── checkin/[actionStepId]/ # دیپ‌لینک نوتیفیکیشن
│   ├── history/                # تاریخچهٔ آزمون‌ها
│   ├── explore/                # هاب «کاوش»: آزمون رایگان + عمیق
│   ├── profile/                # پروفایل + bookmarks/ + feedback/
│   │
│   ├── api/                    # Route Handlers
│   │   ├── chat/sessions/[sessionId]/messages/route.ts              # پروکسی SSE
│   │   ├── chat/sessions/[sessionId]/messages/[messageId]/regenerate/route.ts
│   │   └── payment/callback/route.ts                                 # ← کد مرده (پایین را ببین)
│   ├── firebase-messaging-sw.js/route.ts    # سرویس‌ورکر پوش + کش آفلاین
│   └── push/actions.ts
│
├── components/
│   ├── ui/                     # primitives شادcn (button, card, input, badge, progress, …)
│   ├── site/                   # SiteChrome, SiteHeader, SiteFooter, MobileTabBar, LogoMark
│   ├── action-steps/           # ActionStepProposalSheet, StepDetailSheet, StepCompletionSheet,
│   │                           # StepNotificationCard, actions.ts
│   ├── report/                 # ReportV2Parts, ReportV2Chat, ReportV2Feedback, StepEditSheet, …
│   ├── analytics/              # TrackOnMount, TrackedLink, UtmCapture
│   ├── push/                   # RegisterServiceWorker
│   └── test/                   # RetakeNote
│
├── lib/
│   ├── api/                    # client.ts, endpoints.ts, schemas.ts, constants.ts, track-event-action.ts
│   ├── chat/                   # parse-sse.ts, prompts.ts
│   ├── analytics/              # utm.ts, source.ts, client-error.ts
│   ├── push/                   # subscribe.ts
│   ├── constants/              # app-download.ts, demographic-options.ts
│   └── utils/                  # action-step, date (jalali), digits, network, price, profile,
│                               # report, deep-report, utils(cn)
│
├── public/                     # آیکون‌ها، تصاویر گزارش/دیپ، offline.html
├── android/twa-manifest.json   # کانفیگ Bubblewrap (APK/AAB)
├── design_handoff_faraman_app 34/   # هندآف دیزاین (HTML پروتوتایپ + assets + README)
└── scripts/render_env.sh
```

**آمار کد:** ~۱۸٬۰۰۰ خط `.ts`/`.tsx` در `app/`+`components/`+`lib/`، ۱۰۸ فایل در `app/`.

---

## ۴. مدل معماری — چهار ستون

این پروژه از چهار مکانیزم Next استفاده می‌کند و **مرز بین‌شان کاملاً مشخص است**:

```
┌──────────────────────────────────────────────────────────────────────┐
│ ۱. Server Component (پیش‌فرض هر page.tsx)                            │
│    • fetch داده با apiFetch / apiFetchCached                         │
│    • ریدایرکت و گارد دسترسی                                          │
│    • رندر اولیهٔ SSR                                                  │
│    • ❌ نمی‌تواند Set-Cookie بنویسد                                  │
├──────────────────────────────────────────────────────────────────────┤
│ ۲. Server Action ("use server")  →  app/*/actions.ts                 │
│    • mutationها با apiMutate (کوکی‌های بک‌اند را relay می‌کند)        │
│    • الگوی ثابت: ActionResult<T> = {ok:true,data} | {ok:false,message}│
│    • قابل فراخوانی از Client Component                              │
├──────────────────────────────────────────────────────────────────────┤
│ ۳. Route Handler  →  app/api/**/route.ts                             │
│    • فقط جایی که Server Action کافی نیست:                            │
│      استریم SSE، ریدایرکت مرورگر، فایل داینامیک (SW/manifest)        │
├──────────────────────────────────────────────────────────────────────┤
│ ۴. proxy.ts (میدل‌ور)                                                │
│    • refresh شفاف توکن قبل از رسیدن درخواست به صفحه                  │
│    • گیت /login برای کاربر لاگین‌کرده                                 │
└──────────────────────────────────────────────────────────────────────┘
```

### چرا این تقسیم‌بندی؟

| نیاز | ابزار انتخابی | دلیل |
|---|---|---|
| خواندن داده در صفحه | Server Component + `apiFetch` | بدون آبشار کلاینت، SEO، بدون loading state دستی |
| خواندن داده‌ای که تکرار می‌شود | `apiFetchCached` | کش per-user با tag برای invalidation دقیق |
| نوشتن / mutation | Server Action | تایپ‌سیف، بدون نوشتن route دستی، کوکی relay می‌شود |
| استریم | Route Handler | Server Actionها یک پاسخ JSON بافر می‌کنند و برای SSE کار نمی‌کنند |
| refresh توکن | `proxy.ts` | قبل از هر رندر، شفاف، بدون flicker |

---

## ۵. لایهٔ API — مهم‌ترین بخش فرانت

سه فایل ستون فقرات هستند: `client.ts` (حمل‌ونقل)، `schemas.ts` (قرارداد)، `endpoints.ts` (تابع‌ها).

### ۵.۱ `lib/api/client.ts` (۲۳۹ خط)

کارهای این فایل:

**(الف) پوشش envelope.** همهٔ پاسخ‌های بک‌اند `{code, message, data}` هستند (حتی خطاها). پس یک `envelopeSchema` تعریف شده و هر پاسخ با `safeParse` باز می‌شود. کامنت کد صریح است: این ساختار «با صدا زدن بک‌اند واقعی تأیید شده، نه از OpenAPI» — چون drf-spectacular برای چند endpoint می‌گوید «بدنه ندارد» در حالی که envelope برمی‌گرداند.

**(ب) `ApiError`.** یک `Error` سفارشی با `status`، `message` و `data` خام. کل UI روی `error instanceof ApiError` و `error.status === 401` تصمیم می‌گیرد.

**(ج) استخراج پیام دقیق از خطای validation.** خطای DRF در `data` به‌شکل `{field: string[]}` می‌آید و `message` یک متن کلی است. تابع `extractErrorMessage` خطاهای فیلد را بیرون می‌کشد تا به کاربر پیام واقعی نشان داده شود (مثلاً «کد وارد شده باید ۴ رقم و فقط شامل عدد باشد.»).

**(د) چهار تابع عمومی:**

| تابع | برای | ویژگی |
|---|---|---|
| `apiFetch(path, schema, opts)` | خواندن در Server Component | کوکی‌ها را forward می‌کند ولی نمی‌تواند Set-Cookie را ذخیره کند (Server Component فقط‌خواندنی است) |
| `apiMutate(path, schema, opts)` | mutation در Server Action / Route Handler | `Set-Cookie` بک‌اند را **به مرورگر relay می‌کند** (`parseSetCookie`) |
| `apiFetchCached(path, schema, {tag, revalidate})` | خواندن تکراری | `unstable_cache` با کلید per-user |
| `revalidateUserTag(tag)` / `updateUserTag(tag)` | invalidation | نسخهٔ مخصوص Route Handler / Server Action |

**(ه) کوکی‌های relay.** `buildForwardedCookieHeader()` همهٔ کوکی‌های مرورگر را **به‌جز** توکن‌های خودمان (`faraman_access`, `faraman_refresh`) forward می‌کند — چون توکن به‌صورت `Authorization: Bearer` می‌رود و کوکی `anonymous_id` هم باید به بک‌اند برسد.

**(و) کش per-user — نکتهٔ ظریف امنیتی.** `unstable_cache` آرگومان‌هایش را در کلید کش می‌گذارد. اگر توکن خام در کلید برود، ممکن است در لاگ/دیسک ذخیره شود. راه‌حل: `userCacheKey()` یک **هش SHA-256 کوتاه** از توکن (۱۶ کاراکتر) می‌سازد؛ برای کاربر ناشناس `"anon"`. تگ هم به‌صورت `"${tag}:${key}"` اسکوپ می‌شود، پس دو کاربر هرگز entry مشترک ندارند.

همچنین `apiFetchCached` **فقط bearer token** را forward می‌کند، نه کل jar کوکی — چون کوکی‌هایی مثل `anonymous_id` می‌توانند تغییر کنند بدون اینکه دادهٔ این کاربر تغییر کرده باشد، و این کش را بی‌دلیل تکه‌تکه می‌کرد.

### ۵.۲ `lib/api/schemas.ts` (۹۶۰ خط، ۸۹ اسکیما)

همهٔ قرارداد API به‌صورت zod مدل شده است. این فایل به بخش‌های کامنت‌گذاری‌شده تقسیم شده و هر بخش می‌گوید داده از کجا آمده:

```
Real backend contract (from /api/schema/)
Demographics      (GET/PATCH ...)
Assessment/attempt (confirmed by calling the backend)
Payment           (POST /api/payment/initiate/)
Entitlements      (GET /api/users/me/entitlements/)
Action step deadline (apps.action_steps.models.ActionStep.DeadlineType)
Deep report       (GET /api/reports/attempts/{id}/ for a deep attempt)
Report            (v1)
Initial report v2 (report_spec_v2_0)
Pre-start / Feedback / Report email / Report history / Report attempts history
Chat (chat_spec_v1.md) / Message feedback+bookmark+regenerate
Action steps v2 / Push notifications
```

سیاست: **هر پاسخ بک‌اند قبل از رسیدن به UI با zod پارس می‌شود.** یعنی اگر بک‌اند شکل پاسخ را بشکند، تایپ‌اسکریپت در زمان اجرا خطای واضح می‌دهد به‌جای `undefined is not a function` در عمق UI.

این فایل همچنین منبع تایپ‌هاست (`type ReportResult = z.infer<...>`)، پس قرارداد و تایپ هیچ‌وقت از هم جدا نمی‌شوند.

### ۵.۳ `lib/api/endpoints.ts` (۴۷۴ خط، ~۴۰ تابع)

یک تابع per endpoint، با نام و امضای خوانا. نمونه:

```ts
getProfile() / updateProfile(input) / deleteAccount() / acceptTerms()
getAssessment(slug) / getPreStart(slug) / startAttempt(slug)
submitAnswer(attemptId, input) / deleteAnswer(attemptId, qid) / completeAttempt(id)
getReport(attemptId) / acceptReportStep(id, index) / retryReportGeneration(id)
sendReportEmail(id, email)
getEntitlements() / getProductPrices() / initiatePayment(...)
createChatSession(input) / listChatSessions() / getChatSessionMessages(id)
acceptChatAction(messageId) / submitMessageFeedback(...) / bookmarkMessage(...)
listPendingActionSteps(source?) / getActionStep(id) / editActionStep(...) /
completeActionStep(...) / recordActionStepReflection(...) / submitActionStepFollowup(...) /
reactivateActionStep(...)
registerPushSubscription(input) / trackEvent(input)
```

الگوی تکرارشوندهٔ مهم: **mutationها تگ کش مربوطه را invalidate می‌کنند.**

```ts
export async function acceptReportStep(attemptId, index) {
  const step = await apiMutate(`/api/reports/attempts/${attemptId}/steps/${index}/accept/`, ...);
  await updateUserTag("action-steps");     // ← وگرنه داشبورد دادهٔ کهنه نشان می‌دهد
  return step;
}
```

تگ‌های موجود: `action-steps`, `report-history`, `entitlements`, `product-prices`.

### ۵.۴ `lib/api/constants.ts`

- `API_BASE_URL` از `NEXT_PUBLIC_API_BASE_URL`
- `APP_URL` — آدرس عمومی خود سایت، **عمداً از درخواست استنتاج نمی‌شود** (پشت reverse proxy که Host را forward نمی‌کند، `request.url` به آدرس داخلی کانتینر مثل `0.0.0.0:3000` تبدیل می‌شد).
- `ACCESS_TOKEN_COOKIE = "faraman_access"` / `REFRESH_TOKEN_COOKIE = "faraman_refresh"`
- `SELF_KNOWLEDGE_ASSESSMENT_SLUG = "test-likert-v2"` / `DEEP_ASSESSMENT_SLUG = "deep-150-v1"`
- `FIREBASE_CONFIG` و `FCM_VAPID_KEY`

---

## ۶. احراز هویت در فرانت

### ۶.۱ چرخهٔ کامل

```
۱) کاربر شماره را می‌دهد
   login-form (client) → requestOtpAction ({"use server"})
        → sendOtp() → POST /api/account/otp/send/  (با UTM از کوکی)

۲) کاربر کد را می‌دهد
   verifyOtpAction → verifyOtp() → {access, refresh}
        → cookies().set(faraman_access, ..., maxAge: 60*30)      # ۳۰ دقیقه
        → cookies().set(faraman_refresh, ..., maxAge: 60*60*24*7) # ۷ روز
        → trackEventAction("auth_completed")

۳) هر درخواست بعدی
   proxy.ts: اگر access نبود ولی refresh بود → POST /api/account/token/refresh/
        → توکن جدید در کوکی + تزریق در هدر Cookie درخواست جاری
          (response.cookies.set فقط در درخواست *بعدی* به مرورگر می‌رسد، پس هدر
           request هم بازنویسی می‌شود تا همین رندر توکن را ببیند)

۴) logout
   کوکی‌ها حذف + POST /api/account/logout/ (بک‌اند همهٔ توکن‌ها را blacklist می‌کند)
```

**اعداد ۳۰ دقیقه و ۷ روز باید دستی با `SIMPLE_JWT` بک‌اند هم‌خوان بمانند** — این وابستگی در سه جا کامنت شده است (`proxy.ts`, `login/actions.ts`, `lib/api/constants.ts`). اگر لایف‌تایم بک‌اند عوض شود، این‌ها هم باید عوض شوند.

### ۶.۲ گارد دسترسی

- **در `proxy.ts`:** فقط `/login` گیت شده (کاربر لاگین‌کرده به `/` ریدایرکت می‌شود). عمداً آزمون و گزارش گیت نمی‌شوند چون ناشناس کار می‌کنند.
- **در صفحات:** الگوی تکرارشونده در `dashboard`, `history`, `profile`, `checkin`, `dashboard/history`:

```ts
const store = await cookies();
if (!store.has(ACCESS_TOKEN_COOKIE)) redirect(`/login?${new URLSearchParams({ next: "/dashboard" })}`);
```

و اگر بک‌اند ۴۰۱ داد (توکن منقضی/باطل) هم همان ریدایرکت انجام می‌شود.

### ۶.۳ نکته‌های ظریف که در کد حل شده‌اند

- **هرگز Server Action را روی `/login` ریدایرکت نکن.** Actionها به URL صفحه‌ای POST می‌شوند که از آن صدا زده شده‌اند؛ اگر `proxy.ts` یک POST از `/login` را به `/` ریدایرکت کند، ریدایرکت روی پارامتر `next` غلبه می‌کند. به همین دلیل شرط `!request.headers.has("next-action")` وجود دارد.
- **رویداد `auth_completed` داخل Server Action ثبت می‌شود**، نه از کلاینت بعد از بازگشت — چون آن درخواست دوم دوباره به `/login` POST می‌شد و ریدایرکت می‌خورد.

---

## ۷. نقشهٔ مسیرها

| مسیر | نوع | دسترسی | کار |
|---|---|---|---|
| `/` | RSC | عمومی | مهمان → landing؛ لاگین‌کرده → `AppHomeView` |
| `/explore` | RSC | عمومی | هاب «کاوش»: آزمون رایگان + عمیق + ادامهٔ آخرین تلاش |
| `/about`, `/blog`, `/terms` | RSC | عمومی | محتوا |
| `/login` | RSC + Client form | عمومی | OTP دو مرحله‌ای |
| `/test` | RSC | عمومی | معرفی آزمون رایگان |
| `/test/resume` | RSC | عمومی | ادامهٔ آزمون نیمه‌کاره |
| `/test/demographic` | RSC + Client form | عمومی | سن/جنسیت/وضعیت/هدف (قابل ذخیره ناشناس) |
| `/test/questions` | Client | عمومی | ۳۰ سؤال، ذخیرهٔ هر پاسخ با Server Action |
| `/test/analysis` | Client (loader) | عمومی | polling تا آماده‌شدن گزارش (حالت retry هم دارد) |
| `/preview` | RSC | عمومی | تیزر گزارش (v1/v2) |
| `/report` | RSC | مالک | گزارش کامل (v1/v2) + کارت ایمیل + CTA چت |
| `/report/feedback` | RSC + Client | مالک | فیدبک گزارش |
| `/deep-test` | RSC | عمومی | معرفی آزمون عمیق |
| `/deep-test/questions` | Client | خریدار | ۱۵۰ سؤال + milestone |
| `/deep-test/analysis` | Client (loader) | خریدار | polling گزارش عمیق |
| `/deep-report` | RSC | خریدار | گزارش عمیق با بخش‌های قابل پرسش |
| `/paywall` | RSC | عمومی (قیمت عمومی) | فروش آزمون عمیق؛ مهمان → `/login` |
| `/payment/result` | RSC + Client | عمومی | نتیجهٔ پرداخت؛ invalidate دستی entitlements |
| `/chat` | Client (۱۴۳۲ خط) | لاگین | چت استریمی + پنل تاریخچه + کارت قدم |
| `/dashboard` | RSC | لاگین | خانهٔ کاربر: گزارش فعلی، قدم‌های جاری با urgency |
| `/dashboard/history` | RSC | لاگین | تاریخچهٔ قدم‌ها |
| `/checkin/[id]` | RSC | لاگین | دیپ‌لینک پوش (reminder/followup) |
| `/history` | RSC | لاگین | تاریخچهٔ آزمون‌ها/گزارش‌ها |
| `/profile` | RSC + Client | لاگین | پروفایل، جمعیت‌شناسی، خروج، حذف حساب |
| `/profile/bookmarks` | RSC | لاگین | پیام‌های ذخیره‌شدهٔ چت |
| `/profile/feedback` | RSC + Client | لاگین | فیدبک محصول |
| `/api/chat/.../messages` | Route Handler | — | پروکسی SSE |
| `/api/chat/.../regenerate` | Route Handler | — | پروکسی SSE |
| `/api/payment/callback` | Route Handler | — | **کد مرده** |
| `/firebase-messaging-sw.js` | Route Handler | — | سرویس‌ورکر پوش + کش آفلاین |
| `/manifest.webmanifest` | `manifest.ts` | — | PWA |
| `/robots.txt`, `/sitemap.xml` | `robots.ts`, `sitemap.ts` | — | SEO |
| `/opengraph-image` | `opengraph-image.tsx` | — | تصویر OG داینامیک |

**ریدایرکت‌های کوتاه کمپین** (در `next.config.ts`):

| کد | مقصد |
|---|---|
| `/d` | `/paywall?utm_source=sms&utm_campaign=deep_followup` |
| `/k` | `/test?utm_source=telegram&utm_campaign=kaaf` |
| `/ka` | `/test?utm_source=telegram_ads&utm_campaign=kaaf_channel` |
| `/kf` | `/paywall?utm_source=sms&utm_campaign=kf_tst_flw` |

این‌ها برای پیامک/تلگرام هستند؛ `UtmCapture` پارامترها را در کوکی `faraman_utm` می‌ریزد.

**منطق تشخیص گزارش:** `app/report/page.tsx` یک «دیسپچر» است:

```
getReport(attemptId)
 ├─ status === "generating" → redirect /test/analysis (برگشت به حلقهٔ polling)
 ├─ status === "error"      → <ReportUnavailable attemptId={...}/> (با دکمهٔ retry)
 ├─ !("stage" in result)    → گزارش deep است → redirect /deep-report
 ├─ stage === "preview"     → redirect /preview
 └─ isReportV2(result) ? <ReportViewV2/> : <ReportView/>
```

---

## ۸. جریان داده — یک مثال کامل

**مثال: صفحهٔ داشبورد (`app/dashboard/page.tsx`)**

```tsx
export default async function DashboardPage() {
  // ۱) گارد دسترسی
  const store = await cookies();
  if (!store.has(ACCESS_TOKEN_COOKIE)) redirect(`/login?next=/dashboard`);

  // ۲) سه خواندن موازی-پذیر، هر کدام مقاوم به خطا
  let name, profileIncomplete;
  try {
    const profile = await getProfile();          // → apiFetch → بک‌اند
    name = profile.name;
    profileIncomplete = !isProfileComplete(profile);
  } catch (error) {
    if (error instanceof ApiError && error.status === 401) redirect(...);
    // خطای غیراحراز هویت: به fallback برو، کل صفحه را نشکن
  }

  const history = await getReportHistory().catch(...);  // اولین گزارش
  const pendingSteps = await listPendingActionSteps().catch(() => []);

  // ۳) محاسبهٔ سمت سرور (urgency هر قدم بر اساس deadline)
  const stepsWithUrgency = withUrgency(pendingSteps);

  // ۴) تحویل دادهٔ آماده به Client Component
  return <DashboardView name={name} currentReport={...} profileIncomplete={...} pendingSteps={stepsWithUrgency} />;
}
```

**اصولی که در این ۳۰ خط دیده می‌شود — و در کل پروژه تکرار می‌شوند:**

1. گارد دسترسی **اول** صفحه.
2. هر fetch در `try/catch` **جداگانه**: یک خطای غیرحیاتی (مثلاً لیست قدم‌ها) نباید کل داشبورد را به صفحهٔ خطا تبدیل کند.
3. `error.status === 401` تنها خطایی است که به ریدایرکت منجر می‌شود.
4. محاسبهٔ منطق (urgency) در سرور انجام می‌شود، نه در کلاینت.
5. Client Component فقط دادهٔ آماده می‌گیرد و رندر می‌کند؛ خودش fetch اولیه نمی‌کند.

**مقایسه با صفحهٔ تعاملی (`app/test/questions`)**: آنجا صفحه یک Client Component است و هر پاسخ با `submitAnswerAction` (Server Action) ذخیره می‌شود. الگوی خطا:

```ts
type ActionResult<T> = { ok: true; data: T } | { ok: false; message: string };
// همهٔ actions این الگو را دارند — نه throw، نه any
```

---

## ۹. استریم چت — پیچیده‌ترین جریان فرانت

سه لایه درگیر است:

```
chat-view.tsx (client)
   │  fetch(`/api/chat/sessions/${id}/messages`, {method:"POST", body})
   ▼
app/api/chat/.../route.ts (Route Handler، server)
   │  کوکی httpOnly → Authorization: Bearer
   │  fetch(`${API_BASE_URL}/api/chat/sessions/${id}/messages/`)
   │  بدنهٔ پاسخ را **بدون تغییر** pipe می‌کند
   ▼
Django (SSE)
```

### چرا Route Handler و نه Server Action؟

کامنت خود فایل پاسخ می‌دهد: JWT در کوکی httpOnly است و Client Component نمی‌تواند آن را بخواند، و `apiFetch`/`apiMutate` یک envelope JSON بافر می‌کنند — برای stream بی‌فایده‌اند. این route در سرور اجرا می‌شود، Bearer را می‌چسباند و بدنه را مستقیم pipe می‌کند.

### مدیریت خطای دوگانه

Route Handler دو نوع خطا را تفکیک می‌کند:

- خطای **قبل از استریم** (session بد، پیام بیش از حد بلند) — بک‌اند یک envelope JSON معمولی برمی‌گرداند، نه SSE. route آن را با همان status و content-type relay می‌کند.
- خطای **داخل استریم** — `event: error` در بدنه.

### پارس SSE (`lib/chat/parse-sse.ts`)

یک پارسر مینیمال و بدون کتابخانه (عمدی، برای سه نوع event): بافر می‌کند، روی `\n\n` می‌شکند، `event:`/`data:` را می‌خواند و به‌صورت `AsyncGenerator` می‌دهد. سپس در `chat-view.tsx`:

```ts
for await (const evt of parseSseStream(res.body)) {
  if (evt.event === "delta")  → متن را روی پیام در حال تایپ append کن
  if (evt.event === "done")   → id، proposed_action، quick_replies را ثبت کن
  if (evt.event === "error")  → پیام خطا را با user_message نشان بده
}
```

### رفتارهای UI که در `chat-view.tsx` پیاده شده

- **TTFT ادراکی:** پیام کاربر فوراً ظاهر می‌شود، سپس پیام assistant با `streaming: true` که متنش بزرگ می‌شود.
- **تشخیص آفلاین:** `isConnectionError` / `isOffline` از `lib/utils/network.ts`. پیام خطا عمداً می‌گوید «ارتباط با اینترنت برقرار نیست» — نسخهٔ قبلی می‌گفت «الان کمی شلوغ است» که اشتباهاً بک‌اند را مقصر می‌دانست.
- **`callAction`:** چون Server Actionها خطای بک‌اند را به `{ok:false, message}` تبدیل می‌کنند، یک *rejection* در کلاینت یعنی خودِ رفت‌وبرگشت شکسته — بدون این wrapper صفحه بی‌صدا هیچ کاری نمی‌کرد.
- **کارت قدم پیشنهادی:** از `proposed_action` ساخته می‌شود؛ با انتخاب deadline و پذیرش، `acceptChatActionAction` صدا زده می‌شود و کارت به حالت «پذیرفته‌شده» می‌رود.
- **درخواست پوش، گِیت‌شده با تپ کاربر:** `shouldAskForPush()` فقط وقتی true است که permission قبلاً granted نباشد؛ درخواست خودکار و بی‌دلیل مرورگر، نرخ رد شدن را بالا می‌برد و دیگر قابل بازپرسیدن نیست (برای همین `DENIED_HINT` وجود دارد که راهنمای تنظیمات مرورگر می‌دهد).
- **پنل تاریخچه:** lazy لود (`listChatSessionsAction`)، با حذف و بازکردن نشست.
- **فیدبک/بوکمارک/کپی/regenerate** برای هر پیام assistant.

---

## ۱۰. پرداخت در فرانت

### جریان فعلی

```
/paywall (یا /deep-test) → initiatePayment() → { payment_url }
   → window.location = payment_url   (درگاه زرین‌پال)

زرین‌پال → GET api.faraman.ai/api/payment/callback/?Authority=..&Status=..
   → بک‌اند verify می‌کند و ۳۰۲ می‌دهد به:
     faraman.ai/payment/result?status=success&assessment=deep-150-v1&attempt_id=..

/payment/result (RSC)
   → در mount: markEntitlementsStaleAction()   ← invalidate دستی کش entitlements
   → دکمه‌های «برو به آزمون» / «برگشت»
```

**نکتهٔ مهم `markEntitlementsStaleAction`:** چون callback دیگر از داخل Next عبور نمی‌کند و Server Actionی اجرا نمی‌شود، کش `getEntitlements` (۵ دقیقه) خودش باطل نمی‌شد. این action که از `useEffect` روی mount صدا زده می‌شود، همان کار را می‌کند تا `/paywall` و `/deep-test` خرید را فوراً ببینند.

### ⚠️ کد مرده: `app/api/payment/callback/route.ts`

این فایل وجود دارد و کامنت آن می‌گوید «زرین‌پال به اینجا ریدایرکت می‌کند و ما server-to-server به بک‌اند relay می‌کنیم». **اما این دیگر درست نیست.** بک‌اند حالا `callback_url` را روی `BACKEND_PUBLIC_URL/api/payment/callback/` می‌گذارد و خودش ریدایرکت نهایی به فرانت را می‌سازد (به‌دلیل یک incident واقعی: relay قدیمی هیچ error handling روی `fetch` نداشت و اگر فرانت در آن لحظه در دسترس نبود، پرداخت واقعی بدون هیچ مسیر retry تأیید نمی‌شد).

نتیجه: این route دیگر هیچ‌وقت صدا زده نمی‌شود. **قبل از هر کاری این را با تیم تأیید کن**، ولی شواهد قوی است که باید حذف شود (همراه با کامنت گمراه‌کننده‌اش).

---

## ۱۱. پوش نوتیفیکیشن و سرویس‌ورکر

```
RegisterServiceWorker (در layout)
   → register("/firebase-messaging-sw.js")

app/firebase-messaging-sw.js/route.ts  (Route Handler، نه فایل استاتیک)
   • importScripts نسخهٔ compat Firebase 10.14.1
   • firebase.initializeApp(FIREBASE_CONFIG)     ← همان کانفیگ اپ، بدون کپی که drift کند
   • onBackgroundMessage → self.registration.showNotification
   • notificationclick → فوکوس/باز کردن تب با URL
   • install → کش offline.html  (تنها سرویس‌ورکر سایت — یک SW دوم با همین scope
                                 با آن بر سر fetch events می‌جنگید)
```

**چرا data-only؟** بک‌اند (`push_sender.py`) هیچ فیلد `notification` نمی‌فرستد، عمداً. اگر می‌فرستاد، مرورگر نوتیف بومی خودش را نشان می‌داد **و** این handler یکی دیگر → دو نوتیف برای یک رویداد. الان `showNotification()` تنها منبع حقیقت است.

**لایهٔ کلاینت (`lib/push/subscribe.ts`):**

- `shouldAskForPush()` — آیا باید پیشنهاد بدهیم؟
- `subscribeToPush()` → `Notification.requestPermission()` → dynamic import `firebase/app` + `firebase/messaging` (تا SDK در باندل اصلی نباشد) → `getToken({vapidKey, serviceWorkerRegistration})` → `registerPushSubscriptionAction(token)` به بک‌اند.

---

## ۱۲. UI و دیزاین سیستم

### ۱۲.۱ توکن‌های طراحی

`app/globals.css` نسخهٔ Tailwind 4 است (بدون فایل کانفیگ JS): `@import "tailwindcss"` + `@theme inline { ... }` و متغیرهای CSS.

توکن‌های اختصاصی فرامن (نام‌گذاری‌شده از `design_handoff_faraman_app 34/Design System.dc.html`):

```
--primary-deep, --navy, --purple-accent
--success, --success-tint
--warning, --warning-tint, --warning-border
--danger-tint, --danger-border, --danger-text
--lavender-tint, --lavender-border, --lavender-text
--purple-tint, --disabled
--text-secondary, --text-faint, --text-faintest
--chip-border
```

رنگ‌های پایه: پس‌زمینهٔ `#F8F4EC` (کرم گرم)، متن `#242A38`، تم PWA `#2743c6`.

### ۱۲.۲ قاعده‌های RTL و فارسی (از هندآف، در کد رعایت شده)

- `dir="rtl"` روی `<html>`، `lang="fa"`.
- **فلش برگشت به راست اشاره می‌کند**، chevron رفتن به چپ.
- **ارقام فارسی‌الهندی** در نمایش: `toPersianDigits()`. ورودی شماره موبایل و OTP استثناست (`dir="ltr"`, چپ‌چین) — و `toEnglishDigits()` برای پارس ورودی کاربر.
- **فونت:** `Estedad` (variable 100–900) با `next/font/local` از `app/fonts/Estedad-Variable.woff2`.
- تاریخ شمسی: `formatJalali()` با dayjs + jalaliday، خروجی مثل «۱۵ تیر ۱۴۰۴».
- چیدمان: ستون تک، `max-width` + `mx-auto`، padding افقی ۲۸px، حداقل تاچ ۴۴px.
- عرض‌ها: صفحات جریان **۵۶۰px**، گزارش **۶۸۰px**، هیرو لندینگ **۷۲۰px**.
- Responsive عمدتاً بدون media query: `clamp()` برای تایپوگرافی و `grid-template-columns: repeat(auto-fit, minmax(...))` برای کارت‌ها.

### ۱۲.۳ کامپوننت‌ها

- `components/ui/` — ۱۲ primitive از shadcn با style `base-nova` و **`@base-ui/react`** به‌جای Radix: `button`, `card`, `input`, `label`, `badge`, `progress`, `separator`, `skeleton`, `spinner`, `sonner`, + `use-sheet-drag.ts` (هوک کشیدن شیت).
- `components/site/` — `SiteChrome` تصمیم می‌گیرد چه چیزی نشان داده شود:
  - مسیرهای بدون chrome: `/test/questions`, `/test/demographic`, `/test/analysis`, `/chat`, `/login`
  - هدر شفاف روی هیرو: `/report`, `/deep-report`, `/preview` (روشن) و `/` (variant متفاوت چون هیروی لندینگ عکس روشن است)
  - بقیه: هدر/فوتر/TabBar معمولی
  - `MobileTabBar` ثابت پایین + یک `div` با ارتفاع ۷۶px برای اینکه محتوا زیرش نرود.
- `components/action-steps/` — چهار شیت/کارت برای چرخهٔ قدم: پیشنهاد، جزئیات، اتمام، کارت نوتیفیکیشن.
- `components/report/` — قطعات گزارش v2 (بخش‌ها، چت، فیدبک، ویرایش قدم، نوار ایمیل).

---

## ۱۳. کش و Revalidation

| داده | تگ | پنجره |
|---|---|---|
| دسترسی‌ها (`getEntitlements`) | `entitlements` | ۵ دقیقه |
| قیمت محصولات (`getProductPrices`) | `product-prices` | ۳۰۰ ثانیه |
| تاریخچهٔ گزارش‌ها | `report-history` | ۶۰ ثانیه |
| تاریخچهٔ attemptها | `report-history` | ۳۰ ثانیه |
| قدم‌های در جریان / تاریخچه | `action-steps` | ۳۰ ثانیه |
| بقیه (پروفایل، چت، گزارش) | بدون کش (`apiFetch`) | — |

**دو تابع invalidation با دلیل متفاوت:**

- `updateUserTag(tag)` → از **Server Action** (تحت Next فقط `updateTag` آنجا مجاز است). معنایش: درخواست بعدی منتظر دادهٔ تازه می‌ماند.
- `revalidateUserTag(tag)` → از **Route Handler** (چون `updateTag` آنجا مجاز نیست). معنایش: stale-while-revalidate.

مثال استفاده: `payment-result-view` با `markEntitlementsStaleAction` تگ `entitlements` را باطل می‌کند تا کاربر بعد از خریدن، بلافاصله آزمون را باز ببیند.

---

## ۱۴. تحلیل و ردیابی (Analytics)

```
UtmCapture (در layout)
   → UTM را از URL می‌خواند و در کوکی faraman_utm (۳۰ روز) می‌نویسد

trackEventAction (Server Action)
   → UTM از کوکی را می‌خواند
   → properties: { ...utm, ...input.properties }   ← property صریح بر کوکی اولویت دارد
   → trackEvent → POST /api/events/track/
   → هر خطا بی‌صدا بلعیده می‌شود («analytics هرگز نباید UX را که می‌سنجد بشکند»)

TrackOnMount      ← ثبت رویداد در mount (با withUtm اختیاری)
TrackedLink       ← لینک با رویداد
toastClientError  ← توست خطا + ثبت رویداد client_error_shown (متن تا ۲۰۰ کاراکتر)
```

نکتهٔ طراحی مهم: UTM در `window.location` خوانده می‌شود (داخل effect)، نه از `searchParams` — تا صفحه statically renderable بماند.

---

## ۱۵. PWA و اپ اندروید

- `app/manifest.ts` — نام/آیکون/رنگ/`start_url`/`display: standalone`/`dir: rtl`.
- `public/offline.html` + کش در سرویس‌ورکر.
- `android/twa-manifest.json` — کانفیگ **Bubblewrap** برای ساختن Trusted Web Activity:
  - `packageId: ai.faraman.twa`, `host: faraman.ai`, نسخه `1.0.1` (code 2)
  - `enableNotifications: true`, `minSdkVersion: 21`, `fallbackType: customtabs`
- CI job `android-apk` در `.gitlab-ci.yml` فرانت: **دستی**، روی runner با JDK 17 + Android SDK.
  - سه متغیر CI لازم است: `ANDROID_KEYSTORE_BASE64`, `BUBBLEWRAP_KEYSTORE_PASSWORD`, `BUBBLEWRAP_KEY_PASSWORD`.
  - Bubblewrap به نسخهٔ `1.23.0` pin شده (عمدی): نسخه‌های جدیدتر به `androidbrowserhelper` جدیدتر نیاز دارند که `dl.google.com` از این سرور 404 می‌دهد.
  - `JAVA_OPTS` از یک SOCKS proxy محلی (`127.0.0.1:51414`) رد می‌شود چون Google Maven مستقیم در دسترس نیست.
  - ترفند `update --skipVersionUpgrade` قبل از `build` تا در یک checkout تازه، Bubblewrap به‌صورت تعاملی hang نکند.

---

## ۱۶. استقرار فرانت

### Dockerfile (سه مرحله)

```
deps    → node:22-alpine (از mirror) + npm ci
builder → کپی node_modules + سورس، تزریق NEXT_PUBLIC_* به‌صورت build-arg، npm run build
runner  → فقط .next/standalone + .next/static + public، کاربر non-root (uid 1001)
          CMD ["node", "server.js"]
```

**نکتهٔ کلیدی:** `NEXT_PUBLIC_*` در **زمان build** داخل باندل inline می‌شود، نه در زمان اجرا. پس `docker-compose.yml` همهٔ آن‌ها را به‌عنوان `build.args` پاس می‌دهد و `.env` باید **قبل از** `make build` وجود داشته باشد (برخلاف بک‌اند که کانفیگش runtime-only است).

### `docker-compose.yml` فرانت

```
nginx-proxy     (پورت ۸۰/۴۴۳، docker.sock read-only)
acme-companion  (گواهی Let's Encrypt)
web             (VIRTUAL_HOST=faraman.ai,www.faraman.ai, VIRTUAL_PORT=3000)
```

این استک همان چیزی است که `api.faraman.ai`، `grafana.faraman.ai` و `metabase.faraman.ai` هم گواهی‌شان را از آن می‌گیرند.

### CI/CD

```
build   → source scripts/render_env.sh && make build      (MR + main)
test    → ❌ کامنت‌شده  (قرار بود: npm ci && npm run lint && npx tsc --noEmit)
deploy  → source scripts/render_env.sh && make up          (فقط main)
android-apk → دستی
```

---

## ۱۷. کنوانسیون‌ها و قواعد عملی

**الگوهایی که هنگام اضافه‌کردن کد باید رعایت کنی:**

1. **هر صفحهٔ خواندنی = Server Component.** `cookies()` و `redirect()` آزادند. fetchها در `lib/api/endpoints.ts`، نه در صفحه.
2. **هر mutation = Server Action** در `actions.ts` همان مسیر، با امضای `ActionResult<T>`.
3. **هر پاسخ API = zod schema** در `schemas.ts`، و تایپ از `z.infer` گرفته می‌شود.
4. **`"use client"` را فقط در برگ‌ها بگذار.** صفحه‌ها Server باشند، و فقط جزء تعاملی Client شود (`*-view.tsx`).
5. **`import "server-only"`** در هر ماژولی که نباید به کلاینت برسد (`client.ts`, `endpoints.ts`).
6. **هر fetch غیرحیاتی را جدا `catch` کن** تا یک شکست کل صفحه را نکشد.
7. **پیام خطا برای کاربر از `ApiError.message`** بیاید (که خودش پیام میدانی DRF را استخراج کرده).
8. **ارقام و تاریخ:** نمایش با `toPersianDigits`/`formatJalali`، پارس ورودی با `toEnglishDigits`.
9. **هر mutation که دادهٔ کش‌شده را عوض می‌کند** باید تگ مربوطه را invalidate کند.
10. **`aria-*` و `min-height:44px`** برای دسترس‌پذیری و تاچ.

**چیزهایی که «نکن»:**

- ❌ `fetch` مستقیم به `API_BASE_URL` از یک Client Component (توکن httpOnly است)
- ❌ خواندن/نوشتن توکن از `localStorage` یا `document.cookie`
- ❌ نوشتن منطق کسب‌وکار در کامپوننت (مثل محاسبهٔ سطح یا قیمت — این‌ها در بک‌اند هستند)
- ❌ استفاده از `searchParams` برای UTM (باعث dynamic شدن صفحه می‌شود)
- ❌ استنتاج `APP_URL` از `request.url` (پشت پروکسی می‌شکند)
- ❌ اضافه‌کردن Server Action دوم روی `/login` که به ریدایرکت برخورد کند
- ❌ ساخت سرویس‌ورکر دوم (با Firebase SW بر سر fetch می‌جنگد)

---

## ۱۸. نقاط ضعف، بدهی فنی و توصیه‌ها

### 🔴 مهم

1. **هیچ تستی وجود ندارد** — نه unit، نه integration، نه e2e. `package.json` هیچ test script ندارد. تنها شبکهٔ امنیت، `eslint` و `tsc --noEmit` است که **هر دو در CI کامنت‌اند**. برای پروژه‌ای با این حجم منطق (SSE، کش per-user، refresh توکن، پرداخت)، این بزرگ‌ترین شکاف است. پیشنهاد: Vitest برای `lib/` (خصوصاً `parse-sse`, `client.ts`, `utils/*`) + Playwright برای دو مسیر بحرانی (آزمون و پرداخت).
2. **`app/api/payment/callback/route.ts` کد مرده است** و کامنت آن گمراه‌کننده.
3. **هم‌خوانی دستی لایف‌تایم توکن** بین `proxy.ts`/`login/actions.ts` و `SIMPLE_JWT` بک‌اند — سه عدد جادویی که اگر یکی عوض شود، کاربر بعد از ۳۰ دقیقه بی‌دلیل logout می‌شود.
4. **بدون staging** — هر merge به `main` روی `faraman.ai` می‌رود.

### 🟠 متوسط

5. **وابستگی‌های استفاده‌نشده:** `zustand`, `motion`, `recharts` (حذف کن).
6. **`schemas.ts` با ۹۶۰ خط و ۸۹ اسکیما** بزرگ شده؛ شکستن به `schemas/report.ts`, `schemas/chat.ts`, … خواندن و diff را بهتر می‌کند.
7. **`chat-view.tsx` با ۱۴۳۲ خط** — بزرگ‌ترین فایل پروژه. کاندید استخراج: کامپوننت پیام، کارت قدم، پنل تاریخچه، کامپوزر، هوک استریم (`useChatStream`).
8. **`ReportView` (۷۳۹) + `ReportViewV2` (۵۲۸)** موازی زندگی می‌کنند. تا وقتی v1 لازم است این درست است، ولی وقتی v2 تثبیت شد باید v1 بازنشسته شود.
9. **دوباره‌کاری سناریوها در دو مسیر آزموم** (`test/*` و `deep-test/*`) — منطق مشابه، کامپوننت‌های جدا.

### 🟡 کوچک

10. `allowedDevOrigins` در `next.config.ts` یک IP محلی هاردکد دارد (`10.40.135.155`).
11. `design_handoff_faraman_app 34/` (با فاصله در نام) داخل مخزن است و حجم زیادی asset دارد؛ بهتر است به مخزن جدا یا Git LFS برود.
12. `.env.example` فرانت هنوز `ACME_EMAIL` را با کامنت «Traefik» توضیح می‌دهد، در حالی که پروژه از `nginx-proxy` + `acme-companion` استفاده می‌کند — کامنت کهنه.
13. `PAYWALL_DISCOUNT_PERCENT` منطق «قیمت خط‌خورده» را از قیمت واقعی مشتق می‌کند (`real / (1 - percent/100)`). این یک قرارداد ظریف بین فرانت و بک‌اند است که باید مستند و تست شود.

---

## ۱۹. «کجا چه چیزی را پیدا کنم» — نقشهٔ سریع

| می‌خواهم بدانم… | برو به |
|---|---|
| قرارداد کامل API در تایپ‌اسکریپت | `lib/api/schemas.ts` |
| یک endpoint چطور صدا زده می‌شود | `lib/api/endpoints.ts` |
| envelope، کوکی، کش، خطا | `lib/api/client.ts` |
| refresh توکن / گیت ورود | `proxy.ts` |
| چیدمان کلی، فونت، chrome | `app/layout.tsx` + `components/site/site-chrome.tsx` |
| توکن‌های رنگ/تایپ | `app/globals.css` |
| ورود با OTP | `app/(auth)/login/{page.tsx,_components/login-form.tsx,actions.ts}` |
| جریان آزمون ۳۰ سؤالی | `app/test/**` |
| جریان آزمون ۱۵۰ سؤالی | `app/deep-test/**` |
| گزارش v1 / v2 | `app/report/page.tsx` → `_components/report-view{,-v2}.tsx` |
| گزارش عمیق | `app/deep-report/_components/deep-report-view.tsx` |
| استریم چت | `app/chat/_components/chat-view.tsx` + `app/api/chat/**` + `lib/chat/parse-sse.ts` |
| چرخهٔ قدم عملی | `components/action-steps/**` + `app/dashboard/**` |
| پرداخت | `app/paywall/**`, `app/payment/result/**` |
| پوش | `lib/push/subscribe.ts`, `app/firebase-messaging-sw.js/route.ts`, `app/push/actions.ts` |
| رویدادها و UTM | `lib/api/track-event-action.ts`, `lib/analytics/utm.ts`, `components/analytics/**` |
| تاریخ شمسی و ارقام | `lib/utils/date.ts`, `lib/utils/digits.ts` |
| متن‌های خطای شبکه | `lib/utils/network.ts` |
| طراحی مرجع (پروتوتایپ) | `design_handoff_faraman_app 34/` (خصوصاً `Faraman App.dc.html` و `Design System.dc.html`) |
| کانفیگ اپ اندروید | `android/twa-manifest.json` |
