# فرامن (Faraman) — نمای کلی پروژه، وضعیت فعلی و قابلیت‌ها

> این سند برای «آشنایی اولیه و آنبورد شدن» نوشته شده است. اگر می‌خواهی جزئیات فنی هر لایه را ببینی، به دو سند کنار آن برو:
> - `02-backend-architecture.md` — معماری، لایه‌بندی و جزئیات بک‌اند (Django)
> - `03-frontend-architecture.md` — معماری، ساختار و جزئیات فرانت‌اند (Next.js)

---

## ۱. محصول در یک نگاه

**فرامن** یک محصول **خودشناسی و رشد شخصی** است، فارسی و کاملاً راست‌به‌چپ، mobile-first، که با هوش مصنوعی کار می‌کند.

مسیر اصلی محصول:

1. کاربر یک **تست شخصیت کوتاه (۳۰ سؤالی)** را رایگان انجام می‌دهد.
2. سیستم پاسخ‌ها را **کاملاً در بک‌اند** امتیازدهی می‌کند (هیچ عددی توسط AI ساخته نمی‌شود) و سپس یک **گزارش اولیه** با AI تولید می‌شود.
3. کاربر **گزارش را می‌خواند**؛ یک «قدم اول» پیشنهادی را می‌تواند بپذیرد و به یک **Action Step** واقعی با موعد (deadline) و یادآور پوش تبدیل کند.
4. کاربر می‌تواند با **دستیار چت** دربارهٔ گزارش و قدم‌هایش گفت‌وگو کند (استریم SSE).
5. یک **تست عمیق ۱۵۰ سؤالی** به‌صورت پرداختی (زرین‌پال) وجود دارد که گزارش آن ۸ فراخوانی مدل است و تحلیل خیلی مفصل‌تری می‌دهد.
6. در طول مسیر: پوش‌نوتیفیکیشن (FCM)، ایمیل گزارش با PDF، بوکمارک پیام، فیدبک، ردیابی رویداد و UTM برای بازاریابی.

از نظر فنی، پروژه **دو اپلیکیشن جدا** است:

| | مخزن/پوشه | نقش |
|---|---|---|
| **فرانت‌اند** | `front-main` (نام پکیج: `faraman-front`) | Next.js — همهٔ UI، SSR، Server Actions، پروکسی SSE، سرور PWA/APK |
| **بک‌اند** | `back-main` (نام پروژه: `faraman_back`) | Django + DRF — همهٔ منطق، داده، AI، پرداخت، اعلان |

دیتابیس، صف کار (Celery)، کش/OTP (Redis) و کل استک مانیتورینگ همه سمت بک‌اند هستند. **فرانت‌اند هیچ‌وقت مستقیم با دیتابیس یا سرویس‌های خارجی حرف نمی‌زند** — فقط با API بک‌اند.

---

## ۲. وضعیت کلی پروژه (تصویر لحظه‌ای)

این پروژه **در حال بهره‌برداری واقعی (production) است**، نه یک نمونهٔ اولیه. شواهد:

- دامنه‌های زندهٔ `faraman.ai`، `api.faraman.ai`، `grafana.faraman.ai`، `metabase.faraman.ai` در کانفیگ‌ها هست.
- CI/CD روی GitLab خودمیزبان (hamgit.ir) با **runner از نوع shell روی خود سرور production**.
- مانیتورینگ کامل (Prometheus + Grafana + Loki + Promtail + exporterها + Metabase).
- تست بار (Locust) واقعاً اجرا شده و دو باگ ظرفیت جدی بر اساس آن رفع شده.
- یک فایل `CLAUDE.md` در بک‌اند با بیش از ۸۰ کیلوبایت مستندات تصمیم‌ها، تاریخچهٔ باگ‌ها و «قواعد سختِ» معماری.

در همان حال، چند بخش **نیمه‌کاره یا در حال عرضه** است (جزئیات در بخش‌های ۶ و ۷):

- عرضهٔ **گزارش اولیه نسخهٔ ۲** (`report_v2`) — کد و فرانت آماده است ولی فلگ روشن‌کردنش تصمیم محصولی است.
- **گزارش عمیق**: پرامپت‌های ۸ فراخوانی هنوز «eval» نشده‌اند (خودِ کد این را در `.env.example` نوشته).
- **تست بار روی production** ساخته نشده (فاز دوم).
- **Backup/PITR برای دیتابیس** وجود ندارد.
- **HA واقعی** (Postgres/Redis/VM) انجام نشده؛ فقط افزونگی در سطح پروسه داریم.
- **مرحلهٔ `test` در CI هر دو مخزن کامنت شده** است؛ یعنی merge به `main` = استقرار زنده و بدون هیچ گیت تست.

> ⚠️ **مهم‌ترین واقعیتی که باید بدانی:** **هیچ محیط staging وجود ندارد.** merge به `main` بلافاصله image می‌سازد، کانتینرها را recreate می‌کند و migration را روی production اجرا می‌کند. هر تغییر کانفیگ یا تنظیمات باید با این فرض انجام شود که مستقیم روی کاربر واقعی می‌رود.

---

## ۳. معماری کلان (تصویر بزرگ)

```
                        ┌──────────────────────────────┐
   کاربر (مرورگر/APK)   │      faraman.ai (Next.js)     │
        ───────────────►│  • RSC / Server Actions       │
                        │  • Route Handlers (SSE relay) │
                        │  • httpOnly JWT cookies       │
                        └───────────────┬───────────────┘
                                        │  server-to-server (Bearer JWT)
                                        │  + api.faraman.ai برای callback زرین‌پال
                        ┌───────────────▼───────────────┐
                        │      nginx (compose own)      │
                        │  upstream web / web2 (failover)│
                        └───────────────┬───────────────┘
                          ┌─────────────┴─────────────┐
                    ┌─────▼─────┐               ┌─────▼─────┐
                    │   web     │               │   web2    │   gunicorn + gevent
                    │  Django   │               │  Django   │   3 workers × 100 conn
                    └─────┬─────┘               └─────┬─────┘
                          │                           │
        ┌─────────────────┼───────────┬───────────────┼──────────────┐
        │                 │           │               │              │
   ┌────▼────┐      ┌─────▼─────┐ ┌───▼────┐   ┌──────▼──────┐  ┌────▼─────┐
   │   db    │      │   redis   │ │celery  │   │ celery-beat │  │ external │
   │pgbouncer│      │ OTP/thrott│ │celery2 │   │  (فقط ۱)    │  │ services │
   └────┬────┘      │ broker    │ └───┬────┘   └─────────────┘  └────┬─────┘
        │           └───────────┘     │                             │
   ┌────▼─────┐                       │        OpenAI / AvalAI · Melipayamak(SMS)
   │ postgres │◄──────────────────────┘        Liara(SMTP) · Zarinpal · Firebase(FCM)
   │   16     │                                Bale(alert) · Metabase · Grafana
   └──────────┘
```

نکات کلیدی که از این نمودار باید برداشت شود:

- **TLS و دامنه‌ها** توسط یک استک جدا مدیریت می‌شود: `nginx-proxy` + `acme-companion` که در مخزن فرانت (`delyar-front_default` network) بالاست. nginx خودِ بک‌اند فقط HTTP روی پورت ۸۱ است و با `VIRTUAL_HOST=api.faraman.ai` به آن استک وصل می‌شود تا گواهی بگیرد.
- **pgbouncer** با نام سرویس `db` جای postgres نشسته؛ به همین دلیل هیچ‌جا `DB_HOST` عوض نشده. این تصمیم بعد از یک تست بار واقعی گرفته شد (۵۱٪ خطا در ۲۰۰ کاربر همزمان).
- **celery-beat هرگز نباید بیشتر از ۱ رپلیکا شود** — وگرنه هر تسک زمان‌بندی‌شده دو بار اجرا می‌شود.
- تعداد مصرف‌کننده‌های AI زیاد است و همه از یک کلاینت مشترک OpenAI با تنظیمات تایم‌اوت خاص استفاده می‌کنند (جزئیات در سند بک‌اند).

---

## ۴. قابلیت‌های فعلی (فهرست کامل با وضعیت)

### ۴.۱ احراز هویت و حساب کاربری

| قابلیت | وضعیت | توضیح کوتاه |
|---|---|---|
| ورود با شماره موبایل + OTP | ✅ کامل | بدون رمز عبور. کد ۵ رقمی، هش SHA-256 در Redis با TTL ۵ دقیقه |
| محدودیت درخواست مجدد OTP | ✅ کامل | وجود کلید در Redis = throttled |
| محافظت brute-force روی verify | ✅ کامل | شمارندهٔ تلاش غلط؛ بعد از `OTP_MAX_VERIFY_ATTEMPTS` (پیش‌فرض ۵) کد باطل می‌شود |
| JWT (access 30m / refresh 7d) | ✅ کامل | `rest_framework_simplejwt` + اپ blacklist؛ logout همهٔ توکن‌ها را باطل می‌کند |
| refresh شفاف در فرانت | ✅ کامل | `proxy.ts` (میان‌افزار Next) قبل از رسیدن درخواست به صفحه، توکن را تازه می‌کند |
| پروفایل و جمعیت‌شناسی | ✅ کامل | `PATCH` پروفایل + فرم جمعیت‌شناسی (سن/جنسیت/وضعیت/هدف) |
| Demographics ناشناس → claim بعد از ورود | ✅ کامل | کاربر بدون ورود هم می‌تواند فرم را پر کند؛ بعد از login به حسابش منتقل می‌شود |
| پذیرش قوانین با نسخه | ✅ کامل | `terms_version` + `terms_accepted_at` |
| حذف حساب (soft delete) | ✅ کامل | همهٔ داده‌های شخصی با کاربر soft-delete می‌شوند |
| OTP bypass برای اکانت‌های تست | ✅ کامل | `TEST_OTP_PHONE_NUMBERS` + `TEST_OTP_CODE` |
| پیامک | ✅ Melipayamak | ایراد پیامک به `SmsDeliveryError` تبدیل می‌شود، نه ۵۰۰ خام |

### ۴.۲ آزمون‌ها (Assessment)

| قابلیت | وضعیت |
|---|---|
| آزمون کوتاه ۳۰ سؤالی (Big Five) | ✅ فعال — slug: `test-likert-v2`، scoring profile: `big_five_30` |
| آزمون عمیق ۱۵۰ سؤالی (۳۰ facet + ۵ domain) | ✅ فعال — slug: `deep-150-v1`، scoring profile: `facet_150` |
| شروع/ادامهٔ خودکار attempt ناتمام | ✅ |
| ثبت پاسخ، undo پاسخ | ✅ |
| بررسی کامل‌بودن و اتمام آزمون | ✅ از طریق `ScoringRouter` (اگر اشتباه route شود، آزمون کامل «ناتمام» گزارش می‌شود) |
| محدودیت تعداد تلاش روزانه | ✅ throttle روی شماره موبایل |
| داده‌های ناشناس قبل از ورود | ✅ attempt با `anonymous_id`؛ بعد از login مالکیت claim می‌شود |
| ذخیرهٔ UTM منبع آزمون | ✅ در `Attempt.source` |
| سؤالات آزمون عمیق از منبع علمی | ✅ `apps/assessment/data/deep_150.py` (ترنسکرایپ دفترچهٔ امتیازدهی v1.2) |

### ۴.۳ تولید گزارش

| قابلیت | وضعیت | توضیح |
|---|---|---|
| گزارش اولیه | ✅ اما **آسنکرون** | یک فراخوانی AI در Celery؛ ردیف `Report` با `status=generating` ساخته می‌شود و فرانت polling می‌کند |
| گزارش اولیه — **نسخه ۱** | ✅ پایدار | ساختار بلند و کلاسیک (`dimension_scores` + متن‌های AI) |
| گزارش اولیه — **نسخه ۲** (کوتاه، کارت‌محور) | 🟡 آماده، در حال عرضه | `hook`, ۲ `finding`, `open_question`, `exit`. با env `REPORT_INITIAL_VERSION` سوییچ می‌شود؛ پیش‌فرض کد هنوز v1 است |
| گزارش عمیق | ✅ کد کامل، 🟡 کیفیت در حال سنجش | ۸ فراخوانی موازی AI (۵ domain + ۲ topics + ۱ closing) با نردبان تلاش مستقل هر کدام |
| امتیازدهی deterministic | ✅ | هیچ عددی از AI نمی‌آید؛ در گزارش عمیق حتی `raw` و `provisional` هم به کلاینت نمی‌رسد (فقط `low/mid/high`) |
| الگوهای ترکیبی (active_patterns) | ✅ | در بک‌اند محاسبه می‌شود، نه توسط مدل |
| Memory (حافظهٔ بلندمدت) | ✅ | ۴ نوع: `core_pattern`, `strength`, `growth_edge`, `growth_focus`؛ کلید یکتا `(user, type, source)` |
| لاگ هزینهٔ هر فراخوانی AI | ✅ | `GenerationLog` با توکن، مدل، latency و cost محاسبه‌شده از جدول قیمت (`ModelPricing`) |
| Retry دستی تولید گزارش | ✅ | `POST /api/reports/attempts/<id>/retry/` بدون نیاز به تکرار آزمون |
| Preview برای کاربر مهمان | ✅ | گزارش ناقص/تیزر بدون لاگین |
| ارسال گزارش با ایمیل + PDF | ✅ | SMTP لیارا + WeasyPrint با فونت وزیرمتن embed‌شده |
| گزارش‌های v1 و v2 همزمان قابل زندگی | ✅ | هر ردیف `report_version` خودش را دارد |

### ۴.۴ چت با دستیار

| قابلیت | وضعیت | توضیح |
|---|---|---|
| استریم پاسخ با SSE | ✅ | `event: delta / done / error`، دو هاپ (Django → Route Handler → مرورگر) |
| منابع ورود به چت (entry sources) | ✅ | `manual`, `report_cta`, `report_open_question`, `report_finding_focus:<0|1>`, `deep_report_cta`, `deep_report_focus:<section>`, `action_rejected`, `action_active`, `action_missed`, `action_completed` |
| تزریق حافظه و تاریخچهٔ قدم‌ها | ✅ | memory + ۳ قدم آخر به payload مدل می‌رود |
| کارت قدم پیشنهادی در چت | ✅ | با مارکر `<<<ACTION>>>` در پاسخ مدل، پارس و به کارت تبدیل می‌شود |
| Quick replies | ✅ | دکمه‌های پاسخ سریع، متually exclusive با کارت قدم |
| Regenerate پیام | ✅ | با همان محدودیت مصرف |
| تاریخچهٔ نشست‌ها با عنوان و آخرین پیام | ✅ | ستون‌های denormalized برای حذف N+1 |
| فیدبک (👍/👎) و بوکمارک پیام | ✅ | `/api/messages/...` |
| سقف پیام روزانه | ✅ | ۵۰ پیام (send + regenerate مشترک) در پنجرهٔ ۲۴ ساعته، پیش‌فرض env |
| قطع تمیز در disconnect کاربر | ✅ | متن تولیدشده تا لحظهٔ قطع ذخیره می‌شود؛ متریک `client_disconnect` |

### ۴.۵ قدم‌های عملی (Action Steps)

| قابلیت | وضعیت |
|---|---|
| ساخت قدم از گزارش / از چت | ✅ (`source`: `initial_report:rec_n`, `deep_report:action_n`, `chat`) |
| محاسبهٔ deadline بر اساس انتخاب کاربر | ✅ (`tonight`, `tomorrow_morning`, `tomorrow_evening`, `within_24h` — همه به وقت تهران) |
| یادآور و follow-up | ✅ دو نوتیفیکیشن، زمان‌بندی‌شده در بک‌اند |
| پوش نوتیفیکیشن FCM | ✅ data-only تا نوتیف دوتایی نمایش داده نشود |
| اتمام قدم + بازتاب (reflection) | ✅ |
| ثبت مانع («چرا انجام نشد») | ✅ با فهرست دلایل |
| ویرایش قدم (با شمارش edit) | ✅ |
| تاریخچهٔ قدم‌ها + فعال‌سازی مجدد | ✅ |
| دیپ‌لینک نوتیفیکیشن به `/checkin/:id` | ✅ |

### ۴.۶ پرداخت و دسترسی

| قابلیت | وضعیت |
|---|---|
| درگاه زرین‌پال (REST v4) | ✅ با sandbox پیش‌فرض روشن |
| Callback مستقیم روی بک‌اند | ✅ `api.faraman.ai/api/payment/callback/` → ریدایرکت به فرانت |
| محصولات و قیمت عمومی | ✅ `GET /api/payment/products/` بدون نیاز به لاگین |
| کوپن تخفیف (درصدی، سقف مصرف، انقضا) | ✅ با `select_for_update` |
| Purchase / Entitlement | ✅ `EntitlementService.has_access` تنها منبع حقیقت |
| مدل «بعد از آزمون پرداخت کن» | ✅ `Assessment.report_requires_purchase` → گزارش با `status=awaiting_payment` قفل می‌ماند |
| مصرف دسترسی بعد از اتمام آزمون | ✅ آزمون بعدی نیاز به پرداخت جدید دارد |

### ۴.۷ رشد، تحلیل و عملیات

| قابلیت | وضعیت |
|---|---|
| ردیابی رویداد با allowlist پراپرتی | ✅ ~۲۷ رویداد، هر کدام فقط کلیدهای مجاز |
| UTM first-touch روی کاربر | ✅ |
| UTM last-touch روی هر رویداد + ایندکس partial | ✅ برای قیف‌های کمپین در Metabase |
| لینک‌های کوتاه کمپین (`/d`, `/k`, `/ka`, `/kf`) | ✅ ریدایرکت‌های Next با UTM |
| فیدبک محصول (امتیاز + دلیل + کامنت) | ✅ |
| مانیتورینگ متریک‌های اپلیکیشن | ✅ متریک‌های `faraman_*` |
| لاگ متمرکز | ✅ Loki + Promtail |
| داشبورد محصول | ✅ Metabase با نقش SELECT-only |
| آلرتینگ به پیام‌رسان بله | ✅ وب‌هوک Grafana → `apps/alerting` |
| PWA + اپ اندروید (TWA) | ✅ manifest + bubblewrap؛ APK/AAB دستی در CI |
| تست بار | ✅ Locust روی استک لوکال |

---

## ۵. مسیر کاربر و ماشین حالت

```
        ┌──────────── landing (/) ────────────┐
        │  (کاربر لاگین‌کرده نسخهٔ app-home     │
        │   را می‌بیند، مهمان نسخهٔ landing)     │
        └───────────────┬─────────────────────┘
                        ▼
        /explore (کاوش: آزمون رایگان + آزمون عمیق)
                        │
        ┌───────────────┼────────────────────┐
        ▼                                    ▼
   /test (معرفی)                      /deep-test (معرفی، پرداختی)
        ▼                                    │  بدون خرید → /paywall
   /test/demographic (اختیاری)                ▼
        ▼                              /deep-test/questions (۱۵۰ سؤال)
   /test/questions (۳۰ سؤال)                  ▼
        ▼                              /deep-test/analysis (polling)
   /test/analysis (polling گزارش)               ▼
        ▼                              /deep-report?attemptId=
   گزارش:
     ├── کاربر مهمان → /preview (تیزر) → /login
     └── صاحب گزارش → /report (v1 یا v2)
                          │
     ┌────────────────────┼─────────────────────┬───────────────┐
     ▼                    ▼                     ▼               ▼
  /chat            کارت «قدم اول»        /report/feedback    /paywall
  (دستیار)          → ActionStep             (فیدبک)       (ارتقا به عمیق)
     │                    │
     ▼                    ▼
  /profile          /dashboard (قدم‌های جاری)
  ├── /profile/bookmarks          ├── /dashboard/history
  ├── /profile/feedback           └── /checkin/:id  ← دیپ‌لینک پوش
  ├── /history (تاریخچهٔ آزمون‌ها)
  └── /terms, /about, /blog
```

نکته‌های مهم این ماشین حالت:

- **آزمون و دیدن گزارش بدون لاگین ممکن است** (backend مالکیت را با `anonymous_id` می‌شناسد). فقط چت، داشبورد و پروفایل لاگین می‌خواهند.
- اگر گزارش هنوز `generating` باشد، صفحات `/report` و `/preview` کاربر را به `/test/analysis` برمی‌گردانند تا حلقهٔ polling ادامه پیدا کند.
- اگر گزارش از نوع deep باشد (فیلد `stage` ندارد)، به `/deep-report` ریدایرکت می‌شود.
- `/report` بر اساس `report_version` بین `ReportView` (v1) و `ReportViewV2` انتخاب می‌کند.

---

## ۶. مدل داده در سطح کلان

۱۱ اپ Django، ۱۱ دامنه. جدول‌ها تقریباً این‌ها هستند (جزئیات در سند بک‌اند):

```
users ─┬─ anonymous_demographics (پیش از ثبت‌نام)
       ├─ assessment_attempts ─┬─ assessment_answers
       │                       ├─ reports ─┬─ report_generation_logs
       │                       │           ├─ report_email_deliveries
       │                       │           └─ user_memories
       │                       └─ payments ─── purchases
       ├─ chat_sessions ─┬─ chat_messages ─┬─ message_feedbacks
       │                 │                 └─ message_bookmarks
       │                 └─ chat_generation_logs
       ├─ action_steps ─┬─ action_step_responses
       │                └─ notifications
       ├─ push_subscriptions
       ├─ feedbacks
       └─ events

assessments ─┬─ assessment_sections ─── assessment_questions
             └─ payment_products ─┬─ payment_coupons
                                  └─ payments
```

اصول مشترک داده:

- **Soft delete** با جفت `is_deleted` / `deleted_at` در جاهایی که داده شخصی است (گزارش، چت، فیدبک، لاگ‌ها، attempt).
- **UUID** برای موجودیت‌هایی که در URL می‌آیند و نباید قابل شمارش باشند (`ChatSession`, `ActionStep`). `Attempt` و `Report` عددی هستند.
- **JSONField** برای همهٔ چیزهایی که شکلشان با نسخهٔ پرامپت عوض می‌شود (`report_data`, `facet_scores`, `scoring`, `properties`, …). این عمدی است: تغییر نسخهٔ گزارش نباید ردیف‌های قدیمی را بشکند.

---

## ۷. چه چیزهایی «در حال تکمیل» هستند

این بخش مهم‌ترین قسمت برای آنبورد شدن است، چون این‌ها جاهایی هستند که ممکن است رویشان کار کنی.

### ۷.۱ عرضهٔ گزارش نسخهٔ ۲ (`report_v2`)

- کدِ کامل سمت AI (`schema_v2.py`, `prompt_v2.py`, `fewshot_v2/`)، سمت سرویس (`_build_preview_v2`, ایمیل `pdf_initial_v2.html`) و سمت فرانت (`ReportViewV2`, `PreviewReportV2`) وجود دارد.
- **سوییچ:** env `REPORT_INITIAL_VERSION` (در `.env.example` روی `report_v2` است، اما پیش‌فرض کد `report_v1` است). چون تولید در Celery انجام می‌شود، **بعد از تغییر این متغیر باید `celery`/`celery2` ری‌استارت شوند**.
- v1 حذف نمی‌شود: هر ردیف نسخهٔ خودش را نگه می‌دارد، پس می‌توان رفت و برگشت کرد.
- چت هم برای v2 مسیر جدید دارد (`report_open_question`, `report_finding_focus:0|1`) و اگر گزارش v1 باشد خطای `ReportVersionMismatchException` می‌دهد.

### ۷.۲ کیفیت گزارش عمیق

- خودِ `.env.example` می‌گوید: «the eight-call prompts have not been through eval yet» در حالی که `DEEP_REPORT_AI_ENABLED=true` است.
- یعنی ریسک اصلی اینجاست: کد درست کار می‌کند، اما **کیفیت خروجی مدل سنجیده نشده**.

### ۷.۳ فاز دوم تست بار روی production

- `REPORT_AI_ENABLED` / `DEEP_REPORT_AI_ENABLED` / `CHAT_AI_ENABLED` فلگ‌های **global** هستند؛ اگر روی production خاموش شوند، همهٔ کاربران واقعی خروجی mock می‌گیرند.
- راه‌حل طراحی‌شده (هنوز ساخته نشده): یک «bypass secret» در سطح درخواست (مثل الگوی `GRAFANA_WEBHOOK_SECRET` با `hmac.compare_digest`) تا فقط ترافیک تست mock شود.

### ۷.۴ بقیهٔ موارد نیمه‌کاره

| مورد | وضعیت |
|---|---|
| اپ اندروید (TWA) | manifest و CI job دستی وجود دارد؛ نسخه `1.0.1` |
| سیاست اعلان (notification policy) در Grafana که آلرت‌ها را به contact point بله بفرستد | contact point ساخته شده، **routing rule هنوز نه** |
| Readiness probe (علاوه بر liveness) | عمداً عقب افتاده تا orchestrator مناسب بیاید |
| i18n کامل | ساختار `lang/fa/messages.py` آماده است ولی رشته‌های فارسی هاردکد در چند جا باقی مانده (مثلاً متن نوتیفیکیشن) |

---

## ۸. ریسک‌ها، بدهی فنی و کارهای باز

این‌ها از فایل `CLAUDE.md` بک‌اند استخراج شده‌اند (آن فایل تاریخچهٔ دقیق دارد). دسته‌بندی‌شده و به ترتیب اهمیت:

### 🔴 ریسک بالا

1. **بدون staging + بدون گیت تست در CI.** مرحلهٔ `test:` در هر دو `.gitlab-ci.yml` کامنت است. هیچ‌کس قبل از deploy، `manage.py check`، migration یا تست‌ها را روی یک `.env` رندرشده اجرا نمی‌کند. (این باعث یک incident واقعی شده: `DB_CONN_MAX_AGE` خالی → `int('')` → کرش settings.py روی import → همهٔ workerها بی‌صدا کرش‌لوپ شدند.)
2. **بدون backup/PITR برای Postgres.** یک کانتینر با یک volume محلی. از دست رفتن volume = از دست رفتن کامل داده.
3. **به‌روزرسانی امنیتی HTTP سطح انتقال تنظیم نشده:** `SECURE_PROXY_SSL_HEADER`, `SECURE_SSL_REDIRECT`, `HSTS`, `SESSION_COOKIE_SECURE`, `CSRF_COOKIE_SECURE`, `SECURE_CONTENT_TYPE_NOSNIFF`. `manage.py check --deploy` همه را flag می‌کند. (دلیلش این است که TLS را پروکسی بیرونی terminate می‌کند و Django از آن بی‌خبر است.)
4. **Rate limit روی اکثر endpointهای احراز هویت‌شده نیست.** فقط OTP، events، attempt، ایمیل گزارش و چت (۵۰/روز) محدود شده‌اند. بقیهٔ APIها باز هستند.
5. **Celery: بدون time limit و بدون صف جدا.** گزارش عمیق (۸ فراخوانی، چند دقیقه) با گزارش اولیه و نوتیفیکیشن‌ها در یک صف و یک worker است. یک فراخوانی هنگ‌کرده، اسلات worker را نامحدود نگه می‌دارد.

### 🟠 ریسک متوسط

6. **SPOF در سطح زیرساخت:** `postgres`, `redis`, `nginx` و خود VM تک‌نسخه‌ای‌اند. roadmap در `docs/infrastructure.md` (فاز B و C) نوشته شده ولی شروع نشده.
7. **`os.getenv(key, default)` در برابر `render_env.sh` شکننده است.** این اسکریپت برای هر کلید `.env.example` یک خط می‌نویسد — حتی اگر متغیر CI تنظیم نشده باشد (مقدار خالی). پس `os.getenv` با default خودش هرگز fire نمی‌شود؛ فقط `os.getenv(x) or default` امن است. **این قاعده برای هر متغیر جدید عددی/بولین حیاتی است.**
8. **nginx هیچ `keepalive` به upstream ندارد** → هر درخواست یک اتصال TCP جدید به web/web2. (رفعش ساده است ولی عمداً جدا شده تا ریسکش جدا بماند.)
9. **migration دستی است:** `entrypoint.sh` فقط gunicorn را بالا می‌آورد؛ migration در CI با `make migrate` اجرا می‌شود. چیزی جلوی deploy کد جلوتر از schema را نمی‌گیرد.

### 🟡 بدهی فنی / کد

10. **`requirements.txt` بک‌اند پر از وابستگی مرده است.** کل یک استک قدیمی Flask/SQLAlchemy/Alembic/zeep/suds/pyfcm/APScheduler/django-emoji و `google-cloud-*` هنوز نصب می‌شود، در حالی که کد فقط از Django/DRF/Celery/Redis/requests/pydantic/openai/WeasyPrint/firebase-admin استفاده می‌کند. این هم زمان build را بالا می‌برد هم سطح حمله را.
11. **کد تکراری بین `ReportService` و `DeepReportService`:** متدهای `_persist_memories` و `_log_generation` تقریباً کپی‌به‌کپی هستند؛ اصلاح در یکی و نه دیگری باعث واگرایی رفتار می‌شود.
12. **کلاینت mock گزارش عمیق، fixture را در هر فراخوانی از دیسک می‌خواند و پارس می‌کند.**
13. **ایمپورت داخل تابع در `push_sender.py`** (lazy init برای firebase) — از نظر قاعدهٔ ۴ معماری «خاکستری» است.
14. **emit شدن دو نوتیفیکیشن در پوش** در گذشته؛ با data-only ارسال حل شده، ولی مراقب باش برنگردد.
15. **کد مردهٔ فرانت:** `app/api/payment/callback/route.ts` هنوز وجود دارد، در حالی که بک‌اند حالا callback را مستقیم می‌گیرد و خودش ریدایرکت می‌کند. کامنت داخل همین فایل هم دیگر درست نیست.
16. **فرانت‌اند هیچ تستی ندارد** (نه unit، نه e2e). فقط `eslint` و `tsc --noEmit` که هر دو در CI کامنت‌اند.

---

## ۹. نقشهٔ راه پیشنهادی برای onboarding

اگر تازه وارد شده‌ای، به این ترتیب بخوان و انجام بده:

**روز ۱ — شناخت بدون کد زدن**

1. همین سند را تمام کن.
2. `back-main/CLAUDE.md` را بخوان (طولانی است ولی مهم‌ترین سند پروژه است — تصمیم‌ها و تاریخچه).
3. `back-main/docs/infrastructure.md` را بخوان (توپولوژی، deploy، plan افزونگی).
4. سند `02-backend-architecture.md` و `03-frontend-architecture.md` را بخوان.

**روز ۲ — راه‌اندازی محیط**

1. بک‌اند: `cp .env.example .env` و مقادیر را پر کن → `make up` → `make migrate` → `make seed-test-assessment` + `make seed-deep-assessment`.
2. `make test` را اجرا کن (تست‌ها repository را mock می‌کنند، پس به DB واقعی نیاز ندارند).
3. فرانت: `npm ci` → `cp .env.example .env.local` (حداقل `NEXT_PUBLIC_API_BASE_URL`) → `npm run dev`.
4. `make monitoring-up` برای دیدن Prometheus/Grafana.
5. سراغ `loadtest/` برو و `make loadtest-run` را با سناریوی سبک امتحان کن.

**روز ۳ — مسیرهای داغ کد**

1. یک درخواست را end-to-end دنبال کن: `POST /api/account/otp/send/` → `otp_view` → `OtpService` → `OtpRepository` (Redis) → `SMSService`.
2. مسیر آزمون: `attempt_view` → `AttemptService` → `ScoringRouter` → Celery task → `ReportService.generate_initial` → `ReportRepository`.
3. مسیر چت: `chat_view` → `ChatService.send_message` → `_stream` → `AiChatClient` → `ChatGenerationClient` → `generate_chat_stream`.
4. سمت فرانت: `lib/api/client.ts` (پوشش envelope، کوکی‌ها، کش per-user) → `lib/api/endpoints.ts` (همهٔ APIها) → یک Server Action (`app/test/questions/actions.ts`) → یک صفحهٔ Server Component (`app/dashboard/page.tsx`) → یک جزء کلاینتی (`app/chat/_components/chat-view.tsx`).

**روز ۴ — اولین قدم‌های واقعی**

- یک مورد از لیست «بدهی فنی» را انتخاب کن که ریسک کم دارد (مثلاً پاکسازی `requirements.txt` با `pip check`، یا حذف route مردهٔ payment callback، یا اضافه‌کردن `keepalive` به nginx).
- **قبل از هر تغییری** دو نکته را در ذهن داشته باش: (۱) merge = deploy روی production، (۲) هر متغیر محیطی جدید باید `os.getenv(x) or default` باشد و در `.env.example` + متغیرهای GitLab ثبت شود.

---

## ۱۰. واژه‌نامهٔ پروژه

| اصطلاح | معنی در این پروژه |
|---|---|
| **Attempt** | یک بار شرکت در یک آزمون. مالکش یا `user` است یا `anonymous_id`. |
| **Report (initial / deep)** | خروجی یک attempt. `report_type` تشخیص‌دهنده است، نه دو جدول جدا. |
| **report_v1 / report_v2** | دو شکل گزارش اولیه. هر ردیف نسخه‌اش را نگه می‌دارد. |
| **scoring_profile** | تعیین می‌کند کدام سرویس امتیازدهی اجرا شود (`big_five_30` یا `facet_150`). |
| **facet / domain** | در آزمون ۱۵۰ سؤالی: ۳۰ facet زیر هر ۵ domain بزرگ. |
| **Core Domain Raw / quality_metrics** | داده‌های cross-check آزمون عمیق؛ ذخیره می‌شود ولی هرگز نمایش داده یا به AI داده نمی‌شود. |
| **Entry source** | دلیل ورود کاربر به چت (از گزارش، از قدم، از داشبورد، دستی…). پرامپت بر اساس آن عوض می‌شود. |
| **Action Step** | یک کار مشخص با موعد و یادآور، که از گزارش یا چت ساخته می‌شود. |
| **Memory** | جملهٔ حافظهٔ بلندمدت دربارهٔ کاربر که از گزارش استخراج و در چت تزریق می‌شود. |
| **Entitlement / Purchase** | حق دسترسی خریداری‌شده به یک محصول. بعد از یک آزمون مصرف می‌شود. |
| **Anonymous id** | کوکی پایدار که به کاربر قبل از لاگین هویت می‌دهد تا آزمون در مرور نیمه‌کاره نماند. |
| **Envelope** | شکل ثابت پاسخ API: `{code, message, data, message_key?}`. |
| **AppException** | کلاس پایهٔ خطاهای دامنه؛ هندلر global آن را به envelope تبدیل می‌کند. |
| **Ladder (نردبان تلاش)** | زنجیرهٔ تلاش‌های مدل: primary ×N روی OpenAI → backup روی OpenAI → backup روی AvalAI. |
| **SSE** | Server-Sent Events؛ پروتکل استریم پاسخ چت. |
| **TWA** | Trusted Web Activity؛ اپ اندروید که همان PWA را در وب‌ویو نشان می‌دهد. |
| **render_env.sh** | اسکریپت CI که `.env` را از متغیرهای GitLab می‌سازد (با تلهٔ «خط خالی»). |

---

## ۱۱. جمع‌بندی صادقانه

**نقاط قوت این کدبیس:**

- لایه‌بندی سخت‌گیرانه و یکدست در بک‌اند (view → service → repository) که در تمام ۱۱ اپ رعایت شده و «قواعد سخت» مکتوب دارد.
- جداسازی مسئولیت بین فرانت و بک‌اند تمیز است: فرانت هیچ‌وقت به دیتابیس، کلید AI، یا درگاه پرداخت دسترسی ندارد.
- تصمیم‌های ظرفیت و پایداری **بر اساس اندازه‌گیری** گرفته شده‌اند (pgbouncer، gevent، `CONN_MAX_AGE=0`) نه حدس.
- مستندسازی تصمیم‌ها بسیار خوب است — به‌خصوص `CLAUDE.md` که تاریخچهٔ هر باگ و دلیل هر انتخاب را نگه می‌دارد.
- امنیت پایهٔ محصول درست است: هیچ عدد خامی از آزمون به کلاینت نمی‌رود، OTP هش می‌شود، OTP brute-force محدود شده، حساب‌ها soft-delete می‌شوند، ایمیل گزارش throttle دارد، allowlist برای پراپرتی رویدادها وجود دارد.

**نقاط ضعف اصلی:**

- فرآیند انتشار (بدون staging، بدون تست در CI) بزرگ‌ترین ریسک است — نه خودِ کد.
- زیرساخت تک‌نقطه‌ای (DB، Redis، VM) با یک محصول در حال رشد تناسب ندارد.
- بدهی فنی «تمیزکاری» (requirements مرده، کد تکراری بین دو سرویس گزارش، نداشتن تست فرانت) هنوز جمع نشده.
- کیفیت خروجی AI در گزارش عمیق هنوز ارزیابی نشده — این یک ریسک محصولی است، نه مهندسی.
