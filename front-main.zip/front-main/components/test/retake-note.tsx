import { History, Clock } from "lucide-react";
import { toPersianDigits } from "@/lib/utils/digits";

// Design reference: design_handoff_faraman_app/RetakeNote.dc.html — the shared 2-state retake
// component (design_brief_free_test_flow_EN.md §5). Tone rule: the capped copy always frames the
// limit around result reliability, never cost — never change that framing here.
const RESET_LABEL = "فردا";

export function RetakeNote({
  remaining,
  limit,
}: {
  remaining: number;
  limit: number;
}) {
  if (remaining <= 0) {
    return (
      <div className="border-lavender-border bg-lavender-tint flex items-start gap-[13px] rounded-2xl border px-[18px] py-4">
        <div className="mt-px grid size-[34px] flex-none place-items-center rounded-[11px] bg-[#E7E2F5]">
          <Clock size={18} strokeWidth={1.8} className="text-lavender-text" />
        </div>
        <div className="flex flex-col gap-[5px]">
          <div className="text-lavender-text text-[13px] leading-[1.7] font-extrabold">
            هر دو آزمون امروزتان را انجام داده‌اید — و همین کافی‌ست تا نتیجه‌ها معنادار بمانند.
          </div>
          <div className="text-[12px] leading-[1.95] text-[#6A6394]">
            گزارش شما امن است و هر وقت خواستید می‌توانید ببینیدش. یک آزمون تازه {RESET_LABEL} باز
            می‌شود.
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="shadow-card border-border bg-card flex items-center gap-[13px] rounded-2xl border px-[18px] py-3.5">
      <div className="bg-secondary grid size-[34px] flex-none place-items-center rounded-[11px]">
        <History size={18} strokeWidth={1.8} className="text-primary" />
      </div>
      <div className="flex flex-col gap-0.5">
        <div className="text-[13px] font-extrabold">
          {remaining >= limit
            ? `امروز ${toPersianDigits(limit)} آزمون رایگان دارید`
            : `می‌توانید امروز ${toPersianDigits(remaining)} آزمون دیگر انجام دهید`}
        </div>
        <div className="text-text-faint text-[11.5px] leading-[1.7]">
          هر آزمون یک نتیجهٔ تازه می‌سازد — برای اینکه نتیجه‌ها معنادار بمانند، روزی دو بار.
        </div>
      </div>
    </div>
  );
}
