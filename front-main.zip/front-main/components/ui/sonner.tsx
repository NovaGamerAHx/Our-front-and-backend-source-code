"use client";

import { useTheme } from "next-themes";
import { Toaster as Sonner, toast, type ToasterProps } from "sonner";
import { CheckIcon, InfoIcon, TriangleAlertIcon, XIcon, Loader2Icon } from "lucide-react";

// Tap anywhere on a toast to dismiss it early; otherwise it auto-hides after AUTO_DISMISS_MS.
const AUTO_DISMISS_MS = 5000;

const Toaster = ({ ...props }: ToasterProps) => {
  const { theme = "system" } = useTheme();

  function handleClick(event: React.MouseEvent<HTMLDivElement>) {
    const target = event.target as HTMLElement;
    const toastEl = target.closest("[data-sonner-toast]");
    if (!toastEl) return;
    // A loading toast is tracking real work — it dismisses itself when that resolves.
    if (toastEl.getAttribute("data-type") === "loading") return;
    // The action / close buttons run their own handlers — let them.
    if (target.closest("[data-button],[data-close-button]")) return;
    // Don't yank the toast away mid text-selection.
    if (window.getSelection()?.toString()) return;
    toast.dismiss();
  }

  return (
    <div onClick={handleClick}>
      <Sonner
        theme={theme as ToasterProps["theme"]}
        className="toaster group"
        duration={AUTO_DISMISS_MS}
        // Design System §9: plain glyphs sit inside a filled colored disc (styled in globals.css),
        // so the icons themselves are simple strokes, not their own bordered circles.
        icons={{
          success: <CheckIcon className="size-3" strokeWidth={3.5} />,
          info: <InfoIcon className="size-3" strokeWidth={2.5} />,
          warning: <TriangleAlertIcon className="size-3" strokeWidth={2.5} />,
          error: <XIcon className="size-3" strokeWidth={3.5} />,
          loading: <Loader2Icon className="size-4 animate-spin" />,
        }}
        style={
          {
            "--normal-bg": "#ffffff",
            "--normal-text": "#242a38",
            "--normal-border": "var(--border)",
            "--border-radius": "14px",
          } as React.CSSProperties
        }
        toastOptions={{
          classNames: {
            toast: "cn-toast",
          },
        }}
        {...props}
      />
    </div>
  );
};

export { Toaster };
