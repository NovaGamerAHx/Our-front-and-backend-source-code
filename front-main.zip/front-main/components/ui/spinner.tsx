import { cn } from "@/lib/utils";

/**
 * Design System §4 — inline loading spinner for buttons that call an API.
 * A 16px ring: 2px track at ~30% of the current text color, solid head in the
 * current color, 0.7s linear spin. Sits before the (unchanged) button label,
 * so `gap` on the button is what separates them.
 */
export function Spinner({ className }: { className?: string }) {
  return <span role="status" aria-label="در حال بارگذاری" className={cn("fm-spinner", className)} />;
}
