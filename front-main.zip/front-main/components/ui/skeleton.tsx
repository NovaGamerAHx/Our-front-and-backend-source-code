import { cn } from "@/lib/utils";

function Skeleton({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="skeleton"
      className={cn("bg-muted animate-pulse rounded-md", className)}
      {...props}
    />
  );
}

/**
 * Edge States §e4/e9 shimmer block — the placeholder shape used in every route's
 * `loading.tsx`. Pass width/height/radius via `className` (e.g. `h-16 w-full rounded-2xl`).
 */
function Sk({ className, ...props }: React.ComponentProps<"div">) {
  return <div aria-hidden className={cn("fm-sk", className)} {...props} />;
}

export { Skeleton, Sk };
