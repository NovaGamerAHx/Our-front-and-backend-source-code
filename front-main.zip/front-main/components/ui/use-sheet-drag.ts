"use client";

import { useEffect, useRef, useState, type CSSProperties, type PointerEvent as ReactPointerEvent } from "react";

/** Movement (px) before a pointer-down turns into a drag -- keeps taps/clicks working. */
const DRAG_SLOP = 6;
/** Drag far enough, or flick fast enough, and the sheet closes instead of snapping back. */
const CLOSE_DISTANCE = 96;
const CLOSE_VELOCITY = 0.5; // px per ms
const FLICK_MIN_DISTANCE = 24;
/** Matches the slide-out transition below, so onClose fires once the sheet is off-screen. */
const CLOSE_MS = 180;

/**
 * Drag-to-dismiss for the bottom sheets (the grab handle at the top of each one is the
 * affordance for it). Downward drags follow the finger; releasing past the threshold slides
 * the sheet out and then calls `onClose`.
 *
 * `handleProps` goes on the grab handle (always draggable), `sheetProps` + `sheetRef` +
 * `sheetStyle` on the sheet itself, which also picks up drags that start on plain content --
 * but not on form controls, and not while the sheet's own content is scrolled down.
 */
export function useSheetDrag<T extends HTMLElement = HTMLDivElement>(onClose: () => void) {
  const sheetRef = useRef<T | null>(null);
  const startRef = useRef<{ y: number; t: number } | null>(null);
  const draggingRef = useRef(false);
  const [offset, setOffset] = useState(0);
  const [closing, setClosing] = useState(false);
  /** Mirrors `draggingRef` for rendering -- the ref is what the handlers read synchronously. */
  const [dragging, setDragging] = useState(false);
  const onCloseRef = useRef(onClose);
  useEffect(() => {
    onCloseRef.current = onClose;
  });

  // Set by prepareForNavigation() when a button is about to route away (e.g. "دیدن قدم‌هایم").
  // router.push/replace only writes window.history in a post-commit effect, so for a dynamic
  // destination it lands well after this hook's own unmount cleanup -- meaning the cleanup would
  // still see fmSheet on top and fire history.back(), whose popstate cancels the in-flight
  // navigation and strands the user. This flag tells the cleanup to leave history alone and let
  // the navigation (a router.replace, which overwrites our throwaway entry) settle it.
  const navigatingRef = useRef(false);

  // Claims the back gesture (hardware/browser back button, swipe-back) for the sheet instead of
  // letting it navigate the page underneath -- pushing a throwaway history entry means popping
  // it (popstate) closes the sheet rather than leaving wherever it was opened from.
  useEffect(() => {
    window.history.pushState({ fmSheet: true }, "");
    function onPopState() {
      onCloseRef.current();
    }
    window.addEventListener("popstate", onPopState);
    return () => {
      window.removeEventListener("popstate", onPopState);
      // Closed some other way (drag, backdrop tap, a button) while our entry is still on top --
      // consume it so it doesn't linger as a dead entry the next back-press has to eat through.
      // Skipped when a button is routing away (navigatingRef) -- see the note above.
      if (!navigatingRef.current && window.history.state?.fmSheet) window.history.back();
    };
  }, []);

  function onHandlePointerDown(e: ReactPointerEvent) {
    if (closing) return;
    startRef.current = { y: e.clientY, t: e.timeStamp };
    draggingRef.current = true;
    setDragging(true);
    e.currentTarget.setPointerCapture(e.pointerId);
  }

  function onSheetPointerDown(e: ReactPointerEvent) {
    if (closing || draggingRef.current || startRef.current) return;
    const target = e.target as HTMLElement;
    if (target.closest("input,textarea,select,button,a,[data-no-sheet-drag]")) return;
    if (scrolledDown(target, sheetRef.current)) return;
    startRef.current = { y: e.clientY, t: e.timeStamp };
  }

  function onPointerMove(e: ReactPointerEvent) {
    const start = startRef.current;
    if (!start || closing) return;
    const dy = e.clientY - start.y;
    if (!draggingRef.current) {
      if (dy < DRAG_SLOP) return;
      draggingRef.current = true;
      setDragging(true);
      e.currentTarget.setPointerCapture(e.pointerId);
    }
    setOffset(Math.max(0, dy));
  }

  function onPointerUp(e: ReactPointerEvent) {
    const start = startRef.current;
    const wasDragging = draggingRef.current;
    startRef.current = null;
    draggingRef.current = false;
    setDragging(false);
    if (!start || !wasDragging || closing) {
      setOffset(0);
      return;
    }
    const dy = Math.max(0, e.clientY - start.y);
    const velocity = dy / Math.max(1, e.timeStamp - start.t);
    if (dy > CLOSE_DISTANCE || (dy > FLICK_MIN_DISTANCE && velocity > CLOSE_VELOCITY)) {
      setClosing(true);
      setOffset(sheetRef.current?.offsetHeight ?? window.innerHeight);
      window.setTimeout(onClose, CLOSE_MS);
      return;
    }
    setOffset(0);
  }

  function onPointerCancel() {
    if (closing) return;
    startRef.current = null;
    draggingRef.current = false;
    setDragging(false);
    setOffset(0);
  }

  const moving = offset > 0 || closing;
  const sheetStyle: CSSProperties = moving
    ? {
        transform: `translateY(${offset}px)`,
        // The entry keyframes animate transform too -- drop them once the finger owns it.
        animation: "none",
        transition: dragging ? "none" : `transform ${CLOSE_MS}ms cubic-bezier(.2,.8,.2,1)`,
        overscrollBehavior: "contain",
      }
    : { overscrollBehavior: "contain" };

  return {
    sheetRef,
    sheetStyle,
    /** Call right before router.push/replace in a button handler that navigates away, so the
     * unmount cleanup doesn't pop its history entry out from under the pending navigation. */
    prepareForNavigation: () => {
      navigatingRef.current = true;
    },
    sheetProps: {
      onPointerDown: onSheetPointerDown,
      onPointerMove,
      onPointerUp,
      onPointerCancel,
    },
    handleProps: {
      onPointerDown: onHandlePointerDown,
      // Without this the browser claims the vertical gesture and cancels the drag.
      style: { touchAction: "none" } as CSSProperties,
    },
  };
}

/** True when the pointer is inside anything (the sheet itself included) that is scrolled down --
 * there a downward drag belongs to that scroller, not to the sheet. */
function scrolledDown(target: HTMLElement, sheet: HTMLElement | null): boolean {
  for (let el: HTMLElement | null = target; el; el = el.parentElement) {
    if (el.scrollTop > 0) return true;
    if (el === sheet) break;
  }
  return false;
}
