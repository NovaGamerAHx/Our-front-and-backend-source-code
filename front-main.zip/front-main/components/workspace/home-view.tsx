import Link from "next/link";
import { ChevronLeft, FileText } from "lucide-react";
import {
  getWorkspaceData,
  getCanonicalContext,
  reportChatHref,
  reportHref,
} from "@/lib/workspace/data";
import { getPreStart } from "@/lib/api/endpoints";
import { DEEP_ASSESSMENT_SLUG, SELF_KNOWLEDGE_ASSESSMENT_SLUG } from "@/lib/api/constants";
import { formatJalali } from "@/lib/utils/date";
import { toPersianDigits } from "@/lib/utils/digits";
import type { ReportAttemptHistoryItem } from "@/lib/api/schemas";
import { HomeComposer } from "./home-composer";
import { ReportInsight } from "./report-insight";
import { CHAT_SUGGESTED_PROMPTS } from "@/lib/chat/prompts";

function latestPendingAttempt(history: ReportAttemptHistoryItem[]): ReportAttemptHistoryItem | undefined {
  const sorted = [...history].sort(
    (a, b) => new Date(b.completed_at).getTime() - new Date(a.completed_at).getTime(),
  );
  const seenTypes = new Set<string>();
  for (const item of sorted) {
    if (seenTypes.has(item.report_type)) continue;
    seenTypes.add(item.report_type);
    if (item.status !== "ok") return item;
  }
  return undefined;
}

export async function WorkspaceHome() {
  const [data, context, deep, initial] = await Promise.all([
    getWorkspaceData(),
    getCanonicalContext(),
    getPreStart(DEEP_ASSESSMENT_SLUG).catch(() => null),
    getPreStart(SELF_KNOWLEDGE_ASSESSMENT_SLUG).catch(() => null),
  ]);
  const recent = data.sessions.find((s) => s.preview);
  const report = context?.report;
  const finding = report?.findings[0];

  const completedReports = [...data.history]
    .filter((h) => h.status === "ok")
    .sort((a, b) => new Date(b.completed_at).getTime() - new Date(a.completed_at).getTime());

  // Completed assessments with generated reports take priority over in-progress attempts.
  const hasCompletedReports = completedReports.length > 0;
  const inProgress = hasCompletedReports
    ? null
    : deep?.has_in_progress_attempt
      ? { title: "آزمون خودشناسی عمیق", href: "/deep-test/questions", pre: deep }
      : initial?.has_in_progress_attempt
        ? { title: "آزمون خودشناسی اولیه", href: "/test/questions", pre: initial }
        : null;
  const pending = hasCompletedReports ? undefined : latestPendingAttempt(data.history);
  const activeWork =
    inProgress ||
    (pending
      ? {
          title:
            pending.status === "awaiting_payment"
              ? "پاسخ‌هایت آماده است"
              : pending.status === "generating"
                ? "گزارشت در حال ساخته شدن است"
                : "ساخت گزارشت نیاز به بررسی دارد",
          href: reportHref(pending),
          pre: null,
        }
      : null);
  const reportHistory =
    (report ? completedReports.find((h) => h.attempt_id === report.attempt_id) : undefined) ??
    completedReports[0];
  const fresh = !hasCompletedReports && !data.history.length && !data.historyUnavailable && !inProgress;

  return (
    <main className="fm-home-page">
      <div className="fm-home-grid">
        <section className="fm-home-hero fm-gradient">
          <div>
            <p className="fm-greeting">سلام {data.profile?.name || "دوست من"}</p>
            <h1>امروز از چه چیزی حرف بزنیم؟</h1>
          </div>
          <HomeComposer />
          <div className="fm-home-prompts">
            {reportHistory && (
              <Link href={reportChatHref(reportHistory, "درباره‌ی گزارشم حرف بزنیم", "/")}>
                درباره‌ی گزارشم حرف بزنیم
              </Link>
            )}
            {CHAT_SUGGESTED_PROMPTS.map((text) => (
              <Link
                key={text}
                href={`/chat?${new URLSearchParams({ initial_message: text, from: "/" })}`}
              >
                {text}
              </Link>
            ))}
          </div>
        </section>
        <div className="fm-home-cards">
          {recent && (
            <Link
              className="fm-card fm-resume-card"
              href={`/chat?${new URLSearchParams({ session_id: recent.session_id, from: "/" })}`}
            >
              <small>
                از همان‌جا ادامه بدهیم
                {recent.last_message_at ? ` · ${formatJalali(recent.last_message_at, "D MMMM")}` : ""}
              </small>
              <p>
                <strong>{recent.preview}</strong>
              </p>
              <span className="fm-button fm-soft fm-resume-cta">ادامه بدهیم</span>
            </Link>
          )}
          {finding && report && (
            <ReportInsight
              key={`${report.attempt_id}:${finding.key}`}
              attemptId={report.attempt_id}
              reportType={report.report_type}
              finding={finding}
              href={`/chat?${new URLSearchParams({
                entry_source: report.report_type === "deep" ? "deep_report_context" : "report_context",
                attempt_id: String(report.attempt_id),
                from: "/",
                initial_message: `درباره‌ی این برداشت گزارشم حرف بزنیم: ${finding.text}`,
              })}`}
            />
          )}
          {completedReports.map((item) => (
            <Link
              key={item.attempt_id}
              className="fm-card fm-row fm-latest-report"
              href={reportHref(item)}
            >
              <span className="fm-icon purple">
                <FileText size={20} />
              </span>
              <span>
                <strong>گزارش {item.report_type === "deep" ? "عمیق" : "اولیه"}</strong>
                <small>{formatJalali(item.completed_at)}</small>
              </span>
              <ChevronLeft size={18} />
            </Link>
          ))}
          {activeWork ? (
            <section className="fm-card">
              <h2>{activeWork.title}</h2>
              {activeWork.pre && (
                <p>
                  {activeWork.pre.answered_count != null && activeWork.pre.total_questions != null
                    ? `${toPersianDigits(activeWork.pre.answered_count)} از ${toPersianDigits(activeWork.pre.total_questions)} پاسخ`
                    : "پاسخ‌های قبلی‌ات ذخیره شده‌اند."}
                </p>
              )}
              <Link className="fm-button" href={activeWork.href}>
                {activeWork.pre ? "ادامه‌ی آزمون" : "ادامه‌ی ساخت گزارش"}
              </Link>
            </section>
          ) : fresh ? (
            <section className="fm-card fm-new-user">
              <h2>آزمون خودشناسی اولیه</h2>
              <p>۳۰ جمله · حدود ۱۰ دقیقه · رایگان</p>
              <p>گفت‌وگو درباره‌ی نتیجه با فرامن</p>
              <Link href="/test" className="fm-button">
                شروع آزمون خودشناسی اولیه
              </Link>
            </section>
          ) : null}
          {data.historyUnavailable && (
            <p role="status">
              گزارش‌ها فعلاً دریافت نشدند. <Link href="/explore">تلاش دوباره</Link>
            </p>
          )}
        </div>
      </div>
    </main>
  );
}
