import Link from "next/link";
import {
  getWorkspaceData,
  getCanonicalContext,
  reportChatHref,
  reportHref,
} from "@/lib/workspace/data";
import { getPreStart } from "@/lib/api/endpoints";
import { DEEP_ASSESSMENT_SLUG, SELF_KNOWLEDGE_ASSESSMENT_SLUG } from "@/lib/api/constants";
import { HomeComposer } from "./home-composer";
import { ReportInsight } from "./report-insight";
import { CHAT_SUGGESTED_PROMPTS } from "@/lib/chat/prompts";
export async function WorkspaceHome() {
  const [data, context, deep, initial] = await Promise.all([
    getWorkspaceData(),
    getCanonicalContext(),
    getPreStart(DEEP_ASSESSMENT_SLUG).catch(() => null),
    getPreStart(SELF_KNOWLEDGE_ASSESSMENT_SLUG).catch(() => null),
  ]);
  const recent = data.sessions.find((s) => s.preview);
  const report = context?.report;
  const finding = report?.findings[0];
  const inProgress = deep?.has_in_progress_attempt
    ? { title: "آزمون خودشناسی عمیق", href: "/deep-test/questions", pre: deep }
    : initial?.has_in_progress_attempt
      ? { title: "آزمون خودشناسی اولیه", href: "/test/questions", pre: initial }
      : null;
  const pending = data.history.find((h) => h.status !== "ok");
  const activeWork =
    inProgress ||
    (pending
      ? {
          title:
            pending.status === "awaiting_payment"
              ? "پاسخ‌هایت آماده است"
              : pending.status === "generating"
                ? "گزارشت در حال ساخته شدن است"
                : "ساخت گزارشت نیاز به بررسی دارد",
          href: reportHref(pending),
          pre: null,
        }
      : null);
  const reportHistory = report
    ? data.history.find((h) => h.attempt_id === report.attempt_id)
    : undefined;
  const fresh = !data.history.length && !data.historyUnavailable && !inProgress;
  return (
    <main className="fm-home-page">
      <div className="fm-home-grid">
        <section className="fm-home-hero fm-gradient">
          <div>
            <p className="fm-greeting">سلام {data.profile?.name || "دوست من"}</p>
            <h1>امروز از چه چیزی حرف بزنیم؟</h1>
          </div>
          <HomeComposer />
          <div className="fm-home-prompts">
            {reportHistory && (
              <Link href={reportChatHref(reportHistory)}>درباره‌ی گزارشم حرف بزنیم</Link>
            )}
            {CHAT_SUGGESTED_PROMPTS.map((text) => (
              <Link
                key={text}
                href={`/chat?${new URLSearchParams({ initial_message: text, from: "/" })}`}
              >
                {text}
              </Link>
            ))}
          </div>
        </section>
        <div className="fm-home-cards">
          {recent && (
            <Link className="fm-card fm-resume-card" href={`/chat?session_id=${recent.session_id}`}>
              <small>از همان‌جا ادامه بدهیم</small>
              <p>
                <strong>{recent.preview}</strong>
              </p>
              <span className="fm-button fm-soft fm-resume-cta">ادامه بدهیم</span>
            </Link>
          )}
          {activeWork ? (
            <section className="fm-card">
              <h2>{activeWork.title}</h2>
              {activeWork.pre && (
                <p>
                  {activeWork.pre.answered_count != null
                    ? `${activeWork.pre.answered_count} از ${activeWork.pre.total_questions} پاسخ`
                    : "پاسخ‌های قبلی‌ات ذخیره شده‌اند."}
                </p>
              )}
              <Link className="fm-button" href={activeWork.href}>
                {activeWork.pre ? "ادامه‌ی آزمون" : "ادامه‌ی ساخت گزارش"}
              </Link>
            </section>
          ) : finding && report && reportHistory ? (
            <ReportInsight
              attemptId={report.attempt_id}
              finding={finding}
              href={reportChatHref(
                reportHistory,
                `درباره‌ی این برداشت گزارشم حرف بزنیم: ${finding.text}`,
              ).replace("report_cta", "report_context")}
            />
          ) : fresh ? (
            <section className="fm-card fm-new-user">
              <h2>آزمون خودشناسی اولیه</h2>
              <p>۳۰ جمله · حدود ۱۰ دقیقه · رایگان</p>
              <p>گفت‌وگو درباره‌ی نتیجه با فرامن</p>
              <Link href="/test" className="fm-button">
                شروع آزمون خودشناسی اولیه
              </Link>
            </section>
          ) : null}
          {data.historyUnavailable && (
            <p role="status">
              گزارش‌ها فعلاً دریافت نشدند. <Link href="/explore">تلاش دوباره</Link>
            </p>
          )}
        </div>
      </div>
    </main>
  );
}
