import { BackLink } from "@/components/site/back-navigation";
import Image from "next/image";
import Link from "next/link";
import {
  ArrowLeft,
  Compass,
  Layers,
  MessageCircle,
  Sprout,
  Sparkles,
  Heart,
  Clock3,
  PauseCircle,
} from "lucide-react";
import { TrackedLink } from "@/components/analytics/tracked-link";
export const DEEP_BENEFITS = [
  {
    icon: Layers,
    title: "۳۰ ویژگی شخصیتی",
    text: "از نظم و اضطراب تا کنجکاوی و صراحت",
    color: "purple",
  },
  {
    icon: Compass,
    title: "سبک تو در زندگی روزمره",
    text: "تصمیم‌گیری، ارتباط، کار، استرس و رابطه‌ها",
    color: "orange",
  },
  {
    icon: Sprout,
    title: "نقطه‌های قوت و چیزهایی که کمتر می‌بینی",
    text: "آنچه به آن تکیه می‌کنی و آنچه کمتر به آن نگاه می‌کنی",
    color: "green",
  },
  {
    icon: MessageCircle,
    title: "گفت‌وگو با فرامن، با گزارش عمیقت",
    text: "فرامن در گفت‌وگوها از گزارش عمیقت کمک می‌گیرد",
    color: "blue",
  },
];
export function DeepBenefits() {
  return (
    <div className="fm-benefits">
      {DEEP_BENEFITS.map(({ icon: Icon, title, text, color }) => (
        <div key={title} className="fm-benefit">
          <span className={`fm-icon ${color}`}>
            <Icon size={23} />
          </span>
          <div>
            <h3>{title}</h3>
            <p>{text}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
export function DeepIntro({
  capped,
  source,
  entry = false,
  hasInProgress = false,
}: {
  capped: boolean;
  source: string;
  entry?: boolean;
  hasInProgress?: boolean;
}) {
  const href = entry
    ? `/deep-test?source=${encodeURIComponent(source)}`
    : `/deep-test/questions?source=${encodeURIComponent(source)}`;
  return (
    <main className="fm-page fm-deep-intro">
      <BackLink className="fm-intro-back" href="/explore">
        → <span>آزمون خودشناسی عمیق</span>
      </BackLink>
      <div className="fm-breadcrumb">
        <Link href="/explore">خودشناسی</Link>
        <span>/</span>آزمون خودشناسی عمیق
      </div>
      <section className="fm-deep-hero">
        <div className="fm-deep-intro-copy">
          <h1>
            چیزی که از خودت شناختی،
            <br />
            فقط شروع ماجراست.
          </h1>
          <div className="fm-intro-facts">
            <span>
              <Layers size={17} />
              ۳۰ کارت پنج‌سؤالی
            </span>
            <span>
              <Clock3 size={17} />
              حدود ۲۵ دقیقه
            </span>
            <span>
              <PauseCircle size={17} />
              هر جا خواستی توقف کن
            </span>
          </div>
          <div className="fm-answer-guide">
            <strong>راهنمای جواب دادن</strong>
            <p>
              بر اساس اینکه هر جمله در چند ماه اخیر و در بیشتر موقعیت‌ها چقدر تو را توصیف می‌کند
              جواب بده، نه بر اساس اینکه دوست داری چطور باشی.
            </p>
            <p className="fm-desktop-only">جواب درست و غلط ندارد.</p>
          </div>
          {capped ? (
            <>
              <p role="status" className="fm-muted">
                امروز به سقف آزمون‌های تازه رسیده‌ای. فردا دوباره تلاش کن.
              </p>
              <button className="fm-button" disabled>
                شروع کارت اول
              </button>
            </>
          ) : (
            <Link className="fm-button fm-intro-start" href={href}>
              {hasInProgress ? "ادامهٔ آزمون" : "شروع کارت اول"}
              <ArrowLeft size={19} />
            </Link>
          )}
        </div>
        <div className="fm-deep-intro-art">
          <Image
            src="/workspace-art/deep.jpg"
            alt="تصویرسازی مسیر خودشناسی"
            width={560}
            height={560}
            priority
          />
        </div>
      </section>
      <section className="fm-deep-benefits-section">
        <h2>
          <span className="fm-desktop-label">در گزارش عمیق چه می‌بینی</span>
          <span className="fm-mobile-label">در گزارش عمیق</span>
        </h2>
        <div className="fm-intro-benefits-card">
          <div className="fm-demo-radar">
            <svg
              viewBox="0 0 200 200"
              width="150"
              height="150"
              role="img"
              aria-label="نمونه‌ی نمودار پنج بُعد؛ نتیجه‌ی تو نیست"
            >
              <polygon
                fill="#F6F4FC"
                points="100,20 176.1,75.3 147,164.7 53,164.7 23.9,75.3"
                stroke="#E2DDEE"
                strokeWidth="1.5"
              />
              <polygon
                fill="none"
                points="100,47 150.4,83.6 131.2,142.9 68.8,142.9 49.6,83.6"
                stroke="#ECE8F3"
              />
              <polygon
                fill="none"
                points="100,73 125.7,91.7 115.9,121.8 84.1,121.8 74.3,91.7"
                stroke="#ECE8F3"
              />
              <polygon
                fill="#2F44C2"
                fillOpacity=".16"
                points="100,32 153.3,82.7 128.2,138.8 64.7,148.5 58.2,86.4"
                stroke="#2F44C2"
                strokeLinejoin="round"
                strokeWidth="2.5"
              />
              <circle cx="100" cy="32" fill="#8A63B8" r="6" />
              <circle cx="153.3" cy="82.7" fill="#3F7FD4" r="6" />
              <circle cx="128.2" cy="138.8" fill="#D9893A" r="6" />
              <circle cx="64.7" cy="148.5" fill="#D9534F" r="6" />
              <circle cx="58.2" cy="86.4" fill="#4F8F5C" r="6" />
            </svg>
          </div>
          <DeepBenefits />
        </div>
      </section>
      <section className="fm-intro-samples">
        <div className="fm-card fm-report-sample">
          <h2>نمونه‌ی گزارش عمیق</h2>
          {[
            { t: "ویژگی‌های شخصیتی", i: Sparkles, c: "purple" },
            { t: "سبک ارتباطی", i: MessageCircle, c: "blue" },
            { t: "سبک تصمیم‌گیری", i: Compass, c: "orange" },
            { t: "مدیریت احساسات", i: Heart, c: "pink" },
            { t: "سبک زندگی", i: Sprout, c: "green" },
          ].map(({ t, i: Icon, c }) => (
            <div className={`fm-sample-topic ${c}`} key={t}>
              <Icon size={20} />
              {t}
              <ArrowLeft size={16} />
            </div>
          ))}
        </div>
        <div className="fm-card fm-chat-sample">
          <h2>گفت‌وگو با فرامن درباره‌ی گزارشت</h2>
          <p className="fm-muted">
            بعد از گرفتن گزارش، هر سؤالی درباره‌ی نتیجه‌هایت داری از فرامن بپرس.
          </p>
          <span className="fm-demo-user">چرا وقتی تحت فشارم بد تصمیم می‌گیرم؟</span>
          <span className="fm-demo-ai">آخرین بار کی این‌طوری شد؟</span>
        </div>
      </section>
      <section className="fm-how">
        <h2>چطور پیش می‌رود</h2>
        <ol>
          {[
            "به ۳۰ کارت جواب می‌دهی",
            "گزارش عمیقت ساخته می‌شود",
            "درباره‌اش با فرامن حرف می‌زنی",
          ].map((t) => (
            <li key={t}>{t}</li>
          ))}
        </ol>
      </section>
    </main>
  );
}
export function FreeIntro({
  nextHref,
  capped,
  hasInProgress,
  lastResult,
  guest = false,
}: {
  nextHref: string;
  capped: boolean;
  hasInProgress: boolean;
  lastResult: { attemptId: number; completedAt: string } | null;
  guest?: boolean;
}) {
  return (
    <main className={`fm-page fm-free-intro ${guest ? "fm-guest-free-intro" : ""}`}>
      <BackLink href="/explore" className="fm-back">
        → <span>آزمون خودشناسی اولیه</span>
      </BackLink>
      <div className="fm-free-hero">
        <div className="fm-free-art-wrap">
          <Image
            className="fm-free-art"
            src="/workspace-art/initial.jpg"
            alt="تصویرسازی شناخت خود در آینه"
            width={1120}
            height={630}
            priority
          />
          <span className="fm-free-art-badge">آزمون خودشناسی اولیه</span>
        </div>
        <div className="fm-free-copy">
          <span className="fm-eyebrow">آزمون خودشناسی اولیه · رایگان</span>
          <h1>چقدر خودت را می‌شناسی؟</h1>
          <p>
            به ۳۰ جمله‌ی کوتاه جواب بده تا ببینی کجا قوی هستی و کجا معمولاً گیر می‌کنی. بعد می‌توانی
            درباره‌اش با فرامن حرف بزنی.
          </p>
          {guest ? (
            <div className="fm-free-facts">
              <span>۳۰ جمله</span>
              <span>حدود ۱۰ دقیقه</span>
              <span>بدون ثبت‌نام</span>
            </div>
          ) : (
            <small className="fm-muted">۳۰ جمله · حدود ۱۰ دقیقه</small>
          )}
          {capped ? (
            <>
              <p role="status">آزمون‌های امروزت تمام شده. فردا می‌توانی دوباره شروع کنی.</p>
              <div className="fm-free-cta-row">
                {lastResult && (
                  <Link className="fm-button" href={`/report?attemptId=${lastResult.attemptId}`}>
                    دیدن آخرین گزارش
                    <ArrowLeft size={18} />
                  </Link>
                )}
                <button className={`fm-button ${lastResult ? "fm-outline" : ""}`} disabled>
                  شروع آزمون خودشناسی اولیه
                </button>
              </div>
            </>
          ) : lastResult ? (
            <div className="fm-free-cta-row">
              <Link className="fm-button" href={`/report?attemptId=${lastResult.attemptId}`}>
                دیدن آخرین گزارش
                <ArrowLeft size={18} />
              </Link>
              <TrackedLink
                event="test_intro_start_clicked"
                href={nextHref}
                className="fm-button fm-outline"
              >
                {hasInProgress ? "ادامه‌ی آزمون تازه" : "شروع آزمون تازه"}
              </TrackedLink>
            </div>
          ) : (
            <TrackedLink event="test_intro_start_clicked" href={nextHref} className="fm-button">
              {hasInProgress ? "ادامه‌ی آزمون" : "شروع آزمون خودشناسی اولیه"}
              <ArrowLeft size={18} />
            </TrackedLink>
          )}
        </div>
      </div>
      <section className="fm-free-outcomes">
        <h2>{guest ? "بعد از آزمون چه می‌بینی" : "بعد از آزمون"}</h2>
        <div className="fm-free-outcomes-list">
          {[
            {
              t: "نقطه‌های قوتت",
              d: "سه چیزی که واقعاً در آن خوبی، و اینکه کجا به کارت می‌آیند.",
              i: Sparkles,
              c: "purple",
            },
            {
              t: "جاهایی که گیر می‌کنی",
              d: "الگوهایی که معمولاً جلوی پیشرفتت را می‌گیرند.",
              i: Compass,
              c: "orange",
            },
            {
              t: "گفت‌وگو درباره‌ی نتیجه با فرامن",
              d: "هر جای نتیجه که برایت سؤال بود، با فرامن درباره‌اش حرف بزن.",
              i: MessageCircle,
              c: "blue",
            },
          ].map(({ t, d, i: Icon, c }) => (
            <div className="fm-benefit" key={t}>
              <span className={`fm-icon ${c}`}>
                <Icon size={22} />
              </span>
              <div>
                <h3>{t}</h3>
                <p>{d}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
      <div className="fm-answer-guide">
        <strong>لازم نیست آماده باشی، فقط صادق باش.</strong>
        <p>جواب درست و غلط ندارد. هر جمله را با اولین حسی که داری جواب بده.</p>
      </div>
      <p className="fm-privacy">
        جواب‌هایت فقط برای ساختن گزارش خودت استفاده می‌شود و هر وقت بخواهی پاک می‌شود.
      </p>
    </main>
  );
}
