"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Send } from "lucide-react";
export function HomeComposer() {
  const [message, setMessage] = useState("");
  const router = useRouter();
  function submit() {
    if (message.trim())
      router.push(`/chat?${new URLSearchParams({ initial_message: message.trim(), from: "/" })}`);
  }
  return (
    <form
      className="fm-home-composer"
      onSubmit={(e) => {
        e.preventDefault();
        submit();
      }}
    >
      <label className="sr-only" htmlFor="fm-home-message">
        پیام
      </label>
      <textarea
        id="fm-home-message"
        rows={3}
        maxLength={2000}
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="هر چه در ذهنت هست بنویس…"
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
            e.preventDefault();
            submit();
          }
        }}
      />
      <button className="fm-send" type="submit" disabled={!message.trim()} aria-label="فرستادن">
        <Send size={23} style={{ transform: "rotate(-90deg)" }} />
      </button>
    </form>
  );
}
