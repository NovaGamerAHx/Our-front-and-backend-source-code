"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { Menu, X } from "lucide-react";
import { LogoMark } from "@/components/site/logo-mark";
import { SiteFooter } from "@/components/site/site-footer";

const SELF_KNOWLEDGE_PATHS = [
  "/explore",
  "/test",
  "/test/resume",
  "/deep-test",
  "/paywall",
  "/report",
  "/report/feedback",
  "/deep-report",
  "/preview",
];

export function PublicChrome({
  children,
  overlay = false,
  showFooter = false,
}: {
  children: React.ReactNode;
  overlay?: boolean;
  showFooter?: boolean;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    if (!overlay) return;
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [overlay]);

  useEffect(() => {
    if (!menuOpen) return;
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") setMenuOpen(false);
    }
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [menuOpen]);

  function handleLoginClick(e: React.MouseEvent<HTMLAnchorElement>) {
    e.preventDefault();
    setMenuOpen(false);
    const current = `${window.location.pathname}${window.location.search}`;
    router.push(current && current !== "/" ? `/login?next=${encodeURIComponent(current)}` : "/login");
  }

  function isActive(href: string) {
    if (href === "/explore") return SELF_KNOWLEDGE_PATHS.includes(pathname);
    return pathname === href || pathname.startsWith(`${href}/`);
  }

  const navItems = [
    { href: "/explore", label: "خودشناسی", requiresLogin: false },
    { href: "/login?next=%2Fchat", label: "گفت‌وگو", requiresLogin: true },
    { href: "/blog", label: "فرابلاگ", requiresLogin: false },
    { href: "/about", label: "درباره‌ی فرامن", requiresLogin: false },
  ] as const;

  const headerClassName = [
    "fm-public-header",
    "fm-legacy-chrome",
    overlay ? "fm-public-header-overlay" : "",
    overlay && scrolled ? "is-scrolled" : "",
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <div className={`fm-workspace fm-public-workspace ${overlay ? "fm-public-overlay-root" : ""}`}>
      <header className={headerClassName}>
        <div className="fm-public-header-inner">
          <div className="fm-public-brand-group">
            <Link href="/" className="fm-brand" onClick={() => setMenuOpen(false)}>
              <LogoMark height={34} />
              <span>فرامن</span>
            </Link>
            <nav className="fm-public-nav" aria-label="منوی سایت">
              {navItems.map((item) => {
                const active = !item.requiresLogin && isActive(item.href);
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    aria-current={active ? "page" : undefined}
                    className={active ? "is-active" : ""}
                  >
                    {item.label}
                  </Link>
                );
              })}
            </nav>
          </div>
          <div className="fm-public-actions">
            <Link href="/login" onClick={handleLoginClick} className="fm-public-login">
              ورود
            </Link>
            <button
              type="button"
              aria-label="منو"
              aria-expanded={menuOpen}
              onClick={() => setMenuOpen(true)}
              className="fm-public-menu-btn"
            >
              <Menu size={22} strokeWidth={2} />
            </button>
          </div>
        </div>
      </header>

      {menuOpen && (
        <div
          className="fm-public-drawer fm-legacy-chrome"
          role="dialog"
          aria-modal="true"
          aria-label="منوی سایت"
        >
          <div className="fm-public-drawer-top">
            <Link href="/" className="fm-brand" onClick={() => setMenuOpen(false)}>
              <LogoMark height={30} />
              <span>فرامن</span>
            </Link>
            <button
              type="button"
              aria-label="بستن منو"
              onClick={() => setMenuOpen(false)}
              className="fm-public-menu-btn"
            >
              <X size={22} strokeWidth={2} />
            </button>
          </div>

          <nav className="fm-public-drawer-card" aria-label="منوی موبایل">
            {navItems.map((item) => {
              const active = !item.requiresLogin && isActive(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMenuOpen(false)}
                  aria-current={active ? "page" : undefined}
                  className={active ? "is-active" : ""}
                >
                  <span>{item.label}</span>
                  {item.requiresLogin && <small>با ورود</small>}
                </Link>
              );
            })}
          </nav>

          <Link href="/login" onClick={handleLoginClick} className="fm-public-drawer-cta">
            ورود
          </Link>
        </div>
      )}

      <div className="fm-workspace-body">{children}</div>
      {showFooter && (
        <div className="fm-legacy-chrome">
          <SiteFooter />
        </div>
      )}
    </div>
  );
}
