import { ReportRadar } from "./report-radar";
import Image from "next/image";
import Link from "next/link";
import { FileText, ChevronLeft, Layers, CircleAlert } from "lucide-react";
import {
  getWorkspaceData,
  getWorkspaceReport,
  reportChatHref,
  reportHref,
  getCanonicalContext,
} from "@/lib/workspace/data";
import { getPreStart } from "@/lib/api/endpoints";
import { DEEP_ASSESSMENT_SLUG, SELF_KNOWLEDGE_ASSESSMENT_SLUG } from "@/lib/api/constants";
import { formatJalali } from "@/lib/utils/date";
import { toPersianDigits } from "@/lib/utils/digits";
import type {
  ReportAttemptHistoryItem,
  PreStartResponse,
  ReportResult,
} from "@/lib/api/schemas";

const TOPICS = ["ویژگی‌های شخصیتی", "سبک ارتباطی", "سبک تصمیم‌گیری", "مدیریت احساسات", "سبک زندگی"];

const INITIAL_DOMAIN_TITLES: Record<string, string> = {
  emotional_stability: "ثبات هیجانی",
  extraversion: "برون‌گرایی",
  openness: "گشودگی",
  agreeableness: "همراهی",
  conscientiousness: "وظیفه‌شناسی",
};

function extractRadarDomains(
  reportResponse: ReportResult | null,
): { code: string; title: string; score: number }[] {
  if (
    !reportResponse ||
    reportResponse.status !== "ok" ||
    !("dimension_scores" in reportResponse)
  ) {
    return [];
  }
  const keys: string[] = [
    "emotional_stability",
    "extraversion",
    "openness",
    "agreeableness",
    "conscientiousness",
  ];
  const scores = keys
    .map((key) => {
      const entry = reportResponse.dimension_scores.find((d) => d.key === key);
      if (!entry || typeof entry.score_percent !== "number") return null;
      return { code: key, title: INITIAL_DOMAIN_TITLES[key] ?? key, score: entry.score_percent };
    })
    .filter((x): x is { code: string; title: string; score: number } => x !== null);
  return scores.length === 5 ? scores : [];
}

export async function PublicSelfKnowledgeView() {
  const freeStart = await getPreStart(SELF_KNOWLEDGE_ASSESSMENT_SLUG).catch(() => null);
  const inProgress = Boolean(freeStart?.has_in_progress_attempt);
  const initialState = inProgress
    ? freeStart?.answered_count != null && freeStart?.total_questions != null
      ? `${toPersianDigits(freeStart.answered_count)} از ${toPersianDigits(freeStart.total_questions)}`
      : "در حال انجام"
    : "رایگان · بدون ثبت‌نام";
  const initialHref = inProgress
    ? "/test/questions"
    : freeStart?.has_previous_report
      ? "/test/resume"
      : "/test";
  const initialLabel = inProgress ? "ادامه‌ی آزمون" : "شروع آزمون";

  return (
    <main className="fm-page fm-self-page">
      <header className="fm-page-title">
        <h1>خودشناسی</h1>
        <p>دو آزمون، برای اینکه خودت را بهتر بشناسی.</p>
      </header>
      <section>
        <div className="fm-section-heading">
          <h2>آزمون‌ها</h2>
        </div>
        <div className="fm-test-grid">
          <article className="fm-test-card">
            <div className="fm-test-art">
              <Image src="/workspace-art/initial.jpg" alt="" width={560} height={300} />
              <span className="fm-test-badge">{initialState}</span>
            </div>
            <div className="fm-test-copy">
              <Image
                className="fm-test-thumbnail"
                src="/workspace-art/initial.jpg"
                alt=""
                width={56}
                height={56}
              />
              <span className="fm-icon purple">
                <Layers size={24} />
              </span>
              <div className="fm-test-text">
                <h3>آزمون خودشناسی اولیه</h3>
                <p className="fm-test-description">کجا قوی هستی و کجا معمولاً گیر می‌کنی</p>
                <small className="fm-test-description">۳۰ جمله · حدود ۱۰ دقیقه</small>
                <small className="fm-mobile-test-state">{initialState}</small>
              </div>
              <div className="fm-actions">
                <Link className="fm-button" href={initialHref}>
                  {initialLabel}
                  <ChevronLeft size={16} />
                </Link>
              </div>
            </div>
          </article>

          <article className="fm-test-card">
            <div className="fm-test-art">
              <Image src="/workspace-art/deep.jpg" alt="" width={560} height={300} />
              <span className="fm-test-badge">با ورود</span>
            </div>
            <div className="fm-test-copy">
              <Image
                className="fm-test-thumbnail"
                src="/workspace-art/deep.jpg"
                alt=""
                width={56}
                height={56}
              />
              <span className="fm-icon blue">
                <Layers size={24} />
              </span>
              <div className="fm-test-text">
                <h3>آزمون خودشناسی عمیق</h3>
                <p className="fm-test-description">
                  نگاهی دقیق‌تر به ۳۰ ویژگی و سبک تو در کار، رابطه و تصمیم‌گیری
                </p>
                <small className="fm-test-description">۱۵۰ جمله در ۳۰ کارت · حدود ۲۵ دقیقه</small>
                <small className="fm-mobile-test-state">با ورود</small>
              </div>
              <div className="fm-actions">
                <Link className="fm-button fm-outline" href="/deep-test">
                  بیشتر بدانید
                  <ChevronLeft size={16} />
                </Link>
              </div>
            </div>
          </article>
        </div>
      </section>
    </main>
  );
}

export async function SelfKnowledgeView() {
  const data = await getWorkspaceData();
  const [deepStart, freeStart, canonical] = await Promise.all([
    getPreStart(DEEP_ASSESSMENT_SLUG).catch(() => null),
    getPreStart(SELF_KNOWLEDGE_ASSESSMENT_SLUG).catch(() => null),
    getCanonicalContext(),
  ]);

  const sortedHistory = [...data.history].sort(
    (a, b) => new Date(b.completed_at).getTime() - new Date(a.completed_at).getTime(),
  );
  const deep = sortedHistory.find((h) => h.report_type === "deep" && h.status === "ok");
  const free = sortedHistory.find((h) => h.report_type === "initial" && h.status === "ok");
  const reports = [deep, free]
    .filter((item): item is ReportAttemptHistoryItem => Boolean(item))
    .sort((a, b) => new Date(b.completed_at).getTime() - new Date(a.completed_at).getTime());

  const featuredItem = reports[0] ?? null;
  let featuredDomains = canonical?.report?.scores ?? [];
  if (featuredItem && canonical?.report?.attempt_id !== featuredItem.attempt_id) {
    const fetched = await getWorkspaceReport(featuredItem.attempt_id);
    featuredDomains = extractRadarDomains(fetched);
  }

  const duplicateHistory = ["deep", "initial"].some(
    (type) => sortedHistory.filter((h) => h.status === "ok" && h.report_type === type).length > 1,
  );

  function reportCard(item: ReportAttemptHistoryItem, featured: boolean) {
    return (
      <article
        key={item.attempt_id}
        className={`fm-card fm-report-card ${featured ? "fm-gradient fm-featured-report" : ""}`}
      >
        <div className="fm-report-copy">
          {!featured && (
            <Link
              className="fm-report-mobile-link"
              href={reportHref(item)}
              aria-label={`دیدن گزارش ${item.report_type === "deep" ? "عمیق" : "اولیه"}`}
            />
          )}
          {featured ? (
            <small>آخرین گزارش · {formatJalali(item.completed_at)}</small>
          ) : (
            <span className="fm-icon purple">
              <FileText size={26} />
            </span>
          )}
          <h2>گزارش {item.report_type === "deep" ? "عمیق" : "اولیه"}</h2>
          {!featured && <small className="fm-muted">{formatJalali(item.completed_at)}</small>}
          <p>
            {item.report_type === "deep"
              ? "۳۰ ویژگی شخصیتی و سبک تو در کار، رابطه، تصمیم‌گیری و روبه‌رو شدن با استرس."
              : "نقطه‌های قوتت و جاهایی که معمولاً گیر می‌کنی."}
          </p>
          {featured && (
            <div className="fm-topic-chips">
              {TOPICS.map((t) => (
                <span key={t}>{t}</span>
              ))}
            </div>
          )}
          <div className="fm-actions">
            <Link
              className={`fm-button ${featured ? "fm-white" : "fm-outline"}`}
              href={reportHref(item)}
            >
              دیدن گزارش
            </Link>
            <Link
              className={`fm-button ${featured ? "fm-glass" : "fm-soft"}`}
              href={reportChatHref(item)}
            >
              درباره‌اش حرف بزنیم
            </Link>
          </div>
        </div>
        {featured && featuredDomains.length === 5 && (
          <ReportRadar domains={featuredDomains} light />
        )}
      </article>
    );
  }

  function testCard(isDeep: boolean, pre: PreStartResponse | null) {
    const type = isDeep ? "deep" : "initial";
    const successful = isDeep ? deep : free;
    const latestOfType = sortedHistory.find((h) => h.report_type === type);
    const pending =
      latestOfType && latestOfType.status !== "ok" && !successful ? latestOfType : undefined;
    const base = isDeep ? "/deep-test" : "/test";
    const inProgress = pre?.has_in_progress_attempt;
    let label = successful ? "انجام دوباره" : "شروع";
    let href = base;
    let state = successful
      ? `داده‌ای · ${formatJalali(successful.completed_at, "D MMMM")}`
      : isDeep
        ? "حدود ۲۵ دقیقه"
        : "حدود ۱۰ دقیقه · رایگان";
    if (pending) {
      href = reportHref(pending);
      label =
        pending.status === "awaiting_payment"
          ? "ساخت گزارش"
          : pending.status === "error"
            ? "بررسی گزارش"
            : "وضعیت گزارش";
      state =
        pending.status === "awaiting_payment"
          ? "جواب‌هایت آماده است"
          : pending.status === "generating"
            ? "گزارشت در حال ساخته شدن است"
            : "ساخت گزارش نیاز به بررسی دارد";
    }
    if (inProgress && !successful) {
      href = isDeep ? "/deep-test/questions?source=explore" : "/test/questions";
      label = "ادامه";
      state =
        pre?.answered_count != null
          ? pre.total_questions
            ? `${toPersianDigits(pre.answered_count)} از ${toPersianDigits(pre.total_questions)}`
            : `${toPersianDigits(pre.answered_count)} پاسخ ثبت‌شده`
          : "در حال انجام";
    } else if (inProgress && successful) {
      href = isDeep ? "/deep-test/questions?source=explore" : "/test/questions";
      label = "ادامه‌ی آزمون تازه";
    }
    // A resumable attempt gets a progress bar (design ref: "وسط آزمون رفته" row) so the row
    // shows how far along the user is, not just a percentage-less "ادامه" link.
    const answeredCount = pre?.answered_count ?? null;
    const totalCount = pre?.total_questions ?? null;
    const progress =
      inProgress && answeredCount != null && totalCount
        ? {
            percent: Math.min(100, Math.max(2, Math.round((answeredCount / totalCount) * 100))),
            label: `${toPersianDigits(answeredCount)} از ${toPersianDigits(totalCount)}`,
          }
        : null;
    if (progress) state = "در حال انجام";
    return (
      <article className="fm-test-card" key={base}>
        <div className="fm-test-art">
          <Image
            src={isDeep ? "/workspace-art/deep.jpg" : "/workspace-art/initial.jpg"}
            alt=""
            width={560}
            height={300}
          />
          <span className="fm-test-badge">{state}</span>
        </div>
        <div className="fm-test-copy">
          <Image
            className="fm-test-thumbnail"
            src={isDeep ? "/workspace-art/deep.jpg" : "/workspace-art/initial.jpg"}
            alt=""
            width={56}
            height={56}
          />
          <span className={`fm-icon ${isDeep ? "blue" : "purple"}`}>
            <Layers size={24} />
          </span>
          <div className="fm-test-text">
            <h3>آزمون خودشناسی {isDeep ? "عمیق" : "اولیه"}</h3>
            <p className="fm-test-description">
              {isDeep
                ? "نگاهی دقیق‌تر به ۳۰ ویژگی و سبک تو در کار، رابطه و تصمیم‌گیری"
                : "کجا قوی هستی و کجا معمولاً گیر می‌کنی"}
            </p>
            <small className="fm-test-description">
              {isDeep ? "۳۰ کارت پنج‌سؤالی · حدود ۲۵ دقیقه" : "۳۰ جمله · حدود ۱۰ دقیقه · رایگان"}
            </small>
            {progress ? (
              <div className="fm-test-progress" role="img" aria-label={progress.label}>
                <div className="fm-test-progress-track">
                  <i style={{ width: `${progress.percent}%` }} />
                </div>
                <small>{progress.label}</small>
              </div>
            ) : (
              <small className="fm-mobile-test-state">{state}</small>
            )}
          </div>
          <div className="fm-actions">
            {successful && (
              <Link className="fm-button fm-test-report-link" href={reportHref(successful)}>
                دیدن گزارش
              </Link>
            )}
            <Link className={successful ? "fm-text-link" : "fm-button"} href={href}>
              {label}
              <ChevronLeft size={16} />
            </Link>
          </div>
        </div>
      </article>
    );
  }

  const hasActiveFailedOrGenerating = ["deep", "initial"].some((type) => {
    const latest = sortedHistory.find((h) => h.report_type === type);
    return latest && (latest.status === "error" || latest.status === "generating");
  });

  return (
    <main className="fm-page fm-self-page">
      <header className="fm-page-title">
        <h1>خودشناسی</h1>
        <p>گزارش‌ها و آزمون‌هایت</p>
      </header>
      <section>
        <div className="fm-section-heading">
          <h2>گزارش‌های من</h2>
          {duplicateHistory && (
            <Link href="/history">
              همه‌ی گزارش‌ها (
              {toPersianDigits(sortedHistory.filter((h) => h.status === "ok").length)}){" "}
              <ChevronLeft size={16} />
            </Link>
          )}
        </div>
        <div className="fm-report-grid">
          {reports.map((item, index) => reportCard(item, index === 0))}
          {!deep && !free && (
            <div className="fm-card fm-empty">
              <FileText size={28} />
              <p>
                {data.historyUnavailable
                  ? "دریافت گزارش‌ها ممکن نشد. لطفاً صفحه را دوباره بارگذاری کن."
                  : "گزارش‌های تو بعد از انجام آزمون، اینجا قرار می‌گیرند."}
              </p>
            </div>
          )}
        </div>
      </section>
      <section>
        <div className="fm-section-heading">
          <h2>آزمون‌ها</h2>
        </div>
        <div className="fm-test-grid">
          {testCard(true, deepStart)}
          {testCard(false, freeStart)}
        </div>
      </section>
      {hasActiveFailedOrGenerating && (
        <div className="fm-card fm-row">
          <CircleAlert size={20} />
          <Link href="/history">مشاهدهٔ وضعیت گزارش‌های در حال ساخت یا ناموفق</Link>
        </div>
      )}
    </main>
  );
}
