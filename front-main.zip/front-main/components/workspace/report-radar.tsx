/** Backend deterministic values only. Missing scores never become guessed numbers. */
export function ReportRadar({
  domains,
  light = false,
}: {
  domains: { code: string; title: string; score?: number; level?: string }[];
  light?: boolean;
}) {
  if (domains.length !== 5) return null;
  const ordered = domains;
  if (ordered.some((d) => !Number.isFinite(d.score) || d.score! < 0 || d.score! > 100)) return null;
  const point = (i: number, radius: number) => {
    const a = ((-90 + i * 72) * Math.PI) / 180;
    return [100 + Math.cos(a) * radius, 100 + Math.sin(a) * radius];
  };
  const polygon = (radius: number) =>
    Array.from({ length: 5 }, (_, i) => point(i, radius).join(",")).join(" ");
  const points = ordered.map((d, i) => point(i, d.score! * 0.8));
  const color = light ? "#fff" : "#5b63d6";
  return (
    <figure className={`fm-radar ${light ? "fm-radar-light" : ""}`}>
      <svg
        viewBox="0 0 200 200"
        role="img"
        aria-label={ordered.map((d) => `${d.title}: ${d.score} از ۱۰۰`).join("، ")}
      >
        {[80, 53, 26].map((r) => (
          <polygon
            key={r}
            points={polygon(r)}
            fill="none"
            stroke={color}
            strokeOpacity={0.22}
            strokeWidth={1}
          />
        ))}
        {ordered.map((d, i) => (
          <path
            key={d!.code}
            d={`M100 100 L${point(i, 80).join(" ")}`}
            stroke={color}
            strokeOpacity={0.15}
          />
        ))}
        <polygon
          points={points.map((p) => p.join(",")).join(" ")}
          fill={color}
          fillOpacity={0.22}
          stroke={color}
          strokeWidth={2.2}
          strokeLinejoin="round"
        />
        {points.map(([cx, cy], i) => (
          <circle
            key={i}
            cx={cx}
            cy={cy}
            r={4}
            fill={["#c9a9f0", "#8fc0ff", "#ffc388", "#ff9c9c", "#a6dca6"][i]}
          />
        ))}
      </svg>
      <figcaption>امتیازهای پنج بُعد · از ۱۰۰</figcaption>
    </figure>
  );
}
