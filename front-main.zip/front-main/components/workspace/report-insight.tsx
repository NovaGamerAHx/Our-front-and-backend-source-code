"use client";
import Link from "next/link";
import { useState } from "react";
import { rejectFindingAction } from "@/app/workspace-actions";
export function ReportInsight({
  attemptId,
  finding,
  href,
}: {
  attemptId: number;
  finding: { key: string; text: string };
  href: string;
}) {
  const [hidden, setHidden] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(false);
  if (hidden) return null;
  return (
    <section className="fm-card fm-insight">
      <small>یک برداشت از گزارشت</small>
      <p>{finding.text}</p>
      <div className="fm-actions">
        <Link href={href} className="fm-button fm-white">
          درباره‌اش حرف بزنیم
        </Link>
        <button
          className="fm-text-link"
          disabled={busy}
          onClick={async () => {
            setBusy(true);
            setError(false);
            const result = await rejectFindingAction(attemptId, finding.key);
            setBusy(false);
            if (result.ok) setHidden(true);
            else setError(true);
          }}
        >
          {busy ? "در حال ثبت…" : "این با من نمی‌خواند"}
        </button>
      </div>
      {error && <p role="alert">ثبت نشد؛ دوباره تلاش کن.</p>}
    </section>
  );
}
