import { getWorkspaceData } from "@/lib/workspace/data";
import { WorkspaceChrome } from "./workspace-chrome";
export async function WorkspaceFrame({
  children,
  payment = false,
}: {
  children: React.ReactNode;
  payment?: boolean;
}) {
  const data = await getWorkspaceData();
  return (
    <WorkspaceChrome
      name={data.profile?.name ?? null}
      sessions={data.sessions}
      authenticated={data.authenticated}
      payment={payment}
    >
      {children}
    </WorkspaceChrome>
  );
}
