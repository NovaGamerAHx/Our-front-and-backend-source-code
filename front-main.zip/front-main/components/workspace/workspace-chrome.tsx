"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { listChatSessionsAction } from "@/app/chat/actions";
import { usePathname, useSearchParams, useRouter } from "next/navigation";
import { Home, MessageCircle, Layers, UserRound, Plus } from "lucide-react";
import { LogoMark } from "@/components/site/logo-mark";
import type { ChatSessionSummary } from "@/lib/api/schemas";
import "./workspace.css";

export function WorkspaceChrome({
  children,
  name,
  sessions,
  authenticated,
  payment,
}: {
  children: React.ReactNode;
  name: string | null;
  sessions: ChatSessionSummary[];
  authenticated: boolean;
  payment: boolean;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [liveSessions, setLiveSessions] = useState<ChatSessionSummary[] | null>(null);
  useEffect(() => {
    const refresh = () => {
      void listChatSessionsAction().then((result) => {
        if (result.ok) setLiveSessions(result.data);
      });
    };
    window.addEventListener("faraman:chat-updated", refresh);
    return () => window.removeEventListener("faraman:chat-updated", refresh);
  }, []);
  const recentSessions = liveSessions ?? sessions;
  const params = useSearchParams();
  const chat = pathname === "/chat";
  const reportPage = pathname === "/report" || pathname === "/deep-report" || pathname === "/preview";
  const intro = pathname === "/test" || pathname === "/deep-test";
  const freshChat = "/chat?fresh=1";
  const tabs = [
    { href: "/", label: "خانه", icon: Home },
    { href: "/chat", label: "گفت‌وگو", icon: MessageCircle },
    { href: "/explore", label: "خودشناسی", icon: Layers },
    { href: "/profile", label: "من", icon: UserRound },
  ];
  const active = (href: string) =>
    href === "/profile"
      ? pathname === "/profile" || pathname.startsWith("/profile/")
      : href === "/explore"
      ? ["/explore", "/deep-test", "/test", "/paywall", "/report", "/deep-report", "/preview"].some((p) => pathname === p || pathname.startsWith(`${p}/`))
      : pathname === href;
  const accountHref = authenticated ? "/profile" : "/login";
  return (
    <div
      className={`fm-workspace ${chat ? "fm-chat-workspace" : ""} ${payment ? "fm-payment-workspace" : ""}`}
    >
      {!payment && (
        <aside className="fm-sidebar">
          <Link href="/" className="fm-brand">
            <LogoMark height={38} />
            <span>فرامن</span>
          </Link>
          <Link
            href={freshChat}
            onClick={(e) => {
              e.preventDefault();
              router.push(`/chat?fresh=${Date.now()}`);
            }}
            className="fm-button fm-new-chat"
          >
            <Plus size={18} />
            گفت‌وگوی تازه
          </Link>
          <nav aria-label="منوی اصلی">
            {tabs.slice(0, 3).map(({ href, label, icon: Icon }) => (
              <Link
                key={href}
                href={href}
                aria-current={active(href) ? "page" : undefined}
                className={active(href) ? "is-active" : ""}
              >
                <Icon size={20} />
                {label}
              </Link>
            ))}
          </nav>
          <div className="fm-recent">
            <h2>گفت‌وگوهای اخیر</h2>
            {recentSessions.length ? (
              recentSessions.slice(0, 8).map((s) => (
                <Link
                  key={s.session_id}
                  href={`/chat?session_id=${encodeURIComponent(s.session_id)}`}
                  aria-current={params.get("session_id") === s.session_id ? "page" : undefined}
                >
                  {s.preview || "گفت‌وگو با فرامن"}
                </Link>
              ))
            ) : (
              <p>گفت‌وگوهای تو اینجا قرار می‌گیرند.</p>
            )}
          </div>
          <Link href={accountHref} className="fm-account">
            <span className="fm-avatar">{name?.trim().slice(0, 1) || <UserRound size={18} />}</span>
            <span>
              <strong>{name || (authenticated ? "حساب من" : "ورود به فرامن")}</strong>
              <small>من · حساب و تنظیمات</small>
            </span>
          </Link>
        </aside>
      )}
      <div className="fm-workspace-body">
        {!chat && !payment && !intro && !reportPage && (
          <header className="fm-mobile-header">
            <Link href="/" className="fm-brand">
              <LogoMark height={28} />
              <span>فرامن</span>
            </Link>
            <Link aria-label="حساب من" href={accountHref} className="fm-avatar">
              {name?.trim().slice(0, 1) || <UserRound size={18} />}
            </Link>
          </header>
        )}
        {children}
      </div>
      {!chat && !payment && (
        <nav className="fm-bottom-nav" aria-label="نوار اصلی">
          {tabs.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href === "/profile" ? accountHref : href}
              aria-current={active(href) ? "page" : undefined}
              className={active(href) ? "is-active" : ""}
            >
              <Icon size={23} />
              <span>{label}</span>
            </Link>
          ))}
        </nav>
      )}
    </div>
  );
}
