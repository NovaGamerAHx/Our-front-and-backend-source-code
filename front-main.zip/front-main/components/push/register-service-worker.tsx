"use client";

import { useEffect } from "react";
import { subscribeToPush } from "@/lib/push/subscribe";

/** Registers the Firebase messaging service worker on every route -- silent, no permission
 * prompt (that only happens in lib/push/subscribe.ts, on a deliberate user tap).
 *
 * Also silently re-registers the FCM token on every route when permission was already granted
 * in an earlier session. A token can go stale between visits (browser/OS token rotation, site
 * data cleared, reinstall) with nothing telling the backend, so a reminder/followup notification
 * scheduled hours or days later (apps/notifications in faraman-back) silently has no live
 * subscription to send to. Refreshing here -- mounted app-wide in layout.tsx -- rather than only
 * where this previously lived (chat-view.tsx, refreshed only on opening /chat) keeps that window
 * short regardless of which screen the user opens first. subscribeToPush() re-checks
 * Notification.permission itself, so this is a no-op once granted permission is confirmed
 * unchanged.
 *
 * Re-runs when `isLoggedIn` flips: the register call needs an authenticated user, so a load on
 * the login page (or any logged-out screen) fails with 401 -- and the root layout doesn't remount
 * on the client-side navigation after sign-in, so without this the token stayed unregistered
 * until the next full page load. */
export function RegisterServiceWorker({ isLoggedIn }: { isLoggedIn: boolean }) {
  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/firebase-messaging-sw.js").catch(() => {});
    }
  }, []);

  useEffect(() => {
    if (isLoggedIn && typeof Notification !== "undefined" && Notification.permission === "granted") {
      subscribeToPush();
    }
  }, [isLoggedIn]);

  return null;
}
