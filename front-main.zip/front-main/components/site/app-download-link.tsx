"use client";

import type { ComponentProps } from "react";
import { Download } from "lucide-react";
import { DIRECT_DOWNLOAD_HREF } from "@/lib/constants/app-download";
import { trackEventAction } from "@/lib/api/track-event-action";

type Props = Omit<ComponentProps<"a">, "href" | "download" | "children"> & {
  source: "app_home" | "landing" | "report_v1" | "report_v2" | "report_v3" | "deep_report";
};

/** Best-effort click tracking; never delays or prevents the browser download. */
export function AppDownloadLink({ source, onClick, ...props }: Props) {
  return (
    <a href={DIRECT_DOWNLOAD_HREF} download {...props} onClick={(event) => {
      onClick?.(event);
      if (!event.defaultPrevented) void trackEventAction({ event_name: "app_download_clicked", properties: { source } });
    }}>
      <Download size={15} strokeWidth={2} aria-hidden="true" />
      دانلود مستقیم اپلیکیشن
    </a>
  );
}
