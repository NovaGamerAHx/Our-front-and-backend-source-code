"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, MessageCircle, Layers, UserRound } from "lucide-react";

/** The same destinations and labels as the workspace navigation on legacy pages. */
export function MobileTabBar({ isLoggedIn }: { isLoggedIn: boolean }) {
  const pathname = usePathname();
  const tabs = [
    { href: "/", label: "خانه", Icon: Home, active: pathname === "/" },
    { href: isLoggedIn ? "/chat" : "/login?next=%2Fchat", label: "گفت‌وگو", Icon: MessageCircle, active: pathname.startsWith("/chat") },
    { href: "/explore", label: "خودشناسی", Icon: Layers, active: ["/explore", "/test", "/deep-test", "/report", "/deep-report", "/preview", "/paywall"].some(p => pathname === p || pathname.startsWith(`${p}/`)) },
    { href: isLoggedIn ? "/profile" : "/login?next=%2Fprofile", label: "من", Icon: UserRound, active: pathname === "/profile" || pathname.startsWith("/profile/") },
  ];
  return (
    <nav aria-label="نوار اصلی" className="fixed inset-x-0 bottom-0 z-[45] hidden grid-cols-4 max-[899px]:grid border-t border-[#ece6da] bg-white px-2 pt-1.5 pb-[calc(10px+env(safe-area-inset-bottom,0px))]">
      {tabs.map(({ href, label, Icon, active }) => (
        <Link key={label} href={href} aria-current={active ? "page" : undefined} className={`flex min-h-[54px] flex-col items-center justify-center gap-1 text-xs ${active ? "font-bold text-[#2f44c2]" : "font-medium text-[#6b6a78]"}`}>
          <Icon size={23} aria-hidden="true" />
          <span>{label}</span>
        </Link>
      ))}
    </nav>
  );
}
