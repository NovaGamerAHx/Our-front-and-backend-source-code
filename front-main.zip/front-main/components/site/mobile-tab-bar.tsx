"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

const EXPLORE_MATCH = ["/explore", "/test", "/preview"];
const DASHBOARD_MATCH = ["/dashboard", "/history"];
const CHAT_MATCH = ["/chat"];
const PROFILE_MATCH = ["/profile", "/terms"];

type TabKey = "explore" | "dashboard" | "chat" | "profile";

function tabFromPath(pathname: string): TabKey | null {
  if (EXPLORE_MATCH.some((p) => pathname === p || pathname.startsWith(`${p}/`))) return "explore";
  if (DASHBOARD_MATCH.includes(pathname)) return "dashboard";
  if (CHAT_MATCH.includes(pathname)) return "chat";
  if (PROFILE_MATCH.includes(pathname)) return "profile";
  return null;
}

function tabColor(active: boolean) {
  return active ? "#2743C6" : "#5D5C55";
}

export function MobileTabBar({ isLoggedIn }: { isLoggedIn: boolean }) {
  const pathname = usePathname();

  // Optimistic active tab: set synchronously in onClick so the bar highlights the
  // target the instant it's tapped — before the route's data fetch even starts
  // (Edge States §e9). Reset during render once the real pathname catches up.
  const [optimisticTab, setOptimisticTab] = useState<TabKey | null>(null);
  const [seenPathname, setSeenPathname] = useState(pathname);
  if (pathname !== seenPathname) {
    setSeenPathname(pathname);
    setOptimisticTab(null);
  }

  const activeTab = optimisticTab ?? tabFromPath(pathname);

  const tabs: { key: TabKey; href: string; label: string; icon?: React.ReactNode }[] = [
    {
      key: "explore",
      href: "/explore",
      label: "کاوش",
      icon: (
        <>
          <circle cx="12" cy="12" r="8.5" />
          <path d="m14.8 9.2-1.9 4.4-4.4 1.9 1.9-4.4Z" />
        </>
      ),
    },
    {
      key: "dashboard",
      href: isLoggedIn ? "/dashboard" : "/login?next=%2Fdashboard",
      label: "داشبورد",
      icon: (
        <>
          <rect x="4" y="4" width="7" height="7" rx="2" />
          <rect x="13" y="4" width="7" height="7" rx="2" />
          <rect x="4" y="13" width="7" height="7" rx="2" />
          <rect x="13" y="13" width="7" height="7" rx="2" />
        </>
      ),
    },
    {
      key: "chat",
      href: isLoggedIn ? `/chat?from=${encodeURIComponent(pathname)}` : "/login?next=%2Fchat",
      label: "گفتگو",
    },
    {
      key: "profile",
      href: isLoggedIn ? "/profile" : "/login?next=%2Fprofile",
      label: "پروفایل",
      icon: (
        <>
          <circle cx="12" cy="8" r="3.4" />
          <path d="M5.5 20a6.5 6.5 0 0 1 13 0" />
        </>
      ),
    },
  ];

  return (
    <nav className="border-border fixed inset-x-0 bottom-0 z-[45] grid grid-cols-4 border-t bg-[#FFFDF8] px-1 pt-2 pb-2.5 shadow-[0_-6px_24px_rgba(80,70,40,.07)] md:hidden">
      {tabs.map((tab) => {
        const active = activeTab === tab.key;
        return (
          <Link
            key={tab.key}
            href={tab.href}
            onClick={() => setOptimisticTab(tab.key)}
            aria-current={active ? "page" : undefined}
            className="flex min-h-12 flex-col items-center justify-center gap-1 rounded-xl transition-[transform,opacity] duration-75 active:scale-95 active:opacity-70"
          >
            {tab.key === "chat" ? (
              <Image src="/icons/chat-tab-icon.png" alt="" width={24} height={24} />
            ) : (
              <svg
                width="22"
                height="22"
                viewBox="0 0 24 24"
                fill="none"
                stroke={tabColor(active)}
                strokeWidth="1.9"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                {tab.icon}
              </svg>
            )}
            <span
              className="text-[11.5px]"
              style={{ fontWeight: active ? 800 : 600, color: tabColor(active) }}
            >
              {tab.label}
            </span>
          </Link>
        );
      })}
    </nav>
  );
}
