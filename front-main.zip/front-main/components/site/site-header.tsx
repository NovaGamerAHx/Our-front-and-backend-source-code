"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { LogoMark } from "@/components/site/logo-mark";
import { usePathname, useRouter } from "next/navigation";

type NavItem = { label: string; href: string; match: string[] };

const NAV_GUEST: NavItem[] = [
  { label: "کاوش", href: "/explore", match: ["/explore", "/test"] },
  { label: "فرابلاگ", href: "/blog", match: ["/blog"] },
  { label: "دربارهٔ فرامن", href: "/about", match: ["/about"] },
];

const NAV_USER: NavItem[] = [
  { label: "کاوش", href: "/explore", match: ["/explore", "/test"] },
  { label: "داشبورد", href: "/dashboard", match: ["/dashboard", "/history"] },
  { label: "گفت‌وگو", href: "/chat", match: ["/chat"] },
  { label: "فرابلاگ", href: "/blog", match: ["/blog"] },
  { label: "دربارهٔ فرامن", href: "/about", match: ["/about"] },
];

function Logo({ light }: { light: boolean }) {
  return (
    <div className="flex flex-none items-center gap-2">
      <LogoMark height={36} />
      <span
        className={`text-[17px] font-extrabold transition-colors duration-[250ms] ${light ? "text-white" : "text-foreground"}`}
      >
        فرامن
      </span>
    </div>
  );
}

// "solid": normal in-flow header (cream bg, blue accent) used by most pages.
// "overlay-dark": floats transparently over the landing's light photo hero -- dark foreground
// and the landing-only plum accent (Landing v2 §1a) both before and after the solid-on-scroll
// switch; only the background/blur/shadow change on scroll.
// "overlay-light": floats transparently over the app's dark navy-gradient heroes (report,
// deep-report, preview) with white foreground, inverting to solid white + blue accent on scroll.
type HeaderVariant = "solid" | "overlay-dark" | "overlay-light";

export function SiteHeader({
  isLoggedIn,
  variant,
}: {
  isLoggedIn: boolean;
  variant: HeaderVariant;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [scrolled, setScrolled] = useState(false);

  // Same "redirect-with-return-target" contract as login-form.tsx's loginHref: land the visitor
  // back on whatever page they were reading (report/preview/chat/...) after verifying, instead of
  // always bouncing to the dashboard default. Reads window.location at click time (query string
  // included, unlike usePathname()) rather than tracking it in state -- there's nothing to
  // synchronize until the moment of the actual click.
  function handleLoginClick(e: React.MouseEvent<HTMLAnchorElement>) {
    e.preventDefault();
    const current = `${window.location.pathname}${window.location.search}`;
    router.push(current !== "/" ? `/login?next=${encodeURIComponent(current)}` : "/login");
  }

  // Optimistic active nav item: highlight the tapped link synchronously, before
  // the destination starts fetching (Edge States §e9). Reset during render once
  // the real pathname catches up (React's "adjust state on prop change" pattern).
  const [optimisticHref, setOptimisticHref] = useState<string | null>(null);
  const [seenPathname, setSeenPathname] = useState(pathname);
  if (pathname !== seenPathname) {
    setSeenPathname(pathname);
    setOptimisticHref(null);
  }

  useEffect(() => {
    function onScroll() {
      setScrolled(window.scrollY > 8);
    }
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const floats = variant !== "solid";
  const onDark = variant === "overlay-light" && !scrolled;
  const accentColor = variant === "overlay-dark" ? "#6B4FA8" : "var(--primary)";
  const navItems = isLoggedIn ? NAV_USER : NAV_GUEST;

  const chromeStyle: React.CSSProperties = {
    background: scrolled ? "rgba(255,255,255,.92)" : floats ? "transparent" : "var(--background)",
    backdropFilter: scrolled ? "blur(12px)" : "none",
    borderBottom: `1px solid ${scrolled ? "var(--border)" : "transparent"}`,
    boxShadow: scrolled ? "0 6px 22px rgba(80,70,40,.07)" : "none",
    transition: "background .25s ease, border-color .25s ease, box-shadow .25s ease",
  };

  const loginButtonStyle: React.CSSProperties = {
    background: onDark ? "#fff" : accentColor,
    color: onDark ? "#22307E" : "#fff",
    transition: "background .25s ease, color .25s ease",
  };

  const pillStyle: React.CSSProperties = {
    background: onDark ? "rgba(255,255,255,.14)" : "#fff",
    borderColor: onDark ? "rgba(255,255,255,.34)" : "var(--border)",
    color: onDark ? "#fff" : "var(--foreground)",
    transition: "background .25s ease, color .25s ease, border-color .25s ease",
  };

  return (
    <header
      className={`sticky top-0 z-40 ${floats ? "-mb-16 md:-mb-[68px]" : ""}`}
      style={chromeStyle}
    >
      {/* Desktop row */}
      <div className="mx-auto hidden w-full max-w-[1120px] items-center gap-[26px] px-7 py-[13px] md:flex">
        <Link href="/" className="flex-none">
          <Logo light={onDark} />
        </Link>
        <nav className="flex flex-1 items-center gap-0.5">
          {navItems.map((item) => {
            const active = optimisticHref
              ? optimisticHref === item.href
              : item.match.includes(pathname);
            const href =
              item.href === "/chat" ? `/chat?from=${encodeURIComponent(pathname)}` : item.href;
            return (
              <Link
                key={item.label}
                href={href}
                onClick={() => setOptimisticHref(item.href)}
                className="rounded-[10px] px-[13px] py-2.5 text-[13px] whitespace-nowrap"
                style={{
                  fontWeight: active ? 800 : 600,
                  color: onDark
                    ? active
                      ? "#fff"
                      : "rgba(255,255,255,.78)"
                    : active
                      ? "#22307E"
                      : "var(--muted-foreground)",
                  background: onDark
                    ? active
                      ? "rgba(255,255,255,.16)"
                      : "transparent"
                    : active
                      ? "var(--secondary)"
                      : "transparent",
                }}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="flex flex-none items-center gap-2.5">
          {isLoggedIn ? (
            <Link
              href="/profile"
              className="flex min-h-10 items-center gap-2.5 rounded-full border py-[7px] pr-4 pl-2 text-[12.5px] font-bold"
              style={pillStyle}
            >
              <span className="bg-secondary grid size-[26px] place-items-center rounded-full">
                <svg
                  width="15"
                  height="15"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="#2743C6"
                  strokeWidth="1.9"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <circle cx="12" cy="8" r="3.4" />
                  <path d="M5.5 20a6.5 6.5 0 0 1 13 0" />
                </svg>
              </span>
              پروفایل
            </Link>
          ) : (
            <Link
              href="/login"
              onClick={handleLoginClick}
              className="min-h-10 rounded-full px-[22px] py-2.5 text-[12.5px] font-extrabold"
              style={loginButtonStyle}
            >
              ورود
            </Link>
          )}
        </div>
      </div>

      {/* Mobile row */}
      <div className="flex items-center justify-between gap-3 px-[18px] py-2.5 md:hidden">
        <Link href="/" className="flex-none">
          <div className="flex items-center gap-2">
            <LogoMark height={30} />
            <span
              className={`translate-y-[2px] text-[16px] font-extrabold transition-colors duration-[250ms] ${onDark ? "text-white" : "text-foreground"}`}
            >
              فرامن
            </span>
          </div>
        </Link>
        {!isLoggedIn && (
          <Link
            href="/login"
            onClick={handleLoginClick}
            className="flex min-h-11 items-center rounded-full px-[22px] text-[12.5px] font-extrabold"
            style={loginButtonStyle}
          >
            ورود
          </Link>
        )}
      </div>
    </header>
  );
}
