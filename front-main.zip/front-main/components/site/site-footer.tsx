"use client";

import Link from "next/link";
import { LogoMark } from "@/components/site/logo-mark";
import { ComingSoonButton } from "@/components/report/coming-soon-button";

// Enamad's official embed snippet, verbatim (their panel treats altering the seal's markup as a
// legal violation) -- including the non-standard `code` attribute, which JSX's img typings don't
// know about, hence the cast rather than dropping/renaming it.
const ENAMAD_IMG_PROPS = {
  referrerPolicy: "origin",
  src: "https://trustseal.enamad.ir/logo.aspx?id=7576065&Code=KcYbASroP4NohcIprgbDQYp8o1mTPXW8",
  alt: "",
  code: "KcYbASroP4NohcIprgbDQYp8o1mTPXW8",
  style: { cursor: "pointer" },
} as React.ImgHTMLAttributes<HTMLImageElement> & { code: string };

export function SiteFooter() {
  return (
    <footer className="border-border mt-auto hidden border-t bg-[#FFFDF8] md:block">
      <div className="mx-auto flex w-full max-w-[1120px] flex-col gap-9 px-7 pt-11 pb-[22px]">
        <div className="grid grid-cols-[1.5fr_1fr_1fr_auto] gap-10">
          <div className="flex max-w-[340px] flex-col gap-3.5">
            <div className="flex items-center gap-2">
              <LogoMark height={36} />
              <div className="text-base font-extrabold">فرامن</div>
            </div>
            <p className="text-muted-foreground text-[12.5px] leading-[2]">
              شناخت خودتان با یک آزمون کوتاه و یک قدم عملی برای امروز — ساده، محرمانه و بر اساس
              پاسخ‌های خودتان.
            </p>
          </div>

          <div className="flex flex-col gap-2.5">
            <div className="text-[12.5px] font-extrabold">پیوندها</div>
            <Link
              href="/about"
              className="text-[12.5px] leading-[1.9] font-semibold text-[#5D5C55]"
            >
              دربارهٔ فرامن
            </Link>
            <Link href="/blog" className="text-[12.5px] leading-[1.9] font-semibold text-[#5D5C55]">
              فرابلاگ
            </Link>
            <ComingSoonButton className="cursor-pointer text-right text-[12.5px] leading-[1.9] font-semibold text-[#5D5C55]">
              نظر شما
            </ComingSoonButton>
            <Link
              href="/terms?tab=terms"
              className="text-[12.5px] leading-[1.9] font-semibold text-[#5D5C55]"
            >
              قوانین استفاده
            </Link>
            <Link
              href="/terms?tab=privacy"
              className="text-[12.5px] leading-[1.9] font-semibold text-[#5D5C55]"
            >
              حریم خصوصی
            </Link>
          </div>

          <div className="flex flex-col gap-2.5">
            <div className="text-[12.5px] font-extrabold">تماس با ما</div>
            <a
              href="mailto:hello@faraman.ai"
              dir="ltr"
              className="text-right text-[12.5px] leading-[1.9] font-semibold text-[#5D5C55] no-underline"
            >
              hello@faraman.ai
            </a>
            <ComingSoonButton className="text-primary cursor-pointer text-right text-[12.5px] leading-[1.9] font-bold">
              ارسال پیام به تیم پشتیبانی
            </ComingSoonButton>
          </div>

          <div className="flex flex-col items-center justify-center gap-1.5">
            <a
              referrerPolicy="origin"
              target="_blank"
              href="https://trustseal.enamad.ir/?id=7576065&Code=KcYbASroP4NohcIprgbDQYp8o1mTPXW8"
              className="block size-[72px] overflow-hidden rounded-lg"
            >
              {/* eslint-disable-next-line @next/next/no-img-element -- Enamad's verifier serves this
                  image directly from trustseal.enamad.ir; next/image would need that host allow-listed
                  and would optimize/rehost an image that must render exactly as Enamad issued it. */}
              <img {...ENAMAD_IMG_PROPS} className="size-full object-contain" />
            </a>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 border-t border-[#F2EDE1] pt-[18px]">
          <div className="text-text-faint text-[11.5px]">© ۱۴۰۵ فرامن — تمام حقوق محفوظ است.</div>
          <div className="text-text-faint text-[11.5px]">فرامن جایگزین مشاورهٔ تخصصی نیست.</div>
        </div>
      </div>
    </footer>
  );
}
