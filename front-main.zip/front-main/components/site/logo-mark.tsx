import Image from "next/image";

// The brand mark (public/icons/logo-mark.svg). Its aspect ratio is 626:961, so size it by height.
export function LogoMark({ height, className = "" }: { height: number; className?: string }) {
  return (
    <Image
      src="/icons/logo-mark.svg"
      alt=""
      width={Math.round((height * 626) / 961)}
      height={height}
      className={`flex-none ${className}`}
      style={{ height, width: "auto" }}
    />
  );
}
