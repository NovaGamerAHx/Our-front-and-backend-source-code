"use client";

import { usePathname, useSearchParams } from "next/navigation";
import { PublicChrome } from "@/components/workspace/public-chrome";
import { WorkspaceChrome } from "@/components/workspace/workspace-chrome";
import type { ChatSessionSummary } from "@/lib/api/schemas";

const NO_CHROME_PREFIXES = [
  "/test/questions",
  "/test/demographic",
  "/test/analysis",
  "/deep-test/questions",
  "/deep-test/analysis",
  "/chat",
];
const NO_CHROME_EXACT = ["/login"];
const FOOTER_PATHS = ["/", "/blog", "/about", "/terms"];

export function SiteChrome({
  isLoggedIn,
  workspace,
  children,
}: {
  isLoggedIn: boolean;
  workspace: { profile: { name: string | null } | null; sessions: ChatSessionSummary[] } | null;
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const workspaceRoute =
    ["/explore", "/chat", "/deep-test", "/test", "/profile"].includes(pathname) ||
    (pathname === "/" && isLoggedIn);
  const paymentId = Number(searchParams.get("deepAttemptId"));
  if (workspaceRoute || (pathname === "/paywall" && Number.isInteger(paymentId) && paymentId > 0)) {
    return <>{children}</>;
  }

  const showChrome =
    !NO_CHROME_PREFIXES.some((prefix) => pathname.startsWith(prefix)) &&
    !NO_CHROME_EXACT.includes(pathname);

  if (!showChrome) {
    return <>{children}</>;
  }

  if (isLoggedIn && workspace) {
    return (
      <WorkspaceChrome
        name={workspace.profile?.name ?? null}
        sessions={workspace.sessions}
        authenticated
        payment={false}
      >
        {children}
      </WorkspaceChrome>
    );
  }

  return (
    <PublicChrome
      overlay={pathname === "/"}
      showFooter={FOOTER_PATHS.includes(pathname)}
    >
      {children}
    </PublicChrome>
  );
}
