"use client";

import { usePathname } from "next/navigation";
import { SiteHeader } from "./site-header";
import { SiteFooter } from "./site-footer";
import { MobileTabBar } from "./mobile-tab-bar";

// The question-answering funnel (free + deep), the auth (OTP) flow, and the chat screen are
// focused, single-purpose screens — matching the design, they never show site chrome
// (header/footer/tab bar). The free-test intro and its returning-visitor screen (`/test`,
// `/test/resume`) DO show chrome now that they're reachable from the کاووش nav item. Chat also
// manages its own full-viewport height/scroll, which the tab bar's fixed overlay would break.
// Everything else gets the shared chrome.
const NO_CHROME_PREFIXES = ["/test/questions", "/test/demographic", "/test/analysis", "/chat"];
const NO_CHROME_EXACT = ["/login"];

// Both reports and the pre-login preview open on a full-bleed dark navy-gradient hero — the
// header floats transparently over it (overlaid via negative margin, white foreground) until
// scrolled. The landing's hero is a light photo (Landing v2 §1a), so it gets its own overlay
// variant: still floating/transparent pre-scroll, but with dark foreground and the landing-only
// plum accent instead of white-on-dark + blue.
const OVERLAY_LIGHT_HERO_PATHS = ["/report", "/deep-report", "/preview"];

export function SiteChrome({
  isLoggedIn,
  children,
}: {
  isLoggedIn: boolean;
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const showChrome =
    !NO_CHROME_PREFIXES.some((prefix) => pathname.startsWith(prefix)) &&
    !NO_CHROME_EXACT.includes(pathname);
  const headerVariant =
    pathname === "/"
      ? "overlay-dark"
      : OVERLAY_LIGHT_HERO_PATHS.includes(pathname)
        ? "overlay-light"
        : "solid";

  return (
    <>
      {showChrome && <SiteHeader isLoggedIn={isLoggedIn} variant={headerVariant} />}
      {children}
      {showChrome && (
        <>
          <SiteFooter />
          <div className="h-[76px] md:hidden" />
          <MobileTabBar isLoggedIn={isLoggedIn} />
        </>
      )}
    </>
  );
}
