"use client";

import { usePathname, useSearchParams } from "next/navigation";
import { SiteHeader } from "./site-header";
import { SiteFooter } from "./site-footer";
import { WorkspaceChrome } from "@/components/workspace/workspace-chrome";
import type { ChatSessionSummary } from "@/lib/api/schemas";
import { MobileTabBar } from "./mobile-tab-bar";

// The question-answering funnel (free + deep), the auth (OTP) flow, and the chat screen are
// focused, single-purpose screens — matching the design, they never show site chrome
// (header/footer/tab bar). The free-test intro and its returning-visitor screen (`/test`,
// `/test/resume`) DO show chrome now that they're reachable from the خودشناسی nav item. Chat also
// manages its own full-viewport height/scroll, which the tab bar's fixed overlay would break.
// Everything else gets the shared chrome.
const NO_CHROME_PREFIXES = ["/test/questions", "/test/demographic", "/test/analysis", "/deep-test/questions", "/deep-test/analysis", "/chat"];
const NO_CHROME_EXACT = ["/login"];

// Both reports and the pre-login preview open on a full-bleed dark navy-gradient hero — the
// header floats transparently over it (overlaid via negative margin, white foreground) until
// scrolled. The landing's hero is a light photo (Landing v2 §1a), so it gets its own overlay
// variant: still floating/transparent pre-scroll, but with dark foreground and the landing-only
// plum accent instead of white-on-dark + blue.
const OVERLAY_LIGHT_HERO_PATHS = ["/report", "/deep-report", "/preview"];

export function SiteChrome({
  isLoggedIn,
  workspace,
  children,
}: {
  isLoggedIn: boolean;
  workspace: { profile: { name: string | null } | null; sessions: ChatSessionSummary[] } | null;
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  // Only the supplied redesign routes use the new workspace. Other pages and the guest
  // landing retain their original chrome and styling.
  const workspaceRoute =
    ["/explore", "/chat", "/deep-test", "/test", "/profile"].includes(pathname) ||
    (pathname === "/" && isLoggedIn);
  const paymentId = Number(searchParams.get("deepAttemptId"));
  if (workspaceRoute || (pathname === "/paywall" && Number.isInteger(paymentId) && paymentId > 0))
    return <>{children}</>;

  const showChrome =
    !NO_CHROME_PREFIXES.some((prefix) => pathname.startsWith(prefix)) &&
    !NO_CHROME_EXACT.includes(pathname);
  // Authenticated legacy pages share the same navigation as the redesigned workspace.
  // Focused flows keep their intentionally distraction-free layout.
  if (isLoggedIn && showChrome && workspace) {
    return (
      <WorkspaceChrome name={workspace.profile?.name ?? null} sessions={workspace.sessions} authenticated payment={false}>
        {children}
      </WorkspaceChrome>
    );
  }
  const headerVariant =
    pathname === "/"
      ? "overlay-dark"
      : OVERLAY_LIGHT_HERO_PATHS.includes(pathname)
        ? "overlay-light"
        : "solid";

  return (
    <>
      {showChrome && (
        <div className="fm-legacy-chrome" style={{ display: "contents" }}>
          <SiteHeader isLoggedIn={isLoggedIn} variant={headerVariant} />
        </div>
      )}
      {children}
      {showChrome && (
        <>
          <div className="fm-legacy-chrome" style={{ display: "contents" }}>
            <SiteFooter />
            <div className="h-[76px] min-[900px]:hidden" />
            <MobileTabBar isLoggedIn={isLoggedIn} />
          </div>
        </>
      )}
    </>
  );
}
