"use client";

import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useRef, type ComponentProps } from "react";

// In-memory, per-tab history of routes seen while this app is mounted. Do not use
// window.history.length: it includes external sites and cannot identify the prior URL.
const visited: string[] = [];
export function NavigationTracker() {
  const pathname = usePathname();
  const params = useSearchParams();
  const query = params.toString();
  const popped = useRef(false);
  useEffect(() => {
    const onPop = () => { popped.current = true; };
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);
  useEffect(() => {
    const url = pathname + (query ? `?${query}` : "") + window.location.hash;
    if (pathname === "/login") return;
    if (visited[visited.length - 1] === url) { popped.current = false; return; }
    const previousIndex = popped.current ? visited.lastIndexOf(url) : -1;
    popped.current = false;
    if (previousIndex >= 0) visited.splice(previousIndex + 1);
    else visited.push(url);
    if (visited.length > 50) visited.shift();
  }, [pathname, query]);
  return null;
}

export function useAppBack(fallback: string) {
  const router = useRouter();
  return () => {
    const current = window.location.pathname + window.location.search + window.location.hash;
    const last = visited[visited.length - 1];
    const previous = last === current ? visited[visited.length - 2] : undefined;
    // Explicit route replacement avoids leaving the app on direct entry and avoids
    // sending the user back through an OTP redirect or a stale browser snapshot.
    if (previous) visited.pop();
    router.replace(previous || fallback);
  };
}

export function BackLink({ href, onClick, ...props }: ComponentProps<typeof Link> & { href: string }) {
  const goBack = useAppBack(href);
  return <Link href={href} {...props} onClick={(event) => {
    onClick?.(event);
    if (!event.defaultPrevented && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey && event.button === 0) {
      event.preventDefault();
      goBack();
    }
  }} />;
}
