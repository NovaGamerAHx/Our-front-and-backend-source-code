"use client";

import { useEffect } from "react";
import { UTM_COOKIE, UTM_COOKIE_MAX_AGE, readUtmParams } from "@/lib/analytics/utm";

/** Persists utm_source/utm_campaign from the landing URL into a cookie so they survive navigation
 *  until signup. A visit without UTM params leaves any existing cookie untouched. */
export function UtmCapture() {
  useEffect(() => {
    const { utm_source, utm_campaign } = readUtmParams();
    if (!utm_source && !utm_campaign) return;
    const value = encodeURIComponent(JSON.stringify({ utm_source, utm_campaign }));
    document.cookie = `${UTM_COOKIE}=${value}; path=/; max-age=${UTM_COOKIE_MAX_AGE}; samesite=lax${
      window.location.protocol === "https:" ? "; secure" : ""
    }`;
  }, []);

  return null;
}
