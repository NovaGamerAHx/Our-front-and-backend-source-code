"use client";

import { useEffect } from "react";
import { trackEventAction } from "@/lib/api/track-event-action";
import { readUtmParams } from "@/lib/analytics/utm";
import type { TrackEventInput } from "@/lib/api/schemas";

export function TrackOnMount({
  event,
  properties,
  withUtm = false,
}: {
  event: TrackEventInput["event_name"];
  properties?: TrackEventInput["properties"];
  /** Adds utm_source/utm_medium/utm_campaign from the current URL's query string. Read from
   *  window.location in the effect (not via `searchParams`) so the page stays statically
   *  renderable. */
  withUtm?: boolean;
}) {
  useEffect(() => {
    void trackEventAction({
      event_name: event,
      properties: withUtm ? { ...readUtmParams(), ...properties } : properties,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return null;
}
