"use client";

import Link from "next/link";
import type { ComponentProps } from "react";
import { trackEventAction } from "@/lib/api/track-event-action";
import type { TrackEventInput } from "@/lib/api/schemas";

type TrackedLinkProps = ComponentProps<typeof Link> & {
  event: TrackEventInput["event_name"];
  eventProperties?: TrackEventInput["properties"];
};

export function TrackedLink({ event, eventProperties, onClick, ...props }: TrackedLinkProps) {
  return (
    <Link
      {...props}
      onClick={(e) => {
        void trackEventAction({ event_name: event, properties: eventProperties });
        onClick?.(e);
      }}
    />
  );
}
