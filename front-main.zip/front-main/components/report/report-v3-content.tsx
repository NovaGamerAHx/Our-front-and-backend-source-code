"use client";
import { AppDownloadLink } from "@/components/site/app-download-link";
import { BackLink } from "@/components/site/back-navigation";
import Image from "next/image";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import {
  ArrowDown,
  ArrowLeft,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  LockKeyhole,
  Mail,
  MessageCircle,
  RefreshCw,
  Send,
  Sparkles,
  X,
} from "lucide-react";
import type {
  FullReportV3Response,
  PreviewReportV3Response,
  DimensionKey,
} from "@/lib/api/schemas";
import { DIMENSION_LABELS, V2_LEVEL_LABELS } from "@/lib/utils/report";
import { formatJalali } from "@/lib/utils/date";
import { toPersianDigits as digits } from "@/lib/utils/digits";
import { LogoMark } from "@/components/site/logo-mark";
import { ReportV2Feedback } from "@/components/report/report-v2-feedback";
import { sendReportEmailAction } from "@/components/report/actions";
import { ReportV3Step } from "./report-v3-step";

const SECTIONS = ["آینه", "پنج بُعد", "سه سکه", "کارت هدف", "دو یافته", "یک سؤال"];
const AREA: Record<string, string> = {
  work: "کار",
  relationship: "رابطه",
  decision: "تصمیم",
  stress: "استرس",
};
const AXES: DimensionKey[] = [
  "emotional_stability",
  "extraversion",
  "openness",
  "agreeableness",
  "conscientiousness",
];
function SectionHeading({
  n,
  title,
  children,
}: {
  n: number;
  title: string;
  children?: React.ReactNode;
}) {
  return (
    <header id={`s${n}`} className="rv-heading">
      <small>
        بخش {digits(n)} از ۶{n === 4 ? " · کارت هدف" : ""}
      </small>
      <h2>{title}</h2>
      {children && <p>{children}</p>}
    </header>
  );
}
function DeepHint({ children }: { children: React.ReactNode }) {
  return (
    <Link href="/deep-test?source=initial_report" className="rv-deep-hint">
      <span className="rv-hint-icon">
        <Sparkles size={18} />
      </span>
      <span>
        <small>در گزارش عمیق</small>
        <span>{children}</span>
      </span>
      <ChevronLeft size={18} />
    </Link>
  );
}
function Locked({ children = "بعد از ورود" }: { children?: React.ReactNode }) {
  return (
    <span className="rv-locked">
      <LockKeyhole size={15} />
      {children}
    </span>
  );
}

export function ReportV3Content({
  result,
  attemptId,
  completedAt,
}: {
  result: FullReportV3Response | PreviewReportV3Response;
  attemptId: number;
  completedAt?: string;
}) {
  const full = result.stage === "full";
  const report = full ? result.report : null;
  const hook = full ? result.report.hook : result.preview.hook;
  const scores = full ? result.dimension_scores : result.preview.dimension_scores;
  const coins = full ? result.report.coins : result.preview.coins_front;
  const findings = full ? result.report.findings : result.preview.findings;
  const [active, setActive] = useState(1);
  const [selected, setSelected] = useState<DimensionKey | null>("emotional_stability");
  const [showAsk, setShowAsk] = useState(false);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [emailOpen, setEmailOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [sending, setSending] = useState(false);
  const [emailStatus, setEmailStatus] = useState("");
  const [draft, setDraft] = useState("");
  useEffect(() => {
    const update = () => setShowAsk(window.scrollY > 600);
    update();
    window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, []);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const login = `/login?${new URLSearchParams({ next: `/report?attemptId=${attemptId}` })}`;
  const chat = (source = "report_cta", message?: string) => {
    const q = new URLSearchParams({
      entry_source: source,
      attempt_id: String(attemptId),
      from: `/report?attemptId=${attemptId}`,
    });
    if (message) q.set("initial_message", message);
    return `/chat?${q}`;
  };
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (visible[0]) setActive(Number(visible[0].target.id.slice(1)));
      },
      { rootMargin: "-15% 0px -65% 0px" },
    );
    SECTIONS.forEach((_, i) => {
      const element = document.getElementById(`s${i + 1}`);
      if (element) observer.observe(element);
    });
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    if (emailOpen) dialogRef.current?.showModal();
    else dialogRef.current?.close();
  }, [emailOpen]);
  const toc = (
    <nav aria-label="بخش‌های گزارش" className="rv-toc">
      <div>
        <strong>در این گزارش</strong>
        <small>
          <span className="rv-toc-desktop">{digits(active)} از ۶</span>
          <span className="rv-toc-mobile">۶ بخش · حدود ۷ دقیقه</span>
        </small>
      </div>
      <span className="rv-toc-progress">
        <i style={{ width: `${(active / 6) * 100}%` }} />
      </span>
      {SECTIONS.map((title, i) => (
        <a key={title} href={`#s${i + 1}`} className={active === i + 1 ? "is-active" : ""}>
          <span>{digits(i + 1)}</span>
          {title}
        </a>
      ))}
      {full && (
        <p className="rv-toc-guidance">
          <MessageCircle size={15} />
          کنار بیشتر بخش‌ها می‌توانی با فرامن درباره‌اش حرف بزنی.
        </p>
      )}
    </nav>
  );
  // Full geometry uses backend numbers. Preview geometry encodes categories only, never fake scores.
  const levelRadius = { very_low: 8, low: 24, medium: 40, medium_high: 56, high: 72 };
  const radiusFor = (key: DimensionKey) => {
    if (result.stage === "full") {
      const score = result.dimension_scores.find((d) => d.key === key)?.score_percent;
      return typeof score === "number" && Number.isFinite(score)
        ? Math.max(0, Math.min(100, score)) * 0.8
        : 0;
    }
    const level = result.preview.dimension_scores.find((d) => d.key === key)?.level;
    return level ? levelRadius[level] : 0;
  };
  const point = (i: number, r: number) =>
    [
      100 + Math.cos(((-90 + i * 72) * Math.PI) / 180) * r,
      100 + Math.sin(((-90 + i * 72) * Math.PI) / 180) * r,
    ].join(",");
  const radar = (
    <svg
      viewBox="-84 -30 368 238"
      role="img"
      aria-label={
        full
          ? `امتیازهای واقعی پنج بُعد؛ ${result.dimension_scores.map((d) => `${DIMENSION_LABELS[d.key]}: ${"score_percent" in d ? d.score_percent : ""} از ۱۰۰`).join("، ")}`
          : "نمای سطح پنج بُعد؛ نمودار کیفی، نه امتیاز عددی"
      }
    >
      {[80, 53, 26].map((r) => (
        <polygon
          key={r}
          points={AXES.map((_, i) => point(i, r)).join(" ")}
          fill="none"
          stroke="#3A3248"
        />
      ))}
      {AXES.map((_, i) => (
        <path key={i} d={`M100 100 L${point(i, 80).replace(",", " ")}`} stroke="#332B40" />
      ))}
      <polygon
        points={AXES.map((key, i) => {
          return point(i, radiusFor(key));
        }).join(" ")}
        fill="#C3B4EA"
        fillOpacity=".18"
        stroke="#C3B4EA"
        strokeWidth="2.5"
      />
      {AXES.map((key, i) => {
        const d = scores.find((item) => item.key === key);
        const radius = radiusFor(key);
        const xy = point(i, radius).split(",").map(Number);
        const labels = [
          { x: 100, y: -14, a: "middle" },
          { x: 184, y: 70, a: "start" },
          { x: 150, y: 184, a: "middle" },
          { x: 50, y: 184, a: "middle" },
          { x: 16, y: 70, a: "end" },
        ] as const;
        const pos = labels[i];
        const color = ["#A98AD8", "#64A0EC", "#E8A65E", "#EA7A74", "#74BC83"][i];
        return (
          <g key={key}>
            <circle cx={xy[0]} cy={xy[1]} r={5.5} fill={color} stroke="#231C2C" strokeWidth={2} />
            <text
              x={pos.x}
              y={pos.y}
              textAnchor={pos.a}
              fontSize={13}
              fontWeight={700}
              fill="#F3EEE6"
            >
              {DIMENSION_LABELS[key]}
            </text>
            <text x={pos.x} y={pos.y + 16} textAnchor={pos.a} fontSize={12.5} fill={color}>
              {d ? V2_LEVEL_LABELS[d.level] : ""}
            </text>
          </g>
        );
      })}
    </svg>
  );
  return (
    <>
      {!full && (
        <header className="rv-preview-header">
          <Link href="/" className="rv-brand">
            <LogoMark height={36} />
            فرامن
          </Link>
          <Link href={login} className="rv-button rv-outline">
            ورود
          </Link>
        </header>
      )}
      <header className="rv-mobile-header">
        <BackLink href={full ? "/explore" : "/test"} aria-label="برگشت">
          <ChevronRight size={22} />
        </BackLink>
        <strong>گزارش خودشناسی اولیه</strong>
        {full ? (
          <button aria-label="فرستادن به ایمیل" onClick={() => setEmailOpen(true)}>
            <Mail size={20} />
          </button>
        ) : (
          <Link href={login}>ورود</Link>
        )}
        <span className="rv-progress" style={{ width: `${(active / 6) * 100}%` }} />
      </header>
      <main className="rv-page">
        <section className="rv-hero">
          <div className="rv-hero-copy">
            <small>
              گزارش خودشناسی اولیه{completedAt ? ` · ${formatJalali(completedAt)}` : ""}
            </small>
            <h1>{hook}</h1>
            <p>
              ساخته‌شده از ۳۰ جوابی که دادی{" "}
              <span className="rv-desktop-inline">· ۶ بخش · حدود ۷ دقیقه</span>
            </p>
            <div className="rv-hero-actions">
              {full ? (
                <>
                  <a className="rv-button rv-cream" href="#s1">
                    شروع خواندن <ArrowDown size={17} />
                  </a>
                  <button className="rv-button rv-outline" onClick={() => setEmailOpen(true)}>
                    <Mail size={17} />
                    فرستادن به ایمیل
                  </button>
                </>
              ) : (
                <>
                  <Link href={login} className="rv-button rv-primary">
                    دیدن گزارش کامل <ArrowLeft size={18} />
                  </Link>
                  <small>رایگان است. گزارشت فقط برای خودت است.</small>
                </>
              )}
            </div>
            <AppDownloadLink source="report_v3" className="rv-app-download inline-flex min-h-11 items-center gap-2 text-sm font-bold text-white underline underline-offset-4" />
          </div>
          <Image src="/report-v3/hero.jpg" width={894} height={785} alt="" priority />
        </section>
        <div className="rv-mobile-toc">
          {toc}
          {full && (
            <button className="rv-email-strip" onClick={() => setEmailOpen(true)}>
              <Mail size={22} />
              <span>
                <strong>یک نسخه برای خودت</strong>
                <small>گزارش را به ایمیلت می‌فرستیم.</small>
              </span>
              <b>بفرست</b>
            </button>
          )}
        </div>
        <div className="rv-layout">
          <div className="rv-sections">
            <section>
              <SectionHeading n={1} title="آینه">
                تو از بیرون، از درون، و چیزی که کمتر می‌بینی.
              </SectionHeading>
              <div className="rv-card rv-mirror">
                {(
                  [
                    ["outer", "از بیرون"],
                    ["inner", "از درون"],
                    ["blind_spot", "چیزی که کمتر می‌بینی"],
                  ] as const
                ).map(([key, title]) => (
                  <div key={key}>
                    <small>{title}</small>
                    {report ? <p>{report.mirror[key]}</p> : <Locked />}
                  </div>
                ))}
              </div>
              {full && <DeepHint>الگوهای رفتارت، هرکدام با نشانه‌هایش</DeepHint>}
            </section>
            <section>
              <SectionHeading n={2} title="پنج بُعد شخصیت تو">
                کنار هر بُعد، سطح تو آمده.{" "}
                {full
                  ? "روی هر بُعد بزن تا ببینی در رفتارت چطور دیده می‌شود."
                  : "توضیح هر بُعد بعد از ورود باز می‌شود."}
              </SectionHeading>
              <div className="rv-dimensions">
                <div className="rv-chart-card">{radar}</div>
                <div className="rv-dimension-list">
                  {scores.map((d) => (
                    <details key={d.key} open={full && selected === d.key}>
                      <summary
                        onClick={(e) => {
                          e.preventDefault();
                          setSelected((current) => (current === d.key ? null : d.key));
                        }}
                      >
                        <span>{DIMENSION_LABELS[d.key]}</span>
                        <b>{V2_LEVEL_LABELS[d.level]}</b>
                        {full ? <ChevronDown size={16} /> : <LockKeyhole size={15} />}
                      </summary>
                      {report && <p>{report.dimension_insights[d.key]}</p>}
                    </details>
                  ))}
                </div>
              </div>
              {full && <DeepHint>هر بُعد به ۶ ویژگی ریزتر شکسته می‌شود؛ یعنی ۳۰ ویژگی</DeepHint>}
            </section>
            <section>
              <SectionHeading n={3} title="سه سکه">
                هر قوتی روی دیگری هم دارد. کارت را لمس کن تا برگردد.
              </SectionHeading>
              <div className="rv-coins">
                {coins.map((coin, i) => {
                  const back = flipped.includes(i);
                  const fullCoin = report?.coins[i];
                  return (
                    <article className={`rv-coin rv-coin-${i}`} key={i}>
                      <div>
                        <small>سکه‌ی {digits(i + 1)}</small>
                        <span>{back ? "روی دیگر" : "روی اول"}</span>
                      </div>
                      <h3>
                        {back
                          ? (fullCoin?.back_title ?? "روی دیگر این سکه بعد از ورود")
                          : coin.front_title}
                      </h3>
                      <p>
                        {back
                          ? (fullCoin?.back_text ?? "می‌بینی همین قوت کجا برایت گران تمام می‌شود.")
                          : coin.front_text}
                      </p>
                      {back && !full ? (
                        <Link className="rv-button rv-outline" href={login}>
                          <LockKeyhole size={15} />
                          ورود و دیدن
                        </Link>
                      ) : (
                        <button
                          aria-pressed={back}
                          onClick={() =>
                            setFlipped((v) =>
                              v.includes(i) ? v.filter((n) => n !== i) : [...v, i],
                            )
                          }
                        >
                          <RefreshCw size={15} />
                          برگردان
                        </button>
                      )}
                    </article>
                  );
                })}
              </div>
            </section>
            <section>
              <SectionHeading
                n={4}
                title={report?.goal_card.title ?? (!full ? result.preview.goal_card_title : "")}
              >
                جایی که این ویژگی‌ها خودشان را نشان می‌دهند
              </SectionHeading>
              <div className="rv-card rv-goal">
                {report ? (
                  <>
                    <p className="rv-goal-insight">{report.goal_card.bottleneck_insight}</p>
                    <div className="rv-goal-columns">
                      <div>
                        <h3>به کارت می‌آید</h3>
                        <ul>
                          {report.goal_card.helps.map((t) => (
                            <li key={t}>{t}</li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h3>گاهی کار را سخت می‌کند</h3>
                        <ul>
                          {report.goal_card.hard.map((t) => (
                            <li key={t}>{t}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                    <Link
                      className="rv-button rv-primary"
                      href={chat(
                        "report_goal",
                        `می‌خواهم «${report.goal_card.title}» را روی موقعیت الانم بررسی کنم.`,
                      )}
                    >
                      <MessageCircle size={18} />
                      این را روی موقعیت الانت با فرامن بررسی کن
                    </Link>
                  </>
                ) : (
                  <Locked>اینکه کجا به کارت می‌آید و کجا کار را سخت می‌کند، بعد از ورود</Locked>
                )}
              </div>
              {full && (
                <DeepHint>سبک تصمیم‌گیری‌ات، و جایی که بیشترین وقت را از تو می‌گیرد</DeepHint>
              )}
            </section>
            <section>
              <SectionHeading n={5} title="دو یافته">
                دو موقعیت از زندگی روزمره که این ویژگی‌ها در آن‌ها دیده می‌شوند.
              </SectionHeading>
              <div className="rv-findings">
                {findings.map((finding, i) => {
                  const detail = report?.findings[i];
                  return (
                    <article
                      className={`rv-finding ${!detail ? "rv-finding-preview" : ""}`}
                      key={i}
                    >
                      <Image
                        src={`/report-v3/finding-${i + 1}.jpg`}
                        width={919}
                        height={576}
                        alt=""
                      />
                      <div className="rv-finding-body">
                        <div className="rv-finding-meta">
                          <span>{AREA[finding.area] ?? finding.area}</span>
                          <small>
                            یافته‌ی {digits(i + 1)} از {digits(findings.length)}
                          </small>
                        </div>
                        <h3>{finding.title}</h3>
                        {detail ? (
                          <>
                            <p>{detail.what}</p>
                            <details>
                              <summary>
                                بیشتر درباره‌ی این یافته <ChevronDown size={17} />
                              </summary>
                              <div>
                                <h4>هزینه‌اش</h4>
                                <p>{detail.cost}</p>
                                <h4>یک نکته‌ی جالب</h4>
                                <p>{detail.curiosity}</p>
                              </div>
                            </details>
                            {detail.suggested_step && (
                              <div className="rv-suggested">
                                <small>
                                  یک پیشنهاد کوچک · {detail.suggested_step.deadline_text}
                                </small>
                                <p>{detail.suggested_step.text}</p>
                                <ReportV3Step attemptId={attemptId} index={i + 1} />
                              </div>
                            )}
                            <Link
                              className="rv-button rv-outline"
                              href={chat(
                                `report_finding_focus:${i}`,
                                `می‌خواهم درباره‌ی «${finding.title}» بیشتر حرف بزنم.`,
                              )}
                            >
                              <MessageCircle size={17} />
                              درباره‌ی این یافته با فرامن حرف بزن
                            </Link>
                          </>
                        ) : (
                          <Locked>موقعیت، هزینه‌اش و یک پیشنهاد، بعد از ورود</Locked>
                        )}
                      </div>
                      {full && (
                        <DeepHint>
                          {i === 0
                            ? "سبک ارتباطی‌ات با آدم‌ها، و جایی که حرفت کمتر شنیده می‌شود"
                            : "سبک کاری‌ات، و محیطی که در آن بهتر کار می‌کنی"}
                        </DeepHint>
                      )}
                    </article>
                  );
                })}
              </div>
            </section>
            {full && (
              <section className="rv-card rv-chat-box">
                <h2>درباره‌ی این گزارش حرف بزنیم؟</h2>
                <p>
                  هر جای گزارش که برایت سؤال شد یا با موقعیتی در زندگی‌ات جور درآمد، با فرامن
                  درباره‌اش حرف بزن. فرامن این گزارش را می‌شناسد.
                </p>
                <form action="/chat" className="rv-composer">
                  <input type="hidden" name="entry_source" value="report_cta" />
                  <input type="hidden" name="attempt_id" value={attemptId} />
                  <input type="hidden" name="from" value={`/report?attemptId=${attemptId}`} />
                  <input
                    name="initial_message"
                    aria-label="پیام درباره‌ی گزارش"
                    maxLength={2000}
                    required
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    placeholder="بنویس…"
                  />
                  <button aria-label="ارسال به گفت‌وگو" disabled={!draft.trim()}>
                    <Send size={18} />
                  </button>
                </form>
                <div className="rv-prompts">
                  {[
                    "از کجا شروع کنم؟",
                    "یک جایش با من نمی‌خواند",
                    "این را در کارم چطور به کار ببرم؟",
                  ].map((t) => (
                    <Link key={t} href={chat("report_cta", t)}>
                      {t}
                    </Link>
                  ))}
                </div>
              </section>
            )}
            <section>
              <SectionHeading n={6} title="یک سؤال برای تو" />
              {report ? (
                <div className="rv-exit">
                  <p>{report.exit.bridge}</p>
                  <h3>چه چیزی پشت این رفتارهاست؟</h3>
                  <p>{report.exit.root_question}</p>
                </div>
              ) : (
                <div className="rv-card">
                  <p>این دو رفتار شاید یک ریشه داشته باشند:</p>
                  <Locked />
                  <h3>چه چیزی پشت این رفتارهاست؟</h3>
                  <Locked>سؤالی که برای تو نوشته شده، بعد از ورود</Locked>
                </div>
              )}
            </section>
            {full && (
              <section className="rv-deep-cta">
                <small>قدم بعدی</small>
                <h2>آزمون خودشناسی عمیق</h2>
                <p>شناخت دقیق‌تری از ویژگی‌ها و سبک تو در زندگی روزمره.</p>
                <ul>
                  <li>۳۰ ویژگی شخصیتی، به‌جای ۵ بُعد</li>
                  <li>قوت‌ها و چیزهایی که کمتر می‌بینی، با نشانه‌هایشان</li>
                  <li>سبک تو در تصمیم، رابطه و کار</li>
                  <li>اینکه استرس و انرژی‌ات چطور کار می‌کنند</li>
                </ul>
                <small>۳۰ کارت پنج‌سؤالی · حدود ۲۵ دقیقه</small>
                <Link className="rv-button rv-cream" href="/deep-test?source=initial_report">
                  شناخت عمیق‌تر خودم <ArrowLeft size={18} />
                </Link>
              </section>
            )}
            {full && result.report_id && (
              <div className="rv-feedback">
                <ReportV2Feedback reportId={result.report_id} />
              </div>
            )}
            <p className="rv-disclaimer">
              این گزارش برای خودشناسی است، نه تشخیص روان‌شناختی. اگر حالت خوب نیست، با یک متخصص حرف
              بزن.
            </p>
            {!full && (
              <section className="rv-login-card" id="login">
                <LockKeyhole size={28} />
                <h2>گزارش کاملت آماده است</h2>
                <p>با ورود، این‌ها برایت باز می‌شود و گزارش در حسابت می‌ماند:</p>
                <ul>
                  <li>متن آینه و توضیح هر بُعد</li>
                  <li>روی دیگر سه سکه</li>
                  <li>کارت هدف و دو یافته، کامل</li>
                  <li>یک سؤال برای تو، و گفت‌وگو با فرامن</li>
                </ul>
                <Link href={login} className="rv-button rv-primary">
                  ورود و دیدن گزارش کامل
                </Link>
                <small>رایگان است. گزارشت فقط برای خودت است.</small>
              </section>
            )}
          </div>
          <aside className="rv-context">
            {!full && (
              <div className="rv-aside-login">
                <h3>گزارش کاملت آماده است</h3>
                <p>با ورود، این‌ها برایت باز می‌شود و گزارش در حسابت می‌ماند:</p>
                <ul>
                  <li>متن آینه و توضیح هر بُعد</li>
                  <li>روی دیگر سه سکه</li>
                  <li>کارت هدف و دو یافته، کامل</li>
                  <li>یک سؤال برای تو، و گفت‌وگو با فرامن</li>
                </ul>
                <Link href={login} className="rv-button rv-cream">
                  ورود و دیدن گزارش کامل
                </Link>
                <small>رایگان است. گزارشت فقط برای خودت است.</small>
              </div>
            )}
            {toc}
            {full && (
              <>
                <div className="rv-card">
                  <h3>گفت‌وگو درباره‌ی گزارش</h3>
                  <form action="/chat" className="rv-composer rv-context-composer">
                    <input type="hidden" name="entry_source" value="report_cta" />
                    <input type="hidden" name="attempt_id" value={attemptId} />
                    <input type="hidden" name="from" value={`/report?attemptId=${attemptId}`} />
                    <input
                      name="initial_message"
                      aria-label="پرسش از فرامن درباره‌ی گزارش"
                      value={draft}
                      onChange={(e) => setDraft(e.target.value)}
                      placeholder="از فرامن بپرس…"
                      maxLength={2000}
                      required
                    />
                    <button aria-label="فرستادن پرسش درباره‌ی گزارش" disabled={!draft.trim()}>
                      <Send size={16} />
                    </button>
                  </form>
                  <div className="rv-prompts">
                    {["از کجا شروع کنم؟", "یک جایش با من نمی‌خواند"].map((t) => (
                      <Link key={t} href={chat("report_cta", t)}>
                        {t}
                      </Link>
                    ))}
                  </div>
                </div>
                <Link href="/deep-test?source=initial_report" className="rv-card rv-next">
                  <small>قدم بعدی</small>
                  <h3>آزمون خودشناسی عمیق</h3>
                  <p>۳۰ ویژگی شخصیتی، و سبک تو در تصمیم، رابطه و کار.</p>
                  <b>
                    شناخت عمیق‌تر خودم <ChevronLeft size={16} />
                  </b>
                </Link>
              </>
            )}
          </aside>
        </div>
      </main>
      {full ? (
        <Link className={`rv-mobile-ask ${showAsk ? "is-shown" : ""}`} href={chat()}>
          <LogoMark height={28} />
          از فرامن بپرس
          <MessageCircle size={18} />
        </Link>
      ) : (
        <div className="rv-mobile-login">
          <Link className="rv-button rv-primary" href={login}>
            <LockKeyhole size={18} />
            ورود و دیدن گزارش کامل
          </Link>
          <small>رایگان است. گزارشت فقط برای خودت است.</small>
        </div>
      )}
      <dialog
        ref={dialogRef}
        className="rv-email-dialog"
        aria-labelledby="rv-email-title"
        onCancel={() => setEmailOpen(false)}
        onClick={(e) => {
          if (e.target === e.currentTarget) setEmailOpen(false);
        }}
      >
        <div className="fm-report-v3">
          <button aria-label="بستن" className="rv-dialog-close" onClick={() => setEmailOpen(false)}>
            <X size={20} />
          </button>
          <h2 id="rv-email-title">یک نسخه برای خودت</h2>
          <p>گزارش را به ایمیلت می‌فرستیم.</p>
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              setSending(true);
              setEmailStatus("");
              const response = await sendReportEmailAction(attemptId, email.trim());
              setSending(false);
              setEmailStatus(response.ok ? "گزارش به ایمیلت فرستاده شد." : response.message);
            }}
          >
            <label htmlFor="rv-email">ایمیل</label>
            <input
              id="rv-email"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              dir="ltr"
            />
            <button className="rv-button rv-primary" disabled={sending}>
              {sending ? "در حال ارسال…" : "بفرست"}
            </button>
          </form>
          <p role="status">{emailStatus}</p>
        </div>
      </dialog>
    </>
  );
}
