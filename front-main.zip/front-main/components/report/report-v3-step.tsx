"use client";
import { useState } from "react";
import { acceptReportStepAction } from "@/components/action-steps/actions";
export function ReportV3Step({ attemptId, index }: { attemptId: number; index: number }) {
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  return (
    <div>
      <button
        type="button"
        className="fm-button fm-outline"
        disabled={busy || saved}
        onClick={async () => {
          setBusy(true);
          setError(null);
          const result = await acceptReportStepAction(attemptId, index);
          setBusy(false);
          if (result.ok) setSaved(true);
          else setError(result.message);
        }}
      >
        {saved ? "قدم ثبت شد" : busy ? "در حال ثبت…" : "این قدم را برمی‌دارم"}
      </button>
      {error && <p role="alert">{error}</p>}
    </div>
  );
}
