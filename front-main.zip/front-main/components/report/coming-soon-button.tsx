"use client";

import { toast } from "sonner";
import type { ComponentProps } from "react";

/** Some report screens (paywall, feedback) aren't built yet — keep the CTAs visible for content
 * fidelity but make that explicit instead of linking to a 404. */
export function ComingSoonButton({ children, className, ...props }: ComponentProps<"button">) {
  return (
    <button
      type="button"
      onClick={() => toast("این بخش به‌زودی اضافه می‌شود.")}
      className={className}
      {...props}
    >
      {children}
    </button>
  );
}
