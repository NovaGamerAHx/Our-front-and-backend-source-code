"use client";

import { useState } from "react";
import type { DeadlineType } from "@/lib/api/schemas";
import { DEADLINE_OPTIONS } from "@/lib/utils/action-step";
import { useSheetDrag } from "@/components/ui/use-sheet-drag";

// The popup for "ویرایش" on the report's small-step box. Accepting happens inline in the card; this
// sheet only edits the text and deadline, same layout as the proposal sheet's editing state.
export function ReportV2StepEditSheet({
  text,
  deadlineType,
  onSave,
  onClose,
}: {
  text: string;
  deadlineType: DeadlineType;
  onSave: (text: string, deadlineType: DeadlineType) => void;
  onClose: () => void;
}) {
  const [draftText, setDraftText] = useState(text);
  const [draftDeadline, setDraftDeadline] = useState(deadlineType);
  const { sheetRef, sheetStyle, sheetProps, handleProps } = useSheetDrag(onClose);

  return (
    <div className="fixed inset-0 z-[75] flex flex-col items-center justify-end" dir="rtl">
      <button
        type="button"
        aria-label="بستن"
        onClick={onClose}
        className="animate-fm-fade absolute inset-0 cursor-default bg-[rgba(30,26,20,.46)]"
      />
      <div
        ref={sheetRef}
        style={sheetStyle}
        {...sheetProps}
        className="animate-fm-sheet relative flex max-h-[90vh] w-full max-w-[440px] flex-col gap-4 overflow-y-auto rounded-t-[26px] bg-white px-[22px] pt-2.5 pb-6 shadow-[0_-12px_40px_rgba(40,30,10,.18)]"
      >
        <div
          {...handleProps}
          className="-mx-[22px] flex cursor-grab justify-center py-2 active:cursor-grabbing"
        >
          <div className="h-[5px] w-[42px] rounded-full bg-[#E7E2D6]" />
        </div>
        <div className="text-[11.5px] font-extrabold text-[#8E6BA8]">قدم پیشنهادی</div>
        <div className="flex flex-col gap-3.5">
          <div className="text-[14px] font-extrabold text-[#242A38]">
            متن و مهلت را خودت تنظیم کن
          </div>
          <textarea
            value={draftText}
            onChange={(e) => setDraftText(e.target.value)}
            dir="rtl"
            rows={4}
            className="w-full resize-none rounded-2xl border-[1.5px] border-[#E7E2D6] bg-[#FBF8F1] px-4 py-3.5 text-[15px] leading-[2] text-[#242A38] outline-none focus:border-[#6B4FA8]"
          />
          <div className="flex flex-col gap-2">
            <div className="text-[11.5px] font-extrabold text-[#8B8676]">مهلت</div>
            <div className="flex flex-wrap gap-1.5">
              {DEADLINE_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setDraftDeadline(opt.value)}
                  className={
                    opt.value === draftDeadline
                      ? "min-h-11 cursor-pointer rounded-full border-[1.5px] border-[#6B4FA8] bg-[#6B4FA8] px-4 py-[11px] text-[12.5px] font-bold text-white"
                      : "min-h-11 cursor-pointer rounded-full border-[1.5px] border-[#E7E2D6] bg-white px-4 py-[11px] text-[12.5px] font-bold text-[#242A38]"
                  }
                >
                  {opt.label}
                </button>
              ))}
            </div>
            <div className="text-[11px] leading-[1.85] text-[#A9A597]">
              تا وقتی خودت مهلت را عوض نکنی، همان مهلت اول می‌ماند — بازنویسی متن آن را جلو
              نمی‌اندازد.
            </div>
          </div>
          <div className="flex gap-2.5">
            <button
              type="button"
              onClick={() => onSave(draftText.trim() || text, draftDeadline)}
              className="min-h-12 flex-1 cursor-pointer rounded-[15px] bg-[#6B4FA8] p-3.5 text-sm font-extrabold text-white"
            >
              ثبت ویرایش
            </button>
            <button
              type="button"
              onClick={onClose}
              className="min-h-12 flex-1 cursor-pointer rounded-[15px] border-[1.5px] border-[#E7E2D6] bg-white p-3.5 text-[13.5px] font-bold text-[#8B8676]"
            >
              بی‌خیال
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
