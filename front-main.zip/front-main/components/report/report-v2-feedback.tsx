"use client";

import { useState, useTransition } from "react";
import { toast } from "sonner";
import { submitFeedbackAction } from "@/app/report/feedback/actions";
import { toPersianDigits } from "@/lib/utils/digits";

// The design's "Report v3 · Feedback" block: the same rating + tags + comment as /report/feedback,
// inline at the end of the report so the reader doesn't have to leave the page.

const RATINGS = [1, 2, 3, 4, 5];
// Same split as the design: 4-5 ask what landed, 1-3 ask where it missed.
const HIGH_TAGS = ["دقیق بود", "چیز تازه‌ای درباره‌ی خودم فهمیدم", "یافته‌ها ملموس بودند", "لحنش خوب بود"];
const LOW_TAGS = ["خیلی کلی بود", "مواردی که گفت را خودم می‌دانستم", "لحنش به دلم ننشست"];
const HIGH_QUESTION = "چه چیزی بیشتر به دلت نشست؟";
const LOW_QUESTION = "کجا درباره‌ی تو درست نبود؟";

export function ReportV2Feedback({ reportId }: { reportId: number }) {
  const [rating, setRating] = useState(0);
  const [tags, setTags] = useState<string[]>([]);
  const [comment, setComment] = useState("");
  const [done, setDone] = useState(false);
  const [isPending, startTransition] = useTransition();
  const canSubmit = rating > 0 && !isPending;
  const isHigh = rating >= 4;
  const tagOptions = isHigh ? HIGH_TAGS : LOW_TAGS;

  function pickRating(n: number) {
    // The tag set differs between 1-3 and 4-5, so a pick from the other set must not carry over.
    if ((n >= 4) !== isHigh) setTags([]);
    setRating(n);
  }

  function submit() {
    if (!canSubmit) return;
    startTransition(async () => {
      const result = await submitFeedbackAction(reportId, rating, tags, comment.trim());
      if (!result.ok) {
        toast.error(result.message);
        return;
      }
      setDone(true);
    });
  }

  return (
    <section className="mt-[clamp(16px,3vw,32px)] flex flex-col items-center gap-6 rounded-[28px] border-[1.5px] border-[rgba(195,174,235,.4)] bg-[#2B2139] px-[clamp(18px,4vw,48px)] py-[clamp(24px,4.5vw,48px)] text-center shadow-[0_24px_60px_-24px_rgba(0,0,0,.6)]">
      {done ? (
        <div className="animate-fm-in flex flex-col items-center gap-3">
          <div className="grid size-[60px] place-items-center rounded-full bg-[rgba(195,174,235,.18)] text-[26px] text-[#C3AEEB]">
            ✓
          </div>
          <div className="text-[clamp(19px,2.2vw,24px)] font-extrabold text-[#F3EFE8]">ممنون، نظرت ثبت شد.</div>
          <p className="max-w-[420px] text-[14.5px] leading-[2] text-[#C9C2D3] text-pretty">
            با همین پاسخ‌هاست که گزارش‌های فرامن دقیق‌تر می‌شوند.
          </p>
          <button
            type="button"
            onClick={() => setDone(false)}
            className="min-h-11 cursor-pointer p-2 text-[13px] font-bold text-[#C3AEEB] hover:text-[#F3EFE8]"
          >
            تغییر پاسخ
          </button>
        </div>
      ) : (
        <>
          <div className="flex flex-col items-center gap-2.5">
            <div className="text-[13px] font-extrabold text-[#C3AEEB]">نظر تو درباره‌ی این گزارش</div>
            <h2 className="text-[clamp(22px,3vw,32px)] leading-[1.6] font-extrabold text-balance text-[#F3EFE8]">
              این گزارش چقدر تو را درست شناخت؟
            </h2>
            <p className="max-w-[460px] text-[14.5px] leading-[2] text-[#C9C2D3] text-pretty">
              پاسخت مستقیم دقت گزارش‌های بعدی را بالاتر می‌برد.
            </p>
          </div>

          <div className="flex w-full max-w-[560px] flex-col gap-2.5">
            <div className="grid grid-cols-5 gap-[clamp(6px,1.4vw,12px)]">
              {RATINGS.map((n) => (
                <button
                  key={n}
                  type="button"
                  aria-label={toPersianDigits(n)}
                  aria-pressed={rating === n}
                  onClick={() => pickRating(n)}
                  className={`h-[clamp(58px,7vw,72px)] cursor-pointer rounded-[18px] text-[clamp(20px,2.4vw,26px)] font-extrabold transition-[background,transform] duration-150 hover:border-[#C3AEEB] ${
                    rating === n
                      ? "scale-[1.04] border-[1.5px] border-[#C3AEEB] bg-[#C3AEEB] text-[#1E1428]"
                      : "border-[1.5px] border-white/14 bg-[#15121B] text-[#F3EFE8]"
                  }`}
                >
                  {toPersianDigits(n)}
                </button>
              ))}
            </div>
            <div className="flex justify-between gap-3 text-[12.5px] font-bold text-[#A79FB3]">
              <span>اصلاً شبیه من نبود</span>
              <span>دقیقاً خودم بودم</span>
            </div>
          </div>

          {rating > 0 && (
            <div className="animate-fm-in flex w-full max-w-[560px] flex-col gap-3">
              <div className="text-[15px] font-extrabold text-[#F3EFE8]">{isHigh ? HIGH_QUESTION : LOW_QUESTION}</div>
              <div className="flex flex-wrap justify-center gap-2">
                {tagOptions.map((tag) => {
                  const on = tags.includes(tag);
                  return (
                    <button
                      key={tag}
                      type="button"
                      aria-pressed={on}
                      onClick={() => setTags((prev) => (on ? prev.filter((t) => t !== tag) : [...prev, tag]))}
                      className={`min-h-11 cursor-pointer rounded-full border px-4 py-2.5 text-[13.5px] font-bold ${
                        on
                          ? "border-[#C3AEEB] bg-[#C3AEEB] text-[#1E1428]"
                          : "border-white/14 bg-[#15121B] text-[#D9D1E6]"
                      }`}
                    >
                      {tag}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <div className="flex w-full max-w-[560px] flex-col gap-3 border-t border-white/10 pt-5">
            <div className="text-right text-[15px] font-extrabold text-[#F3EFE8]">نظرت را بنویس</div>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={4}
              placeholder="کدام بخش گزارش درباره‌ی تو درست بود و کدام نه؟ هر چیزی که به ذهنت می‌رسد…"
              className="box-border w-full resize-y rounded-2xl border-[1.5px] border-[rgba(195,174,235,.35)] bg-[#15121B] px-4 py-3.5 text-right text-[15px] leading-[1.9] text-[#F3EFE8] outline-none placeholder:text-[#8E879A]"
            />
            <button
              type="button"
              onClick={submit}
              disabled={!canSubmit}
              className={`min-h-14 rounded-full px-6 py-[15px] text-base font-extrabold ${
                canSubmit
                  ? "cursor-pointer bg-[#C3AEEB] text-[#1E1428] hover:bg-[#D4C3F2]"
                  : "cursor-not-allowed bg-white/8 text-[#8E879A]"
              }`}
            >
              {isPending ? "در حال ارسال…" : "ثبت نظرم"}
            </button>
          </div>
        </>
      )}
    </section>
  );
}
