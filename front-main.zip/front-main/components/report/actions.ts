"use server";

import { ApiError } from "@/lib/api/client";
import { sendReportEmail } from "@/lib/api/endpoints";

type ActionResult = { ok: true } | { ok: false; message: string };

const GENERIC_ERROR = "ارسال ایمیل با خطا مواجه شد. لطفاً دوباره تلاش کنید.";

export async function sendReportEmailAction(attemptId: number, email: string): Promise<ActionResult> {
  try {
    await sendReportEmail(attemptId, email);
    return { ok: true };
  } catch (error) {
    return { ok: false, message: error instanceof ApiError ? error.message : GENERIC_ERROR };
  }
}
