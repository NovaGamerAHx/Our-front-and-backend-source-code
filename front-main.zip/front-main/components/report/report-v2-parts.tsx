import Image from "next/image";
import { toPersianDigits } from "@/lib/utils/digits";
import { DIMENSION_LABELS, FINDING_AREA_LABELS, V2_LEVEL_LABELS } from "@/lib/utils/report";
import type { DimensionKey, DimensionLevel, FindingArea } from "@/lib/api/schemas";

// Shared pieces of the v2 initial report and its pre-login preview ("Faraman App.dc.html", screens
// "گزارش اولیه — نسخهٔ جدید" and "پیش‌نمایش — نسخهٔ جدید"; the file's internal ids say reportV3 /
// previewV3, but this is the backend's `report_v2`). Both are the same dark page, the preview just
// cuts it short, so the opening blocks live here.

export const V2_PAGE = "bg-[#15121B] text-[#F3EFE8]";
export const V2_WRAP =
  "mx-auto box-border flex w-full max-w-[1120px] flex-col gap-[clamp(20px,3vw,32px)] px-[clamp(20px,4vw,28px)] pt-[clamp(88px,10vw,124px)] pb-[clamp(64px,8vw,104px)]";
export const V2_CARD = "rounded-3xl border border-white/12 bg-[#231C2D]";
export const V2_GRID =
  "grid gap-[clamp(16px,2vw,24px)] [grid-template-columns:repeat(auto-fit,minmax(min(100%,400px),1fr))]";
export const V2_BODY = "text-[clamp(14.5px,1.3vw,15.5px)] leading-[2.1] text-[#C9C2D3] text-pretty";

// The four illustrations that fill the design's rv3-* image slots. Decorative: the text beside each
// one carries the meaning, so alt stays empty.
export const V2_IMAGES = {
  hero: { src: "/report/hero.webp", width: 1018, height: 679 },
  strength: { src: "/report/strength.webp", width: 928, height: 619 },
  finding1: { src: "/report/finding-1.webp", width: 928, height: 773 },
  finding2: { src: "/report/finding-2.webp", width: 928, height: 773 },
} as const;

const FADE_MASK = "radial-gradient(ellipse 50% 50% at 50% 50%,#000 30%,rgba(0,0,0,.6) 62%,transparent 96%)";

/** An illustration faded into the dark card at its edges, as the design's masked slots do. */
export function V2Illustration({
  image,
  aspect,
  priority,
  className = "",
}: {
  image: { src: string; width: number; height: number };
  aspect: string;
  priority?: boolean;
  className?: string;
}) {
  return (
    <div
      className={`relative w-full ${className}`}
      style={{ aspectRatio: aspect, WebkitMaskImage: FADE_MASK, maskImage: FADE_MASK }}
    >
      <Image
        src={image.src}
        alt=""
        fill
        priority={priority}
        sizes="(min-width: 1024px) 480px, 100vw"
        className="object-cover"
      />
    </div>
  );
}

/** The hook is one tension in two halves ("X، ولی Y."): the second half is set apart in lilac,
 * as in the design. A hook without a comma just renders whole. */
export function V2Hero({
  kicker,
  hook,
  children,
}: {
  kicker: string;
  hook: string;
  children?: React.ReactNode;
}) {
  const at = hook.indexOf("، ");
  const first = at === -1 ? hook : hook.slice(0, at + 1);
  const rest = at === -1 ? "" : hook.slice(at + 2);

  return (
    <section className={`${V2_GRID} items-center pb-[clamp(8px,3vw,32px)] gap-[clamp(20px,4vw,56px)]`}>
      <div className="flex flex-col gap-[clamp(14px,2vw,22px)]">
        <div className="text-[13px] font-bold text-[#A79FB3]">{kicker}</div>
        <h1 className="text-[clamp(26px,4.4vw,48px)] leading-[1.55] font-extrabold tracking-[-.01em] text-balance text-[#F3EFE8]">
          {first}
          {rest && <span className="block text-[#C3AEEB]">{rest}</span>}
        </h1>
        {children}
      </div>
      <V2Illustration image={V2_IMAGES.hero} aspect="5/4" priority className="max-h-[460px]" />
    </section>
  );
}

// Same pentagon as the design: 320x270 box, centre (160,140), radius 80, axes every 72 degrees
// from the top. The shape's radius never reaches 0 so even a very low level stays visible.
const RADAR = { w: 320, h: 270, cx: 160, cy: 140, r: 80 };

function point(index: number, radius: number): [number, number] {
  const angle = ((index * 72 - 90) * Math.PI) / 180;
  return [RADAR.cx + radius * Math.cos(angle), RADAR.cy + radius * Math.sin(angle)];
}

function toPoints(points: [number, number][]) {
  return points.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
}

function ring(count: number, scale: number) {
  return toPoints(Array.from({ length: count }, (_, i) => point(i, RADAR.r * scale)));
}

export type V2Dimension = { key: DimensionKey; level: DimensionLevel; percent: number };

/** The five-dimension radar, labelled with the level word only -- never a number (spec §2). */
export function V2RadarCard({ dimensions, footnote }: { dimensions: V2Dimension[]; footnote: string }) {
  const n = dimensions.length;
  const shape = toPoints(dimensions.map((d, i) => point(i, RADAR.r * (0.14 + (0.86 * d.percent) / 100))));
  const axes = dimensions.map((_, i) => `M${RADAR.cx},${RADAR.cy}L${point(i, RADAR.r).map((v) => v.toFixed(1)).join(",")}`).join("");
  const pct = (v: number, total: number) => `${((v / total) * 100).toFixed(2)}%`;

  return (
    <div className={`${V2_CARD} flex flex-col gap-2.5 p-[clamp(20px,2.4vw,30px)]`}>
      <div className="flex items-baseline justify-between gap-3">
        <h2 className="text-[clamp(15px,1.5vw,18px)] font-extrabold text-[#F3EFE8]">پنج بُعد شخصیت تو</h2>
        <div className="text-xs text-[#8E879A]">{footnote}</div>
      </div>
      <div className="relative mx-auto mt-1.5 aspect-[320/270] w-full max-w-[440px]">
        <svg viewBox={`0 0 ${RADAR.w} ${RADAR.h}`} className="absolute inset-0 h-full w-full overflow-visible">
          <polygon points={ring(n, 1)} fill="rgba(255,255,255,.03)" stroke="rgba(255,255,255,.14)" strokeWidth="1" />
          <polygon points={ring(n, 2 / 3)} fill="none" stroke="rgba(255,255,255,.08)" strokeWidth="1" />
          <polygon points={ring(n, 1 / 3)} fill="none" stroke="rgba(255,255,255,.08)" strokeWidth="1" />
          <path d={axes} stroke="rgba(255,255,255,.08)" strokeWidth="1" fill="none" />
          <polygon points={shape} fill="rgba(195,174,235,.18)" stroke="#C3AEEB" strokeWidth="1.6" strokeLinejoin="round" />
        </svg>
        {dimensions.map((d, i) => {
          const label = point(i, RADAR.r + 36);
          const dot = point(i, RADAR.r * (0.14 + (0.86 * d.percent) / 100));
          return (
            <div key={d.key} className="contents">
              <div
                className="absolute -mt-1 -ml-1 size-2 rounded-full bg-[#C3AEEB] shadow-[0_0_0_3px_#231C2D]"
                style={{ left: pct(dot[0], RADAR.w), top: pct(dot[1], RADAR.h) }}
              />
              <div
                className="absolute flex -translate-x-1/2 -translate-y-1/2 flex-col items-center gap-[5px] whitespace-nowrap"
                style={{ left: pct(label[0], RADAR.w), top: pct(label[1], RADAR.h) }}
              >
                <div className="text-[12.5px] font-bold text-[#F3EFE8]">{DIMENSION_LABELS[d.key]}</div>
                <div className="rounded-full bg-[rgba(195,174,235,.14)] px-2.5 py-[3px] text-[11px] font-bold text-[#D9CCF3]">
                  {V2_LEVEL_LABELS[d.level]}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function V2StrengthCard({ title, text }: { title: string; text: string }) {
  return (
    <div className={`${V2_CARD} flex flex-col gap-4 p-[clamp(20px,2.4vw,30px)]`}>
      <V2Illustration image={V2_IMAGES.strength} aspect="16/9" />
      <div className="text-[12.5px] font-bold text-[#A79FB3]">نقطه‌ی قوت تو</div>
      <h2 className="text-[clamp(19px,2vw,24px)] leading-[1.6] font-extrabold text-balance text-[#F3EFE8]">{title}</h2>
      <p className={V2_BODY}>{text}</p>
    </div>
  );
}

const ORDINALS = ["اول", "دوم"];

export function findingPill(index: number, area: FindingArea) {
  return `یافته‌ی ${ORDINALS[index] ?? toPersianDigits(index + 1)} · ${FINDING_AREA_LABELS[area]}`;
}

/** "۲ یافته · کار و رابطه" -- built from the report's own finding areas. */
export function findingsEyebrow(areas: FindingArea[]) {
  return `${toPersianDigits(areas.length)} یافته · ${areas.map((a) => FINDING_AREA_LABELS[a]).join(" و ")}`;
}

export function V2Pill({ children }: { children: React.ReactNode }) {
  return (
    <div className="self-start rounded-full bg-[rgba(195,174,235,.14)] px-3 py-[5px] text-[11.5px] font-extrabold text-[#D9CCF3]">
      {children}
    </div>
  );
}

export function V2FindingsHeader({ eyebrow, heading }: { eyebrow: string; heading: string }) {
  return (
    <div className="flex flex-col gap-2">
      <div className="text-[13px] font-bold text-[#A79FB3]">{eyebrow}</div>
      <h2 className="text-[clamp(21px,2.8vw,32px)] leading-[1.6] font-extrabold text-balance text-[#F3EFE8]">{heading}</h2>
    </div>
  );
}

export const V2_DISCLAIMER =
  "این گزارش برای خودشناسی و رشد فردی است و جایگزین ارزیابی تخصصی یا درمانی نیست.";

export function V2ChatIcon({ size = 16 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="flex-none"
    >
      <path d="M20 12a8 8 0 0 1-11.6 7.1L4 20l.9-4.4A8 8 0 1 1 20 12z" />
    </svg>
  );
}
