import { V2_CARD, V2_GRID, V2_PAGE, V2_WRAP } from "@/components/report/report-v2-parts";

// Loading state for /report and /preview. The route's loading.tsx can't know which version the
// report is until the data arrives, and new reports are v2, so it mirrors the v2 page: dark page,
// hero text beside the illustration, the radar and strength cards, then the two finding cards.
function Bar({ className }: { className: string }) {
  return <div aria-hidden className={`animate-pulse rounded-lg bg-white/10 ${className}`} />;
}

export function ReportV2Loading() {
  return (
    <main className={`${V2_PAGE} min-h-dvh`}>
      <div className={V2_WRAP}>
        <section className={`${V2_GRID} items-center gap-[clamp(20px,4vw,56px)]`}>
          <div className="flex flex-col gap-4">
            <Bar className="h-3 w-32" />
            <Bar className="h-7 w-[85%]" />
            <Bar className="h-7 w-[60%] bg-[rgba(195,174,235,.22)]" />
          </div>
          <div aria-hidden className="aspect-[5/4] max-h-[460px] w-full animate-pulse rounded-3xl bg-white/6" />
        </section>

        <section className={`${V2_GRID} items-stretch`}>
          <div className={`${V2_CARD} flex min-h-[320px] flex-col gap-4 p-[clamp(20px,2.4vw,30px)]`}>
            <Bar className="h-4 w-40" />
            <Bar className="mx-auto mt-4 size-[200px] rounded-full" />
          </div>
          <div className={`${V2_CARD} flex flex-col gap-4 p-[clamp(20px,2.4vw,30px)]`}>
            <div aria-hidden className="aspect-video w-full animate-pulse rounded-2xl bg-white/6" />
            <Bar className="h-3 w-24" />
            <Bar className="h-5 w-[70%]" />
            <Bar className="h-3 w-full" />
            <Bar className="h-3 w-[80%]" />
          </div>
        </section>

        <section className={V2_GRID}>
          {[0, 1].map((i) => (
            <div key={i} className={`${V2_CARD} flex flex-col gap-4 p-[clamp(20px,2.4vw,30px)]`}>
              <div aria-hidden className="aspect-video w-full animate-pulse rounded-2xl bg-white/6" />
              <Bar className="h-6 w-28 rounded-full" />
              <Bar className="h-5 w-[75%]" />
              <Bar className="h-3 w-full" />
              <Bar className="h-3 w-[88%]" />
            </div>
          ))}
        </section>

        <div className="text-center text-xs text-[#8E879A]">داریم گزارش‌تان را آماده می‌کنیم…</div>
      </div>
    </main>
  );
}
