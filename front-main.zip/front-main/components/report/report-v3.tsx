import type { FullReportV3Response, PreviewReportV3Response } from "@/lib/api/schemas";
import { WorkspaceFrame } from "@/components/workspace/frame";
import { getWorkspaceData } from "@/lib/workspace/data";
import { ReportV3Content } from "./report-v3-content";
import "./report-v3.css";
// A separate v3 renderer: historical v1/v2/deep components remain byte-identical to baseline.
export async function ReportV3({
  result,
  attemptId,
}: {
  result: FullReportV3Response | PreviewReportV3Response;
  attemptId: number;
}) {
  const full = result.stage === "full";
  const data = full ? await getWorkspaceData() : null;
  const date = data?.history.find((h) => h.attempt_id === attemptId)?.completed_at;
  const content = <ReportV3Content result={result} attemptId={attemptId} completedAt={date} />;
  return (
    <div className="fm-report-v3" dir="rtl">
      {full ? <WorkspaceFrame>{content}</WorkspaceFrame> : content}
    </div>
  );
}
