import Link from "next/link";

// Soft-brick error styling (Design System §9) — never a harsh red, and always a forward path,
// same treatment as the analysis screen's own failure state.
export function ReportUnavailable({
  message,
  attemptId,
  retryable = true,
  retakeHref = "/test",
}: {
  message: string;
  // Only set for an actual generation failure (report.status === "error"), never for a generic
  // not-found/access-denied/network error -- retrying those wouldn't help. When set, it routes
  // into AnalysisLoader's retry mode (see app/test/analysis), which re-dispatches generation
  // for this attempt without re-taking the test.
  attemptId?: number;
  // false when the backend says a retry cannot help (see error.retryable): the report failed
  // because of the answers themselves -- every question answered with the neutral middle
  // option -- and a retry re-reads those same answers, so it would fail identically forever.
  // Defaults to true so every other caller keeps today's behavior unchanged.
  retryable?: boolean;
  // Where "retake the test" goes when retryable is false. This component is shared by the
  // initial-report and deep-report pages, so the two instruments need different targets --
  // defaulting to /test would send a deep-report visitor into the 30-item initial test.
  retakeHref?: string;
}) {
  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[390px] flex-col items-center justify-center gap-4 px-7 text-center">
      <div className="bg-danger-tint text-danger-text grid size-[72px] place-items-center rounded-full text-2xl">
        !
      </div>
      <h1 className="text-lg font-extrabold">گزارش در دسترس نیست</h1>
      <p className="text-muted-foreground max-w-[280px] text-[13px] leading-[2]">{message}</p>
      {attemptId !== undefined && !retryable ? (
        <>
          <Link
            href={retakeHref}
            className="bg-primary hover:bg-primary/90 min-h-11 w-full rounded-2xl p-4 text-center text-[15px] font-extrabold text-white"
          >
            انجام دوبارهٔ آزمون
          </Link>
          <Link href="/" className="text-primary text-[12.5px] font-bold hover:underline">
            بازگشت به صفحهٔ اصلی
          </Link>
        </>
      ) : attemptId !== undefined ? (
        <>
          <Link
            href={`/test/analysis?attemptId=${attemptId}&retry=1`}
            className="bg-primary hover:bg-primary/90 min-h-11 w-full rounded-2xl p-4 text-center text-[15px] font-extrabold text-white"
          >
            تلاش دوباره
          </Link>
          <Link href="/" className="text-primary text-[12.5px] font-bold hover:underline">
            بازگشت به صفحهٔ اصلی
          </Link>
        </>
      ) : (
        <Link
          href="/"
          className="bg-primary hover:bg-primary/90 min-h-11 w-full rounded-2xl p-4 text-center text-[15px] font-extrabold text-white"
        >
          بازگشت به صفحهٔ اصلی
        </Link>
      )}
    </main>
  );
}
