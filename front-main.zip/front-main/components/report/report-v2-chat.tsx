"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { reportChatHref } from "@/app/report/_components/report-view";
import { V2ChatIcon } from "@/components/report/report-v2-parts";

// The design's "Report v3 · Chat" card: suggested questions + a free-text box.

function SendIcon({ size, stroke }: { size: number; stroke: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke={stroke}
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="-scale-x-100"
    >
      <path d="m22 2-7 20-4-9-9-4Z" />
      <path d="M22 2 11 13" />
    </svg>
  );
}

export function ReportChatSection({
  attemptId,
  questions,
}: {
  attemptId: number;
  questions: string[];
}) {
  const router = useRouter();
  const [input, setInput] = useState("");

  function send(message: string) {
    const value = message.trim();
    if (!value) return;
    router.push(reportChatHref(attemptId, value));
  }

  return (
    <>
      <div className="flex flex-col gap-[18px] rounded-3xl border-[1.5px] border-[rgba(169,191,230,.4)] bg-[#1C2333] p-[clamp(20px,3vw,32px)] shadow-[0_20px_50px_-20px_rgba(0,0,0,.6)]">
        <div className="flex items-center gap-3.5">
          <div className="grid size-[52px] flex-none place-items-center rounded-2xl bg-[#A9BFE6] text-[#141A28]">
            <V2ChatIcon size={26} />
          </div>
          <div className="flex flex-col gap-0.5">
            <div className="text-[13px] font-extrabold text-[#A9BFE6]">گفتگو با فرامن</div>
            <h3 className="text-[clamp(19px,2.2vw,24px)] leading-[1.6] font-extrabold text-balance text-[#F3EFE8]">
              درباره‌ی این یافته‌ها سؤالی داری؟ از فرامن بپرس.
            </h3>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {questions.map((q) => (
            <button
              key={q}
              type="button"
              onClick={() => send(q)}
              className="min-h-11 cursor-pointer rounded-full border border-[rgba(169,191,230,.35)] bg-[rgba(169,191,230,.08)] px-4 py-2.5 text-right text-[13.5px] font-bold text-[#DCE6F7] hover:border-[rgba(169,191,230,.6)] hover:bg-[rgba(169,191,230,.18)]"
            >
              {q}
            </button>
          ))}
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
          className="flex items-center gap-2 rounded-[18px] border-[1.5px] border-[rgba(169,191,230,.45)] bg-[#15121B] py-1.5 pr-1.5 pl-4"
        >
          <button
            type="submit"
            aria-label="ارسال"
            className="grid size-[46px] flex-none cursor-pointer place-items-center rounded-[13px] bg-[#A9BFE6] hover:bg-[#C4D4F0]"
          >
            <SendIcon size={18} stroke="#141A28" />
          </button>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="یا سؤال خودت را بنویس…"
            className="min-h-[46px] min-w-0 flex-1 border-none bg-transparent text-[15px] text-[#F3EFE8] outline-none placeholder:text-[#8E879A]"
          />
        </form>
      </div>
    </>
  );
}
