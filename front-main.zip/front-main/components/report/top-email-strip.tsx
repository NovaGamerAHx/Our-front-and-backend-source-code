"use client";

import { useState, useTransition } from "react";
import { toast } from "sonner";
import { Mail } from "lucide-react";
import { Spinner } from "@/components/ui/spinner";
import { sendReportEmailAction } from "@/components/report/actions";

// Design handoff's send-button icon (a plain arrow shape, not lucide's paper-plane Send) --
// mirrored via -scale-x-100 since it's authored pointing up-left but sits on the input's
// leading (right) edge in this RTL layout.
function SendIcon() {
  return (
    <svg
      width={17}
      height={17}
      viewBox="0 0 24 24"
      fill="none"
      stroke="#fff"
      strokeWidth={1.9}
      strokeLinecap="round"
      strokeLinejoin="round"
      className="-scale-x-100"
    >
      <path d="m22 2-7 20-4-9-9-4Z" />
      <path d="M22 2 11 13" />
    </svg>
  );
}

// The compact "email a copy" strip that sits near the TOP of both report screens (design
// handoff Phase 5 §A) -- distinct from the larger EmailReportCard further down the page. Both
// hit the same sendReportEmailAction; this is only a smaller, horizontal presentation of it.
export function TopEmailStrip({
  attemptId,
  label,
  className = "",
}: {
  attemptId: number;
  label: string;
  className?: string;
}) {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [isPending, startTransition] = useTransition();

  function submit() {
    if (!email.trim() || isPending) return;
    startTransition(async () => {
      const result = await sendReportEmailAction(attemptId, email.trim());
      if (!result.ok) {
        toast.error(result.message);
        return;
      }
      setSent(true);
    });
  }

  return (
    <div
      className={`border-border flex flex-wrap items-center gap-3.5 rounded-2xl border-[1.5px] bg-white px-4 py-2.5 shadow-[0_4px_16px_rgba(80,70,40,.05)] ${className}`}
    >
      <div className="flex flex-none items-center gap-2.5">
        <div className="grid size-[30px] flex-none place-items-center rounded-[10px]" style={{ background: "#E9EBF8" }}>
          <Mail size={16} strokeWidth={1.8} className="text-primary" />
        </div>
        <div className="text-[13.5px] font-extrabold whitespace-nowrap">{label}</div>
      </div>
      {sent ? (
        <div className="bg-success-tint flex min-h-11 min-w-[210px] flex-1 items-center gap-2.5 rounded-xl px-3.5 py-2.5">
          <span className="text-success text-sm">✓</span>
          <div className="text-success flex-1 truncate text-[12.5px] font-bold">به {email} فرستاده شد.</div>
          <button
            type="button"
            onClick={() => setSent(false)}
            className="text-primary mr-auto text-xs font-extrabold whitespace-nowrap"
          >
            تغییر ایمیل
          </button>
        </div>
      ) : (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
          className="border-border flex min-w-[210px] flex-1 items-center gap-2 rounded-xl border-[1.5px] bg-[#FBF8F1] py-1 pr-1 pl-3.5"
        >
          <button
            type="submit"
            aria-label="ارسال"
            disabled={!email.trim() || isPending}
            className="bg-primary grid size-[38px] flex-none cursor-pointer place-items-center rounded-xl disabled:opacity-50"
          >
            {isPending ? <Spinner /> : <SendIcon />}
          </button>
          <input
            type="email"
            dir="rtl"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="ایمیلت را وارد کن"
            className="text-foreground min-h-[38px] min-w-0 flex-1 border-none bg-transparent text-[13.5px] outline-none"
          />
        </form>
      )}
    </div>
  );
}
