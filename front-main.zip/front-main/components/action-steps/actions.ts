"use server";

import { ApiError } from "@/lib/api/client";
import {
  acceptReportStep,
  completeActionStep,
  editActionStep,
  reactivateActionStep,
  recordActionStepReflection,
  submitActionStepFollowup,
} from "@/lib/api/endpoints";
import type {
  ActionStep,
  CompleteActionStepInput,
  DeadlineType,
  ReactivateActionStepInput,
  RecordActionStepReflectionInput,
  SubmitActionStepFollowupInput,
} from "@/lib/api/schemas";

type ActionResult<T> = { ok: true; data: T } | { ok: false; message: string };

const GENERIC_ERROR = "خطای غیرمنتظره‌ای رخ داد. لطفاً دوباره تلاش کنید.";

function toResult<T>(fn: () => Promise<T>) {
  return fn()
    .then((data): ActionResult<T> => ({ ok: true, data }))
    .catch((error): ActionResult<T> => ({
      ok: false,
      message: error instanceof ApiError ? error.message : GENERIC_ERROR,
    }));
}

/**
 * Accepts a report/deep-report suggested_step, optionally applying a local edit (text and/or
 * deadline the user changed in the proposal sheet's "ویرایش" state) in the same round trip --
 * the accept endpoint itself takes no body, so an edit is a second PATCH right after create.
 */
export async function acceptReportStepAction(
  attemptId: number,
  index: number,
  edits?: { step_text?: string; deadline_type?: DeadlineType },
): Promise<ActionResult<ActionStep>> {
  return toResult(async () => {
    const step = await acceptReportStep(attemptId, index);
    if (edits && (edits.step_text !== undefined || edits.deadline_type !== undefined)) {
      return editActionStep(step.id, edits);
    }
    return step;
  });
}

export async function editActionStepAction(
  actionStepId: string,
  input: { step_text?: string; deadline_type?: DeadlineType },
): Promise<ActionResult<ActionStep>> {
  return toResult(() => editActionStep(actionStepId, input));
}

export async function completeActionStepAction(
  actionStepId: string,
  input: CompleteActionStepInput = {},
): Promise<ActionResult<ActionStep>> {
  return toResult(() => completeActionStep(actionStepId, input));
}

export async function recordActionStepReflectionAction(
  actionStepId: string,
  input: RecordActionStepReflectionInput,
): Promise<ActionResult<ActionStep>> {
  return toResult(() => recordActionStepReflection(actionStepId, input));
}

export async function submitActionStepFollowupAction(
  actionStepId: string,
  input: SubmitActionStepFollowupInput,
): Promise<ActionResult<ActionStep>> {
  return toResult(() => submitActionStepFollowup(actionStepId, input));
}

export async function reactivateActionStepAction(
  actionStepId: string,
  input: ReactivateActionStepInput,
): Promise<ActionResult<ActionStep>> {
  return toResult(() => reactivateActionStep(actionStepId, input));
}
