"use client";

import { useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import { toast } from "sonner";
import type { ActionStep, DeadlineType } from "@/lib/api/schemas";
import { DEADLINE_OPTIONS, DEADLINE_TEXT, actionStepSourceLabel } from "@/lib/utils/action-step";
import { completeActionStepAction, editActionStepAction } from "./actions";
import { StepCompletionSheet } from "./step-completion-sheet";
import { useSheetDrag } from "@/components/ui/use-sheet-drag";
import { Spinner } from "@/components/ui/spinner";

type Phase = "view" | "editing";

export function StepDetailSheet({
  open,
  onClose,
  step,
  onUpdated,
  onCompleted,
}: {
  open: boolean;
  onClose: () => void;
  step: ActionStep;
  onUpdated?: (step: ActionStep) => void;
  onCompleted?: (step: ActionStep) => void;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [phase, setPhase] = useState<Phase>("view");
  const [current, setCurrent] = useState(step);
  const [editDraftText, setEditDraftText] = useState(step.step_text);
  const [editDraftDeadline, setEditDraftDeadline] = useState<DeadlineType>(step.deadline_type);
  const [submitting, setSubmitting] = useState(false);
  const [showCompletion, setShowCompletion] = useState(false);
  const { sheetRef, sheetStyle, sheetProps, handleProps, prepareForNavigation } = useSheetDrag(onClose);

  if (!open) return null;

  if (showCompletion) {
    return (
      <StepCompletionSheet
        open
        onClose={onClose}
        step={current}
        onReflected={(updated) => onCompleted?.(updated)}
        // This sheet stays mounted underneath (hooks run past the early return), so its own
        // useSheetDrag entry has to be spared the unmount history.back() too when the
        // completion sheet routes into chat -- see onNavigateAway there.
        onNavigateAway={prepareForNavigation}
      />
    );
  }

  // "انجامش دادم" registers the step right here (action_steps_spec_v2 §8) -- the reflection
  // that the completion sheet then asks for is optional and never gates the completion.
  async function completeNow() {
    setSubmitting(true);
    const result = await completeActionStepAction(current.id, {});
    setSubmitting(false);
    if (!result.ok) {
      toast.error(result.message);
      return;
    }
    setCurrent(result.data);
    onCompleted?.(result.data);
    setShowCompletion(true);
  }

  async function saveEdit() {
    setSubmitting(true);
    const result = await editActionStepAction(current.id, {
      step_text: editDraftText,
      deadline_type: editDraftDeadline,
    });
    setSubmitting(false);
    if (!result.ok) {
      toast.error(result.message);
      return;
    }
    setCurrent(result.data);
    onUpdated?.(result.data);
    setPhase("view");
  }

  function talkAboutIt() {
    // prepareForNavigation() before routing away: otherwise useSheetDrag's unmount cleanup pops
    // the sheet's throwaway history entry and that popstate cancels the pending navigation --
    // the tap looked like it did nothing but close the sheet. replace, not push, so chat
    // overwrites that entry and back from chat lands on this page once.
    prepareForNavigation();
    onClose();
    // action_active (action_step.md §6.2): this step is accepted and still pending -- unlike
    // action_completed/action_missed (which need a recorded outcome) or action_rejected (which
    // needs no ActionStep row at all, since rejection is only possible before accepting), the
    // conversation here is about this exact step, before its deadline. The backend requires the
    // bound step to still be pending.
    router.replace(
      `/chat?entry_source=action_active&action_step_id=${current.id}&from=${encodeURIComponent(pathname)}`,
    );
  }

  return (
    <div className="fixed inset-0 z-[74] flex flex-col items-center justify-end" dir="rtl">
      <button
        type="button"
        aria-label="بستن"
        onClick={onClose}
        className="animate-fm-fade absolute inset-0 cursor-default bg-[rgba(30,26,20,.42)]"
      />
      <div
        ref={sheetRef}
        style={sheetStyle}
        {...sheetProps}
        className="animate-fm-sheet relative flex w-full max-w-[440px] flex-col gap-4 rounded-t-[26px] bg-white px-[22px] pt-2.5 pb-6 shadow-[0_-12px_40px_rgba(40,30,10,.18)]"
      >
        <div {...handleProps} className="-mx-[22px] flex cursor-grab justify-center py-2 active:cursor-grabbing">
          <div className="h-[5px] w-[42px] rounded-full bg-[#E7E2D6]" />
        </div>

        {phase === "view" && (
          <>
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-full bg-secondary px-2.5 py-[5px] text-[10.5px] font-extrabold text-[#22307E]">
                {actionStepSourceLabel(current.source)}
              </span>
              <span className="text-[11.5px] font-bold text-[#8B8676]">
                مهلت: {DEADLINE_TEXT[current.deadline_type]}
              </span>
            </div>
            <p className="m-0 text-[16.5px] leading-[2] font-extrabold text-pretty text-[#242A38]">
              {current.step_text}
            </p>
            <div className="flex flex-col gap-2.5">
              <button
                type="button"
                onClick={completeNow}
                disabled={submitting}
                className="bg-primary flex min-h-[50px] cursor-pointer items-center justify-center gap-2.5 rounded-2xl p-[15px] text-[15px] font-extrabold text-white disabled:cursor-not-allowed disabled:opacity-75"
              >
                {submitting && <Spinner />}
                انجامش دادم
              </button>
              <div className="flex gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    setEditDraftText(current.step_text);
                    setEditDraftDeadline(current.deadline_type);
                    setPhase("editing");
                  }}
                  className="border-border min-h-[46px] flex-1 cursor-pointer rounded-[15px] border-[1.5px] bg-white p-[13px] text-[13px] font-bold"
                >
                  ویرایش
                </button>
                <button
                  type="button"
                  onClick={talkAboutIt}
                  className="border-border min-h-[46px] flex-1 cursor-pointer rounded-[15px] border-[1.5px] bg-white p-[13px] text-[13px] font-bold"
                >
                  دربارهٔ این قدم حرف بزنیم
                </button>
              </div>
            </div>
          </>
        )}

        {phase === "editing" && (
          <div className="flex flex-col gap-3.5">
            <div className="text-[14px] font-extrabold">متن و مهلت را خودت تنظیم کن</div>
            <textarea
              value={editDraftText}
              onChange={(e) => setEditDraftText(e.target.value)}
              dir="rtl"
              rows={4}
              className="border-border focus:border-primary w-full resize-none rounded-2xl border-[1.5px] bg-[#FBF8F1] px-4 py-3.5 text-sm leading-[2] outline-none"
            />
            <div className="flex flex-col gap-2">
              <div className="text-[11.5px] font-extrabold text-[#8B8676]">مهلت</div>
              <div className="flex flex-wrap gap-1.5">
                {DEADLINE_OPTIONS.map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setEditDraftDeadline(opt.value)}
                    className={
                      opt.value === editDraftDeadline
                        ? "border-primary bg-secondary text-primary min-h-11 cursor-pointer rounded-full border-[1.5px] px-4 py-[11px] text-[12.5px] font-bold"
                        : "border-border text-foreground min-h-11 cursor-pointer rounded-full border-[1.5px] bg-white px-4 py-[11px] text-[12.5px] font-bold"
                    }
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={saveEdit}
                disabled={submitting}
                className="flex min-h-12 flex-1 cursor-pointer items-center justify-center gap-2.5 rounded-[15px] bg-[#6B4FA8] p-3.5 text-sm font-extrabold text-white disabled:cursor-not-allowed disabled:opacity-75"
              >
                {submitting && <Spinner />}
                ثبت ویرایش
              </button>
              <button
                type="button"
                onClick={() => setPhase("view")}
                className="border-border min-h-12 flex-1 cursor-pointer rounded-[15px] border-[1.5px] bg-white p-3.5 text-[13.5px] font-bold text-[#8B8676]"
              >
                بی‌خیال
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
