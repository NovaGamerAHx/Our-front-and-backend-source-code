"use client";

import { useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import { Bell, Check } from "lucide-react";
import { toast } from "sonner";
import { DENIED_HINT, shouldAskForPush, subscribeToPush } from "@/lib/push/subscribe";
import type { DeadlineType, SuggestedStep } from "@/lib/api/schemas";
import { DEADLINE_OPTIONS, DEADLINE_TEXT } from "@/lib/utils/action-step";
import { acceptReportStepAction } from "./actions";
import { useSheetDrag } from "@/components/ui/use-sheet-drag";
import { Spinner } from "@/components/ui/spinner";

type Phase = "view" | "editing" | "notifAsk" | "done";

export function ActionStepProposalSheet({
  open,
  onClose,
  kicker,
  suggestedStep,
  attemptId,
  index,
}: {
  open: boolean;
  onClose: () => void;
  kicker: string;
  suggestedStep: SuggestedStep;
  attemptId: number;
  index: number;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [phase, setPhase] = useState<Phase>("view");
  const [text, setText] = useState(suggestedStep.text);
  const [deadlineType, setDeadlineType] = useState<DeadlineType>(suggestedStep.deadline_type);
  const [edited, setEdited] = useState(false);
  const [editDraftText, setEditDraftText] = useState(suggestedStep.text);
  const [editDraftDeadline, setEditDraftDeadline] = useState<DeadlineType>(suggestedStep.deadline_type);
  const [submitting, setSubmitting] = useState(false);
  const [pushSubscribing, setPushSubscribing] = useState(false);
  const { sheetRef, sheetStyle, sheetProps, handleProps, prepareForNavigation } = useSheetDrag(onClose);

  if (!open) return null;

  function startEdit() {
    setEditDraftText(text);
    setEditDraftDeadline(deadlineType);
    setPhase("editing");
  }

  function saveEdit() {
    setText(editDraftText);
    setDeadlineType(editDraftDeadline);
    setEdited(true);
    setPhase("view");
  }

  async function accept() {
    setSubmitting(true);
    const edits = edited ? { step_text: text, deadline_type: deadlineType } : undefined;
    const result = await acceptReportStepAction(attemptId, index, edits);
    setSubmitting(false);
    if (!result.ok) {
      toast.error(result.message);
      return;
    }
    setPhase(shouldAskForPush() ? "notifAsk" : "done");
  }

  // Rejecting a suggested_step never persists an ActionStep (action_step.md §3) -- chat's
  // create_session builds action_rejected's context straight from the report's own
  // attempt_id+index instead (ChatService.create_session's ephemeral path), so no accept call
  // happens here. Any local "ویرایش" draft is discarded along with the rejection -- it was
  // never committed anywhere, so there is nothing for chat to carry forward.
  function reject() {
    // Same prepareForNavigation() + replace dance as goSteps() below -- without it the sheet's
    // unmount cleanup fires history.back() and its popstate cancels this navigation, so the tap
    // just closed the sheet and never reached chat.
    prepareForNavigation();
    onClose();
    const from = encodeURIComponent(`${pathname}?attemptId=${attemptId}`);
    router.replace(`/chat?entry_source=action_rejected&attempt_id=${attemptId}&index=${index}&from=${from}`);
  }

  async function allowNotif() {
    setPushSubscribing(true);
    const result = await subscribeToPush();
    setPushSubscribing(false);
    if (result === "error") toast.error("فعال‌سازی اعلان‌ها موفق نبود.");
    if (result === "denied" && Notification.permission === "denied") toast.error(DENIED_HINT);
    setPhase("done");
  }

  function goSteps() {
    // prepareForNavigation() first: it stops useSheetDrag's unmount cleanup from firing
    // history.back() (whose popstate would cancel this navigation). Then router.replace --
    // replace, not push, so it overwrites the sheet's throwaway history entry instead of
    // stacking on it, leaving a clean back stack (.., report, dashboard). No onClose(): the
    // route transition unmounts the sheet, and the sheet showing "done" until then is fine.
    // /dashboard is dynamic (cookies()) with staleTimes.dynamic = 0, so it loads fresh already.
    prepareForNavigation();
    router.replace("/dashboard");
  }

  return (
    <div className="fixed inset-0 z-[75] flex flex-col items-center justify-end" dir="rtl">
      <button
        type="button"
        aria-label="بستن"
        onClick={onClose}
        className="animate-fm-fade absolute inset-0 cursor-default bg-[rgba(30,26,20,.46)]"
      />
      <div
        ref={sheetRef}
        style={sheetStyle}
        {...sheetProps}
        className="animate-fm-sheet relative flex max-h-[90vh] w-full max-w-[440px] flex-col gap-4 overflow-y-auto rounded-t-[26px] bg-white px-[22px] pt-2.5 pb-6 shadow-[0_-12px_40px_rgba(40,30,10,.18)]"
      >
        <div {...handleProps} className="-mx-[22px] flex cursor-grab justify-center py-2 active:cursor-grabbing">
          <div className="h-[5px] w-[42px] rounded-full bg-[#E7E2D6]" />
        </div>
        <div className="text-[11.5px] font-extrabold text-[#8E6BA8]">{kicker}</div>

        {phase === "view" && (
          <div className="flex flex-col gap-3.5">
            <p className="m-0 text-[17px] leading-[2] font-extrabold text-pretty text-[#242A38]">{text}</p>
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-full bg-secondary px-[13px] py-1.5 text-xs font-bold whitespace-nowrap text-[#22307E]">
                مهلت: {DEADLINE_TEXT[deadlineType]}
              </span>
              {edited && <span className="text-[10.5px] font-bold text-[#A9A597]">ویرایش‌شده</span>}
            </div>
            {suggestedStep.substeps && suggestedStep.substeps.length > 0 && (
              <div className="flex flex-col gap-2.5 rounded-2xl bg-[#FBF8F1] p-4">
                <div className="text-[11.5px] font-extrabold text-[#8B8676]">اگر خواستی، به همین ترتیب</div>
                {suggestedStep.substeps.map((sub, i) => (
                  <div key={i} className="flex items-start gap-2.5">
                    <div className="mt-0.5 grid size-[18px] flex-none place-items-center rounded-[6px] bg-secondary text-[10px] font-extrabold text-[#22307E]">
                      {i + 1}
                    </div>
                    <div className="text-[12.5px] leading-[1.9] text-pretty text-[#3C4150]">{sub}</div>
                  </div>
                ))}
              </div>
            )}
            <div className="flex flex-col gap-2.5">
              <button
                type="button"
                onClick={accept}
                disabled={submitting}
                className="bg-primary flex min-h-[52px] cursor-pointer items-center justify-center gap-2.5 rounded-2xl p-4 text-[15.5px] font-extrabold text-white disabled:cursor-not-allowed disabled:opacity-75"
              >
                {submitting && <Spinner />}
                {submitting ? "در حال ثبت…" : "قبول دارم"}
              </button>
              <div className="flex gap-2.5">
                <button
                  type="button"
                  onClick={startEdit}
                  className="border-border min-h-[46px] flex-1 cursor-pointer rounded-[15px] border-[1.5px] bg-white p-[13px] text-[13.5px] font-bold"
                >
                  ویرایش
                </button>
                <button
                  type="button"
                  onClick={reject}
                  className="border-border min-h-[46px] flex-1 cursor-pointer rounded-[15px] border-[1.5px] bg-[#FBF8F1] p-[13px] text-[13.5px] font-bold text-[#8B8676]"
                >
                  این به من نمی‌خوره
                </button>
              </div>
            </div>
          </div>
        )}

        {phase === "editing" && (
          <div className="flex flex-col gap-3.5">
            <div className="text-[14px] font-extrabold">متن و مهلت را خودت تنظیم کن</div>
            <textarea
              value={editDraftText}
              onChange={(e) => setEditDraftText(e.target.value)}
              dir="rtl"
              rows={4}
              className="border-border focus:border-primary w-full resize-none rounded-2xl border-[1.5px] bg-[#FBF8F1] px-4 py-3.5 text-sm leading-[2] outline-none"
            />
            <div className="flex flex-col gap-2">
              <div className="text-[11.5px] font-extrabold text-[#8B8676]">مهلت</div>
              <div className="flex flex-wrap gap-1.5">
                {DEADLINE_OPTIONS.map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setEditDraftDeadline(opt.value)}
                    className={
                      opt.value === editDraftDeadline
                        ? "border-primary bg-secondary text-primary min-h-11 cursor-pointer rounded-full border-[1.5px] px-4 py-[11px] text-[12.5px] font-bold"
                        : "border-border text-foreground min-h-11 cursor-pointer rounded-full border-[1.5px] bg-white px-4 py-[11px] text-[12.5px] font-bold"
                    }
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
              <div className="text-[11px] leading-[1.85] text-[#A9A597]">
                تا وقتی خودت مهلت را عوض نکنی، همان مهلت اول می‌ماند — بازنویسی متن آن را جلو نمی‌اندازد.
              </div>
            </div>
            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={saveEdit}
                className="min-h-12 flex-1 cursor-pointer rounded-[15px] bg-[#6B4FA8] p-3.5 text-sm font-extrabold text-white"
              >
                ثبت ویرایش
              </button>
              <button
                type="button"
                onClick={() => setPhase("view")}
                className="border-border min-h-12 flex-1 cursor-pointer rounded-[15px] border-[1.5px] bg-white p-3.5 text-[13.5px] font-bold text-[#8B8676]"
              >
                بی‌خیال
              </button>
            </div>
          </div>
        )}

        {phase === "notifAsk" && (
          <div className="flex flex-col gap-3.5">
            <div className="flex items-center gap-2.5">
              <div className="grid size-[38px] flex-none place-items-center rounded-xl bg-secondary">
                <Bell size={19} strokeWidth={1.9} className="text-primary" />
              </div>
              <div className="text-[15.5px] font-extrabold text-[#242A38]">یادآوری همین قدم را بفرستم؟</div>
            </div>
            <div className="flex flex-col gap-2.5">
              <button
                type="button"
                onClick={allowNotif}
                disabled={pushSubscribing}
                className="bg-primary flex min-h-12 cursor-pointer items-center justify-center gap-2.5 rounded-[15px] p-[15px] text-[14.5px] font-extrabold text-white disabled:cursor-not-allowed disabled:opacity-75"
              >
                {pushSubscribing && <Spinner />}
                {pushSubscribing ? "در حال فعال‌سازی…" : "بله، یادآوری کن"}
              </button>
              <button
                type="button"
                onClick={() => setPhase("done")}
                className="border-border min-h-[46px] cursor-pointer rounded-[15px] border-[1.5px] bg-white p-[13px] text-[13.5px] font-bold text-[#8B8676]"
              >
                نه، لازم نیست
              </button>
            </div>
          </div>
        )}

        {phase === "done" && (
          <div className="flex flex-col gap-3.5">
            <div className="flex items-center gap-2.5">
              <Check size={20} strokeWidth={2.4} className="text-success" />
              <div className="text-[15.5px] font-extrabold text-[#242A38]">ثبت شد</div>
            </div>
            <p className="m-0 text-[13px] leading-[2] text-[#5D5C55]">قدمت به لیست قدم‌های جاری اضافه شد.</p>
            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={goSteps}
                className="bg-primary min-h-12 flex-1 cursor-pointer rounded-2xl p-3.5 text-[13.5px] font-extrabold text-white"
              >
                دیدن قدم‌هایم
              </button>
              <button
                type="button"
                onClick={onClose}
                className="border-border min-h-12 flex-1 cursor-pointer rounded-2xl border-[1.5px] bg-white p-3.5 text-[13.5px] font-bold"
              >
                همین‌جا می‌مانم
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
