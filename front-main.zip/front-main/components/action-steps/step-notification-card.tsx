"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Bell } from "lucide-react";
import { toast } from "sonner";
import { trackEventAction } from "@/lib/api/track-event-action";
import type { ActionStep, ActionStepChannel, ActionStepFollowupResult, ActionStepObstacle } from "@/lib/api/schemas";
import { OBSTACLE_OPTIONS } from "@/lib/utils/action-step";
import { submitActionStepFollowupAction } from "./actions";
import { Spinner } from "@/components/ui/spinner";

type Kind = "reminder" | "followup";
type Phase = "ask" | "blocker" | "closed";

/**
 * The dashboard's dark inline notification card and the checkin deep-link page's highlighted
 * card are the same component now (action_steps_spec_v2 §7) -- `kind` picks between the
 * reminder's "did you already do it" quick options and the followup's done/partial/not_done ask.
 */
export function StepNotificationCard({
  step,
  kind,
  channel = "login",
  onResolved,
  onDismiss,
}: {
  step: ActionStep;
  kind: Kind;
  channel?: ActionStepChannel;
  onResolved?: (step: ActionStep) => void;
  onDismiss?: () => void;
}) {
  const router = useRouter();
  const [phase, setPhase] = useState<Phase>("ask");
  const [pickedResult, setPickedResult] = useState<ActionStepFollowupResult | null>(null);
  const [lastResult, setLastResult] = useState<ActionStepFollowupResult | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  async function submit(result: ActionStepFollowupResult, obstacle: ActionStepObstacle | null) {
    setSubmitting(true);
    const res = await submitActionStepFollowupAction(step.id, { result, obstacle, channel });
    setSubmitting(false);
    if (!res.ok) {
      toast.error(res.message);
      return;
    }
    onResolved?.(res.data);
    setLastResult(result);
    setPhase("closed");
  }

  function pickResult(result: ActionStepFollowupResult) {
    if (submitting) return;
    if (result === "done") {
      submit(result, null);
      return;
    }
    setPickedResult(result);
    setPhase("blocker");
  }

  function pickObstacle(obstacle: ActionStepObstacle) {
    if (submitting || !pickedResult) return;
    submit(pickedResult, obstacle);
  }

  function dismiss() {
    setDismissed(true);
    onDismiss?.();
  }

  function continueInChat() {
    void trackEventAction({ event_name: "returned_to_chat_after_checkin", properties: { action_step_id: step.id } });
    // action_step.md §6.2: the user accepted this step and then did not do it -- that is
    // action_missed, not action_rejected. Rejection is only possible *before* accepting, so a
    // rejected step is never in action_steps at all; sending action_rejected with a real
    // action_step_id fails ChatRequest validation ("a rejected step has no status or obstacle").
    // lastResult is "partial"/"not_done" on this branch, which is exactly what action_missed needs.
    const entrySource = lastResult === "done" ? "action_completed" : "action_missed";
    const from = encodeURIComponent(`/checkin/${step.id}`);
    router.push(`/chat?entry_source=${entrySource}&action_step_id=${step.id}&from=${from}`);
  }

  return (
    <div className="flex flex-col gap-3 rounded-[18px] bg-[#242A38] p-4 shadow-[0_8px_24px_rgba(36,42,56,.2)]">
      <div className="flex items-center gap-2.5">
        <div className="grid size-8 flex-none place-items-center rounded-[9px] bg-white/12">
          <Bell size={16} strokeWidth={1.9} className="text-white" />
        </div>
        <div className="flex min-w-0 flex-1 flex-col gap-0.5">
          <div className="text-[11px] font-extrabold text-white/62">
            فرامن • {kind === "reminder" ? "یادآوری" : "پیگیری"}
          </div>
        </div>
        {phase === "ask" && kind === "reminder" && (
          <button
            type="button"
            aria-label="بستن"
            onClick={dismiss}
            className="grid size-[30px] flex-none cursor-pointer place-items-center rounded-[9px] text-[14px] text-white/50"
          >
            ✕
          </button>
        )}
      </div>

      <div className="text-pretty text-[13.5px] leading-[1.9] font-bold text-white">{step.step_text}</div>

      {phase === "ask" && kind === "reminder" && (
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => pickResult("done")}
            disabled={submitting}
            className="flex min-h-11 cursor-pointer items-center justify-center gap-2 rounded-full bg-white px-[18px] py-[11px] text-[12.5px] font-extrabold text-[#242A38] disabled:cursor-not-allowed disabled:opacity-75"
          >
            {submitting && <Spinner />}
            همین حالا انجامش دادم
          </button>
          <button
            type="button"
            onClick={dismiss}
            className="min-h-11 cursor-pointer rounded-full border border-white/30 bg-transparent px-[18px] py-[11px] text-[12.5px] font-bold text-white"
          >
            باشد
          </button>
        </div>
      )}

      {phase === "ask" && kind === "followup" && (
        <div className="flex flex-col gap-2.5">
          <div className="text-xs font-extrabold text-white/72">انجامش دادی؟</div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => pickResult("done")}
              disabled={submitting}
              className="flex min-h-11 cursor-pointer items-center justify-center gap-2 rounded-full bg-white px-[18px] py-[11px] text-[12.5px] font-extrabold text-[#242A38] disabled:cursor-not-allowed disabled:opacity-75"
            >
              {submitting && <Spinner />}
              انجام دادم
            </button>
            <button
              type="button"
              onClick={() => pickResult("partial")}
              disabled={submitting}
              className="min-h-11 cursor-pointer rounded-full border border-white/30 bg-transparent px-[18px] py-[11px] text-[12.5px] font-bold text-white disabled:cursor-not-allowed disabled:opacity-60"
            >
              نیمه‌کاره
            </button>
            <button
              type="button"
              onClick={() => pickResult("not_done")}
              disabled={submitting}
              className="min-h-11 cursor-pointer rounded-full border border-white/30 bg-transparent px-[18px] py-[11px] text-[12.5px] font-bold text-white disabled:cursor-not-allowed disabled:opacity-60"
            >
              نشد
            </button>
          </div>
        </div>
      )}

      {phase === "blocker" && (
        <div className="flex flex-col gap-2.5 border-t border-white/12 pt-3">
          <div className="text-[12.5px] font-extrabold text-white">چه چیزی جلویش را گرفت؟</div>
          <div className="flex flex-wrap gap-1.5">
            {OBSTACLE_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => pickObstacle(opt.value)}
                disabled={submitting}
                className="min-h-11 cursor-pointer rounded-full border border-white/24 bg-white/8 px-[15px] py-[10px] text-xs font-bold text-white disabled:cursor-not-allowed disabled:opacity-60"
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {phase === "closed" && (
        <div className="flex flex-col gap-2 border-t border-white/12 pt-3">
          <div className="text-[12.5px] font-extrabold text-[#9FE0BE]">ثبت شد</div>
          <div className="text-[11.5px] leading-[1.9] text-white/62">
            به تاریخچهٔ قدم‌ها منتقل شد. یادآوری دیگری برای این قدم فرستاده نمی‌شود.
          </div>
          <button type="button" onClick={continueInChat} className="self-start cursor-pointer text-[12px] font-bold text-white">
            ادامه در گفتگو
          </button>
        </div>
      )}
    </div>
  );
}
