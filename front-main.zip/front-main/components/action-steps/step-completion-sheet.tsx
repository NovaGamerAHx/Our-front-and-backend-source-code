"use client";

import { useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import { Check } from "lucide-react";
import { toast } from "sonner";
import type { ActionStep } from "@/lib/api/schemas";
import { recordActionStepReflectionAction } from "./actions";
import { useSheetDrag } from "@/components/ui/use-sheet-drag";
import { Spinner } from "@/components/ui/spinner";

const REFLECTION_CHIPS = [
  "بهتر از چیزی که فکر می‌کردم بود",
  "سخت‌تر از چیزی که فکر می‌کردم بود",
  "همون چیزی بود که انتظار داشتم",
];

type Phase = "ask" | "invite";

/**
 * Shown after the step is already marked done (the Step Detail sheet's "انجامش دادم" tap) --
 * this sheet only collects the optional "چطور بود؟" reflection and then invites the user into
 * chat. Skipping the reflection never touches the backend.
 */
export function StepCompletionSheet({
  open,
  onClose,
  step,
  onReflected,
  onNavigateAway,
}: {
  open: boolean;
  onClose: () => void;
  step: ActionStep;
  onReflected?: (step: ActionStep) => void;
  // The parent sheet's own useSheetDrag prepareForNavigation() -- it is still mounted behind
  // this one, so its history entry needs the same exemption before we route into chat.
  onNavigateAway?: () => void;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [phase, setPhase] = useState<Phase>("ask");
  const [text, setText] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const { sheetRef, sheetStyle, sheetProps, handleProps, prepareForNavigation } = useSheetDrag(onClose);

  if (!open) return null;

  async function submit(reflectionText?: string) {
    if (!reflectionText) {
      setPhase("invite");
      return;
    }
    setSubmitting(true);
    const result = await recordActionStepReflectionAction(step.id, { reflection_text: reflectionText });
    setSubmitting(false);
    if (!result.ok) {
      toast.error(result.message);
      return;
    }
    onReflected?.(result.data);
    setPhase("invite");
  }

  function goChat() {
    // Both sheets' unmount cleanups would fire history.back() here, and either popstate cancels
    // the navigation -- so exempt this one and the parent's before routing (useSheetDrag's
    // prepareForNavigation note). replace overwrites this sheet's throwaway entry.
    prepareForNavigation();
    onNavigateAway?.();
    onClose();
    router.replace(
      `/chat?entry_source=action_completed&action_step_id=${step.id}&from=${encodeURIComponent(pathname)}`,
    );
  }

  return (
    <div className="fixed inset-0 z-[76] flex flex-col items-center justify-end" dir="rtl">
      <button
        type="button"
        aria-label="بستن"
        onClick={onClose}
        className="animate-fm-fade absolute inset-0 cursor-default bg-[rgba(30,26,20,.46)]"
      />
      <div
        ref={sheetRef}
        style={sheetStyle}
        {...sheetProps}
        className="animate-fm-sheet relative flex max-h-[90vh] w-full max-w-[440px] flex-col gap-4 overflow-y-auto rounded-t-[26px] bg-white px-[22px] pt-2.5 pb-6 shadow-[0_-12px_40px_rgba(40,30,10,.18)]"
      >
        <div {...handleProps} className="-mx-[22px] flex cursor-grab justify-center py-2 active:cursor-grabbing">
          <div className="h-[5px] w-[42px] rounded-full bg-[#E7E2D6]" />
        </div>
        <div className="flex items-center gap-2.5">
          <Check size={20} strokeWidth={2.4} className="text-success" />
          <div className="text-[15.5px] font-extrabold text-[#242A38]">ثبت شد. به تاریخچه رفت.</div>
        </div>
        <div className="text-[13px] leading-[1.95] text-pretty text-[#5D5C55]">{step.step_text}</div>

        {phase === "ask" && (
          <div className="border-border flex flex-col gap-3.5 border-t pt-[15px]">
            <div className="text-[14.5px] font-extrabold text-[#242A38]">چطور بود؟</div>
            <div className="text-xs leading-[1.9] text-[#8B8676]">
              یک جمله کافی است — همین یک جمله باعث می‌شود گفتگوهای بعدی دقیق‌تر باشند.
            </div>
            <div className="flex flex-wrap gap-1.5">
              {REFLECTION_CHIPS.map((chip) => (
                <button
                  key={chip}
                  type="button"
                  onClick={() => setText(chip)}
                  className={
                    text === chip
                      ? "border-primary bg-secondary text-primary min-h-11 cursor-pointer rounded-full border-[1.5px] px-[15px] py-[10px] text-xs font-bold"
                      : "border-border text-foreground min-h-11 cursor-pointer rounded-full border-[1.5px] bg-white px-[15px] py-[10px] text-xs font-bold"
                  }
                >
                  {chip}
                </button>
              ))}
            </div>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              dir="rtl"
              rows={3}
              placeholder="مثلاً: فکر می‌کردم سخت باشد، ولی بعد از شروع راحت شد."
              className="border-border focus:border-primary w-full resize-none rounded-2xl border-[1.5px] bg-[#FBF8F1] px-4 py-3.5 text-[13.5px] leading-[1.95] outline-none"
            />
            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={() => submit(text.trim() || undefined)}
                disabled={submitting}
                className="bg-primary flex min-h-12 flex-1 cursor-pointer items-center justify-center gap-2.5 rounded-[15px] p-3.5 text-[13.5px] font-extrabold text-white disabled:cursor-not-allowed disabled:opacity-75"
              >
                {submitting && <Spinner />}
                ثبت بازتاب
              </button>
              <button
                type="button"
                onClick={() => submit(undefined)}
                disabled={submitting}
                className="border-border min-h-12 flex-1 cursor-pointer rounded-[15px] border-[1.5px] bg-white p-3.5 text-[13.5px] font-bold text-[#8B8676] disabled:cursor-not-allowed disabled:opacity-60"
              >
                رد می‌کنم
              </button>
            </div>
          </div>
        )}

        {phase === "invite" && (
          <div className="border-border flex flex-col gap-3.5 border-t pt-[15px]">
            <div className="text-[14.5px] font-extrabold text-[#242A38]">هر وقت خواستی، حرف بزنیم</div>
            <p className="m-0 text-[13px] leading-[2] text-pretty text-[#5D5C55]">
              اگر دوست داشتی همین حالا دربارهٔ تجربه‌اش حرف بزنیم و ببینیم قدم بعدی چه شکلی است.
            </p>
            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={goChat}
                className="bg-primary min-h-12 flex-1 cursor-pointer rounded-[15px] p-3.5 text-[13.5px] font-extrabold text-white"
              >
                بریم گفتگو
              </button>
              <button
                type="button"
                onClick={onClose}
                className="border-border min-h-12 flex-1 cursor-pointer rounded-[15px] border-[1.5px] bg-white p-3.5 text-[13.5px] font-bold"
              >
                الان نه
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
