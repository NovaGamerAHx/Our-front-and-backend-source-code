import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Lets phones on the LAN reach the dev server (HMR, RSC payloads, Server Actions)
  // when testing against `next dev` from a real mobile device instead of localhost.
  allowedDevOrigins: ["10.40.135.155"],
  // Produces .next/standalone — a self-contained server bundle (no node_modules
  // install needed at runtime) for the production Docker image.
  output: "standalone",
  // Short link for SMS campaigns. The destination's UTM params are written to the faraman_utm
  // cookie by UtmCapture when the page loads.
  async redirects() {
    return [
      {
        source: "/d",
        destination: "/paywall?utm_source=sms&utm_campaign=deep_followup",
        permanent: false,
      },
      {
        source: "/k",
        destination: "/test?utm_source=telegram&utm_campaign=kaaf",
        permanent: false,
      },
      {
        source: "/ka",
        destination: "/test?utm_source=telegram_ads&utm_campaign=kaaf_channel",
        permanent: false,
      },
      {
        source: "/kf",
        destination: "/paywall?utm_source=sms&utm_campaign=kf_tst_flw",
        permanent: false,
      },
    ];
  },
};

export default nextConfig;
