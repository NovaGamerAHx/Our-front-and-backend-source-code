import "server-only";
import {
  DEFAULT_DEEP_UTM,
  DEFAULT_PAY_UTM,
  readUtmFromSearch,
  withDefaultUtm,
  type UtmParams,
} from "@/lib/analytics/utm";

export { DEFAULT_DEEP_UTM, DEFAULT_PAY_UTM, withDefaultUtm, type UtmParams };

/**
 * Short links (server-only): tiny shareable URLs for SMS/campaigns that land on the right
 * screen without the recipient having to know the real route.
 *
 * - Payment:  /flc7 (ultra-short) or /go/pay[?coupon=CODE][&source=sms]
 *   Smart redirect: logged-out -> login (then back here); logged-in with a finished deep
 *   test awaiting payment -> /paywall?deepAttemptId=<id> with the coupon pre-filled;
 *   already paid -> that report; otherwise -> /deep-test so they take the test first
 *   (the backend only sells the deep report for a finished attempt -- see
 *   PaymentService._get_payable_attempt).
 * - Deep test: /c9 (ultra-short) or /go/deep[?source=sms] -> /deep-test?source=<source>
 *
 * Paths are filesystem routes (app/go/pay, app/go/deep), so renaming a path means renaming
 * its folder -- but everything else is env-configurable here with safe defaults, so changing
 * the pre-filled coupon or the default source never needs a code deploy.
 */

/** Payment short link path. Share as `${APP_URL}/go/pay?coupon=FARAMAN75`. */
export const PAY_SHORT_LINK_PATH = "/go/pay";

/** Deep-test short link path. Share as `${APP_URL}/go/deep`. */
export const DEEP_SHORT_LINK_PATH = "/go/deep";

/** Ultra-short payment link (alias of /go/pay, same logic). Share as `${APP_URL}/flc7?coupon=FARAMAN75`. */
export const PAY_SHORT_LINK_PATH_SHORT = "/flc7";

/** Ultra-short deep-test link (alias of /go/deep, same logic). Share as `${APP_URL}/c9`. */
export const DEEP_SHORT_LINK_PATH_SHORT = "/c9";

/** Max coupon length, matching Coupon.code (max_length=32) on the backend. */
const MAX_COUPON_LENGTH = 32;

/**
 * Coupon to pre-fill on the paywall when a short link carries no explicit ?coupon=.
 * From `SHORT_LINK_DEFAULT_COUPON` (server-only env var):
 * - unset (no line at all) -> "FARAMAN75", so a plain /go/pay link works out of the box;
 * - set to a code -> that code (change the campaign without a deploy);
 * - set to empty (`SHORT_LINK_DEFAULT_COUPON=`) -> null, i.e. no pre-fill at all: the
 *   paywall opens with an empty promo box and the visitor types a code only if they have one.
 * An explicit ?coupon= in the URL always wins over this default (see app/go/pay/page.tsx).
 */
export function shortLinkDefaultCoupon(): string | null {
  const raw = process.env.SHORT_LINK_DEFAULT_COUPON;
  if (raw === undefined) return "FARAMAN75";
  if (raw.trim() === "") return null;
  return sanitizeCoupon(raw) ?? "FARAMAN75";
}

/**
 * Default `source` for /go/deep when the URL carries no ?source=. From
 * `SHORT_LINK_DEEP_SOURCE` (server-only env var); missing/blank falls back to "sms".
 */
export function shortLinkDeepSource(): string {
  const raw = process.env.SHORT_LINK_DEEP_SOURCE;
  if (raw === undefined || raw.trim() === "") return "sms";
  const value = raw.trim().toLowerCase().slice(0, 40);
  return /^[a-z0-9_]+$/.test(value) ? value : "sms";
}

/**
 * Normalize a coupon code from a URL: trimmed, or null when absent/malformed. The backend
 * looks codes up case-insensitively (CouponRepository.get_locked_for_code uses __iexact),
 * so the original case is preserved for display.
 */
export function sanitizeCoupon(raw: string | undefined): string | null {
  const value = raw?.trim().slice(0, MAX_COUPON_LENGTH);
  return value && /^[A-Za-z0-9_-]+$/.test(value) ? value : null;
}

/** /paywall URL for one finished deep attempt, with the coupon pre-filled when given. */
export function buildPaywallUrl(
  attemptId: number,
  coupon: string | null,
  utm: UtmParams = {},
): string {
  const params = new URLSearchParams({ deepAttemptId: String(attemptId) });
  if (coupon) params.set("coupon", coupon);
  for (const [key, value] of Object.entries(utm)) {
    if (value) params.set(key, value);
  }
  return `/paywall?${params.toString()}`;
}

// ---- UTM campaign forwarding ------------------------------------------------
// UtmCapture (components/analytics/utm-capture.tsx) persists utm_source/utm_campaign from
// the landing URL into the faraman_utm cookie -- but it is a client component and never runs
// on short-link pages, which redirect server-side before any JS executes. The cookie is
// therefore written by proxy.ts (the only place that can set cookies on redirect responses);
// these helpers only read UTM from the URL and forward it through every redirect destination
// so the campaign survives to the landing page (where UtmCapture also writes it, idempotently).

/** UTM values from a short-link URL's searchParams, trimmed and length-capped; absent keys omitted. */
export function readUtmFromSearchParams(
  params: Record<string, string | undefined>,
): UtmParams {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (typeof value === "string") search.set(key, value);
  }
  return readUtmFromSearch(search);
}

/** Append UTM params to a path (which may already carry a query string). No-op when empty. */
export function appendUtm(path: string, utm: UtmParams): string {
  const entries = Object.entries(utm).filter(([, v]) => v);
  if (entries.length === 0) return path;
  const separator = path.includes("?") ? "&" : "?";
  return `${path}${separator}${new URLSearchParams(entries as [string, string][]).toString()}`;
}
