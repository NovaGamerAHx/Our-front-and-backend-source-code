// Direct APK download, served as a static file from public/downloads. Replace the file there
// (signed with the key whose fingerprint is in public/.well-known/assetlinks.json) to ship a new build.
export const DIRECT_DOWNLOAD_HREF = "/downloads/faraman.apk";
