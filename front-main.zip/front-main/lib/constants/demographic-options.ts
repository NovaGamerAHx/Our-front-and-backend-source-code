import type { GenderValue, GoalValue, LifeSituationValue } from "@/lib/api/schemas";

export const GENDER_OPTIONS: { value: GenderValue; label: string }[] = [
  { value: "female", label: "زن" },
  { value: "male", label: "مرد" },
];

export const LIFE_SITUATION_OPTIONS: { value: LifeSituationValue; label: string }[] = [
  { value: "student", label: "در حال تحصیل" },
  { value: "employed", label: "شاغل" },
  { value: "self_employed", label: "فریلنسر یا صاحب کسب‌وکار" },
  { value: "job_seeking", label: "در جست‌وجوی کار" },
  { value: "transitioning", label: "در حال تغییر مسیر شغلی" },
  { value: "family_care", label: "مشغول رسیدگی به خانه و خانواده" },
  { value: "other", label: "سایر" },
];

export const GOAL_OPTIONS: { value: GoalValue; label: string }[] = [
  { value: "decisions", label: "بهتر تصمیم بگیرم" },
  { value: "mastery", label: "منظم‌تر باشم" },
  { value: "growth", label: "یاد بگیرم و پیشرفت کنم" },
  { value: "relationships", label: "روابط بهتری داشته باشم" },
  { value: "purpose", label: "در کارم پیشرفت کنم" },
  { value: "self_regard", label: "اعتمادبه‌نفس بیشتری داشته باشم" },
  { value: "stress", label: "آرام‌تر باشم" },
  { value: "unsure", label: "هنوز مطمئن نیستم" },
];
