"use client";

import { FCM_VAPID_KEY, FIREBASE_CONFIG } from "@/lib/api/constants";
import { registerPushSubscriptionAction } from "@/app/push/actions";

export type SubscribeResult = "subscribed" | "denied" | "unsupported" | "error";

/** Whether to offer the "remind me about this step" prompt: everywhere push is possible except
 * where permission is already granted (a denied user is asked again each time -- see
 * DENIED_HINT for what tapping "yes" does then, since the browser won't re-show its dialog). */
export function shouldAskForPush(): boolean {
  if (typeof window === "undefined" || !("serviceWorker" in navigator) || !("Notification" in window)) return false;
  return Notification.permission !== "granted";
}

export const DENIED_HINT = "اعلان‌ها برای این سایت مسدود شده‌اند. از تنظیمات مرورگر (Site settings) آن‌ها را فعال کنید.";

/**
 * Requests notification permission (only shows the native dialog if not already asked -- see
 * chat-view.tsx's caller for the deliberate-tap gating) and, if granted, registers an FCM token
 * with the backend. Dynamic imports keep the Firebase SDK out of the main bundle until needed.
 */
export async function subscribeToPush(): Promise<SubscribeResult> {
  if (typeof window === "undefined" || !("serviceWorker" in navigator) || !("Notification" in window)) {
    return "unsupported";
  }

  const permission = await Notification.requestPermission();
  if (permission !== "granted") return "denied";

  try {
    const [{ initializeApp }, { getMessaging, getToken, deleteToken }] = await Promise.all([
      import("firebase/app"),
      import("firebase/messaging"),
    ]);

    const app = initializeApp(FIREBASE_CONFIG);
    const messaging = getMessaging(app);
    const registration = await navigator.serviceWorker.ready;
    const tokenOptions = { vapidKey: FCM_VAPID_KEY, serviceWorkerRegistration: registration };

    const token = await getToken(messaging, tokenOptions);
    if (!token) return "error";

    const result = await registerPushSubscriptionAction(token);
    if (!result.ok) return "error";
    if (!result.data.tokenWasInactive) return "subscribed";

    // The backend had deactivated this exact token after FCM rejected it, and getToken() just
    // handed it back from the SDK's cache -- re-registering it would only flip it active until
    // the next send fails again. Drop it and mint a fresh one (once; no loop).
    await deleteToken(messaging);
    const freshToken = await getToken(messaging, tokenOptions);
    if (!freshToken) return "error";

    const retry = await registerPushSubscriptionAction(freshToken);
    return retry.ok ? "subscribed" : "error";
  } catch {
    return "error";
  }
}
