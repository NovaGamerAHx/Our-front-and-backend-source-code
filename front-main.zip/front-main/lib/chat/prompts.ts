// The quick-prompt chips shown above the chat composer.
export const CHAT_SUGGESTED_PROMPTS = [
  "مهم ترین نکته‌ی گزارشم چیه؟",
  "به کاری رو مدام عقب می‌اندازم",
  "یه تصمیم دارم که نمیتونم بگیرمش",
  "حس میکنم یه جا گیر کردم",
] as const;
