// Shared home/chat suggestions; each label is the actual message.
export const CHAT_SUGGESTED_PROMPTS = [
  "یه کاری رو مدام عقب می‌اندازم",
  "یه تصمیم دارم که نمی‌تونم بگیرمش",
  "حس می‌کنم یه جا گیر کردم",
] as const;
