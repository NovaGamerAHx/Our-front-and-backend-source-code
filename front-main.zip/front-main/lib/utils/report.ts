import type {
  DimensionKey,
  DimensionLevel,
  FindingArea,
  FullReportV2Response,
  PreviewReportV2Response,
  Recommendation,
} from "@/lib/api/schemas";

export const DIMENSION_ICONS: Record<DimensionKey, string> = {
  emotional_stability: "/report-icons/dim-emotional.png",
  extraversion: "/report-icons/dim-social.png",
  openness: "/report-icons/dim-growth.png",
  agreeableness: "/report-icons/dim-empathy.png",
  conscientiousness: "/report-icons/dim-responsibility.png",
};

export const DIMENSION_LABELS: Record<DimensionKey, string> = {
  emotional_stability: "ثبات هیجانی",
  extraversion: "انرژی اجتماعی",
  openness: "ذهن رشدگرا",
  agreeableness: "همدلی و همکاری",
  conscientiousness: "مسئولیت‌پذیری",
};

export const DIMENSION_LEVEL_LABELS: Record<DimensionLevel, string> = {
  high: "بالا",
  medium_high: "نسبتاً بالا",
  medium: "متوسط",
  low: "کم",
  very_low: "خیلی کم",
};

export const LIFE_PATTERN_LABELS: Record<string, string> = {
  decision_style: "سبک تصمیم‌گیری",
  relationship_style: "سبک ارتباطی",
  work_learning_style: "سبک کار و یادگیری",
  stress_energy_pattern: "استرس و انرژی",
};

export const ACTION_TYPE_LABELS: Record<Recommendation["action_type"], string> = {
  decision: "تصمیم‌گیری",
  execution: "اجرا",
  relationship: "رابطه",
  learning: "یادگیری",
  wellbeing: "بهزیستی",
  communication: "ارتباط",
};

/** Full dimension_scores come back in a fixed backend order; re-sort strongest-first so the
 * report reads like the design sample (highest scores lead), same rule the backend already
 * applies to the preview's level-only list. */
export function sortDimensionsByScore<T extends { score_percent: number }>(dimensions: T[]): T[] {
  return [...dimensions].sort((a, b) => b.score_percent - a.score_percent);
}

/** The five-axis radar chart has a fixed pentagon layout (top, then clockwise), unlike the
 * ranked dimension cards below it — each axis is tied to a specific point on the shape, not to
 * score order. */
export const RADAR_AXES: { key: DimensionKey; angleDeg: number }[] = [
  { key: "emotional_stability", angleDeg: -90 },
  { key: "extraversion", angleDeg: -18 },
  { key: "openness", angleDeg: 54 },
  { key: "agreeableness", angleDeg: 126 },
  { key: "conscientiousness", angleDeg: 198 },
];

const RADAR_CENTER = 100;
const RADAR_RADIUS = 76;

export function computeRadarPolygonPoints(scoresByKey: Map<DimensionKey, number>): string {
  return RADAR_AXES.map(({ key, angleDeg }) => {
    const pct = scoresByKey.get(key) ?? 0;
    const r = (RADAR_RADIUS * pct) / 100;
    const rad = (angleDeg * Math.PI) / 180;
    const x = RADAR_CENTER + r * Math.cos(rad);
    const y = RADAR_CENTER + r * Math.sin(rad);
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(" ");
}

/** Five-tier color scale for the dimension level pill, the radar percentage labels, and the
 * inline percentage next to each dimension name — each level gets its own color (never shared
 * with another level), running from primary blue (high) down through the design system's
 * "never a harsh red" soft-brick danger tone (very_low). */
export const DIMENSION_LEVEL_COLORS: Record<DimensionLevel, { color: string; bg: string }> = {
  high: { color: "#2743C6", bg: "#E9EBF8" },
  medium_high: { color: "#2E8A5C", bg: "#E4F2EA" },
  medium: { color: "#8A6B2E", bg: "#FBF3E4" },
  low: { color: "#A85C2E", bg: "#F7E3D2" },
  very_low: { color: "#8F412C", bg: "#F9EAE5" },
};

// ---- Initial report v2 ----

/** The backend serves v1 and v2 reports side by side (each row keeps the version it was generated
 * with), so every report/preview page branches on this before choosing a renderer. */
export function isReportV2(
  result: { report_version: string },
): result is FullReportV2Response | PreviewReportV2Response {
  return result.report_version === "report_v2";
}

/** v2 words the levels differently from v1's pills (design: Initial Report v2). */
export const V2_LEVEL_LABELS: Record<DimensionLevel, string> = {
  very_low: "خیلی پایین",
  low: "پایین",
  medium: "متوسط",
  medium_high: "نسبتاً بالا",
  high: "بالا",
};

/** The preview only carries levels, so its meters sit at each band's midpoint. */
export const V2_LEVEL_MIDPOINTS: Record<DimensionLevel, number> = {
  very_low: 10,
  low: 30,
  medium: 50,
  medium_high: 70,
  high: 90,
};

export const FINDING_AREA_LABELS: Record<FindingArea, string> = {
  work: "کار",
  relationship: "رابطه",
  decision: "تصمیم",
  stress: "استرس",
};
