import type { Profile } from "@/lib/api/schemas";

const COMPLETENESS_FIELDS = ["gender", "birth_year", "life_situation", "goal"] as const;

export function isProfileComplete(profile: Pick<Profile, (typeof COMPLETENESS_FIELDS)[number]>) {
  return COMPLETENESS_FIELDS.every((key) => profile[key] !== null && profile[key] !== undefined);
}
