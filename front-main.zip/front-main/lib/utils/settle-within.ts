// Resolves when `promise` settles or after `ms`, whichever comes first -- never rejects.
// For awaiting best-effort work (analytics) without letting it hold up the caller.
export function settleWithin(promise: Promise<unknown>, ms: number): Promise<void> {
  return Promise.race([
    promise.then(
      () => undefined,
      () => undefined,
    ),
    new Promise<void>((resolve) => setTimeout(resolve, ms)),
  ]);
}
