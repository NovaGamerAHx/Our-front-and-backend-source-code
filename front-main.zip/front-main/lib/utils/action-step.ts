import type { ActionStep, ActionStepChannel, ActionStepObstacle, DeadlineType } from "@/lib/api/schemas";

/** Persian labels for the 4 deadline_type values -- shared by the chat action card, the report
 * proposal sheet, the step detail sheet, and the checkin card (step-notification-card.tsx). */
export const DEADLINE_TEXT: Record<DeadlineType, string> = {
  tonight: "امشب",
  tomorrow_morning: "فردا صبح",
  tomorrow_evening: "فردا عصر",
  within_24h: "تا ۲۴ ساعت آینده",
};

export const DEADLINE_OPTIONS: { value: DeadlineType; label: string }[] = (
  Object.entries(DEADLINE_TEXT) as [DeadlineType, string][]
).map(([value, label]) => ({ value, label }));

/** Same 5 values as the backend's ActionStepResponse.Obstacle enum (mirrors the old
 * FollowupResponse.Obstacle) -- order and wording match the design. */
export const OBSTACLE_OPTIONS: { value: ActionStepObstacle; label: string }[] = [
  { value: "no_time", label: "وقت نشد" },
  { value: "didnt_know_where_to_start", label: "نمی‌دانستم از کجا شروع کنم" },
  { value: "wanted_to_think_more", label: "می‌خواستم بیشتر فکر کنم" },
  { value: "lost_importance", label: "اهمیتش کم شد" },
  { value: "other", label: "دلیل دیگر" },
];

export const ACTION_STEP_SOURCE_LABELS: Record<string, string> = {
  chat: "گفتگو",
};

/** A step's `source` is "chat", "initial_report:rec_<n>" or "deep_report:action_<n>" --
 * this maps it to the short Persian badge label the design shows on each pending/history row. */
export function actionStepSourceLabel(source: string): string {
  if (source in ACTION_STEP_SOURCE_LABELS) return ACTION_STEP_SOURCE_LABELS[source];
  if (source.startsWith("initial_report:")) return "گزارش";
  if (source.startsWith("deep_report:")) return "گزارش عمیق";
  return source;
}

/**
 * The dashboard's source *filter* groups by category, not by the literal `source` string --
 * "initial_report:rec_1" and "initial_report:rec_2" are both "از گزارش", not two separate
 * filters. Fixed 3 categories (design's stepFilters), always offered regardless of what's
 * actually present in the current pending list.
 */
export const SOURCE_CATEGORIES = ["report", "deep_report", "chat"] as const;
export type SourceCategory = (typeof SOURCE_CATEGORIES)[number];

export const SOURCE_CATEGORY_LABELS: Record<SourceCategory, string> = {
  report: "از گزارش اولیه",
  deep_report: "از گزارش عمیق",
  chat: "از گفتگو",
};

export function actionStepSourceCategory(source: string): SourceCategory {
  if (source.startsWith("initial_report:")) return "report";
  if (source.startsWith("deep_report:")) return "deep_report";
  return "chat";
}

export const CHANNEL_FOR_DASHBOARD: ActionStepChannel = "dashboard";

/** How close a pending step is to its deadline -- drives the step card's tint on the dashboard
 * instead of the old dark notification card. Followup wins over reminder, mirroring the old
 * pickNotifStep priority. */
export type StepUrgency = "overdue" | "approaching" | null;

export function actionStepUrgency(step: ActionStep, now: number): StepUrgency {
  if (new Date(step.followup_at).getTime() <= now) return "overdue";
  if (new Date(step.remind_at).getTime() <= now) return "approaching";
  return null;
}
