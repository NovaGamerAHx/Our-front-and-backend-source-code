import { toPersianDigits } from "@/lib/utils/digits";

/** "٬"-grouped Persian-digit Toman string, e.g. 199000 -> "۱۹۹٬۰۰۰ تومان". */
export function formatToman(toman: number): string {
  const grouped = Math.round(toman)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, "٬");
  return `${toPersianDigits(grouped)} تومان`;
}

export type PaywallPricing = {
  /** The real, post-discount price from the backend (Product.price). */
  price: string;
  /** Pre-discount price, struck through. `null` when no promotion is running (percent <= 0). */
  oldPrice: string | null;
  /** Amber promo badge copy, e.g. "٪۵۰ تخفیف". `null` when no promotion is running. */
  discountBadge: string | null;
};

/**
 * Given the real price (Toman, from the backend) and a discount percent (env-configured,
 * default 50), derive what the paywall price card shows. `percent` is the share *already taken
 * off*, so the pre-discount price is `real / (1 - percent/100)`, rounded to the nearest 1,000
 * Toman. `percent <= 0` means no promotion: just the price, no badge, no strikethrough
 * (design README, "when no promotion is active, hide the badge and the struck-through price").
 */
export function computePaywallPricing(realToman: number, percent: number): PaywallPricing {
  const price = formatToman(realToman);

  if (!Number.isFinite(percent) || percent <= 0 || percent >= 100) {
    return { price, oldPrice: null, discountBadge: null };
  }

  const oldToman = Math.round(realToman / (1 - percent / 100) / 1000) * 1000;
  return {
    price,
    oldPrice: formatToman(oldToman),
    discountBadge: `٪${toPersianDigits(Math.round(percent))} تخفیف`,
  };
}

/**
 * Discount percent for the paywall, from `PAYWALL_DISCOUNT_PERCENT` (server-only env var).
 * Defaults to 50; a missing/blank/invalid value falls back to the default, `0` disables the
 * promotion.
 */
export function paywallDiscountPercent(): number {
  const raw = process.env.PAYWALL_DISCOUNT_PERCENT;
  if (raw === undefined || raw.trim() === "") return 50;
  const parsed = Number(raw);
  return Number.isFinite(parsed) ? parsed : 50;
}
