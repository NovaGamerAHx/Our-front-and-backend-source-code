import type { DeepDomainScore, DeepLevel } from "@/lib/api/schemas";

export const DEEP_LEVEL_LABELS: Record<DeepLevel, string> = {
  low: "پایین",
  mid: "میانه",
  high: "بالا",
};

const DEEP_LEVEL_SEGMENT: Record<DeepLevel, number> = { low: 0, mid: 1, high: 2 };

/** The three-band strip next to a domain/facet level pill — deliberately not a percentage bar
 * (deep-report.md §2.4/§9: no score is ever shown, only low/mid/high). `variant: "dark"` is for
 * the strip drawn over a navy section background, `"light"` for the default white-card one. */
export function deepLevelBands(level: DeepLevel, variant: "light" | "dark" = "light"): string[] {
  const seg = DEEP_LEVEL_SEGMENT[level];
  const active = variant === "dark" ? "linear-gradient(90deg,#E8B98F,#F0D2AE)" : "linear-gradient(90deg,#2743C6,#8E6BA8)";
  const inactive = variant === "dark" ? "rgba(255,255,255,.16)" : "#EDE7DA";
  return [0, 1, 2].map((i) => (i === seg ? active : inactive));
}

export const DEEP_TOPIC_LABELS = {
  decision_style: "سبک تصمیم‌گیری",
  communication_style: "سبک ارتباطی",
  work_style: "سبک کاری و رهبری",
  stress_and_energy: "استرس، انرژی و بازیابی",
  learning_and_growth: "یادگیری و رشد",
  close_relationships: "روابط نزدیک",
} as const;

export const DEEP_TOPIC_LEADS: Record<keyof typeof DEEP_TOPIC_LABELS, string> = {
  decision_style: "چطور بین گزینه‌ها انتخاب می‌کنی — از سرعت گرفته تا اینکه چقدر جا برای تجدیدنظر می‌گذاری.",
  communication_style: "الگوی حضور تو در گفتگو — چیزهایی که دیگران احتمالاً از تعامل با تو تجربه می‌کنند.",
  work_style: "ریتم کار و رهبری‌ات — از ساختار و نظم تا واگذاری و اعتماد به دیگران.",
  stress_and_energy: "چه چیزی انرژی‌ات را می‌گیرد، از کجا دوباره پرش می‌کنی، و چطور از فشار برمی‌گردی.",
  learning_and_growth: "شیوهٔ یادگیری‌ات — از پذیرش تجربهٔ تازه تا تبدیل آموخته‌ها به اقدام.",
  close_relationships: "الگوی تو در نزدیک‌ترین رابطه‌هایت — نزدیکی، اعتماد و مرزبندی.",
};

// The five-axis radar chart is a fixed pentagon (top, then clockwise), same layout convention as
// the initial report's own radar (lib/utils/report.ts) — matched to the deep test's domain codes
// instead of the initial test's dimension keys, since the two scales are not comparable
// (deep-report.md §1: this test's N is emotional REACTIVITY, the opposite direction of the
// initial test's emotional_stability).
const DEEP_DOMAIN_ANGLES: Record<string, number> = { N: -90, E: -18, O: 54, A: 126, C: 198 };

const DEEP_RADAR_CENTER = 100;
const DEEP_RADAR_INNER = 14;
const DEEP_RADAR_SPAN = 74;
// Un-normed data can't render as a percentage (deep-report.md §2.4) -- these three fixed radii
// are what "low/mid/high" look like on the shape, not a measured distance.
const DEEP_LEVEL_RADIUS_FRACTION: Record<DeepLevel, number> = { low: 0.42, mid: 0.68, high: 0.94 };

function deepRadarPoint(angleDeg: number, fraction: number): string {
  const rad = (angleDeg * Math.PI) / 180;
  const r = DEEP_RADAR_INNER + fraction * DEEP_RADAR_SPAN;
  const x = DEEP_RADAR_CENTER + r * Math.cos(rad);
  const y = DEEP_RADAR_CENTER + r * Math.sin(rad);
  return `${x.toFixed(1)},${y.toFixed(1)}`;
}

export function computeDeepRadarPolygon(domainScores: DeepDomainScore[]): string {
  return domainScores
    .map((d) => deepRadarPoint(DEEP_DOMAIN_ANGLES[d.code] ?? 0, DEEP_LEVEL_RADIUS_FRACTION[d.level]))
    .join(" ");
}

/** One of the three reference rings behind the filled shape, at a fixed level radius (not tied
 * to any one domain's actual level). */
export function computeDeepRadarRing(domainScores: DeepDomainScore[], fraction: number): string {
  return domainScores.map((d) => deepRadarPoint(DEEP_DOMAIN_ANGLES[d.code] ?? 0, fraction)).join(" ");
}

export type DeepAxisLabel = {
  code: string;
  name: string;
  level: string;
  /** Center of the label box, as a percentage of the square chart wrapper's side. */
  left: string;
  top: string;
};

/** Label ring radius, in percent of the square chart wrapper's half-side. The chart SVG itself
 * only covers the middle 62% of that wrapper (see the radar in deep-report-view), so its outermost
 * vertex sits at ~27% — the gap up to 36% is the breathing room the names need. Positions are
 * percentages because the names are laid out as real HTML boxes with a fixed width and normal
 * wrapping: as SVG <text> the long Persian domain titles ("واکنش‌پذیری هیجانی") could not wrap and
 * ran into each other and into the column beside the chart. */
const DEEP_AXIS_LABEL_RADIUS = 36;

export function computeDeepAxisLabels(domainScores: DeepDomainScore[]): DeepAxisLabel[] {
  return domainScores.map((d) => {
    const rad = ((DEEP_DOMAIN_ANGLES[d.code] ?? 0) * Math.PI) / 180;
    return {
      code: d.code,
      name: d.title,
      level: DEEP_LEVEL_LABELS[d.level],
      left: (50 + DEEP_AXIS_LABEL_RADIUS * Math.cos(rad)).toFixed(1),
      top: (50 + DEEP_AXIS_LABEL_RADIUS * Math.sin(rad)).toFixed(1),
    };
  });
}
