import dayjs from "dayjs";
import "dayjs/locale/fa";
import jalaliday from "jalaliday/dayjs";
import { toPersianDigits } from "./digits";

dayjs.extend(jalaliday);

/** Format an ISO date string as a Shamsi (Jalali) date with Persian digits, e.g. "۱۵ تیر ۱۴۰۴". */
export function formatJalali(isoDate: string, format = "D MMMM YYYY"): string {
  const formatted = dayjs(isoDate).calendar("jalali").locale("fa").format(format);
  return toPersianDigits(formatted);
}

/** The current Shamsi (Jalali) year, e.g. 1404. */
export function currentJalaliYear(): number {
  return Number(dayjs().calendar("jalali").format("YYYY"));
}
