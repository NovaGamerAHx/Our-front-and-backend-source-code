/**
 * The browser could not reach our own server at all -- a dropped connection, airplane mode,
 * captive-wifi. Worded as the user's connection, not ours: the previous generic
 * "الان کمی شلوغ است" wrongly blamed the backend for what is a client-side outage.
 */
export const CONNECTION_ERROR_MESSAGE =
  "ارتباط با اینترنت برقرار نیست. لطفاً اتصال خود را بررسی کنید و دوباره تلاش کنید.";

export type ActionResult<T> = { ok: true; data: T } | { ok: false; message: string };

/** navigator.onLine only ever reports a *definite* disconnect -- true means "maybe online". */
export function isOffline(): boolean {
  return typeof navigator !== "undefined" && navigator.onLine === false;
}

/**
 * fetch() rejects with a TypeError when the request never completed (DNS/TCP/TLS failure, the
 * connection dropping mid-body). Aborts arrive as an AbortError DOMException instead, so they
 * never land here. A Server Action call fails the same way -- it is a fetch() underneath.
 */
export function isConnectionError(error: unknown): boolean {
  return error instanceof TypeError || isOffline();
}

/**
 * Server Actions convert backend failures into `{ ok: false, message }` on the server, so a
 * *rejection* here means the round-trip itself failed. Without this the rejection is unhandled
 * and the screen just silently does nothing.
 */
export async function callAction<T>(
  call: Promise<ActionResult<T>>,
  fallbackMessage: string,
): Promise<ActionResult<T>> {
  try {
    return await call;
  } catch (error) {
    return {
      ok: false,
      message: isConnectionError(error) ? CONNECTION_ERROR_MESSAGE : fallbackMessage,
    };
  }
}
