import { z } from "zod";
export const workspaceContextSchema = z.object({
  report: z
    .object({
      attempt_id: z.number(),
      report_type: z.enum(["initial", "deep"]),
      completed_at: z.string().nullable(),
      scores: z.array(
        z.object({ code: z.string(), title: z.string(), score: z.number().min(0).max(100) }),
      ),
      findings: z.array(z.object({ key: z.string(), text: z.string() })),
    })
    .nullable(),
});
export type WorkspaceReport = NonNullable<z.infer<typeof workspaceContextSchema>["report"]>;
