import "server-only";
import { cache } from "react";
import { cookies } from "next/headers";
import { ACCESS_TOKEN_COOKIE } from "@/lib/api/constants";
import {
  getProfile,
  listChatSessions,
  getReportAttemptsHistory,
  getReport,
  getWorkspaceContext,
} from "@/lib/api/endpoints";
import type { ReportAttemptHistoryItem } from "@/lib/api/schemas";

// Request-local deduplication only. Never share personal workspace data between users.
export const getWorkspaceData = cache(async () => {
  const authenticated = (await cookies()).has(ACCESS_TOKEN_COOKIE);
  if (!authenticated)
    return { authenticated, profile: null, sessions: [], history: [], historyUnavailable: false };
  const [profile, sessions, history] = await Promise.all([
    getProfile().catch(() => null),
    listChatSessions().catch(() => []),
    getReportAttemptsHistory().catch(() => null),
  ]);
  return {
    authenticated,
    profile,
    sessions,
    history: history ?? [],
    historyUnavailable: history === null,
  };
});
export const getWorkspaceReport = cache((id: number) => getReport(id).catch(() => null));
export function reportHref(item: ReportAttemptHistoryItem) {
  if (item.status === "awaiting_payment") return `/paywall?deepAttemptId=${item.attempt_id}`;
  if (item.status === "generating") {
    return item.report_type === "deep"
      ? `/deep-test/analysis?attemptId=${item.attempt_id}`
      : `/test/analysis?attemptId=${item.attempt_id}`;
  }
  if (item.status === "error") {
    return item.report_type === "deep"
      ? `/deep-test/analysis?attemptId=${item.attempt_id}&retry=1`
      : `/test/analysis?attemptId=${item.attempt_id}&retry=1`;
  }
  return `/${item.report_type === "deep" ? "deep-report" : "report"}?attemptId=${item.attempt_id}`;
}
export function reportChatHref(
  item: Pick<ReportAttemptHistoryItem, "attempt_id" | "report_type">,
  message?: string,
  from = "/explore",
) {
  const query = new URLSearchParams({
    entry_source: item.report_type === "deep" ? "deep_report_cta" : "report_cta",
    attempt_id: String(item.attempt_id),
    from,
  });
  if (message) query.set("initial_message", message);
  return `/chat?${query}`;
}

export const getCanonicalContext = cache(() => getWorkspaceContext().catch(() => null));
