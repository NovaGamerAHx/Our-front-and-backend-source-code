"use client";

import { toast } from "sonner";
import { trackEventAction } from "@/lib/api/track-event-action";

const MAX_MESSAGE_LENGTH = 200;

/** Shows an error toast and records it as a client_error_shown event for the given flow. */
export function toastClientError(context: string, message: string) {
  toast.error(message);
  void trackEventAction({
    event_name: "client_error_shown",
    properties: { context, message: message.slice(0, MAX_MESSAGE_LENGTH) },
  });
}
