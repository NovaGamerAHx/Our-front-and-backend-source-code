const UTM_KEYS = ["utm_source", "utm_medium", "utm_campaign"] as const;
const MAX_UTM_LENGTH = 100;

/** utm_* values from the current URL, trimmed and length-capped; absent keys are omitted. */
export function readUtmParams(): Record<string, string> {
  const query = new URLSearchParams(window.location.search);
  const utm: Record<string, string> = {};
  for (const key of UTM_KEYS) {
    const value = query.get(key)?.trim();
    if (value) utm[key] = value.slice(0, MAX_UTM_LENGTH);
  }
  return utm;
}

/** Cookie holding the visitor's campaign, read server-side by requestOtpAction at signup. */
export const UTM_COOKIE = "faraman_utm";
export const UTM_COOKIE_MAX_AGE = 60 * 60 * 24 * 30;

export type UtmAttribution = { utm_source?: string; utm_campaign?: string };

/** Parses the UTM_COOKIE value; anything malformed is treated as no attribution. */
export function parseUtmCookie(raw: string | undefined): UtmAttribution {
  if (!raw) return {};
  try {
    const data = JSON.parse(decodeURIComponent(raw)) as Record<string, unknown>;
    const out: UtmAttribution = {};
    if (typeof data.utm_source === "string") out.utm_source = data.utm_source.slice(0, MAX_UTM_LENGTH);
    if (typeof data.utm_campaign === "string") out.utm_campaign = data.utm_campaign.slice(0, MAX_UTM_LENGTH);
    return out;
  } catch {
    return {};
  }
}
