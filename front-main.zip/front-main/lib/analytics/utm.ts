const UTM_KEYS = ["utm_source", "utm_medium", "utm_campaign"] as const;
const MAX_UTM_LENGTH = 100;

/** utm_* values from the current URL, trimmed and length-capped; absent keys are omitted. */
export function readUtmParams(): Record<string, string> {
  const query = new URLSearchParams(window.location.search);
  const utm: Record<string, string> = {};
  for (const key of UTM_KEYS) {
    const value = query.get(key)?.trim();
    if (value) utm[key] = value.slice(0, MAX_UTM_LENGTH);
  }
  return utm;
}

/** Cookie holding the visitor's campaign, read server-side by requestOtpAction at signup. */
export const UTM_COOKIE = "faraman_utm";
export const UTM_COOKIE_MAX_AGE = 60 * 60 * 24 * 30;

export type UtmAttribution = { utm_source?: string; utm_campaign?: string };

/** Parses the UTM_COOKIE value; anything malformed is treated as no attribution. */
export function parseUtmCookie(raw: string | undefined): UtmAttribution {
  if (!raw) return {};
  try {
    const data = JSON.parse(decodeURIComponent(raw)) as Record<string, unknown>;
    const out: UtmAttribution = {};
    if (typeof data.utm_source === "string") out.utm_source = data.utm_source.slice(0, MAX_UTM_LENGTH);
    if (typeof data.utm_campaign === "string") out.utm_campaign = data.utm_campaign.slice(0, MAX_UTM_LENGTH);
    return out;
  } catch {
    return {};
  }
}

// ---- Short-link campaign defaults (shared by proxy.ts + short-links.ts) ----
// Defined here (not in server-only short-links.ts) so the Edge proxy can read them too.
// Keep in sync: proxy.ts applies these for /flc7 and /c9 when the URL carries no UTM.

export type UtmParams = {
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
};

/** Default campaign for the ultra-short payment link (/flc7) when the URL carries no UTM. */
export const DEFAULT_PAY_UTM: UtmParams = {
  utm_source: "sms",
  utm_medium: "sms",
  utm_campaign: "faraman75",
};

/** Default campaign for the ultra-short deep-test link (/c9) when the URL carries no UTM. */
export const DEFAULT_DEEP_UTM: UtmParams = {
  utm_source: "sms",
  utm_medium: "sms",
  utm_campaign: "deep-invite",
};

/** UTM values from a URLSearchParams, trimmed and length-capped; absent keys omitted. */
export function readUtmFromSearch(search: URLSearchParams): UtmParams {
  const utm: UtmParams = {};
  for (const key of UTM_KEYS) {
    const value = search.get(key)?.trim();
    if (value) utm[key] = value.slice(0, MAX_UTM_LENGTH);
  }
  return utm;
}

/** Merge URL-provided UTM over defaults (provided wins per key; missing keys fall back). */
export function withDefaultUtm(provided: UtmParams, defaults: UtmParams): UtmParams {
  return { ...defaults, ...provided };
}

/**
 * faraman_utm cookie value for `utm`, or null when there's nothing to persist (no
 * utm_source and no utm_campaign -- matching UtmCapture, which leaves any existing cookie
 * untouched in that case). Same name/format as UtmCapture so requestOtpAction and
 * trackEventAction read it identically.
 */
export function buildUtmCookieValue(utm: UtmParams): string | null {
  if (!utm.utm_source && !utm.utm_campaign) return null;
  // Raw JSON, not encodeURIComponent(...): the serializers percent-encode the value exactly
  // once (document.cookie in UtmCapture, and the manual Set-Cookie header in proxy.ts) and
  // parseUtmCookie decodes exactly once. Pre-encoding here would double-encode it and
  // parseUtmCookie would then fail to JSON.parse, silently dropping the campaign.
  return JSON.stringify({ utm_source: utm.utm_source, utm_campaign: utm.utm_campaign });
}
