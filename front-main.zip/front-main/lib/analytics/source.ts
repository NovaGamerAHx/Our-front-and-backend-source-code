const MAX_SOURCE_LENGTH = 40;

/** Where a visitor came from (the `source` query param); anything absent or malformed is "direct". */
export function sanitizeSource(raw: string | undefined): string {
  const value = raw?.trim().toLowerCase().slice(0, MAX_SOURCE_LENGTH);
  return value && /^[a-z0-9_]+$/.test(value) ? value : "direct";
}
