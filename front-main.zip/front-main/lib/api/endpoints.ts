import "server-only";
import { z } from "zod";
import { apiFetch, apiFetchCached, apiMutate, updateUserTag } from "./client";
import {
  emptySchema,
  profileSchema,
  refreshTokenResponseSchema,
  tokenPairSchema,
  reportResultSchema,
  generatingReportResponseSchema,
  reportEmailInputSchema,
  reportHistoryItemSchema,
  reportAttemptHistoryItemSchema,
  trackEventInputSchema,
  productPriceSchema,
  assessmentSchema,
  attemptSchema,
  answerRecordSchema,
  submitFeedbackInputSchema,
  demographicsSchema,
  patchedDemographicsInputSchema,
  patchedProfileInputSchema,
  preStartResponseSchema,
  initiatePaymentResponseSchema,
  entitlementSchema,
  createChatSessionInputSchema,
  chatSessionSchema,
  chatSessionSummarySchema,
  chatSessionMessageSchema,
  submitMessageFeedbackInputSchema,
  bookmarkedMessageSchema,
  actionStepSchema,
  editActionStepInputSchema,
  completeActionStepInputSchema,
  recordActionStepReflectionInputSchema,
  submitActionStepFollowupInputSchema,
  reactivateActionStepInputSchema,
  registerPushSubscriptionInputSchema,
  type Assessment,
  type Attempt,
  type AnswerRecord,
  type Profile,
  type ReportResult,
  type GeneratingReportResponse,
  type ReportHistoryItem,
  type ReportAttemptHistoryItem,
  type SubmitAnswerInput,
  type SubmitFeedbackInput,
  type TrackEventInput,
  type Demographics,
  type PatchedDemographicsInput,
  type PatchedProfileInput,
  type PreStartResponse,
  type InitiatePaymentResponse,
  type Entitlement,
  type ProductPrice,
  type CreateChatSessionInput,
  type ChatSession,
  type ChatSessionSummary,
  type ChatSessionMessage,
  type SubmitMessageFeedbackInput,
  type BookmarkedMessage,
  type ActionStep,
  type EditActionStepInput,
  type CompleteActionStepInput,
  type RecordActionStepReflectionInput,
  type SubmitActionStepFollowupInput,
  type ReactivateActionStepInput,
  type RegisterPushSubscriptionInput,
  registerPushSubscriptionResultSchema,
} from "./schemas";

// ---- Auth (real) ----

export function sendOtp(phoneNumber: string, utm: { utm_source?: string; utm_campaign?: string } = {}) {
  return apiMutate("/api/account/otp/send/", emptySchema, {
    method: "POST",
    body: { phone_number: phoneNumber, ...utm },
  });
}

export function verifyOtp(phoneNumber: string, code: string) {
  return apiMutate("/api/account/otp/verify/", tokenPairSchema, {
    method: "POST",
    body: { phone_number: phoneNumber, code },
  });
}

export function refreshAccessToken(refresh: string) {
  return apiMutate("/api/account/token/refresh/", refreshTokenResponseSchema, {
    method: "POST",
    body: { refresh },
  });
}

export function logout(refresh: string) {
  return apiMutate("/api/account/logout/", emptySchema, {
    method: "POST",
    body: { refresh },
  });
}

// ---- Profile (real) ----

export function getProfile(): Promise<Profile> {
  return apiFetchCached("/api/account/profile/", profileSchema, { tag: "profile", revalidate: 60 });
}

export async function updateProfile(input: PatchedProfileInput): Promise<Profile> {
  const body = patchedProfileInputSchema.parse(input);
  const profile = await apiMutate("/api/account/profile/", profileSchema, { method: "PATCH", body });
  await updateUserTag("profile");
  return profile;
}

export async function acceptTerms() {
  const result = await apiMutate("/api/account/terms/accept/", emptySchema, { method: "POST" });
  await updateUserTag("profile");
  return result;
}

export function deleteAccount() {
  return apiMutate("/api/account/delete/", emptySchema, { method: "POST" });
}

// ---- Demographics (real) — works for both authenticated and anonymous callers. ----

export function getDemographics(): Promise<Demographics> {
  return apiFetchCached("/api/account/profile/demographics/", demographicsSchema, {
    tag: "demographics",
    revalidate: 300,
  });
}

export async function updateDemographics(input: PatchedDemographicsInput): Promise<Demographics> {
  const body = patchedDemographicsInputSchema.parse(input);
  const demographics = await apiMutate("/api/account/profile/demographics/", demographicsSchema, {
    method: "PATCH",
    body,
  });
  await updateUserTag("demographics");
  return demographics;
}

// ---- Events (real) ----

export function trackEvent(input: TrackEventInput) {
  const body = trackEventInputSchema.parse(input);
  return apiMutate("/api/events/track/", emptySchema, { method: "POST", body });
}

// ---- Assessment/attempt (real) ----

export function getAssessment(slug: string): Promise<Assessment> {
  return apiFetch(`/api/assessments/${slug}/`, assessmentSchema);
}

/**
 * Info to show before starting an assessment: the caller's latest report for it (if any,
 * gated the same way as GET report detail) and how many new attempts remain in today's
 * limit. Works before signup — anonymous callers get their own anonymous_id-scoped answer.
 */
export function getPreStart(slug: string): Promise<PreStartResponse> {
  return apiFetch(`/api/assessments/${slug}/pre-start/`, preStartResponseSchema);
}

export function startAttempt(assessmentSlug: string): Promise<Attempt> {
  return apiMutate("/api/assessments/attempts/", attemptSchema, {
    method: "POST",
    body: { assessment_slug: assessmentSlug },
  });
}

export function submitAnswer(attemptId: number, input: SubmitAnswerInput): Promise<AnswerRecord> {
  return apiMutate(`/api/assessments/attempts/${attemptId}/answers/`, answerRecordSchema, {
    method: "POST",
    body: input,
  });
}

export function deleteAnswer(attemptId: number, questionId: number): Promise<null> {
  return apiMutate(`/api/assessments/attempts/${attemptId}/answers/${questionId}/`, emptySchema, {
    method: "DELETE",
  });
}

export async function completeAttempt(attemptId: number): Promise<Attempt> {
  const attempt = await apiMutate(`/api/assessments/attempts/${attemptId}/complete/`, attemptSchema, {
    method: "POST",
  });
  await updateUserTag("report-history");
  return attempt;
}

// ---- Payment (real) ----

/**
 * Starts a Zarinpal payment to unlock a requires_purchase assessment, optionally discounted by a
 * coupon code. The caller must redirect the browser to the returned payment_url (Zarinpal's own
 * hosted pay page -- it can't be embedded) unless `unlocked` comes back true, meaning a 100%-off
 * coupon fully covered the price and access was already granted with no gateway hop. The backend
 * handles Zarinpal's callback itself and redirects the buyer straight to /payment/result, so
 * there's no separate "verify" call on the frontend.
 */
export function initiatePayment(
  assessmentSlug: string,
  couponCode?: string,
  attemptId?: number,
): Promise<InitiatePaymentResponse> {
  return apiMutate("/api/payment/initiate/", initiatePaymentResponseSchema, {
    method: "POST",
    body: { assessment_slug: assessmentSlug, coupon_code: couponCode, attempt_id: attemptId },
  });
}

/** Every active product plus whether the authenticated caller owns it. Authenticated only --
 * throws ApiError(401) for an anonymous caller, same as any other IsAuthenticated endpoint. */
export function getEntitlements(): Promise<Entitlement[]> {
  return apiFetchCached("/api/users/me/entitlements/", z.array(entitlementSchema), {
    tag: "entitlements",
    revalidate: 300,
  });
}

// ---- Report (real) ----

/**
 * Gated server-side by the backend itself: an anonymous caller gets back `stage: "preview"`
 * (teaser fields only), an authenticated owner gets `stage: "full"`. Throws ApiError(404) if no
 * report exists yet for this attempt (e.g. it isn't complete/scoreable) and ApiError(403) if the
 * caller doesn't own the attempt.
 */
export function getReport(attemptId: number): Promise<ReportResult> {
  return apiFetch(`/api/reports/attempts/${attemptId}/`, reportResultSchema);
}

/**
 * Accepts the report's suggested_step/small_action at 1-based `index`, creating an ActionStep
 * directly (action_steps_spec_v2 §3) -- no chat detour. Backs "قدم اولش را بگیر" on both the
 * initial report's recommendations and the deep report's small_actions.
 */
export async function acceptReportStep(attemptId: number, index: number): Promise<ActionStep> {
  const step = await apiMutate(
    `/api/reports/attempts/${attemptId}/steps/${index}/accept/`,
    actionStepSchema,
    { method: "POST" },
  );
  await updateUserTag("action-steps");
  return step;
}

/**
 * Re-dispatches generation for a report that ended in error, reusing the attempt's already-
 * scored answers -- no re-test required. Returns the same `generating` shape a fresh attempt's
 * report does, so the caller can poll it the same way (see AnalysisLoader's retry mode).
 */
export async function retryReportGeneration(attemptId: number): Promise<GeneratingReportResponse> {
  const result = await apiMutate(
    `/api/reports/attempts/${attemptId}/retry/`,
    generatingReportResponseSchema,
    { method: "POST" },
  );
  await updateUserTag("report-history");
  return result;
}

/**
 * Emails the report (initial or deep) to `email` -- not persisted anywhere, sent ad hoc from
 * whatever the user typed into the report page's email card.
 */
export function sendReportEmail(attemptId: number, email: string) {
  const body = reportEmailInputSchema.parse({ email });
  return apiMutate(`/api/reports/attempts/${attemptId}/email/`, emptySchema, {
    method: "POST",
    body,
  });
}

// ---- Feedback (real) ----

export function submitFeedback(input: SubmitFeedbackInput) {
  const body = submitFeedbackInputSchema.parse(input);
  return apiMutate("/api/feedback/", emptySchema, { method: "POST", body });
}

/** Every active product's price. Works for anonymous callers, unlike getEntitlements. */
export function getProductPrices(): Promise<ProductPrice[]> {
  return apiFetchCached("/api/payment/products/", z.array(productPriceSchema), {
    tag: "product-prices",
    revalidate: 300,
  });
}

// ---- Report history (real) ----

export function getReportHistory(): Promise<ReportHistoryItem[]> {
  return apiFetchCached("/api/reports/history/", z.array(reportHistoryItemSchema), {
    tag: "report-history",
    revalidate: 60,
  });
}

/**
 * "History of attempts", not just successful reports -- backs the کاوش hub's attempts list so a
 * still-generating or failed attempt stays visible, and a failed one can be retried without
 * re-taking the test. Same cache tag as getReportHistory() so completeAttempt/retry invalidate
 * both lists together.
 */
export function getReportAttemptsHistory(): Promise<ReportAttemptHistoryItem[]> {
  return apiFetchCached("/api/reports/attempts-history/", z.array(reportAttemptHistoryItemSchema), {
    tag: "report-history",
    revalidate: 30,
  });
}

// ---- Chat (real) ----
// The streaming send-message call is NOT here -- it goes through
// app/api/chat/sessions/[sessionId]/messages/route.ts instead, since apiFetch/apiMutate buffer
// a single JSON envelope and can't be used for an SSE response.

export function createChatSession(input: CreateChatSessionInput): Promise<ChatSession> {
  const body = createChatSessionInputSchema.parse(input);
  return apiMutate("/api/chat/sessions/", chatSessionSchema, { method: "POST", body });
}

export async function acceptChatAction(messageId: number): Promise<ActionStep> {
  const step = await apiMutate(`/api/chat/messages/${messageId}/accept-action/`, actionStepSchema, {
    method: "POST",
  });
  await updateUserTag("action-steps");
  return step;
}

export function listChatSessions(): Promise<ChatSessionSummary[]> {
  return apiFetch("/api/chat/sessions/", z.array(chatSessionSummarySchema));
}

export function getChatSessionMessages(sessionId: string): Promise<ChatSessionMessage[]> {
  return apiFetch(`/api/chat/sessions/${sessionId}/messages/`, z.array(chatSessionMessageSchema));
}

export function deleteChatSession(sessionId: string) {
  return apiMutate(`/api/chat/sessions/${sessionId}/`, emptySchema, { method: "DELETE" });
}

// The streaming regenerate call, like send-message above, is NOT here -- it goes through
// app/api/chat/sessions/[sessionId]/messages/[messageId]/regenerate/route.ts for the same reason.

// ---- Message feedback/bookmark (real) ----

export function submitMessageFeedback(messageId: number, input: SubmitMessageFeedbackInput) {
  const body = submitMessageFeedbackInputSchema.parse(input);
  return apiMutate(`/api/messages/${messageId}/feedback/`, emptySchema, { method: "POST", body });
}

export function removeMessageFeedback(messageId: number) {
  return apiMutate(`/api/messages/${messageId}/feedback/`, emptySchema, { method: "DELETE" });
}

export function bookmarkMessage(messageId: number) {
  return apiMutate(`/api/messages/${messageId}/bookmark/`, emptySchema, { method: "POST" });
}

export function removeMessageBookmark(messageId: number) {
  return apiMutate(`/api/messages/${messageId}/bookmark/`, emptySchema, { method: "DELETE" });
}

export function getBookmarkedMessages(): Promise<BookmarkedMessage[]> {
  return apiFetch("/api/messages/bookmarked/", z.array(bookmarkedMessageSchema));
}

// ---- Action steps v2 (real — GET/POST /api/action-steps/*). acceptReportStep() above creates
// the first step; everything else here manages it afterward. ----

/** "قدم‌های جاری" -- every pending step, optionally filtered to one source. */
export function listPendingActionSteps(source?: string): Promise<ActionStep[]> {
  const query = source ? `?${new URLSearchParams({ source }).toString()}` : "";
  return apiFetchCached(`/api/action-steps/${query}`, z.array(actionStepSchema), {
    tag: "action-steps",
    revalidate: 30,
  });
}

/** "تاریخچهٔ قدم‌ها" -- done/partial/not_done steps, newest first. */
export function listActionStepHistory(): Promise<ActionStep[]> {
  return apiFetchCached("/api/action-steps/history/", z.array(actionStepSchema), {
    tag: "action-steps",
    revalidate: 30,
  });
}

/** A single step -- backs the Step Detail sheet and the checkin notification deep-link. */
export function getActionStep(actionStepId: string): Promise<ActionStep> {
  return apiFetch(`/api/action-steps/${actionStepId}/`, actionStepSchema);
}

export async function editActionStep(
  actionStepId: string,
  input: EditActionStepInput,
): Promise<ActionStep> {
  const body = editActionStepInputSchema.parse(input);
  const step = await apiMutate(`/api/action-steps/${actionStepId}/`, actionStepSchema, {
    method: "PATCH",
    body,
  });
  await updateUserTag("action-steps");
  return step;
}

/** Self-serve "I did it" -- optionally carries the completion reflection text. */
export async function completeActionStep(
  actionStepId: string,
  input: CompleteActionStepInput = {},
): Promise<ActionStep> {
  const body = completeActionStepInputSchema.parse(input);
  const step = await apiMutate(`/api/action-steps/${actionStepId}/complete/`, actionStepSchema, {
    method: "POST",
    body,
  });
  await updateUserTag("action-steps");
  return step;
}

/** The optional "چطور بود؟" reflection, recorded after the step is already done. */
export async function recordActionStepReflection(
  actionStepId: string,
  input: RecordActionStepReflectionInput,
): Promise<ActionStep> {
  const body = recordActionStepReflectionInputSchema.parse(input);
  const step = await apiMutate(`/api/action-steps/${actionStepId}/reflection/`, actionStepSchema, {
    method: "POST",
    body,
  });
  await updateUserTag("action-steps");
  return step;
}

/** Notif-tap and dashboard-history "چرا انجام نشد" responses, differentiated by `channel`. */
export async function submitActionStepFollowup(
  actionStepId: string,
  input: SubmitActionStepFollowupInput,
): Promise<ActionStep> {
  const body = submitActionStepFollowupInputSchema.parse(input);
  const step = await apiMutate(`/api/action-steps/${actionStepId}/followup/`, actionStepSchema, {
    method: "POST",
    body,
  });
  await updateUserTag("action-steps");
  return step;
}

/** Creates a new step from a not_done one; the original row is left untouched. */
export async function reactivateActionStep(
  actionStepId: string,
  input: ReactivateActionStepInput,
): Promise<ActionStep> {
  const body = reactivateActionStepInputSchema.parse(input);
  const step = await apiMutate(`/api/action-steps/${actionStepId}/reactivate/`, actionStepSchema, {
    method: "POST",
    body,
  });
  await updateUserTag("action-steps");
  return step;
}

// ---- Push notifications (real) ----

export function registerPushSubscription(input: RegisterPushSubscriptionInput) {
  const body = registerPushSubscriptionInputSchema.parse(input);
  return apiMutate("/api/notifications/push-subscriptions/", registerPushSubscriptionResultSchema, {
    method: "POST",
    body,
  });
}
