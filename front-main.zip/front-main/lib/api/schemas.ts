import { z } from "zod";

// ---- Real backend contract (from /api/schema/) ----

export const requestOtpInputSchema = z.object({
  phone_number: z.string().max(20),
});
export type RequestOtpInput = z.infer<typeof requestOtpInputSchema>;

export const verifyOtpInputSchema = z.object({
  phone_number: z.string().max(20),
  code: z.string().max(5),
});
export type VerifyOtpInput = z.infer<typeof verifyOtpInputSchema>;

export const tokenPairSchema = z.object({
  access: z.string(),
  refresh: z.string(),
});
export type TokenPair = z.infer<typeof tokenPairSchema>;

export const genderValueSchema = z.enum(["female", "male"]);
export type GenderValue = z.infer<typeof genderValueSchema>;

export const genderSchema = z
  .union([genderValueSchema, z.literal(""), z.null()])
  .transform((v) => (v === "" ? null : v));

export const lifeSituationValueSchema = z.enum([
  "student",
  "employed",
  "self_employed",
  "job_seeking",
  "transitioning",
  "family_care",
  "other"])
export type LifeSituationValue = z.infer<typeof lifeSituationValueSchema>;

export const goalValueSchema = z.enum([
  "decisions",
  "mastery",
  "growth",
  "relationships",
  "purpose",
  "self_regard",
  "stress",
  "unsure"])
export type GoalValue = z.infer<typeof goalValueSchema>;

// birth_year/gender/life_situation/goal are the same 4 "demographic" fields also exposed
// standalone (pre-signup) via /api/account/profile/demographics/ — see the Demographics
// schema below. Age/education/job/disorder exist on the backend too but aren't surfaced
// anywhere in the current design, so they're left out of this schema.
//
// Unlike the demographics endpoint (verified live), the real /api/account/profile/ response
// doesn't reliably match the documented enum|null shape for these four fields — e.g. an unset
// birth_year is sometimes just absent rather than null. `.catch(null)` treats any value that
// doesn't parse (missing, blank, or an unrecognized shape) as "unset" instead of failing the
// whole profile fetch — safe because these fields are display-only and optional everywhere.
export const profileSchema = z.object({
  id: z.number(),
  phone_number: z.string(),
  name: z.string().nullable(),
  gender: genderSchema.catch(null),
  birth_year: z.number().nullable().catch(null),
  life_situation: lifeSituationValueSchema.nullable().catch(null),
  goal: goalValueSchema.nullable().catch(null),
  reference_code: z.string(),
  terms_version: z.string().nullable(),
  terms_accepted_at: z.string().nullable(),
});
export type Profile = z.infer<typeof profileSchema>;

export const patchedProfileInputSchema = z.object({
  name: z.string().max(100).nullable().optional(),
  gender: genderValueSchema.optional(),
  birth_year: z.number().int().min(1300).max(1450).optional(),
  life_situation: lifeSituationValueSchema.optional(),
  goal: goalValueSchema.optional(),
});
export type PatchedProfileInput = z.infer<typeof patchedProfileInputSchema>;

// ---- Demographics (real — GET/PATCH /api/account/profile/demographics/, from /api/schema/).
// Works for both authenticated and anonymous callers (stored against the anonymous_id cookie
// pre-signup) — the same underlying fields as above, exposed standalone so the pre-test/
// post-test flow doesn't require a signed-in Profile fetch. `answered` isn't in the documented
// schema but is present on the actual response (confirmed by calling the backend directly) —
// it's true once any of the four fields has been set. ----

export const demographicsSchema = z.object({
  birth_year: z.number().nullable(),
  gender: genderSchema,
  life_situation: lifeSituationValueSchema.nullable(),
  goal: goalValueSchema.nullable(),
  answered: z.boolean(),
});
export type Demographics = z.infer<typeof demographicsSchema>;

export const patchedDemographicsInputSchema = z.object({
  birth_year: z.number().int().min(1300).max(1450).optional(),
  gender: genderValueSchema.optional(),
  life_situation: lifeSituationValueSchema.optional(),
  goal: goalValueSchema.optional(),
});
export type PatchedDemographicsInput = z.infer<typeof patchedDemographicsInputSchema>;

// The envelope's `data` field is `null` for endpoints with no real payload.
export const emptySchema = z.null();

export const logoutInputSchema = z.object({
  refresh: z.string(),
});

export const refreshTokenInputSchema = z.object({
  refresh: z.string(),
});

// SimpleJWT normally returns a fresh access token; the swagger doc lists "no response
// body" for this endpoint, which looks like a doc gap rather than the real behavior.
export const refreshTokenResponseSchema = z.object({
  access: z.string(),
});

export const eventNameSchema = z.enum([
  "landing_viewed",
  "start_test_clicked",
  "auth_started",
  "auth_code_requested",
  "auth_code_request_failed",
  "test_started",
  "test_completed",
  "report_generated",
  "preview_viewed",
  "full_report_viewed",
  "login_after_preview",
  "checkin_notif_opened",
  "returned_to_chat_after_checkin",
  "test_intro_viewed",
  "paywall_viewed",
  "paywall_pay_clicked",
  "paywall_login_redirected",
  "push_permission_result",
  "otp_verify_failed",
  "otp_resend_clicked",
  "feedback_form_opened",
  "client_error_shown",
  "test_intro_start_clicked",
  "auth_completed",
  "deep_intro_viewed",
  "deep_questions_viewed",
  "chat_opened",
]);

export const trackEventInputSchema = z.object({
  event_name: eventNameSchema,
  properties: z.record(z.string(), z.unknown()).optional(),
  occurred_at: z.string().nullable().optional(),
});
export type TrackEventInput = z.infer<typeof trackEventInputSchema>;

// ---- Assessment/attempt contract (real — /api/assessments/*, confirmed by calling the
// backend directly since /api/schema/ documents no response bodies for these) ----

export const assessmentQuestionSchema = z.object({
  id: z.number(),
  order: z.number(),
  text: z.string(),
  question_type: z.string(),
  options: z.array(z.unknown()),
});
export type AssessmentQuestion = z.infer<typeof assessmentQuestionSchema>;

export const assessmentSchema = z.object({
  id: z.number(),
  slug: z.string(),
  title: z.string(),
  kind: z.string(),
  version: z.number(),
  requires_purchase: z.boolean(),
  questions: z.array(assessmentQuestionSchema),
});
export type Assessment = z.infer<typeof assessmentSchema>;

export const submitAnswerInputSchema = z.object({
  question_id: z.number(),
  value: z.number(),
});
export type SubmitAnswerInput = z.infer<typeof submitAnswerInputSchema>;

export const answerRecordSchema = z.object({
  id: z.number(),
  question_id: z.number(),
  value: z.number(),
  answered_at: z.string(),
});
export type AnswerRecord = z.infer<typeof answerRecordSchema>;

// status seen so far: "in_progress" | "completed"; error messages hint at a "stopped"
// state too, so this is left as a plain string rather than a closed enum.
// `answers` carries every previously-submitted answer so a resumed attempt can
// repopulate the form — the backend returns this on both start and resume.
export const attemptSchema = z.object({
  id: z.number(),
  assessment_slug: z.string(),
  status: z.string(),
  started_at: z.string(),
  completed_at: z.string().nullable(),
  answers: z.array(answerRecordSchema),
});
export type Attempt = z.infer<typeof attemptSchema>;

// ---- Payment (real — POST /api/payment/initiate/). Returns a Zarinpal-hosted payment_url the
// caller must redirect the browser to; the backend itself handles Zarinpal's callback and lands
// the buyer on /payment/result -- see apps/payment (backend). ----

export const initiatePaymentInputSchema = z.object({
  assessment_slug: z.string(),
  coupon_code: z.string().optional(),
  // Pay-after-test: the completed deep attempt whose locked report this payment unlocks.
  attempt_id: z.number().optional(),
});
export type InitiatePaymentInput = z.infer<typeof initiatePaymentInputSchema>;

// payment_url is null when a 100%-off coupon fully covered the price -- the backend grants
// access directly and there's no Zarinpal hop to redirect to.
export const initiatePaymentResponseSchema = z.object({
  payment_url: z.string().nullable(),
  unlocked: z.boolean(),
  attempt_id: z.number().nullable().optional(),
});
export type InitiatePaymentResponse = z.infer<typeof initiatePaymentResponseSchema>;

// ---- Entitlements (real — GET /api/users/me/entitlements/, from /api/schema/). Every active
// product plus whether the authenticated caller owns it -- used to gate the deep-test intro
// screen without waiting for a 402 from POST /api/assessments/attempts/. Authenticated only. ----

export const entitlementSchema = z.object({
  product_key: z.string(),
  title: z.string(),
  assessment_slug: z.string(),
  has_access: z.boolean(),
  // Product price in Toman (apps.payment.models.Product.price). The paywall treats this as the
  // real, post-discount price and derives the struck-through "old price" from it -- see
  // lib/utils/price.ts and app/paywall/page.tsx.
  price: z.number(),
});
export type Entitlement = z.infer<typeof entitlementSchema>;

// GET /api/payment/products/ -- same shape as an entitlement minus ownership, so the paywall
// can show the price to anonymous visitors.
export const productPriceSchema = entitlementSchema.omit({ has_access: true });
export type ProductPrice = z.infer<typeof productPriceSchema>;

// ---- Action step deadline (real — apps.action_steps.models.ActionStep.DeadlineType, and the
// same 4 values reused for chat's proposed_action). Declared here, ahead of both report contracts
// below, since report_spec_v1.6's `suggested_step` (on initial-report recommendations and, with
// the identical shape, deep-report small_actions) needs it already bound. ----

export const deadlineTypeSchema = z.enum([
  "tonight",
  "tomorrow_morning",
  "tomorrow_evening",
  "within_24h",
]);
export type DeadlineType = z.infer<typeof deadlineTypeSchema>;

// action_steps_spec_v2 §3/§3.1: the ready-to-accept step attached to a report recommendation or
// deep-report small_action. `substeps` is a short numbered list, only ever present when the step
// genuinely has internal structure -- almost always null (deep-report.md §6.5: always null there).
export const suggestedStepSchema = z.object({
  text: z.string(),
  deadline_text: z.string(),
  deadline_type: deadlineTypeSchema,
  substeps: z.array(z.string()).nullable(),
});
export type SuggestedStep = z.infer<typeof suggestedStepSchema>;

// ---- Deep report contract (real — GET /api/reports/attempts/{attempt_id}/ for a deep attempt,
// confirmed against apps/report/services/report_service.py's _build_deep and the fixed mock at
// apps/ai/deep_report_generation/mock/deep_report_mock.json. deep-report.md §6/§9 is the content
// spec. Unlike the initial report there is no preview/full split -- the deep test is always
// purchase-gated to an authenticated owner, so `get_report` raises ReportAccessDeniedException
// for anyone else instead of falling back to a teaser. Levels are always one of low/mid/high
// (deep-report.md §2.4) -- never a raw number or percent (§2.4, §9: "no score is ever shown").
// Declared ahead of the initial report's own contract below since reportResultSchema's union
// (further down) needs this name already bound. ----

export const deepLevelSchema = z.enum(["low", "mid", "high"]);
export type DeepLevel = z.infer<typeof deepLevelSchema>;

export const deepDomainScoreSchema = z.object({
  code: z.string(),
  title: z.string(),
  level: deepLevelSchema,
});
export type DeepDomainScore = z.infer<typeof deepDomainScoreSchema>;

export const deepFacetScoreSchema = z.object({
  code: z.string(),
  domain: z.string(),
  title: z.string(),
  level: deepLevelSchema,
});
export type DeepFacetScore = z.infer<typeof deepFacetScoreSchema>;

const deepDomainOverviewSchema = z.object({
  code: z.string(),
  title: z.string(),
  level: deepLevelSchema,
  description: z.string(),
});

const deepDomainFacetSchema = z.object({
  code: z.string(),
  level: deepLevelSchema,
  when_it_works: z.string(),
  when_it_costs: z.string(),
});

const deepDomainSectionSchema = z.object({
  code: z.string(),
  facets: z.array(deepDomainFacetSchema),
  summary: z.string(),
});

const deepStrengthItemSchema = z.object({
  title: z.string(),
  evidence: z.string(),
  value: z.string(),
  overuse: z.string(),
});

const deepBlindSpotItemSchema = z.object({
  hypothesis: z.string(),
  evidence: z.string(),
  trigger: z.string(),
  visible_sign: z.string(),
});

const deepTopicRowSchema = z.object({ topic: z.string(), text: z.string() });

// decision_style / communication_style / work_style / stress_and_energy / learning_and_growth /
// close_relationships all share this shape (deep-report.md §9: "one component is enough").
const deepTopicSectionSchema = z.object({
  rows: z.array(deepTopicRowSchema),
  closing: z.string(),
});

export const deepReportDataSchema = z.object({
  identity_line: z.string(),
  top_strengths: z.array(z.string()),
  growth_priorities: z.array(z.string()),
  confidence_note: z.string(),
  domains_overview: z.array(deepDomainOverviewSchema),
  integrated_interpretation: z.string(),
  domains: z.array(deepDomainSectionSchema),
  strengths: z.object({
    items: z.array(deepStrengthItemSchema),
    development_message: z.string(),
  }),
  blind_spots: z.object({
    items: z.array(deepBlindSpotItemSchema),
    reflection_questions: z.array(z.string()),
  }),
  decision_style: deepTopicSectionSchema,
  communication_style: deepTopicSectionSchema,
  work_style: deepTopicSectionSchema,
  stress_and_energy: deepTopicSectionSchema,
  learning_and_growth: deepTopicSectionSchema,
  close_relationships: deepTopicSectionSchema,
  closing: z.object({
    at_my_best: z.string(),
    under_pressure: z.string(),
    // deep-report.md §6.5: exactly the same suggested_step shape as the initial report's
    // recommendations, so both sources render/commit through the same UI.
    small_actions: z.array(suggestedStepSchema),
  }),
});
export type DeepReportData = z.infer<typeof deepReportDataSchema>;

export const deepReportResponseSchema = z.object({
  status: z.literal("ok"),
  report_type: z.literal("deep"),
  report_version: z.string(),
  report_id: z.number(),
  title: z.string(),
  disclaimer: z.string(),
  closing_reminder: z.string(),
  domain_scores: z.array(deepDomainScoreSchema),
  facet_scores: z.array(deepFacetScoreSchema),
  report: deepReportDataSchema,
});
export type DeepReportResponse = z.infer<typeof deepReportResponseSchema>;

// ---- Report contract (real — GET /api/reports/attempts/{attempt_id}/, confirmed by calling the
// backend directly since /api/schema/ documents no response body for this endpoint either.
// Gated server-side: unauthenticated callers get `stage: "preview"`, authenticated callers who
// own the attempt get `stage: "full"`. report_spec_v1.3 is the canonical content spec. ----

export const dimensionKeySchema = z.enum([
  "emotional_stability",
  "extraversion",
  "openness",
  "agreeableness",
  "conscientiousness",
]);
export type DimensionKey = z.infer<typeof dimensionKeySchema>;

export const dimensionLevelSchema = z.enum(["very_low", "low", "medium", "medium_high", "high"]);
export type DimensionLevel = z.infer<typeof dimensionLevelSchema>;

export const fullDimensionScoreSchema = z.object({
  key: dimensionKeySchema,
  score_percent: z.number(),
  level: dimensionLevelSchema,
});
export type FullDimensionScore = z.infer<typeof fullDimensionScoreSchema>;

export const previewDimensionScoreSchema = z.object({
  key: dimensionKeySchema,
  level: dimensionLevelSchema,
});
export type PreviewDimensionScore = z.infer<typeof previewDimensionScoreSchema>;

export const snapshotInterpretationSchema = z.object({
  key: dimensionKeySchema,
  text: z.string(),
});

export const reportStrengthSchema = z.object({
  title: z.string(),
  description: z.string(),
  why_it_matters: z.string(),
});

export const reportGrowthEdgeSchema = z.object({
  title: z.string(),
  description: z.string(),
  growth_reframe: z.string(),
});

export const lifePatternCardSchema = z.object({
  key: z.enum([
    "decision_style",
    "relationship_style",
    "work_learning_style",
    "stress_energy_pattern",
  ]),
  summary: z.string(),
  best_when: z.string(),
  watch_out: z.string(),
});

export const recommendationSchema = z.object({
  title: z.string(),
  description: z.string(),
  action_type: z.enum([
    "decision",
    "execution",
    "relationship",
    "learning",
    "wellbeing",
    "communication",
  ]),
  // Optional: reports generated before report_spec_v1.6 don't have this in their stored
  // report_data, and old rows are never backfilled -- viewing one of those must still work,
  // just without the "قدم اولش را بگیر" button.
  suggested_step: suggestedStepSchema.optional(),
});
export type Recommendation = z.infer<typeof recommendationSchema>;

export const reportDataSchema = z.object({
  summary: z.object({ one_line: z.string() }),
  snapshot_interpretations: z.array(snapshotInterpretationSchema),
  core_narrative: z.object({ body: z.string() }),
  key_strengths: z.array(reportStrengthSchema),
  growth_edges: z.array(reportGrowthEdgeSchema),
  life_pattern_cards: z.array(lifePatternCardSchema),
  growth_path: z.object({
    main_growth_focus: z.string(),
    why_this_matters: z.string(),
    growth_principle: z.string(),
    recommendations: z.array(recommendationSchema),
    // next_action_prompt removed in report_spec_v1.6 -- report.growth_path.recommendations[i]
    // .suggested_step above lets the user commit to a step directly, no chat detour needed.
  }),
});
export type ReportData = z.infer<typeof reportDataSchema>;

export const fullReportResponseSchema = z.object({
  status: z.literal("ok"),
  stage: z.literal("full"),
  report_version: z.string(),
  report_id: z.number().optional(),
  dimension_scores: z.array(fullDimensionScoreSchema),
  report: reportDataSchema,
});
export type FullReportResponse = z.infer<typeof fullReportResponseSchema>;

export const previewReportResponseSchema = z.object({
  status: z.literal("ok"),
  stage: z.literal("preview"),
  report_version: z.string(),
  preview: z.object({
    summary_one_line: z.string(),
    dimension_scores: z.array(previewDimensionScoreSchema),
    personality_pattern_first_paragraph: z.string(),
    first_strength: z.object({
      title: z.string(),
      description: z.string(),
    }),
    teaser_line: z.string(),
    locked_counts: z.object({
      strengths: z.number(),
      growth_edges: z.number(),
      recommendations: z.number(),
    }),
  }),
});
export type PreviewReportResponse = z.infer<typeof previewReportResponseSchema>;

// ---- Initial report v2 (report_spec_v2_0; backend `report_version: "report_v2"`). The backend
// keeps v1 rows in their old shape, so both coexist and the client picks a renderer from each
// response's own `report_version`. Declared before the union below so it can sit in front of the
// v1 schemas (their `report_version` is a plain string, only the `report` shape tells them apart).

export const reportV2VersionSchema = z.literal("report_v2");

export const findingAreaSchema = z.enum(["work", "relationship", "decision", "stress"]);
export type FindingArea = z.infer<typeof findingAreaSchema>;

export const reportV2FindingSchema = z.object({
  area: findingAreaSchema,
  title: z.string(),
  what: z.string(),
  cost: z.string(),
  curiosity: z.string(),
  // Exactly one finding (the first) carries a step; the second is null (spec §4.4).
  suggested_step: suggestedStepSchema.nullable(),
});
export type ReportV2Finding = z.infer<typeof reportV2FindingSchema>;

export const reportV2DataSchema = z.object({
  hook: z.string(),
  strength: z.object({ title: z.string(), text: z.string() }),
  findings_heading: z.string(),
  findings: z.array(reportV2FindingSchema),
  open_question: z.object({ text: z.string(), finding_index: z.number() }),
  exit: z.object({ bridge: z.string(), root_question: z.string() }),
});
export type ReportV2Data = z.infer<typeof reportV2DataSchema>;

export const fullReportV2ResponseSchema = z.object({
  status: z.literal("ok"),
  stage: z.literal("full"),
  report_version: reportV2VersionSchema,
  report_id: z.number().optional(),
  dimension_scores: z.array(fullDimensionScoreSchema),
  report: reportV2DataSchema,
});
export type FullReportV2Response = z.infer<typeof fullReportV2ResponseSchema>;

// Server-gated teaser (spec §5.4): cost/curiosity, the second finding's scene, the open question,
// the step and the exit card never reach the client before login.
export const previewReportV2ResponseSchema = z.object({
  status: z.literal("ok"),
  stage: z.literal("preview"),
  report_version: reportV2VersionSchema,
  preview: z.object({
    hook: z.string(),
    dimension_scores: z.array(previewDimensionScoreSchema),
    strength: z.object({ title: z.string(), text: z.string() }),
    findings_heading: z.string(),
    first_finding: z.object({ area: findingAreaSchema, title: z.string(), what: z.string() }),
    second_finding: z.object({ area: findingAreaSchema, title: z.string() }),
  }),
});
export type PreviewReportV2Response = z.infer<typeof previewReportV2ResponseSchema>;

export const errorReportResponseSchema = z.object({
  status: z.literal("error"),
  report_version: z.string(),
  error: z.object({
    code: z.string(),
    user_message: z.string(),
    should_display_report: z.boolean(),
  }),
});
export type ErrorReportResponse = z.infer<typeof errorReportResponseSchema>;

// The backend now generates both report types asynchronously (Celery) -- a report row is
// created as "generating" and filled in by a worker, so a GET can land mid-generation for
// either type, not just the deep one.
export const generatingReportResponseSchema = z.object({
  status: z.literal("generating"),
  report_type: z.string(),
  report_version: z.string(),
});
export type GeneratingReportResponse = z.infer<typeof generatingReportResponseSchema>;

// Pay-after-test: the deep test is free to take, but its finished report stays locked until a
// payment bound to that attempt is verified. The backend returns only this marker -- no scores
// or content -- so /deep-report sends the visitor to the paywall instead of rendering anything.
export const awaitingPaymentReportResponseSchema = z.object({
  status: z.literal("awaiting_payment"),
  report_type: z.string(),
  report_version: z.string(),
  payment_required: z.literal(true),
});
export type AwaitingPaymentReportResponse = z.infer<typeof awaitingPaymentReportResponseSchema>;

// Not a discriminatedUnion: "full", "preview" and the deep shape all share status "ok" with no
// single key carrying a distinct literal across every member (the deep shape has no `stage` at
// all, which is exactly what makes it fail fullReportResponseSchema/previewReportResponseSchema
// and fall through to deepReportResponseSchema below).
export const reportResultSchema = z.union([
  fullReportV2ResponseSchema,
  previewReportV2ResponseSchema,
  fullReportResponseSchema,
  previewReportResponseSchema,
  deepReportResponseSchema,
  generatingReportResponseSchema,
  awaitingPaymentReportResponseSchema,
  errorReportResponseSchema,
]);
export type ReportResult = z.infer<typeof reportResultSchema>;

// ---- Pre-start (real — GET /api/assessments/{slug}/pre-start/, confirmed by calling the backend
// directly since /api/schema/ documents no response body for this endpoint. Works before signup.
// `latest_report` is gated the same way as GET report detail (preview for anonymous, full for
// authenticated) and additionally carries `attempt_id` so the caller can link straight into it. ----

export const preStartLatestReportSchema = z
  .object({ attempt_id: z.number() })
  .and(reportResultSchema);
export type PreStartLatestReport = z.infer<typeof preStartLatestReportSchema>;

export const preStartResponseSchema = z.object({
  assessment_slug: z.string(),
  has_in_progress_attempt: z.boolean().default(false),
  has_previous_report: z.boolean(),
  latest_report: preStartLatestReportSchema.nullable(),
  remaining_attempts_today: z.number(),
  attempt_limit: z.number(),
});
export type PreStartResponse = z.infer<typeof preStartResponseSchema>;

// ---- Feedback (real — POST /api/feedback/, from /api/schema/). `report` and `app` are the
// two target_type values the backend currently supports. ----

// ---- Report email (real — POST /api/reports/attempts/<id>/email/). The address is never
// persisted -- it's whatever the user typed into the report page's email card, sent ad hoc. ----
export const reportEmailInputSchema = z.object({
  email: z.string().email(),
});
export type ReportEmailInput = z.infer<typeof reportEmailInputSchema>;

export const submitFeedbackInputSchema = z.object({
  target_type: z.enum(["report", "app"]),
  target_id: z.string().max(100),
  rate: z.number().min(0).max(5).nullable(),
  reason: z.string().max(40).default(""),
  comment: z.string().default(""),
});
export type SubmitFeedbackInput = z.infer<typeof submitFeedbackInputSchema>;

// ---- Report history (real — GET /api/reports/history/, from /api/schema/). One row per
// completed, scored attempt with a report, newest first. No is_current flag on the wire —
// the caller's first entry is the current report. `report_type` tells the caller which report
// route to link to (a mixed history can hold both an initial and a deep row). ----

export const reportHistoryItemSchema = z.object({
  attempt_id: z.number(),
  report_id: z.number(),
  report_type: z.enum(["initial", "deep"]),
  completed_at: z.string(),
  summary_one_line: z.string(),
});
export type ReportHistoryItem = z.infer<typeof reportHistoryItemSchema>;

// ---- Report attempts history (real — GET /api/reports/attempts-history/, from /api/schema/).
// One row per attempt with a report of ANY status (generating/ok/error), newest first — unlike
// the OK-only history above, this backs the کاوش "history of attempts" page so a still-
// generating or failed attempt stays visible, and a failed one stays retryable (POST
// /api/reports/attempts/{id}/retry/) instead of silently disappearing when generation doesn't
// succeed on the first try. ----

export const reportAttemptStatusSchema = z.enum(["generating", "awaiting_payment", "ok", "error"]);
export type ReportAttemptStatus = z.infer<typeof reportAttemptStatusSchema>;

export const reportAttemptHistoryItemSchema = z.object({
  attempt_id: z.number(),
  report_id: z.number(),
  report_type: z.enum(["initial", "deep"]),
  status: reportAttemptStatusSchema,
  completed_at: z.string(),
  // "" unless status is ok/error respectively -- nothing to show yet otherwise.
  summary_one_line: z.string(),
  error_message: z.string(),
});
export type ReportAttemptHistoryItem = z.infer<typeof reportAttemptHistoryItemSchema>;

// ---- Chat (real — chat_spec_v1.md). `entry_source` is fixed for a session's lifetime and is
// only ever set by us when creating it, never echoed back by the backend. The streaming
// send-message call itself doesn't go through apiFetch/apiMutate (see app/api/chat/.../route.ts)
// but its SSE payloads are still worth validating with these same schemas client-side. ----

// chat_spec_v3 §1.1 / deep_report_spec_v1_1.md §1. `action_preview:rec_<n>` is gone -- the
// report creates step 1 directly now (no forced chat detour) -- replaced by the four action
// sources, which carry `action_step_id` instead of `attempt_id`. `action_missed` = a step the
// user accepted but did not do, opened from the dashboard's Step History; the backend requires
// its bound step to be not_done/partial. `action_active` = a step the user accepted whose
// deadline hasn't passed yet, opened from the Step Detail sheet's "بیا درباره‌اش حرف بزنیم"
// button (action_step.md §6.2); the backend requires its bound step to still be pending.
export const chatEntrySourceSchema = z.enum([
  "manual",
  "report_cta",
  // Initial report v2 only: the "answer this in chat" button under the report's open question.
  // The question is shown on the empty chat screen but is display-only, never a message.
  "report_open_question",
  // Initial report v2 only: the chat button inside one finding card (0 = first, 1 = second).
  // Same idea as deep_report_focus: tells the model which finding the user came from.
  "report_finding_focus:0",
  "report_finding_focus:1",
  "action_rejected",
  "action_completed",
  "action_missed",
  "action_active",
  "deep_report_cta",
  "deep_report_focus:domain_N",
  "deep_report_focus:domain_E",
  "deep_report_focus:domain_O",
  "deep_report_focus:domain_A",
  "deep_report_focus:domain_C",
  "deep_report_focus:strengths",
  "deep_report_focus:blind_spots",
  "deep_report_focus:decision_style",
  "deep_report_focus:communication_style",
  "deep_report_focus:work_style",
  "deep_report_focus:stress_and_energy",
  "deep_report_focus:learning_and_growth",
  "deep_report_focus:close_relationships",
]);
export type ChatEntrySource = z.infer<typeof chatEntrySourceSchema>;

export const createChatSessionInputSchema = z.object({
  entry_source: chatEntrySourceSchema,
  attempt_id: z.number().optional(),
  // Required for entry_source action_rejected/action_completed/action_missed/action_active
  // (chat_spec_v3 §1.1/§1.4).
  action_step_id: z.string().optional(),
  // action_rejected only, and only when action_step_id is omitted: the 1-based index (with
  // attempt_id above) of a report suggested_step/small_action rejected before it was ever
  // accepted -- action_step.md §3, no ActionStep row exists yet for those.
  index: z.number().optional(),
});
export type CreateChatSessionInput = z.infer<typeof createChatSessionInputSchema>;

export const chatSessionSchema = z.object({
  session_id: z.string(),
});
export type ChatSession = z.infer<typeof chatSessionSchema>;

// Same enum as deadlineTypeSchema above -- kept under this name too since it's already the
// established import everywhere in the chat/checkin UI.
export const chatDeadlineTypeSchema = deadlineTypeSchema;
export type ChatDeadlineType = DeadlineType;

// chat_spec_v3 §2.4: chat output is always a *new* step -- a step can only be rejected before
// it is accepted, so there is never a row to replace. `id` is retired (still tolerated here in
// case an older backend emits it; accept-action ignores it). `substeps` mirrors
// report_spec_v1.6's suggested_step (almost always null).
export const chatProposedActionSchema = z.object({
  id: z.string().nullable().optional(),
  text: z.string(),
  deadline_text: z.string(),
  deadline_type: chatDeadlineTypeSchema,
  substeps: z.array(z.string()).nullable().optional(),
});
export type ChatProposedAction = z.infer<typeof chatProposedActionSchema>;

// The `done` SSE event. `message_id` is a backend->frontend-only addition (not part of the
// AI-service contract) needed to target POST /api/chat/messages/{id}/accept-action/.
// `generation_meta` is internal/analytics data (chat_spec_v1.md §2.6) and deliberately omitted.
export const chatDoneEventSchema = z.object({
  status: z.literal("ok"),
  prompt_version: z.string(),
  message_id: z.number(),
  message: z.string(),
  proposed_action: chatProposedActionSchema.nullable(),
  // Tap-able reply options for this turn -- also not part of the AI-service contract, mutually
  // exclusive with proposed_action.
  quick_replies: z.array(z.string()).nullable(),
});
export type ChatDoneEvent = z.infer<typeof chatDoneEventSchema>;

export const chatErrorEventSchema = z.object({
  status: z.literal("error"),
  code: z.string(),
  user_message: z.string(),
});
export type ChatErrorEvent = z.infer<typeof chatErrorEventSchema>;

// GET /api/chat/sessions/ and GET /api/chat/sessions/{id}/messages/ -- not part of
// chat_spec_v1.md (which defines no such endpoints), added purely so the frontend can read back
// history the backend already persists.

export const chatSessionSummarySchema = z.object({
  session_id: z.string(),
  entry_source: z.string(),
  created_at: z.string(),
  preview: z.string().nullable(),
  last_message_at: z.string(),
});
export type ChatSessionSummary = z.infer<typeof chatSessionSummarySchema>;

export const chatMessageRoleSchema = z.enum(["user", "assistant"]);
export type ChatMessageRole = z.infer<typeof chatMessageRoleSchema>;

export const chatSessionMessageSchema = z.object({
  id: z.number(),
  role: chatMessageRoleSchema,
  content: z.string(),
  proposed_action: chatProposedActionSchema.nullable(),
  quick_replies: z.array(z.string()).nullable(),
  action_accepted: z.boolean(),
  created_at: z.string(),
  // The requester's own vote/bookmark on this message (null/false if none) -- lets the chat
  // screen restore highlighted thumbs-up/down and a filled bookmark icon on reopen.
  is_useful: z.boolean().nullable(),
  is_bookmarked: z.boolean(),
});
export type ChatSessionMessage = z.infer<typeof chatSessionMessageSchema>;

// ---- Message feedback/bookmark/regenerate (real — POST /api/messages/{id}/feedback/, POST+DELETE
// /api/messages/{id}/bookmark/, GET /api/messages/bookmarked/). All three only ever act on the
// caller's own assistant messages. Regenerate has no request/response schema of its own -- it's a
// POST that streams the same delta/done/error SSE shape as sending a message
// (chatDoneEventSchema/chatErrorEventSchema above), proxied the same way. ----

export const submitMessageFeedbackInputSchema = z.object({
  is_useful: z.boolean(),
});
export type SubmitMessageFeedbackInput = z.infer<typeof submitMessageFeedbackInputSchema>;

export const bookmarkedMessageSchema = z.object({
  message_id: z.number(),
  session_id: z.string(),
  content: z.string(),
  created_at: z.string(),
  bookmarked_at: z.string(),
});
export type BookmarkedMessage = z.infer<typeof bookmarkedMessageSchema>;

// Shared step-response vocabulary, reused by action_steps_spec_v2 below.
export const followupResultSchema = z.enum(["done", "partial", "not_done"]);
export type FollowupResult = z.infer<typeof followupResultSchema>;

export const followupObstacleSchema = z.enum([
  "no_time",
  "didnt_know_where_to_start",
  "wanted_to_think_more",
  "lost_importance",
  "other",
]);
export type FollowupObstacle = z.infer<typeof followupObstacleSchema>;

// ---- Action steps v2 (real — GET/POST /api/action-steps/*, POST
// /api/reports/attempts/{id}/steps/{index}/accept/). A step can come from a report
// recommendation, a deep report small_action, or chat (source), and multiple can be pending at
// once. ----

export const actionStepStatusSchema = z.enum(["pending", "done", "partial", "not_done"]);
export type ActionStepStatus = z.infer<typeof actionStepStatusSchema>;

// Reuses the result/obstacle vocabulary above, and adds a `dashboard` channel for the Step
// History "چرا انجام نشد" flow.
export const actionStepFollowupResultSchema = followupResultSchema;
export type ActionStepFollowupResult = FollowupResult;

export const actionStepObstacleSchema = followupObstacleSchema;
export type ActionStepObstacle = FollowupObstacle;

export const actionStepChannelSchema = z.enum(["notif", "login", "dashboard"]);
export type ActionStepChannel = z.infer<typeof actionStepChannelSchema>;

export const actionStepLatestResponseSchema = z.object({
  result: actionStepFollowupResultSchema,
  obstacle: actionStepObstacleSchema.or(z.literal("")),
  channel: actionStepChannelSchema,
});
export type ActionStepLatestResponse = z.infer<typeof actionStepLatestResponseSchema>;

export const actionStepSchema = z.object({
  id: z.string(),
  source: z.string(),
  step_text: z.string(),
  substeps: z.array(z.string()).nullable(),
  deadline_type: deadlineTypeSchema,
  deadline_at: z.string(),
  remind_at: z.string(),
  followup_at: z.string(),
  status: actionStepStatusSchema,
  // action_step.md v2.2 §8.0: the obstacle answer ("چه چیزی جلویش را گرفت؟") and the timestamp
  // of whichever answer (reflection or obstacle) was last recorded now live on the row itself.
  obstacle: actionStepObstacleSchema.or(z.literal("")),
  answered_at: z.string().nullable(),
  edit_count: z.number(),
  edited_at: z.string().nullable(),
  completed_at: z.string().nullable(),
  created_at: z.string(),
  // Step History (action_step.md §6.2): a not_done/partial row that's already been answered
  // shows that answer instead of the reactivate/answer buttons; a done row shows its
  // completion reflection, if any.
  latest_response: actionStepLatestResponseSchema.nullable(),
  reflection_text: z.string().nullable(),
});
export type ActionStep = z.infer<typeof actionStepSchema>;

export const editActionStepInputSchema = z.object({
  step_text: z.string().optional(),
  deadline_type: deadlineTypeSchema.optional(),
});
export type EditActionStepInput = z.infer<typeof editActionStepInputSchema>;

export const completeActionStepInputSchema = z.object({
  reflection_text: z.string().optional(),
});
export type CompleteActionStepInput = z.infer<typeof completeActionStepInputSchema>;

// The "چطور بود؟" reflection, sent on its own after the step is already done (the skip path
// never sends it, so unlike complete's field this one is required).
export const recordActionStepReflectionInputSchema = z.object({
  reflection_text: z.string().min(1),
});
export type RecordActionStepReflectionInput = z.infer<typeof recordActionStepReflectionInputSchema>;

export const submitActionStepFollowupInputSchema = z.object({
  result: actionStepFollowupResultSchema,
  obstacle: actionStepObstacleSchema.nullable().optional(),
  channel: actionStepChannelSchema,
});
export type SubmitActionStepFollowupInput = z.infer<typeof submitActionStepFollowupInputSchema>;

export const reactivateActionStepInputSchema = z.object({
  deadline_type: deadlineTypeSchema,
});
export type ReactivateActionStepInput = z.infer<typeof reactivateActionStepInputSchema>;

// ---- Push notifications (real — POST/DELETE /api/notifications/push-subscriptions/). `token`
// is the FCM registration token from the browser's getToken() call. ----

export const registerPushSubscriptionInputSchema = z.object({ token: z.string() });
export type RegisterPushSubscriptionInput = z.infer<typeof registerPushSubscriptionInputSchema>;

// `token_was_inactive`: this exact token had been deactivated server-side (FCM rejected it), so
// the browser is still handing out a dead token and the client should mint a fresh one.
// Nullable so a frontend deployed ahead of the backend (which used to answer `data: null`) still works.
export const registerPushSubscriptionResultSchema = z.object({ token_was_inactive: z.boolean() }).nullable();
export type RegisterPushSubscriptionResult = z.infer<typeof registerPushSubscriptionResultSchema>;
