"use server";

import { cookies } from "next/headers";
import { UTM_COOKIE, parseUtmCookie } from "@/lib/analytics/utm";
import { trackEvent } from "./endpoints";
import type { TrackEventInput } from "./schemas";

// Analytics must never break the UX it's observing — swallow failures.
export async function trackEventAction(input: TrackEventInput) {
  try {
    // Attach the visitor's campaign to every event. Explicit properties (e.g. UTM read from
    // the landing URL) win over the cookie.
    const utm = parseUtmCookie((await cookies()).get(UTM_COOKIE)?.value);
    await trackEvent({ ...input, properties: { ...utm, ...input.properties } });
  } catch {
    // best-effort
  }
}
