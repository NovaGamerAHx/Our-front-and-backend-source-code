export const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8000";

/** This site's own public URL -- server-side only, deliberately NOT inferred from a request's
 * Host/origin (app/api/payment/callback/route.ts used to do that and broke in production behind
 * a reverse proxy that doesn't forward the original Host, redirecting buyers to the container's
 * internal bind address instead of the real domain). Set explicitly, same as FRONTEND_URL on
 * the backend. */
export const APP_URL = process.env.APP_URL ?? "http://localhost:3000";

/** httpOnly cookies we own, set after otp/verify. Never read/set from client components. */
export const ACCESS_TOKEN_COOKIE = "faraman_access";
export const REFRESH_TOKEN_COOKIE = "faraman_refresh";

/** The only self-knowledge assessment currently published on the backend. */
export const SELF_KNOWLEDGE_ASSESSMENT_SLUG = "test-likert-v2";

/** The paid supplementary assessment unlocked via Zarinpal -- see apps/payment (backend) and
 * apps/payment/management/commands/seed_deep_assessment.py, which seeds it for local dev.
 * "deep-test-v1" is a retired placeholder slug the seed command deactivates -- don't reuse it. */
export const DEEP_ASSESSMENT_SLUG = "deep-150-v1";

/** Firebase Web app config (public, not secret) -- from Firebase Console > Project Settings >
 * General > Your apps > Web app. Used to init the client SDK for push notifications. */
export const FIREBASE_CONFIG = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY ?? "",
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN ?? "",
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID ?? "",
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET ?? "",
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID ?? "",
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID ?? "",
};

/** Firebase Console > Project Settings > Cloud Messaging > Web configuration > Web Push
 * certificate. Distinct from a raw VAPID keypair -- this one is tied to the Firebase project. */
export const FCM_VAPID_KEY = process.env.NEXT_PUBLIC_FCM_VAPID_KEY ?? "";
