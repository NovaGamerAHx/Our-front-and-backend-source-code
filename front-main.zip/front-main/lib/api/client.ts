import "server-only";
import { createHash } from "node:crypto";
import { cookies } from "next/headers";
import { revalidateTag, unstable_cache, updateTag } from "next/cache";
import { z, type ZodType } from "zod";
import { API_BASE_URL, ACCESS_TOKEN_COOKIE, REFRESH_TOKEN_COOKIE } from "./constants";

// Every response (success and error) is wrapped in this envelope — confirmed by
// calling the real backend, not by the OpenAPI schema, which just says "no
// response body" for several endpoints that actually return { code, message, data }.
const envelopeSchema = z.object({
  code: z.number(),
  message: z.string(),
  data: z.unknown(),
});

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public data?: unknown,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

type RequestOptions = {
  method?: "GET" | "POST" | "PATCH" | "DELETE";
  body?: unknown;
  cache?: RequestCache;
};

async function buildForwardedCookieHeader(): Promise<string> {
  const store = await cookies();
  return store
    .getAll()
    .filter((c) => c.name !== ACCESS_TOKEN_COOKIE && c.name !== REFRESH_TOKEN_COOKIE)
    .map((c) => `${c.name}=${c.value}`)
    .join("; ");
}

/** Parses one Set-Cookie header value into the shape cookies().set() expects. */
function parseSetCookie(raw: string) {
  const [pair, ...attrParts] = raw.split(";").map((s) => s.trim());
  const eq = pair.indexOf("=");
  const name = pair.slice(0, eq);
  const value = pair.slice(eq + 1);

  const attrs: Record<string, string | boolean> = {};
  for (const part of attrParts) {
    const [key, val] = part.split("=");
    attrs[key.toLowerCase()] = val ?? true;
  }

  return {
    name,
    value,
    path: typeof attrs.path === "string" ? attrs.path : "/",
    maxAge: typeof attrs["max-age"] === "string" ? Number(attrs["max-age"]) : undefined,
    httpOnly: Boolean(attrs.httponly),
    secure: Boolean(attrs.secure),
    sameSite:
      typeof attrs.samesite === "string"
        ? (attrs.samesite.toLowerCase() as "lax" | "strict" | "none")
        : undefined,
  };
}

/**
 * DRF validation errors land in the envelope's `data` as { field: string[] }, while
 * `message` is just a generic "submitted data is invalid" — surface the specific
 * field errors when present, e.g. "کد وارد شده باید ۴ رقم و فقط شامل عدد باشد."
 */
function extractErrorMessage(envelope: { message: string; data: unknown }): string {
  if (envelope.data && typeof envelope.data === "object" && !Array.isArray(envelope.data)) {
    const fieldErrors = Object.values(envelope.data as Record<string, unknown>)
      .flat()
      .filter((v): v is string => typeof v === "string");
    if (fieldErrors.length > 0) return fieldErrors.join(" ");
  }
  return envelope.message;
}

type AuthHeaders = { accessToken?: string; cookieHeader?: string };

/** The bare HTTP call, with no envelope validation -- shared by `request` and the cached path. */
async function performRequest(
  path: string,
  options: RequestOptions,
  auth: AuthHeaders,
): Promise<{ raw: unknown; response: Response }> {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    method: options.method ?? "GET",
    headers: {
      "Content-Type": "application/json",
      ...(auth.cookieHeader ? { Cookie: auth.cookieHeader } : {}),
      ...(auth.accessToken ? { Authorization: `Bearer ${auth.accessToken}` } : {}),
    },
    body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
    cache: options.cache,
  });

  const contentType = res.headers.get("content-type") ?? "";
  const rawBody = contentType.includes("application/json")
    ? await res.json().catch(() => null)
    : null;
  return { raw: rawBody, response: res };
}

function unwrapEnvelope<T>(schema: ZodType<T>, rawBody: unknown, res: Response): T {
  const envelope = envelopeSchema.safeParse(rawBody);
  if (!res.ok) {
    const message = envelope.success ? extractErrorMessage(envelope.data) : res.statusText;
    throw new ApiError(res.status, message, rawBody);
  }
  return schema.parse(envelope.success ? envelope.data.data : undefined);
}

async function request<T>(
  path: string,
  schema: ZodType<T>,
  options: RequestOptions,
  { relayCookies }: { relayCookies: boolean },
): Promise<T> {
  const store = await cookies();
  const access = store.get(ACCESS_TOKEN_COOKIE)?.value;
  const cookieHeader = await buildForwardedCookieHeader();

  const { raw, response } = await performRequest(path, options, {
    accessToken: access,
    cookieHeader,
  });

  if (relayCookies) {
    for (const rawCookie of response.headers.getSetCookie()) {
      const cookie = parseSetCookie(rawCookie);
      store.set(cookie.name, cookie.value, {
        path: cookie.path,
        maxAge: cookie.maxAge,
        httpOnly: cookie.httpOnly,
        secure: cookie.secure,
        sameSite: cookie.sameSite,
      });
    }
  }

  return unwrapEnvelope(schema, raw, response);
}

/**
 * Ties a cache entry/tag to the caller's identity without putting the raw access token in a
 * cache key (which `unstable_cache` may log/persist) -- short hash of the token, "anon" when
 * signed out. Two different users never share an entry; a token refresh just costs one miss.
 */
function userCacheKey(accessToken: string | undefined): string {
  if (!accessToken) return "anon";
  return createHash("sha256").update(accessToken).digest("hex").slice(0, 16);
}

function scopedTag(tag: string, key: string): string {
  return `${tag}:${key}`;
}

/**
 * Like `apiFetch`, but the result is cached across requests (not just deduped within one) via
 * `unstable_cache`, scoped per-user. Only forwards the bearer token -- not the full cookie jar --
 * since `unstable_cache` includes its arguments in the cache key, and the other cookies (e.g. an
 * anonymous session id) can change without meaning this user's data changed, which would
 * needlessly fragment the cache. Use only for authenticated, own-account reads; call
 * `revalidateUserTag(tag)` from whatever mutation invalidates this data.
 */
export async function apiFetchCached<T>(
  path: string,
  schema: ZodType<T>,
  { tag, revalidate = 60 }: { tag: string; revalidate?: number | false },
): Promise<T> {
  const store = await cookies();
  const access = store.get(ACCESS_TOKEN_COOKIE)?.value;
  const key = userCacheKey(access);

  const cached = unstable_cache(
    async (accessToken: string | undefined) => {
      const { raw, response } = await performRequest(path, { method: "GET" }, { accessToken });
      return unwrapEnvelope(schema, raw, response);
    },
    [path, key],
    { tags: [scopedTag(tag, key)], revalidate },
  );

  return cached(access);
}

/**
 * Invalidates every `apiFetchCached` entry tagged `tag` for the current caller, immediately --
 * the next read waits for fresh data instead of serving stale content. Only callable from
 * within a Server Action (a Next constraint of `updateTag`); use `revalidateUserTag` from Route
 * Handlers instead.
 */
export async function updateUserTag(tag: string): Promise<void> {
  const store = await cookies();
  const key = userCacheKey(store.get(ACCESS_TOKEN_COOKIE)?.value);
  updateTag(scopedTag(tag, key));
}

/**
 * Invalidates every `apiFetchCached` entry tagged `tag` for the current caller with
 * stale-while-revalidate semantics. Use this (not `updateUserTag`) from Route Handlers, where
 * `updateTag` isn't allowed.
 */
export async function revalidateUserTag(tag: string): Promise<void> {
  const store = await cookies();
  const key = userCacheKey(store.get(ACCESS_TOKEN_COOKIE)?.value);
  revalidateTag(scopedTag(tag, key), "max");
}

/**
 * For reads in Server Components. Forwards cookies/auth to the backend but cannot
 * persist any Set-Cookie the backend sends back — Server Components are read-only.
 */
export function apiFetch<T>(
  path: string,
  schema: ZodType<T>,
  options: Omit<RequestOptions, "method"> = {},
): Promise<T> {
  return request(path, schema, { ...options, method: "GET" }, { relayCookies: false });
}

/**
 * For mutations inside Server Actions / Route Handlers. Same as apiFetch, but also
 * relays any Set-Cookie from the backend (e.g. the anonymous session cookie) to the browser.
 */
export function apiMutate<T>(
  path: string,
  schema: ZodType<T>,
  options: RequestOptions = {},
): Promise<T> {
  return request(path, schema, options, { relayCookies: true });
}
