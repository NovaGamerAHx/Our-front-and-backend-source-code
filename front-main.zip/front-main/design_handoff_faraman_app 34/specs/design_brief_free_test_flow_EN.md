# Design Brief — Free Test Flow, Preview, Login, Dashboard & Report History

**Owner:** PM · **Audience:** Designer (Claude Design) · **Status:** Decisions finalized for Phase 1 · **Date:** 2026-07-19
**Nature of this document:** a content inventory + flow spec, not a visual spec. It says what each page/state must contain and why; layout, visual style, and motion are yours to design.

---

## 0. Product context (brief)

Persian-language self-development companion. Phase 1 flow: Landing → free test → light login → initial report → recommendations → Action Preview → limited chat (not in current sprint) → paid deeper test. Audience: ages 23–43, Persian-speaking, urban, self-development-oriented.

---

## 1. Core rules governing this whole flow

1. **A report is generated once per completed test**, via one LLM call, and stored. Every subsequent viewing is read from storage — free, instant, no regeneration.
2. **Retake limit: 2 free tests per day**, for every user, whether anonymous (not logged in) or logged in. The previous report always stays viewable regardless of retake state.
3. **The full report is gated server-side.** Before login, the client only ever receives preview-safe fields — never the full report payload, even hidden in markup.
4. **Tone rule for all retake-limit messaging:** always frame the limit around *result reliability/meaningfulness*, never around cost, tokens, or business reasons.
5. **Paid tests are out of scope for this doc** — there, login + payment happen before the test starts, so none of this cost/limit logic applies.

---

## 2. Full flow overview

```
Landing
  → Start test (no login required, anonymous_id created)
  → Answer questions
  → "See results" button
  → [once] Report generated via LLM + stored (tied to anonymous_id)
  → Preview shown (server-side gated — only preview fields reach the client)
  → Login CTA
  → Login → report re-parented to account → Full report
  → (later) Recommendations, Action Preview, limited chat (dormant), paid deeper test
```

---

## 3. Stage-by-stage detail

### Stage 1 — Landing & starting the test (anonymous)
User starts the test without signing up; an `anonymous_id` is created and stored (cookie/localStorage).
**Cost:** none. **Retake-limit messaging:** none — keep this page completely clean, no mention of limits here.

*Scenarios:*
- User closes mid-test → answers should be saved client-side so they can resume.
- Cookie/localStorage cleared → progress is lost; accepted tradeoff for Phase 1.

### Stage 2 — "See results" & report generation
Clicking the button triggers exactly **one** LLM call; the full report + memory candidates are generated and stored; the preview is derived from that same report (not separately generated).
**Cost:** 1 LLM call per completed test — this is the structural cost ceiling.
**Optional messaging here:** a single first-time line during generation, framing "one full attempt per day, so results stay meaningful" — optional, not required.

*Scenarios:*
- LLM error/timeout → friendly "preparing your report…" state, one auto-retry, then a graceful retry option. Test answers must remain saved so retry doesn't require retaking the test.
- User closes mid-generation → generation continues server-side; preview is ready on return.
- Traffic spike / bot → covered by retake cap + backend monitoring (not a page-content concern).

### Stage 3 — Preview page (pre-login) — **NEW PAGE, does not exist yet**
Content pulled from the API's `stage=preview` response only.

**Must include:**
- One-line summary (`summary_one_line`)
- Dimension levels only, no interpretive text (`dimension_scores` → key + level)
- First strength title (`first_strength_title`)
- Teaser line (`teaser_line`)
- Locked-section counter (`locked_counts`, e.g. "3 recommendations waiting 🔒")
- **Login CTA framed as "unlock your full report"** — not a generic login prompt. This is the page's entire conversion purpose.
- **Retake-status note** (see shared Retake Component, Section 6)

**Must NOT include:** recommendations, Action Preview, chat entry point — none of that is unlocked yet; showing teasers for it here blurs what login actually unlocks.

### Stage 4 — Full report page — **EXISTING PAGE, needs rework per API doc**
Two states on one page (or two pages — designer's call, but should feel like *the same page unlocking*, not a separate destination):
- `stage=preview` state → same content as Stage 3.
- `stage=full` state (post-login) → full report per API spec: dimension interpretations, strengths, growth edges, recommendations.

### Stage 5 — Login & full report unlock
Existing page, minor changes: CTA and framing should read as "unlock your full report" rather than a generic login prompt, consistent with the preview page.

*Scenarios:*
- User already has an account and a new anonymous report exists → new report attaches to that account; older report(s) remain (this feeds directly into Report History, Section 7).
- Incomplete login (OTP didn't arrive, etc.) → preview stays put; user resumes anytime.
- User dislikes the report and wants a new one → that's a **retake**, not a regenerate. There is no "regenerate from the same answers" — it would cost another LLM call and undermine trust if the output differs from the same inputs.

### Stage 6 — Retake (test again)
Rule: **maximum 2 free retakes per day**, per anonymous_id or per account. Previous report(s) always remain viewable.
**Cost:** 1 LLM call per retake — the only recurring cost in this flow, and it's capped by this rule.

---

## 4. Returning-user pages — two different audiences, two different pages

### 4.A — Anonymous returning user (thin "resume" screen)
**Job:** confirm this is their saved result, route back to preview, push login.

**Must include:**
- Confirmation this is their previous result (not a blank state — otherwise they'll think nothing happened and look for a start button)
- Direct entry into the **preview** (not the full report — not earned yet)
- Retake-status note (shared component, Section 6)
- Login CTA framed as "unlock your full report"

**Must NOT include:** recommendations, Action Preview, chat — none of that belongs to an unauthenticated user.

**States:**
- Completed test + report exists → as above.
- Started test, didn't finish → resume (if progress saved) or restart.
- No test taken at all → redirect to landing/start-test.

### 4.B — Logged-in returning user (real dashboard)
**Job:** show where the user is in the Phase 1 chain (report → recommendations → Action Preview → chat → paid test) and pull them toward the next unopened step.

**Sections, in priority order:**

1. **Report status** — access to the full report, plus entry point into **Report History** (Section 7), plus the retake-status note (account-level).
2. **Recommendations** — prominent if generated and not yet acted on; if already engaged, show that state rather than re-offering as untouched.
3. **Action Preview** — state-dependent: not started (invite to pick a recommendation and turn it into a step) / in progress or saved (show the saved step, offer to continue or take to chat) / already used (only one is free — reflect as used, don't re-offer as new).
4. **Paid deeper test / upgrade** — **prominent placement**, per decision (Section 8). Not folded into another section — its own clear entry point.
5. **Chat** — **dormant this build** (see Section 9). Do not add a live entry point yet.
6. **Retake control** — same shared component, account-level.

**States:** brand-new logged-in user (report only) / mid-chain (has recommendations, no Action Preview yet) / fully engaged (candidate for paid upsell).

---

## 5. Shared retake component (used on: preview page, full report page, both dashboards)

One component, two states, reused everywhere a retake is offered:

**State A — retake available (0 or 1 used today, cap is 2):**
Neutral, informative. Show remaining count if useful (e.g., "1 more test today").

**State B — cap reached (2 used today):**
State when it resets ("available again tomorrow") + explicitly reassure the existing report is safe and viewable — the user's concern is not losing access, it's not getting a *new* result.

**Backend data needed:** `retakes_remaining_today` (0/1/2) and, when 0, the reset time.

**Final copy for State B (approved):**

> **"You've used both of today's tests — and that's exactly enough to keep your results meaningful. Your report is safe and ready whenever you want to look at it. A new test unlocks tomorrow."**

Shorter variant, for tight inline/toast spacing:

> **"Today's two tests are used. Your report's still here — a new one unlocks tomorrow."**

**Where the retake note should appear vs. not:**

| Location | Show retake note? |
|---|---|
| Landing page | No |
| Start-test screen | No |
| During the test | No |
| Report generation (first time) | Optional, one line |
| Preview page | Yes, every time |
| Full report page | Yes, every time |
| Both dashboards | Yes, every time |
| Click on retake while capped | Yes — inline/toast with State B copy above |

---

## 6. Report history — **NEW, full history (decided)**

Show the **complete list** of a user's past reports, not just the latest.

**Content requirements:**
- Full list, **newest first**.
- Each entry: generation date + a short identifier (recommend reusing that report's one-line summary as the label — already-generated content, no new copy needed).
- The current/most recent report should be visually distinguished from older ones — the user needs to know which reflects "who they are now" vs. an older snapshot.
- Each entry opens its full report.
- Lives on the logged-in dashboard (Section 4.B) and/or profile — designer's call which is the primary entry point, but at least one must exist.
- Anonymous users don't get this — at most one active report, no history concept applies.
- Design for an open-ended list (a user could retake over months) — pagination/scroll vs. capped "show more" is a layout call, but content-wise it must show *all* reports, ordered.

---

## 7. Paid test upsell — **prominent on the logged-in dashboard (decided)**

**Content requirements:**
- Frame as an upgrade to deeper understanding of *this specific user*, tied to their existing report/recommendations — not a generic "buy now" banner.
- Needs its own clear entry point (Section 4.B, item 4) — not folded into another section.
- Prominent but not dominant: should coexist with free-value sections without burying them. Suggest a distinct, well-placed card/section rather than the top-most element pushing everything else down — trust-building content still needs to be immediately reachable.
- State-dependent copy:
  - Brand-new user, hasn't engaged with anything free yet → upsell can still show, but shouldn't pitch "go deeper" before they've gone anywhere — acknowledge they're early.
  - User has engaged with recommendations/Action Preview → reference that progress directly (e.g., "you've started exploring X — the deeper test builds a full picture around it").

---

## 8. Chat — design the page fully, keep entry point dormant

Chat is not in the current sprint, but the page itself is already designed — treat it as **built-but-dormant**.

**Requirements:**
- The chat page: fully designed, as if shipping.
- Dashboard: **no live entry point** into chat yet. A visible-but-dead link would feel broken. Design the dashboard's chat section as a reserved placeholder (e.g., "coming soon," or simply omit the card for this build) so it can switch on later without redesigning the dashboard layout.
- Clearly mark, in the file/handoff, which dashboard elements are "live now" vs. "designed but not yet enabled," so nothing ships prematurely.

---

## 9. Profile button — placement

**Principle:** profile only makes sense for a **logged-in** user. An anonymous user has no profile — their equivalent slot is the login CTA.

**Placement:**
- **Logged-in:** profile icon/button in a fixed top-nav position, present on every post-login page (dashboard, full report, recommendations, Action Preview, chat page).
- **Anonymous:** the same header slot shows a **login CTA** instead of a profile icon — one fixed slot, swapping by auth state.

**Inside the profile (content, not layout):**
- Entry point to Report History (Section 6) — either here or from the dashboard; designer decides the primary entry point.
- Account status (login identifier — phone/email).
- Log out.
- Nothing more for Phase 1 — keep this a simple access point, not a settings hub.

---

## 10. Page-by-page build checklist

**Build (new):**
- Preview page (Section 3)
- Anonymous returning-user screen (Section 4.A)
- Logged-in dashboard (Section 4.B)
- Report History section/page (Section 6) — full list
- Shared retake component, 2 states (Section 5)
- Header slot with profile/login swap (Section 9)
- Chat page — designed fully but dormant entry point (Section 8)

**Modify (existing):**
- Full report page → two states (preview/full) per API doc (Section 4/Stage 4)
- Login page → CTA and framing: "unlock your full report" (Stage 5)
- Test page → save progress + optional one-line note during report generation (Stage 2)
- Side pages → add the profile/login header slot, consistent nav

**Leave alone:**
- Landing page content — clean, no retake-limit messaging here

---

## 11. Events logged from day one (context for designer, owned by Full-stack)

`test_started` (anon/logged-in split), `test_completed`, `report_generated`, `preview_viewed`, `login_after_preview`, `full_report_viewed`, `retake_started`, `retake_capped`. These exist to validate/adjust the rules above later — mentioned here only so the designer understands the flow is instrumented, not because it affects layout.

---

## 12. One-line summary

> A report is generated once per completed test and stored; re-viewing it is always free; only retaking the test is capped (2/day); the full report is gated server-side; users get a full report history; the paid test upsell is prominent on the logged-in dashboard; chat is fully designed but dormant this build; and the retake-cap messaging always centers on result reliability, never cost.
