# Handoff: Faraman — Self-Development / Self-Knowledge App (MVP)

> **Seventh refresh.** `Faraman App.dc.html` re-copied from the latest project state; the file wins over prose.
>
> **Sixth refresh.** `Faraman App.dc.html` re-copied from the latest project state (screen ids unchanged; the file wins over prose). All other files verified identical to the project.
>
> **Previous refresh (fifth).** `Faraman App.dc.html` re-copied from the latest project state (supersedes the previous copy; screen ids unchanged). Added to `explorations/`: `Initial Report v2`, `Telegram Ad - Free Test`, `Telegram Post - Decision Style` (reference only). Where prose below disagrees with `Faraman App.dc.html`, the file wins.
>
> **Previous refresh.** **Fourth refresh.** `Faraman App.dc.html` was re-copied from the current project state (it supersedes the previous copy; screen ids unchanged). New files added: **logo assets** — `assets/logo-faraman.png`, `logo-faraman-transparent.png`, `logo-faraman-theme.png`, `logo-faraman-theme.svg`, `logo-faraman-theme-embedded.svg` (use for header/footer/favicon; the app file is the source of truth for which variant sits where) — and **explorations** now included in `explorations/`: `Directions`, `Hero Illustration Options`, `Landing Bottom Options`, `Landing Redesign`, `Landing v2`, `Logo Marks` (historical options only — do not build from them). `Design System`, `Edge States`, `RetakeNote`, fonts and icons are unchanged. Prose below was not re-verified line-by-line; where it disagrees with `Faraman App.dc.html`, the file wins.
>
> **Earlier refresh note:** the landing/home page — previously its own file, `Landing v2.dc.html` — was **merged into `Faraman App.dc.html`** (see its "LANDING — WEB (v2)" section, screen id `landing`). `Faraman App.dc.html` is the single source of truth for the whole flow, landing included. `Landing v2.dc.html` is kept only as a historical exploration in `explorations/` — do not build from it; if it disagrees with `Faraman App.dc.html`, the app file wins.

## Overview
Faraman (فرامن) is a mobile-first, **Persian / right-to-left (RTL)** self-knowledge app. A user takes a short personality test, receives an AI-generated "initial personality profile" report, turns a recommendation into a concrete "step for today," can chat with an AI assistant about their report, leave feedback, and is offered a paid deeper test. This bundle covers the full free-tier flow end-to-end.

**Target platform: a responsive web application.** Design mobile-first, but every screen must scale gracefully up to tablet/desktop widths. All screens are single-column, centered, capped at a max-width, and everything reads right-to-left. See **Responsive Behavior** below for the exact rules — they are already baked into the prototype (fluid `clamp()` type, `auto-fit` grids, centered capped columns) and demonstrated in the Design System file.

---

## About the Design Files
The file in this bundle — **`Faraman App.dc.html`** — is a **design reference created in HTML**. It is a working prototype that demonstrates the intended look, copy, layout, screen flow, and interaction behavior. **It is not production code to ship as-is.**

The task is to **recreate this design as a responsive web app inside the target codebase's existing environment** (e.g. a React / Vue / Svelte web app), using that project's established components, routing, state management, and styling conventions. If no codebase exists yet, choose an appropriate modern web framework for a mobile-first, RTL, responsive app and implement the screens and behaviors documented here. It must be responsive across phone → tablet → desktop, matching the design at every width.

### Four reference files, four jobs
- **`Faraman App.dc.html`** — the interactive flow (all ~28 screens + site chrome + real logic/timings). Source of truth for *behavior*.
- **`Design System.dc.html`** — the visual foundation: color, type, spacing, components, general states. Source of truth for *styling*. **Open this first.**
- **`Edge States.dc.html`** — a gallery of edge-case screens (resume, incomplete test, load/error/offline, skipped login/payment, negative feedback). Source of truth for *what happens when things go wrong*.
- **`explorations/Landing v2.dc.html`** — superseded historical exploration only, kept for reference. Its landing design was merged directly into `Faraman App.dc.html` (screen id `landing`, marked "LANDING — WEB (v2)" in the source). Do not build from this file** — build the landing/home experience from this file, not from the Landing section of `Faraman App.dc.html`. See **§1a Landing v2** for full detail.

> The prototype was built with a small internal template runtime (`support.js`, the `<x-dc>` / `<sc-if>` / `<sc-for>` tags). **Do not port that runtime.** It exists only to make the HTML preview interactive. Read it for *behavior*, not for *architecture*.

> **`Landing v2.dc.html` bundles a web/app mode switcher pill (bottom-left, "وب" / "اپ ۳۹۰") purely so reviewers can preview both the responsive web layout and the 390px app-home composition in one file. This switcher is a prototyping affordance — do not build it into the real product; in production the app-home layout renders on native/mobile-web and the web flow renders on desktop/marketing web, chosen by platform, not a user-facing toggle.**

### How to run the prototype locally
Open `Faraman App.dc.html` in a browser (it loads `support.js` and the `assets/` font relatively). A floating **"نقشهٔ صفحات" (page map)** button appears bottom-left — it's a dev-only screen jumper so you can inspect any screen directly. **This nav is a prototyping affordance and must NOT be built into the real app.**

---

## Fidelity
**High-fidelity (hi-fi).** Colors, typography, spacing, radii, shadows, copy, and interaction timings in this document are final and should be matched closely. Where a value below is exact (hex, px, ms), treat it as the spec. The `Design System.dc.html` file is the canonical token/component reference; this README's Design Tokens section mirrors it.

---

## Global Design Rules (apply to every screen)

- **Direction:** `dir="rtl"` on the app root. All layouts mirror; back arrows point **→** (right-pointing glyph = "back" in RTL); forward/proceed chevrons point **←**.
- **Language:** All copy is Persian. Numerals shown to users are **Persian-Indic digits** (۰۱۲۳۴۵۶۷۸۹), not Latin. Phone/OTP input fields are the exception — they use `dir="ltr"` and left-aligned text so numbers enter naturally.
- **Font:** `Estedad` (variable weight 100–900), shipped in `assets/Estedad-FD-Variable.woff2`. Fallback `system-ui, sans-serif`. Use the real Estedad font in the app.
- **Page background:** `#F8F4EC` (warm off-white). Body text default `#242A38`.
- **Content width:** Most screens cap at `max-width` and center with `margin:0 auto`:
  - Test / Start / Lead / Action / Chat / Feedback / Paywall / Profile: **560px**
  - Report: **680px**, Landing hero copy block: **720px**
  - Horizontal padding: **28px** on the sides throughout.
- **Minimum touch target:** 44px (buttons and tappable rows all honor `min-height:44px`).
- **Screen enter animation:** most screens fade+rise in via `@keyframes fmIn` (`opacity 0→1`, `translateY(10px)→0`, ~0.35–0.4s ease). Reuse a single "screen enter" transition.
- **Scroll reset:** on every screen change, scroll to top.

---

## Responsive Behavior (web)

Design mobile-first; the same layout scales up cleanly. The prototype achieves responsiveness **mostly without media queries** — reproduce these mechanisms:

- **Centered capped columns.** Every screen is a single column with `margin:0 auto` and a `max-width`, sitting on the cream page. On desktop the content stays centered and comfortably readable — it does **not** stretch full-width. Caps: flow screens **560px**, Report **680px**, Landing **720px**, the Design System doc **960px**. Keep the 28px side padding on mobile.
- **Fluid type via `clamp()`.** Headlines scale with viewport, e.g. hero `clamp(30px,5vw,42px)`, report headline `clamp(21px,3vw,26px)`, meta text `clamp(14.5px,1.6vw,16.5px)`. No breakpoint needed.
- **Auto-fit grids.** Card groups use `grid-template-columns: repeat(auto-fit, minmax(<min>, 1fr))` so they reflow from 1 column on a phone to 2–3 across on wider screens automatically. Mins used: landing "how it works" `200px`, report dimensions/edges `260px`, strengths `200px`. Keep these — they are the whole responsive strategy for card sections.
- **Reference breakpoints** (from the design system, for anything the above doesn't cover): **390 / 430 / 768 / 1280**. Treat 390–430 as phones, 768 as tablet, 1280 as desktop.
- **Sticky / thumb-reachable CTAs.** On mobile the primary CTA is full-width and pinned to the bottom of the screen (`margin-top:auto` in a full-height flex column). Honor mobile safe-area insets (`env(safe-area-inset-bottom)`) so pinned CTAs clear the home indicator. On desktop the same button sits inline at its natural width within the capped column.
- **Chat screen** is full viewport height with a sticky header, a scrolling message area, and a pinned composer — this holds at every width; just center the 560px column on desktop.
- **Emotional gradient stays contained.** The dusk gradient appears only in the Landing hero, Analysis screen, and Report header. On desktop it spans the full window width but its inner content still respects the capped, centered column.

---

## Navigation Model / State Machine

There is **one top-level state: the current screen** (`screen`), one of:
`landing → startTest → test → analysis → lead → report`, with `report` branching to `action`, `chat`, `feedback`, `paywall`, and `profile`.

Primary happy path:
1. **landing** — user taps "شروع تست" (Start test) → `startTest`
2. **startTest** — intro/expectations → "شروع کنیم" → `test`
3. **test** — 8 Likert questions → after last answer → `analysis`
4. **analysis** — fake processing (auto-advances) → `lead`
5. **lead** — phone → OTP (or skip) → `report`
6. **report** — the main destination; from here the user branches out.

Back arrows and secondary links move backward along these edges (see per-screen detail). `analysis` is the only screen that advances **automatically** with no user action.

---

## Screens / Views

### 1. Landing (`landing`)
**Purpose:** Explain the product and drive "Start test."

**Layout (top → bottom):**
- **Hero block** with a full-width diagonal gradient background: `linear-gradient(165deg, #1B2150 0%, #3A3D8F 52%, #8E6BA8 82%, #C98F9B 100%)`. Two decorative soft circles overlay it (a peach radial glow bottom-left, a faint white circle top-right). Inside, capped 720px:
  - Top bar: brand wordmark **"فرامن"** (white, 800, 20px) on the right; on the left a two-button group: a pill **"ورود" (Login)** outline button (`1px solid rgba(255,255,255,.35)`, transparent, white text, radius 999px, 8×18px) → **Profile**, and next to it a solid **"ثبت‌نام" (Register)** pill (white bg, `#22307E` text, 800) → begins the flow at **Start Test**.
  - A floating white orb (64px, radial-gradient, `fmFloat` 5s bob animation).
  - `h1` "خودتان را دقیق‌تر بشناسید." — white, 800, `clamp(30px,5vw,42px)`, line-height 1.55.
  - Sub `p` — `rgba(255,255,255,.82)`, `clamp(14.5px,1.6vw,16.5px)`, line-height 2.
  - Primary CTA **"شروع تست"** — white bg, text `#22307E`, 800, 16px, radius 16px, 17px padding, shadow `0 10px 30px rgba(10,15,50,.3)` → `startTest`.
  - Three meta chips under CTA (centered, wrap): "حدود ۱۰ دقیقه" · "بدون پاسخ درست و غلط" · "محرمانه" separated by faint dots.
- **Body** (background `#F8F4EC`, capped 720px, 44px gaps between sections):
  - **"چطور کار می‌کند / در سه قدم ساده"** — 3-card responsive grid (`repeat(auto-fit,minmax(200px,1fr))`, 12px gap). Each white card: radius 20px, `1px solid #EDE7DA`, top accent bar (4px gradient — card 1 blue `#2743C6→#5A6FE0`, card 2 purple `#8E6BA8→#B08FCB`, card 3 green `#2E8A5C→#5FB587`), a 52px rounded icon tile with a line icon, a big faint step number (۱/۲/۳), a bold title, a muted body line.
  - **"چه چیزی به دست می‌آورید"** — 3 stacked white list rows (radius 18px), each a 44px colored icon tile + a question-style label.
  - **AI teaser card** — dark gradient card (`linear-gradient(150deg,#1B2150,#3A3D8F 55%,#8E6BA8)`), radius 24px, with a chat-bubble icon, heading "دربارهٔ گزارش‌تان سؤال بپرسید", body, and a mock 2-message chat exchange (user bubble white on right, AI bubble translucent on left).
  - **"این تست برای شما مناسب است اگر…"** white card with 3 trust chips (lock/heart/badge line icons) and a secondary **"شروع تست"** CTA (solid blue `#2743C6`) → `startTest`.
  - **Footer**: two fine-print privacy/disclaimer lines (muted `#A9A597` / `#C4C0B2`).

**Interactions:** "ورود" → Profile; "ثبت‌نام" → Start Test. Both "شروع تست" buttons → Start Test.

---

### 1a. Landing v2 — the current landing + app-mode home (now inside `Faraman App.dc.html`, screen id `landing`)
**This replaces §1 above as the source of truth for the landing/home experience.** It now lives directly in `Faraman App.dc.html` (no longer a separate file) — the description below is still accurate to the current markup. Where any earlier note disagrees with this section, this section wins.

#### What changed in this revision (vs. the previous bundle)
- **The hero is photographic, not a gradient.** A full-bleed dawn photograph (`assets/hero-bg-clouds.jpg` — a calm figure walking a lit path at dawn) replaced the dusk-gradient hero and the floating phone mock. The page now reads **light and warm**, with the dusk gradient reserved for small report mocks.
- **New accent palette.** The landing's action color is **plum `#6B4FA8`** with ink `#4A2F63` and `#5A3F76`, warm amber `#B4703A` / `#8A5A26`, and hairline rules in `#D9C6B2` — not the app's blue `#2743C6`. (The in-app flow keeps blue; this is a landing-only accent shift. Reconcile with the design system before reusing these elsewhere.)
- **App-download links** under the hero CTAs: "دانلود مستقیم اپلیکیشن" (download icon) and "دانلود از کافه‌بازار" (`assets/cafebazaar-icon.png`). Both are placeholders — wire to real URLs.
- **Removed:** the Science section, the Privacy 3-card section, the Farablog banner content, the four hero meta chips, and **both character `<image-slot>` panels** (`lp2-report`, `lp2-deep`). The `showPrivacySection` / `showCharSlots` props remain declared but no longer drive anything — **drop them**; only `showBlogStrip` still wraps a (now empty) section.
- **New sections:** "پس از گزارش" (chat + step-by-step) replaces the old Assistant+Step row, and the trust/science content is now a card **inside** the Deep Test section.
- The hero `h1`, eyebrow, and companion voice («تو») are unchanged from the previous revision. **Copy is the spec** — keep the companion framing; do not re-introduce a test-mechanics headline.

**Purpose:** two destinations from the same tokens — the **public web landing** and the **app-mode home** (390px). Which renders is a **platform decision, not a user toggle**; the "وب / اپ ۳۹۰" pill bottom-left is a reviewer affordance only — **do not ship it**.

**Shared chrome:** the sticky desktop/mobile site header and desktop footer from `Faraman App.dc.html` §A, unchanged (overlay-on-hero → solid-on-scroll). The header's login button now uses the plum `--hdBtnBg` (`#6B4FA8`).

#### Web landing, top → bottom (sections capped 1120px, 28px side padding, fluid `clamp()` + `cqw`)

1. **Hero — two separate compositions, one per breakpoint.**
   - **Desktop/tablet** (`.fm-hero-desktop`): `height:100vh; min-height:640px`, the photo full-bleed behind, and a left-to-right white scrim (`linear-gradient(to left, rgba(255,255,255,.6) … )`) so the RTL text column stays legible over the image. Content: hairline-rule eyebrow **«حکیم درون تو»** (22×1px `rgba(74,47,99,.4)` rule), `h1` **«فرامن، همان صدای آرامی که راه را می‌داند.»**, explainer paragraph, then a two-button row — primary **«شروع آزمون خودشناسی»** (plum, hover lift `-3px`) and outline **«نمونه‌ای از روایت فرامن»** anchoring to `#nemoone` — then the two download links.
   - **Mobile** (`.fm-hero-mobile`): a stacked variant — image **band** on top, text block on cream `#F8F4EC` below, plus the caption «۳۰ پرسش کوتاه برای شروع · حدود ۱۰ دقیقه». Both variants are in the markup and swapped by CSS custom properties (`--fmDesk`/`--fmMob`); in production use one responsive hero with the image cropping differently, not two DOM copies.
   - The image carries a real Persian `alt`, `fetchpriority="high"`, and intrinsic `width/height` (1376×768) — keep all three (LCP + a11y).
2. **Report Sample** (`#nemoone`) — eyebrow «نمونه‌ای از روایت فرامن» + `h2` «همراهی که تو را به اوج می‌رساند». Left: a white narrative card with a **2×2 stat grid** (۵ ابعاد / ۳ توانایی / ۴ موقعیت / ۳ قدم, each a Persian numeral + a narrative sentence, amber/plum/violet/green), the pull-quote «تو توان رفتن را داری، آنچه دشوار است، نخستین قدم است.», one prose paragraph, and the link «ادامه‌ی روایت خودت را بخوان ←». Right: a **report mock card** labelled «نمونهٔ واقعی گزارش» — dusk-gradient header with the insight line, two animated dimension meters (ذهن رشدگرا ۸۴٪ / انرژی اجتماعی ۵۸٪) and a navy «قدم امروز» card. This mock is the **only** place the dusk gradient appears on the landing.
3. **پس از گزارش — chat (primary) + steps (secondary).** `h2` «گزارشت، آغاز گفتگوی تو برای فراتر رفتن از امروزت است». Two cards side by side, wrapping on narrow widths:
   - **Left — chat (interactive, the one live demo on the page).** A lavender card with four `role="tab"` chips: درباره‌ی گزارشم / این قدم به من نمی‌خوره / انجامش دادم، بعدش چی؟ / نشد. بیا حرف بزنیم. Picking one swaps the two-bubble exchange below (user + Faraman reply) and re-fires a `fmFade .34s` transition; chip 3 ("انجامش دادم") additionally reveals a **step card** with «قبول دارم» / «یک پیشنهاد دیگر بده». Default selection is chip index **2**. Keyboard-operable (Enter/Space, `aria-selected`). Reproduce it as a real tablist.
   - **Right — قدم‌به‌قدم.** A warm card with a 5-node **vertical timeline** (amber connector line): قدم امروز → یادآوری پیش از مهلت → «انجامش دادی؟» with the three real check-in pills (انجام دادم / نیمه‌کاره / نشد) → چطور بود؟ → «قدم بعدی، در گفتگو →», closing with the reassurance «"نشد" هم یک پاسخ است…». It visualises the Phase-3 §H step lifecycle — keep the two in sync.
4. **Deep Test + trust (one section).** A dark plum promo card: badge «پروفایل توسعهٔ فردی», headline **«آنچه از خودت پنهان مانده»**, explainer, four meta chips (۳۰ ویژگی شخصیتی / نقاط کور / سبک تصمیم، رابطه و کار / گفتگوی عمیق‌تر) and CTA **«شروع تست تکمیلی»**. Directly beneath it, the **trust card** (formerly the standalone Science section): eyebrow «چرا می‌توانی به آن تکیه کنی», headline «اینجا کسی تو را قضاوت نمی‌کند.», the five-factor explainer, the non-diagnostic disclaimer strip, and all **5 dimension meters** as a sample scorecard (۸۴ / ۸۸ / ۶۶ / ۵۸ / ۷۲).
5. **Farablog strip** — wrapped in `showBlogStrip` but **currently empty**; the banner was removed. Either rebuild it from the app's Farablog coming-soon page or drop the flag.
6. **Final CTA** — centered plum/gradient block: «از «من» تا «فرامن»، یک قدم فاصله است.» + «شناختن خودت، نخستین قدم است…» + CTA «شروع تست خودشناسی», with a lock-icon privacy reassurance line underneath.
7. **Site footer** — shared chrome; now a 4-column grid whose last cell holds an app-download QR block. Contact address is `hello@faraman.ai`.

#### App-mode home (390px)
A mobile-native **mirror of the web flow**, not a separate information architecture: App Hero (same photo + scrim, stacked) → App Report Sample (2×2 stat grid + narrative + report mock) → App After Report (chat card with horizontally-scrolling chips + the same step timeline) → App Deep Test → App Trust (5 meters) → App Final CTA. Keep the web and app surfaces telling the *same* story with the *same* sample-report content.

#### Motion
- **Scroll-reveal:** every block/card carries `data-reveal` (+ optional `data-delay` ms). An `IntersectionObserver` (threshold 0.15, `rootMargin 0 0 -8% 0`) fades+rises each target once (`opacity 0→1`, `translateY(22px)→0`, `.7s cubic-bezier(.2,.8,.2,1)`), never re-hiding. Meters (`data-fill="{pct}"`) animate their width from 0 on the same observer.
- **Header solid-on-scroll:** a passive `scroll` listener flips a set of CSS custom properties on `documentElement` past `scrollY > 8` (bg, blur, border, shadow, text and button colors).
- Hero blocks enter with staggered `fmRise` (.6–.8s); chat-demo swaps use `fmFade .34s`.

#### Props
- `showBlogStrip` (bool, default true) — wraps the now-empty Farablog section.
- `showPrivacySection`, `showCharSlots` (bool) — **dead props**, no longer wired to anything. Do not implement.

#### Assets used
`assets/hero-bg-clouds.jpg` (hero photograph, 1376×768), `assets/cafebazaar-icon.png`, `assets/Estedad-FD-Variable.woff2`. The hero photo is a **stand-in for licensed/commissioned artwork** — confirm rights or replace before launch; keep the alt text and the scrim if you swap it. `assets/hero-bg-path.jpg`, `assets/hero-companion.jpg` and `assets/hero-lantern-{a,b,c}.svg` are the alternates explored in `explorations/Hero Illustration Options.dc.html` — not used by the shipped landing.

#### Implementation notes
- [ ] Treat this file as the landing/home spec of record; retire §1 of `Faraman App.dc.html`.
- [ ] One responsive hero, not two DOM copies; keep `alt`, `fetchpriority`, intrinsic size, and the white scrim (contrast over a photo is the whole reason the scrim exists).
- [ ] Build the chat-moment demo as a real tablist (4 chips → 4 scripted exchanges, chip 3 reveals the step card), keyboard-accessible.
- [ ] Wire both app-download links; hide them on platforms where they don't apply.
- [ ] Drop the وب/اپ switcher, the dead props, and the empty Farablog section.
- [ ] Landing uses the plum accent, the in-app flow uses blue — pick one canonical mapping before implementation and update the design system accordingly.

---

### 2. Start Test (`startTest`)
**Purpose:** Set expectations before the questions.

**Layout:** 560px column, full min-height, `fmIn`.
- Header row: 40×40 back button (glyph "→", white bg, `1px solid #EDE7DA`, radius 12px) + label "تست خودشناسی".
- `h1` "چند سؤال کوتاه دربارهٔ خودتان" (28px, 800) + explainer paragraph.
- A 3-item list (each row: 36px rounded blue tile `#E9EBF8` with icon/number + label), separated by `1px solid #EDE7DA` bottom borders: "۸ سؤال کوتاه — حدود ۱۰ دقیقه", "می‌توانید هر وقت خواستید ادامه دهید", "پاسخ‌ها فقط برای ساخت گزارش شما استفاده می‌شود".
- Pinned to bottom (`margin-top:auto`): primary CTA **"شروع کنیم"** (solid blue) → `test`; below it "آماده نیستید؟ بعداً برمی‌گردم" where the link portion → `landing`.

**Interactions:** back arrow → `landing`; "شروع کنیم" → `test`; "بعداً برمی‌گردم" → `landing`.

---

### 3. Test — Questions (`test`)
**Purpose:** Collect 8 Likert (1–5) answers.

**The 8 questions (exact copy, in order):**
1. وقتی تصمیم مهمی پیش می‌آید، معمولاً قبل از اقدام همهٔ جوانب را بررسی می‌کنم.
2. در جمع‌های جدید، معمولاً من شروع‌کنندهٔ گفتگو هستم.
3. وقتی کاری را شروع می‌کنم، معمولاً تا پایان پای آن می‌مانم.
4. اشتباه‌هایم را فرصتی برای یادگیری می‌دانم.
5. وقتی برنامه‌هایم به هم می‌ریزد، به‌سختی آرامشم را حفظ می‌کنم.
6. برایم مهم است که دیگران در کنار من احساس راحتی کنند.
7. قبل از شروعِ یک کار، معمولاً منتظر شرایط ایده‌آل می‌مانم.
8. یادگیری چیزهای جدید به من انرژی می‌دهد.

**Layout:** 560px column.
- Header: back button (→) + centered "سؤال {n} از {total}" (Persian digits) + a "ذخیره و خروج" (save & exit) link on the left (blue `#2743C6`).
- **Progress bar** below header: 5px track `#EDE7DA`, fill `linear-gradient(90deg,#2743C6,#8E6BA8)`, width = `round((q / total) * 100)%` (i.e. progress reflects questions *completed*, min 2% on Q1), animated `width .4s ease`.
- Question `h2` (23px, 800, line-height 1.75, `min-height:120px` so layout doesn't jump between questions). The question block has `key = qNum` so it **re-fires the `fmIn` enter animation on each question change**.
- **Likert scale:** a row of **5 equal buttons** labeled ۱–۵ (`flex:1`, height 58px, radius 16px). Unselected: white bg, `1.5px solid #EDE7DA`, text `#5D5C55`. Selected: bg `#2743C6`, white text, blue border. Hover: `translateY(-2px)`.
- Under the scale, two anchor labels: right "کاملاً مخالفم" (strongly disagree), left "کاملاً موافقم" (strongly agree).
- **Encouragement line:** on Q5 only (`q === 4`), show a centered purple note "بیش از نیمی از راه را آمده‌اید — عالی پیش می‌روید."
- Bottom row: "قبلی" (previous, outline) + "بعدی" (next) button. Next is **disabled** (grey `#C9CDDE`) until the current question is answered; enabled = blue. On the **last** question the next button label becomes **"پایان تست"** (finish).

**Interactions & rules:**
- Selecting a scale value stores the answer for the current question index.
- **Auto-advance:** ~420ms after picking an answer, auto-advance to the next question; if it was the last question, auto-advance to `analysis`. (Manual "بعدی" also works immediately.)
- "قبلی" / back arrow: if `q > 0` go to previous question; if on Q1, go back to `startTest`.
- "بعدی": if answered and not last → next question; if last → `analysis`.
- "ذخیره و خروج" → `landing` (in production this would persist progress).
- Answers persist when navigating back/forward within the test (re-selecting shows the stored value highlighted).

---

### 4. Analysis / Loading (`analysis`)
**Purpose:** Simulated processing screen between test and report. **Auto-advances — no user action.**

**Layout:** full-screen dark gradient (`linear-gradient(165deg,#1B2150,#3A3D8F 55%,#8E6BA8)`), centered column:
- A 96px glowing orb, `fmPulse` animation (scale + opacity pulse, 2.2s loop).
- A rotating status message (white, 18px, 800) that re-animates (`fmIn`, keyed on index) each time it changes, plus a static sub-line "چند لحظه طول می‌کشد".
- Three bouncing dots (`fmDot`, staggered 0 / .2s / .4s).

**Rotating messages (exact, in order):**
1. داریم الگوی پاسخ‌هایتان را بررسی می‌کنیم…
2. داریم مسیرهای رشد مناسب شما را پیدا می‌کنیم…
3. گزارش اولیه‌تان تقریباً آماده است…

**Behavior:** step through the 3 messages on a **1700ms interval**; after the last message elapses, navigate to `lead`. Clear the interval on leaving the screen. (In production, replace the fake timer with the real report-generation request; show these messages while awaiting it.)

---

### 5. Lead Capture — Phone → OTP (`lead`)
**Purpose:** Authenticate by phone, then verify OTP. No separate consent screen or persisted consent — accepting terms/privacy is implied by proceeding, communicated as a single inline sentence (see below).

**Shared header:** a 40px tile with "✓" + green label "گزارش شما آماده است" (your report is ready).

**Sub-step A — Phone (`leadStep === 'phone'`):**
- `h1` "گزارش‌تان را کجا ذخیره کنیم؟" + explainer.
- Labeled input "شمارهٔ موبایل": `1.5px solid #EDE7DA`, radius 16px, 16–18px padding, 17px text, `dir="ltr"`, left-aligned, placeholder "۰۹۱۲ ··· ····", `inputMode="tel"`. Focus border → `#2743C6`.
- Helper line "کد تأیید برایتان پیامک می‌شود."
- Pinned bottom: **"دریافت کد تأیید"** (get code) — disabled/grey until the number has ≥5 chars, then blue → OTP sub-step.
- **Consent sentence (pattern reference: Digikala's login screen)** — directly under the CTA, one small centered line, muted grey with two inline colored links (no checkbox, nothing saved/tracked, not a gate on the button): "ورود یا ثبت‌نام شما به معنای پذیرش **شرایط استفاده فرامن** و **قوانین حریم‌خصوصی** است". The two bracketed phrases are **real links to an in-app Terms/Privacy page** (see §6 below), blue `#2743C6`, 700 weight, no underline; the rest is `#A9A597`. Tapping a link navigates there and remembers which screen to return to.
- Below that: "فعلاً بدون ذخیره ادامه می‌دهم ←" (skip) → `report`.

**Sub-step B — OTP (`leadStep === 'otp'`):**
- `h1` "کد تأیید را وارد کنید" + "کد ۶ رقمی به شمارهٔ {phone} پیامک شد." (phone shown `dir="ltr"`, bold).
- **6-digit OTP as six separate boxes** in a row (`direction:ltr`, 8px gap, each `flex:1` box 60px tall, radius 14px, 26px/800 centered digit). A box shows `1.5px solid #2743C6` when it is filled OR is the current active slot; otherwise `#EDE7DA`. Implementation in the prototype: the six boxes are display-only; a single transparent full-cover `<input inputMode="numeric" maxLength=6 dir="ltr" autoFocus>` overlays them and holds the value. **Sanitized to digits only (Persian & Latin) and clamped to 6 chars.** (Six real inputs with focus-advance/backspace + paste support is equally acceptable.)
- Row: "تغییر شماره" (change number → back to phone step) and "ارسال دوبارهٔ کد" (resend). After tapping resend, its label becomes "کد دوباره ارسال شد ✓".
- Pinned bottom: **"تأیید و ادامه"** — disabled/grey until all 6 digits entered, then blue → `report`.

**Note for production:** wire the real SMS/OTP service (prototype accepts any 6 digits). No acceptance state needs to be stored anywhere — use of the product after this screen simply constitutes agreement, same as the reference pattern. Keep the "skip / continue without saving" escape hatch.

### 6. Terms of Use & Privacy Policy (`terms`)
**Purpose:** the actual page the two consent links open — a real, in-app reference for the terms/privacy content (not a dead link, not a modal-only summary).

**Layout:** 560px column.
- Header: back button (→) + "قوانین و حریم خصوصی". **Back returns to whichever screen opened it** (in the MVP flow, the phone step of Lead Capture) — track the originating screen and return there, don't hardcode a single previous screen.
- A two-tab segmented control: **"شرایط استفاده"** and **"حریم خصوصی"**. Tapping the sentence's first link opens the page on the Terms tab; the second link opens it on the Privacy tab.
- Each tab: a small "آخرین به‌روزرسانی: {version}" line, then stacked sections (bold heading + body paragraph, 13.5px/2.1 line-height) — 4 sections per tab in the prototype (account/service scope, data collected & why, no third-party sharing, changes/deletion rights).
- A lavender note at the bottom (`#F3F1FA` bg, `#E4E0F2` border, `#4A4390` text) flagging that **this copy is a draft placeholder** and must be replaced with reviewed legal text before shipping.

**Content status — important:** the prototype ships **draft/placeholder copy only**, written to demonstrate structure and tone — Faraman doesn't have real Terms of Use / Privacy Policy text yet. **Do not treat this copy as final or launch with it as-is.** Swap in the actual reviewed legal text (and real version number) before this ships; keep the page's structure (two tabs, sectioned, versioned) since that part of the design is intentional.

---

### 7. Report (`report`) — main destination
**Purpose:** Present the initial personality profile. This is the richest screen and the hub the user returns to.

**Header (dark gradient, capped 680px):**
- Top bar: "فرامن" wordmark + **"پروفایل"** pill → Profile.
- Eyebrow "پروفایل اولیهٔ شخصیت شما", a large white headline summary ("شما تحلیل‌گری دقیق هستید که پیش از اقدام، دنبال اطمینان می‌گردد."), and a fine disclaimer that this is an initial picture, not a diagnosis.

**Body (capped 680px, 48px section gaps):**

1. **Low-confidence banner (conditional)** — when the `lowConfidence` flag is on, show a warm banner (`#FBF3E4` bg, `#EFD9AE` border, `#8A6B2E` text) explaining the report was built with medium confidence because some answers lacked a clear pattern. (This is a real report state to support — likely driven by the analysis output, e.g. inconsistent/incomplete answers.)

2. **"تصویر کلی شخصیت" — 5 dimension cards** (`repeat(auto-fit,minmax(260px,1fr))` grid). Each white card: name (bold) + a level pill + a 6px progress meter (fill `linear-gradient(90deg,#2743C6,#8E6BA8)`, width = pct) + a note line. The five dimensions (name / level / pct / note / pill color):
   - ذهن رشدگرا — بالا — 85% — pill blue (`#2743C6` on `#E9EBF8`)
   - مسئولیت‌پذیری — نسبتاً بالا — 72% — pill blue
   - همدلی و همکاری — متوسط — 58% — pill amber (`#8A6B2E` on `#FBF3E4`)
   - انرژی اجتماعی — متوسط — 52% — pill amber
   - ثبات هیجانی — متوسط — 55% — pill amber

3. **"الگوی اصلی شخصیت شما"** — a white card with two prose paragraphs (14.5px, line-height 2.15).

4. **"نقاط قوت کلیدی" — 3 strength cards** (`minmax(200px,1fr)` grid). Each: a 34px colored rounded tile (blue/purple/amber bg) + title + description.

5. **"چیزهایی که بهتر است مراقب‌شان باشید"** (growth edges, framed positively — subtitle "نه نقطه‌ضعف — جاهایی که رشد از آن‌جا شروع می‌شود") — 2 lavender cards (`#F3F1FA` bg, `#E4E0F2` border, title `#4A4390`).

6. **"شخصیت شما در موقعیت‌های واقعی" — 4 accordions.** Each white card row: title + one-line summary + a chevron "⌄" that rotates 180° when open (`transform .2s`). **Accordion behavior:** tapping a row toggles it open; **only one open at a time** — opening one closes the others; tapping the open one closes it (so zero can be open). Open content reveals two labeled blocks: "بهترین شرایط برای شما" (green label) and "حواس‌تان باشد" (amber label), with `fmIn` reveal. **Default: the first accordion is open on entry.** The four situations: سبک تصمیم‌گیری / سبک ارتباطی / سبک کار و یادگیری / استرس و انرژی (full copy in the HTML).

7. **"مسیر رشد شما" — growth CTA card** (solid `#22307E` navy, radius 22px): eyebrow "تمرکز اصلی", title "تبدیل تحلیل به اقدام", a body line, then 3 recommendation chips (translucent white). Two buttons: **"یکی از توصیه‌ها را قدم امروز کنید"** (white) → `action`; **"دربارهٔ گزارشم سؤال دارم"** (outline) → `chat`.

8. **Upsell card** (white) — "می‌خواهید عمیق‌تر بروید؟" + link "آشنایی با گزارش کامل ←" → `paywall`.

9. **Feedback prompt** (top-bordered) — "چقدر این گزارش شما را درست شناخته؟" + link "نظرم را می‌گویم ←" → `feedback`.

**Interactions summary:** "پروفایل" → Profile; accordions toggle (single-open); "قدم امروز" → Action; "سؤال دارم" → Chat; "گزارش کامل" → Paywall; "نظرم را می‌گویم" → Feedback.

---

### 8. Action — "Step for today" (`action`)
**Purpose:** Turn a recommendation into one concrete micro-action. Two states: config → result.

**On entry, state resets** (no time/size selected, not built, not saved).

**Header:** back button (→ `report`) + "قدم امروز". Then a blue callout card (`#E9EBF8`) showing the selected recommendation: "تصمیم‌های کم‌ریسک را بدون تحلیل طولانی بگیرید".

**State A — Config (`!actionBuilt`):**
- "چه زمانی از روز برایتان بهتر است؟" — pill single-select: صبح / ظهر / عصر.
- "چقدر وقت می‌گذارید؟" — pill single-select: ۵ دقیقه / ۱۵ دقیقه / ۳۰ دقیقه.
- Pill style: unselected white / `1.5px solid #EDE7DA` / `#5D5C55`; selected blue bg + white; radius 999px; `min-height:44px`.
- Bottom CTA **"ساخت قدم امروز"** — disabled/grey until **both** a time and a size are selected, then blue → builds the action (State B).

**State B — Result (`actionBuilt`, `fmIn`):**
- White card: eyebrow "قدم امروز شما" + the generated action sentence (composed from the chosen time): _"امروز {time}، فقط یک تصمیم کم‌ریسک را انتخاب کنید و قدم بعدیِ آن را در یک جمله بنویسید. همین."_ + two tags: "آسان" (green) and the chosen duration (blue).
- Buttons: **"ذخیرهٔ قدم امروز"** (save) — after tapping, label becomes "ذخیره شد ✓". And **"عملی‌ترش کنیم؟ از هوش مصنوعی بپرسید"** (outline) → `chat`.

**Interactions:** both selects required to enable build; save toggles the saved label; back arrow → `report`.

---

### 9. Chat — AI assistant (`chat`)
**Purpose:** Ask the AI about the report. Scripted in the prototype; **wire to the real LLM in production.**

**Layout:** 560px, **full viewport height** with a sticky header, a scrolling message list (`flex:1; overflow-y:auto`), and a pinned composer.
- **Header (sticky):** back button (→ `report`) + title "گفتگو دربارهٔ گزارش شما" + subtitle "متصل به پروفایل اولیهٔ شخصیت".
- **Messages:** user bubbles right-aligned, blue `#2743C6`, white text, radius `18px 18px 6px 18px`. AI bubbles left-aligned, white, `1px solid #EDE7DA`, radius `18px 18px 18px 6px`. Each new bubble animates in (`fmIn`). Under the **latest AI** message (except the first seeded one) show a "مفید بود 👍 / 👎" feedback row.
- **Seed message (AI, on load):** "سلام! من این‌جا هستم تا دربارهٔ گزارش‌تان صحبت کنیم. هر بخشی که مبهم بود یا خواستید عملی‌ترش کنید، بپرسید."
- **Typing indicator:** while awaiting a reply, show a 3-dot (`fmDot`) bubble left-aligned.
- **Composer (pinned bottom):** a horizontally-scrollable row of **suggested-prompt chips** (the 4 scripted questions), then an input (radius 999px, focus border `#2743C6`) + a 48px round blue send button "↑".

**Send behavior:** on send (button or Enter key): append the user message, clear input, show typing indicator, and after ~**1300ms** append the AI reply. Ignore empty sends and sends while already typing. In the prototype, replies come from a fixed script keyed by the 4 suggested prompts, with a sensible generic fallback for anything else — **replace this with a real streaming LLM call grounded in the user's report.** (Full scripted Q&A text is in the HTML `chatScript`.)

---

### 10. Feedback (`feedback`)
**Purpose:** Rate how accurate the report felt. Two states: form → thank-you.

**Header:** back (→ `report`) + "بازخورد".

**State A — Form (`!fbSubmitted`):**
- `h1` "چقدر حس کردید این گزارش شما را درست شناخته؟"
- **Rating:** 5 equal buttons ۱–۵ (same selected/unselected style as the Likert scale; height 56px). Single-select.
- "کدام توصیف نزدیک‌تر است؟" — **multi-select** pill tags (toggle on/off, can pick several): دقیق بود / کمی کلی بود / بعضی بخش‌ها اشتباه بود / لحنش خوب بود / توصیه‌ها کاربردی بود.
- Optional free-text `textarea` (3 rows, no resize) with placeholder example.
- Bottom CTA **"ارسال بازخورد"** — disabled/grey until a rating (1–5) is chosen; then blue → thank-you state.

**State B — Thank-you (`fbSubmitted`, `fmIn`):** centered — a 72px green ✓ circle, "ممنون از شما", a line, and a "بازگشت به گزارش" outline button → `report`.

**Interactions:** rating is required; tags multi-toggle; back arrow → `report`.

---

### 11. Paywall — Full report (`paywall`)
**Purpose:** Offer the paid deeper test. Reassures the free report stays available.

**Header:** back (→ `report`) + "گزارش کامل".
- A 52px gradient tile + `h1` "شناخت عمیق‌تر، با تست تکمیلی" + reassurance line that the free report stays.
- **Benefits list** (4 rows, each a 22px ✓ circle + bold title + muted desc, `1px` bottom borders): تست تکمیلی ۶۰ سؤالی / گزارش کامل و چندلایه / گفتگوی نامحدود با هوش مصنوعی / به‌روزرسانی گزارش با گذر زمان (full desc copy in HTML).
- **Price card** (white): "دسترسی کامل" + an amber **discount badge** (bg `#F5E3C4`, text `#8A5A18`, radius 9px, default "٪۵۰ تخفیف") under the label, and a price row showing the **old price struck through** (14.5px/700, `#9A9890`, `text-decoration:line-through`, default "۳۹۹٬۰۰۰ تومان") next to the **current price** (24px/900, `#242A38`, default "۱۹۹٬۰۰۰ تومان"). All three strings are configurable props (`paywallPrice`, `paywallOldPrice`, `paywallDiscountBadge`) — **drive them from the real pricing/promotion data; when no promotion is active, hide the badge and the struck-through price and show the price alone.** Persian-Indic digits throughout. Primary CTA **"ادامه و پرداخت"** (blue) — in the prototype it just returns to `report`; **wire to the real payment flow.** Secondary "شاید بعداً — بازگشت به گزارش رایگان" → `report`.
- Footer reassurance line.

---

### 12. Profile (`profile`)
**Purpose:** Account hub (mostly static in the MVP).

**Header:** back (→ `report`) + "پروفایل".
- Avatar (60px gradient circle with initial "ن") + name "نیما" + masked phone "۰۹۱۲ ··· ۴۵۶۷" (`dir="ltr"`).
- A list of rows (white, radius 16px, chevron "‹"):
  - "گزارش ذخیره‌شدهٔ من" (my saved report) → `report`
  - "وضعیت اشتراک" (subscription) with a "رایگان" (free) amber badge → `paywall`
  - "خروج از حساب" (log out) — static in prototype
  - "حذف حساب و داده‌ها" (delete account & data) — red text `#B4533A`, static in prototype

---

## Edge Cases & Error States

Two sources define these — build them, not just the happy path:

### A. General reusable states (from `Design System.dc.html` §9 "حالت‌های عمومی")
- **Skeleton loaders** — shimmer placeholders (`fmShimmer`, 1.6s linear loop; gradient `#EDE7DA → #F6F1E6 → #EDE7DA`, `background-size:300% 100%`). **Use skeletons, not spinners**, whenever content is loading (esp. the report).
- **Toast** — dark pill (`#242A38`, white text, radius 14px, shadow `0 8px 24px rgba(0,0,0,.18)`), small colored status dot, bottom-anchored, auto-hides after ~3s. E.g. "قدم امروز ذخیره شد".
- **Inline error card** — soft-brick palette: bg `#F9EAE5`, border `#EDCABC`, text `#8F412C`, with a `#B4533A` retry button. **Never use a harsh red.**
- **Offline card** — neutral, reassuring: saved report remains viewable without connection (PWA).

### B. Flow-specific edge screens (from `Edge States.dc.html`, ids e1–e8, all 390px mobile frames)
- **e1 — Resume half-finished test.** On return, a card shows "تست شما نیمه‌کاره مانده" with the saved progress bar (e.g. ۳/۸, 38%) and "ادامهٔ تست از سؤال ۴" + "شروع دوباره از اول". → **Persist test progress and offer resume.**
- **e2 — Report viewed without login.** Amber "not saved yet" banner at the top of the report warning that closing loses access, with a "ذخیرهٔ گزارش با شماره" CTA (report content skeletons below). → **Gate persistence behind the phone capture, but let users read first.**
- **e3 — Incomplete test → no report.** Centered state "هنوز چند سؤال مانده" (e.g. ۳/۸) explaining all questions are needed for an accurate report; answers preserved; "ادامهٔ تست" / "بعداً ادامه می‌دهم". → **Don't generate a report from a partial test.**
- **e4 — Report loading (skeleton).** The report header + card skeletons with "داریم گزارش‌تان را آماده می‌کنیم…". This is the real loading treatment behind the Analysis screen's transition.
- **e5 — Report generation failed.** Centered soft-brick "!" state "در ساخت گزارش مشکلی پیش آمد" reassuring that answers are safe and no re-test is needed; "تلاش دوباره" + "بازگشت به صفحهٔ اصلی". → **Never lose the user's answers on failure; always offer retry.**
- **e6 — Negative-feedback follow-up.** When the feedback rating is low, a soft follow-up appears: "ممنون که صادق بودید. کدام بخش دقیق نبود؟" with the report-section tags and an offer to answer a few more questions to improve accuracy ("بله، ادامه می‌دهم" / "نه، ممنون"). → **Low ratings trigger this recovery flow, not a dead end.**
- **e7 — Payment cancelled.** Gentle "مشکلی نیست" screen confirming the free report stays available; "بازگشت به گزارش من" + "یادآوری برای بعد". → **Abandoning the paywall must never trap the user.**
- **e8 — Offline with saved report.** A dark offline status bar ("اتصال اینترنت برقرار نیست" + retry) above the saved report (still viewable), with an amber note that AI chat and the extended test require a connection. → **Cache the saved report for offline; gracefully disable online-only features.**
- **e9 — Instant navigation, skeleton-first.** Two-frame comparison: at 0ms the tapped nav tab is already active and the incoming screen shows skeleton placeholders; at ~600ms real content replaces the skeleton. → **Navigation must be optimistic: switch route/active-tab state synchronously on tap, before any fetch starts. Never hold the transition on a pending request — render the destination's skeleton immediately, swap in real content when data resolves. Pair with an immediate `:active`/pointerdown press state on buttons so taps register instantly regardless of network speed. Debounce to prevent duplicate navigations, but never disable the tap-feedback itself. On timeout, fall back to the e5/e8 error/offline treatments instead of leaving the user stuck.**

**Guiding principle across all edge states (from the design-system dev notes):** reassure, preserve the user's data, and always provide a forward path — never a dead end, never harsh error styling.

**Buttons (variants — see `Design System.dc.html` §4):**
- **Primary:** bg `#2743C6`, white, 800, radius 16px, 16px padding, shadow `0 6px 18px rgba(39,67,198,.22)`, `min-height:44px`.
- **Secondary:** bg `#E9EBF8`, text `#22307E`, 800.
- **Outline:** white bg, `1.5px solid #EDE7DA`, text `#242A38`, 700.
- **Ghost/text:** transparent, blue `#2743C6` text, with trailing "←".
- **Disabled:** bg `#C9CDDE`, white.
- **Loading:** primary with 3 `fmDot` dots instead of a spinner.
- **Small:** 13px, radius 12px, `min-height:40px`.
- On dark gradient surfaces the primary button inverts to **white bg + `#22307E` text**.

**Inputs (states — see `Design System.dc.html` §5):** default `1.5px solid #EDE7DA`, bg `#F8F4EC` or `#fff`, radius 16px; focus border `#2743C6` + halo `0 0 0 3px rgba(39,67,198,.1)`; error border `#D98A73` on bg `#F9EAE5` with `#B4533A` helper text; success border `#6FBF97` on bg `#E4F2EA` with green helper. Phone/OTP fields are `dir="ltr"`, left/centered.

**"Never" rules (hard constraints from the design system):** no harsh/pure red (use soft brick `#B4533A`); no clinical blue for large surfaces (blue is for action/emphasis only); **no raw numeric scores in the report** (use soft levels like بالا/متوسط + a meter); no body text under 12px (11px only for disclaimers); the dusk gradient only in the 3 emotional moments (hero, analysis, report header).

---

## Phase 2 — Conversion path, auth states & logged-in experience

This section covers the pages added per the Free-Test-Flow brief (`uploads/design_brief_free_test_flow_EN.md`). They extend the existing system — same fonts, tokens, gradient, card style. Screen ids: `preview`, `resume`, `dashboard`, `history`, plus the shared `RetakeNote` child component.

### Core rules that shape these pages (from the brief)
- **A report is generated once per completed test and stored.** Re-viewing is always free/instant. Only *retaking* the test costs anything and is capped.
- **Retake cap: 2 free tests/day** per anonymous_id or per account. Previous report(s) always stay viewable. Backend supplies `retakes_remaining_today` (0/1/2) and, when 0, the reset time.
- **The full report is gated server-side.** Pre-login, the client must only ever receive preview-safe fields — never the full payload, even hidden in markup. The prototype fakes this with separate `preview` vs `report` screens; in production the gate is the API (`stage=preview` vs `stage=full`).
- **Retake-limit tone rule:** always frame the cap around *result reliability/meaningfulness*, never cost/tokens/business reasons. (All copy in `RetakeNote` already follows this.)

### A. Shared Retake component — `RetakeNote.dc.html`
One component, two states. **As of the current build it is used ONLY on the anonymous `resume` screen** (retake availability is an anonymous-visitor concern). It is intentionally **not** shown on preview, dashboard, or the full report — see the placement notes in B/D below. (It stays reusable for a capped-retake inline/toast if needed.)
- **Props:** `remaining` (int 0–2), `reset` (text, e.g. “فردا”), `compact` (bool — one-line variant for tight spaces/toasts).
- **State A — available (`remaining > 0`):** neutral white card, blue refresh icon. Title “امروز ۲ تست رایگان دارید” (or “می‌توانید امروز ۱ تست دیگر …”), reliability-framed subline.
- **State B — capped (`remaining === 0`):** calm lavender card (`#F3F1FA`/`#E4E0F2`/`#4A4390`), clock icon, reassurance that the report is safe + resets `reset`. **Not** an alarming/red paywall.
- Render Persian-Indic digits. Where the note appears: preview ✅, full report ✅, both dashboards ✅, capped-retake attempt (inline/toast) ✅ — **never** on landing, start-test, or during the test.

> **Landing chat example fix:** in the landing page's AI-chat teaser, the **user** bubble is right-aligned (white) and the **model** bubble is left-aligned (translucent) — RTL-correct.

### B. Preview page (`preview`) — pre-login, server-gated
The anonymous conversion page. Dark gradient header with the one-line summary; body shows **only preview-safe content**, and is intentionally **fuller** than a bare teaser to build desire without leaking the full report:
- **No retake info here.** Retake availability lives only on the `resume` screen — the preview must not show any test-count / can-I-retake messaging.
- **Dimension levels only** — name + level pill, **no meters, no interpretive notes** (those are full-report-only).
- **Personality-pattern snippet** — the first ~1 sentence of the narrative shown clearly, then a second paragraph that **fades out** (white gradient mask) as a taste of more.
- **One strength shown in full** (title + teaser), then **2 more strength cards under a blur overlay** with a 🔒 “۲ نقطهٔ قوت دیگر در گزارش کامل” pill.
- **Real-situation cards teaser** — 2 situation cards under a blur overlay with a 🔒 “۴ موقعیت واقعی در گزارش کامل” pill.
- Section count chips (e.g. “۳ مورد”) hint at how much more the full report holds.
- The blurred/faded content is decorative (`user-select:none; pointer-events:none`) — in production it must still be **preview-safe placeholder**, never the real locked payload rendered-then-blurred.
- **Locked-section teaser** (navy card): “۳ توصیهٔ عملی… / تحلیل کامل… / مسیر رشد…” each with a 🔒, then the **login CTA framed as “قفل گزارش کامل را باز کنید”** → `lead`. This is the page's entire conversion purpose.
- **Header slot shows “ورود” (login), not a profile icon** — anonymous users have no profile.
- **Must NOT include** recommendations, Action Preview, or a chat entry point.

### C. Anonymous returning-user “resume” screen (`resume`)
Thin re-entry screen for an anonymous user with a saved report. Confirms “گزارش قبلی‌تان این‌جاست” (never a blank state), a card that opens the **preview** (not the full report — not earned yet), the `RetakeNote`, and a login CTA. Header slot = login.
- **This is the ONLY screen that shows retake availability.** When a retake is still possible (`remaining > 0`), show the `RetakeNote` availability state **AND a “شروع یک تست تازه” button that routes to the test flow** (`startTest`). When capped (`remaining === 0`), show only the calm capped message — **no remaining-count / no start-test button.**
- States to support: completed+report → as above; started-not-finished → resume or restart; no test at all → send to landing.

### D. Logged-in dashboard (`dashboard`)
The post-login home. **Header slot shows the profile avatar** (fixed top-nav on every post-login page). Sections, in priority order (per brief 4.B):
1. **Report status** — gradient card: current report's one-line summary + “دیدن گزارش کامل” → `report` + “تاریخچهٔ گزارش‌ها” → `history`.
2. **Recommendations** — prominent when not yet acted on → `report`. (If already engaged, show that state instead of re-offering as untouched.)
3. **Action Preview** — state-dependent: not started (invite) / saved (show step, continue) / used (only one free — reflect as used). Prototype shows the “not started” state.
4. **Paid deeper-test upsell** — its **own distinct card** (warm plum gradient, differentiated from the report gradient), state-aware copy that references the user's progress → `paywall`. Prominent but not burying the free-value sections above it.
6. **Chat — LIVE this build.** It sits at the **bottom** of the dashboard as an **active entry card** (gradient chat icon, “گفتگو با دستیار فرامن”) that routes into the fully-built `chat` screen. (Earlier drafts had it as a dormant “coming soon” placeholder — that is no longer the case.)

**No retake info on the dashboard** — retake availability is an anonymous-visitor concern shown only on `resume`; logged-in users don't see a test-count on the dashboard.

### E. Report History (`history`)
Full list of the user's past reports, **newest first**. Each row: generation date + the report's one-line summary as its label; **the current/most-recent report is visually distinguished** (blue-bordered white card + “فعلی” badge; older ones are muted `#FBF8F1`). Each row opens its full report. Logged-in only (anonymous users have at most one active report, no history). Design for an open-ended list.

### F. Full report as the `stage=full` state (existing `report` screen)
The existing `report` screen **is** the post-login full state. The `preview` screen is the `stage=preview` state; together they satisfy “same page unlocking” (brief Stage 4). In production, gate by API stage rather than two hardcoded screens. (The full report does **not** show the RetakeNote.)

### F.1 Report content = `report_spec_v1.3.md` (canonical)
The report + preview copy/data now follows the report service spec (`uploads/report_spec_v1.3.md`) exactly — treat that spec as the source of truth for content; this prototype is its visual realization.
- **Voice:** informal **«تو»** throughout the report + preview (per the spec's sample), not «شما». The rest of the app flow (landing/test/dashboard chrome) keeps its own voice.
- **5 Big-Five dimensions**, display-label → data-key: ثبات هیجانی=`emotional_stability`, انرژی اجتماعی=`extraversion`, ذهن رشدگرا=`openness`, همدلی و همکاری=`agreeableness`, مسئولیت‌پذیری=`conscientiousness`. Sample scores/levels: 72/medium_high, 58/medium, 84/high, 66/medium_high, 88/high. `score_percent` (0–100, from backend) drives the meter length; `level` is the Persian label pill; the note under each is `snapshot_interpretations` (from AI). Level→label: high=بالا, medium_high=نسبتاً بالا, medium=متوسط, low=کم, very_low=خیلی کم. Pill color: high & medium_high = blue, medium/low = amber.
- **Fixed counts (design must rely on these):** 5 dimensions · 3 strengths (each title + description + «چرا مهم است» = `why_it_matters`) · 2 growth edges (each description + «💡 یادآوری رشد» = `growth_reframe`; never the words ضعف/مشکل/اختلال/نقص) · 4 life-pattern cards (keys `decision_style`/`relationship_style`/`work_learning_style`/`stress_energy_pattern`, each summary + «بهترین حالتت» = `best_when` + «مراقب باش» = `watch_out`) · 3 recommendations (title + description; each carries an `action_type` from `decision|execution|relationship|learning|wellbeing|communication`).
- **Narrative** = `core_narrative.body`, exactly 3 paragraphs. **Growth path** = focus + `why_this_matters` + principle («پیشرفت، ارزشمندتر از کمال است») + the 3 recommendations + a next-action CTA.
- **Static copy** (front-end config, not AI): title «پروفایل اولیه شخصیت تو», subtitle، disclaimer «این گزارش برای خودشناسی و رشد فردی است و جایگزین ارزیابی تخصصی یا درمانی نیست.» (shown at the bottom of the report).
- **Non-diagnostic language rule (safety):** never «تو اضطراب/افسردگی/اختلال داری», «همیشه/هیچ‌وقت», «قطعاً»; use «به نظر می‌رسد / ممکن است / بر اساس پاسخ‌هایت / یکی از الگوها».

### F.2 Preview gating detail (`stage=preview`, §5.2)
Pre-login the server returns **only**: `summary_one_line`, `dimension_scores` as **key + level ONLY (no score_percent, no interpretation text)**, `first_strength_title`, `teaser_line`, and `locked_counts {strengths:3, growth_edges:2, recommendations:3}`. So the preview shows dimension **level pills only** (no meters — the percent must not reach the client), one strength title, the teaser, and 🔒 locked-section teasers. Everything else is locked. Preview dimensions are ordered by level (highest first) per the spec sample.

### H. Demographic block (`demographic`) — after test, before preview
A separate, optional block shown **after the test finishes, before analysis/preview** (flow: test → **demographic** → analysis → lead → preview). Purpose: collect 4 profile/goal fields that shape recommendation *tone & examples only* — never scores (see `uploads/demographic-fields-report-usage.md`, the canonical spec).
- **Visually distinct from the test (a requirement, not a preference).** The test's mental contract was "1–5 scale → a score." These questions must *not* look like a continuation: a green **"تست کامل شد ✓"** transition banner opens the screen, and the questions use **single-choice chips**, never scales. The format change alone signals "new phase, not scored."
- **Light & fast:** exactly the 4 spec questions (age range, gender, life situation, current goal), single-choice, done in seconds — must not feel like a second test.
- **Every question is skippable with a visible, guilt-free skip:** each question row has a muted "رد کردن / پاک کردن" affordance; the bottom CTA is "ادامه" (always enabled — everything is optional) plus a "فعلاً رد می‌کنم و ادامه می‌دهم" skip-all link.
- **Returning-user state (`demoReturning` prop):** if the user already provided this before, don't re-ask — show a "این اطلاعات را قبلاً به ما داده‌ای" card with **"ادامه به پیش‌نمایش گزارش"** / **"ورود و دیدن نتیجه"**, plus a subtle "می‌خواهم به‌روزش کنم" that reveals the full form.
- **Field-usage rules (from the spec — enforce server-side):** gender is collected but **never enters the report prompt** (DB/analytics only); age/situation/goal only steer recommendation examples & tone, never dimension scores or interpretation. All fields optional; the report must be complete without any of them; none become `memory_candidate`s.

### I. Profile-completion nudge (incomplete profiles) — never blocks anything
Two placements, both live:
- **I1 — Dashboard strip (`showProfileNudge`):** a slim, calm lavender strip near the top of the dashboard (NOT a popup/modal/interstitial). Shows on every dashboard entry while the profile is incomplete; benefit-framed ("کمی بیشتر از خودت بگو … تا بتوانیم بهتر همراهی‌ات کنیم"), dismissible inline (✕). **No alarm styling** — no red, no "!" — incomplete is a valid state, not an error. Never gates anything.
- **I2 — Completeness indicator (`profileIncomplete`):** a gentle "{n} از ۴ تکمیل شده" progress card inside the profile page with a per-field checklist. Always-available baseline; the strip is the active nudge.
- **Honesty rule:** copy says "helps us help you" but must never promise a concrete personalized output that isn't produced.

### G. Header slot swap & auth-aware routing
- One fixed header slot swaps by auth state: **logged-in → profile avatar** (dashboard, full report, action, etc.); **anonymous → login CTA** (preview, resume, landing).
- Flow wiring in the prototype: **anonymous “skip / continue without saving” on the lead screen → `preview`** (not the full report); **OTP verify → sets logged-in → `report` (full)**. Profile now also links to Dashboard + Report History.

### Prototype tweaks for testing (current, complete)
Grouped as they appear in the prototype's tweak panel. **All of these are real product inputs — model them as state/config, not as prototype scaffolding** (except `showDevNav`).
- **قدم‌های عملی (steps):** `dashboardSeed` (enum `empty|active|full`, default `empty`) — how much step data the dashboard has (empty state / one active step / full list + history); `notifState` (enum `none|reminder|followup`, default `followup`) — which stage the dashboard notification card opens in; `stepAccent` (color, default `#6B4FA8`) — the accent used by the step-tracking surfaces. (Earlier builds exposed `stepState`/`entryChannel`; these three replace them — the underlying per-step state machine described in Phase 3 §H and Phase 4 §C is unchanged.)
- **حالت‌های گزارش:** `lowConfidence` (bool, default false) — the medium-confidence report banner.
- **آزمون مجدد:** `retakesRemaining` (int 0–2, default 1) — `RetakeNote` State A vs. B on the resume screen.
- **بلوک جمعیت‌شناختی:** `demoReturning` (bool, default false) — demographic block full form vs. returning-user state.
- **کاوش (اپ):** `freeLimitReached` (bool) · `hasFreeResult` (bool, default true) · `deepPaid` (bool) · `deepTaken` (bool) · `deepUnfinished` (bool) · `freeUnfinished` (bool) — the Explore/Free-Test card states (daily cap reached, has a previous result, deep test purchased/taken/unfinished, free test unfinished). All real backend state.
- **پروفایل:** `profileFilled` (int 0–4, default 0) — dashboard nudge strip (shows when <4) + profile completeness indicator.
- **پی‌وال:** `paywallPrice` (text, default "۱۹۹٬۰۰۰ تومان"); `paywallOldPrice` (text, default "۳۹۹٬۰۰۰ تومان") — struck-through pre-discount price; `paywallDiscountBadge` (text, default "٪۵۰ تخفیف") — the amber promo badge. All three come from real pricing/promotion config.
- **حالت‌های گزارش (new):** `lastReportFailed` (bool, default false) — on the Explore/last-report status card, flips the "report ready" row into a failed-generation state: a red "دوباره تلاش کن" regenerate button + reassurance line that the answers are safe and the same answers will be resent. This surfaces the e5 report-failure edge case as a real, always-available card state (not only the standalone `Edge States.dc.html` gallery) — wire it to the actual report-generation status, not a manual toggle.
- **پروتوتایپ:** `showDevNav` (bool, default true) — the floating page-map jumper. **DEV ONLY — do not ship.**

---

## Phase 3 — Site chrome, standalone login, content pages, the paid Deep Test, chat upgrades & step follow-up

Everything in this section is **new in the current build** and sits on top of Phase 1/2. Screen ids added: `login`, `blog`, `about`, `deepIntro`, `deepTest`, `deepMile`, `deepAnalysis`, `deepReport`, `bookmarks`, `appFeedback`.

**Complete screen list in the current prototype:** site header (desktop) · site header (mobile) · landing · explore · freeTest · startTest · test · analysis · demographic · lead · blog · about · login · report · deepIntro · deepTest · deepMile · deepAnalysis · deepReport · chat · feedback · appFeedback · paywall · profile · bookmarks · terms · preview · resume · dashboard · stepHistory · history · site footer (desktop) · mobile tab bar · dev nav · toast. (`explore`, `freeTest`, `stepHistory` are Phase 4 additions — see below.)

### A. Persistent site chrome (new)
The app is no longer a bare flow — it now has real site chrome that appears on the "site-like" screens and is **absent during focused tasks** (test, deep test, analysis screens, lead capture, milestone, login).

- **Chrome screens** (chrome shown): `blog, about, landing, report, dashboard, profile, history, bookmarks, paywall, preview, terms, action, feedback, appFeedback, resume`. All other screens are chrome-free full-attention screens.
- **Desktop header** — sticky, `z-index:40`, capped 1120px inner row, 13×28px padding, translucent bg + `backdrop-filter` blur, 1px bottom border. Over the landing/report gradient it **overlays** the hero (negative margin) and goes transparent/borderless; on cream screens it is solid. Left side: wordmark + 28px gradient logo tile (clicking → home). Right side: nav links + the auth slot.
- **Mobile header** — same sticky/overlay logic, condensed: logo + wordmark only, with the auth slot.
- **Mobile tab bar** — bottom fixed bar on chrome screens for phone widths. Honor `env(safe-area-inset-bottom)`.
- **Desktop footer** — on chrome screens only.
- **Nav items are auth-aware.** Logged-in: داشبورد (active on `dashboard`/`history`) · گفتگو با دستیار (active on `chat`/`bookmarks`) · فرابلاگ · دربارهٔ فرامن. Anonymous: the equivalent public set, with the login CTA in the auth slot instead of the avatar.
- **Home target is auth-dependent:** `homeScreen = loggedIn ? 'dashboard' : 'landing'`. The logo always goes there.
- **Gated entries redirect through login.** e.g. tapping "گفتگو با دستیار" while anonymous goes to `login` with a stored `loginAfter` return target, then lands on `chat` after verifying. **Implement login as a redirect-with-return-target, not a dead end.**

### B. Standalone Login screen (`login`) — new
Distinct from the in-flow `lead` capture. Same two sub-steps (`loginStep: 'phone' | 'otp'`), same input/OTP treatment and consent sentence as §5, but reached from the header/nav rather than after a test, and it **returns the user to wherever they were heading** (`loginAfter`, default `dashboard`).
- `login` state: `loginStep`, `loginOtp`, `loginResent`, `loginAfter`.
- Reuse one phone/OTP component for both `lead` and `login`; only the surrounding framing and the post-success destination differ.

### C. Farablog (`blog`) — coming soon
A real page, honestly labeled. 880px cap, 44px top padding. A lavender **"به‌زودی"** badge, a heading + explanation of what the blog will be, and placeholder article cards. **Ship it as a genuine coming-soon page, not a fake feed** — no dummy articles presented as real posts.

### D. About Faraman (`about`)
880px cap. Eyebrow "دربارهٔ فرامن", the product's purpose/philosophy in prose, and supporting cards. Static content page.

### E. The paid Deep Test — 150 questions (`deepIntro → deepTest → deepMile → deepAnalysis → deepReport`)
This is the paid tier the paywall sells, now fully designed.

**E.1 — Intro (`deepIntro`).** 560px. Back → `paywall`. Purple "پروفایل توسعهٔ فردی" badge, `h1` **"۱۵۰ سؤال"**, and the key reassurance: each page holds only five questions, progress saves per card, resumable. Three bordered rows: "۳۰ کارتِ پنج‌سؤالی — حدود ۲۵ دقیقه در کل" / "هر جا خواستی توقف کن؛ پاسخ‌ها نگه داشته می‌شوند" / "پاسخ درست و غلط ندارد — نزدیک‌ترین گزینه به این چند ماهت را انتخاب کن". Then an answering-guide card (`#F1EEE6`, radius 18px): answer based on the last few months in most situations, not aspiration. Bottom: **"شروع کارت اول"** → `deepTest`; ghost "بعداً شروع می‌کنم" → `dashboard`.

**E.2 — Card of 5 (`deepTest`).** The core of the deep test. **600px** cap (wider than the free test).
- Constants: `deepTotal = 150`, `deepPerCard = 5` → **30 cards**.
- **Sticky top block** (bg `#F8F4EC`): 38px back button, card label "کارت {n} از ۳۰", count label "{answered} از ۱۵۰ سؤال", a "ذخیره و خروج" link → `dashboard`, and a 6px progress bar (`width .45s ease`, min 1.5%) = `answered / 150`.
- Under it, a static scale legend row: "۱ = کاملاً مخالفم" (right) / "۵ = کاملاً موافقم" (left).
- **Five question cards** per screen, each a white 20px-padded card (radius 20px, `1px solid #EDE7DA`) with a 28px numbered blue tile, the statement, and its own 1–5 Likert row.
- **Next button is state-aware, and its label teaches:** when the card is incomplete it is grey `#C9CDDE` and reads **"به {n} سؤال باقی‌مانده پاسخ بده"** (n = remaining count, Persian digits); when complete it is blue and reads **"کارت بعدی"**. Reproduce this — it replaces a generic disabled state with a useful instruction.
- Back: previous card (scroll to top), or → `deepIntro` from card 1.
- Answers stored in `deepAnswers` keyed by absolute question index (`card * 5 + k`) — **persist server-side per card, since resume is a promise made on the intro screen.**

**E.3 — Milestone (`deepMile`).** A full-screen gradient encouragement beat between cards, shown **once per milestone** (`deepSeenMiles` guard — never re-shown on back/forward). Currently one milestone at card 2 → **۲۵٪**, "یک‌چهارم راه را آمدی", body explaining what has been captured so far and that answers are saved. 132px ring, then "ادامه" → next card and "بعداً ادامه می‌دهم" → `dashboard`. **Design for a milestone map, not one hardcoded point** — the prototype's `deepMilestones` is a keyed object; add 50%/75% entries the same way.

**E.4 — Deep analysis (`deepAnalysis`).** Same gradient/orb language as the free analysis, but with **4 messages and a step indicator** (dots brighten as they complete): scoring 30 facets → finding active combined patterns → writing report sections → assembling the summary and blind spots. Replace the timer with the real generation request.

**E.5 — Deep Report (`deepReport`) — one long scrolling page.** The paid deliverable, and the most substantial screen in the app.
- **Reading-progress bar:** a 3px fixed bar at the very top (`position:fixed; top:0`, `z-index:20`) whose width tracks scroll position (`linear-gradient(90deg,#2743C6,#8E6BA8)`, `width .1s linear`), driven by a scroll listener on a ref.
- **Alternating image/text rows.** Most sections pair prose with a large illustration panel, alternating `row` / `row-reverse` per index so the page has rhythm. The image panels are **`<image-slot>` placeholders** (see Assets) — the real illustrations are supplied by the client, not drawn in the design.
- **Section order:**
  1. **Cover** — "پروفایل توسعهٔ فردی" + headline, with a full-figure character illustration slot (`deep-cover`).
  2. **نگاه اول / خلاصهٔ پروفایل تو** — two highlight cards: **برجسته‌ترین منبع رشد** and **بیشترین هزینهٔ پنهان**, plus "سه قوتِ طبیعی" and "سه اولویتِ رشد" lists (slot `deep-summary`).
  3. **شکلِ کلی — نمای کلیِ پنج عامل** — the five factors as three bands (low / middle / high) with the caption explaining the ring order, then **تفسیرِ یکپارچهٔ پنج عامل** as prose.
  4. **Per-factor sections (5)** — each: factor name + level, summary, then its **facets**, each with "وقتی خوب کار می‌کند" / "وقتی هزینه می‌سازد". Each factor section ends with an **"«{factor}» در من چطور کار می‌کند؟ بیا حرف بزنیم"** button that opens `chat` seeded with that question. Own image slot (`deep-domain-{i}`), alternating side.
  5. **سرمایهٔ رفتاری — نقاط قوت و شکلِ افراطی‌شان** — each strength paired with **"وقتی از حد بگذرد"** (its overuse form), then a **پیامِ توسعه‌ای این بخش** and a "بگو کدام قوتت را دقیق‌تر بشناسیم" chat entry (slot `deep-strengths`).
  6. **نقاط کور — «فرضیه‌ها، نه حکم»** — each blind spot given as a hypothesis with **شواهد / محرک / نشانهٔ قابل مشاهده**, plus **سه سؤال برای خودت**, and a chat entry (slot `deep-blind`). The framing header is load-bearing: these are hypotheses, never verdicts.
  7. **سبک‌ها و زمینه‌ها** — contextual style cards, own slots.
  8. **از اینجا به بعد — جمع‌بندی و تعهد شخصی** — "در بهترین حالتم چطور عمل می‌کنم", "زیر فشار، چه الگویی را زودتر تشخیص بدهم", **سه کارِ کوچک از این هفته**, and "بگو کدام قدم را با هم دقیق‌تر کنیم" (slot `deep-closing`).
  9. **Closing CTA** — "حالا دربارهٔ همین گزارش حرف بزنیم" → `chat`, and "بازگشت به داشبورد".
- **Chat is woven through the report.** Multiple sections end with a context-seeded chat entry point; each pre-fills a specific question. Implement as "open chat with this seeded prompt", not a generic link.
- **Safety framing carries over from the free report** — non-diagnostic language, hypotheses not verdicts, no raw scores (levels + bands only).

### F. Chat upgrades (`chat`) — substantially expanded
The chat is no longer a scripted teaser. Per-message and composer behavior now includes:
- **Per-message action row** on AI messages: 👍 / 👎 vote (toggleable, tinted when active — up `#E7EBFA`/`#2743C6`, down `#F6E9E9`/`#B4553F`), **copy** (shows a copied confirmation state), **save/bookmark** (filled purple `#8E6BA8` when saved), and **regenerate**. Message metadata lives in `msgMeta` keyed by message index.
- The action row is **hidden** on quick-reply messages, action cards, check-in messages, and the message currently being typed.
- **Quick-reply messages** — AI messages can carry a `quick` payload (a question + options); once answered, the answer replaces the options.
- **Action cards in-chat** — the AI can emit a "step for today" card inline.
- **Check-in messages in-chat** — the follow-up check-in (see H) can also run inside the conversation.
- Saved messages feed the **Bookmarks** screen.

### G. Bookmarks (`bookmarks`) — new
560px. The list of chat messages the user saved (the purple save icon in the chat action row). Reached from the profile and from the chat nav group. Rows show the saved message; empty state must be a real designed state, not a blank page.

### H. Step follow-up & check-in — the "قدم امروز" lifecycle (new, prop-driven)
The "step for today" is now a **tracked commitment with a deadline and a check-in**, not a one-off card. Driven by two prototype props:
- **`stepState`** (enum, default `dueLast`): `calm` | `due` | `dueLast` | `expired` | `none`.
- **`entryChannel`** (enum, default `notif`): `login` | `notif` — how the user arrived. On `notif` **and** a due step, the dashboard opens with a **notification banner** at the top (suppressed once opened, or if the check-in is already answered).

**Due card on the dashboard** (`stepDue` = `due` or `dueLast`): a white card with a **blue 1.5px border** and blue shadow — "وقتِ پیگیریِ قدم توست", "مهلت: {deadline} — گذشته", the step text in 16px/800, then the check-in.

**Check-in sequence (three stages, one card):**
1. **Ask** — "انجامش دادی؟" with three pills: **انجام دادم** (solid blue) / **نیمه‌کاره** / **نشد** (outline `1.5px #C7CEF0`, all `min-height:44px`). On `dueLast`, a muted line adds "این آخرین یادآوریِ این قدم است." — **the reminder chain has a defined end; it does not nag forever.**
2. **Blocker** — if the answer wasn't "done": "چه چیزی جلویش را گرفت؟" with a wrapping row of ~5 blocker chips.
3. **Closed** — a resolved state after the check-in is answered; the card stops asking.

**Rules:** a step only enters this lifecycle once seeded; `stepState: 'none'` means no step exists (no card at all); `stepConsumed` retires it. Tone stays supportive at every branch — "نشد" must never be treated as failure.

### I. App feedback (`appFeedback`) — new, distinct from report feedback
Reached from the **profile**, not the report. 560px, back → `profile`. Rating + free text about **the app itself** (`appFbRating`, `appFbText`, `appFbDone`), with its own thank-you state. Keep the two feedback surfaces separate: `feedback` = "did this report describe you accurately", `appFeedback` = "how is the product".

### J. Profile additions
The profile is now the hub for the secondary surfaces: saved report, subscription, **پیام‌های نشان‌شده (Bookmarks)**, **نظر دربارهٔ اپ (App feedback)**, report history, dashboard, and the destructive actions. Confirmation sheets (`confirmAction`, `profileSheet`, `profileDraft`) back the editable/destructive rows — destructive actions are confirmed, never immediate.

---

## Phase 4 — App-mode home ("Explore"), per-test detail page, and the step-tracking system

New in the current build, on top of Phases 1–3. New screen ids: `explore`, `freeTest`, `stepHistory`. The dashboard's step section was substantially rebuilt.

### A. Explore — app-mode home (`explore`)
For a **logged-in returning user**, this replaces `landing` as the entry point to taking a test (the marketing `landing` page remains for anonymous/new visitors — `homeScreen = loggedIn ? 'dashboard' : 'landing'`; `explore` is reached from the nav, not auto-shown). 560px, chrome shown.
- Heading "کاووش" + one-line explainer.
- **Test picker cards, not a single CTA** — two cards, always both visible:
  - **Free test card** (white, blue top accent bar) — icon tile, title "تست خودشناسی" + a "رایگان" pill, description. If unfinished (`freeUnfinished`), an inline progress bar + "{done} از {total} سؤال". Bottom row: a **daily-limit status chip** (`freeLimitText`/`freeLimitBg`/`freeLimitFg` — reflects the once-a-day cap) + "مشاهدهٔ تست ‹" → `freeTest`.
  - **Deep test card** (dark gradient, same family as the paid upsell) — icon tile, title "تست تکمیلی" + a status pill (`deepBadgeText`: "ویژه" or "خریداری‌شده" once paid), description. If unfinished, inline progress bar. Bottom row: status text + "مشاهدهٔ تست ‹" → `paywall` (or resume if already purchased/unfinished).
- **Current report card** — icon + "تست خودشناسی — {date}" + `previewSummary` + two buttons: "دیدن گزارش کامل" → `report`, "تاریخچهٔ گزارش‌ها" → `history`.
- Card style is the shared pattern for "pick one of several available tests" — reuse it if more test types are added later.

### B. Free Test detail (`freeTest`)
A dedicated info/launch page for the free test, reached from the Explore card (`goFreeTest`) — replaces jumping straight from a teaser into the test. 560px.
- Back → `explore` (logged-in) or `landing` (anonymous) — `freeTestBack` checks auth.
- `h1` "تست خودشناسی فرامن" + a 3-stat row (30 سؤال / ۱۰ دقیقه / 3 قدم عملی).
- "در گزارش چه می‌بینی" — checklist card (`freeBenefits`, ✓ bullet rows).
- **Daily-limit-reached state** (`freeLimitReached`) — soft-amber card ("تست‌های امروزت تمام شده" + reset time `freeResetText`); the free test is capped to **once per day** (distinct from the paid deep-test's separate cap) — reproduce this as a real per-day gate, not a UI-only disable.
- **Last-result shortcut** (`hasFreeResult`) — a two-row card: "دیدن نتیجهٔ آخرین تست" → `report`, "گفتگو دربارهٔ همین تست" → `chat`.
- Pinned bottom CTA (`startFreeTest`, disabled when limit reached) → `test`, with a small caption note underneath.

### C. Step-tracking system — dashboard rebuild + new Step History screen
The "قدم امروز" follow-up (Phase 3 §H) is now a full multi-step tracker rather than a single due-card:

**Dashboard (`dashboard`) additions:**
- **Notification card** (`notifCard`) — dark card with **four sequential sub-states in one component**, each shown by a state flag (not mutually-exclusive screens, but a controlled stage machine on the same card):
  1. `notifReminderActions` — initial reminder: body text + "همین حالا انجامش دادم" / "باشد".
  2. `notifFollowupActions` — follow-up ask "انجامش دادی؟" → انجام دادم / نیمه‌کاره / نشد (three pills, same tone rules as Phase 3 §H).
  3. `notifBlockerAsk` — if not fully done: "چه چیزی جلویش را گرفت؟" + a wrapping row of blocker chips (`notifBlockers`, dark pill style matching the card).
  4. `notifClosed` — resolved confirmation ("{label} — ثبت شد") + note that it moved to step history and no further reminders will be sent for that step.
  Each stage is dismissible (✕ → `notifDismiss`).
- **Step filter row** (`stepFilters`) — horizontally-scrollable pill filters above the pending list (e.g. all/overdue/today — see `stepFilters` array in the logic for exact labels), each toggled via `f.pick`.
- **Pending steps list** (`pendingSteps`) — replaces the old single due-card: each row is a white/tinted card with a **tappable circular "mark complete" affordance** (44px hit target, empty ring) at the leading edge, the step text, and a deadline label. Tapping the row body (`s.open`) opens detail; tapping the circle (`s.complete`) completes inline.
- **Empty state** (`noPending`) — dashed-border card with a real designed message + two forward actions ("دیدن توصیه‌های گزارش" → `report`, "گفتگو با دستیار" → `chat`) — never a blank gap.
- **"تاریخچهٔ قدم‌ها" row** → new `stepHistory` screen (see below), with a one-line teaser of what's inside.

**Step History (`stepHistory`) — new screen.** 680px, chrome-free-adjacent detail page, back → `dashboard`.
- Explains its purpose: completed/expired steps land here; tap to see detail or record a missing answer.
- **History list** (`historySteps`), each an accordion row: a small circular status mark (done/expired glyph + color), the step text, meta line; tapping toggles detail (`h.toggle`, single row expands in place — chevron rotates like the report accordions).
  - **Done branch** (`h.isDone`): "انجام شد — {date}" (green) + a reflection line + a "قدمِ بعدی را بگیر" CTA (purple, routes into the next recommendation).
  - **Already-answered branch** (`h.answered`): shows the recorded blocker/channel in a muted sub-card — read-only, no re-asking.
  - **Needs-answer branch** (`h.needsAnswer`): a step that expired with no response — "دوباره فعالش کن" (reactivate) or "بگو چرا انجام نشد" (opens the blocker picker).
  - **Blocker-ask branch** (`h.blockerAsk`): same blocker-chip pattern as the dashboard notification card, so a lapsed step can still be closed out with a reason after the fact.
- **Empty state** (`noHistory`) — dashed card, "تاریخچه هنوز خالی است".

**Model implication:** a step now has richer state than before — pending → (reminder → followup-ask → optional blocker) → closed, or expired → (reactivate | answer-later-with-blocker). Persist this per-step state machine server-side; the UI stages above are its exact rendering.

---

## Phase 5 — Report delivery, in-report chat, and report feedback

New in the current build of `Faraman App.dc.html`, on top of Phases 1–4. No new screens — these change the **report** and **deepReport** surfaces and the **chat** screen.

### A. Email a copy of the report (free report + deep report)
Both report screens carry an **email-delivery strip** — the free report's sits just under the gradient header (`margin-top:-30px`, overlapping it), the deep report's inside the page flow. One white card, `1.5px solid #EDE7DA`, radius 16px, laid out as a wrapping row:
- Leading: a 30px `#E9EBF8` icon tile + label «یک نسخه از گزارش را برایت ایمیل می‌کنیم» (deep report: «نسخهٔ کامل گزارش را برایت ایمیل کنیم»).
- **Unsent state:** an inline email field (`type="email"`, `min-width:210–220px`, bg `#FBF8F1`) + a send button; the button is **disabled until the value matches a basic email pattern**, and **Enter** in the field sends.
- **Sent state:** the field is replaced by a green confirmation (`#E4F1EA`, ✓, «به {email} فرستاده شد.») with a «تغییر ایمیل» link that returns to the editable state.
- State keys: `reportEmailValue/Sent/Open`, `deepEmailValue/Sent/Open`.
- **Production:** send the real report (PDF/HTML) to a verified address; pre-fill from the account when logged in, and treat this as an explicit opt-in to that one email, not a marketing subscription.

### B. Sticky in-report chat dock (free report)
The free report no longer ends with a single "ask about my report" card. Instead a **sticky dock** sits at the bottom of the report screen (`position:sticky`, `z-index:30`, over a `linear-gradient(180deg, transparent, #F8F4EC 40%)` fade, capped 680px):
- A horizontally-scrolling row of **suggested-prompt chips** (white, `1px solid #C7CEF0`, blue text) — each opens `chat` seeded with that prompt.
- A pill **composer** (white, `1.5px solid #C7CEF0`, shadow, placeholder «دربارهٔ گزارش بپرس…») with a 40px round blue send button; Enter also sends. Sending opens `chat` carrying the typed message.
- `reportDockBottom` = `74px` when the mobile tab bar is visible, otherwise `0` — **the dock must clear the tab bar and the safe-area inset**, not sit under them.
- The report also keeps a gradient «دربارهٔ همین تست بپرس» card inside the flow and a white **«اینجا تازه شروع ماجراست»** upsell card (`#FFFDF8`, `1.5px solid #DCD3BE`, outline CTA → `paywall`) — the upsell is now quiet rather than a full gradient block.

### C. Deep Report — per-section feedback + seeded chat ("action bars")
Every major deep-report section (each of the 5 factors, the strengths section, blind spots, each style/context card, and the closing section) now ends with a **horizontal action bar** delimited by hairline top/bottom borders (`#E4DFD2` on light sections, `rgba(255,255,255,.22)` on dark):
- **Vote pair** — 👍 / 👎 as 40px icon buttons. Toggleable and mutually exclusive per section; active up = `#2E8A5C` filled, active down = `#D08A6A` filled, inactive = the section's muted base color. Stored in `deepVotes` keyed by section (`dom-{factor}`, `deep-strengths`, `deep-blind`, `deep-closing`, `th-{style}`) via the `voteVals(key, base)` helper.
- **Seeded-chat CTA** — a full-width pill (`min-height:54px`, blue `#2743C6`; amber outline on the blind-spots section) reading the section's question in guillemets, e.g. «{factor} در من چطور کار می‌کند؟», «کدام یک از این قوت‌ها را دقیق‌تر بشناسم؟», «یکی از این‌ها برایم آشناست — درباره‌اش حرف بزنیم»، «کدام قدم را با هم دقیق‌تر کنیم؟». Each opens `chat` **pre-seeded with that exact question**.
- **Production:** persist section-level votes against the report id (they are the quality signal for the generated report) and keep the seeded prompt attached to the chat turn so the assistant knows which section it is answering about.

### D. Deep Report — closing "explore" block
The deep report's closing CTA was rebuilt as a light card on the gradient: headline «چه چیزی را می‌خواهی کاوش کنی؟» over a `#FBFAF7` panel titled «با دستیارت حرف بزن» + «دستیار کلِ این گزارش را پیش رویش دارد. مثلاً بپرس:», then **one full-width outline button per suggested prompt** (blue border, 56px min-height, each sends that prompt into `chat`). Below the panel: «{ask about the whole report}» (white) and «بازگشت به داشبورد» (outline). Prompts come from `deepExplorePrompts` (derived from `chatScript`) — in production, generate them from the user's actual report sections.

### E. Chat — empty state
The chat screen now has two modes:
- **Empty** (`chatEmpty`: no user messages, not typing, no seeded entry) — a centered welcome: 64px gradient icon tile, «سلام {نام}» (falls back to «دوست من» when no profile name), the headline «امروز از کجا شروع کنیم؟», and a stacked list of suggested-prompt buttons under «نمی‌دانی از کجا شروع کنی؟ یکی از این‌ها را بپرس».
- **Conversation** (`chatHasMsgs`) — the message list as documented in Phase 3 §F.
Both share the composer. Build the empty state as a real designed state; never open chat on a blank page.

### F. Footer
The desktop footer grid is now **4 columns**, the last holding an app-download **QR block**, and the contact address is `hello@faraman.ai`.

### Implementation checklist (Phase 5)
- [ ] Email-a-copy strip on both reports: validated inline field, Enter-to-send, green sent state with «تغییر ایمیل», real delivery.
- [ ] Sticky report chat dock: prompt chips + composer, clears the mobile tab bar (`74px`) and safe-area inset, seeds `chat` with the chip/typed text.
- [ ] Deep-report action bars: toggleable 👍/👎 per section persisted against the report id, plus per-section seeded-chat CTAs.
- [ ] Deep-report closing explore block with per-prompt buttons generated from the user's own report.
- [ ] Chat empty state with name greeting and suggested prompts.

---

## Design Tokens

**Colors**
- Page bg / warm off-white: `#F8F4EC`
- Primary text: `#242A38`; secondary text `#3C4150`; muted `#5D5C55`; faint `#A9A597`; faintest `#C4C0B2`
- Primary blue (actions/selected): `#2743C6`; deep navy (headlines/cards): `#22307E` / `#1B2150`
- Purple accent: `#8E6BA8`; green (positive): `#2E8A5C`; amber (caution): `#8A6B2E`; danger: `#B4533A`
- Disabled button grey: `#C9CDDE`
- Tints: blue `#E9EBF8`, purple `#F3EBF6` / lavender `#F3F1FA`, green `#E4F2EA`, amber `#FBF3E4`
- Borders: `#EDE7DA` (default), `#E4E0F2` (lavender card), `#EFD9AE` (amber banner), `#DCD6C6` (chip)
- **Signature gradient** (hero / analysis / report header): `linear-gradient(165deg, #1B2150 0%, #3A3D8F ~55%, #8E6BA8 ~82%, #C98F9B 100%)` (report/analysis stop at `#8E6BA8`)
- Progress/meter fill: `linear-gradient(90deg, #2743C6, #8E6BA8)`

**Typography** — Estedad. Rough scale: display `clamp(30–42px)`/800; h1 25–28px/800; section title 17–20px/800; question 23px/800; body 13.5–16px/500–700 with generous line-heights (1.9–2.15); labels/eyebrows 11–13px/700–800.

**Radii:** buttons/inputs 14–16px; cards 16–24px; pills/chips 999px; icon tiles 10–18px.

**Shadows:** cards `0 2px 10px rgba(80,70,40,.05)` → `0 4px 16px rgba(80,70,40,.06)`; primary CTA `0 6px 18px rgba(39,67,198,.22)`; elevated `0 10px 30px rgba(10,15,50,.3)`.

**Spacing:** side padding 28px; section gaps 28–48px; content max-widths 560 / 680 / 720px.

**Animations / timings:**
- `fmIn` screen/element enter: opacity+`translateY(10px)` ~0.35–0.4s ease
- `fmPulse` (analysis orb): scale/opacity, 2.2s loop
- `fmFloat` (landing orb): 5s bob
- `fmDot` (loading/typing dots): 1.2s, staggered 0/.2/.4s
- Progress bar: `width .4s ease`; pill/button state: `.15–.2s`; accordion chevron: `transform .2s`
- Test auto-advance after answer: **420ms**; analysis message interval: **1700ms**; chat reply delay: **1300ms**

---

## State Management (variables to model)

- `screen` — current screen (enum above)
- `answers` — map of question index → 1–5 (persist across back/forward)
- `q` — current question index (0–7)
- `analysisIdx` — which loading message is showing
- `leadStep` — `'phone' | 'otp'`; `contact` (phone string), `otp` (≤6 digits), `resent` (bool). No consent state is tracked — the terms/privacy sentence is static UI, not a stored flag.
- `sitOpen` — index of the open report accordion (`-1` = none; default `0`)
- `chatMsgs` — array of `{role:'user'|'ai', text}`; `chatText` (composer input); `typing` (bool)
- `actionWhen`, `actionSize` — selected chips; `actionBuilt` (bool); `actionSaved` (bool)
- `fbRating` (0–5), `fbTags` (string[]), `fbText` (string), `fbSubmitted` (bool)

**Configurable / report-driven props** (surfaced as tweaks in the prototype — treat as real inputs in production):
- `lowConfidence` (bool) — toggles the medium-confidence report banner
- `paywallPrice` / `paywallOldPrice` / `paywallDiscountBadge` (strings) — current price, struck-through pre-discount price, promo badge copy (defaults "۱۹۹٬۰۰۰ تومان" / "۳۹۹٬۰۰۰ تومان" / "٪۵۰ تخفیف"); hide the last two when no promotion is running
- `showDevNav` (bool) — the floating page-map jumper. **DEV ONLY — do not ship.**

**Data that should come from the backend in production** (hard-coded in the prototype): the 8 questions, all report content (5 dimensions + pcts, strengths, edges, 4 situations, 3 recommendations, headline summary, low-confidence flag), chat replies, paywall benefits & price.

---

## Assets
- **`assets/Estedad-FD-Variable.woff2`** — the Estedad variable font (weights 100–900). Use in the app. Source: bundled here from the prototype.
- **Icons** — the prototype uses inline stroke SVGs (Lucide-style: `stroke-width:1.8`, round caps/joins) and a few emoji/glyphs (✓ 🔒 → ← ‹ ⌄ ↑). Replace with the codebase's icon set, matching the line-icon style and stroke weight.
- **`assets/hero-wide-art.webp`** (desktop hero, 700×768) and **`assets/hero-hand-hq.webp`** (mobile hero, 1094×910) — the current landing hero illustration ("a hand holding up a figure"), replacing the earlier dawn-photograph hero. **Stand-in artwork: confirm licensing or replace before launch.** Unused alternates kept for reference only: `hero-bg-clouds.jpg`, `hero-bg-path.jpg`, `hero-companion.jpg`, `hero-lantern-{a,b,c}.svg`, `hero-clouds-*`, `hero-wide-900/1376*.webp`.
- **`assets/free-test-mirror-1120x630.png`** — illustration on the "Free Test" ad-landing description screen.
- **`assets/cafebazaar-icon.png`** — the کافه‌بازار store mark used in the hero download links.
- **`assets/icons/*.png`** — the illustration/icon set used by the report sections (dimension icons `dim-emotional`, `dim-empathy`, `dim-growth`, `dim-responsibility`, `dim-social`, plus `growth-path`, `key-strengths`, `personality-pattern`, `personality`, `real-situations` and friends). Bundled here; use them or their production equivalents.
- **Deep Report illustration slots — client-supplied.** The Deep Report's large image panels are `<image-slot>` placeholders in the prototype (`image-slot.js`), each with a Persian placeholder describing what belongs there. Slot ids: `deep-cover` (full-figure character, transparent background), `deep-summary` (illustrated portrait / "first look"), `deep-domain-0…4` (one per personality factor), `deep-strengths`, `deep-blind`, `deep-closing`, plus one per style/context card. **These are intentionally empty in the design — the real artwork must be supplied and dropped in; do not ship the placeholders.** Keep the alternating row layout and the panel sizes (240–340px tall, radius 24px) when the real images land.
- Otherwise no raster images are required by the flow (the `uploads/` folder in the source project holds the design brief and reference photos, not runtime assets).

---

## Files in this bundle
- **`Faraman App.dc.html`** — the interactive design reference (all screens + logic, landing included — see §1a). Open in a browser to explore; read the `<script>` at the bottom for exact state logic, copy, and timings. Source of truth for **behavior**.
- **`RetakeNote.dc.html`** — the retake-status component (two states), used on the anonymous `resume` screen. Source of truth for **behavior**.
- **`Design System.dc.html`** — the visual foundation: colors, type scale, spacing, button/input/component variants, general states (skeleton/toast/error/offline), and dev notes. Source of truth for **styling**. **Open this first.**
- **`Edge States.dc.html`** — gallery of edge-case screens (e1–e8: resume, skipped login, incomplete test, report loading/failed, negative feedback, payment cancelled, offline). Source of truth for **error/edge behavior**.
- **`support.js`** — the prototype's preview runtime. **Reference only — do not port.**
- **`image-slot.js`** — the drag-and-drop image placeholder used for the Deep Report's illustration panels. **Prototype-only** — replace with real `<img>` elements once artwork exists.
- **`assets/Estedad-FD-Variable.woff2`** — the app font.
- **`assets/icons/`** — the report illustration/icon PNGs.
- **`README.md`** — this spec.
- **`explorations/`** — design explorations behind the shipped landing, for context only (**not** specs to build): `Landing v2.dc.html` (superseded — its design was merged into `Faraman App.dc.html`, kept only for history), `Landing Redesign.dc.html` (earlier visual directions, web + app-home artboards), `Landing Bottom Options.dc.html` (alternative treatments for the landing's lower half), `Hero Illustration Options.dc.html` (hero-image/illustration candidates, including earlier photographic-hero directions no longer used), `Logo Marks.dc.html`, `Directions.dc.html`. Each opens standalone in a browser. Where any of these disagree with `Faraman App.dc.html`, **`Faraman App.dc.html` wins.**
- **`specs/`** — the source briefs this design was built against, for cross-checking:
  - `report_spec_v1.3.md` — canonical report content/data contract (fixed counts, level labels, voice, safety rules).
  - `demographic-fields-report-usage.md` — the 4 demographic fields and how they may/may not be used.
  - `design_brief_free_test_flow_EN.md` — the free-test/conversion-flow brief (Phase 2 pages).
  - `action_preview_v1.md` — spec for the Action Preview / "step for today" feature referenced on the dashboard.
  - `Design Brief - MVP Self-Development App.pdf` — the original MVP brief.

---

## Implementation checklist / gotchas
- [ ] Build as a **responsive web app**, mobile-first: centered capped columns (560/680/720px), `clamp()` type, and `auto-fit` card grids so it scales phone → tablet → desktop with minimal media queries (ref breakpoints 390/430/768/1280).
- [ ] Build RTL-first; mirror layouts and arrow directions; render Persian-Indic numerals in UI (Latin only inside phone/OTP fields).
- [ ] Use real Estedad font.
- [ ] Respect mobile safe-area insets for the pinned bottom CTAs.
- [ ] Model the screen state machine and the per-screen sub-states (lead phone/otp, action config/result, feedback form/done).
- [ ] Match interaction timings (420ms auto-advance, 1700ms analysis steps, 1300ms chat reply) and the enter animations.
- [ ] Report accordion is single-open with the first item open by default.
- [ ] Disabled→enabled button gating: Next (answered), OTP send (≥5 chars), verify (4 digits), build action (both chips), submit feedback (rating chosen).
- [ ] Build the edge/error states (skeletons not spinners, soft-brick errors, offline, test resume, incomplete-test guard, report-failure retry, negative-feedback follow-up, payment-cancel exit) — see the Edge Cases section and `Edge States.dc.html`.
- [ ] Build the Phase-2 pages: **Preview** (server-gated, preview fields only), **Resume** (anonymous re-entry), **Dashboard** (logged-in), **Report History** (full list, newest first, current distinguished), and the shared **RetakeNote** (2 states, reliability-framed).
- [ ] Enforce the server-side gate: pre-login clients receive **only** preview-safe fields — never the full report payload, even hidden in markup.
- [ ] Retake cap = 2/day per anonymous_id or account; previous reports always viewable; RetakeNote copy always frames the cap around result reliability, never cost.
- [ ] Header slot swaps by auth: profile avatar (logged-in) vs. login CTA (anonymous).
- [ ] Chat is **live**: an active entry card at the bottom of the dashboard routes into the full `chat` screen.
- [ ] Retake info appears **only** on the `resume` screen (availability + “start new test” button when possible; calm capped message with no count when not) — never on preview, dashboard, or the full report.
- [ ] Preview page is fuller: level-only dimensions, a fading narrative snippet, one full strength + blurred locked strengths/situations behind 🔒 pills — all preview-safe placeholder, never the real locked payload blurred.
- [ ] Demographic block runs **after** the test, before analysis/preview: visually distinct (green "تست کامل شد ✓" banner, single-choice chips, NOT scales), light/fast (4 optional questions), every question skippable, plus a returning-user state. Gender never enters the report prompt; age/situation/goal steer only recommendation tone/examples, never scores.
- [ ] Profile nudge never blocks: soft recurring dashboard strip (dismissible, no alarm styling) + gentle completeness indicator in the profile page. Honest, benefit-framed copy only.
- [ ] Honor the "never" rules (no harsh red, no raw scores, no clinical-blue surfaces, no <12px body).
- [ ] Registration consent is a **single inline sentence** under the phone-step CTA (“ورود یا ثبت‌نام شما به معنای پذیرش … است”, Digikala-style), with the two terms/privacy phrases linking to a real in-app Terms/Privacy page (screen 6) — no checkbox, no separate consent screen, nothing stored/tracked about acceptance.
- [ ] The Terms/Privacy page content shipped in the prototype is **placeholder copy** — replace with reviewed legal text before launch.
- [ ] OTP is **6 digits shown as six separate boxes**; verify enables only when all six are filled; accept paste and Persian/Latin digits.
- [ ] Landing top bar has both **ورود (Login)** and **ثبت‌نام (Register)** buttons.
- [ ] Replace fake analysis timer with real report generation; replace scripted chat with a real report-grounded LLM call; wire OTP and payment to real services.
- [ ] Build the **persistent site chrome**: sticky desktop header (overlays and goes transparent on gradient screens, solid on cream), mobile header, mobile tab bar, desktop footer — shown only on the "site" screens, absent during test / deep test / analysis / lead / milestone / login. Nav set and auth slot swap by auth state; logo goes to `dashboard` when logged in, `landing` when not.
- [ ] Build the **standalone `login` screen** as a redirect-with-return-target (`loginAfter`), reusing one phone/OTP component shared with `lead`. Gated nav entries (e.g. chat while anonymous) route through it and land on the intended destination.
- [ ] Build **Farablog** as an honest coming-soon page (no fake articles) and **About Faraman** as a real content page.
- [ ] Build the **Deep Test**: intro (۱۵۰ سؤال / ۳۰ cards / resumable promise) → cards of 5 (600px cap, sticky header + progress, per-card gating with the instructive next-button label "به {n} سؤال باقی‌مانده پاسخ بده") → milestone screens (once each, milestone-map driven, currently 25%) → 4-message deep analysis with step dots → deep report. **Persist `deepAnswers` per card server-side — resume is a promise made on the intro screen.**
- [ ] Build the **Deep Report** as one long scrolling page with a fixed 3px scroll-progress bar, alternating image/text rows, and the 9-part section order (cover / first look / five-factor overview / 5 per-factor sections with facets / behavioral capital with overuse forms / blind spots as hypotheses with evidence-trigger-signal / styles & contexts / closing commitment / chat CTA). Each factor, strength, and blind-spot section opens `chat` **seeded with a specific question**.
- [ ] Deep Report illustration panels are **client-supplied artwork** — the design ships empty slots with descriptions. Never ship the placeholders.
- [ ] Build the **chat upgrades**: per-AI-message action row (vote toggle with tinted active states, copy with confirmation, save/bookmark, regenerate) stored in a per-index metadata map; hidden on quick-reply / action-card / check-in / mid-typing messages; plus quick-reply payloads, inline action cards, and inline check-ins.
- [ ] Build **Bookmarks** from saved chat messages, with a real designed empty state.
- [ ] Build the **step follow-up lifecycle**: `stepState` (calm/due/dueLast/expired/none) + `entryChannel` (login/notif) → notification banner on notif-entry, blue-bordered due card with deadline, then the 3-stage check-in (انجام دادم / نیمه‌کاره / نشد → blocker chips → closed). **The reminder chain ends — `dueLast` says so explicitly; never nag indefinitely, and never frame "نشد" as failure.**
- [ ] Build **App feedback** (from the profile) as a surface separate from report feedback.
- [ ] Profile hosts the secondary surfaces (bookmarks, app feedback, history, dashboard) and confirms destructive actions with a sheet — never immediate.
- [ ] Paywall price card shows a **promotional price pair** (struck-through old price + current price) and an amber discount badge, all from real pricing config — with a no-promotion state that shows only the current price.
- [ ] Remove the dev page-map nav entirely.
- [ ] Build **Explore** as the logged-in home (test-picker cards for free + deep test, each with its own progress/limit state) and the **Free Test detail** page (stats, benefits, once-a-day limit state, last-result shortcut) — `homeScreen` still resolves to `landing` for anonymous visitors.
- [ ] Build the **step-tracking rebuild**: dashboard notification card as a 4-stage sequence (reminder → follow-up ask → blocker → closed) rather than a single due-card; a filterable pending-steps list with inline complete; and the new **Step History** screen (done/answered/needs-answer/blocker-ask branches, reactivate flow). Persist the step's full state machine server-side.
- [ ] Build the **current landing** from `Landing v2.dc.html` (§1a): photographic hero + scrim, plum accent, app-download links, interactive chat-moment tablist, step timeline, merged Deep-Test + trust section. Drop the mode switcher, the dead props, the empty Farablog section.
- [ ] Build the **Phase 5 report surfaces**: email-a-copy strip on both reports, the sticky in-report chat dock (clearing the tab bar + safe area), per-section 👍/👎 + seeded-chat action bars in the deep report, the closing explore block, and the chat empty state.


## Image-slot images
Images dropped into `<image-slot>` placeholders (`rv3-hero`, `rv3-strength`, `rv3-f1`, `rv3-f2`, `deep-cover`) are exported to `assets/slots/` (named by slot id). The same data is in `.image-slots.state.json` (hidden file, keep it next to `Faraman App.dc.html` to render them in the prototype). In production, replace each `<image-slot>` with an `<img>` using the matching file.
