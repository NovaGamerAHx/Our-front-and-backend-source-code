import type { Metadata } from "next";
import { TrackedLink } from "@/components/analytics/tracked-link";

export const metadata: Metadata = {
  title: "دربارهٔ فرامن",
  description:
    "فرامن یک آزمون کوتاه و یک گزارش شخصی است که به زبان ساده نوشته می‌شود — بدون برچسب و تیپ‌بندی، با یک قدم عملی برای همین امروز.",
};

const ABOUT_VALUES = [
  {
    title: "زبان ساده",
    body: "گزارش با جمله‌های روزمره نوشته می‌شود، نه اصطلاح‌های تخصصی.",
  },
  {
    title: "یک قدم عملی",
    body: "هر گزارش با یک کار کوچک و مشخص برای امروز تمام می‌شود.",
  },
  {
    title: "محرمانه",
    body: "پاسخ‌های شما فقط برای ساختن گزارش خودتان استفاده می‌شود.",
  },
];

export default function AboutPage() {
  return (
    <main className="mx-auto box-border flex w-full max-w-[880px] flex-col gap-8 px-7 pt-11 pb-[72px]">
      <div className="flex max-w-[620px] flex-col gap-3">
        <div className="text-text-faint text-xs font-extrabold tracking-[.04em]">دربارهٔ فرامن</div>
        <h1 className="text-[29px] leading-[1.6] font-extrabold text-pretty">
          شناخت خود، بدون واژه‌های سنگین
        </h1>
        <p className="text-[14px] leading-[2.1] text-pretty text-[#5D5C55]">
          فرامن یک آزمون کوتاه است و یک گزارش که به زبان خودتان نوشته می‌شود؛ به‌جای برچسب و تیپ‌بندی،
          یک قدم عملی برای همین امروز پیش می‌گذارد. همه‌چیز محرمانه است و فقط بر پایهٔ پاسخ‌های
          خودتان ساخته می‌شود.
        </p>
      </div>

      <div className="grid [grid-template-columns:repeat(auto-fit,minmax(220px,1fr))] gap-3.5">
        {ABOUT_VALUES.map((value) => (
          <div
            key={value.title}
            className="border-border flex flex-col gap-2.5 rounded-[20px] border bg-white p-[22px]"
          >
            <div className="text-[14.5px] font-extrabold">{value.title}</div>
            <div className="text-[12.5px] leading-[2] text-[#5D5C55]">{value.body}</div>
          </div>
        ))}
      </div>

      <div className="bg-primary-deep flex flex-wrap items-center justify-between gap-5 rounded-[24px] p-7">
        <div className="flex max-w-[420px] flex-col gap-[7px]">
          <div className="text-[17px] font-extrabold text-white">هنوز آزمون را ندادید؟</div>
          <div className="text-[12.5px] leading-[2] text-white/78">
            حدود ۷ دقیقه وقت می‌برد و گزارش اولیه بی‌درنگ آماده می‌شود.
          </div>
        </div>
        <TrackedLink
          event="start_test_clicked"
          href="/test"
          className="text-primary-deep min-h-11 rounded-full bg-white px-7 py-[15px] text-[13.5px] font-extrabold"
        >
          شروع آزمون
        </TrackedLink>
      </div>

      <div className="flex flex-col gap-2.5">
        <div className="text-[12.5px] font-extrabold">تماس با ما</div>
        <div className="text-[12.5px] leading-[2] text-[#5D5C55]">
          hello@faraman.ai
        </div>
      </div>
    </main>
  );
}
