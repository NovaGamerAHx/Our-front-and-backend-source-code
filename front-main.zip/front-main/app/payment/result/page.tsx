import { PaymentResultView } from "./_components/payment-result-view";

type PaymentResultPageProps = {
  searchParams: Promise<{ status?: string; attempt_id?: string }>;
};

export default async function PaymentResultPage({ searchParams }: PaymentResultPageProps) {
  const { status, attempt_id: rawAttemptId } = await searchParams;
  const normalized = status === "success" || status === "cancelled" ? status : "failed";
  const parsed = rawAttemptId ? Number(rawAttemptId) : NaN;
  const attemptId = Number.isInteger(parsed) && parsed > 0 ? parsed : undefined;

  return <PaymentResultView status={normalized} attemptId={attemptId} />;
}
