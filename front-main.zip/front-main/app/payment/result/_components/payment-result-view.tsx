"use client";

import { useEffect } from "react";
import Link from "next/link";
import { ComingSoonButton } from "@/components/report/coming-soon-button";
import { markEntitlementsStaleAction } from "../actions";

type PaymentStatus = "success" | "cancelled" | "failed";

type Copy = {
  icon: string;
  iconBg: string;
  title: string;
  body: string;
  primaryLabel: string;
  primaryHref: string;
};

// Pay-after-test: a payment unlocks one finished deep attempt's report, so every outcome points
// back at that attempt. Without an attempt id (an old link) they fall back to generic targets.
function copyFor(status: PaymentStatus, attemptId: number | undefined): Copy {
  const reportHref = attemptId !== undefined ? `/deep-report?attemptId=${attemptId}` : "/history";
  const paywallHref = attemptId !== undefined ? `/paywall?deepAttemptId=${attemptId}` : "/explore";

  if (status === "success") {
    return {
      icon: "✓",
      iconBg: "#E4F2EA",
      title: "پرداخت با موفقیت انجام شد",
      body: "گزارش کامل شما در حال ساخته شدن است. چند لحظه بعد آماده می‌شود.",
      primaryLabel: "دیدن گزارش",
      primaryHref: reportHref,
    };
  }
  if (status === "cancelled") {
    return {
      icon: "✓",
      iconBg: "#E9EBF8",
      title: "مشکلی نیست",
      body: "پاسخ‌های شما ذخیره شده‌اند و گزارشتان منتظر شماست. هر وقت خواستید، از همین‌جا بازش کنید.",
      primaryLabel: "بازگشت به گزارش",
      primaryHref: paywallHref,
    };
  }
  return {
    icon: "!",
    iconBg: "#F6E7E1",
    title: "پرداخت انجام نشد",
    body: "متأسفانه پرداخت شما با مشکل مواجه شد. پاسخ‌های شما همچنان ذخیره است و می‌توانید دوباره تلاش کنید.",
    primaryLabel: "تلاش مجدد",
    primaryHref: paywallHref,
  };
}

export function PaymentResultView({
  status,
  attemptId,
}: {
  status: PaymentStatus;
  attemptId?: number;
}) {
  const copy = copyFor(status, attemptId);

  // A successful purchase changed entitlements on the backend, but no Server Action ran on
  // the way here (see actions.ts) -- invalidate on mount so the buyer's next visit to
  // /paywall or /explore reflects it instead of showing the stale, unpaid state.
  useEffect(() => {
    if (status === "success") {
      void markEntitlementsStaleAction();
    }
  }, [status]);

  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-[390px] flex-col items-center justify-center gap-5 px-7 py-12 text-center">
      <div
        className="flex size-[60px] items-center justify-center rounded-[20px] text-[22px]"
        style={{ background: copy.iconBg }}
      >
        {copy.icon}
      </div>
      <div className="text-[17px] font-extrabold">{copy.title}</div>
      <p className="text-muted-foreground max-w-[280px] text-[13px] leading-[2]">{copy.body}</p>
      <Link
        href={copy.primaryHref}
        className="bg-primary flex min-h-11 w-full items-center justify-center rounded-2xl p-4 text-[15px] font-extrabold text-white"
      >
        {copy.primaryLabel}
      </Link>
      {status === "cancelled" && (
        <ComingSoonButton className="text-text-faint cursor-pointer text-[12px]">
          یادآوری برای بعد
        </ComingSoonButton>
      )}
    </main>
  );
}
