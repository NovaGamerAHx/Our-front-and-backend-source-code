"use server";

import { updateUserTag } from "@/lib/api/client";

/**
 * The Zarinpal callback is handled entirely by the backend, which redirects the browser
 * straight here -- no Server Action runs in that flow, so the cached entitlements list
 * (apiFetchCached, 5min revalidate) never gets invalidated on its own. Called from the
 * result view on mount so /paywall and /deep-test see the purchase immediately instead of
 * waiting out the cache window.
 */
export async function markEntitlementsStaleAction(): Promise<void> {
  await updateUserTag("entitlements");
}
