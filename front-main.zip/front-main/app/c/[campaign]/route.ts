import { type NextRequest, NextResponse } from "next/server";
import { APP_URL } from "@/lib/api/constants";

/**
 * Campaign short links: /c/<campaign>
 *
 * One short URL per campaign that lands on the free-test intro page with the UTM pair the
 * analytics funnel needs. Examples:
 *
 *   https://faraman.ai/c/kaaf_channel_newdsgn                      -> /test?utm_source=telegram&utm_campaign=kaaf_channel_newdsgn
 *   https://faraman.ai/c/kaaf_channel_newdsgn?s=instagram          -> /test?utm_source=instagram&utm_campaign=kaaf_channel_newdsgn
 *   https://faraman.ai/c/kaaf_channel_newdsgn?s=sms&m=conversational -> adds utm_medium
 *
 * Why the redirect lives here (not in next.config's static `redirects()` map): that map needs one
 * hardcoded entry per campaign, so every new campaign needs a deploy. This route handler reads the
 * campaign straight from the path, so a new campaign only needs a new URL.
 *
 * The destination is /test (the free-test intro). The landing page's UtmCapture component then
 * stores utm_source/utm_campaign in the `faraman_utm` cookie for 30 days, which is what
 * trackEventAction attaches to every later event and what requestOtpAction sends at signup (the
 * backend stores both on the User row on first touch).
 *
 * `source` query param (`s`) defaults to "telegram" — the paid campaigns all run there. Anything
 * that isn't a slug-safe token is dropped rather than forwarded, so a crafted link can't inject
 * arbitrary text into the analytics columns.
 */

const MAX_VALUE_LENGTH = 100;
const SLUG = /^[a-z0-9][a-z0-9_-]*$/;

function clean(raw: string | null | undefined): string {
  const value = (raw ?? "").trim().toLowerCase().slice(0, MAX_VALUE_LENGTH);
  return SLUG.test(value) ? value : "";
}

export async function GET(request: NextRequest, { params }: { params: Promise<{ campaign: string }> }) {
  const { campaign: rawCampaign } = await params;
  const campaign = clean(rawCampaign);
  const source = clean(request.nextUrl.searchParams.get("s")) || "telegram";
  const medium = clean(request.nextUrl.searchParams.get("m"));

  // No campaign in the path -> plain /test. Nothing to attribute, so don't fabricate one.
  if (!campaign) return NextResponse.redirect(new URL("/test", APP_URL));

  const target = new URL("/test", APP_URL);
  target.searchParams.set("utm_source", source);
  target.searchParams.set("utm_campaign", campaign);
  if (medium) target.searchParams.set("utm_medium", medium);

  // 307: keeps the GET semantics and stops intermediary caches from pinning one campaign's
  // destination for the next visitor (301 would be cached).
  return NextResponse.redirect(target, 307);
}
