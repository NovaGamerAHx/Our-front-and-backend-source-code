"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { Bookmark, ChevronLeft, MessageSquare, LogOut, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { toPersianDigits } from "@/lib/utils/digits";
import { currentJalaliYear } from "@/lib/utils/date";
import { isProfileComplete } from "@/lib/utils/profile";
import {
  GENDER_OPTIONS,
  GOAL_OPTIONS,
  LIFE_SITUATION_OPTIONS,
} from "@/lib/constants/demographic-options";
import type { Profile } from "@/lib/api/schemas";
import { deleteAccountAction, logoutAction, updateProfileAction } from "../actions";
import { useSheetDrag } from "@/components/ui/use-sheet-drag";
import { Spinner } from "@/components/ui/spinner";

const MIN_AGE = 12;
const MAX_AGE = 90;
const TOTAL_COMPLETENESS_FIELDS = 4;

type FieldKey = "name" | "gender" | "birth_year" | "life_situation" | "goal";

type FieldDef =
  | {
      key: FieldKey;
      label: string;
      countsTowardCompleteness: boolean;
      kind: "text";
      placeholder: string;
      hint: string;
    }
  | { key: FieldKey; label: string; countsTowardCompleteness: boolean; kind: "year" }
  | {
      key: FieldKey;
      label: string;
      countsTowardCompleteness: boolean;
      kind: "choice";
      options: { value: string; label: string }[];
    };

const FIELD_DEFS: FieldDef[] = [
  {
    key: "name",
    label: "نام",
    kind: "text",
    countsTowardCompleteness: false,
    placeholder: "نامت را بنویس",
    hint: "نامی که در گفتگوها و گزارش‌ها با آن خطابت می‌کنیم. می‌توانی نام مستعار بگذاری.",
  },
  { key: "gender", label: "جنسیت", kind: "choice", countsTowardCompleteness: true, options: GENDER_OPTIONS },
  { key: "birth_year", label: "سال تولد", kind: "year", countsTowardCompleteness: true },
  {
    key: "life_situation",
    label: "وضعیت زندگی",
    kind: "choice",
    countsTowardCompleteness: true,
    options: LIFE_SITUATION_OPTIONS,
  },
  { key: "goal", label: "هدف فعلی", kind: "choice", countsTowardCompleteness: true, options: GOAL_OPTIONS },
];

function displayValue(def: FieldDef, profile: Profile): { text: string; filled: boolean } {
  const raw = profile[def.key];
  if (raw === null || raw === undefined) {
    return { text: def.kind === "text" ? def.placeholder : "انتخاب کن", filled: false };
  }
  if (def.kind === "year") return { text: toPersianDigits(raw as number), filled: true };
  if (def.kind === "choice") {
    const option = def.options.find((o) => o.value === raw);
    return { text: option?.label ?? String(raw), filled: true };
  }
  return { text: String(raw), filled: true };
}

function rowClass() {
  return "flex min-h-11 w-full cursor-pointer items-center gap-3 px-[18px] py-[15px] text-right";
}

type ConfirmKind = "logout" | "delete";

const CONFIRM_CONFIG: Record<
  ConfirmKind,
  { title: string; message: string; confirmLabel: string; icon: typeof LogOut; danger: boolean }
> = {
  logout: {
    title: "خروج از حساب",
    message: "مطمئنی می‌خواهی از حساب کاربری‌ات خارج شوی؟",
    confirmLabel: "خروج از حساب",
    icon: LogOut,
    danger: false,
  },
  delete: {
    title: "حذف حساب و داده‌ها",
    message:
      "با حذف حساب، گزارش‌ها، پیام‌های نشان‌شده و همهٔ داده‌های تو برای همیشه پاک می‌شوند. این کار غیرقابل بازگشت است.",
    confirmLabel: "حذف حساب",
    icon: Trash2,
    danger: true,
  },
};

export function ProfileView({ profile: initialProfile }: { profile: Profile }) {
  const [profile, setProfile] = useState(initialProfile);
  const [activeField, setActiveField] = useState<FieldDef | null>(null);
  const [draft, setDraft] = useState("");
  const [isPending, startTransition] = useTransition();
  const [confirmKind, setConfirmKind] = useState<ConfirmKind | null>(null);
  const [isLoggingOut, startLogout] = useTransition();
  const [isDeleting, startDelete] = useTransition();
  const { sheetRef, sheetStyle, sheetProps, handleProps } = useSheetDrag<HTMLFormElement>(closeSheet);

  function handleConfirm() {
    if (confirmKind === "logout") {
      startLogout(async () => {
        await logoutAction();
      });
      return;
    }
    if (confirmKind === "delete") {
      startDelete(async () => {
        const result = await deleteAccountAction();
        if (!result.ok) {
          toast.error(result.message);
          setConfirmKind(null);
        }
      });
    }
  }

  const filled = FIELD_DEFS.filter(
    (def) => def.countsTowardCompleteness && displayValue(def, profile).filled,
  ).length;
  const incomplete = !isProfileComplete(profile);
  const pct = Math.round((filled / TOTAL_COMPLETENESS_FIELDS) * 100);

  const nowYear = currentJalaliYear();
  const years = Array.from({ length: MAX_AGE - MIN_AGE + 1 }, (_, i) => nowYear - MIN_AGE - i);

  function openSheet(def: FieldDef) {
    const raw = profile[def.key];
    setDraft(raw === null || raw === undefined ? "" : String(raw));
    setActiveField(def);
  }

  function closeSheet() {
    setActiveField(null);
    setDraft("");
  }

  function confirm() {
    if (!activeField || !draft.trim() || isPending) return;
    const field = activeField;

    startTransition(async () => {
      const value = field.kind === "year" ? Number(draft) : field.kind === "text" ? draft.trim() : draft;
      const patch = { [field.key]: value };
      const result = await updateProfileAction(patch);
      if (!result.ok) {
        toast.error(result.message);
        return;
      }
      setProfile(result.data);
      closeSheet();
    });
  }

  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col gap-[22px] px-[22px] pt-5 pb-12">
      <div className="flex items-center gap-3">
        <Link
          href="/dashboard"
          className="border-border text-muted-foreground bg-card grid size-10 place-items-center rounded-xl border text-base"
        >
          →
        </Link>
        <div className="text-[16px] font-extrabold">حساب کاربری</div>
      </div>

      <div className="flex items-center gap-3.5 px-0.5 pb-1">
        <div
          className="grid size-[58px] flex-none place-items-center rounded-full text-[22px] font-extrabold text-white"
          style={{ background: "linear-gradient(135deg,#2743C6,#8E6BA8)" }}
        >
          {(profile.name ?? "ف").trim().charAt(0)}
        </div>
        <div className="flex min-w-0 flex-col gap-0.5">
          <div className="text-[18px] font-extrabold">{profile.name || "مهمان"}</div>
          <div dir="ltr" className="text-text-faint text-xs">
            {profile.phone_number}
          </div>
        </div>
      </div>

      {incomplete && (
        <div className="border-lavender-border flex flex-col gap-2.5 rounded-2xl border bg-gradient-to-br from-[#F3F1FA] to-[#F7F3F1] px-[18px] py-4">
          <div className="flex items-center justify-between gap-2.5">
            <div className="text-lavender-text text-[13.5px] font-extrabold">پروفایلت را کامل‌تر کن</div>
            <div className="text-purple-accent bg-card rounded-full px-2.5 py-[3px] text-[11.5px] font-extrabold">
              {toPersianDigits(filled)} از {toPersianDigits(TOTAL_COMPLETENESS_FIELDS)}
            </div>
          </div>
          <div className="border-lavender-border h-[7px] overflow-hidden rounded-full bg-[#E4E0F2]">
            <div
              className="h-full rounded-full transition-[width] duration-[450ms] ease-out"
              style={{ width: `${pct}%`, background: "linear-gradient(90deg,#8E6BA8,#B08FCB)" }}
            />
          </div>
          <div className="text-[11.5px] leading-[1.85] text-[#7A72A8]">
            هرچه بیشتر از خودت بگویی، بهتر می‌توانیم همراهی‌ات کنیم. تکمیل این بخش‌ها کاملاً اختیاری
            است.
          </div>
        </div>
      )}

      <div className="flex flex-col gap-2.5">
        <div className="text-text-faint px-1 text-[11.5px] font-extrabold tracking-wide">
          مشخصات من
        </div>
        <div className="border-border bg-card divide-border divide-y overflow-hidden rounded-2xl border">
          {FIELD_DEFS.map((def) => {
            const { text, filled: fieldFilled } = displayValue(def, profile);
            return (
              <button key={def.key} type="button" onClick={() => openSheet(def)} className={rowClass()}>
                <span className={`size-[7px] flex-none rounded-full ${fieldFilled ? "bg-primary" : "bg-border"}`} />
                <span className="flex-none text-[14px] font-bold">{def.label}</span>
                <span
                  className={`flex-1 truncate text-left text-[13.5px] ${
                    fieldFilled ? "text-primary font-bold" : "text-text-faint font-semibold"
                  }`}
                >
                  {text}
                </span>
                <ChevronLeft size={18} strokeWidth={2.5} className="text-muted-foreground flex-none" />
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex flex-col gap-2.5">
        <div className="text-text-faint px-1 text-[11.5px] font-extrabold tracking-wide">
          فعالیت من
        </div>
        <div className="border-border bg-card overflow-hidden rounded-2xl border">
          <Link href="/profile/bookmarks" className={rowClass()}>
            <span className="bg-purple-tint grid size-[34px] flex-none place-items-center rounded-[11px]">
              <Bookmark size={17} strokeWidth={2} className="text-purple-accent" />
            </span>
            <span className="flex-1 text-[14px] font-bold">پیام‌های نشان‌شده</span>
            <ChevronLeft size={18} strokeWidth={2.5} className="text-muted-foreground flex-none" />
          </Link>
        </div>
      </div>

      <div className="flex flex-col gap-2.5">
        <div className="text-text-faint px-1 text-[11.5px] font-extrabold tracking-wide">بازخورد</div>
        <Link
          href="/profile/feedback"
          className={`${rowClass()} border-border bg-card rounded-2xl border`}
        >
          <span className="bg-secondary grid size-[34px] flex-none place-items-center rounded-[11px]">
            <MessageSquare size={17} strokeWidth={2} className="text-primary" />
          </span>
          <span className="flex flex-1 flex-col gap-0.5">
            <span className="text-[14px] font-bold">نظر بده و به بهبود فرامن کمک کن</span>
            <span className="text-text-faint text-[11px] leading-[1.6]">
              هر پیشنهاد یا ایرادی که دیدی برایمان بنویس
            </span>
          </span>
          <ChevronLeft size={18} strokeWidth={2.5} className="text-muted-foreground flex-none" />
        </Link>
      </div>

      <div className="flex flex-col gap-2.5">
        <div className="text-text-faint px-1 text-[11.5px] font-extrabold tracking-wide">حساب</div>
        <div className="border-border bg-card divide-border divide-y overflow-hidden rounded-2xl border">
          <button type="button" onClick={() => setConfirmKind("logout")} className={rowClass()}>
            <LogOut size={18} strokeWidth={2} className="text-muted-foreground flex-none" />
            <span className="flex-1 text-[14px] font-bold">خروج از حساب</span>
            <ChevronLeft size={18} strokeWidth={2.5} className="text-muted-foreground flex-none" />
          </button>
          <button type="button" onClick={() => setConfirmKind("delete")} className={rowClass()}>
            <Trash2 size={18} strokeWidth={2} className="text-destructive flex-none" />
            <span className="text-destructive flex-1 text-[14px] font-bold">حذف حساب و داده‌ها</span>
            <ChevronLeft size={18} strokeWidth={2.5} className="text-destructive flex-none" />
          </button>
        </div>
        <div className="text-[10.5px] leading-[1.7] text-[#B7B2A4] px-1">
          با حذف حساب، گزارش‌ها، پیام‌های نشان‌شده و همهٔ داده‌های تو برای همیشه پاک می‌شوند.
        </div>
      </div>

      {confirmKind &&
        (() => {
          const config = CONFIRM_CONFIG[confirmKind];
          const Icon = config.icon;
          const isBusy = isLoggingOut || isDeleting;
          return (
            <div className="fixed inset-0 z-50 flex items-center justify-center px-6" dir="rtl">
              <div
                onClick={() => !isBusy && setConfirmKind(null)}
                className="animate-fm-fade absolute inset-0 bg-[rgba(30,26,20,.42)]"
              />
              <div className="animate-fm-in border-border bg-card relative flex w-full max-w-[360px] flex-col items-center gap-4 rounded-[22px] border p-7 text-center shadow-[0_12px_40px_rgba(40,30,10,.18)]">
                <span
                  className={`grid size-14 place-items-center rounded-full ${
                    config.danger ? "bg-danger-tint text-destructive" : "bg-secondary text-primary"
                  }`}
                >
                  <Icon size={24} strokeWidth={2} />
                </span>
                <div className="flex flex-col gap-2">
                  <div className="text-[16px] font-extrabold">{config.title}</div>
                  <p className="text-muted-foreground text-[13px] leading-[1.95]">{config.message}</p>
                </div>
                <div className="mt-1 flex w-full flex-col gap-2.5">
                  <button
                    type="button"
                    onClick={handleConfirm}
                    disabled={isBusy}
                    className={`flex min-h-11 cursor-pointer items-center justify-center gap-2.5 rounded-2xl p-3.5 text-[14px] font-extrabold text-white transition-opacity disabled:cursor-not-allowed disabled:opacity-75 ${
                      config.danger ? "bg-destructive" : "bg-primary"
                    }`}
                  >
                    {isBusy && <Spinner />}
                    {confirmKind === "logout" && isLoggingOut
                      ? "در حال خروج…"
                      : confirmKind === "delete" && isDeleting
                        ? "در حال حذف…"
                        : config.confirmLabel}
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmKind(null)}
                    disabled={isBusy}
                    className="border-border text-muted-foreground min-h-11 cursor-pointer rounded-2xl border-[1.5px] bg-white p-3.5 text-[13.5px] font-bold disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    انصراف
                  </button>
                </div>
              </div>
            </div>
          );
        })()}

      {activeField && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-end" dir="rtl">
          <div onClick={closeSheet} className="animate-fm-fade absolute inset-0 bg-[rgba(30,26,20,.42)]" />
          <form
            ref={sheetRef}
            onSubmit={(e) => {
              e.preventDefault();
              confirm();
            }}
            {...sheetProps}
            className="animate-fm-sheet relative flex w-full max-w-[440px] flex-col rounded-t-[26px] bg-card px-[22px] pt-[10px] pb-[24px] shadow-[0_-12px_40px_rgba(40,30,10,.18)]"
            style={{ maxHeight: "min(560px, 82vh)", ...sheetStyle }}
          >
            <div {...handleProps} className="-mx-[22px] mb-3.5 flex cursor-grab justify-center py-2 active:cursor-grabbing">
              <div className="h-[5px] w-[42px] rounded-full bg-[#E7E2D6]" />
            </div>
            <div className="flex items-center justify-between border-b border-[#F1ECE2] pb-3.5">
              <div className="text-[16px] font-extrabold">{activeField.label}</div>
              <button
                type="button"
                onClick={closeSheet}
                className="text-text-faint grid size-[30px] cursor-pointer place-items-center rounded-lg text-base"
              >
                ✕
              </button>
            </div>

            <div className="flex flex-col gap-3.5 overflow-y-auto pt-[18px] pb-1.5">
              {activeField.kind === "text" && (
                <div className="flex flex-col gap-3">
                  <input
                    autoFocus
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    placeholder={activeField.placeholder}
                    className="rounded-t-xl border-0 border-b-2 border-primary bg-[#FAF8F3] px-4 py-[15px] text-[16px] font-bold outline-none"
                  />
                  <p className="text-[12px] leading-[1.9] text-[#8B8676]">{activeField.hint}</p>
                </div>
              )}

              {activeField.kind === "year" && (
                <div
                  className="flex max-h-[210px] flex-col gap-1 overflow-y-auto p-1"
                  style={{
                    maskImage:
                      "linear-gradient(180deg, transparent, #000 22%, #000 78%, transparent)",
                    WebkitMaskImage:
                      "linear-gradient(180deg, transparent, #000 22%, #000 78%, transparent)",
                  }}
                >
                  {years.map((year) => {
                    const selected = draft === String(year);
                    return (
                      <button
                        key={year}
                        type="button"
                        onClick={() => setDraft(String(year))}
                        className={`cursor-pointer rounded-xl p-3 text-center transition-all duration-[120ms] ${
                          selected
                            ? "bg-primary text-[18px] font-extrabold text-white"
                            : "text-[15px] font-semibold text-[#8B8676]"
                        }`}
                      >
                        {toPersianDigits(year)}
                      </button>
                    );
                  })}
                </div>
              )}

              {activeField.kind === "choice" && (
                <div className="flex flex-col gap-[9px]">
                  {activeField.options.map((option) => {
                    const selected = draft === option.value;
                    return (
                      <button
                        key={option.value}
                        type="button"
                        onClick={() => setDraft(option.value)}
                        className={`flex min-h-11 cursor-pointer items-center gap-3 rounded-[14px] border-[1.5px] px-4 py-[15px] text-right transition-all duration-[130ms] ${
                          selected ? "border-primary bg-[#F0F2FC]" : "border-border bg-card"
                        }`}
                      >
                        <span
                          className={`grid size-5 flex-none place-items-center rounded-full border-2 ${
                            selected ? "border-primary" : "border-[#CFC8BC]"
                          }`}
                        >
                          <span className={`size-2.5 rounded-full ${selected ? "bg-primary" : ""}`} />
                        </span>
                        <span
                          className={`flex-1 text-sm ${
                            selected ? "text-primary font-extrabold" : "font-semibold text-[#3C4150]"
                          }`}
                        >
                          {option.label}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={!draft.trim() || isPending}
              className="bg-primary mt-4 flex min-h-[52px] cursor-pointer items-center justify-center gap-2.5 rounded-2xl p-4 text-[15.5px] font-extrabold text-white transition-opacity disabled:cursor-not-allowed disabled:opacity-40"
            >
              {isPending && <Spinner />}
              ذخیره
            </button>
          </form>
        </div>
      )}
    </main>
  );
}
