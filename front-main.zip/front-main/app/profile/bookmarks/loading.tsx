import { Sk } from "@/components/ui/skeleton";

// Instant fallback for پیام‌های نشان‌شده while bookmarks are fetched.
export default function BookmarksLoading() {
  return (
    <main className="mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col gap-5 px-[22px] pt-5 pb-12">
      <div className="flex items-center gap-3">
        <Sk className="size-10 rounded-xl" />
        <Sk className="h-4 w-32" />
      </div>

      <div className="flex flex-col gap-2.5">
        {[0, 1, 2].map((i) => (
          <Sk key={i} className="h-[108px] w-full rounded-2xl" />
        ))}
      </div>
    </main>
  );
}
