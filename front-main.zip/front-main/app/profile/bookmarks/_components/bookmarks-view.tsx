import Link from "next/link";
import { Bookmark } from "lucide-react";
import { formatJalali } from "@/lib/utils/date";
import type { BookmarkedMessage } from "@/lib/api/schemas";

function BookmarkRow({ item }: { item: BookmarkedMessage }) {
  return (
    <div className="border-border flex flex-col gap-[11px] rounded-2xl border bg-white px-[17px] py-4">
      <p className="text-pretty text-[13px] leading-[2] text-[#3C4150]">{item.content}</p>
      <div className="flex items-center justify-between gap-2">
        <span className="bg-purple-tint text-lavender-text rounded-full px-2.5 py-1 text-[10px] font-extrabold">
          گفتگو
        </span>
        <span className="text-[10.5px] text-[#B7B2A4]">{formatJalali(item.bookmarked_at)}</span>
      </div>
    </div>
  );
}

export function BookmarksView({ items }: { items: BookmarkedMessage[] }) {
  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col gap-5 px-[22px] pt-5 pb-12">
      <div className="flex items-center gap-3">
        <Link
          href="/profile"
          className="border-border text-muted-foreground bg-card grid size-10 flex-none place-items-center rounded-xl border text-base"
        >
          →
        </Link>
        <div className="text-[16px] font-extrabold text-[#242A38]">
          جمله‌هایی که از گزارش‌ها و گفتگوها نشان کرده‌ای، این‌جاست
        </div>
      </div>

      {items.length > 0 ? (
        <div className="flex flex-col gap-2.5">
          {items.map((item) => (
            <BookmarkRow key={item.message_id} item={item} />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center gap-3.5 pt-16 text-center">
          <div className="bg-purple-tint grid size-[60px] place-items-center rounded-[18px]">
            <Bookmark size={24} strokeWidth={1.8} className="text-purple-accent" />
          </div>
          <div className="text-[16px] font-extrabold">هنوز چیزی نشان نکرده‌ای</div>
          <p className="text-muted-foreground max-w-[260px] text-[12.5px] leading-[1.9]">
            هر جمله‌ای در گزارش یا گفتگو که برایت مهم بود را نشان کن تا این‌جا ذخیره شود.
          </p>
        </div>
      )}
    </main>
  );
}
