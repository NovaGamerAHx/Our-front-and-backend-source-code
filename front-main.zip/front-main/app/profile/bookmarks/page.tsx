import Link from "next/link";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { ACCESS_TOKEN_COOKIE } from "@/lib/api/constants";
import { ApiError } from "@/lib/api/client";
import { getBookmarkedMessages } from "@/lib/api/endpoints";
import { BookmarksView } from "./_components/bookmarks-view";

export default async function BookmarksPage() {
  const store = await cookies();
  if (!store.has(ACCESS_TOKEN_COOKIE)) {
    redirect(`/login?${new URLSearchParams({ next: "/profile/bookmarks" }).toString()}`);
  }

  let items;
  try {
    items = await getBookmarkedMessages();
  } catch (error) {
    if (error instanceof ApiError && error.status === 401) {
      redirect(`/login?${new URLSearchParams({ next: "/profile/bookmarks" }).toString()}`);
    }
    const message = error instanceof ApiError ? error.message : "پیام‌های نشان‌شده در دسترس نیست.";
    return (
      <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[390px] flex-col items-center justify-center gap-4 px-7 text-center">
        <div className="bg-danger-tint text-danger-text grid size-[72px] place-items-center rounded-full text-2xl">
          !
        </div>
        <h1 className="text-lg font-extrabold">پیام‌های نشان‌شده در دسترس نیست</h1>
        <p className="text-muted-foreground max-w-[280px] text-[13px] leading-[2]">{message}</p>
        <Link
          href="/profile"
          className="bg-primary hover:bg-primary/90 min-h-11 w-full rounded-2xl p-4 text-center text-[15px] font-extrabold text-white"
        >
          بازگشت به پروفایل
        </Link>
      </main>
    );
  }

  return <BookmarksView items={items} />;
}
