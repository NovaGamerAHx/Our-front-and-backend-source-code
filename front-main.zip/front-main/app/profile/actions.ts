"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { ACCESS_TOKEN_COOKIE, REFRESH_TOKEN_COOKIE } from "@/lib/api/constants";
import { ApiError } from "@/lib/api/client";
import { deleteAccount, logout, updateProfile } from "@/lib/api/endpoints";
import type { PatchedProfileInput, Profile } from "@/lib/api/schemas";

type UpdateProfileResult =
  | { ok: true; data: Profile }
  | { ok: false; message: string };

type DeleteAccountResult = { ok: true } | { ok: false; message: string };

const GENERIC_ERROR = "به‌روزرسانی با خطا مواجه شد. لطفاً دوباره تلاش کنید.";
const DELETE_ACCOUNT_GENERIC_ERROR = "حذف حساب با خطا مواجه شد. لطفاً دوباره تلاش کنید.";

export async function updateProfileAction(
  input: PatchedProfileInput,
): Promise<UpdateProfileResult> {
  try {
    return { ok: true, data: await updateProfile(input) };
  } catch (error) {
    return { ok: false, message: error instanceof ApiError ? error.message : GENERIC_ERROR };
  }
}

export async function logoutAction() {
  const store = await cookies();
  const refresh = store.get(REFRESH_TOKEN_COOKIE)?.value;

  if (refresh) {
    try {
      await logout(refresh);
    } catch {
      // Blacklisting server-side is best-effort — still clear local cookies below.
    }
  }

  store.delete(ACCESS_TOKEN_COOKIE);
  store.delete(REFRESH_TOKEN_COOKIE);
  redirect("/");
}

export async function deleteAccountAction(): Promise<DeleteAccountResult> {
  try {
    await deleteAccount();
  } catch (error) {
    return {
      ok: false,
      message: error instanceof ApiError ? error.message : DELETE_ACCOUNT_GENERIC_ERROR,
    };
  }

  const store = await cookies();
  store.delete(ACCESS_TOKEN_COOKIE);
  store.delete(REFRESH_TOKEN_COOKIE);
  redirect("/");
}
