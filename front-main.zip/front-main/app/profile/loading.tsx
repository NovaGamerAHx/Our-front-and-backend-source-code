import { Sk } from "@/components/ui/skeleton";

// Instant fallback for پروفایل while getProfile() resolves.
export default function ProfileLoading() {
  return (
    <main className="mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col gap-[22px] px-[22px] pt-5 pb-12">
      <div className="flex items-center gap-3">
        <Sk className="size-10 rounded-xl" />
        <Sk className="h-4 w-24" />
      </div>

      <div className="flex items-center gap-4">
        <Sk className="size-16 rounded-full" />
        <div className="flex flex-1 flex-col gap-2">
          <Sk className="h-5 w-32" />
          <Sk className="h-3.5 w-24" />
        </div>
      </div>

      <Sk className="h-[92px] w-full rounded-2xl" />

      <div className="flex flex-col gap-2.5">
        {[0, 1, 2, 3].map((i) => (
          <Sk key={i} className="h-14 w-full rounded-2xl" />
        ))}
      </div>

      <div className="mt-2 flex flex-col gap-2.5">
        <Sk className="h-12 w-full rounded-2xl" />
        <Sk className="h-12 w-full rounded-2xl" />
      </div>
    </main>
  );
}
