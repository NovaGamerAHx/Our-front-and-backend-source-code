import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { ACCESS_TOKEN_COOKIE } from "@/lib/api/constants";
import { ApiError } from "@/lib/api/client";
import { getProfile } from "@/lib/api/endpoints";
import { ProfileView } from "./_components/profile-view";

export default async function ProfilePage() {
  const store = await cookies();
  const loginRedirect = `/login?${new URLSearchParams({ next: "/profile" }).toString()}`;
  if (!store.has(ACCESS_TOKEN_COOKIE)) {
    redirect(loginRedirect);
  }

  const profile = await getProfile().catch((error) => {
    if (error instanceof ApiError && error.status === 401) {
      redirect(loginRedirect);
    }
    throw error;
  });

  return <ProfileView profile={profile} />;
}
