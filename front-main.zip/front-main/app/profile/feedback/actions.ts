"use server";

import { ApiError } from "@/lib/api/client";
import { submitFeedback } from "@/lib/api/endpoints";

type ActionResult = { ok: true } | { ok: false; message: string };

const GENERIC_ERROR = "ثبت نظر با خطا مواجه شد. لطفاً دوباره تلاش کنید.";

export async function submitAppFeedbackAction(rating: number, comment: string): Promise<ActionResult> {
  try {
    await submitFeedback({
      target_type: "app",
      target_id: "app",
      rate: rating,
      reason: "",
      comment,
    });
    return { ok: true };
  } catch (error) {
    return { ok: false, message: error instanceof ApiError ? error.message : GENERIC_ERROR };
  }
}
