import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { ACCESS_TOKEN_COOKIE } from "@/lib/api/constants";
import { TrackOnMount } from "@/components/analytics/track-on-mount";
import { AppFeedbackView } from "./_components/app-feedback-view";

export default async function AppFeedbackPage() {
  const store = await cookies();
  if (!store.has(ACCESS_TOKEN_COOKIE)) {
    const params = new URLSearchParams({ next: "/profile/feedback" });
    redirect(`/login?${params.toString()}`);
  }

  return (
    <>
      <TrackOnMount event="feedback_form_opened" properties={{ target_type: "app" }} />
      <AppFeedbackView />
    </>
  );
}
