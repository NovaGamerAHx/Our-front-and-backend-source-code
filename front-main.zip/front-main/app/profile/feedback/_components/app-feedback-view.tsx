"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { toast } from "sonner";
import { Spinner } from "@/components/ui/spinner";
import { submitAppFeedbackAction } from "../actions";

const RATING_VALUES = [1, 2, 3, 4, 5];
const RATING_LABELS = ["", "اصلاً راضی نبودم", "می‌تواند بهتر باشد", "خوب بود", "خیلی خوب بود", "عالی بود!"];

export function AppFeedbackView() {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [isPending, startTransition] = useTransition();

  const canSubmit = rating > 0 && !isPending;

  function submit() {
    if (!canSubmit) return;
    startTransition(async () => {
      const result = await submitAppFeedbackAction(rating, comment.trim());
      if (!result.ok) {
        toast.error(result.message);
        return;
      }
      setSubmitted(true);
    });
  }

  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col gap-[26px] px-[22px] pt-5 pb-12">
      <div className="flex items-center gap-3">
        <Link
          href="/profile"
          className="border-border text-muted-foreground bg-card grid size-10 place-items-center rounded-xl border text-base"
        >
          →
        </Link>
        <div className="text-[16px] font-extrabold">نظر شما</div>
      </div>

      {submitted ? (
        <div className="animate-fm-in flex flex-col items-center gap-4 pt-14 text-center">
          <div className="bg-success-tint text-success grid size-[72px] place-items-center rounded-full text-[28px]">
            ✓
          </div>
          <div className="text-xl font-extrabold">ممنون از شما</div>
          <p className="text-muted-foreground max-w-[300px] text-[13.5px] leading-[2]">
            نظرت ثبت شد. همین بازخوردهاست که فرامن را بهتر می‌کند.
          </p>
          <Link
            href="/profile"
            className="border-border bg-card min-h-11 rounded-2xl border-[1.5px] px-8 py-3.5 text-[14px] font-bold"
          >
            بازگشت به حساب کاربری
          </Link>
        </div>
      ) : (
        <>
          <div className="flex flex-col gap-2">
            <h1 className="text-[22px] leading-[1.6] font-extrabold text-pretty">
              به ما کمک کنید فرامن را بهتر کنیم
            </h1>
            <p className="text-text-faint text-[13.5px] leading-[1.95]">
              نظرهای شما برای ما بسیار ارزشمند است.
            </p>
          </div>

          <div className="flex flex-col gap-3">
            <div className="text-[13.5px] font-extrabold">تجربه‌ات از فرامن چطور بوده؟</div>
            <div className="flex justify-center gap-1.5">
              {RATING_VALUES.map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setRating(value)}
                  className="grid h-[52px] w-12 cursor-pointer place-items-center bg-transparent text-[38px] leading-none transition-all duration-[120ms]"
                  style={{
                    color: value <= rating ? "#E8A93B" : "#E7E2D6",
                    transform: value <= rating ? "scale(1.08)" : "scale(1)",
                  }}
                >
                  ★
                </button>
              ))}
            </div>
            <div className="text-purple-accent min-h-4 text-center text-xs font-bold">
              {RATING_LABELS[rating]}
            </div>
          </div>

          <div className="flex flex-col gap-2.5">
            <div className="text-[13.5px] font-extrabold">
              نظرت را بنویس <span className="text-text-faint font-medium">(اختیاری)</span>
            </div>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="چه چیزی را دوست داشتی؟ چه چیزی می‌تواند بهتر شود؟"
              rows={4}
              className="border-border focus:border-primary rounded-2xl border-[1.5px] bg-card px-4 py-3.5 text-[13.5px] leading-[2] outline-none resize-none"
            />
          </div>

          <button
            type="button"
            onClick={submit}
            disabled={!canSubmit}
            className={`mt-auto flex min-h-11 items-center justify-center gap-2.5 rounded-2xl p-[17px] text-[16px] font-extrabold text-white transition-colors disabled:cursor-not-allowed ${
              canSubmit ? "bg-primary hover:bg-primary/90 cursor-pointer" : isPending ? "bg-primary opacity-75" : "bg-disabled"
            }`}
          >
            {isPending && <Spinner />}
            {isPending ? "در حال ارسال…" : "ارسال نظر"}
          </button>
        </>
      )}
    </main>
  );
}
