import { FIREBASE_CONFIG } from "@/lib/api/constants";

// Served at /firebase-messaging-sw.js -- the exact path Firebase's web SDK looks for by default.
// A dynamic route rather than a static public/ file so it can embed the same config the main
// app uses (same pattern as app/manifest.ts), instead of a hardcoded copy that could drift.
//
// This is also the only service worker registered for the site (see
// components/push/register-service-worker.tsx), so the offline-fallback cache lives here too --
// a second SW at the same scope would fight this one for control of fetch events.
const OFFLINE_CACHE = "offline-v1";
const OFFLINE_URL = "/offline.html";

export async function GET() {
  const body = `
    importScripts("https://www.gstatic.com/firebasejs/10.14.1/firebase-app-compat.js");
    importScripts("https://www.gstatic.com/firebasejs/10.14.1/firebase-messaging-compat.js");

    firebase.initializeApp(${JSON.stringify(FIREBASE_CONFIG)});
    const messaging = firebase.messaging();

    messaging.onBackgroundMessage((payload) => {
      // Backend sends data-only messages (see push_sender.py) precisely so this handler is
      // the single source of truth for what's displayed -- a top-level \`notification\`
      // payload would make the browser auto-display its own notification too, doubling it.
      const { title, body, url } = payload.data ?? {};
      self.registration.showNotification(title ?? "فرامن", {
        body,
        icon: "/icons/icon-192.png",
        data: { url },
      });
    });

    self.addEventListener("notificationclick", (event) => {
      event.notification.close();
      const url = event.notification.data && event.notification.data.url;
      if (!url) return;
      event.waitUntil(
        clients.matchAll({ type: "window" }).then((clientList) => {
          for (const client of clientList) {
            if (client.url.includes(url) && "focus" in client) return client.focus();
          }
          return clients.openWindow(url);
        }),
      );
    });

    self.addEventListener("install", (event) => {
      self.skipWaiting();
      event.waitUntil(caches.open("${OFFLINE_CACHE}").then((cache) => cache.add("${OFFLINE_URL}")));
    });

    self.addEventListener("activate", (event) => {
      event.waitUntil(clients.claim());
    });

    self.addEventListener("fetch", (event) => {
      if (event.request.mode !== "navigate") return;
      event.respondWith(
        fetch(event.request).catch(() => caches.match("${OFFLINE_URL}")),
      );
    });
  `;

  return new Response(body, { headers: { "Content-Type": "application/javascript" } });
}
