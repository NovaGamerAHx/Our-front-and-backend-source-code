import type { MetadataRoute } from "next";
import { APP_URL } from "@/lib/api/constants";

// Kept in sync by hand with the allow-list in app/robots.ts -- only public marketing routes
// belong in either place. See app/robots.ts for why every other route is excluded.
export default function sitemap(): MetadataRoute.Sitemap {
  const routes: {
    path: string;
    changeFrequency: MetadataRoute.Sitemap[number]["changeFrequency"];
    priority: number;
  }[] = [
    { path: "/", changeFrequency: "monthly", priority: 1 },
    { path: "/test", changeFrequency: "monthly", priority: 0.9 },
    { path: "/explore", changeFrequency: "monthly", priority: 0.7 },
    { path: "/about", changeFrequency: "yearly", priority: 0.5 },
    { path: "/blog", changeFrequency: "weekly", priority: 0.5 },
    { path: "/terms", changeFrequency: "yearly", priority: 0.2 },
  ];

  return routes.map(({ path, changeFrequency, priority }) => ({
    url: `${APP_URL}${path}`,
    lastModified: new Date(),
    changeFrequency,
    priority,
  }));
}
