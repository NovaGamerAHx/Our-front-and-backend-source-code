import { redirect } from "next/navigation";
import { sanitizeSource } from "@/lib/analytics/source";
import {
  appendUtm,
  readUtmFromSearchParams,
  shortLinkDeepSource,
} from "@/lib/constants/short-links";

type GoDeepPageProps = {
  searchParams: Promise<{
    source?: string;
    utm_source?: string;
    utm_medium?: string;
    utm_campaign?: string;
  }>;
};

/**
 * Deep-test short link (/go/deep): for SMS invites to people who took the initial test.
 * Forwards to the deep-test intro (/deep-test), which itself handles the login redirect
 * (with next preserved) for logged-out visitors. An explicit ?source= wins; without one,
 * SHORT_LINK_DEEP_SOURCE (default "sms") applies.
 *
 * UTM campaign params are forwarded to /deep-test; the faraman_utm cookie itself is
 * written by proxy.ts (UtmCapture never runs on this redirecting page).
 */
export default async function GoDeepPage({ searchParams }: GoDeepPageProps) {
  const rawParams = await searchParams;
  const { source: rawSource } = rawParams;
  const utm = readUtmFromSearchParams(rawParams);
  const source = rawSource ? sanitizeSource(rawSource) : shortLinkDeepSource();
  redirect(appendUtm(`/deep-test?source=${encodeURIComponent(source)}`, utm));
}
