"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ChevronLeft, Clock, MessageCircle } from "lucide-react";
import type { ActionStep, ReportHistoryItem } from "@/lib/api/schemas";
import { toPersianDigits } from "@/lib/utils/digits";
import {
  DEADLINE_TEXT,
  SOURCE_CATEGORIES,
  SOURCE_CATEGORY_LABELS,
  actionStepSourceCategory,
  type SourceCategory,
  type StepUrgency,
} from "@/lib/utils/action-step";
import { ProfileNudgeBanner } from "./profile-nudge-banner";
import { StepDetailSheet } from "@/components/action-steps/step-detail-sheet";

// Design handoff's send-button icon (a plain arrow shape, not lucide's paper-plane Send) --
// mirrored via -scale-x-100 since it's authored pointing up-left but the button sits on the
// input's leading (right) edge in this RTL layout.
function SendIcon({ size = 18 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="#fff"
      strokeWidth={1.9}
      strokeLinecap="round"
      strokeLinejoin="round"
      className="-scale-x-100"
    >
      <path d="m22 2-7 20-4-9-9-4Z" />
      <path d="M22 2 11 13" />
    </svg>
  );
}

const CHIP_BASE = "min-h-10 flex-none cursor-pointer rounded-full border px-3.5 py-[9px] text-xs font-bold whitespace-nowrap";
const CHIP_SELECTED = `${CHIP_BASE} border-[#6B4FA8] bg-[#6B4FA8] text-white`;
const CHIP_UNSELECTED = `${CHIP_BASE} border-chip-border text-muted-foreground bg-white`;

// Deadline proximity tints the card itself (replaces the old dark notification box): a calm
// blue-lavender once the reminder window opens, red once the followup window (deadline passed) opens.
const STEP_CARD_TINT: Record<Exclude<StepUrgency, null>, string> = {
  approaching: "border-[#C7CDF0] bg-[#EEF0FB]",
  overdue: "border-danger-border bg-danger-tint",
};

export function DashboardView({
  name,
  currentReport,
  profileIncomplete,
  pendingSteps,
}: {
  name: string | null;
  currentReport: ReportHistoryItem | null;
  profileIncomplete: boolean;
  pendingSteps: (ActionStep & { urgency: StepUrgency })[];
}) {
  const router = useRouter();
  const reportHref = currentReport ? `/report?attemptId=${currentReport.attempt_id}` : null;
  const [sourceFilter, setSourceFilter] = useState<SourceCategory | null>(null);
  const [detailStep, setDetailStep] = useState<ActionStep | null>(null);
  const [chatInput, setChatInput] = useState("");

  const filteredSteps = sourceFilter
    ? pendingSteps.filter((s) => actionStepSourceCategory(s.source) === sourceFilter)
    : pendingSteps;

  function refresh() {
    router.refresh();
  }

  function askDashboardChat() {
    const value = chatInput.trim();
    if (!value) return;
    router.push(`/chat?from=%2Fdashboard&initial_message=${encodeURIComponent(value)}`);
  }

  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[680px] flex-col gap-6 px-7 pt-6 pb-12">
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-0.5">
          <div className="text-text-faint text-[12.5px]">سلام،</div>
          <div className="text-xl font-extrabold">{name ?? "دوست من"} 👋</div>
        </div>
        <Link
          href="/profile"
          className="grid size-11 flex-none place-items-center rounded-full text-[17px] font-extrabold text-white"
          style={{ background: "linear-gradient(135deg,#2743C6,#8E6BA8)" }}
        >
          {(name ?? "ف").charAt(0)}
        </Link>
      </div>

      <ProfileNudgeBanner visible={profileIncomplete} />

      <div
        className="relative flex flex-col gap-2.5 overflow-hidden rounded-[18px] p-[14px_15px] shadow-[0_10px_24px_-14px_rgba(39,67,198,.6)]"
        style={{ background: "linear-gradient(135deg,#1F2A63,#2743C6 60%,#8E6BA8)" }}
      >
        <div
          className="pointer-events-none absolute -top-[60px] -left-[30px] size-[130px] rounded-full"
          style={{ background: "rgba(255,255,255,.08)" }}
        />
        <div className="relative flex items-center gap-2.5">
          <div className="grid size-8 flex-none place-items-center rounded-[10px]" style={{ background: "rgba(255,255,255,.18)" }}>
            <MessageCircle size={17} strokeWidth={1.9} className="text-white" />
          </div>
          <div className="flex-1 text-[14px] leading-[1.6] font-extrabold text-white">امروز از چه چیزی حرف بزنیم؟</div>
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            askDashboardChat();
          }}
          className="relative flex items-center gap-1.5 rounded-[14px] bg-white py-1 pr-1 pl-4"
        >
          <button
            type="submit"
            aria-label="ارسال"
            disabled={!chatInput.trim()}
            className="bg-primary grid size-10 flex-none cursor-pointer place-items-center rounded-[13px] disabled:opacity-40"
          >
            <SendIcon />
          </button>
          <input
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            dir="rtl"
            placeholder="هر چه در ذهنت هست بنویس…"
            className="text-foreground min-h-[38px] min-w-0 flex-1 border-none bg-transparent text-[13px] outline-none"
          />
        </form>
      </div>

      <div className="flex flex-col gap-3.5">
        <div className="flex items-baseline justify-between gap-2.5">
          <div className="text-[15px] font-extrabold">قدم‌های جاری</div>
          <div className="text-text-faint text-[11.5px] font-bold">{toPersianDigits(pendingSteps.length)} قدم</div>
        </div>

        {pendingSteps.length > 0 && (
          <div className="flex gap-1.5 overflow-x-auto pb-0.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            <button type="button" onClick={() => setSourceFilter(null)} className={sourceFilter === null ? CHIP_SELECTED : CHIP_UNSELECTED}>
              همه
            </button>
            {SOURCE_CATEGORIES.map((category) => (
              <button
                key={category}
                type="button"
                onClick={() => setSourceFilter(category)}
                className={sourceFilter === category ? CHIP_SELECTED : CHIP_UNSELECTED}
              >
                {SOURCE_CATEGORY_LABELS[category]}
              </button>
            ))}
          </div>
        )}

        {filteredSteps.length > 0 ? (
          <div className="flex flex-col gap-2.5">
            {filteredSteps.map((step) => (
              <button
                key={step.id}
                type="button"
                onClick={() => setDetailStep(step)}
                className={`shadow-card flex w-full cursor-pointer items-center gap-1.5 rounded-2xl border py-2.5 pr-2 pl-3 text-right ${
                  step.urgency ? STEP_CARD_TINT[step.urgency] : "border-border bg-card"
                }`}
              >
                <span
                  aria-hidden
                  className="grid size-11 flex-none place-items-center rounded-full"
                >
                  <span className="block size-6 rounded-full border-2 border-[#C3CBEA]" />
                </span>
                <span className="flex min-w-0 flex-1 flex-col gap-1.5 py-1">
                  <span className="text-foreground text-[13.5px] leading-[1.85] font-bold text-pretty">
                    {step.step_text}
                  </span>
                  <span
                    className={`text-[10.5px] font-bold ${
                      step.urgency === "overdue"
                        ? "text-danger-text"
                        : step.urgency === "approaching"
                          ? "text-lavender-text"
                          : "text-[#8B8676]"
                    }`}
                  >
                    {step.urgency === "overdue"
                      ? `مهلت گذشت — ${DEADLINE_TEXT[step.deadline_type]}`
                      : `مهلت: ${DEADLINE_TEXT[step.deadline_type]}`}
                  </span>
                </span>
              </button>
            ))}
          </div>
        ) : (
          <div className="border-chip-border bg-card flex flex-col gap-3 rounded-[18px] border border-dashed p-[22px]">
            <div className="text-[14px] font-extrabold">
              {!currentReport
                ? "هنوز گزارشی نداری"
                : pendingSteps.length > 0
                  ? "در این منبع قدمی نیست"
                  : "الان قدم جاری نداری"}
            </div>
            <p className="text-muted-foreground m-0 text-[12.5px] leading-[1.95] text-pretty">
              {currentReport
                ? "هنوز قدمی برای انجام از این قسمت ندارید. می‌توانید به بخش توصیه‌های گزارش‌ها مراجعه کنید تا متناسب با آن، قدم پیشنهادی فرامن را دریافت کنید. یا از بخش دستیار قدم مناسب امروز در جهت رشدتان را دریافت کنید."
                : "برای شروع، یک آزمون بده تا توصیه‌هایت آماده شود."}
            </p>
            <div className="flex gap-2.5">
              {reportHref && (
                <Link
                  href={`${reportHref}#advice`}
                  className="bg-primary grid min-h-11 flex-1 place-items-center rounded-[13px] px-5 py-3 text-center text-[13px] font-extrabold text-white"
                >
                  توصیه‌های گزارش
                </Link>
              )}
              <Link
                href="/chat?from=%2Fdashboard&intent=next_step"
                className="border-border grid min-h-11 flex-1 place-items-center rounded-[13px] border-[1.5px] bg-white px-5 py-3 text-center text-[13px] font-bold"
              >
                گفتگو با دستیار
              </Link>
            </div>
          </div>
        )}
      </div>

      <Link
        href="/dashboard/history"
        className="shadow-card border-border bg-card flex items-center gap-3 rounded-2xl border px-[19px] py-[17px]"
      >
        <div className="bg-muted grid size-9 flex-none place-items-center rounded-[11px]">
          <Clock size={18} strokeWidth={1.8} className="text-muted-foreground" />
        </div>
        <div className="flex min-w-0 flex-1 flex-col gap-0.5">
          <div className="text-[13.5px] font-extrabold">تاریخچهٔ قدم‌ها</div>
          <div className="text-muted-foreground text-[11.5px]">قدم‌های انجام‌شده و گذشته را از اینجا ببین</div>
        </div>
        <ChevronLeft size={16} strokeWidth={2.5} className="text-muted-foreground flex-none" />
      </Link>

      {currentReport && (
        <div
          className="relative flex flex-col gap-3.5 overflow-hidden rounded-[20px] p-6"
          style={{ background: "linear-gradient(135deg,#2C2350,#5A3F7A)" }}
        >
          <div
            className="pointer-events-none absolute -top-10 -right-[30px] size-[150px] rounded-full"
            style={{ background: "rgba(232,169,143,.25)" }}
          />
          <div className="relative flex flex-col gap-1.5">
            <div className="text-lg leading-[1.6] font-extrabold text-white">مسیر ادامه داره</div>
            <p className="text-[12.5px] leading-[1.95] text-white/80">
              هر چی خودت رو بیشتر بشناسی، مسیر رشدت روشن‌تر میشه.
            </p>
          </div>
          <Link
            href="/explore"
            className="relative min-h-11 self-start rounded-2xl bg-white px-[26px] py-3.5 text-[14px] font-extrabold text-[#3A2B5C]"
          >
            قدم بعدی
          </Link>
        </div>
      )}

      {detailStep && (
        <StepDetailSheet
          open
          onClose={() => setDetailStep(null)}
          step={detailStep}
          onUpdated={refresh}
          onCompleted={refresh}
        />
      )}
    </main>
  );
}
