"use client";

import { useState } from "react";
import Link from "next/link";
import { User, X } from "lucide-react";

export function ProfileNudgeBanner({ visible }: { visible: boolean }) {
  const [dismissed, setDismissed] = useState(false);

  if (!visible || dismissed) return null;

  return (
    <div className="bg-lavender-tint border-lavender-border flex items-center gap-3 rounded-2xl border px-4 py-[13px]">
      <div className="grid size-8 flex-none place-items-center rounded-[10px] bg-[#E7E2F5]">
        <User size={17} strokeWidth={1.8} className="text-[#6A5CA8]" />
      </div>
      <Link href="/profile" className="flex flex-1 flex-col gap-0.5">
        <div className="text-lavender-text text-[12.5px] font-extrabold">کمی بیشتر از خودت بگو</div>
        <div className="text-[11px] leading-[1.65] text-[#7A72A8]">
          تا بتوانیم بهتر همراهی‌ات کنیم .
        </div>
      </Link>
      <Link href="/profile" className="flex-none text-[11.5px] font-extrabold whitespace-nowrap text-[#6A5CA8]">
        تکمیل
      </Link>
      <button
        type="button"
        onClick={() => setDismissed(true)}
        className="grid size-[26px] flex-none cursor-pointer place-items-center rounded-lg text-[#A79FC8]"
      >
        <X size={15} />
      </button>
    </div>
  );
}
