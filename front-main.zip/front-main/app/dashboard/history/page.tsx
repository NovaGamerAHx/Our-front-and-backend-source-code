import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { ACCESS_TOKEN_COOKIE } from "@/lib/api/constants";
import { listActionStepHistory } from "@/lib/api/endpoints";
import type { ActionStep } from "@/lib/api/schemas";
import { StepHistoryView } from "./_components/step-history-view";

export default async function StepHistoryPage() {
  const store = await cookies();
  if (!store.has(ACCESS_TOKEN_COOKIE)) {
    redirect(`/login?${new URLSearchParams({ next: "/dashboard/history" }).toString()}`);
  }

  let items: ActionStep[] = [];
  try {
    items = await listActionStepHistory();
  } catch {
    // Non-critical: falls back to the empty state below.
  }

  return <StepHistoryView items={items} />;
}
