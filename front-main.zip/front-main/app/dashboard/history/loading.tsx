import { Sk } from "@/components/ui/skeleton";

// Instant fallback for تاریخچهٔ قدم‌ها while the closed-steps list is fetched.
export default function StepHistoryLoading() {
  return (
    <main className="mx-auto box-border flex min-h-dvh w-full max-w-[680px] flex-col gap-5 px-7 pt-6 pb-16">
      <div className="flex items-center gap-3">
        <Sk className="size-11 rounded-xl" />
        <Sk className="h-5 w-32" />
      </div>

      <Sk className="h-4 w-full max-w-[440px]" />

      <div className="flex flex-col gap-2.5">
        {[0, 1, 2, 3].map((i) => (
          <Sk key={i} className="h-[74px] w-full rounded-2xl" />
        ))}
      </div>
    </main>
  );
}
