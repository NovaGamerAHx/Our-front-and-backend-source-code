"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ChevronDown } from "lucide-react";
import { toast } from "sonner";
import type { ActionStep } from "@/lib/api/schemas";
import { formatJalali } from "@/lib/utils/date";
import { OBSTACLE_OPTIONS } from "@/lib/utils/action-step";
import { reactivateActionStepAction, submitActionStepFollowupAction } from "@/components/action-steps/actions";
import { Spinner } from "@/components/ui/spinner";

const CHANNEL_LABELS: Record<string, string> = {
  notif: "نوتیف",
  login: "ورود",
  dashboard: "داشبورد",
};

export function StepHistoryView({ items }: { items: ActionStep[] }) {
  const router = useRouter();
  const [openId, setOpenId] = useState<string | null>(null);
  const [askingId, setAskingId] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState<string | null>(null);

  function toggle(id: string) {
    setOpenId((prev) => (prev === id ? null : id));
    setAskingId(null);
  }

  async function reactivate(step: ActionStep) {
    setSubmitting(step.id);
    const result = await reactivateActionStepAction(step.id, { deadline_type: "within_24h" });
    setSubmitting(null);
    if (!result.ok) {
      toast.error(result.message);
      return;
    }
    toast.success("قدم جدید به لیست قدم‌های جاری اضافه شد.");
    router.refresh();
  }

  async function answerWhyNot(step: ActionStep, obstacle: (typeof OBSTACLE_OPTIONS)[number]["value"]) {
    setSubmitting(step.id);
    const result = await submitActionStepFollowupAction(step.id, {
      result: "not_done",
      obstacle,
      channel: "dashboard",
    });
    setSubmitting(null);
    if (!result.ok) {
      toast.error(result.message);
      return;
    }
    setAskingId(null);
    router.refresh();
  }

  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[680px] flex-col gap-5 px-7 pt-6 pb-16">
      <div className="flex items-center gap-3">
        <Link
          href="/dashboard"
          aria-label="بازگشت"
          className="border-border flex size-11 flex-none items-center justify-center rounded-xl border bg-white text-[16px] text-[#5D5C55]"
        >
          →
        </Link>
        <div className="text-lg font-extrabold">تاریخچهٔ قدم‌ها</div>
      </div>

      <p className="text-muted-foreground m-0 text-[12.5px] leading-[1.95] text-pretty">
        قدم‌هایی که تیک خورده‌اند یا مهلتشان گذشته، همین‌جا می‌مانند. روی هر کدام بزن تا جزئیاتش را ببینی یا پاسخ نداده
        را ثبت کنی.
      </p>

      {items.length === 0 ? (
        <div className="border-chip-border bg-card flex flex-col gap-2 rounded-[18px] border border-dashed p-6">
          <div className="text-[14px] font-extrabold">تاریخچه هنوز خالی است</div>
          <p className="text-muted-foreground m-0 text-[12.5px] leading-[1.95]">
            اولین قدمی که تیک بخورد یا مهلتش بگذرد، همین‌جا ثبت می‌شود.
          </p>
        </div>
      ) : (
        <div className="flex flex-col gap-[9px]">
          {items.map((step) => {
            const isOpen = openId === step.id;
            const isAsking = askingId === step.id;
            const isDone = step.status === "done";
            const isSubmitting = submitting === step.id;
            return (
              <div
                key={step.id}
                className={`flex flex-col gap-3 rounded-2xl border px-[15px] py-[13px] ${isDone ? "border-border bg-card" : "border-[#DDDAD3] bg-[#E9E7E2]"}`}
              >
                <button
                  type="button"
                  onClick={() => toggle(step.id)}
                  className="flex min-h-11 w-full cursor-pointer items-center gap-3 text-right"
                >
                  <div
                    className={`grid size-[26px] flex-none place-items-center rounded-full text-xs font-extrabold ${
                      isDone ? "bg-success-tint text-success" : "bg-[#EFEADF] text-text-faint"
                    }`}
                  >
                    {isDone ? "✓" : "—"}
                  </div>
                  <div className={`flex min-w-0 flex-1 flex-col gap-1.5 ${isDone ? "" : "opacity-70"}`}>
                    <div className="text-[13px] leading-[1.85] font-bold text-pretty">{step.step_text}</div>
                    <span className="text-text-faint text-[10.5px] font-bold">
                      {isDone
                        ? step.completed_at
                          ? `انجام شد — ${formatJalali(step.completed_at)}`
                          : "انجام شد"
                        : `مهلت گذشت — ${formatJalali(step.deadline_at)}`}
                    </span>
                  </div>
                  <ChevronDown
                    size={16}
                    className={`text-text-faintest flex-none transition-transform ${isOpen ? "rotate-180" : ""}`}
                  />
                </button>

                {isOpen && (
                  <div className="animate-fm-in flex flex-col gap-3 border-t border-[#F1ECE1] pt-[13px]">
                    {isDone ? (
                      <div className="flex flex-col gap-2.5">
                        <div className="text-success text-xs font-extrabold">
                          انجام شد{step.completed_at ? ` — ${formatJalali(step.completed_at)}` : ""}
                        </div>
                        <p className="m-0 text-[12.5px] leading-[1.95] text-[#5D5C55] text-pretty">
                          {step.reflection_text
                            ? `«${step.reflection_text}»`
                            : "بازتابی برایش ثبت نشده — اشکالی ندارد."}
                        </p>
                        <div className="flex flex-wrap gap-[9px] border-t border-[#F1ECE1] pt-3">
                          <Link
                            href={`/chat?entry_source=action_completed&action_step_id=${step.id}&from=%2Fdashboard%2Fhistory`}
                            className="min-h-11 cursor-pointer rounded-[13px] bg-[#6B4FA8] px-[18px] py-3 text-[12.5px] font-extrabold text-white"
                          >
                            قدم بعدی را بگیر
                          </Link>
                        </div>
                      </div>
                    ) : step.latest_response ? (
                      <div className="flex flex-col gap-2.5">
                        <div className="flex flex-col gap-2 rounded-[13px] bg-[#FBF8F1] px-[15px] py-[13px]">
                          <div className="text-[11.5px] font-extrabold text-[#8B8676]">
                            پاسخ ثبت‌شده — {CHANNEL_LABELS[step.latest_response.channel] ?? step.latest_response.channel}
                          </div>
                          <div className="text-[13px] leading-[1.85] font-bold text-[#242A38]">
                            {OBSTACLE_OPTIONS.find((o) => o.value === step.latest_response!.obstacle)?.label ??
                              step.latest_response.obstacle}
                          </div>
                        </div>
                        {/* chat_spec_v3 §1.4: only once "what happened" is on record -- a still-pending
                            overdue step has no chat button, since the model can't tell success from failure. */}
                        <Link
                          href={`/chat?entry_source=action_missed&action_step_id=${step.id}&from=%2Fdashboard%2Fhistory`}
                          className="border-border min-h-11 max-w-max cursor-pointer rounded-[13px] border-[1.5px] bg-white px-4 py-3 text-[12.5px] font-bold text-[#242A38]"
                        >
                          بیا درباره‌اش حرف بزنیم
                        </Link>
                      </div>
                    ) : isAsking ? (
                      <div className="flex flex-col gap-2.5">
                        <div className="text-[12.5px] font-extrabold text-[#242A38]">چه چیزی جلویش را گرفت؟</div>
                        <div className="flex flex-wrap gap-[7px]">
                          {OBSTACLE_OPTIONS.map((opt) => (
                            <button
                              key={opt.value}
                              type="button"
                              disabled={isSubmitting}
                              onClick={() => answerWhyNot(step, opt.value)}
                              className="border-border min-h-11 cursor-pointer rounded-full border-[1.5px] bg-white px-[15px] py-[10px] text-xs font-bold text-[#242A38] disabled:cursor-not-allowed disabled:opacity-60"
                            >
                              {opt.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-wrap gap-2.5">
                        <button
                          type="button"
                          disabled={isSubmitting}
                          onClick={() => reactivate(step)}
                          className="flex min-h-11 cursor-pointer items-center justify-center gap-2.5 rounded-[13px] bg-[#6B4FA8] px-[18px] py-3 text-[12.5px] font-extrabold text-white disabled:cursor-not-allowed disabled:opacity-75"
                        >
                          {isSubmitting && <Spinner />}
                          دوباره فعالش کن
                        </button>
                        <button
                          type="button"
                          onClick={() => setAskingId(step.id)}
                          className="border-border min-h-11 cursor-pointer rounded-[13px] border-[1.5px] bg-white px-4 py-3 text-[12.5px] font-bold text-[#242A38]"
                        >
                          بگو چرا انجام نشد
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </main>
  );
}
