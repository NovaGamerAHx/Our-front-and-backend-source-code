import { redirect } from "next/navigation";
// Backward-compatible bookmark: the dashboard is now Home, not a second destination.
export default function DashboardPage() {
  redirect("/");
}
