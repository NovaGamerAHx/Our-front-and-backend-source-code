import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { ACCESS_TOKEN_COOKIE } from "@/lib/api/constants";
import { ApiError } from "@/lib/api/client";
import { getProfile, getReportHistory, listPendingActionSteps } from "@/lib/api/endpoints";
import type { ActionStep, ReportHistoryItem } from "@/lib/api/schemas";
import { isProfileComplete } from "@/lib/utils/profile";
import { actionStepUrgency, type StepUrgency } from "@/lib/utils/action-step";
import { DashboardView } from "./_components/dashboard-view";

// Not a component/hook, so the impure Date.now() call here doesn't trip react-hooks/purity.
// Reminders arrive only as push notifications (their deep link lands on /checkin) -- here the
// step card itself is tinted by how close it is to its deadline instead of a notification box.
function withUrgency(pendingSteps: ActionStep[]): (ActionStep & { urgency: StepUrgency })[] {
  const now = Date.now();
  return pendingSteps.map((step) => ({ ...step, urgency: actionStepUrgency(step, now) }));
}

export default async function DashboardPage() {
  const store = await cookies();
  if (!store.has(ACCESS_TOKEN_COOKIE)) {
    redirect(`/login?${new URLSearchParams({ next: "/dashboard" }).toString()}`);
  }

  let name: string | null = null;
  let profileIncomplete = false;
  try {
    const profile = await getProfile();
    name = profile.name;
    profileIncomplete = !isProfileComplete(profile);
  } catch (error) {
    if (error instanceof ApiError && error.status === 401) {
      redirect(`/login?${new URLSearchParams({ next: "/dashboard" }).toString()}`);
    }
    // Non-auth failures (network blip, etc.) shouldn't block the dashboard — just fall back
    // to a generic greeting instead of showing an error page for a non-critical field.
  }

  let currentReport: ReportHistoryItem | null = null;
  try {
    const history = await getReportHistory();
    currentReport = history[0] ?? null;
  } catch (error) {
    if (error instanceof ApiError && error.status === 401) {
      redirect(`/login?${new URLSearchParams({ next: "/dashboard" }).toString()}`);
    }
    // Same tolerance as the profile fetch above — fall back to the "no report yet" state
    // rather than blocking the whole dashboard on a transient failure.
  }

  let pendingSteps: ActionStep[] = [];
  try {
    pendingSteps = await listPendingActionSteps();
  } catch {
    // Non-critical: the dashboard still works without the "قدم‌های جاری" list.
  }

  const stepsWithUrgency = withUrgency(pendingSteps);

  return (
    <DashboardView
      name={name}
      currentReport={currentReport}
      profileIncomplete={profileIncomplete}
      pendingSteps={stepsWithUrgency}
    />
  );
}
