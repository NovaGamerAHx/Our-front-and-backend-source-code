import { Sk } from "@/components/ui/skeleton";

// Shown the instant the داشبورد tab is tapped — the tab bar + header stay put and
// this skeleton fills the page area while dashboard/page.tsx fetches (profile,
// report history, pending steps). Mirrors DashboardView's layout so content
// swaps in without a jump. See Edge States §e9.
export default function DashboardLoading() {
  return (
    <main className="mx-auto box-border flex min-h-dvh w-full max-w-[680px] flex-col gap-6 px-7 pt-6 pb-12">
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-1.5">
          <Sk className="h-3 w-10" />
          <Sk className="h-5 w-32" />
        </div>
        <Sk className="size-11 rounded-full" />
      </div>

      <div className="flex flex-col gap-3.5">
        <div className="flex items-baseline justify-between">
          <Sk className="h-4 w-24" />
          <Sk className="h-3 w-12" />
        </div>
        <div className="flex gap-1.5">
          <Sk className="h-9 w-14 rounded-full" />
          <Sk className="h-9 w-24 rounded-full" />
          <Sk className="h-9 w-24 rounded-full" />
        </div>
        <div className="flex flex-col gap-2.5">
          <Sk className="h-[68px] w-full rounded-2xl" />
          <Sk className="h-[68px] w-full rounded-2xl" />
        </div>
      </div>

      <div className="flex flex-col gap-3">
        <Sk className="h-4 w-20" />
        <Sk className="h-[104px] w-full rounded-[18px]" />
      </div>

      <Sk className="h-[72px] w-full rounded-[18px]" />
    </main>
  );
}
