import type { Metadata } from "next";
import localFont from "next/font/local";
import { Geist_Mono } from "next/font/google";
import { cookies } from "next/headers";
import { Toaster } from "@/components/ui/sonner";
import { ACCESS_TOKEN_COOKIE, APP_URL } from "@/lib/api/constants";
import { SiteChrome } from "@/components/site/site-chrome";
import { UtmCapture } from "@/components/analytics/utm-capture";
import { RegisterServiceWorker } from "@/components/push/register-service-worker";
import "./globals.css";

const estedad = localFont({
  src: "./fonts/Estedad-Variable.woff2",
  variable: "--font-sans",
  weight: "100 900",
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const SITE_NAME = "فرامن";
const SITE_DESCRIPTION = "یک ارزیابی کوتاه و محرمانه برای شناخت الگوها و نقاط قوت شما";

export const metadata: Metadata = {
  metadataBase: new URL(APP_URL),
  title: {
    default: SITE_NAME,
    template: `%s | ${SITE_NAME}`,
  },
  description: SITE_DESCRIPTION,
  openGraph: {
    type: "website",
    locale: "fa_IR",
    url: "/",
    siteName: SITE_NAME,
    title: SITE_NAME,
    description: SITE_DESCRIPTION,
  },
  twitter: {
    card: "summary_large_image",
    title: SITE_NAME,
    description: SITE_DESCRIPTION,
  },
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const store = await cookies();
  const isLoggedIn = store.has(ACCESS_TOKEN_COOKIE);

  return (
    <html
      lang="fa"
      dir="rtl"
      className={`${estedad.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="flex min-h-full flex-col">
        <SiteChrome isLoggedIn={isLoggedIn}>{children}</SiteChrome>
        <Toaster dir="rtl" position="top-center" />
        <RegisterServiceWorker isLoggedIn={isLoggedIn} />
        <UtmCapture />
      </body>
    </html>
  );
}
