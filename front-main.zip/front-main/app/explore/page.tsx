import type { Metadata } from "next";
import { WorkspaceFrame } from "@/components/workspace/frame";
import { SelfKnowledgeView } from "@/components/workspace/explore-view";
export const metadata: Metadata = {
  title: "خودشناسی",
  description: "گزارش‌ها و آزمون‌های خودشناسی تو در فرامن",
};
export default function ExplorePage() {
  return (
    <WorkspaceFrame>
      <SelfKnowledgeView />
    </WorkspaceFrame>
  );
}
