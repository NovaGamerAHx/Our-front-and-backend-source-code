import type { Metadata } from "next";
import { cookies } from "next/headers";
import { ACCESS_TOKEN_COOKIE } from "@/lib/api/constants";
import { getReportAttemptsHistory } from "@/lib/api/endpoints";
import type { ReportAttemptHistoryItem } from "@/lib/api/schemas";
import { ExploreView } from "./_components/explore-view";

export const metadata: Metadata = {
  title: "کاوش",
  description: "آزمون رایگان خودشناسی و ارزیابی‌های تکمیلی فرامن را اینجا ببینید و ادامه دهید.",
};

// The کاووش (Explore) hub: public, shows the free and supplementary tests side by side and picks
// up wherever the visitor left off. Reachable from both the nav (logged in or not) and as the
// landing spot for the first tab in the mobile bar.
export default async function ExplorePage() {
  const store = await cookies();
  const isLoggedIn = store.has(ACCESS_TOKEN_COOKIE);

  let history: ReportAttemptHistoryItem[] = [];
  let deepTaken = false;

  if (isLoggedIn) {
    try {
      history = await getReportAttemptsHistory();
      deepTaken = history.some((item) => item.report_type === "deep" && item.status === "ok");
    } catch {
      // Non-critical -- the "latest attempt" card and the deep-report badge just don't show.
    }
  }

  return <ExploreView history={history} deepTaken={deepTaken} />;
}
