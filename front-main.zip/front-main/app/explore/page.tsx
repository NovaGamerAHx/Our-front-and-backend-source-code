import type { Metadata } from "next";
import { getWorkspaceData } from "@/lib/workspace/data";
import { WorkspaceFrame } from "@/components/workspace/frame";
import { PublicChrome } from "@/components/workspace/public-chrome";
import {
  PublicSelfKnowledgeView,
  SelfKnowledgeView,
} from "@/components/workspace/explore-view";

export const metadata: Metadata = {
  title: "خودشناسی",
  description: "گزارش‌ها و آزمون‌های خودشناسی تو در فرامن",
};

export default async function ExplorePage() {
  const workspace = await getWorkspaceData();
  if (!workspace.authenticated || !workspace.profile) {
    return (
      <PublicChrome>
        <PublicSelfKnowledgeView />
      </PublicChrome>
    );
  }
  return (
    <WorkspaceFrame>
      <SelfKnowledgeView />
    </WorkspaceFrame>
  );
}
