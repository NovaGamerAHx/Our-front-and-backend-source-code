import { Sk } from "@/components/ui/skeleton";

// Edge States §e9: tapping کاووش switches the tab and drops this skeleton in
// immediately; explore/page.tsx then resolves (pre-start, report history,
// entitlements) and the real cards replace these.
export default function ExploreLoading() {
  return (
    <main className="mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col gap-[22px] px-5 pt-[18px] pb-10">
      <div className="flex flex-col gap-2">
        <Sk className="h-6 w-28" />
        <Sk className="h-4 w-full max-w-[420px]" />
      </div>

      <Sk className="h-[132px] w-full rounded-2xl" />
      <Sk className="h-[132px] w-full rounded-2xl" />

      <div className="flex flex-col gap-2.5">
        <Sk className="h-3.5 w-32" />
        <Sk className="h-[64px] w-full rounded-2xl" />
      </div>
    </main>
  );
}
