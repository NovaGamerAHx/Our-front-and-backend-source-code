import Link from "next/link";
import {
  Check,
  ChevronLeft,
  ClipboardCheck,
  Clock,
  FileText,
  Loader2,
  RefreshCw,
} from "lucide-react";
import { formatJalali } from "@/lib/utils/date";
import { toPersianDigits } from "@/lib/utils/digits";
import type { ReportAttemptHistoryItem } from "@/lib/api/schemas";

const WEB_DEEP_POINTS = [
  "چرا بعضی الگوها مدام در زندگی‌ات تکرار می‌شوند؟",
  "هر ویژگی، کجا به کارت می‌آید و کجا هزینه می‌سازد",
  "گفتگویی برای فراتر رفتن بر پایه‌ی گزارش کاملت",
];

const WEB_CARD =
  "rounded-3xl border border-[#ECE6D9] bg-white shadow-[0_1px_2px_rgba(36,42,56,.04),0_8px_24px_rgba(36,42,56,.05)] transition-[transform,box-shadow,border-color] duration-300";
const WEB_CARD_HOVER =
  "hover:-translate-y-[3px] hover:border-[#E2D9C8] hover:shadow-[0_2px_4px_rgba(36,42,56,.04),0_18px_40px_rgba(36,42,56,.09)]";

function reportLabel(item: ReportAttemptHistoryItem): string {
  return item.report_type === "deep" ? "پروفایل کامل شخصیت" : "آزمون خودشناسی اولیه";
}

function reportHref(item: ReportAttemptHistoryItem): string {
  return item.report_type === "deep"
    ? `/deep-report?attemptId=${item.attempt_id}`
    : `/report?attemptId=${item.attempt_id}`;
}

function retryHref(item: ReportAttemptHistoryItem): string {
  return `/test/analysis?attemptId=${item.attempt_id}&retry=1`;
}

function dateOf(item: ReportAttemptHistoryItem): string {
  return toPersianDigits(formatJalali(item.completed_at));
}

function ReportCta({ item, className }: { item: ReportAttemptHistoryItem; className: string }) {
  if (item.status === "generating") {
    return (
      <Link href={`/test/analysis?attemptId=${item.attempt_id}`} className={className}>
        پیگیری وضعیت
      </Link>
    );
  }
  if (item.status === "error") {
    return (
      <Link href={retryHref(item)} className={className}>
        تولید دوبارهٔ گزارش
      </Link>
    );
  }
  if (item.status === "awaiting_payment") {
    // reportHref lands on /deep-report, which sends a locked report on to its paywall.
    return (
      <Link href={reportHref(item)} className={className}>
        باز کردن گزارش
      </Link>
    );
  }
  return (
    <Link href={reportHref(item)} className={className}>
      مشاهدهٔ گزارش کامل
    </Link>
  );
}

function FailedBanner({ item }: { item: ReportAttemptHistoryItem }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-4 rounded-[18px] border border-[#F0C9C5] bg-[#FDF3F2] px-5 py-4">
      <div className="text-sm leading-[1.9] text-[#7A2620]">
        تولید این گزارش ناتمام ماند. می‌توانی با همان پاسخ‌ها دوباره درخواست بدهی.
      </div>
      <Link
        href={retryHref(item)}
        className="flex items-center gap-1.5 rounded-full bg-[#B3261E] px-5 py-2.5 text-sm font-extrabold text-white"
      >
        <RefreshCw size={16} strokeWidth={2} />
        تولید دوبارهٔ گزارش
      </Link>
    </div>
  );
}

function ExploreWeb({
  history,
  deepTaken,
  deepStatusText,
}: {
  history: ReportAttemptHistoryItem[];
  deepTaken: boolean;
  deepStatusText: string;
}) {
  const [latest, ...past] = history;
  const deepCtaLabel = deepTaken ? "آزمون خودشناسی عمیق" : "شروع آزمون خودشناسی عمیق";

  return (
    <main className="animate-fm-in hidden min-h-dvh w-full flex-col bg-[#F8F5EE] md:flex">
      <div className="mx-auto flex w-full max-w-[1160px] flex-col gap-2 px-8 pt-14 pb-2">
        <h1 className="text-4xl leading-[1.45] font-extrabold text-[#242A38]">کاوش</h1>
        <p className="text-base leading-[1.9] text-[#5D5C55]">
          گزارش‌هایت را ببین و قدم بعدیِ شناخت خودت را بردار.
        </p>
      </div>

      <div className="mx-auto grid w-full max-w-[1160px] [grid-template-columns:minmax(0,1.75fr)_minmax(300px,1fr)] items-start gap-10 px-8 pt-9 pb-[88px]">
        {/* reports */}
        <section className="flex flex-col gap-5">
          <div className="flex items-baseline justify-between gap-4">
            <h2 className="text-[21px] font-extrabold text-[#242A38]">گزارش‌های من</h2>
            <Link
              href="/history"
              className="text-primary flex items-center gap-0.5 text-sm font-extrabold transition-opacity hover:opacity-70"
            >
              مشاهدهٔ همه <ChevronLeft size={16} strokeWidth={2.5} />
            </Link>
          </div>

          {latest ? (
            <div className="flex flex-col gap-9">
              {latest.status === "error" && <FailedBanner item={latest} />}
              <div
                className={`${WEB_CARD} ${WEB_CARD_HOVER} grid [grid-template-columns:auto_minmax(0,1fr)] items-center gap-7 p-8`}
              >
                <div className="grid h-[116px] w-[92px] place-items-center rounded-[18px] bg-[#F3EEF7]">
                  {latest.status === "generating" ? (
                    <Loader2 size={38} strokeWidth={1.6} className="animate-spin text-[#7A5490]" />
                  ) : (
                    <FileText size={38} strokeWidth={1.6} className="text-[#7A5490]" />
                  )}
                </div>
                <div className="flex min-w-0 flex-col gap-2.5">
                  <div className="flex flex-wrap items-center gap-2.5 text-[13px] font-bold text-[#8B8676]">
                    <span className="rounded-full bg-[#E4F1EA] px-2.5 py-[3px] font-extrabold text-[#2E8A5C]">
                      جدیدترین
                    </span>
                    <span>{reportLabel(latest)}</span>
                    <span>·</span>
                    <span>
                      {latest.status === "generating" ? "در حال ساخته شدن است…" : dateOf(latest)}
                    </span>
                  </div>
                  {latest.status === "ok" && latest.summary_one_line && (
                    <div className="text-[21px] leading-[1.75] font-extrabold text-pretty text-[#242A38]">
                      {latest.summary_one_line}
                    </div>
                  )}
                  <div className="mt-2 flex">
                    <ReportCta
                      item={latest}
                      className="rounded-full bg-[#242A38] px-[26px] py-[13px] text-[14.5px] font-extrabold text-white transition-colors hover:bg-[#363D50]"
                    />
                  </div>
                </div>
              </div>

              {past.length > 0 && (
                <div className="flex flex-col gap-3.5">
                  <h3 className="text-[15px] font-extrabold text-[#242A38]">گزارش‌های قبلی</h3>
                  <div className="flex flex-col gap-2.5">
                    {past.map((item) => (
                      <Link
                        key={item.attempt_id}
                        href={item.status === "ok" ? reportHref(item) : "/history"}
                        className={`${WEB_CARD} ${WEB_CARD_HOVER} flex items-center gap-4 !rounded-[18px] px-5 py-4`}
                      >
                        <div className="grid size-10 flex-none place-items-center rounded-xl bg-[#F5F1E8]">
                          <FileText size={19} strokeWidth={1.6} className="text-[#8B8676]" />
                        </div>
                        <div className="min-w-0 flex-1 truncate text-[15px] leading-[1.8] font-bold text-[#3A3F4D]">
                          {reportLabel(item)}
                        </div>
                        <div className="flex-none text-[13px] text-[#8B8676]">{dateOf(item)}</div>
                        <div className="text-primary flex flex-none items-center gap-0.5 text-sm font-extrabold">
                          مشاهده <ChevronLeft size={16} strokeWidth={2.5} />
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className={`${WEB_CARD} flex flex-wrap items-center justify-between gap-5 p-7`}>
              <div className="text-[15px] leading-[1.9] text-[#5D5C55]">
                هنوز گزارشی نداری. بعد از اولین تست، گزارشت اینجا ثبت می‌شود.
              </div>
              <Link
                href="/test"
                className="rounded-full bg-[#242A38] px-[26px] py-[13px] text-[14.5px] font-extrabold text-white transition-colors hover:bg-[#363D50]"
              >
                شروع تست رایگان
              </Link>
            </div>
          )}
        </section>

        {/* tests */}
        <aside className="sticky top-24 flex flex-col gap-4">
          <div
            className="flex flex-col gap-3.5 rounded-3xl p-7 text-white shadow-[0_14px_34px_-14px_rgba(27,33,80,.55)]"
            style={{ background: "linear-gradient(160deg,#1B2150 0%,#2E3480 100%)" }}
          >
            <div className="text-[13px] font-extrabold text-[#E8B98F]">آزمون خودشناسی عمیق</div>
            <h2 className="text-[22px] leading-[1.6] font-extrabold text-pretty">
              تصویر کامل‌تری از خودت، فراتر از آنچه از خودت میدانی
            </h2>
            <ul className="flex flex-col gap-1.5">
              {WEB_DEEP_POINTS.map((point) => (
                <li key={point} className="flex gap-2.5 text-sm leading-[1.9]">
                  <Check
                    size={16}
                    strokeWidth={2.4}
                    className="mt-[5px] flex-none text-[#E8B98F]"
                  />
                  <span>{point}</span>
                </li>
              ))}
            </ul>
            <div className="mt-1.5 flex flex-col gap-2.5">
              <Link
                href="/paywall?source=explore_web_cta"
                className="rounded-full bg-white px-6 py-3.5 text-center text-[15px] font-extrabold text-[#1B2150] transition-shadow hover:shadow-[0_10px_24px_rgba(0,0,0,.25)]"
              >
                {deepCtaLabel}
              </Link>
              <div className="text-center text-[12.5px] text-[#A8AED6]">{deepStatusText}</div>
            </div>
          </div>

          <Link
            href="/test"
            className={`${WEB_CARD} ${WEB_CARD_HOVER} flex flex-col gap-2 px-6 py-[22px]`}
          >
            <div className="flex items-center justify-between gap-2.5">
              <div className="flex items-center gap-2">
                <span className="text-[15px] font-extrabold text-[#242A38]">
                  آزمون خودشناسی اولیه
                </span>
                <span className="text-primary rounded-full bg-[#EEF0FB] px-[9px] py-0.5 text-[11.5px] font-extrabold">
                  رایگان
                </span>
              </div>
              <span className="text-primary flex items-center gap-0.5 text-sm font-extrabold">
                {latest ? "انجام دوباره" : "شروع"} <ChevronLeft size={16} strokeWidth={2.5} />
              </span>
            </div>
            <p className="text-[13.5px] leading-[1.9] text-[#5D5C55]">
              ۳۰ جمله، حدود ۱۰ دقیقه. نمای اولیه‌ای از الگوهای شخصیتت.
            </p>
          </Link>
        </aside>
      </div>
    </main>
  );
}

function ExploreApp({ latestAttempt }: { latestAttempt: ReportAttemptHistoryItem | null }) {
  const isError = latestAttempt?.status === "error";
  const isGenerating = latestAttempt?.status === "generating";

  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col gap-[26px] px-[18px] pt-[22px] pb-14 md:hidden">
      <h1 className="text-center text-[22px] leading-[1.5] font-extrabold text-[#242A38]">کاوش</h1>

      {/* two primary goals, equal weight */}
      <div className="-mt-1.5 grid grid-cols-2 gap-2.5">
        <Link
          href="/history"
          className="flex min-h-[168px] flex-col items-start justify-between gap-4 rounded-[22px] bg-white p-[18px] text-right transition-transform active:scale-[.98]"
        >
          <div className="grid size-[50px] place-items-center rounded-2xl bg-[#F1EAF5]">
            <FileText size={25} strokeWidth={1.8} className="text-[#7A5490]" />
          </div>
          <div className="flex flex-col gap-[3px]">
            <div className="text-base font-extrabold text-[#242A38]">گزارش‌های من</div>
            <div className="text-[12.5px] text-[#6E6A5E]">همهٔ نتیجه‌های قبلی</div>
          </div>
        </Link>
        <Link
          href="/paywall?source=explore_card"
          className="flex min-h-[168px] flex-col items-start justify-between gap-4 rounded-[22px] p-[18px] text-right shadow-[0_10px_24px_-12px_rgba(27,33,80,.6)] transition-transform active:scale-[.98]"
          style={{ background: "linear-gradient(155deg,#1B2150 0%,#3A3D8F 75%,#6E5A9E 100%)" }}
        >
          <div className="grid size-[50px] place-items-center rounded-2xl bg-white/15">
            <Clock size={25} strokeWidth={1.8} className="text-white" />
          </div>
          <div className="flex flex-col gap-[3px]">
            <div className="text-base font-extrabold text-white">آزمون خودشناسی عمیق</div>
            <div className="text-[12.5px] text-white/80">گامی برای فراتر رفتن</div>
          </div>
        </Link>
      </div>

      {/* latest report: one tap */}
      {latestAttempt && (
        <div className="flex flex-col gap-3 rounded-[20px] bg-white px-[18px] py-4">
          <div className="flex items-center gap-3.5">
            <div className="flex min-w-0 flex-1 flex-col gap-0.5">
              <div className="text-xs font-bold text-[#8B8676]">
                آخرین گزارش · {isGenerating ? "در حال ساخته شدن…" : dateOf(latestAttempt)}
              </div>
              <div className="text-[15px] font-extrabold text-[#242A38]">
                {reportLabel(latestAttempt)}
              </div>
            </div>
            {!isError && (
              <Link
                href={
                  isGenerating
                    ? `/test/analysis?attemptId=${latestAttempt.attempt_id}`
                    : reportHref(latestAttempt)
                }
                className="flex min-h-11 flex-none items-center rounded-[13px] bg-[#242A38] px-5 py-2.5 text-sm font-extrabold text-white"
              >
                {isGenerating
                  ? "پیگیری"
                  : latestAttempt.status === "awaiting_payment"
                    ? "باز کردن"
                    : "مشاهده"}
              </Link>
            )}
          </div>
          {isError && (
            <>
              <p className="text-[13px] leading-[1.9] text-pretty text-[#5D5C55]">
                تولید این گزارش ناتمام ماند. می‌توانی با همان پاسخ‌ها دوباره درخواست بدهی.
              </p>
              <Link
                href={retryHref(latestAttempt)}
                className="flex min-h-12 w-full items-center justify-center gap-1.5 rounded-[14px] bg-[#B3261E] px-5 py-3 text-sm font-extrabold text-white"
              >
                <RefreshCw size={16} strokeWidth={2} />
                تولید دوبارهٔ گزارش
              </Link>
            </>
          )}
        </div>
      )}

      <Link
        href="/test"
        className="flex min-h-[76px] items-center gap-3.5 rounded-[20px] bg-white px-[18px] py-4 text-right transition-transform active:scale-[.98]"
      >
        <div className="grid size-[46px] flex-none place-items-center rounded-[15px] bg-[#E9EBF8]">
          <ClipboardCheck size={22} strokeWidth={1.8} className="text-primary" />
        </div>
        <div className="flex min-w-0 flex-1 flex-col gap-[3px]">
          <div className="text-[15px] font-extrabold text-[#242A38]">آزمون خودشناسی اولیه</div>
          <div className="text-[12.5px] text-[#6E6A5E]">پاسخ به ۳۰ جمله · حدود ۱۰ دقیقه</div>
        </div>
        <div className="text-primary flex flex-none items-center gap-0.5 text-[13.5px] font-extrabold">
          شروع <ChevronLeft size={15} strokeWidth={2.5} />
        </div>
      </Link>
    </main>
  );
}

export function ExploreView({
  history,
  deepTaken,
}: {
  history: ReportAttemptHistoryItem[];
  deepTaken: boolean;
}) {
  const deepStatusText = deepTaken ? "گزارش عمیقت آماده است" : "۳۰ ویژگی شخصیتی + گفتگوی تخصصی";

  return (
    <>
      <ExploreApp latestAttempt={history[0] ?? null} />
      <ExploreWeb history={history} deepTaken={deepTaken} deepStatusText={deepStatusText} />
    </>
  );
}
