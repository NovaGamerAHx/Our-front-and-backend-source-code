"use client";

import { Download } from "lucide-react";
import Image from "next/image";
import { TrackedLink } from "@/components/analytics/tracked-link";
import { DIRECT_DOWNLOAD_HREF } from "@/lib/constants/app-download";
import { ChatDemo } from "./chat-demo";
import { Meter } from "./meter";
import { Reveal } from "./reveal";
import { StepTimeline } from "./step-timeline";

// Landing v2 §1a. The Cafe Bazaar target is still a placeholder per the design handoff -- wire it
// to the real listing URL once it exists.
const CAFEBAZAAR_HREF = "#";

const REPORT_STATS = [
  {
    value: "۵",
    label: "بُعد از شخصیت، با تفسیر شخصی",
    from: "#FFF8EF",
    to: "#FBEFE1",
    border: "#F0DEC7",
    valueColor: "#8A5A26",
    labelColor: "#8A6B2E",
  },
  {
    value: "۳",
    label: "توانایی که می‌توانی به آن تکیه کنی",
    from: "#F6F1FA",
    to: "#EFE6F5",
    border: "#E4D8EE",
    valueColor: "#4A2F63",
    labelColor: "#5A3F76",
  },
  {
    value: "۴",
    label: "موقعیت آشنای رفتاری از زندگی روزمره‌ات",
    from: "#F6F1FA",
    to: "#EFE6F5",
    border: "#E4D8EE",
    valueColor: "#5A3F76",
    labelColor: "#6C4F86",
  },
  {
    value: "۳",
    label: "قدم کوچک برای آغاز راه",
    from: "#EDF7F1",
    to: "#E3F1E9",
    border: "#CFE7D9",
    valueColor: "#1E6B44",
    labelColor: "#2E8A5C",
  },
] as const;

const TRUST_METERS = [
  { label: "ذهن رشدگرا", pct: 84, level: "بالا" },
  { label: "مسئولیت‌پذیری", pct: 88, level: "بالا" },
  { label: "همدلی و همکاری", pct: 66, level: "میانه" },
  { label: "انرژی اجتماعی", pct: 58, level: "میانه" },
  { label: "ثبات هیجانی", pct: 72, level: "میانه" },
] as const;

const DEEP_TEST_CHIPS = [
  "۳۰ ویژگی شخصیتی",
  "الگوهای پنهان",
  "سبک تصمیم، رابطه و کار",
  "گفتگوی عمیق‌تر",
];

function EyebrowRule({ children }: { children: string }) {
  return (
    <div className="flex items-center gap-2.5">
      <div className="h-px w-[22px]" style={{ background: "#D9C6B2" }} />
      <div
        className="text-[clamp(12.5px,1.4vw,13.5px)] font-bold tracking-[.04em] whitespace-nowrap"
        style={{ color: "#5A3F76" }}
      >
        {children}
      </div>
    </div>
  );
}

function DownloadLinks() {
  return (
    <div className="mt-8 flex flex-wrap gap-4">
      <a
        href={DIRECT_DOWNLOAD_HREF}
        download
        className="flex items-center gap-1.5 text-[13.5px] font-bold transition-colors duration-200"
        style={{ color: "rgba(74,47,99,.78)" }}
      >
        <Download size={15} strokeWidth={2} />
        دانلود مستقیم اپلیکیشن
      </a>
      <a
        href={CAFEBAZAAR_HREF}
        className="flex items-center gap-1.5 text-[13.5px] font-bold transition-colors duration-200"
        style={{ color: "rgba(74,47,99,.78)" }}
      >
        <Image src="/landing/cafebazaar-icon.png" alt="" width={16} height={16} />
        دانلود از کافه‌بازار
      </a>
    </div>
  );
}

// The report mock card ("نمونهٔ واقعی گزارش") -- the only place on the landing besides the Deep
// Test promo that carries the emotional dusk-family gradient (here, its plum variant).
function ReportMockCard() {
  return (
    <div className="relative">
      <div
        className="absolute -top-3.5 -left-3.5 z-2 rounded-full px-4 py-1.5 text-[11px] font-extrabold whitespace-nowrap text-white"
        style={{ background: "#8E6BA8", boxShadow: "0 8px 20px rgba(90,60,110,.3)" }}
      >
        نمونهٔ واقعی گزارش
      </div>
      <div
        className="overflow-hidden rounded-[26px] bg-white"
        style={{ boxShadow: "0 24px 54px rgba(74,47,99,.16)" }}
      >
        <div
          className="relative flex flex-col gap-3.5 overflow-hidden px-6 pt-[26px] pb-7"
          style={{ background: "linear-gradient(165deg,#3B2450 0%,#6B4FA8 62%,#A88BC4 100%)" }}
        >
          <div
            className="pointer-events-none absolute -bottom-[60px] -left-[30px] size-[190px] rounded-full"
            style={{ background: "radial-gradient(circle, rgba(232,169,143,.32), transparent 70%)" }}
          />
          <div className="relative text-[10.5px] font-extrabold" style={{ color: "#D6C7E8" }}>
            پروفایل اولیهٔ شخصیت تو
          </div>
          <div className="relative text-base leading-[1.85] font-extrabold text-pretty text-white">
            به نظر می‌رسد تحلیل‌گری دقیق هستی که پیش از اقدام، دنبال اطمینان می‌گردد.
          </div>
        </div>
        <div className="flex flex-col gap-3.5 px-[22px] py-5">
          <Meter label="ذهن رشدگرا" pct={84} level="بالا" tone="plum" gradient="plum" size="lg" />
          <Meter
            label="انرژی اجتماعی"
            pct={58}
            level="متوسط"
            tone="warm"
            gradient="plum"
            size="lg"
            delay={120}
          />
          <div className="flex flex-col gap-1.5 rounded-2xl px-4 py-[15px]" style={{ background: "#4A2F63" }}>
            <div className="text-[10px] font-extrabold" style={{ color: "#D6C7E8" }}>
              قدم امروز
            </div>
            <div className="text-[12.5px] leading-[1.9] font-bold text-white">
              امروز عصر یک تصمیم کم‌ریسک را انتخاب کن و قدم بعدی‌اش را در یک جمله بنویس.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function LandingView() {
  const heroButtons = (
    <div className="mt-9 flex w-full max-w-[560px] flex-col gap-3 md:flex-row md:flex-wrap">
      <TrackedLink
        event="start_test_clicked"
        href="/test"
        className="flex min-h-[58px] flex-1 basis-[210px] items-center justify-center rounded-2xl px-6 text-center text-[clamp(14px,1.55vw,15.5px)] font-extrabold text-white transition-transform duration-200 hover:-translate-y-[3px]"
        style={{ background: "#4A2F63", boxShadow: "0 16px 36px rgba(74,47,99,.3)" }}
      >
        شروع آزمون خودشناسی
      </TrackedLink>
      <a
        href="#nemoone"
        className="flex min-h-[58px] flex-1 basis-[210px] items-center justify-center rounded-2xl border-[1.5px] px-6 text-center text-[clamp(14px,1.55vw,15.5px)] font-bold transition-colors duration-200"
        style={{ borderColor: "rgba(74,47,99,.45)", color: "#4A2F63" }}
      >
        نمونه‌ای از روایت فرامن
      </a>
    </div>
  );

  return (
    <main className="hidden flex-1 flex-col md:flex">
      {/* ================= HERO ================= */}
      {/* md:h-[min(100vh,820px)], not vh -- vh is pinned to the viewport's largest possible
          size (toolbar collapsed), so on a tablet browser with a collapsible chrome (e.g. iPad
          Safari) the hero renders taller than what's actually visible. */}
      <section className="bg-background relative flex min-h-[90dvh] overflow-hidden md:h-[min(100vh,820px)] md:min-h-0">
        <div className="relative z-2 mx-auto flex w-full max-w-[1200px] items-center gap-6 px-6 py-9 md:items-stretch md:gap-[clamp(16px,3vw,48px)] md:px-7 md:pt-[clamp(96px,10vw,124px)] md:pb-0">
          <div className="flex w-full flex-col items-start gap-0 py-3.5 md:flex-[0_1_560px] md:min-w-[min(100%,300px)] md:justify-center md:py-0 md:pb-[clamp(56px,6vw,80px)]">
            <h1
              className="mt-4 text-[28px] leading-[1.52] font-extrabold tracking-[-.01em] text-pretty md:max-w-[640px] md:text-[clamp(28px,4.6vw,47px)]"
              style={{ color: "#4A2F63" }}
            >
              فرامن، همان صدای آرامی که راه را می‌داند.
            </h1>
            <p
              className="mt-4 text-sm leading-[2.1] text-pretty md:mt-6 md:max-w-[660px] md:text-[clamp(14px,1.55vw,16.5px)]"
              style={{ color: "rgba(74,47,99,.88)" }}
            >
              فرامن توانایی‌هایت را برایت روشن می‌کند، گره‌هایت را نشانت می‌دهد و راهی پیش پایت
              می‌گذارد تا به آن کسی که می‌توانی باشی، نزدیک‌تر شوی.
            </p>
            {heroButtons}
            <DownloadLinks />
          </div>
          <div className="hidden min-w-0 flex-1 items-end justify-center overflow-visible md:flex">
            <Image
              src="/landing/hero-wide-art.webp"
              alt="تصویرسازی: دستی که پیکری رو به بالا را نگه می‌دارد"
              width={700}
              height={768}
              priority
              className="block h-auto w-full max-w-[600px] -translate-y-[90px]"
              style={{
                maskImage: "linear-gradient(to bottom, #000 86%, transparent 100%)",
                WebkitMaskImage: "linear-gradient(to bottom, #000 86%, transparent 100%)",
              }}
            />
          </div>
        </div>
      </section>

      {/* ================= REPORT SAMPLE ================= */}
      <section
        id="nemoone"
        className="mx-auto box-border flex w-full max-w-[1120px] flex-col gap-[clamp(28px,3.4vw,40px)] px-7 pt-[clamp(64px,7vw,96px)] pb-[clamp(40px,5vw,64px)]"
      >
        <Reveal className="flex flex-col items-start gap-0">
          <EyebrowRule>نمونه‌ای از روایت فرامن</EyebrowRule>
          <h2 className="mt-5 text-[clamp(22px,3.3vw,34px)] leading-[1.5] font-extrabold tracking-[-.01em] text-pretty">
            همراهی که تو را به اوج می‌رساند
          </h2>
        </Reveal>

        <Reveal
          className="shadow-card border-border flex flex-wrap-reverse items-center gap-[clamp(28px,3.6vw,44px)] rounded-[28px] border bg-white p-[clamp(24px,3vw,38px)]"
        >
          {/* narrative */}
          <div className="flex min-w-[min(100%,300px)] flex-[1_1_380px] flex-col gap-5">
            <div className="grid grid-cols-2 gap-2.5">
              {REPORT_STATS.map((stat) => (
                <div
                  key={stat.label}
                  className="flex items-center gap-2.5 rounded-[14px] border px-[13px] py-2.5"
                  style={{
                    background: `linear-gradient(160deg, ${stat.from}, ${stat.to})`,
                    borderColor: stat.border,
                  }}
                >
                  <div className="text-lg font-black" style={{ color: stat.valueColor }}>
                    {stat.value}
                  </div>
                  <div
                    className="text-[11.5px] leading-[1.6] font-bold text-pretty"
                    style={{ color: stat.labelColor }}
                  >
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
            <div className="text-[clamp(17px,2.1vw,21px)] leading-[1.9] font-extrabold text-pretty">
              «تو توان رفتن را داری، آنچه دشوار است، نخستین قدم است.»
            </div>
            <p className="m-0 text-sm leading-[2.2] text-pretty" style={{ color: "#3C4150" }}>
              وقتی تصمیمی برایت اهمیت دارد، ذهنت پیش از هر قدم دنبال اطمینان بیشتری می‌گردد. همین
              دقت است که کارت را سنجیده می‌کند. اما گاهی، حتی وقتی همه‌چیز را می‌دانی، آغاز را به
              فردا می‌سپاری — و این گره، با تصمیمی کوچک باز می‌شود.
            </p>
            <TrackedLink
              event="start_test_clicked"
              href="/test"
              className="flex items-center gap-1.5 text-sm font-extrabold transition-colors duration-200"
              style={{ color: "#6B4FA8" }}
            >
              ادامه‌ی روایت خودت را بخوان<span className="text-base">←</span>
            </TrackedLink>
          </div>

          {/* report mock */}
          <Reveal delay={100} className="min-w-[min(100%,300px)] flex-[0_1_400px]">
            <ReportMockCard />
          </Reveal>
        </Reveal>
      </section>

      {/* ================= AFTER REPORT: CHAT (primary) + STEPS ================= */}
      <section className="mx-auto box-border flex w-full max-w-[1120px] flex-col gap-[clamp(24px,3vw,34px)] px-7 py-[clamp(56px,7vw,88px)]">
        <Reveal className="flex flex-col items-start gap-0">
          <EyebrowRule>پس از گزارش</EyebrowRule>
          <h2 className="mt-5 text-[clamp(22px,3.3vw,34px)] leading-[1.5] font-extrabold tracking-[-.01em] text-pretty">
            گزارشت، آغاز گفتگوی تو برای فراتر رفتن از امروزت است
          </h2>
        </Reveal>

        <div className="flex flex-wrap items-stretch gap-4.5">
          {/* primary: chat */}
          <Reveal
            className="flex min-w-[min(100%,300px)] flex-[2_1_520px] flex-col gap-5 rounded-[28px] border p-[clamp(22px,3vw,34px)]"
            style={{
              background: "linear-gradient(160deg,#F9F6FC,#EFE6F5)",
              borderColor: "#E4D8EE",
              boxShadow: "0 10px 30px rgba(90,60,110,.08)",
            }}
          >
            <div className="flex items-center gap-3.5">
              <div
                className="grid size-[50px] flex-none place-items-center rounded-[17px] bg-white"
                style={{ boxShadow: "0 4px 14px rgba(90,60,110,.12)" }}
              >
                <svg
                  width="25"
                  height="25"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="#6B4FA8"
                  strokeWidth="1.9"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M20 11.5a7.5 7.5 0 0 1-10.9 6.7L4.5 19.5l1.3-4.6A7.5 7.5 0 1 1 20 11.5Z" />
                </svg>
              </div>
              <div className="flex flex-col gap-1">
                <div className="text-[11.5px] font-extrabold" style={{ color: "#5A3F76" }}>
                  گفتگو
                </div>
                <div className="text-[clamp(18px,2.5vw,24px)] leading-[1.5] font-extrabold text-pretty">
                  هر جای راه که بودی، بهت گوش می‌دیم
                </div>
              </div>
            </div>
            <p className="text-[clamp(13px,1.45vw,14.5px)] leading-[2.1] text-pretty" style={{ color: "#5D5C55" }}>
              گفتگویی که تو را می‌شناسد: از گزارشت خبر دارد، حرف‌هایت یادش می‌ماند و هر بار کمکت می‌کند یک قدم جلوتر بروی.
            </p>
            <ChatDemo />
          </Reveal>

          {/* secondary: step by step */}
          <Reveal
            delay={120}
            className="flex min-w-[min(100%,280px)] flex-[1_1_300px] flex-col gap-4 rounded-[28px] border p-[clamp(20px,2.6vw,28px)]"
            style={{
              background: "linear-gradient(160deg,#FFF8EF,#FBEFE1)",
              borderColor: "#F0DEC7",
            }}
          >
            <div className="flex flex-col gap-1.5">
              <div className="text-[11.5px] font-extrabold" style={{ color: "#B4703A" }}>
                قدم‌به‌قدم
              </div>
              <div className="text-[clamp(16px,1.9vw,18px)] leading-[1.7] font-extrabold text-pretty">
                هر قدم، راه قدم بعدی را باز می‌کند
              </div>
            </div>
            <p className="text-[12.5px] leading-[2.05] text-pretty" style={{ color: "#5D5C55" }}>
              هر توصیه‌ی گزارشت به قدمی کوچک و زمان‌دار تبدیل می‌شود.
            </p>
            <StepTimeline />
            <div className="mt-auto text-[11.5px] leading-[1.95] text-pretty" style={{ color: "#8B8676" }}>
              «نشد» هم یک پاسخ است. فرامن می‌پرسد چه چیزی مانعت شد و قدم بعدی را بهتر می‌چیند.
            </div>
          </Reveal>
        </div>
      </section>

      {/* ================= DEEP TEST + TRUST ================= */}
      <section className="mx-auto box-border w-full max-w-[1120px] px-7 py-[clamp(56px,7vw,88px)]">
        <Reveal
          className="relative flex flex-col gap-[clamp(20px,2.4vw,28px)] overflow-hidden rounded-[28px] p-[clamp(28px,4vw,48px)_clamp(24px,3.6vw,40px)]"
          style={{ background: "linear-gradient(150deg, #2C1E3F 0%, #5A3F76 55%, #C98F9B 100%)" }}
        >
          <div
            className="pointer-events-none absolute -top-[70px] -left-[70px] size-[300px] rounded-full"
            style={{
              background: "radial-gradient(circle, rgba(232,169,143,.35), transparent 70%)",
              animation: "fmPulse 11s ease-in-out infinite",
            }}
          />
          <div className="relative mx-auto flex max-w-[700px] flex-col items-center gap-4.5 text-center">
            <div className="rounded-full border border-white/26 bg-white/16 px-[15px] py-[7px] text-[11.5px] font-extrabold whitespace-nowrap text-white">
              پروفایل توسعهٔ فردی
            </div>
            <div className="text-[clamp(24px,3.6vw,36px)] leading-[1.5] font-extrabold text-pretty text-white">
              آنچه از خودت پنهان مانده
            </div>
            <p className="m-0 text-[clamp(13.5px,1.7vw,15px)] leading-[2.05] text-pretty text-white/90">
              گزارش تکمیلی سراغ لایه‌ای می‌رود که تست کوتاه به آن نمی‌رسد: روی دیگر
              توانایی‌هایت، الگوهای پنهانت و اینکه در تصمیم، رابطه، کار و فشار واقعاً چگونه عمل می‌کنی.
            </p>
          </div>
          <div className="relative mx-auto grid w-full max-w-[940px] grid-cols-[repeat(auto-fit,minmax(min(100%,190px),1fr))] gap-2.5">
            {DEEP_TEST_CHIPS.map((chip) => (
              <div
                key={chip}
                className="flex min-h-[52px] flex-col items-center justify-center rounded-[15px] border border-white/30 bg-white/17 px-3.5 py-2.5 text-center text-[clamp(12.5px,1.35vw,13.5px)] font-extrabold text-white"
              >
                {chip}
              </div>
            ))}
          </div>
          <div className="relative flex flex-col items-center gap-2.5">
            <a
              href="/paywall?source=landing"
              className="rounded-2xl bg-white px-7 py-4 text-sm font-extrabold whitespace-nowrap transition-transform duration-200 hover:-translate-y-[3px]"
              style={{ color: "#4A2F63" }}
            >
              شروع تست تکمیلی
            </a>
          </div>
        </Reveal>

        <Reveal
          className="shadow-card border-border mt-[clamp(40px,5vw,64px)] flex flex-wrap items-center gap-[clamp(24px,3.4vw,40px)] rounded-[26px] border bg-white p-[clamp(22px,3.4vw,38px)]"
        >
          <div className="flex min-w-[min(100%,260px)] flex-[1_1_320px] flex-col gap-3.5">
            <div className="text-xs font-extrabold tracking-[.04em]" style={{ color: "#5A3F76" }}>
              چرا می‌توانی به آن تکیه کنی
            </div>
            <div className="text-[clamp(20px,2.9vw,28px)] leading-[1.55] font-extrabold text-pretty">
              اینجا کسی تو را قضاوت نمی‌کند.
            </div>
            <p className="m-0 text-sm leading-[2.1]" style={{ color: "#5D5C55" }}>
              پرسش‌ها بر پایه پنج عاملی بنا شده‌اند که سال‌ها در پژوهش‌های شخصیت آزموده شده‌اند.
              نتیجه تصویری است از اینکه همین روزها چگونه عمل می‌کنی.
            </p>
            <div
              className="rounded-2xl border px-[17px] py-[15px] text-sm leading-[2] font-bold"
              style={{ background: "#FBF3E4", borderColor: "#EFD9AE", color: "#8A6B2E" }}
            >
              فرامن ابزار خودشناسی و رشد فردی است، نه تشخیص یا درمان.
            </div>
          </div>
          <div className="flex min-w-[min(100%,260px)] flex-[1_1_380px] flex-col gap-2.5">
            {TRUST_METERS.map((meter, i) => (
              <div
                key={meter.label}
                className="rounded-[18px] border px-4.5 py-[15px]"
                style={{ borderColor: "#F0E9DA", background: "#FBF8F1" }}
              >
                <Meter {...meter} tone="plum" gradient="plum" size="lg" delay={i * 100} />
              </div>
            ))}
          </div>
        </Reveal>
      </section>

      {/* ================= FINAL CTA ================= */}
      <section className="mx-auto box-border w-full max-w-[1120px] px-7 pt-[clamp(56px,7vw,88px)] pb-[clamp(72px,8vw,104px)]">
        <Reveal
          className="relative flex flex-col items-center gap-4 overflow-hidden rounded-[28px] p-[clamp(34px,4.6vw,56px)_clamp(24px,3.4vw,44px)] text-center"
          style={{ background: "linear-gradient(165deg,#3B2450 0%,#6B4FA8 55%,#A88BC4 100%)" }}
        >
          <div
            className="pointer-events-none absolute bottom-[-140px] left-[12%] size-[340px] rounded-full"
            style={{
              background: "radial-gradient(circle, rgba(232,169,143,.42), transparent 70%)",
              animation: "fmPulse 10s ease-in-out infinite",
            }}
          />
          <div className="relative max-w-[620px] text-[clamp(21px,3.4vw,34px)] leading-[1.5] font-extrabold text-pretty text-white">
            از «من» تا «فرامن»، یک قدم فاصله است.
          </div>
          <div className="relative max-w-[460px] text-[clamp(15px,1.9vw,18px)] leading-[1.9] text-white/92">
            شناختن خودت، نخستین قدم است برای فراتر رفتن از اینجا که ایستاده‌ای.
          </div>
          <TrackedLink
            event="start_test_clicked"
            href="/test"
            className="relative mt-1.5 rounded-[18px] bg-white px-10 py-[18px] text-[clamp(14px,1.7vw,16px)] font-extrabold transition-transform duration-200 hover:-translate-y-[3px]"
            style={{ color: "#4A2F63", boxShadow: "0 14px 34px rgba(74,47,99,.28)" }}
          >
            شروع تست خودشناسی
          </TrackedLink>
        </Reveal>
        <div className="relative mt-[22px] flex flex-wrap items-center justify-center gap-2 text-center">
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="rgba(255,255,255,.72)"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="flex-none"
          >
            <rect x="4.5" y="10.5" width="15" height="10" rx="2.2" />
            <path d="M8 10.5V7.5a4 4 0 0 1 8 0v3" />
          </svg>
          <div className="max-w-[520px] text-[12.5px] leading-[1.9]" style={{ color: "#5A3F76" }}>
            پاسخ‌هایت فقط برای ساختن گزارش خودت استفاده می‌شوند و محرمانه می‌مانند.
          </div>
        </div>
      </section>
    </main>
  );
}
