// Landing v2 §1a "قدم‌به‌قدم" vertical timeline -- mirrors the Phase-3 step lifecycle
// (قدم امروز → یادآوری → انجامش دادی؟ → چطور بود؟ → قدم بعدی در گفتگو). Shared by the web
// landing and app-mode home so the two stay in sync (README §1a).
function Node({ last = false }: { last?: boolean }) {
  return (
    <div className="flex w-5 flex-none flex-col items-center">
      <div className="mt-1.5 size-[9px] flex-none rounded-full" style={{ background: "#E8B98F" }} />
      {!last && (
        <div className="min-h-[18px] w-[1.5px] flex-1" style={{ background: "#EFD9AE" }} />
      )}
    </div>
  );
}

export function StepTimeline() {
  return (
    <div className="flex flex-col gap-0">
      <div className="flex items-stretch gap-3">
        <Node />
        <div className="pb-3.5 text-[12.5px] leading-[1.7] font-bold" style={{ color: "#5D4F3C" }}>
          قدم امروز
        </div>
      </div>
      <div className="flex items-stretch gap-3">
        <Node />
        <div className="pb-3.5 text-[12.5px] leading-[1.7] font-bold" style={{ color: "#5D4F3C" }}>
          یادآوری پیش از مهلت
        </div>
      </div>
      <div className="flex items-stretch gap-3">
        <Node />
        <div className="flex flex-1 flex-col gap-2 pb-3.5">
          <div className="text-[12.5px] leading-[1.7] font-bold" style={{ color: "#5D4F3C" }}>
            انجامش دادی؟
          </div>
          <div className="flex flex-wrap gap-1.5">
            {["انجام دادم", "نیمه‌کاره", "نشد"].map((label) => (
              <div
                key={label}
                className="rounded-full border bg-white px-[11px] py-[5px] text-[10.5px] font-bold"
                style={{ borderColor: "#EFD9AE", color: "#8A6B2E" }}
              >
                {label}
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="flex items-stretch gap-3">
        <div className="flex w-5 flex-none flex-col items-center">
          <div className="mt-1.5 size-[9px] flex-none rounded-full" style={{ background: "#E8B98F" }} />
          <div
            className="min-h-[18px] w-[1.5px] flex-1"
            style={{ background: "linear-gradient(#EFD9AE,#C9B5E0)" }}
          />
        </div>
        <div className="pb-3.5 text-[12.5px] leading-[1.7] font-bold" style={{ color: "#5D4F3C" }}>
          چطور بود؟
        </div>
      </div>
      <div className="flex items-start gap-3">
        <div className="flex w-5 flex-none flex-col items-center">
          <div
            className="mt-1 size-[13px] flex-none rounded-full"
            style={{ background: "#6B4FA8", boxShadow: "0 0 0 4px rgba(107,79,168,.16)" }}
          />
        </div>
        <div
          className="flex flex-1 items-center gap-2 rounded-2xl border-[1.5px] px-3.5 py-3"
          style={{ background: "#F3EEF7", borderColor: "#DDD0EC" }}
        >
          <div className="flex-1 text-[12.5px] leading-[1.7] font-extrabold" style={{ color: "#4A2F63" }}>
            قدم بعدی، در گفتگو
          </div>
          <div className="flex-none text-[17px] font-extrabold" style={{ color: "#6B4FA8" }}>
            →
          </div>
        </div>
      </div>
    </div>
  );
}
