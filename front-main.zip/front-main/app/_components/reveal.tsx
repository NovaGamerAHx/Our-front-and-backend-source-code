"use client";

import type { CSSProperties, ReactNode } from "react";
import { useInView } from "./use-in-view";

const EASE = "cubic-bezier(.2,.8,.2,1)";

/** Fade+rise wrapper for the Landing v2 scroll-reveal motion (§1a). Stagger siblings via `delay`. */
export function Reveal({
  delay = 0,
  className,
  style,
  children,
}: {
  delay?: number;
  className?: string;
  style?: CSSProperties;
  children: ReactNode;
}) {
  const { ref, inView } = useInView<HTMLDivElement>();

  return (
    <div
      ref={ref}
      className={className}
      style={{
        ...style,
        opacity: inView ? 1 : 0,
        transform: inView ? "translateY(0)" : "translateY(22px)",
        transition: `opacity .7s ${EASE} ${delay}ms, transform .7s ${EASE} ${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}
