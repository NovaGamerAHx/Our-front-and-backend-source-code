"use client";

import { useEffect, useRef, useState } from "react";

/**
 * Landing v2 scroll-reveal spec: fires once when the element is >=15% visible, then
 * disconnects (never re-hides on scroll-out). Falls back to already-visible when
 * IntersectionObserver isn't available.
 */
export function useInView<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  // Always false on the first render, server and client alike -- `typeof IntersectionObserver`
  // reads differently in each environment (no such global in Node), and seeding state from that
  // check produced a real SSR/client mismatch (server painted the filled bar, client's first
  // paint painted it empty) that React flagged as a hydration error. The unsupported-browser
  // fallback below still runs, just one tick later as a normal post-mount state update instead
  // of baked into the initial render.
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === "undefined") {
      setInView(true);
      return;
    }
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
          observer.disconnect();
        }
      },
      { threshold: 0.15, rootMargin: "0px 0px -8% 0px" },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return { ref, inView };
}
