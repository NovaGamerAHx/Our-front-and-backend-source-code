import { Download } from "lucide-react";
import Image from "next/image";
import { TrackedLink } from "@/components/analytics/tracked-link";
import { DIRECT_DOWNLOAD_HREF } from "@/lib/constants/app-download";
import { ChatDemo } from "./chat-demo";
import { Meter } from "./meter";
import { StepTimeline } from "./step-timeline";

// Landing v2 §1a "App-mode home" -- a mobile-native mirror of the web landing flow (same hero,
// report sample, after-report chat + steps, deep test and trust content), not a separate
// information architecture. Shown on small viewports in place of the scrolling web flow
// (LandingView). The Cafe Bazaar target is still a placeholder per the design handoff.
const CAFEBAZAAR_HREF = "#";

const STAT_CHIPS = [
  {
    value: "۵",
    label: "بُعد از شخصیت، با تفسیر شخصی",
    from: "#FFF8EF",
    to: "#FBEFE1",
    border: "#F0DEC7",
    valueColor: "#8A5A26",
    labelColor: "#8A6B2E",
  },
  {
    value: "۳",
    label: "توانایی که می‌توانی به آن تکیه کنی",
    from: "#F6F1FA",
    to: "#EFE6F5",
    border: "#E4D8EE",
    valueColor: "#4A2F63",
    labelColor: "#5A3F76",
  },
  {
    value: "۴",
    label: "موقعیت آشنای رفتاری از زندگی روزمره‌ات",
    from: "#F6F1FA",
    to: "#EFE6F5",
    border: "#E4D8EE",
    valueColor: "#5A3F76",
    labelColor: "#6C4F86",
  },
  {
    value: "۳",
    label: "قدم کوچک برای آغاز راه",
    from: "#EDF7F1",
    to: "#E3F1E9",
    border: "#CFE7D9",
    valueColor: "#1E6B44",
    labelColor: "#2E8A5C",
  },
] as const;

const TRUST_METERS = [
  { label: "ذهن رشدگرا", pct: 84, level: "بالا" },
  { label: "مسئولیت‌پذیری", pct: 88, level: "بالا" },
  { label: "همدلی و همکاری", pct: 66, level: "میانه" },
  { label: "انرژی اجتماعی", pct: 58, level: "میانه" },
  { label: "ثبات هیجانی", pct: 72, level: "میانه" },
] as const;

const DEEP_TEST_CHIPS = ["۳۰ ویژگی شخصیتی", "الگوهای پنهان", "سبک تصمیم، رابطه و کار", "گفتگوی عمیق‌تر"];

function DownloadLinks() {
  return (
    <div className="mt-[22px] flex flex-wrap gap-4">
      <a
        href={DIRECT_DOWNLOAD_HREF}
        download
        className="flex items-center gap-1.5 text-[13.5px] font-bold"
        style={{ color: "rgba(74,47,99,.78)" }}
      >
        <Download size={15} strokeWidth={2} />
        دانلود مستقیم اپلیکیشن
      </a>
      <a
        href={CAFEBAZAAR_HREF}
        className="flex items-center gap-1.5 text-[13.5px] font-bold"
        style={{ color: "rgba(74,47,99,.78)" }}
      >
        <Image src="/landing/cafebazaar-icon.png" alt="" width={16} height={16} />
        دانلود از کافه‌بازار
      </a>
    </div>
  );
}

export function AppHomeView() {
  return (
    <main className="flex flex-1 flex-col md:hidden">
      {/* ================= HERO ================= */}
      <section className="bg-background flex flex-col overflow-hidden px-[18px] pt-[58px] pb-7">
        <Image
          src="/landing/hero-hand-hq.webp"
          alt="تصویرسازی: دستی که پیکری رو به بالا را نگه می‌دارد"
          width={1094}
          height={910}
          priority
          className="mx-auto block h-auto w-[min(68%,280px)]"
          style={{
            maskImage: "linear-gradient(to bottom, #000 82%, transparent 100%)",
            WebkitMaskImage: "linear-gradient(to bottom, #000 82%, transparent 100%)",
            animation: "fmRise .8s ease both",
          }}
        />
        <div
          className="mt-2 flex flex-col items-start gap-0"
          style={{ animation: "fmRise .6s ease both" }}
        >
          <div className="text-[26px] leading-[1.55] font-extrabold text-pretty" style={{ color: "#4A2F63" }}>
            فرامن، همان صدای آرامی که راه را می‌داند.
          </div>
          <div className="mt-4 text-[13.5px] leading-[2.05] text-pretty" style={{ color: "rgba(74,47,99,.88)" }}>
            فرامن توانایی‌هایت را برایت روشن می‌کند، گره‌هایت را نشانت می‌دهد و راهی پیش پایت
            می‌گذارد تا به آن کسی که می‌توانی باشی، نزدیک‌تر شوی.
          </div>
          <div className="mt-6 flex w-full flex-col gap-2.5">
            <TrackedLink
              event="start_test_clicked"
              href="/test"
              className="flex min-h-[54px] items-center justify-center rounded-2xl px-5 text-center text-[15px] font-extrabold text-white"
              style={{ background: "#4A2F63", boxShadow: "0 12px 28px rgba(74,47,99,.3)" }}
            >
              شروع آزمون خودشناسی
            </TrackedLink>
            <a
              href="#nemoone-mobile"
              className="flex min-h-[54px] items-center justify-center rounded-2xl border-[1.5px] px-5 text-center text-[14.5px] font-bold"
              style={{ borderColor: "rgba(74,47,99,.45)", color: "#4A2F63" }}
            >
              نمونه‌ای از روایت فرامن
            </a>
          </div>
          <DownloadLinks />
        </div>
      </section>

      {/* ================= REPORT SAMPLE ================= */}
      {/* Every App Home section below uses the design handoff's literal 44px-top/26px-bottom
          padding, giving a consistent ~70px gap between sections. */}
      <section id="nemoone-mobile" className="flex flex-col gap-4.5 px-[18px] pt-[44px] pb-[26px]">
        <div className="flex flex-col items-start gap-0">
          <div className="flex items-center gap-2.5">
            <div className="h-px w-[22px]" style={{ background: "#D9C6B2" }} />
            <div className="text-xs font-bold tracking-[.04em]" style={{ color: "#5A3F76" }}>
              نمونه‌ای از روایت فرامن
            </div>
          </div>
          <div className="mt-3.5 text-xl leading-[1.55] font-extrabold text-pretty" style={{ color: "#4A2F63" }}>
            همراهی که تو را به اوج می‌رساند
          </div>
        </div>
        <div
          className="flex flex-col gap-4.5 rounded-3xl border bg-white p-[18px]"
          style={{ borderColor: "#EDE7DA", boxShadow: "0 6px 20px rgba(80,70,40,.06)" }}
        >
          <div className="grid grid-cols-2 gap-2.5">
            {STAT_CHIPS.map((chip) => (
              <div
                key={chip.label}
                className="flex items-center gap-2.5 rounded-[14px] border px-3 py-2.5"
                style={{ background: `linear-gradient(160deg, ${chip.from}, ${chip.to})`, borderColor: chip.border }}
              >
                <div className="text-[17px] font-black" style={{ color: chip.valueColor }}>
                  {chip.value}
                </div>
                <div className="text-[11px] leading-[1.6] font-bold" style={{ color: chip.labelColor }}>
                  {chip.label}
                </div>
              </div>
            ))}
          </div>
          <div className="text-base leading-[1.9] font-extrabold text-pretty" style={{ color: "#4A2F63" }}>
            «تو توان رفتن را داری، آنچه دشوار است، نخستین قدم است.»
          </div>
          <p className="m-0 text-[13px] leading-[2.15] text-pretty" style={{ color: "#3C4150" }}>
            وقتی تصمیمی برایت اهمیت دارد، ذهنت پیش از هر قدم دنبال اطمینان بیشتری می‌گردد. همین دقت
            است که کارت را سنجیده می‌کند. اما گاهی، حتی وقتی همه‌چیز را می‌دانی، آغاز را به فردا
            می‌سپاری — و این گره، با تصمیمی کوچک باز می‌شود.
          </p>
          <TrackedLink
            event="start_test_clicked"
            href="/test"
            className="flex items-center gap-1.5 text-[13px] font-extrabold"
            style={{ color: "#6B4FA8" }}
          >
            ادامه‌ی روایت خودت را بخوان<span className="text-[15px]">←</span>
          </TrackedLink>

          <div className="relative mt-1">
            <div
              className="absolute -top-2.5 left-3 z-2 rounded-full px-3.5 py-1.5 text-[10.5px] font-extrabold whitespace-nowrap text-white"
              style={{ background: "#8E6BA8", boxShadow: "0 8px 20px rgba(90,60,110,.3)" }}
            >
              نمونهٔ واقعی گزارش
            </div>
            <div className="overflow-hidden rounded-[22px] bg-white" style={{ boxShadow: "0 14px 34px rgba(74,47,99,.14)" }}>
              <div
                className="flex flex-col gap-2 px-[18px] py-5"
                style={{ background: "linear-gradient(165deg,#3B2450 0%,#6B4FA8 62%,#A88BC4 100%)" }}
              >
                <div className="text-[10px] font-extrabold" style={{ color: "#D6C7E8" }}>
                  پروفایل اولیهٔ شخصیت تو
                </div>
                <div className="text-sm leading-[1.85] font-extrabold text-pretty text-white">
                  به نظر می‌رسد تحلیل‌گری دقیق هستی که پیش از اقدام، دنبال اطمینان می‌گردد.
                </div>
              </div>
              <div className="flex flex-col gap-3 px-[18px] py-4">
                <Meter label="ذهن رشدگرا" pct={84} level="بالا" tone="plum" gradient="plum" />
                <Meter label="انرژی اجتماعی" pct={58} level="متوسط" tone="warm" gradient="plum" delay={120} />
                <div className="flex flex-col gap-1.5 rounded-2xl p-3.5" style={{ background: "#4A2F63" }}>
                  <div className="text-[10px] font-extrabold" style={{ color: "#D6C7E8" }}>
                    قدم امروز
                  </div>
                  <div className="text-[11.5px] leading-[1.9] font-bold text-white">
                    امروز عصر یک تصمیم کم‌ریسک را انتخاب کن و قدم بعدی‌اش را در یک جمله بنویس.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ================= AFTER REPORT: CHAT + STEPS ================= */}
      <section className="flex flex-col gap-3.5 px-[18px] pt-[44px] pb-[26px]">
        <div className="flex flex-col items-start gap-0">
          <div className="flex items-center gap-2.5">
            <div className="h-px w-[22px]" style={{ background: "#D9C6B2" }} />
            <div className="text-xs font-bold tracking-[.04em]" style={{ color: "#5A3F76" }}>
              پس از گزارش
            </div>
          </div>
          <div className="mt-3.5 text-lg leading-[1.55] font-extrabold text-pretty" style={{ color: "#4A2F63" }}>
            گزارشت، آغاز گفتگوی تو برای فراتر رفتن از امروزت است
          </div>
        </div>

        <div
          className="flex flex-col gap-3.5 rounded-[24px] border p-[18px]"
          style={{ background: "linear-gradient(160deg,#F9F6FC,#EFE6F5)", borderColor: "#E4D8EE" }}
        >
          <div className="flex items-center gap-2.5">
            <div
              className="grid size-11 flex-none place-items-center rounded-[15px] bg-white"
              style={{ boxShadow: "0 4px 14px rgba(90,60,110,.12)" }}
            >
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6B4FA8" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
                <path d="M20 11.5a7.5 7.5 0 0 1-10.9 6.7L4.5 19.5l1.3-4.6A7.5 7.5 0 1 1 20 11.5Z" />
              </svg>
            </div>
            <div className="flex flex-col gap-0.5">
              <div className="text-[11px] font-extrabold" style={{ color: "#5A3F76" }}>
                گفتگو
              </div>
              <div className="text-base leading-[1.5] font-extrabold" style={{ color: "#4A2F63" }}>
                هر جای راه که بودی، بهت گوش می‌دیم
              </div>
            </div>
          </div>
          <p className="m-0 text-[12.5px] leading-[2.05] text-pretty" style={{ color: "#5D5C55" }}>
            درباره‌ی گزارشت بپرس، قدمی را که به حالت نمی‌خورد کنار بگذار، یا از کاری که انجام دادی
            یا نشد حرف بزن. فرامن آنچه از تو می‌داند را به یاد دارد و گفتگو را از همان‌جا ادامه
            می‌دهد.
          </p>
          <ChatDemo compactTabs />
        </div>

        <div
          className="flex flex-col gap-3.5 rounded-[24px] border p-[18px]"
          style={{ background: "linear-gradient(160deg,#FFF8EF,#FBEFE1)", borderColor: "#F0DEC7" }}
        >
          <div className="flex flex-col gap-1">
            <div className="text-[11px] font-extrabold" style={{ color: "#B4703A" }}>
              قدم‌به‌قدم
            </div>
            <div className="text-base leading-[1.65] font-extrabold" style={{ color: "#4A2F63" }}>
              هر قدم، راه قدم بعدی را باز می‌کند
            </div>
          </div>
          <p className="m-0 text-[12.5px] leading-[2.05] text-pretty" style={{ color: "#5D5C55" }}>
            هر توصیه‌ی گزارشت به قدمی کوچک و زمان‌دار تبدیل می‌شود.
          </p>
          <StepTimeline />
          <div className="text-[11.5px] leading-[1.95] text-pretty" style={{ color: "#8B8676" }}>
            «نشد» هم یک پاسخ است. فرامن می‌پرسد چه چیزی مانعت شد و قدم بعدی را بهتر می‌چیند.
          </div>
        </div>
      </section>

      {/* ================= DEEP TEST ================= */}
      <section className="px-[18px] pt-[44px] pb-[26px]">
        <div
          className="relative flex flex-col gap-4.5 overflow-hidden rounded-3xl p-[26px_18px]"
          style={{ background: "linear-gradient(150deg,#2C1E3F 0%,#5A3F76 55%,#C98F9B 100%)" }}
        >
          <div
            className="pointer-events-none absolute -top-[60px] -left-[60px] size-[220px] rounded-full"
            style={{ background: "radial-gradient(circle,rgba(232,169,143,.35),transparent 70%)" }}
          />
          <div className="relative flex flex-col items-center gap-3.5 text-center">
            <div className="rounded-full border border-white/26 bg-white/16 px-3.5 py-[7px] text-[11px] font-extrabold text-white">
              پروفایل توسعهٔ فردی
            </div>
            <div className="text-[22px] leading-[1.5] font-extrabold text-pretty text-white">
              آنچه از خودت پنهان مانده
            </div>
            <p className="m-0 text-[13px] leading-[2.05] text-pretty text-white/92">
              گزارش تکمیلی سراغ لایه‌ای می‌رود که تست کوتاه به آن نمی‌رسد: روی دیگر
              توانایی‌هایت، الگوهای پنهانت و اینکه در تصمیم، رابطه، کار و فشار واقعاً چگونه عمل می‌کنی.
            </p>
          </div>
          <div className="relative grid grid-cols-2 gap-2.5">
            {DEEP_TEST_CHIPS.map((chip) => (
              <div
                key={chip}
                className="flex min-h-[52px] flex-col items-center justify-center rounded-[15px] border border-white/30 bg-white/17 px-3.5 py-2.5 text-center text-[12.5px] font-extrabold text-white"
              >
                {chip}
              </div>
            ))}
          </div>
          <div className="relative flex justify-center">
            <a
              href="/paywall?source=home"
              className="flex min-h-[52px] items-center justify-center rounded-2xl bg-white px-7 text-sm font-extrabold"
              style={{ color: "#4A2F63" }}
            >
              شروع تست تکمیلی
            </a>
          </div>
        </div>
      </section>

      {/* ================= TRUST ================= */}
      <section className="flex flex-col gap-3 px-[18px] pt-[44px] pb-[26px]">
        <div
          className="flex flex-col gap-3.5 rounded-3xl border bg-white p-5"
          style={{ borderColor: "#EDE7DA", boxShadow: "0 6px 20px rgba(80,70,40,.06)" }}
        >
          <div className="text-[11.5px] font-extrabold tracking-[.04em]" style={{ color: "#5A3F76" }}>
            چرا می‌توانی به آن تکیه کنی
          </div>
          <div className="text-[19px] leading-[1.55] font-extrabold text-pretty" style={{ color: "#4A2F63" }}>
            اینجا کسی تو را قضاوت نمی‌کند.
          </div>
          <p className="m-0 text-[13px] leading-[2.1]" style={{ color: "#5D5C55" }}>
            پرسش‌ها بر پایه پنج عاملی بنا شده‌اند که سال‌ها در پژوهش‌های شخصیت آزموده شده‌اند.
            نتیجه تصویری است از اینکه همین روزها چگونه عمل می‌کنی.
          </p>
          <div
            className="rounded-2xl border px-[15px] py-[13px] text-[12.5px] leading-[1.95] font-bold"
            style={{ background: "#FBF3E4", borderColor: "#EFD9AE", color: "#8A6B2E" }}
          >
            فرامن ابزار خودشناسی و رشد فردی است، نه تشخیص یا درمان.
          </div>
          <div className="mt-0.5 flex flex-col gap-2.5">
            {TRUST_METERS.map((meter, i) => (
              <div
                key={meter.label}
                className="rounded-2xl border px-[15px] py-[13px]"
                style={{ borderColor: "#F0E9DA", background: "#FBF8F1" }}
              >
                <Meter {...meter} tone="plum" gradient="plum" delay={i * 100} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ================= FINAL CTA ================= */}
      <section className="px-[18px] pt-[44px] pb-[30px]">
        <div
          className="relative flex flex-col items-center gap-3 overflow-hidden rounded-3xl p-7 text-center"
          style={{ background: "linear-gradient(165deg,#3B2450 0%,#6B4FA8 55%,#A88BC4 100%)" }}
        >
          <div
            className="pointer-events-none absolute bottom-[-120px] left-[10%] size-[260px] rounded-full"
            style={{ background: "radial-gradient(circle,rgba(232,169,143,.42),transparent 70%)" }}
          />
          <div className="relative text-xl leading-[1.55] font-extrabold text-pretty text-white">
            از «من» تا «فرامن»، یک قدم فاصله است.
          </div>
          <div className="relative text-[13px] leading-[1.95] text-white/92">
            شناختن خودت، نخستین قدم است برای فراتر رفتن از اینجا که ایستاده‌ای.
          </div>
          <TrackedLink
            event="start_test_clicked"
            href="/test"
            className="relative mt-1 flex min-h-[54px] w-full items-center justify-center rounded-2xl bg-white px-7 text-[14.5px] font-extrabold"
            style={{ color: "#4A2F63", boxShadow: "0 12px 28px rgba(74,47,99,.28)" }}
          >
            شروع تست خودشناسی
          </TrackedLink>
        </div>
        <div className="mt-4 flex items-center justify-center gap-2 text-center">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8E6BA8" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="flex-none">
            <rect x="4.5" y="10.5" width="15" height="10" rx="2.2" />
            <path d="M8 10.5V7.5a4 4 0 0 1 8 0v3" />
          </svg>
          <div className="text-xs leading-[1.9]" style={{ color: "#5A3F76" }}>
            پاسخ‌هایت فقط برای ساختن گزارش خودت استفاده می‌شوند و محرمانه می‌مانند.
          </div>
        </div>
      </section>
    </main>
  );
}
