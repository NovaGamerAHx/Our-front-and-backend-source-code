"use client";

import { useState } from "react";

// Landing v2 §1a "After Report" chat-moment demo -- exact tab labels + scripted exchanges from
// the design handoff's `chatScript`/`renderVals`. Shared by the web landing and the app-mode
// home so the two surfaces can't drift out of sync (README: "keep the two in sync").
const TABS = [
  "راجع به گزارشم سوال دارم",
  "این قدم به من نمی‌خوره",
  "انجامش دادم، بعدش چی؟",
  "نشد. بیا حرف بزنیم",
] as const;

const CONVERSATIONS: readonly [string, string][] = [
  [
    "چرا نوشتی آغاز کردن برایم دشوار است؟",
    "چون در پاسخ‌هایت، پیش از هر تصمیم دنبال اطمینان بیشتری بودی. بیا ببینیم این الگو این هفته کجا خودش را نشان داده.",
  ],
  [
    "امروز عصر اصلاً وقتش را ندارم.",
    "پس بیا کوچک‌ترش کنیم؛ امشب پیش از خواب، فقط ده دقیقه.",
  ],
  [
    "انجامش دادم. قدم بعدی چیه؟",
    "حالا که یک تصمیم کوچک را بی‌معطلی گرفتی، وقتشه یک قدم فراتر بری.",
  ],
  [
    "نشد، باز عقبش انداختم.",
    "همین هم چیزی درباره‌ی تو می‌گوید. بگو چه چیزی جلویت را گرفت تا قدم بعدی را متناسب با همان بسازیم.",
  ],
];

// Default selection is chip index 2 (design spec) -- the one exchange that also reveals the step card.
const DEFAULT_INDEX = 2;
const STEP_REVEAL_INDEX = 2;

export function ChatDemo({ compactTabs = false }: { compactTabs?: boolean }) {
  const [active, setActive] = useState(DEFAULT_INDEX);
  const [fadeKey, setFadeKey] = useState(0);

  function pick(i: number) {
    if (i === active) return;
    setActive(i);
    setFadeKey((k) => k + 1);
  }

  function onKeyDown(e: React.KeyboardEvent, i: number) {
    if (e.key === "Enter" || e.key === " " || e.key === "Spacebar") {
      e.preventDefault();
      pick(i);
    }
  }

  const [userMsg, botMsg] = CONVERSATIONS[active];

  return (
    <div className="flex flex-col gap-3.5">
      <div
        role="tablist"
        className={compactTabs ? "flex gap-1.5 overflow-x-auto pb-0.5" : "flex flex-wrap gap-2"}
      >
        {TABS.map((label, i) => {
          const selected = i === active;
          return (
            <div
              key={label}
              role="tab"
              tabIndex={0}
              aria-selected={selected}
              onClick={() => pick(i)}
              onKeyDown={(e) => onKeyDown(e, i)}
              className={`flex min-h-10 cursor-pointer items-center rounded-full text-xs font-bold whitespace-nowrap transition-[background,color,box-shadow] duration-200 ${
                compactTabs ? "flex-none px-3.5 py-2.5" : "px-4 py-2.5"
              }`}
              style={{
                background: selected ? "#6B4FA8" : "#fff",
                color: selected ? "#fff" : "#5D5C55",
                boxShadow: selected ? "0 6px 16px rgba(107,79,168,.26)" : "inset 0 0 0 1px #E0DAEE",
              }}
            >
              {label}
            </div>
          );
        })}
      </div>

      <div
        key={fadeKey}
        className="flex min-h-[212px] flex-col gap-3 rounded-[22px] border p-4"
        style={{
          background: "rgba(255,255,255,.55)",
          borderColor: "#E7E2F0",
          animation: "fmFade .34s ease both",
        }}
      >
        <div
          className="max-w-[88%] self-start rounded-[18px_18px_6px_18px] px-4 py-3 text-[12.5px] leading-[1.95] text-white"
          style={{ background: "#6B4FA8" }}
        >
          {userMsg}
        </div>
        <div
          className="max-w-[92%] self-end rounded-[18px_18px_18px_6px] border bg-white px-4 py-3 text-[12.5px] leading-[1.95]"
          style={{ borderColor: "#E7E2F0", color: "#3C4150" }}
        >
          {botMsg}
        </div>
        {active === STEP_REVEAL_INDEX && (
          <div
            className="flex w-full flex-col gap-3 self-end rounded-[18px] border-[1.5px] bg-white p-4"
            style={{ borderColor: "#D8D0EC" }}
          >
            <div className="text-[12.5px] leading-[1.95] font-extrabold">
              امروز، یک کار پنج‌دقیقه‌ای را که مدام به بعد موکولش کرده‌ای، همین حالا تمام کن.
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                className="flex min-h-10 items-center rounded-full px-4 text-[11.5px] font-extrabold text-white transition-transform duration-200 hover:-translate-y-0.5"
                style={{ background: "#6B4FA8" }}
              >
                قبول دارم
              </button>
              <button
                type="button"
                className="flex min-h-10 items-center rounded-full border-[1.5px] px-4 text-[11.5px] font-bold transition-transform duration-200 hover:-translate-y-0.5"
                style={{ borderColor: "#E0DAEE", color: "#6C4F86" }}
              >
                یک پیشنهاد دیگر بده
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
