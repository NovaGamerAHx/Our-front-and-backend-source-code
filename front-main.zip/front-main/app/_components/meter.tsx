"use client";

import { useInView } from "./use-in-view";

type MeterTone = "primary" | "warm" | "plum";

const TONE_BADGE: Record<MeterTone, { bg: string; color: string }> = {
  primary: { bg: "#E9EBF8", color: "#2743C6" },
  warm: { bg: "#FBF3E4", color: "#8A6B2E" },
  plum: { bg: "#EFE9F7", color: "#6B4FA8" },
};

/**
 * Dimension meter whose fill animates in once scrolled into view (Landing v2 §1a `data-fill`).
 * `variant="row"` is the label/bar/badge inline layout (Science scorecard). `variant="card"` is
 * the stacked label+badge-over-bar layout used by the hero's sample-report mock.
 * `gradient="plum"` swaps the fill from the app's blue-purple bar to the landing's plum bar
 * (`#6B4FA8→#A88BC4`) -- the landing/app-home surfaces use the plum bar for every tone.
 */
export function Meter({
  label,
  pct,
  level,
  tone,
  delay = 0,
  size = "sm",
  variant = "row",
  gradient = "blue",
}: {
  label: string;
  pct: number;
  level: string;
  tone: MeterTone;
  delay?: number;
  size?: "sm" | "lg";
  variant?: "row" | "card";
  gradient?: "blue" | "plum";
}) {
  const { ref, inView } = useInView<HTMLDivElement>();
  const badge = TONE_BADGE[tone];

  const bar = (
    <div
      ref={ref}
      className={gradient === "blue" ? "bg-gradient-meter h-full rounded-full" : "h-full rounded-full"}
      style={{
        width: inView ? `${pct}%` : 0,
        transition: `width 1.2s cubic-bezier(.2,.8,.2,1) ${delay}ms`,
        ...(gradient === "plum" ? { background: "linear-gradient(90deg,#6B4FA8,#A88BC4)" } : {}),
      }}
    />
  );

  if (variant === "card") {
    return (
      <div
        className="border-border flex flex-col gap-2.5 rounded-2xl border bg-white"
        style={{ padding: "13px 14px" }}
      >
        <div className="flex items-center justify-between gap-2">
          <div className="text-[11.5px] font-extrabold">{label}</div>
          <div
            className="rounded-full text-[9.5px] font-extrabold"
            style={{ background: badge.bg, color: badge.color, padding: "3px 9px" }}
          >
            {level}
          </div>
        </div>
        <div className="bg-border h-[5px] overflow-hidden rounded-full">{bar}</div>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2.5">
      <div
        className={
          size === "lg"
            ? "w-[120px] flex-none text-[13.5px] font-extrabold"
            : "w-[84px] flex-none text-[11.5px] font-bold"
        }
      >
        {label}
      </div>
      <div
        className={`bg-border flex-1 overflow-hidden rounded-full ${size === "lg" ? "h-[9px]" : "h-[5px]"}`}
      >
        {bar}
      </div>
      <div
        className={`flex-none rounded-full text-center font-extrabold ${size === "lg" ? "w-[78px] py-[5px] text-[11px]" : "w-[54px] py-[3px] text-[10px]"}`}
        style={{ background: badge.bg, color: badge.color }}
      >
        {level}
      </div>
    </div>
  );
}
