"use server";

import { ApiError } from "@/lib/api/client";
import { updateDemographics } from "@/lib/api/endpoints";
import type { PatchedDemographicsInput } from "@/lib/api/schemas";

type ActionResult = { ok: true } | { ok: false; message: string };

const GENERIC_ERROR = "ثبت اطلاعات با خطا مواجه شد. لطفاً دوباره تلاش کنید.";

export async function submitDemographicsAction(
  input: PatchedDemographicsInput,
): Promise<ActionResult> {
  if (Object.keys(input).length === 0) return { ok: true };

  try {
    await updateDemographics(input);
    return { ok: true };
  } catch (error) {
    return { ok: false, message: error instanceof ApiError ? error.message : GENERIC_ERROR };
  }
}
