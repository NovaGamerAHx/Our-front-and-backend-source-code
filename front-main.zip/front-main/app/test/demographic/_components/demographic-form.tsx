"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { ChevronDown } from "lucide-react";
import { toast } from "sonner";
import { Spinner } from "@/components/ui/spinner";
import { toPersianDigits } from "@/lib/utils/digits";
import { currentJalaliYear } from "@/lib/utils/date";
import {
  GENDER_OPTIONS,
  GOAL_OPTIONS,
  LIFE_SITUATION_OPTIONS,
} from "@/lib/constants/demographic-options";
import type { GenderValue, GoalValue, LifeSituationValue, PatchedDemographicsInput } from "@/lib/api/schemas";
import { submitDemographicsAction } from "../actions";

// Reasonable adult range for a self-development app: ages ~12 to ~90.
const MIN_AGE = 12;
const MAX_AGE = 90;

function YearDropdown({
  years,
  value,
  onChange,
}: {
  years: number[];
  value: string;
  onChange: (value: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    function handlePointerDown(e: PointerEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("pointerdown", handlePointerDown);
    return () => document.removeEventListener("pointerdown", handlePointerDown);
  }, [open]);

  return (
    <div ref={containerRef} className="relative w-[140px]">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={`flex min-h-11 w-full cursor-pointer items-center justify-between gap-2 rounded-xl border-[1.5px] bg-card px-3.5 py-3 text-[15px] font-extrabold outline-none transition-colors ${
          open ? "border-primary" : "border-border"
        } ${value ? "text-foreground" : "text-text-faint"}`}
      >
        <span>{value ? toPersianDigits(value) : "انتخاب"}</span>
        <ChevronDown size={14} strokeWidth={2.4} className="text-text-faint" />
      </button>
      {open && (
        <div className="border-border absolute inset-x-0 top-[calc(100%+6px)] z-20 flex max-h-[180px] flex-col gap-0.5 overflow-y-auto rounded-xl border bg-card p-1.5 shadow-[0_12px_28px_rgba(30,34,50,.14)]">
          {years.map((year) => {
            const selected = value === String(year);
            return (
              <button
                key={year}
                type="button"
                onClick={() => {
                  onChange(String(year));
                  setOpen(false);
                }}
                className={`min-h-10 cursor-pointer rounded-lg p-2.5 text-center text-sm transition-colors ${
                  selected ? "bg-primary font-extrabold text-white" : "text-muted-foreground font-semibold"
                }`}
              >
                {toPersianDigits(year)}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

function ChipQuestion<T extends string>({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: { value: T; label: string }[];
  value: T | null;
  onChange: (value: T | null) => void;
}) {
  return (
    <div className="border-border bg-card flex flex-col gap-3 rounded-2xl border p-5">
      <div className="text-[14px] font-extrabold">{label}</div>
      <div className="flex flex-wrap gap-2">
        {options.map((option) => {
          const selected = value === option.value;
          return (
            <button
              key={option.value}
              type="button"
              onClick={() => onChange(selected ? null : option.value)}
              className={`min-h-10 cursor-pointer rounded-full px-[15px] py-2.5 text-[12.5px] font-bold transition-all ${
                selected
                  ? "bg-primary text-white"
                  : "border-border bg-card text-muted-foreground hover:border-primary/50 border-[1.5px]"
              }`}
            >
              {option.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function DemographicForm({ attemptId }: { attemptId: number }) {
  const router = useRouter();
  const [birthYear, setBirthYear] = useState("");
  const [gender, setGender] = useState<GenderValue | null>(null);
  const [lifeSituation, setLifeSituation] = useState<LifeSituationValue | null>(null);
  const [goal, setGoal] = useState<GoalValue | null>(null);
  const [isPending, startTransition] = useTransition();

  const nowYear = currentJalaliYear();
  const years = Array.from(
    { length: MAX_AGE - MIN_AGE + 1 },
    (_, i) => nowYear - MIN_AGE - i,
  );

  function proceed(patch: PatchedDemographicsInput) {
    startTransition(async () => {
      if (Object.keys(patch).length > 0) {
        const result = await submitDemographicsAction(patch);
        if (!result.ok) toast.error(result.message);
      }
      router.push(`/test/analysis?attemptId=${attemptId}`);
    });
  }

  function continueClick() {
    const patch: PatchedDemographicsInput = {};
    if (birthYear) patch.birth_year = Number(birthYear);
    if (gender) patch.gender = gender;
    if (lifeSituation) patch.life_situation = lifeSituation;
    if (goal) patch.goal = goal;
    proceed(patch);
  }

  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col gap-6 px-7 pt-6 pb-12">
      <div className="bg-success-tint flex flex-col gap-3 rounded-[20px] border border-[#CDE7D6] p-5">
        <div className="flex items-center gap-2.5">
          <div className="bg-success grid size-[34px] shrink-0 place-items-center rounded-full text-base text-white">
            ✓
          </div>
          <div className="text-success text-[16px] font-extrabold">آزمون کامل شد</div>
        </div>
        <p className="text-[13px] leading-[1.95] text-[#3F7A57]">
          چند سؤال کوتاه تا توصیه‌ها به زندگی شما نزدیک‌تر شوند. همه اختیاری‌اند و چند ثانیه بیشتر
          طول نمی‌کشد.
        </p>
      </div>

      <div className="flex flex-col gap-4">
        <div className="border-border bg-card flex flex-col gap-3 rounded-2xl border p-5">
          <div className="text-[14px] font-extrabold">سال تولد</div>
          <YearDropdown years={years} value={birthYear} onChange={setBirthYear} />
        </div>

        <ChipQuestion label="جنسیت" options={GENDER_OPTIONS} value={gender} onChange={setGender} />
        <ChipQuestion
          label="موقعیت زندگی"
          options={LIFE_SITUATION_OPTIONS}
          value={lifeSituation}
          onChange={setLifeSituation}
        />
        <ChipQuestion label="هدف یا دغدغهٔ فعلی" options={GOAL_OPTIONS} value={goal} onChange={setGoal} />
      </div>

      <div className="mt-auto flex flex-col gap-2.5">
        <button
          type="button"
          onClick={continueClick}
          disabled={isPending}
          className="bg-primary hover:bg-primary/90 flex min-h-11 cursor-pointer items-center justify-center gap-2.5 rounded-2xl p-4 text-[15.5px] font-extrabold text-white transition-colors disabled:cursor-not-allowed disabled:opacity-75"
        >
          {isPending && <Spinner />}
          ادامه
        </button>
      </div>
    </main>
  );
}
