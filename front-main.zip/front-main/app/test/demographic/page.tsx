import { redirect } from "next/navigation";
import { getDemographics } from "@/lib/api/endpoints";
import { DemographicForm } from "./_components/demographic-form";

type DemographicPageProps = {
  searchParams: Promise<{ attemptId?: string }>;
};

export default async function DemographicPage({ searchParams }: DemographicPageProps) {
  const { attemptId: rawAttemptId } = await searchParams;
  const attemptId = rawAttemptId ? Number(rawAttemptId) : NaN;
  if (!Number.isFinite(attemptId)) {
    redirect("/test/questions");
  }

  // Fails open: if the check itself errors, show the form rather than blocking the funnel.
  const demographics = await getDemographics().catch(() => null);
  if (demographics?.answered) {
    redirect(`/test/analysis?attemptId=${attemptId}`);
  }

  return <DemographicForm attemptId={attemptId} />;
}
