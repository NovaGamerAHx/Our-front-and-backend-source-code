import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { ACCESS_TOKEN_COOKIE, SELF_KNOWLEDGE_ASSESSMENT_SLUG } from "@/lib/api/constants";
import { getPreStart } from "@/lib/api/endpoints";
import { isReportV2 } from "@/lib/utils/report";
import { ResumeView } from "./_components/resume-view";

// The anonymous "returning user" screen (design brief §4.A) — reached after the plain test
// intro when the visitor already has a saved result. Never meant for logged-in users (their
// equivalent is the dashboard) or for anyone with no history to actually show.
export default async function TestResumePage() {
  const store = await cookies();
  if (store.has(ACCESS_TOKEN_COOKIE)) {
    redirect("/test/questions");
  }

  const preStart = await getPreStart(SELF_KNOWLEDGE_ASSESSMENT_SLUG).catch(() => null);
  const latestReport = preStart?.latest_report ?? null;

  // This is pre-start for the initial (self-knowledge) assessment specifically, so
  // latestReport can never actually be a deep report -- "stage" in latestReport just narrows
  // the type down to the two shapes that carry it (full/preview) for TypeScript's sake.
  if (
    !preStart?.has_previous_report ||
    !latestReport ||
    latestReport.status !== "ok" ||
    !("stage" in latestReport)
  ) {
    redirect("/test/questions");
  }

  let summary: string;
  if (isReportV2(latestReport)) {
    summary = latestReport.stage === "full" ? latestReport.report.hook : latestReport.preview.hook;
  } else {
    summary =
      latestReport.stage === "full"
        ? latestReport.report.summary.one_line
        : latestReport.preview.summary_one_line;
  }

  return (
    <ResumeView
      attemptId={latestReport.attempt_id}
      summary={summary}
      remaining={preStart.remaining_attempts_today}
      limit={preStart.attempt_limit}
      hasInProgress={preStart.has_in_progress_attempt}
    />
  );
}
