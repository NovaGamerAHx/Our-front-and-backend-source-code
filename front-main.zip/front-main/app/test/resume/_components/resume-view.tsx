import Link from "next/link";
import { ChevronLeft } from "lucide-react";
import { RetakeNote } from "@/components/test/retake-note";

// Same "unlock full report" login CTA construction as the preview page's own login link.
function loginHref(attemptId: number) {
  const params = new URLSearchParams({
    next: `/report?attemptId=${attemptId}`,
    variant: "report-ready",
    skip: `/preview?attemptId=${attemptId}`,
  });
  return `/login?${params.toString()}`;
}

// Design reference: Faraman App.dc.html, RESUME screen (data-screen-label="Resume").
export function ResumeView({
  attemptId,
  summary,
  remaining,
  limit,
  hasInProgress,
}: {
  attemptId: number;
  summary: string;
  remaining: number;
  limit: number;
  hasInProgress: boolean;
}) {
  const capped = remaining <= 0 && !hasInProgress;
  const previewHref = `/preview?attemptId=${attemptId}`;

  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col gap-7 px-7 pt-6 pb-12">
      <div className="flex items-center justify-between pt-1">
        <div className="text-lg font-extrabold">فرامن</div>
        <Link
          href={loginHref(attemptId)}
          className="border-border text-primary rounded-full border bg-white px-[18px] py-2 text-[12.5px] font-bold"
        >
          ورود
        </Link>
      </div>

      <div className="flex flex-col gap-3.5 pt-1">
        <div className="bg-success-tint grid size-12 place-items-center rounded-[15px] text-[22px] text-success">
          ✓
        </div>
        <h1 className="text-[25px] leading-[1.6] font-extrabold text-pretty">
          گزارش قبلی‌تان این‌جاست
        </h1>
        <p className="text-muted-foreground text-[14px] leading-[2]">
          آزمونی که قبلاً انجام دادید ذخیره شده. می‌توانید پیش‌نمایش آن را ببینید و برای باز کردن نسخهٔ
          کامل وارد شوید.
        </p>
      </div>

      <Link
        href={previewHref}
        className="shadow-card border-border flex items-center gap-3.5 rounded-[18px] border bg-white p-5"
      >
        <div className="flex min-w-0 flex-1 flex-col gap-1">
          <div className="text-purple-accent text-[11.5px] font-bold">آخرین نتیجهٔ شما</div>
          <div className="line-clamp-2 text-[13.5px] leading-[1.8] font-bold">{summary}</div>
        </div>
        <ChevronLeft size={18} strokeWidth={2.5} className="text-muted-foreground flex-none" />
      </Link>

      {!hasInProgress && <RetakeNote remaining={remaining} limit={limit} />}

      <div className="mt-auto flex flex-col gap-2.5">
        <Link
          href={previewHref}
          className="bg-primary min-h-11 rounded-2xl p-4 text-center text-[15.5px] font-extrabold text-white"
        >
          دیدن پیش‌نمایش گزارش
        </Link>
        {!capped && (
          <Link
            href="/test/questions"
            className="min-h-11 rounded-2xl border-[1.5px] border-[#C7CEF0] bg-[#F4F6FD] p-[15px] text-center text-[14px] font-extrabold text-primary"
          >
            {hasInProgress ? "ادامه آزمون" : "شروع یک آزمون تازه"}
          </Link>
        )}
        <Link
          href={loginHref(attemptId)}
          className="border-border min-h-11 rounded-2xl border-[1.5px] bg-white p-[14px] text-center text-[13.5px] font-bold"
        >
          ورود و باز کردن گزارش کامل
        </Link>
      </div>
    </main>
  );
}
