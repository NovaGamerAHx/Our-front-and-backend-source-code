import type { Metadata } from "next";
import { SELF_KNOWLEDGE_ASSESSMENT_SLUG } from "@/lib/api/constants";
import { getPreStart } from "@/lib/api/endpoints";
import { getWorkspaceData } from "@/lib/workspace/data";
import { TrackOnMount } from "@/components/analytics/track-on-mount";
import { FreeIntro } from "@/components/workspace/test-intro";
import { WorkspaceFrame } from "@/components/workspace/frame";
import { PublicChrome } from "@/components/workspace/public-chrome";

export const metadata: Metadata = {
  title: "آزمون خودشناسی فرامن",
  description:
    "حدود ۱۰ دقیقه، ۳۰ جملهٔ ساده دربارهٔ خودتان — بدون پاسخ درست و غلط. یک گزارش شخصی از الگوها، نقاط قوت و مسیر رشدت دریافت کن.",
};

export default async function StartTestPage() {
  const [workspace, preStart] = await Promise.all([
    getWorkspaceData(),
    getPreStart(SELF_KNOWLEDGE_ASSESSMENT_SLUG).catch(() => null),
  ]);
  const isAuthenticated = Boolean(workspace.authenticated && workspace.profile);

  const hasInProgress = preStart?.has_in_progress_attempt ?? false;
  const capped = preStart !== null && preStart.remaining_attempts_today <= 0 && !hasInProgress;

  const nextHref =
    !isAuthenticated && preStart?.has_previous_report ? "/test/resume" : "/test/questions";

  let lastResult: { attemptId: number; completedAt: string } | null = null;
  if (isAuthenticated) {
    const latestFree = [...workspace.history]
      .filter((item) => item.report_type === "initial" && item.status === "ok")
      .sort((a, b) => new Date(b.completed_at).getTime() - new Date(a.completed_at).getTime())[0];
    if (latestFree) {
      lastResult = { attemptId: latestFree.attempt_id, completedAt: latestFree.completed_at };
    }
  }

  const content = (
    <FreeIntro
      nextHref={nextHref}
      capped={capped}
      hasInProgress={hasInProgress}
      lastResult={lastResult}
      guest={!isAuthenticated}
    />
  );

  return (
    <>
      <TrackOnMount event="test_intro_viewed" withUtm />
      {isAuthenticated ? (
        <WorkspaceFrame>{content}</WorkspaceFrame>
      ) : (
        <PublicChrome>{content}</PublicChrome>
      )}
    </>
  );
}
