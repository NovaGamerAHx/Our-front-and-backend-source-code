import type { Metadata } from "next";
import { cookies } from "next/headers";
import { ACCESS_TOKEN_COOKIE, SELF_KNOWLEDGE_ASSESSMENT_SLUG } from "@/lib/api/constants";
import { getPreStart, getReportHistory } from "@/lib/api/endpoints";
import { TrackOnMount } from "@/components/analytics/track-on-mount";
import { StartTestView } from "./_components/start-test-view";

export const metadata: Metadata = {
  title: "آزمون خودشناسی فرامن",
  description:
    "حدود ۱۰ دقیقه، ۴۰ جملهٔ ساده دربارهٔ خودتان — بدون پاسخ درست و غلط. یک گزارش شخصی از الگوها، نقاط قوت و مسیر رشدتان دریافت کنید.",
};

export default async function StartTestPage() {
  const store = await cookies();
  const isAuthenticated = store.has(ACCESS_TOKEN_COOKIE);

  // Best-effort: the intro page must never be blocked by this call failing, so a network
  // blip or backend hiccup just falls back to the plain, unrestricted intro.
  const preStart = await getPreStart(SELF_KNOWLEDGE_ASSESSMENT_SLUG).catch(() => null);

  // Resuming an unfinished attempt doesn't use up the daily limit (the backend returns the
  // in-progress one), so a user who exited mid-test must still be able to come back to it.
  const hasInProgress = preStart?.has_in_progress_attempt ?? false;
  const capped = preStart !== null && preStart.remaining_attempts_today <= 0 && !hasInProgress;

  // An anonymous visitor with a previous report gets routed through the dedicated "returning
  // user" screen (app/test/resume) instead of straight into the questions — that screen is
  // where they're shown their old result, not this one. Everyone else (first-time anonymous,
  // or a logged-in user) goes straight to the questions.
  const nextHref =
    !isAuthenticated && preStart?.has_previous_report ? "/test/resume" : "/test/questions";

  let lastResult: { attemptId: number; completedAt: string } | null = null;
  if (isAuthenticated) {
    try {
      const history = await getReportHistory();
      const latestFree = history.find((item) => item.report_type === "initial");
      if (latestFree) {
        lastResult = { attemptId: latestFree.attempt_id, completedAt: latestFree.completed_at };
      }
    } catch {
      // Non-critical -- the "last result" shortcut just doesn't show.
    }
  }

  return (
    <>
      <TrackOnMount event="test_intro_viewed" withUtm />
      <StartTestView nextHref={nextHref} capped={capped} hasInProgress={hasInProgress} lastResult={lastResult} />
    </>
  );
}
