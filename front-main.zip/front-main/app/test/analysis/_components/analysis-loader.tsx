"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { LogoMark } from "@/components/site/logo-mark";
import { trackEventAction } from "@/lib/api/track-event-action";
import {
  completeAttemptAction,
  getReportAction,
  retryReportGenerationAction,
} from "../../questions/actions";

// Handoff v34 "Analysis Loading": three lines that advance while the report is generated, then
// hold on the last one for however long generation still takes (the poll below, not a timer,
// decides when to leave), over a progress bar and one tip card.
const ANALYSIS_MESSAGES = [
  "بیا ببینیم از دل جواب‌هات چه شناخت تازه‌ای از خودت به دست میاد.",
  "بعضی ویژگی‌ها وقتی کنار هم قرار می‌گیرن، معنای جالب‌تری پیدا می‌کنن.",
  "تا چند لحظه دیگه می‌تونی نتیجه رو ببینی.",
];
const ANALYSIS_TIP =
  "خودشناسی یعنی کشف الگوهایی که بی‌آنکه متوجه باشیم، روی انتخاب‌هامون اثر می‌ذارن.";
const MESSAGE_INTERVAL_MS = 2300;
const RETRY_STATIC_MESSAGE = "داریم دوباره برای ساخت گزارش‌تان تلاش می‌کنیم…";

// However fast (or fast-failing) the request is, hold the loading screen up for at
// least this long so it reads as a real processing step instead of a flash.
const MIN_DISPLAY_MS = 2000;

// Report generation runs on a Celery worker now (see faraman-back CLAUDE.md's async-tasks
// section) -- complete_attempt returns as soon as it's queued, so we poll until it's actually
// done instead of navigating straight away.
const POLL_INTERVAL_MS = 3000;
// Give up and show the existing "failed" retry screen rather than polling forever if something
// is stuck (lost task, worker down, etc).
const MAX_POLL_MS = 120_000;

export function AnalysisLoader({
  attemptId,
  retry = false,
}: {
  attemptId: number | null;
  // Retry mode (from the report failure screen's "تلاش دوباره" button): the attempt is already
  // complete, so re-dispatch generation itself instead of completing the attempt again, then
  // fall into the exact same polling loop a fresh attempt uses.
  retry?: boolean;
}) {
  const router = useRouter();
  const [failed, setFailed] = useState(false);
  const [incomplete, setIncomplete] = useState(false);
  const [messageIdx, setMessageIdx] = useState(0);

  useEffect(() => {
    if (attemptId === null) {
      router.replace("/test/questions");
    }
  }, [attemptId, router]);

  useEffect(() => {
    if (retry || failed || incomplete) return;
    const timer = setInterval(
      () => setMessageIdx((i) => Math.min(i + 1, ANALYSIS_MESSAGES.length - 1)),
      MESSAGE_INTERVAL_MS,
    );
    return () => clearInterval(timer);
  }, [retry, failed, incomplete]);

  useEffect(() => {
    if (attemptId === null || failed || incomplete) return;

    let cancelled = false;
    let pollTimer: ReturnType<typeof setTimeout> | undefined;
    const minDisplay = new Promise<void>((resolve) => setTimeout(resolve, MIN_DISPLAY_MS));

    async function pollUntilReady(startedAt: number, properties: Record<string, unknown> | null) {
      const result = await getReportAction(attemptId as number);
      if (cancelled) return;

      if (result.ok && result.data.status !== "generating") {
        // The report actually exists now — this is the right moment for this event, not
        // immediately after complete_attempt returns (which only means "queued").
        if (result.data.status === "ok" && properties) {
          void trackEventAction({ event_name: "report_generated", properties });
        }
        router.push(`/preview?attemptId=${attemptId}`);
        return;
      }

      if (Date.now() - startedAt > MAX_POLL_MS) {
        setFailed(true);
        return;
      }
      pollTimer = setTimeout(() => pollUntilReady(startedAt, properties), POLL_INTERVAL_MS);
    }

    type StartOutcome =
      { ok: true; properties: Record<string, unknown> | null } | { ok: false; incomplete: boolean };

    async function start(): Promise<StartOutcome> {
      if (retry) {
        const result = await retryReportGenerationAction(attemptId as number);
        return result.ok ? { ok: true, properties: null } : { ok: false, incomplete: false };
      }

      const result = await completeAttemptAction(attemptId as number);
      if (!result.ok) {
        return { ok: false, incomplete: result.incomplete };
      }
      // `data: null` means completeAttemptAction hit the 409-already-completed case
      // (a retry after a transient error) — the attempt was already counted as
      // completed the first time, so don't fire test_completed again here.
      let properties: Record<string, unknown> | null = null;
      if (result.data !== null) {
        const attempt = result.data;
        const durationMs =
          new Date(attempt.completed_at ?? Date.now()).getTime() -
          new Date(attempt.started_at).getTime();
        properties = {
          assessment_slug: attempt.assessment_slug,
          attempt_id: attempt.id,
          duration_ms: durationMs,
        };
        void trackEventAction({ event_name: "test_completed", properties });
      }
      return { ok: true, properties };
    }

    Promise.all([start(), minDisplay]).then(([outcome]) => {
      if (cancelled) return;
      if (!outcome.ok) {
        if (outcome.incomplete) {
          setIncomplete(true);
        } else {
          setFailed(true);
        }
        return;
      }
      void pollUntilReady(Date.now(), outcome.properties);
    });

    return () => {
      cancelled = true;
      if (pollTimer) clearTimeout(pollTimer);
    };
  }, [attemptId, failed, incomplete, retry, router]);

  if (attemptId === null) return null;

  // e3 — the attempt was marked complete but required questions are still unanswered
  // (e.g. reached this page directly after skipping questions in the flow). Send the
  // user back to finish rather than showing the generic report-failure state (e5).
  if (incomplete) {
    return (
      <main className="mx-auto box-border flex min-h-dvh w-full max-w-[390px] flex-col items-center justify-center gap-4 px-7 text-center">
        <div className="bg-secondary text-primary grid size-[72px] place-items-center rounded-full text-2xl">
          📝
        </div>
        <h1 className="text-lg font-extrabold">هنوز چند سؤال مانده</h1>
        <p className="text-muted-foreground max-w-[280px] text-[13px] leading-[2]">
          برای ساخت گزارشی دقیق باید به همهٔ سؤالات پاسخ دهید. پاسخ‌های شما محفوظ است.
        </p>
        <button
          onClick={() => router.push("/test/questions")}
          className="bg-primary hover:bg-primary/90 min-h-11 w-full cursor-pointer rounded-2xl p-4 text-[15px] font-extrabold text-white"
        >
          ادامهٔ آزمون
        </button>
        <button
          onClick={() => router.push("/")}
          className="text-primary cursor-pointer text-[12.5px] font-bold hover:underline"
        >
          بعداً ادامه می‌دهم
        </button>
      </main>
    );
  }

  if (failed) {
    return (
      <main className="mx-auto box-border flex min-h-dvh w-full max-w-[390px] flex-col items-center justify-center gap-4 px-7 text-center">
        <div className="bg-danger-tint text-danger-text grid size-[72px] place-items-center rounded-full text-2xl">
          !
        </div>
        <h1 className="text-lg font-extrabold">در ساخت گزارش مشکلی پیش آمد</h1>
        <p className="text-muted-foreground max-w-[280px] text-[13px] leading-[2]">
          نگران نباشید — پاسخ‌هایتان محفوظ است و لازم نیست آزمون را دوباره بدهید.
        </p>
        <button
          onClick={() => setFailed(false)}
          className="bg-primary hover:bg-primary/90 min-h-11 w-full cursor-pointer rounded-2xl p-4 text-[15px] font-extrabold text-white"
        >
          تلاش دوباره
        </button>
        <button
          onClick={() => router.push("/")}
          className="text-primary cursor-pointer text-[12.5px] font-bold hover:underline"
        >
          بازگشت به صفحهٔ اصلی
        </button>
      </main>
    );
  }

  return (
    <main className="bg-gradient-dusk relative flex min-h-dvh flex-col items-center justify-center gap-9 overflow-hidden px-7">
      <div
        className="pointer-events-none absolute -bottom-20 left-[10%] size-[260px] rounded-full"
        style={{ background: "radial-gradient(circle, rgba(232,169,143,.4), transparent 70%)" }}
      />

      <div className="animate-fm-pulse grid size-28 place-items-center rounded-[32px] bg-white shadow-[0_12px_40px_rgba(0,0,0,.25)]">
        <LogoMark height={72} />
      </div>

      <div className="flex max-w-[340px] flex-col items-center gap-3 text-center">
        <div
          key={retry ? "retry" : messageIdx}
          className="animate-fm-in text-lg leading-[1.8] font-extrabold text-white"
        >
          {retry ? RETRY_STATIC_MESSAGE : ANALYSIS_MESSAGES[messageIdx]}
        </div>
      </div>

      <div className="relative h-1 w-[min(260px,70vw)] overflow-hidden rounded-full bg-white/[.18]">
        <div
          className="animate-fm-fill absolute inset-0 origin-right rounded-full"
          style={{ background: "linear-gradient(270deg,#fff,#E8B98F)" }}
        />
      </div>

      <div className="animate-fm-in flex max-w-[340px] flex-col gap-1 rounded-[18px] border border-white/[.18] bg-white/10 px-[18px] py-3.5 text-center [animation-delay:.3s] [animation-fill-mode:both]">
        <div className="text-[13px] leading-[1.95] text-pretty text-white">{ANALYSIS_TIP}</div>
      </div>
    </main>
  );
}
