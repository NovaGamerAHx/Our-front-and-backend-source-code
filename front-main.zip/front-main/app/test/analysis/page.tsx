import { AnalysisLoader } from "./_components/analysis-loader";

type AnalysisPageProps = {
  searchParams: Promise<{ attemptId?: string; retry?: string }>;
};

export default async function AnalysisPage({ searchParams }: AnalysisPageProps) {
  const { attemptId, retry } = await searchParams;
  const parsed = attemptId ? Number(attemptId) : NaN;

  return <AnalysisLoader attemptId={Number.isFinite(parsed) ? parsed : null} retry={retry === "1"} />;
}
