import Image from "next/image";
import Link from "next/link";
import { AlertCircle } from "lucide-react";
import { TrackedLink } from "@/components/analytics/tracked-link";
import { toPersianDigits } from "@/lib/utils/digits";

const START_PILLS = ["۳۰ پرسش کوتاه", "حدود ۱۰ دقیقه", "رایگان"];

const REPORT_PREVIEW = [
  {
    dot: "#8E6BA8",
    title: "نقطه‌های قوتت",
    desc: "سه چیزی که واقعاً در آن خوبی، و اینکه کجا به کارت می‌آیند.",
  },
  {
    dot: "#2743C6",
    title: "جاهایی که گیر می‌کنی",
    desc: "الگوهایی که معمولاً جلوی پیشرفتت را می‌گیرند.",
  },
  {
    dot: "#E8A98F",
    title: "قدم‌هایی برای شروع",
    desc: "کارهایی کوچک و مشخص که همین هفته می‌توانی انجامش بدهی.",
  },
] as const;

const HOW_IT_WORKS = [
  "۳۰ جمله می‌بینی، بگو هر کدام چقدر درباره‌ات درست است",
  "پاسخ‌هایت بررسی می‌شوند",
  "گزارشت آماده است",
] as const;

// Design reference: design_handoff_faraman_app/Faraman App.dc.html, "FREE TEST — DESCRIPTION"
// (data-screen-label="Ad Landing — Free Test"). Copy translated تست→آزمون throughout to match
// the app's established terminology (see RetakeNote.tsx, which made the same substitution from
// its own RetakeNote.dc.html source). SiteChrome already renders the logo/nav header on this
// route, so this view starts straight at the hero image rather than duplicating it.
export function StartTestView({
  nextHref,
  capped,
  hasInProgress,
  lastResult,
}: {
  nextHref: string;
  capped: boolean;
  hasInProgress: boolean;
  lastResult: { attemptId: number; completedAt: string } | null;
}) {
  const hasPreviousResult = lastResult !== null;
  const ctaLabel = hasInProgress
    ? "ادامه آزمون"
    : hasPreviousResult
      ? "شروع آزمون تازه"
      : "شروع آزمون";

  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col items-center px-5 pt-[14px] pb-8">
      <div className="bg-background relative w-full overflow-hidden rounded-[20px]">
        <Image
          src="/test/free-test-mirror-1120x630.png"
          alt="تصویرسازی: کسی که در آینه، نسخهٔ توانمندتر خودش را می‌بیند"
          width={1120}
          height={630}
          priority
          sizes="(min-width: 560px) 560px, 100vw"
          className="block h-[clamp(215px,57vw,300px)] w-full object-cover"
          style={{ objectPosition: "50% 46%" }}
        />
        <div className="absolute inset-x-0 bottom-0 flex px-[clamp(13px,4vw,17px)] pb-3.5">
          <div className="rounded-full bg-white px-3.5 py-[7px] text-[11.5px] font-extrabold text-[#4A2F63] shadow-[0_4px_14px_rgba(80,70,40,.14)]">
            آزمون خودشناسی فرامن
          </div>
        </div>
      </div>

      <div className="flex w-full flex-col gap-2.5 pt-4">
        <h1 className="text-[clamp(23px,6.4vw,30px)] leading-[1.55] font-extrabold text-pretty text-[#4A2F63]">
          چقدر خودت را می‌شناسی؟
        </h1>
        <p className="text-muted-foreground text-[clamp(14px,3.8vw,15px)] leading-[1.95] text-pretty">
          به ۳۰ جمله‌ی کوتاه جواب بده تا ببینی کجا قوی هستی، کجا معمولاً گیر می‌کنی و از کجا
          می‌توانی شروع کنی.
        </p>
      </div>

      {!capped && (
        <div className="flex w-full flex-col gap-[11px] pt-[clamp(15px,4vw,19px)]">
          <TrackedLink
            event="test_intro_start_clicked"
            href={nextHref}
            className="rounded-2xl bg-[#4A2F63] p-[18px] text-center text-lg font-extrabold text-white shadow-[0_10px_24px_rgba(74,47,99,.22)] transition-transform duration-150 hover:-translate-y-0.5"
          >
            {ctaLabel}
          </TrackedLink>
          <div className="flex flex-wrap justify-center gap-[7px]">
            {START_PILLS.map((pill) => (
              <div
                key={pill}
                className="border-border rounded-full border bg-white px-[13px] py-[7px] text-[11.5px] font-bold text-[#7C6F88]"
              >
                {pill}
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="border-border bg-card shadow-card-lg mt-[clamp(18px,5vw,24px)] flex w-full flex-col rounded-[20px] border">
        {REPORT_PREVIEW.map((item, index) => (
          <div
            key={item.title}
            className={`flex gap-3 p-[clamp(15px,4vw,18px)] ${index > 0 ? "border-t border-[#F3EFE6]" : ""}`}
          >
            <div className="mt-2 size-2 flex-none rounded-full" style={{ background: item.dot }} />
            <div className="flex flex-col gap-1">
              <div className="text-[14.5px] font-extrabold">{item.title}</div>
              <div className="text-muted-foreground text-[12.5px] leading-[1.95] text-pretty">
                {item.desc}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex w-full flex-col gap-[11px] pt-[clamp(18px,5vw,24px)]">
        <div className="text-text-faint text-[11.5px] font-extrabold">چطور پیش می‌رود</div>
        <div className="grid grid-cols-[repeat(auto-fit,minmax(140px,1fr))] gap-[9px]">
          {HOW_IT_WORKS.map((step, index) => (
            <div
              key={step}
              className="flex flex-col gap-1.5 rounded-2xl border border-dashed border-[#E3DCCC] bg-[#FFFDF8] px-[15px] py-[14px]"
            >
              <div className="text-purple-accent text-xs font-extrabold">
                {toPersianDigits(index + 1)}
              </div>
              <div className="text-[12.5px] leading-[1.8] text-[#3B3A34]">{step}</div>
            </div>
          ))}
        </div>
        {hasPreviousResult && (
          <div className="border-border flex flex-wrap items-center justify-between gap-2.5 rounded-2xl border bg-[#FFFDF8] px-[15px] py-[13px]">
            <div className="text-[12.5px] font-bold text-[#6C5F7A]">قبلاً آزمون را داده‌ای؟</div>
            <div className="flex gap-2">
              <Link
                href={`/report?attemptId=${lastResult.attemptId}`}
                className="bg-purple-tint rounded-full px-[13px] py-[7px] text-xs font-extrabold text-[#4A2F63]"
              >
                دیدن آخرین گزارش
              </Link>
              <Link
                href={`/chat?entry_source=report_cta&attempt_id=${lastResult.attemptId}&from=%2Ftest`}
                className="bg-purple-tint rounded-full px-[13px] py-[7px] text-xs font-extrabold text-[#4A2F63]"
              >
                گفتگو درباره‌ی آن
              </Link>
            </div>
          </div>
        )}
      </div>

      <div className="bg-purple-tint mt-[clamp(18px,5vw,24px)] flex w-full flex-col gap-1.5 rounded-[18px] p-[clamp(16px,4.5vw,20px)]">
        <div className="text-[clamp(15px,4.2vw,17px)] leading-[1.75] font-extrabold text-pretty text-[#4A2F63]">
          لازم نیست آماده باشی، فقط صادق باش.
        </div>
        <div className="text-[12.5px] leading-[1.95] text-pretty text-[#6C5F7A]">
          پاسخ درست و غلطی وجود ندارد. هر جمله را با اولین حسی که داری جواب بده — همین کافی است.
        </div>
      </div>

      <div className="mt-[18px] flex w-full flex-col gap-3.5">
        {capped && (
          <div className="flex flex-col gap-2.5 rounded-[20px] border border-[#EBD8C4] bg-[#FBF1E9] px-[19px] py-[18px]">
            <div className="flex items-center gap-2.5">
              <div className="grid size-8 flex-none place-items-center rounded-[11px] bg-[#F3E0CE]">
                <AlertCircle size={17} strokeWidth={2} className="text-[#B4703A]" />
              </div>
              <div className="text-[14.5px] font-extrabold text-[#8A5326]">آزمون‌های امروزت تمام شده</div>
            </div>
            <div className="text-[12.5px] leading-[1.95] text-[#9A6E45]">
              آزمون رایگان روزی دو بار قابل انجام است تا پاسخ‌ها با حال واقعی‌ات ثبت شود. فردا می‌توانی دوباره شروع کنی.
            </div>
          </div>
        )}
      </div>

      <div className="text-text-faint w-full pt-[clamp(20px,6vw,28px)] text-center text-[11.5px] leading-[1.9] text-pretty">
        پاسخ‌هایت فقط برای ساختن گزارش خودت استفاده می‌شوند و هر وقت بخواهی پاک می‌شوند.
      </div>

      <div className="mt-auto flex w-full justify-center pt-[clamp(20px,7vw,34px)]">
        <Link href="/terms?tab=terms" className="text-text-faint text-[11.5px] font-semibold">
          قواعد و حریم خصوصی
        </Link>
      </div>
    </main>
  );
}
