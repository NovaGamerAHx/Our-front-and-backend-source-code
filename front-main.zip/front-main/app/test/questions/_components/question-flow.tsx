"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { toPersianDigits } from "@/lib/utils/digits";
import { Spinner } from "@/components/ui/spinner";
import type { AssessmentQuestion } from "@/lib/api/schemas";
import { trackEventAction } from "@/lib/api/track-event-action";
import { startAttemptAction, submitAnswerAction, undoAnswerAction } from "../actions";

const SCALE_VALUES = [1, 2, 3, 4, 5];
// Pause after picking an answer so the selected state is visible before moving on.
const AUTO_ADVANCE_DELAY_MS = 420;

function scaleButtonClass(selected: boolean) {
  return `flex h-[58px] min-w-11 flex-1 items-center justify-center rounded-2xl text-[17px] font-extrabold transition-all disabled:cursor-not-allowed disabled:opacity-60 ${
    selected
      ? "border-2 border-primary bg-primary text-white cursor-pointer"
      : "border-[1.5px] border-border bg-card text-text-secondary cursor-pointer hover:border-primary/50"
  }`;
}

export function QuestionFlow({ questions }: { questions: AssessmentQuestion[] }) {
  const router = useRouter();
  const [attemptId, setAttemptId] = useState<number | null>(null);
  const [attemptFailed, setAttemptFailed] = useState(false);
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [isPending, startTransition] = useTransition();
  const advanceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Always points at the latest goNext so the delayed auto-advance doesn't use stale state.
  const indexRef = useRef(0);
  const goNextRef = useRef<() => void>(() => {});

  function cancelAutoAdvance() {
    if (advanceTimer.current) clearTimeout(advanceTimer.current);
    advanceTimer.current = null;
  }

  useEffect(() => cancelAutoAdvance, []);

  useEffect(() => {
    goNextRef.current = goNext;
    indexRef.current = index;
  });

  useEffect(() => {
    startAttemptAction().then((result) => {
      if (!result.ok) {
        setAttemptFailed(true);
        toast.error(result.message);
        return;
      }
      setAttemptId(result.data.id);
      if (result.data.answers.length === 0) {
        void trackEventAction({
          event_name: "test_started",
          properties: { assessment_slug: result.data.assessment_slug, attempt_id: result.data.id },
        });
        return;
      }

      const resumedAnswers: Record<number, number> = {};
      for (const answer of result.data.answers) {
        resumedAnswers[answer.question_id] = answer.value;
      }
      setAnswers(resumedAnswers);

      const firstUnanswered = questions.findIndex((q) => !(q.id in resumedAnswers));
      setIndex(firstUnanswered === -1 ? questions.length - 1 : firstUnanswered);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (questions.length === 0) {
    return (
      <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col items-center justify-center gap-4 px-7 text-center">
        <p className="text-muted-foreground text-[14.5px] leading-[2.05]">
          سؤالی برای این آزمون یافت نشد.
        </p>
      </main>
    );
  }

  if (attemptFailed) {
    return (
      <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col items-center justify-center gap-5 px-7 text-center">
        <p className="text-muted-foreground text-[14.5px] leading-[2.05]">
          شروع آزمون با خطا مواجه شد.
        </p>
        <button
          onClick={() => window.location.reload()}
          className="bg-primary hover:bg-primary/90 min-h-11 cursor-pointer rounded-2xl px-6 py-3 text-[14px] font-extrabold text-white"
        >
          تلاش دوباره
        </button>
      </main>
    );
  }

  const question = questions[index];
  const total = questions.length;
  const answeredCount = Object.keys(answers).length;
  const selected = answers[question.id];
  const isLast = index === total - 1;
  const ready = attemptId !== null;

  function selectValue(value: number) {
    if (!attemptId || isPending) return;
    cancelAutoAdvance();
    setAnswers((prev) => ({ ...prev, [question.id]: value }));
    startTransition(async () => {
      const result = await submitAnswerAction(attemptId, question.id, value);
      if (!result.ok) {
        toast.error(result.message);
        setAnswers((prev) => {
          const next = { ...prev };
          delete next[question.id];
          return next;
        });
        return;
      }
      const answeredIndex = index;
      advanceTimer.current = setTimeout(() => {
        advanceTimer.current = null;
        // Skip if the user already navigated elsewhere in the meantime.
        if (indexRef.current === answeredIndex) goNextRef.current();
      }, AUTO_ADVANCE_DELAY_MS);
    });
  }

  function undoAnswer() {
    if (!attemptId || isPending || selected === undefined) return;
    cancelAutoAdvance();
    const previousValue = selected;
    setAnswers((prev) => {
      const next = { ...prev };
      delete next[question.id];
      return next;
    });
    startTransition(async () => {
      const result = await undoAnswerAction(attemptId, question.id);
      if (!result.ok) {
        toast.error(result.message);
        setAnswers((prev) => ({ ...prev, [question.id]: previousValue }));
      }
    });
  }

  function goNext() {
    cancelAutoAdvance();
    if (!attemptId || isPending) return;
    if (!isLast) {
      setIndex((i) => i + 1);
      return;
    }

    const firstUnanswered = questions.findIndex((q) => !(q.id in answers));
    if (firstUnanswered !== -1) {
      toast.error("لطفاً به همه سؤالات پاسخ دهید تا بتوانید آزمون را به پایان برسانید.");
      setIndex(firstUnanswered);
      return;
    }
    router.push(`/test/demographic?attemptId=${attemptId}`);
  }


  function goPrevious() {
    cancelAutoAdvance();
    if (index === 0) return;
    setIndex((i) => i - 1);
  }

  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col gap-8 px-7 pt-6 pb-12">
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <button
            onClick={() => router.push("/test")}
            className="border-border text-muted-foreground bg-card hover:bg-muted grid size-10 cursor-pointer place-items-center rounded-xl border text-base"
          >
            →
          </button>
          <div className="text-text-faint text-[12.5px] font-bold whitespace-nowrap">
            سؤال {toPersianDigits(index + 1)} از {toPersianDigits(total)}
          </div>
          <button
            onClick={() => router.push("/")}
            className="text-primary cursor-pointer text-xs font-bold whitespace-nowrap hover:underline"
          >
            ذخیره و خروج
          </button>
        </div>
        <div className="bg-border h-[5px] overflow-hidden rounded-full">
          <div
            className="bg-gradient-meter h-full rounded-full transition-all"
            style={{ width: `${(answeredCount / total) * 100}%` }}
          />
        </div>
      </div>

      <div key={question.id} className="animate-fm-in flex flex-col gap-9 pt-5">
        <h2 className="min-h-[120px] text-[23px] leading-[1.75] font-extrabold">
          {question.text}
        </h2>
        <div className="flex flex-col gap-3.5">
          <div className="flex justify-between gap-2.5">
            {SCALE_VALUES.map((value) => (
              <button
                key={value}
                onClick={() => (selected === value ? undoAnswer() : selectValue(value))}
                disabled={!ready || isPending}
                className={scaleButtonClass(selected === value)}
              >
                {toPersianDigits(value)}
              </button>
            ))}
          </div>
          <div className="flex justify-between">
            <span className="text-text-faint text-[11.5px]">کاملاً مخالفم</span>
            <span className="text-text-faint text-[11.5px]">کاملاً موافقم</span>
          </div>
        </div>
        {index === Math.floor(total / 2) && (
          <p className="text-purple-accent text-center text-[12.5px] font-semibold">
            بیش از نیمی از راه را آمده‌اید — عالی پیش می‌روید.
          </p>
        )}
      </div>

      <div className="mt-auto flex flex-col gap-3">
        <div className="flex gap-2.5">
          <button
            onClick={goPrevious}
            disabled={index === 0}
            className="border-border text-muted-foreground hover:bg-muted min-h-11 cursor-pointer rounded-2xl border-[1.5px] bg-white px-[22px] py-3.5 text-[14px] font-bold disabled:cursor-not-allowed disabled:opacity-60 disabled:hover:bg-white"
          >
            قبلی
          </button>
          <button
            onClick={() => goNext()}
            disabled={!ready || isPending}
            className={`flex min-h-11 flex-1 items-center justify-center gap-2.5 rounded-2xl p-4 text-[15px] font-extrabold text-white transition-colors disabled:cursor-not-allowed ${
              ready && !isPending
                ? "bg-primary hover:bg-primary/90 cursor-pointer"
                : isPending
                  ? "bg-primary opacity-75"
                  : "bg-disabled"
            }`}
          >
            {isPending && selected !== undefined && <Spinner />}
            {isLast ? "پایان" : "بعدی"}
          </button>
        </div>
      </div>
    </main>
  );
}
