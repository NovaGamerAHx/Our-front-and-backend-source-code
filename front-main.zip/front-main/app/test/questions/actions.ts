"use server";

import { ApiError } from "@/lib/api/client";
import {
  completeAttempt,
  deleteAnswer,
  getReport,
  retryReportGeneration,
  startAttempt,
  submitAnswer,
} from "@/lib/api/endpoints";
import { SELF_KNOWLEDGE_ASSESSMENT_SLUG } from "@/lib/api/constants";
import type { Attempt, ReportResult } from "@/lib/api/schemas";

type ActionResult<T> = { ok: true; data: T } | { ok: false; message: string };

const GENERIC_ERROR = "خطای غیرمنتظره‌ای رخ داد. لطفاً دوباره تلاش کنید.";

function toResult<T>(fn: () => Promise<T>) {
  return fn()
    .then((data): ActionResult<T> => ({ ok: true, data }))
    .catch((error): ActionResult<T> => ({
      ok: false,
      message: error instanceof ApiError ? error.message : GENERIC_ERROR,
    }));
}

/** Starts a new attempt, or resumes the in-progress one for this browser's session. */
export async function startAttemptAction(): Promise<ActionResult<Attempt>> {
  return toResult(() => startAttempt(SELF_KNOWLEDGE_ASSESSMENT_SLUG));
}

export async function submitAnswerAction(
  attemptId: number,
  questionId: number,
  value: number,
): Promise<ActionResult<null>> {
  return toResult(() =>
    submitAnswer(attemptId, { question_id: questionId, value }).then(() => null),
  );
}

export async function undoAnswerAction(
  attemptId: number,
  questionId: number,
): Promise<ActionResult<null>> {
  return toResult(() => deleteAnswer(attemptId, questionId));
}

export type CompleteAttemptResult =
  | { ok: true; data: Attempt | null }
  | { ok: false; incomplete: true }
  | { ok: false; incomplete: false; message: string };

export async function completeAttemptAction(attemptId: number): Promise<CompleteAttemptResult> {
  try {
    return { ok: true, data: await completeAttempt(attemptId) };
  } catch (error) {
    // A 409 means the attempt is already completed — e.g. a retry after a transient
    // error masked an earlier success. Treat that as success instead of trapping the
    // user in a retry loop that keeps re-hitting the same conflict.
    if (error instanceof ApiError && error.status === 409) {
      return { ok: true, data: null };
    }
    // A 400 here means the backend rejected completion because required questions are
    // still unanswered (AttemptIncompleteException) — the only 400 this endpoint raises.
    if (error instanceof ApiError && error.status === 400) {
      return { ok: false, incomplete: true };
    }
    return {
      ok: false,
      incomplete: false,
      message: error instanceof ApiError ? error.message : GENERIC_ERROR,
    };
  }
}

/** Used by AnalysisLoader to poll while an async report generation (initial or deep) is in
 * flight -- getReport() is server-only and can't be called directly from that client component. */
export async function getReportAction(attemptId: number): Promise<ActionResult<ReportResult>> {
  return toResult(() => getReport(attemptId));
}

/** Used by AnalysisLoader's `retry` mode: re-dispatches generation for a report that failed,
 * reusing the attempt's already-scored answers, then the same polling loop as a fresh attempt
 * takes over. */
export async function retryReportGenerationAction(attemptId: number): Promise<ActionResult<null>> {
  return toResult(() => retryReportGeneration(attemptId).then(() => null));
}
