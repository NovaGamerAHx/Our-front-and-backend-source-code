"use client";

import { useState } from "react";
import { toPersianDigits } from "@/lib/utils/digits";
import { ActionStepProposalSheet } from "@/components/action-steps/action-step-proposal-sheet";
import type { SuggestedStep } from "@/lib/api/schemas";

export function SmallActionsSection({
  smallActions,
  attemptId,
}: {
  smallActions: SuggestedStep[];
  attemptId: number;
}) {
  const [proposal, setProposal] = useState<{ index: number; step: SuggestedStep } | null>(null);

  return (
    <div className="flex flex-col gap-4 rounded-[24px] bg-white p-7 shadow-[0_4px_18px_rgba(90,60,20,.08)]">
      <div className="text-primary text-[15px] font-extrabold">سه کار کوچک از این هفته</div>
      <div className="grid gap-3.5 [grid-template-columns:repeat(auto-fit,minmax(220px,1fr))]">
        {smallActions.map((action, i) => (
          <div key={i} className="bg-background flex flex-col gap-2.5 rounded-[18px] p-[18px] text-right">
            <div className="text-primary bg-secondary grid size-[26px] place-items-center rounded-[9px] text-xs font-extrabold">
              {toPersianDigits(i + 1)}
            </div>
            <div className="text-[15px] leading-[2.05]" style={{ color: "#3C4150", textAlign: "justify" }}>
              {action.text}
            </div>
            <button
              type="button"
              onClick={() => setProposal({ index: i + 1, step: action })}
              className="text-primary mt-auto min-h-11 cursor-pointer self-start rounded-full border-[1.5px] border-[#C7CEF0] bg-white px-4 py-2.5 text-xs font-extrabold"
            >
              قدم اولش را بگیر
            </button>
          </div>
        ))}
      </div>

      {proposal && (
        <ActionStepProposalSheet
          open
          onClose={() => setProposal(null)}
          kicker="کار کوچک این هفته"
          suggestedStep={proposal.step}
          attemptId={attemptId}
          index={proposal.index}
        />
      )}
    </div>
  );
}
