import Image from "next/image";
import Link from "next/link";
import { MessageCircle } from "lucide-react";
import {
  DEEP_LEVEL_LABELS,
  DEEP_TOPIC_LABELS,
  DEEP_TOPIC_LEADS,
  computeDeepAxisLabels,
  computeDeepRadarPolygon,
  computeDeepRadarRing,
  deepLevelBands,
} from "@/lib/utils/deep-report";
import { toPersianDigits } from "@/lib/utils/digits";
import { TrackOnMount } from "@/components/analytics/track-on-mount";
import { DEEP_ASSESSMENT_SLUG } from "@/lib/api/constants";
import type { DeepReportResponse } from "@/lib/api/schemas";
import { ReportIllustration } from "./illustration-slot";
import { SectionWave } from "./section-wave";
import { ScrollProgressBar } from "./scroll-progress-bar";
import { SmallActionsSection } from "./small-actions-section";
import { EmailReportCard } from "./email-report-card";
import { SectionAskBar } from "./section-ask-bar";
import { TopEmailStrip } from "@/components/report/top-email-strip";

// `focusKey` is one of the deep_report_focus:<section> values chat_spec_v1.md's extension
// defines (deep_report_spec_v1_1.md §1) -- it drives entry_source/focus_section on the backend.
// `title` is only for the chat screen's local opening-greeting bubble (chat-view.tsx's
// entrySeed), unrelated to the backend contract.
function chatSectionHref(attemptId: number, focusKey: string, title: string) {
  const from = encodeURIComponent(`/deep-report?attemptId=${attemptId}`);
  return `/chat?entry_source=${encodeURIComponent(`deep_report_focus:${focusKey}`)}&attempt_id=${attemptId}&section=${encodeURIComponent(title)}&from=${from}`;
}

// The cover and closing ask-bars aren't tied to one report section, so they ride the same
// generic `deep_report_cta` entry source as the bottom chat CTA -- `deep_report_focus:*` is a
// fixed backend enum (lib/api/schemas.ts), not a value this page gets to invent new keys for.
function deepReportCtaHref(attemptId: number, title?: string) {
  const from = encodeURIComponent(`/deep-report?attemptId=${attemptId}`);
  const section = title ? `&section=${encodeURIComponent(title)}` : "";
  return `/chat?entry_source=deep_report_cta&attempt_id=${attemptId}${section}&from=${from}`;
}

function Eyebrow({ children, tone = "muted" }: { children: React.ReactNode; tone?: "muted" | "white" }) {
  return (
    <div
      className={`text-[12px] font-extrabold tracking-[.04em] ${
        tone === "white" ? "text-white/50" : "text-text-faint"
      }`}
    >
      {children}
    </div>
  );
}

function SectionTitle({ children, tone = "dark" }: { children: React.ReactNode; tone?: "dark" | "white" }) {
  return (
    <h2
      className={`text-[clamp(24px,4vw,36px)] leading-[1.5] font-extrabold text-pretty ${
        tone === "white" ? "text-white" : "text-foreground"
      }`}
    >
      {children}
    </h2>
  );
}

function LevelBands({ level, variant = "light" }: { level: DeepReportResponse["domain_scores"][number]["level"]; variant?: "light" | "dark" }) {
  return (
    <div className="flex gap-1.5">
      {deepLevelBands(level, variant).map((bg, i) => (
        <div key={i} className="h-2 flex-1 rounded-full" style={{ background: bg }} />
      ))}
    </div>
  );
}

function RadarSection({ report }: { report: DeepReportResponse }) {
  const radarPoints = computeDeepRadarPolygon(report.domain_scores);
  const axisLabels = computeDeepAxisLabels(report.domain_scores);

  return (
    <section className="relative" style={{ background: "#22307E" }}>
      <SectionWave color="#22307E" variant="b" />
      <div className="mx-auto flex w-full max-w-[960px] flex-col gap-[30px] px-7 pt-14 pb-[76px]">
        <Eyebrow tone="white">شکل کلی</Eyebrow>
        <SectionTitle tone="white">نمای کلی پنج عامل</SectionTitle>
        <div className="flex flex-wrap items-center gap-6">
          <div className="min-w-[260px] flex-1">
            {/* Square stage: the chart keeps to the middle 62%, the five names live in the ring
                around it as HTML so long titles wrap instead of colliding. */}
            <div className="relative mx-auto aspect-square w-full max-w-[380px]">
              <svg
                viewBox="0 0 200 200"
                className="absolute top-1/2 left-1/2 h-[62%] w-[62%] -translate-x-1/2 -translate-y-1/2"
              >
                <polygon points={computeDeepRadarRing(report.domain_scores, 0.94)} fill="none" stroke="rgba(255,255,255,.18)" strokeWidth="1" />
                <polygon points={computeDeepRadarRing(report.domain_scores, 0.68)} fill="none" stroke="rgba(255,255,255,.18)" strokeWidth="1" />
                <polygon points={computeDeepRadarRing(report.domain_scores, 0.42)} fill="none" stroke="rgba(255,255,255,.18)" strokeWidth="1" />
                <polygon points={radarPoints} fill="rgba(232,169,143,.22)" stroke="#E8B98F" strokeWidth="2.4" strokeLinejoin="round" />
              </svg>
              {axisLabels.map((a) => (
                <div
                  key={a.code}
                  className="absolute w-[30%] -translate-x-1/2 -translate-y-1/2 text-center"
                  style={{ left: `${a.left}%`, top: `${a.top}%` }}
                >
                  <div className="text-[12px] leading-[1.5] font-extrabold text-balance text-white">{a.name}</div>
                  <div className="text-[10.5px] leading-[1.6] font-bold text-white/55">{a.level}</div>
                </div>
              ))}
            </div>
            <div className="pt-1.5 text-center text-[11px] leading-[1.9] text-white/50">
              شکل کلی پروفایل — سه حلقه به‌ترتیب پایین، میانه و بالا هستند.
            </div>
          </div>
          <div className="flex min-w-[260px] flex-1 flex-col gap-2.5">
            {report.report.domains_overview.map((d) => (
              <div key={d.code} className="flex flex-col gap-2.5 rounded-[18px] border border-white/16 bg-white/8 px-[18px] py-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="text-[14.5px] font-extrabold text-white">{d.title}</div>
                  <div className="rounded-full border border-[#E8B98F]/45 bg-[#E8B98F]/18 px-3 py-1 text-[11px] font-extrabold text-[#E8B98F]">
                    {DEEP_LEVEL_LABELS[d.level]}
                  </div>
                </div>
                <LevelBands level={d.level} variant="dark" />
              </div>
            ))}
          </div>
        </div>
        <div className="flex flex-col gap-3 rounded-[24px] border border-[#E8B98F]/34 bg-[#E8B98F]/14 p-[26px]">
          <div className="text-base font-extrabold text-[#E8B98F]">تفسیر یکپارچهٔ پنج عامل</div>
          <p className="text-[15px] leading-[2.2] text-white/92" style={{ textAlign: "justify" }}>
            {report.report.integrated_interpretation}
          </p>
        </div>
      </div>
    </section>
  );
}

function DomainSection({
  domain,
  index,
  attemptId,
  facetTitleByCode,
  domainTitleByCode,
  domainLevelByCode,
}: {
  domain: DeepReportResponse["report"]["domains"][number];
  index: number;
  attemptId: number;
  facetTitleByCode: Map<string, string>;
  domainTitleByCode: Map<string, string>;
  domainLevelByCode: Map<string, DeepReportResponse["domain_scores"][number]["level"]>;
}) {
  const bands = ["#FBF6EC", "#F5F0FA", "#FBF3E4", "#F1F4FB", "#F7F1EA"];
  const band = bands[index % bands.length];
  const level = domainLevelByCode.get(domain.code);
  const title = domainTitleByCode.get(domain.code) ?? domain.code;
  const rowReverse = index % 2 === 1;

  return (
    <section className="relative" style={{ background: band }}>
      <SectionWave color={band} variant={index % 2 === 0 ? "a" : "b"} />
      <div className="mx-auto flex w-full max-w-[960px] flex-col gap-7 px-7 pt-14 pb-[76px]">
        <div className={`flex flex-wrap items-center gap-9 ${rowReverse ? "flex-row-reverse" : ""}`}>
          <div className="flex flex-1 basis-[320px] flex-col gap-4">
            <Eyebrow>عامل شخصیت</Eyebrow>
            <SectionTitle>{title}</SectionTitle>
            {level && (
              <div className="self-start rounded-full bg-white px-4 py-2 text-xs font-extrabold text-[#5D5C55] shadow-[0_2px_8px_rgba(80,70,40,.06)]">
                سطح: {DEEP_LEVEL_LABELS[level]}
              </div>
            )}
            <p className="text-muted-foreground max-w-[560px] text-[15px] leading-[2.15]" style={{ textAlign: "justify" }}>
              {domain.summary}
            </p>
          </div>
          <ReportIllustration
            src={DOMAIN_ILLUSTRATIONS[domain.code] ?? DOMAIN_ILLUSTRATIONS.N}
            alt={`تصویرسازی عامل «${title}»`}
          />
        </div>
        <div className="grid gap-[18px] [grid-template-columns:repeat(auto-fit,minmax(320px,1fr))]">
          {domain.facets.map((facet) => (
            <div key={facet.code} className="flex flex-col gap-[22px] rounded-[24px] bg-white p-7 shadow-[0_6px_22px_rgba(80,70,40,.07)]">
              <div className="flex flex-col gap-3.5">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="text-[17.5px] leading-[1.6] font-extrabold">
                    {facetTitleByCode.get(facet.code) ?? facet.code}
                  </div>
                  <div className="bg-muted rounded-full px-3 py-1 text-xs font-extrabold text-[#5D5C55]">
                    {DEEP_LEVEL_LABELS[facet.level]}
                  </div>
                </div>
                <LevelBands level={facet.level} />
              </div>
              <div className="flex flex-col gap-[18px]">
                <div className="flex flex-col gap-2">
                  <div className="text-success bg-success-tint self-start rounded-full px-3 py-1.5 text-xs font-extrabold">
                    وقتی خوب کار می‌کند
                  </div>
                  <div className="text-[15px] leading-[2.2]" style={{ color: "#3C4150", textAlign: "justify" }}>
                    {facet.when_it_works}
                  </div>
                </div>
                <div className="h-px" style={{ background: "#F1ECE1" }} />
                <div className="flex flex-col gap-2">
                  <div className="self-start rounded-full px-3 py-1.5 text-xs font-extrabold" style={{ color: "#9C6416", background: "#FAEEDD" }}>
                    وقتی هزینه می‌سازد
                  </div>
                  <div className="text-[15px] leading-[2.2]" style={{ color: "#3C4150", textAlign: "justify" }}>
                    {facet.when_it_costs}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        <SectionAskBar
          href={chatSectionHref(attemptId, `domain_${domain.code}`, title)}
          defaultValue={`«${title}» در من چطور کار می‌کند؟`}
        />
      </div>
    </section>
  );
}

function TopicSection({
  topicKey,
  section,
  index,
  attemptId,
}: {
  topicKey: keyof typeof DEEP_TOPIC_LABELS;
  section: { rows: { topic: string; text: string }[]; closing: string };
  index: number;
  attemptId: number;
}) {
  const title = DEEP_TOPIC_LABELS[topicKey];
  const rowReverse = index % 2 === 1;
  // Explicit alternation rather than odd:/even: — those count every child of <main>, so the
  // stripe order silently depends on how many non-section elements sit above these.
  const band = index % 2 === 0 ? "#F8F4EC" : "#FFFFFF";

  return (
    <section className="relative" style={{ background: band }}>
      <SectionWave color={band} variant={index % 2 === 0 ? "b" : "a"} />
      <div className="mx-auto flex w-full max-w-[960px] flex-col gap-[30px] px-7 pt-14 pb-[76px]">
        <div className={`flex flex-wrap items-center gap-9 ${rowReverse ? "flex-row-reverse" : ""}`}>
          <div className="flex flex-1 basis-[320px] flex-col gap-3.5">
            <Eyebrow>سبک‌ها و زمینه‌ها</Eyebrow>
            <SectionTitle>{title}</SectionTitle>
            <p className="text-muted-foreground max-w-[560px] text-sm leading-[2.15]">{DEEP_TOPIC_LEADS[topicKey]}</p>
          </div>
          <ReportIllustration src={TOPIC_ILLUSTRATIONS[topicKey]} alt={`تصویرسازی «${title}»`} />
        </div>
        <div className="grid gap-3.5 [grid-template-columns:repeat(auto-fit,minmax(280px,1fr))]">
          {section.rows.map((row, i) => (
            <div key={row.topic} className="border-border relative flex flex-col gap-3 overflow-hidden rounded-[22px] border bg-white px-6 pt-[26px] pb-6 shadow-[0_6px_22px_rgba(80,70,40,.06)]">
              <div className="absolute top-0 right-0 left-0 h-1" style={{ background: "linear-gradient(90deg,#2743C6,#8E6BA8)" }} />
              <div className="pointer-events-none absolute top-4 left-5 text-[46px] leading-none font-black" style={{ color: "#F4F1E9" }}>
                {toPersianDigits(i + 1)}
              </div>
              <div className="relative max-w-[78%] text-[17px] leading-[1.6] font-extrabold">{row.topic}</div>
              <div className="text-muted-foreground relative text-[15px] leading-[2.2]" style={{ textAlign: "justify" }}>
                {row.text}
              </div>
            </div>
          ))}
        </div>
        <div className="flex flex-col gap-3.5 rounded-[24px] p-7" style={{ background: "linear-gradient(135deg,#22307E,#3A3D8F)" }}>
          <div className="text-[15px] font-extrabold text-[#E8B98F]">جمع‌بندی</div>
          <p className="text-[15px] leading-[2.2] text-white/92">{section.closing}</p>
        </div>
        <SectionAskBar
          href={chatSectionHref(attemptId, topicKey, title)}
          defaultValue={`دربارهٔ ${title} برایم مثال بزن`}
        />
      </div>
    </section>
  );
}

const TOPIC_ORDER = [
  "decision_style",
  "communication_style",
  "work_style",
  "stress_and_energy",
  "learning_and_growth",
  "close_relationships",
] as const;

// Matches this test's five domain codes (lib/utils/deep-report.ts's DEEP_DOMAIN_ANGLES).
const DOMAIN_ILLUSTRATIONS: Record<string, string> = {
  N: "/deep-report/deep-domain-n-v2.png",
  E: "/deep-report/deep-domain-e.png",
  O: "/deep-report/deep-domain-o.png",
  A: "/deep-report/deep-domain-a.png",
  C: "/deep-report/deep-domain-c.png",
};

const TOPIC_ILLUSTRATIONS: Record<(typeof TOPIC_ORDER)[number], string> = {
  decision_style: "/deep-report/deep-decision.png",
  communication_style: "/deep-report/deep-communication.png",
  work_style: "/deep-report/deep-work.png",
  stress_and_energy: "/deep-report/deep-stress.png",
  learning_and_growth: "/deep-report/deep-learning.png",
  close_relationships: "/deep-report/deep-relations.png",
};

export function DeepReportView({ attemptId, report }: { attemptId: number; report: DeepReportResponse }) {
  const facetTitleByCode = new Map(report.facet_scores.map((f) => [f.code, f.title]));
  const domainTitleByCode = new Map(report.domain_scores.map((d) => [d.code, d.title]));
  const domainLevelByCode = new Map(report.domain_scores.map((d) => [d.code, d.level]));
  const strengths3 = report.report.top_strengths;
  const growth3 = report.report.growth_priorities;

  // Closing "explore" block prompts (design handoff Phase 5 §D): generated from this reader's
  // own report sections rather than the prototype's hardcoded chatScript, reusing the exact
  // question text already offered on each section's own ask bar so the two stay in sync.
  const explorePrompts = [
    ...report.report.domains.map((domain) => {
      const title = domainTitleByCode.get(domain.code) ?? domain.code;
      return {
        text: `«${title}» در من چطور کار می‌کند؟`,
        href: chatSectionHref(attemptId, `domain_${domain.code}`, title),
      };
    }),
    {
      text: "کدام یک از این قوت‌ها را دقیق‌تر بشناسم؟",
      href: chatSectionHref(attemptId, "strengths", "نقاط قوت و شکل افراطی‌شان"),
    },
    {
      text: "دربارهٔ سبک ارتباطی برایم مثال بزن",
      href: chatSectionHref(attemptId, "communication_style", DEEP_TOPIC_LABELS.communication_style),
    },
  ];

  return (
    <main className="flex flex-col">
      <ScrollProgressBar />
      <TrackOnMount
        event="full_report_viewed"
        properties={{ assessment_slug: DEEP_ASSESSMENT_SLUG, attempt_id: attemptId }}
      />

      {/* ---------- cover ---------- */}
      <section className="bg-gradient-dusk relative overflow-hidden">
        <div
          className="pointer-events-none absolute -bottom-5 -left-[70px] size-[340px] rounded-full"
          style={{ background: "radial-gradient(circle, rgba(232,169,143,.3), transparent 70%)" }}
        />
        <div className="relative mx-auto flex w-full max-w-[960px] flex-wrap items-center gap-9 px-7 pt-20 pb-[76px]">
          <div className="flex flex-1 basis-[320px] flex-col gap-[22px]">
            <div className="self-start rounded-full px-[18px] py-2 text-[11.5px] font-extrabold" style={{ background: "#E8B98F", color: "#3E2810" }}>
              {report.title}
            </div>
            <h1 className="text-[clamp(28px,5vw,44px)] leading-[1.5] font-extrabold text-pretty text-white">
              {report.report.identity_line}
            </h1>
            <div className="max-w-[520px]">
              <SectionAskBar
                href={deepReportCtaHref(attemptId, "خلاصهٔ گزارش")}
                defaultValue="از کجای این گزارش شروع کنم؟"
                tone="amber"
                label="هر جای این گزارش سؤالی داشتی، همین‌جا بپرس"
              />
            </div>
            <p className="max-w-[520px] text-[11.5px] leading-[2] text-white/62">{report.disclaimer}</p>
          </div>
          <div className="relative aspect-[4/3] w-full max-w-[540px] min-w-[280px] flex-1 basis-[460px] md:-left-[110px] md:mx-auto">
            <Image
              src="/deep-report/deep-cover-hq.png"
              alt="تصویرسازی: کسی که با شنل قرمز جلوی دری باز به سوی مسیرِ روشن ایستاده"
              fill
              priority
              sizes="(min-width: 960px) 540px, 90vw"
              className="object-contain"
            />
          </div>
        </div>
      </section>

      {/* ---------- summary ---------- */}
      <section className="bg-background relative">
        <SectionWave color="#F8F4EC" />
        <div className="mx-auto flex w-full max-w-[960px] flex-col gap-[30px] px-7 pt-14 pb-[76px]">
          <TopEmailStrip attemptId={attemptId} label="نسخهٔ کامل گزارش را برایت ایمیل کنیم" />

          <div className="flex flex-col gap-3.5">
            <Eyebrow>نگاه اول</Eyebrow>
            <SectionTitle>خلاصهٔ پروفایل تو</SectionTitle>
          </div>
          <div className="grid gap-[18px] [grid-template-columns:repeat(auto-fit,minmax(300px,1fr))]">
            <div className="flex flex-col gap-4 rounded-[24px] bg-white p-6 shadow-[0_6px_24px_rgba(80,70,40,.06)]">
              <div className="text-primary flex items-center gap-2.5 text-[15px] font-extrabold">
                <div className="bg-secondary grid size-[30px] place-items-center rounded-[10px]">★</div>
                سه قوت طبیعی
              </div>
              <div className="flex flex-col gap-3">
                {strengths3.map((t, i) => (
                  <div key={i} className="flex items-start gap-[11px]">
                    <div className="bg-muted text-text-faint mt-0.5 grid size-[22px] flex-none place-items-center rounded-[7px] text-[11px] font-extrabold">
                      {toPersianDigits(i + 1)}
                    </div>
                    <div className="text-[14px] leading-[1.85] font-bold" style={{ color: "#3C4150" }}>
                      {t}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="flex flex-col gap-4 rounded-[24px] bg-white p-6 shadow-[0_6px_24px_rgba(80,70,40,.06)]">
              <div className="text-purple-accent flex items-center gap-2.5 text-[15px] font-extrabold">
                <div className="bg-purple-tint grid size-[30px] place-items-center rounded-[10px]">↑</div>
                سه اولویت رشد
              </div>
              <div className="flex flex-col gap-3">
                {growth3.map((t, i) => (
                  <div key={i} className="flex items-start gap-[11px]">
                    <div className="bg-purple-tint text-purple-accent mt-0.5 grid size-[22px] flex-none place-items-center rounded-[7px] text-[11px] font-extrabold">
                      {toPersianDigits(i + 1)}
                    </div>
                    <div className="text-[14px] leading-[1.85] font-bold" style={{ color: "#3C4150" }}>
                      {t}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <p className="text-text-faint text-[12.5px] leading-[2]">{report.report.confidence_note}</p>
        </div>
      </section>

      {/* ---------- five factors overview ---------- */}
      <RadarSection report={report} />

      {/* ---------- the five domains ---------- */}
      {report.report.domains.map((domain, i) => (
        <DomainSection
          key={domain.code}
          domain={domain}
          index={i}
          attemptId={attemptId}
          facetTitleByCode={facetTitleByCode}
          domainTitleByCode={domainTitleByCode}
          domainLevelByCode={domainLevelByCode}
        />
      ))}

      {/* ---------- strengths ---------- */}
      <section className="relative" style={{ background: "#F3EBE1" }}>
        <SectionWave color="#F3EBE1" />
        <div className="mx-auto flex w-full max-w-[960px] flex-col gap-[30px] px-7 pt-14 pb-[76px]">
          <div className="flex flex-wrap items-center gap-9">
            <div className="flex flex-1 basis-[320px] flex-col gap-3.5">
              <div className="text-[12px] font-extrabold tracking-[.04em]" style={{ color: "#B0762A" }}>
                سرمایهٔ رفتاری
              </div>
              <h2 className="text-[clamp(24px,4vw,36px)] leading-[1.5] font-extrabold text-pretty" style={{ color: "#3E2E14" }}>
                نقاط قوت — و شکل افراطی‌شان
              </h2>
              <p className="max-w-[560px] text-sm leading-[2.15]" style={{ color: "#7A5C25" }}>
                قوتی که هزینه‌اش گفته نشود، تعریف است نه تحلیل. هر کارت، هر دو را دارد.
              </p>
            </div>
            <ReportIllustration
              src="/deep-report/deep-strengths.png"
              alt="تصویرسازی نقاط قوت: کسی که با شنل قرمز به گلدان‌ها آب می‌دهد"
              fit="cover"
            />
          </div>
          <div className="grid gap-3.5 [grid-template-columns:repeat(auto-fit,minmax(290px,1fr))]">
            {report.report.strengths.items.map((s, i) => (
              <div key={s.title} className="flex flex-col gap-4 rounded-[24px] bg-white p-6 shadow-[0_4px_18px_rgba(80,70,40,.07)]">
                <div className="flex items-center gap-3">
                  <div className="text-primary bg-secondary grid size-[34px] flex-none place-items-center rounded-xl text-[13.5px] font-extrabold">
                    {toPersianDigits(i + 1)}
                  </div>
                  <div className="text-lg font-extrabold">{s.title}</div>
                </div>
                <div className="text-text-faint text-sm leading-[1.9] font-bold">{s.evidence}</div>
                <div className="text-[14px] leading-[2.1]" style={{ color: "#3C4150" }}>
                  {s.value}
                </div>
                <div className="mt-auto flex flex-col gap-2 rounded-[18px] p-4" style={{ background: "#F6F2FA" }}>
                  <div className="text-xs font-extrabold" style={{ color: "#6B5A8C" }}>
                    وقتی از حد بگذرد
                  </div>
                  <div className="text-[13px] leading-[2.05]" style={{ color: "#4A4390" }}>
                    {s.overuse}
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="flex flex-col gap-3.5 rounded-[24px] p-[26px]" style={{ background: "#22307E" }}>
            <div className="text-lg font-extrabold text-[#E8B98F]">پیام توسعه‌ای این بخش</div>
            <p className="text-base leading-[2.2] text-white/92">{report.report.strengths.development_message}</p>
          </div>
          <SectionAskBar
            href={chatSectionHref(attemptId, "strengths", "نقاط قوت و شکل افراطی‌شان")}
            defaultValue="کدام یک از این قوت‌ها را دقیق‌تر بشناسم؟"
          />
        </div>
      </section>

      {/* ---------- blind spots ---------- */}
      <section className="relative" style={{ background: "#3A2B5C" }}>
        <SectionWave color="#3A2B5C" variant="b" />
        <div className="mx-auto flex w-full max-w-[960px] flex-col gap-[30px] px-7 pt-14 pb-[76px]">
          <div className="flex flex-row-reverse flex-wrap items-center gap-9">
            <div className="flex flex-1 basis-[320px] flex-col gap-3.5">
              <Eyebrow tone="white">فرضیه‌ها، نه حکم</Eyebrow>
              <SectionTitle tone="white">الگوهای پنهان</SectionTitle>
              <p className="max-w-[560px] text-sm leading-[2.15] text-white/72">
                این‌ها الگوهایی‌اند که ممکن است در موقعیت خاصی فعال شوند — نشانه‌شان را که بشناسی، قابل مدیریت‌اند.
              </p>
            </div>
            <ReportIllustration
              src="/deep-report/deep-blind.png"
              alt="تصویرسازی نقاط کور: کسی که با فانوس پارچه را از روی آینه‌ای پنهان کنار می‌زند"
              fit="cover"
            />
          </div>
          <div className="flex flex-col gap-3.5">
            {report.report.blind_spots.items.map((b, i) => (
              <div key={i} className="flex flex-col gap-4 rounded-[24px] border border-white/16 bg-white/7 p-6">
                <div className="flex items-start gap-3.5">
                  <div className="grid size-8 flex-none place-items-center rounded-[11px] text-[13px] font-extrabold" style={{ background: "rgba(232,169,143,.22)", color: "#E8B98F" }}>
                    {toPersianDigits(i + 1)}
                  </div>
                  <div className="text-lg leading-[1.75] font-extrabold text-white">{b.hypothesis}</div>
                </div>
                <div className="grid gap-3 [grid-template-columns:repeat(auto-fit,minmax(180px,1fr))]">
                  {[
                    ["شواهد", b.evidence],
                    ["محرک", b.trigger],
                    ["نشانهٔ قابل مشاهده", b.visible_sign],
                  ].map(([label, text]) => (
                    <div key={label} className="flex flex-col gap-1.5">
                      <div className="text-[13px] font-extrabold tracking-[.04em] text-white/50">{label}</div>
                      <div className="text-sm leading-[1.95] font-bold text-white/90">{text}</div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <div className="flex flex-col gap-3.5 rounded-[24px] border p-[26px]" style={{ background: "rgba(232,169,143,.14)", borderColor: "rgba(232,169,143,.32)" }}>
            <div className="text-[15px] font-extrabold text-[#E8B98F]">سه سؤال برای خودت</div>
            <div className="flex flex-col gap-3">
              {report.report.blind_spots.reflection_questions.map((q, i) => (
                <div key={i} className="flex items-start gap-[11px]">
                  <div className="mt-0.5 grid size-[23px] flex-none place-items-center rounded-lg text-[11px] font-extrabold" style={{ background: "rgba(255,255,255,.14)", color: "#E8B98F" }}>
                    {toPersianDigits(i + 1)}
                  </div>
                  <div className="text-[15px] leading-[2.1] text-white/90">{q}</div>
                </div>
              ))}
            </div>
          </div>
          <SectionAskBar
            href={chatSectionHref(attemptId, "blind_spots", "نقاط کور")}
            defaultValue="این چقدر واقعیه؟ — درباره‌اش حرف بزنیم"
            tone="amber"
          />
        </div>
      </section>

      {/* ---------- topic sections ---------- */}
      {TOPIC_ORDER.map((key, i) => (
        <TopicSection key={key} topicKey={key} section={report.report[key]} index={i} attemptId={attemptId} />
      ))}

      {/* ---------- closing ---------- */}
      <section className="relative" style={{ background: "#E8B98F" }}>
        <SectionWave color="#E8B98F" />
        <div className="mx-auto flex w-full max-w-[960px] flex-col gap-[30px] px-7 pt-14 pb-[76px]">
          <div className="flex flex-wrap items-center gap-9">
            <div className="flex flex-1 basis-[320px] flex-col gap-3.5">
              <div className="text-[12px] font-extrabold tracking-[.04em]" style={{ color: "#8A5A2A" }}>
                از اینجا به بعد
              </div>
              <h2 className="text-[clamp(24px,4vw,36px)] leading-[1.5] font-extrabold text-pretty" style={{ color: "#3E2810" }}>
                جمع‌بندی و تعهد شخصی
              </h2>
            </div>
            <ReportIllustration
              src="/deep-report/deep-closing.png"
              alt="تصویرسازی جمع‌بندی: کسی که با شنل قرمز روی سنگ‌های پله‌ای رو به جلو قدم برمی‌دارد"
            />
          </div>
          <div className="grid gap-3.5 [grid-template-columns:repeat(auto-fit,minmax(280px,1fr))]">
            <div className="flex flex-col gap-2.5 rounded-[24px] bg-white p-6 shadow-[0_4px_18px_rgba(90,60,20,.08)]">
              <div className="text-success text-base font-extrabold">در بهترین حالتم چطور عمل می‌کنم</div>
              <p className="text-[15px] leading-[2.15]" style={{ color: "#3C4150", textAlign: "justify" }}>
                {report.report.closing.at_my_best}
              </p>
            </div>
            <div className="flex flex-col gap-2.5 rounded-[24px] bg-white p-6 shadow-[0_4px_18px_rgba(90,60,20,.08)]">
              <div className="text-base font-extrabold" style={{ color: "#B0762A" }}>
                زیر فشار، چه الگویی را زودتر تشخیص بدهم
              </div>
              <p className="text-[15px] leading-[2.15]" style={{ color: "#3C4150", textAlign: "justify" }}>
                {report.report.closing.under_pressure}
              </p>
            </div>
          </div>
          <SmallActionsSection smallActions={report.report.closing.small_actions} attemptId={attemptId} />
          <div className="max-w-[640px] text-[13px] leading-[2.1] font-bold" style={{ color: "#5C3F16" }}>
            {report.closing_reminder}
          </div>
          <SectionAskBar
            href={deepReportCtaHref(attemptId, "جمع‌بندی و تعهد شخصی")}
            defaultValue="کدام قدم را با هم دقیق‌تر کنیم؟"
          />
        </div>
      </section>

      {/* ---------- chat cta: closing "explore" block ---------- */}
      {/* The wave has to hang above this section's top edge, so the glow keeps its own clipping
          wrapper instead of the section carrying overflow-hidden. #1B2150 is where the hero
          gradient starts, so the wave reads as the section's own edge. */}
      <section className="bg-gradient-hero relative overflow-hidden">
        <SectionWave color="#1B2150" variant="b" />
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div
            className="absolute -bottom-[70px] -left-[50px] size-[260px] rounded-full"
            style={{ background: "rgba(232,169,143,.2)" }}
          />
        </div>
        <div className="relative mx-auto flex w-full max-w-[960px] flex-col gap-[22px] px-7 pt-16 pb-11">
          <div className="text-[clamp(22px,3.6vw,32px)] leading-[1.5] font-extrabold text-pretty text-white">
            چه چیزی را می‌خواهی کاوش کنی؟
          </div>

          <div
            className="flex flex-col gap-[18px] rounded-[26px] p-[26px]"
            style={{ background: "#FBFAF7", boxShadow: "0 22px 50px -20px rgba(12,16,48,.6)" }}
          >
            <div className="flex items-center gap-2.5">
              <MessageCircle size={22} strokeWidth={1.9} className="flex-none text-[#8E6BA8]" />
              <div className="text-lg font-extrabold" style={{ color: "#242A38" }}>
                راجع به هر ابهامی که داشتی می‌توانی گفت‌وگو کنی
              </div>
            </div>
            <p className="text-sm leading-[1.95]" style={{ color: "#5D5C55" }}>
              ما گزارشت را بررسی کردیم. حالا می‌توانیم با هم جلو برویم و رشد کنیم. مثلاً بیا راجع به موارد زیر
              گفت‌وگو کنیم:
            </p>
            <div className="flex flex-col gap-2.5">
              {explorePrompts.map((prompt) => (
                <Link
                  key={prompt.text}
                  href={`${prompt.href}&initial_message=${encodeURIComponent(prompt.text)}`}
                  className="flex min-h-14 w-full items-center gap-3 rounded-full border-[1.5px] px-5 py-[11px]"
                  style={{ borderColor: "#2743C6" }}
                >
                  <MessageCircle size={19} strokeWidth={2} className="flex-none text-primary" />
                  <span className="text-primary-deep flex-1 text-right text-sm leading-[1.8] font-extrabold">
                    «{prompt.text}»
                  </span>
                  <span className="text-primary flex-none text-base">←</span>
                </Link>
              ))}
            </div>
          </div>

          <div className="flex flex-wrap gap-2.5">
            <Link
              href={`/chat?entry_source=deep_report_cta&attempt_id=${attemptId}&from=${encodeURIComponent(`/deep-report?attemptId=${attemptId}`)}`}
              className="text-primary-deep min-h-12 flex-1 basis-[220px] rounded-2xl bg-white p-4 text-center text-[15px] font-extrabold"
            >
              گفتگوی آزاد دربارهٔ گزارش
            </Link>
            <Link
              href="/dashboard"
              className="min-h-12 flex-1 basis-[180px] rounded-2xl border border-white/32 p-3.5 text-center text-[13.5px] font-bold text-white"
            >
              بازگشت به داشبورد
            </Link>
          </div>
        </div>
      </section>

      {/* ---------- email + comment (its own band, split off the CTA above by a wave) ---------- */}
      <section className="relative" style={{ background: "#242B62" }}>
        <SectionWave color="#242B62" variant="b" />
        <div className="relative mx-auto grid w-full max-w-[960px] gap-4 px-7 pt-11 pb-16 [grid-template-columns:repeat(auto-fit,minmax(280px,1fr))]">
          <EmailReportCard attemptId={attemptId} />

          <div className="flex flex-col gap-3 rounded-[20px] border border-[#E8B98F]/35 bg-white/8 p-6">
            <div className="grid size-[38px] flex-none place-items-center rounded-xl bg-[#E8B98F]/18">
              <MessageCircle size={19} strokeWidth={1.8} className="text-[#E8B98F]" />
            </div>
            <div className="text-[16.5px] font-extrabold text-white">
              چقدر این گزارش تو را درست شناخته؟
            </div>
            <p className="text-[13.5px] leading-[2] text-white/78">
              نظر شما دقت گزارش‌های تکمیلی بعدی را بالاتر می‌برد. کمتر از یک دقیقه وقت می‌گیرد.
            </p>
            <Link
              href={`/report/feedback?attemptId=${attemptId}&reportId=${report.report_id}&back=${encodeURIComponent(`/deep-report?attemptId=${attemptId}`)}`}
              className="self-start rounded-2xl bg-[#E8B98F] px-[26px] py-[15px] text-[14.5px] font-extrabold text-[#3E2810]"
            >
              نظرم را می‌گویم
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
