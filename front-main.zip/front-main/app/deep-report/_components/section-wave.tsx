/**
 * The wavy seam the deep-report design puts between two stacked full-width sections, instead of a
 * flat color edge.
 *
 * It belongs to the section *below* the seam and is drawn filled with that section's own
 * background color, hanging above its top edge (`bottom-full`). That way the section above can be
 * anything — a flat band, a gradient, a decorated hero — without the wave needing to know its
 * color. The host section must be `relative` (and must not clip its overflow), and gets no wave
 * when it is the first one on the page.
 */

const WAVE_PATHS = {
  // Two mirrored crests so consecutive seams don't read as a repeating stamp.
  a: "M0,26 C220,54 430,2 720,18 C1010,34 1220,58 1440,30 L1440,60 L0,60 Z",
  b: "M0,32 C240,58 470,44 720,20 C980,-4 1210,50 1440,22 L1440,60 L0,60 Z",
} as const;

export function SectionWave({
  color,
  variant = "a",
}: {
  color: string;
  variant?: keyof typeof WAVE_PATHS;
}) {
  return (
    <svg
      aria-hidden
      viewBox="0 0 1440 60"
      preserveAspectRatio="none"
      // translate-y-px closes the hairline the browser can otherwise leave between the wave's
      // baseline and the section's own background at fractional device pixel ratios.
      className="pointer-events-none absolute inset-x-0 bottom-full block h-[clamp(26px,4.5vw,54px)] w-full translate-y-px"
    >
      <path d={WAVE_PATHS[variant]} fill={color} />
    </svg>
  );
}
