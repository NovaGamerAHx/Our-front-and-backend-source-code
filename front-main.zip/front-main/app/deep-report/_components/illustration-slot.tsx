import Image from "next/image";

/** A section's illustration panel -- alternates with text per the design handoff's image/text
 * row layout. `fit="cover"` sections (strengths/blind spots) crop to a rounded frame like a
 * photo card; `fit="contain"` sections (cover/domains/topics/closing) show the full cutout
 * illustration on a transparent background. */
export function ReportIllustration({
  src,
  alt,
  fit = "contain",
  priority = false,
}: {
  src: string;
  alt: string;
  fit?: "contain" | "cover";
  priority?: boolean;
}) {
  return (
    <div
      className={`relative aspect-[4/3] w-full max-w-[440px] min-w-[260px] flex-1 basis-[360px] ${
        fit === "cover" ? "overflow-hidden rounded-[24px]" : ""
      }`}
    >
      <Image
        src={src}
        alt={alt}
        fill
        priority={priority}
        loading={priority ? undefined : "lazy"}
        sizes="(min-width: 960px) 440px, 90vw"
        className={fit === "cover" ? "object-cover" : "object-contain"}
      />
    </div>
  );
}
