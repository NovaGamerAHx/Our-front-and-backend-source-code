"use client";

import { useState, useTransition } from "react";
import { toast } from "sonner";
import { Mail } from "lucide-react";
import { sendReportEmailAction } from "@/components/report/actions";

export function EmailReportCard({ attemptId }: { attemptId: number }) {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [isPending, startTransition] = useTransition();

  function submit() {
    if (!email.trim() || isPending) return;
    startTransition(async () => {
      const result = await sendReportEmailAction(attemptId, email.trim());
      if (!result.ok) {
        toast.error(result.message);
        return;
      }
      setSent(true);
    });
  }

  return (
    <div className="flex flex-col gap-3 rounded-[20px] border border-[#E8B98F]/35 bg-white/8 p-6">
      <div className="grid size-[38px] flex-none place-items-center rounded-xl bg-[#E8B98F]/18">
        <Mail size={19} strokeWidth={1.8} className="text-[#E8B98F]" />
      </div>
      <div className="text-[16.5px] font-extrabold text-white">این گزارش جامع را برای خودت ایمیل کن</div>
      <p className="text-[13.5px] leading-[2] text-white/78">
        یک نسخهٔ کامل از گزارش را به ایمیلت می‌فرستیم تا هر وقت خواستی به آن برگردی.
      </p>
      {sent ? (
        <p className="text-[13.5px] font-bold text-[#E8B98F]">به ایمیلت ارسال شد ✓</p>
      ) : (
        <div className="flex flex-wrap gap-2.5">
          <input
            type="email"
            dir="rtl"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="ایمیلت را وارد کن"
            className="box-border min-h-11 min-w-[180px] flex-1 rounded-[13px] border border-white/25 bg-white/[.06] px-4 py-3 text-[13.5px] text-white outline-none placeholder:text-white/45"
          />
          <button
            type="button"
            onClick={submit}
            disabled={!email.trim() || isPending}
            className="min-h-12 rounded-2xl bg-[#E8B98F] px-[26px] py-[15px] text-[14.5px] font-extrabold text-[#3E2810] disabled:opacity-50"
          >
            {isPending ? "در حال ارسال..." : "ارسال"}
          </button>
        </div>
      )}
    </div>
  );
}
