"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

// Same arrow-glyph send icon as the rest of the app's composers (report-view.tsx,
// dashboard-view.tsx, chat-view.tsx) -- mirrored via -scale-x-100 for the RTL layout.
function SendIcon({ color }: { color: string }) {
  return (
    <svg
      width={20}
      height={20}
      viewBox="0 0 24 24"
      fill="none"
      stroke={color}
      strokeWidth={1.9}
      strokeLinecap="round"
      strokeLinejoin="round"
      className="-scale-x-100"
    >
      <path d="m22 2-7 20-4-9-9-4Z" />
      <path d="M22 2 11 13" />
    </svg>
  );
}

function AskIcon({ color }: { color: string }) {
  return (
    <svg
      width={16}
      height={16}
      viewBox="0 0 24 24"
      fill="none"
      stroke={color}
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      className="flex-none"
    >
      <path d="M20 11.5a7.5 7.5 0 0 1-10.9 6.7L4.5 19.5l1.3-4.6A7.5 7.5 0 1 1 20 11.5Z" />
    </svg>
  );
}

const TONE = {
  blue: {
    labelColor: "#A9A597",
    iconColor: "#A9A597",
    barBg: "#fff",
    barBorder: "#E4DFD2",
    barShadow: "0 4px 16px rgba(80,70,40,.05)",
    inputColor: "#242A38",
    sendBg: "#2743C6",
    sendIcon: "#fff",
  },
  amber: {
    labelColor: "rgba(255,255,255,.65)",
    iconColor: "#E8B98F",
    barBg: "rgba(255,255,255,.08)",
    barBorder: "rgba(232,185,143,.4)",
    barShadow: "none",
    inputColor: "#fff",
    sendBg: "#E8B98F",
    sendIcon: "#3E2810",
  },
} as const;

// Deep Report "action bar" (design handoff Faraman App.dc.html, per-section ask box): a hairline
// hint above an editable, pre-filled question the reader can send as-is or rewrite before it
// opens a fresh chat via ?initial_message=, seeded with that exact text.
export function SectionAskBar({
  href,
  defaultValue,
  tone = "blue",
  label = "هر سوالی راجع به گزارش داشتی در بخش گفت‌وگو بپرس",
}: {
  href: string;
  defaultValue: string;
  tone?: "blue" | "amber";
  label?: string;
}) {
  const router = useRouter();
  const [value, setValue] = useState(defaultValue);
  const c = TONE[tone];

  function send() {
    const trimmed = value.trim();
    if (!trimmed) return;
    router.push(`${href}&initial_message=${encodeURIComponent(trimmed)}`);
  }

  return (
    <div className="flex flex-col gap-2.5">
      <div
        className="flex items-center gap-2 text-[11.5px] font-extrabold tracking-[.06em]"
        style={{ color: c.labelColor }}
      >
        <AskIcon color={c.iconColor} />
        {label}
      </div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
        className="flex items-center gap-2.5 rounded-[18px] border-[1.5px] py-[7px] pr-[7px] pl-[18px]"
        style={{ background: c.barBg, borderColor: c.barBorder, boxShadow: c.barShadow }}
      >
        <button
          type="submit"
          aria-label="ارسال به گفتگو"
          disabled={!value.trim()}
          className="grid size-[46px] flex-none cursor-pointer place-items-center rounded-[14px] disabled:opacity-50"
          style={{ background: c.sendBg }}
        >
          <SendIcon color={c.sendIcon} />
        </button>
        <input
          value={value}
          onChange={(e) => setValue(e.target.value)}
          dir="rtl"
          aria-label="سؤالت را ویرایش کن"
          className="min-h-[34px] min-w-0 flex-1 border-none bg-transparent text-sm leading-[1.95] font-bold outline-none"
          style={{ color: c.inputColor }}
        />
      </form>
    </div>
  );
}
