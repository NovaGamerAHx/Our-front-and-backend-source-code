"use client";

import { useEffect, useState } from "react";

/** Fixed 3px reading-progress bar tracking scroll position, per the deep-report design spec. */
export function ScrollProgressBar() {
  const [pct, setPct] = useState(0);

  useEffect(() => {
    function onScroll() {
      const scrollable = document.documentElement.scrollHeight - window.innerHeight;
      setPct(scrollable > 0 ? Math.min(100, (window.scrollY / scrollable) * 100) : 0);
    }
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="pointer-events-none fixed top-0 right-0 left-0 z-20 h-[3px]">
      <div
        className="h-full"
        style={{
          width: `${pct}%`,
          background: "linear-gradient(90deg,#2743C6,#8E6BA8)",
          transition: "width .1s linear",
        }}
      />
    </div>
  );
}
