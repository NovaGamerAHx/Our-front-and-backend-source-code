import { redirect } from "next/navigation";
import { ApiError } from "@/lib/api/client";
import { getReport } from "@/lib/api/endpoints";
import { ReportUnavailable } from "@/components/report/report-unavailable";
import { DeepReportView } from "./_components/deep-report-view";

type DeepReportPageProps = {
  searchParams: Promise<{ attemptId?: string }>;
};

export default async function DeepReportPage({ searchParams }: DeepReportPageProps) {
  const { attemptId: raw } = await searchParams;
  const attemptId = raw ? Number(raw) : NaN;
  if (!Number.isFinite(attemptId)) {
    redirect("/deep-test?source=report_redirect");
  }

  let result;
  try {
    result = await getReport(attemptId);
  } catch (error) {
    const message = error instanceof ApiError ? error.message : "گزارش در حال حاضر در دسترس نیست.";
    return <ReportUnavailable message={message} />;
  }

  if (result.status === "generating") {
    redirect(`/deep-test/analysis?attemptId=${attemptId}`);
  }

  // Locked until paid (pay-after-test) -- the response carries no content, just this marker.
  if (result.status === "awaiting_payment") {
    redirect(`/paywall?deepAttemptId=${attemptId}`);
  }

  if (result.status === "error") {
    return <ReportUnavailable message={result.error.user_message} attemptId={attemptId} />;
  }

  // This attempt scored as an initial report, not a deep one (e.g. a stale/hand-typed link) —
  // send it to the route that actually knows how to render that shape. `fullReportResponseSchema`
  // and `previewReportResponseSchema` carry no `report_type` at all, so `"in"` is what narrows
  // the union here rather than a direct property check.
  if (!("report_type" in result) || result.report_type !== "deep") {
    redirect(`/report?attemptId=${attemptId}`);
  }

  return <DeepReportView attemptId={attemptId} report={result} />;
}
