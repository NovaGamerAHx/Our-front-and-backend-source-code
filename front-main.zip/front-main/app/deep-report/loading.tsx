import { Sk } from "@/components/ui/skeleton";

// Edge States §e4 — deep report loading. Dusk header up front, shimmer body until
// deep-report/page.tsx resolves getReport(attemptId).
export default function DeepReportLoading() {
  return (
    <main className="flex flex-col">
      <div className="bg-gradient-dusk relative overflow-hidden">
        <div className="relative mx-auto flex w-full max-w-[960px] flex-wrap items-center gap-9 px-7 pt-20 pb-[76px]">
          <div className="flex min-w-[240px] flex-1 flex-col gap-3">
            <div className="h-3 w-32 rounded-sm bg-white/25" />
            <div className="h-5 w-[80%] rounded-lg bg-white/35" />
            <div className="h-5 w-[50%] rounded-lg bg-white/35" />
          </div>
        </div>
      </div>

      <div className="mx-auto flex w-full max-w-[960px] flex-col gap-[30px] px-7 pt-14 pb-[76px]">
        <Sk className="h-4 w-44" />
        <Sk className="h-[180px] w-full rounded-[20px]" />
        <Sk className="h-[180px] w-full rounded-[20px]" />
        <div className="text-text-faint text-center text-xs">داریم گزارش‌تان را آماده می‌کنیم…</div>
      </div>
    </main>
  );
}
