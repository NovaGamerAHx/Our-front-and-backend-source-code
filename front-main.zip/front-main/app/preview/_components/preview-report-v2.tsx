import type { ReactNode } from "react";
import Link from "next/link";
import { Check, Lock } from "lucide-react";
import { TrackOnMount } from "@/components/analytics/track-on-mount";
import {
  V2_BODY,
  V2_CARD,
  V2_DISCLAIMER,
  V2_GRID,
  V2_PAGE,
  V2_WRAP,
  V2FindingsHeader,
  V2Hero,
  V2_IMAGES,
  V2Illustration,
  V2Pill,
  V2RadarCard,
  V2StrengthCard,
  findingPill,
  findingsEyebrow,
} from "@/components/report/report-v2-parts";
import { SELF_KNOWLEDGE_ASSESSMENT_SLUG } from "@/lib/api/constants";
import type { PreviewReportV2Response } from "@/lib/api/schemas";
import { toPersianDigits } from "@/lib/utils/digits";
import { V2_LEVEL_MIDPOINTS } from "@/lib/utils/report";

type PreviewReportV2Props = {
  preview: PreviewReportV2Response["preview"];
  attemptId: number;
  // How many retakes are left today; null when unknown (the pre-start lookup failed).
  retakesRemaining: number | null;
};

function loginHref(attemptId: number) {
  const params = new URLSearchParams({
    next: `/report?attemptId=${attemptId}`,
    variant: "report-ready",
    skip: `/preview?attemptId=${attemptId}`,
    from: "preview",
  });
  return `/login?${params.toString()}`;
}

const UNLOCK_POINTS = [
  "اثر هر دو الگو روی کار و روابطت",
  "یافته‌ی دوم به‌طور کامل",
  "سؤال‌هایی برای شناخت عمیق‌تر خودت",
];

// The locked remainder of a finding is drawn as bars, never as blurred text: report_spec_v2_0
// §5.4 keeps it off the wire pre-login, and blurred real text would be readable in devtools.
function LockedBars({ widths }: { widths: string[] }) {
  return (
    <div aria-hidden="true" className="flex flex-col gap-3 pt-0.5">
      {widths.map((w) => (
        <div key={w} className="h-[9px] rounded-[9px] bg-white/7" style={{ width: w }} />
      ))}
    </div>
  );
}

function PrivacyLine({ children }: { children: ReactNode }) {
  return (
    <div className="flex items-center gap-2.5 text-sm font-bold text-[#D9CCF3]">
      <Lock size={16} strokeWidth={1.9} aria-hidden="true" className="flex-none text-[#C3AEEB]" />
      <span>{children}</span>
    </div>
  );
}

function LockRow({ href, title, hint }: { href: string; title: string; hint: string }) {
  return (
    <Link
      href={href}
      className="mt-auto flex w-full items-center gap-3 border-t border-white/10 pt-4 text-right text-[#D9CCF3] hover:text-[#F3EFE8]"
    >
      <span className="grid size-9 flex-none place-items-center rounded-full bg-[rgba(195,174,235,.16)]">
        <Lock size={16} strokeWidth={1.9} className="text-[#C3AEEB]" />
      </span>
      <span className="flex flex-col">
        <span className="text-sm font-extrabold">{title}</span>
        <span className="text-[12.5px] text-[#A79FB3]">{hint}</span>
      </span>
    </Link>
  );
}

export function PreviewReportV2({ preview, attemptId, retakesRemaining }: PreviewReportV2Props) {
  const { first_finding: first, second_finding: second } = preview;
  const login = loginHref(attemptId);
  const retakeLine =
    retakesRemaining === null
      ? null
      : retakesRemaining > 0
        ? `امروز ${toPersianDigits(retakesRemaining)} بار دیگر می‌توانی تست را تکرار کنی؛ این محدودیت برای معتبر ماندن نتیجه‌هاست.`
        : "تکرار تست از فردا دوباره ممکن است؛ این محدودیت برای معتبر ماندن نتیجه‌هاست.";

  return (
    <main className={V2_PAGE}>
      <TrackOnMount
        event="preview_viewed"
        properties={{ assessment_slug: SELF_KNOWLEDGE_ASSESSMENT_SLUG, attempt_id: attemptId }}
      />
      <div className={V2_WRAP}>
        <V2Hero kicker="پروفایل اولیه‌ی تو" hook={preview.hook}>
          <div className="max-w-[460px] text-[15px] leading-[2] text-[#C9C2D3] text-pretty">
            این یکی از الگوهاییه که در پاسخ‌هات دیده می‌شه. بقیه‌ی یافته‌های شخصی تو هم آماده‌ست.
          </div>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2.5 pt-1">
            <Link
              href={login}
              className="flex min-h-[54px] items-center gap-2.5 rounded-full bg-[#C3AEEB] px-7 py-[15px] text-base font-extrabold text-[#1A1422] hover:bg-[#D2C1F1]"
            >
              <span>دیدن گزارش کامل خودم</span>
              <span aria-hidden="true">←</span>
            </Link>
          </div>
          <PrivacyLine>گزارشت محرمانه‌ست و فقط خودت بهش دسترسی داری.</PrivacyLine>
        </V2Hero>

        <section className={`${V2_GRID} items-stretch`}>
          <V2RadarCard
            footnote="بر اساس ۳۰ پاسخ"
            dimensions={preview.dimension_scores.map((d) => ({
              key: d.key,
              level: d.level,
              percent: V2_LEVEL_MIDPOINTS[d.level],
            }))}
          />
          <V2StrengthCard title={preview.strength.title} text={preview.strength.text} />
        </section>

        <section className="mt-[clamp(12px,2vw,24px)] flex flex-col gap-[clamp(16px,2vw,24px)] border-t border-white/12 pt-[clamp(32px,4.5vw,56px)]">
          <V2FindingsHeader
            eyebrow={findingsEyebrow([first.area, second.area])}
            heading={preview.findings_heading}
          />
          <div className={`${V2_GRID} items-stretch`}>
            <article className={`${V2_CARD} flex flex-col gap-4 p-[clamp(20px,2.4vw,30px)]`}>
              <V2Illustration image={V2_IMAGES.finding1} aspect="16/9" />
              <V2Pill>{findingPill(0, first.area)}</V2Pill>
              <h3 className="text-[clamp(18px,1.9vw,22px)] leading-[1.6] font-extrabold text-balance text-[#F3EFE8]">
                {first.title}
              </h3>
              <p className={V2_BODY}>{first.what}</p>
              <LockedBars widths={["100%", "60%"]} />
              <LockRow
                href={login}
                title="هزینه‌ی این الگو برای تو آماده‌ست"
                hint="با ورود به فرامن، ادامه‌ی این یافته رو بخون."
              />
            </article>
            <article className={`${V2_CARD} flex flex-col gap-4 p-[clamp(20px,2.4vw,30px)]`}>
              <V2Illustration image={V2_IMAGES.finding2} aspect="16/9" />
              <V2Pill>{findingPill(1, second.area)}</V2Pill>
              <h3 className="text-[clamp(18px,1.9vw,22px)] leading-[1.6] font-extrabold text-balance text-[#F3EFE8]">
                {second.title}
              </h3>
              <LockedBars widths={["100%", "88%", "54%"]} />
              <LockRow href={login} title="این یافته کامل آماده‌ست" hint="با ورود به فرامن، بخونش." />
            </article>
          </div>
        </section>

        <section className="mt-[clamp(16px,3vw,40px)] grid items-center gap-[clamp(32px,5vw,72px)] rounded-[32px] border border-[rgba(195,174,235,.35)] bg-[#2B2139] p-[clamp(28px,5vw,64px)] shadow-[0_30px_80px_rgba(0,0,0,.35)] [grid-template-columns:repeat(auto-fit,minmax(min(100%,380px),1fr))]">
          <div className="flex flex-col gap-[18px]">
            <div className="flex items-center gap-2 self-start rounded-full bg-[rgba(195,174,235,.14)] px-3.5 py-[7px] text-[13px] font-extrabold text-[#E4DAF5]">
              <Check size={15} strokeWidth={2.4} className="text-[#C3AEEB]" />
              آزمون خودشناسی تو تکمیل شد
            </div>
            <h2 className="text-[clamp(24px,3.2vw,36px)] leading-[1.6] font-extrabold text-balance">
              حالا وقتشه ببینی نتیجه‌ی آزمونت درباره‌ی تو چی می‌گه.
            </h2>
            <p className="max-w-[480px] text-[15.5px] leading-[2.1] text-[#C9C2D3] text-pretty">
              پروفایل اولیه‌ی شخصیتت آماده‌ست. با ورود به فرامن می‌تونی یافته‌های شخصی خودت رو بخونی و هر زمان
              خواستی دوباره بهشون برگردی.
            </p>
          </div>
          <div className="flex flex-col gap-[18px] rounded-3xl bg-[#F2EDF8] p-[clamp(22px,3vw,32px)] shadow-[0_20px_50px_rgba(0,0,0,.35)]">
            <div className="text-[13px] font-extrabold text-[#6B5A84]">در نتیجه‌ی تو</div>
            <div className="flex flex-col gap-3">
              {UNLOCK_POINTS.map((text) => (
                <div key={text} className="flex items-center gap-3 text-[15.5px] leading-[1.8] font-bold text-[#1E1428]">
                  <span className="grid size-[26px] flex-none place-items-center rounded-full bg-[#2B2139]">
                    <Check size={13} strokeWidth={3} className="text-[#F2EDF8]" />
                  </span>
                  <span>{text}</span>
                </div>
              ))}
            </div>
            <Link
              href={login}
              className="mt-1 flex min-h-[60px] w-full items-center justify-center gap-2.5 rounded-full bg-[#2B2139] p-[18px] text-[17px] font-extrabold text-[#F7F3FC] hover:bg-[#3D2F52]"
            >
              <span>مشاهده‌ی نتیجه‌ی کامل آزمونم</span>
              <span aria-hidden="true">←</span>
            </Link>
            <div className="flex items-center justify-center gap-2 text-center text-[12.5px] leading-[1.8] font-bold text-[#6B5A84]">
              <Lock size={13} strokeWidth={2} aria-hidden="true" className="flex-none" />
              <span>پاسخ‌هات فقط برای ساختن گزارش خودت استفاده می‌شن و محرمانه می‌مونن.</span>
            </div>
            <div className="flex flex-wrap justify-center gap-x-2 gap-y-1 text-center text-[12.5px] leading-[1.8] font-semibold text-[#4A4258]">
              <span className="font-extrabold text-[#1E1428]">رایگان</span>
              <span aria-hidden="true">·</span>
              <span>ورود با شماره‌ی موبایل</span>
              <span aria-hidden="true">·</span>
              <span>ذخیره‌ی گزارش در حساب تو</span>
            </div>
          </div>
        </section>

        <div className="flex flex-wrap items-center justify-center gap-x-2.5 gap-y-1.5 text-center text-[13px] leading-[1.9] text-[#A79FB3]">
          <span>نتیجه‌ات ذخیره شده است.</span>
          {retakeLine && <span>{retakeLine}</span>}
        </div>
        <div className="pt-[clamp(8px,2vw,16px)] text-center text-[11.5px] leading-[1.9] text-[#8E879A] text-pretty">
          {V2_DISCLAIMER}
        </div>
      </div>
    </main>
  );
}
