import Link from "next/link";
import { toPersianDigits } from "@/lib/utils/digits";
import { DIMENSION_LABELS, DIMENSION_LEVEL_COLORS, DIMENSION_LEVEL_LABELS } from "@/lib/utils/report";
import { TrackOnMount } from "@/components/analytics/track-on-mount";
import { SELF_KNOWLEDGE_ASSESSMENT_SLUG } from "@/lib/api/constants";
import type { PreviewReportResponse } from "@/lib/api/schemas";

type PreviewReportProps = {
  preview: PreviewReportResponse["preview"];
  attemptId: number;
};

// Design reference (Faraman App.dc.html, PREVIEW screen) blurs decorative filler content behind
// a lock pill rather than showing nothing — but per report_spec_v1.3 §5.2 the server never sends
// the real locked strengths/situations pre-login, so this is illustrative placeholder copy lifted
// verbatim from the design file, never real per-user data rendered-then-blurred.
const BLURRED_NARRATIVE_CONTINUATION =
  "مسئولیت برای تو فقط یک وظیفه نیست؛ بخشی از هویت توست. وقتی کاری را می‌پذیری، برایت مهم است که آن را درست، باکیفیت و تا انتها پیش ببری و همین باعث می‌شود دیگران بتوانند روی تو حساب کنند.";

const BLURRED_STRENGTHS = [
  {
    title: "ذهن رشدگرا و یادگیرنده",
    body: "فقط به انجام کارها فکر نمی‌کنی؛ می‌خواهی بهتر شوی و راه‌های مؤثرتری پیدا کنی.",
    tint: "#F3EBF6",
  },
  {
    title: "تعادل میان همدلی و قاطعیت",
    body: "احساسات دیگران را می‌بینی، اما اگر به دیدگاهت باور داشته باشی، به‌راحتی از آن نمی‌گذری.",
    tint: "#FBF3E4",
  },
];

const BLURRED_SITUATIONS = [
  { title: "سبک تصمیم‌گیری", body: "تصمیم‌هایت معمولاً سنجیده، منطقی و آینده‌نگرند؛ کمتر از روی هیجان انتخاب می‌کنی." },
  { title: "سبک ارتباطی", body: "کیفیت رابطه برایت مهم‌تر از تعداد است و به آدم‌های قابل‌اعتماد نزدیک‌تر می‌شوی." },
];

// The 4 life-pattern "real situation" cards are a fixed count per report_spec_v1.3 (not
// report-dependent), same as the design's hardcoded "۴ موقعیت واقعی".
const SITUATIONS_TOTAL_COUNT = 4;

function loginHref(attemptId: number) {
  const params = new URLSearchParams({
    next: `/report?attemptId=${attemptId}`,
    variant: "report-ready",
    skip: `/preview?attemptId=${attemptId}`,
    from: "preview",
  });
  return `/login?${params.toString()}`;
}

function LevelPill({ level }: { level: PreviewReportProps["preview"]["dimension_scores"][number]["level"] }) {
  const colors = DIMENSION_LEVEL_COLORS[level];
  return (
    <span
      className="rounded-full px-2.5 py-1 text-[11px] font-bold whitespace-nowrap"
      style={{ color: colors.color, background: colors.bg }}
    >
      {DIMENSION_LEVEL_LABELS[level]}
    </span>
  );
}

export function PreviewReport({ preview, attemptId }: PreviewReportProps) {
  const lockedStrengths = Math.max(0, preview.locked_counts.strengths - 1);
  const loginLink = loginHref(attemptId);

  const lockedItems = [
    `تحلیل کامل ${toPersianDigits(preview.locked_counts.strengths)} نقطهٔ قوت تو`,
    `${toPersianDigits(SITUATIONS_TOTAL_COUNT)} کارت شخصیت در موقعیت‌های واقعی`,
    `مسیر رشد + ${toPersianDigits(preview.locked_counts.recommendations)} توصیهٔ عملی`,
  ];

  return (
    <main className="min-h-dvh">
      <TrackOnMount
        event="preview_viewed"
        properties={{ assessment_slug: SELF_KNOWLEDGE_ASSESSMENT_SLUG, attempt_id: attemptId }}
      />
      <div className="bg-gradient-dusk relative overflow-hidden">
        <div
          className="pointer-events-none absolute -bottom-20 -left-10 size-[240px] rounded-full"
          style={{ background: "radial-gradient(circle, rgba(232,169,143,.45), transparent 70%)" }}
        />
        <div className="relative mx-auto box-border flex w-full max-w-[680px] flex-col gap-3.5 px-7 pt-7 pb-11">
          <div className="h-[52px] flex-none" />
          <div className="animate-fm-in flex flex-col gap-3.5">
            <div className="text-[12.5px] font-bold text-white/70">پیش‌نمایش گزارش شما</div>
            <h1 className="max-w-[520px] text-[clamp(21px,3vw,26px)] leading-[1.75] font-extrabold text-pretty text-white">
              {preview.summary_one_line}
            </h1>
            <div className="text-[11px] leading-[1.8] text-white/55">
              این تصویری اولیه از گزارش شماست. با ورود، میتوانی نسخهٔ کامل را ببینی.
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto box-border flex w-full max-w-[680px] flex-col gap-8 px-7 pt-8 pb-16">
        <section className="flex flex-col gap-4">
          <div className="text-[17px] font-extrabold">تصویر کلی شخصیت</div>
          <div className="grid [grid-template-columns:repeat(auto-fit,minmax(220px,1fr))] gap-2.5">
            {preview.dimension_scores.map((dim) => (
              <div
                key={dim.key}
                className="border-border flex items-center justify-between gap-2.5 rounded-2xl border bg-white px-[18px] py-[15px]"
              >
                <div className="text-[13.5px] font-extrabold">{DIMENSION_LABELS[dim.key]}</div>
                <LevelPill level={dim.level} />
              </div>
            ))}
          </div>
        </section>

        <section className="flex flex-col gap-3.5">
          <div className="text-[17px] font-extrabold">الگوی اصلی شخصیت تو</div>
          <div className="border-border relative flex flex-col gap-3 overflow-hidden rounded-[20px] border bg-white p-6">
            <p className="text-[13.5px] leading-[2.1] text-[#3C4150] text-pretty">
              {preview.personality_pattern_first_paragraph}
            </p>
            <p className="pointer-events-none text-[13.5px] leading-[2.1] text-[#5D5C55] blur-[5px] select-none">
              {BLURRED_NARRATIVE_CONTINUATION}
            </p>
            <div className="pointer-events-none absolute inset-x-0 bottom-0 h-20 bg-gradient-to-b from-white/0 to-white" />
          </div>
        </section>

        <section className="flex flex-col gap-3.5">
          <div className="flex items-center justify-between">
            <div className="text-[17px] font-extrabold">نقاط قوت تو</div>
            <div className="text-purple-accent bg-purple-tint rounded-full px-2.5 py-1 text-[11.5px] font-bold">
              {toPersianDigits(preview.locked_counts.strengths)} مورد
            </div>
          </div>
          <div className="border-border flex flex-col gap-2.5 rounded-[20px] border bg-white p-[22px]">
            <div className="flex items-center gap-2.5">
              <div className="bg-secondary size-[34px] flex-none rounded-xl" />
              <div className="text-[14.5px] font-extrabold">{preview.first_strength.title}</div>
            </div>
            <p className="text-[13px] leading-[2] text-[#5D5C55] text-pretty">{preview.first_strength.description}</p>
          </div>

          {lockedStrengths > 0 && (
            <div className="relative">
              <div className="pointer-events-none flex flex-col gap-2.5 blur-[6px] select-none">
                {BLURRED_STRENGTHS.map((s) => (
                  <div key={s.title} className="border-border flex flex-col gap-2 rounded-[20px] border bg-white p-[22px]">
                    <div className="flex items-center gap-2.5">
                      <div className="size-[34px] flex-none rounded-xl" style={{ background: s.tint }} />
                      <div className="text-[14.5px] font-extrabold">{s.title}</div>
                    </div>
                    <p className="text-[13px] leading-[2] text-[#5D5C55]">{s.body}</p>
                  </div>
                ))}
              </div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="flex items-center gap-[7px] rounded-full bg-[rgba(34,48,126,.92)] px-[18px] py-2 text-xs font-bold whitespace-nowrap text-white">
                  🔒 {toPersianDigits(lockedStrengths)} نقطهٔ قوت دیگر در گزارش کامل
                </div>
              </div>
            </div>
          )}
        </section>

        <section className="flex flex-col gap-3.5">
          <div className="text-[17px] font-extrabold">شخصیت تو در موقعیت‌های واقعی</div>
          <div className="relative">
            <div className="pointer-events-none flex flex-col gap-2.5 blur-[6px] select-none">
              {BLURRED_SITUATIONS.map((s) => (
                <div key={s.title} className="border-border flex flex-col gap-1.5 rounded-2xl border bg-white px-5 py-[18px]">
                  <div className="text-[13.5px] font-extrabold">{s.title}</div>
                  <div className="text-[12.5px] leading-[1.9] text-[#5D5C55]">{s.body}</div>
                </div>
              ))}
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="flex items-center gap-[7px] rounded-full bg-[rgba(34,48,126,.92)] px-[18px] py-2 text-xs font-bold whitespace-nowrap text-white">
                🔒 {toPersianDigits(SITUATIONS_TOTAL_COUNT)} موقعیت واقعی در گزارش کامل
              </div>
            </div>
          </div>
        </section>

        <section
          className="relative flex flex-col gap-[18px] overflow-hidden rounded-[22px] p-7"
          style={{ background: "#22307E" }}
        >
          <div
            className="pointer-events-none absolute -top-[50px] -left-10 size-[170px] rounded-full"
            style={{ background: "rgba(142,107,168,.35)" }}
          />
          <div className="relative flex flex-col gap-3">
            <div className="text-[19px] font-extrabold text-white">در گزارش کامل، این‌ها منتظر شماست</div>
            <p className="text-[13px] leading-[1.9] text-[#C7CEF0] text-pretty">{preview.teaser_line}</p>
            <div className="flex flex-col gap-2">
              {lockedItems.map((text) => (
                <div
                  key={text}
                  className="flex items-center gap-[11px] rounded-2xl border border-white/14 bg-white/8 px-4 py-[13px]"
                >
                  <span className="flex-none text-sm">🔒</span>
                  <span className="text-[13px] leading-[1.8] text-[#EAEDFB]">{text}</span>
                </div>
              ))}
            </div>
          </div>
          <Link
            href={loginLink}
            className="text-primary-deep relative min-h-11 rounded-2xl bg-white p-4 text-center text-[15px] font-extrabold"
          >
            قفل گزارش کامل را باز کنید
          </Link>
          <div className="relative text-center text-[11.5px] text-[#9BA6E8]">فقط با شمارهٔ موبایل — رایگان</div>
        </section>
      </div>
    </main>
  );
}
