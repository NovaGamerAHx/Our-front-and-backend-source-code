import { ReportV2Loading } from "@/components/report/report-v2-loading";

// Same skeleton as the report: the preview is the first screen after the analysis loader, and
// until getReport(attemptId) resolves there is nothing else to show.
export default function PreviewLoading() {
  return <ReportV2Loading />;
}
