import { redirect } from "next/navigation";
import { ApiError } from "@/lib/api/client";
import { getPreStart, getReport } from "@/lib/api/endpoints";
import { SELF_KNOWLEDGE_ASSESSMENT_SLUG } from "@/lib/api/constants";
import { ReportUnavailable } from "@/components/report/report-unavailable";
import { isReportV2 } from "@/lib/utils/report";
import { PreviewReport } from "./_components/preview-report";
import { PreviewReportV2 } from "./_components/preview-report-v2";

type PreviewPageProps = {
  searchParams: Promise<{ attemptId?: string }>;
};

export default async function PreviewPage({ searchParams }: PreviewPageProps) {
  const { attemptId: raw } = await searchParams;
  const attemptId = raw ? Number(raw) : NaN;
  if (!Number.isFinite(attemptId)) {
    redirect("/test");
  }

  let result;
  try {
    result = await getReport(attemptId);
  } catch (error) {
    const message =
      error instanceof ApiError ? error.message : "گزارش در حال حاضر در دسترس نیست.";
    return <ReportUnavailable message={message} />;
  }

  if (result.status === "generating") {
    // Generation runs on a Celery worker now — send the visitor back into AnalysisLoader's
    // polling loop instead of rendering a page that assumes result.stage exists. Safe to
    // re-enter even though the attempt is already completed: completeAttemptAction's existing
    // 409-handling treats that as success and resumes polling immediately.
    redirect(`/test/analysis?attemptId=${attemptId}`);
  }

  if (result.status === "error") {
    return <ReportUnavailable message={result.error.user_message} attemptId={attemptId} />;
  }

  // This attempt is actually a deep report (no `stage` at all) -- send it to the route that
  // knows how to render that shape instead of assuming .stage/.preview exist below.
  if (!("stage" in result)) {
    redirect(`/deep-report?attemptId=${attemptId}`);
  }

  // An authenticated owner never sees the teaser — the backend already sent the full report,
  // so land them on the real report page instead.
  if (result.stage === "full") {
    redirect(`/report?attemptId=${attemptId}`);
  }

  if (isReportV2(result)) {
    if (result.stage !== "preview") redirect(`/report?attemptId=${attemptId}`);
    // Best-effort: only feeds the "retakes left today" line, so a failed lookup just hides it.
    const retakesRemaining = await getPreStart(SELF_KNOWLEDGE_ASSESSMENT_SLUG)
      .then((preStart) => preStart.remaining_attempts_today)
      .catch(() => null);
    return <PreviewReportV2 preview={result.preview} attemptId={attemptId} retakesRemaining={retakesRemaining} />;
  }

  return <PreviewReport preview={result.preview} attemptId={attemptId} />;
}
