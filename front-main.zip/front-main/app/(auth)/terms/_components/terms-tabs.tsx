"use client";

import { useState } from "react";
import type { TermsSection } from "../content";

type TabKey = "terms" | "privacy";

function Sections({ sections }: { sections: TermsSection[] }) {
  return (
    <div className="flex flex-col gap-5">
      {sections.map((sec) => (
        <div key={sec.title} className="flex flex-col gap-2">
          <div className="text-[14.5px] font-extrabold">{sec.title}</div>
          <div className="text-muted-foreground text-[13.5px] leading-[2.1]">{sec.body}</div>
        </div>
      ))}
    </div>
  );
}

export function TermsTabs({
  initialTab,
  version,
  termsSections,
  privacySections,
}: {
  initialTab: TabKey;
  version: string;
  termsSections: TermsSection[];
  privacySections: TermsSection[];
}) {
  const [tab, setTab] = useState<TabKey>(initialTab);

  return (
    <div className="flex flex-col gap-6">
      <div className="flex gap-2 rounded-2xl bg-[#EFEAE0] p-1">
        <button
          type="button"
          onClick={() => setTab("terms")}
          className={`min-h-11 flex-1 cursor-pointer rounded-[11px] py-[11px] text-[13px] font-bold transition-colors ${tab === "terms" ? "bg-card text-foreground" : "text-[#8B8676] hover:text-foreground"
            }`}
        >
          شرایط استفاده
        </button>
        <button
          type="button"
          onClick={() => setTab("privacy")}
          className={`min-h-11 flex-1 cursor-pointer rounded-[11px] py-[11px] text-[13px] font-bold transition-colors ${tab === "privacy" ? "bg-card text-foreground" : "text-[#8B8676] hover:text-foreground"
            }`}
        >
          حریم خصوصی
        </button>
      </div>

      <div className="flex flex-col gap-5">
        <div className="text-text-faint text-[11px]">آخرین به‌روزرسانی: {version}</div>
        <Sections sections={tab === "terms" ? termsSections : privacySections} />
      </div>
    </div>
  );
}
