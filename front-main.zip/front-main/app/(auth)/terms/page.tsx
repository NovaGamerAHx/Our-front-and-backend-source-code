import type { Metadata } from "next";
import Link from "next/link";
import { TermsTabs } from "./_components/terms-tabs";
import { TERMS_VERSION, termsSections, privacySections } from "./content";

export const metadata: Metadata = {
  title: "قوانین و حریم خصوصی",
  description: "قوانین استفاده و سیاست حریم خصوصی فرامن.",
};

type TermsPageProps = {
  searchParams: Promise<{ tab?: string; from?: string }>;
};

export default async function TermsPage({ searchParams }: TermsPageProps) {
  const { tab, from } = await searchParams;
  const initialTab = tab === "privacy" ? "privacy" : "terms";
  const backHref = from && from.startsWith("/") ? from : "/login";

  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col gap-6 px-7 pt-6 pb-14">
      <div className="flex items-center gap-3">
        <Link
          href={backHref}
          className="border-border text-muted-foreground bg-card grid size-10 place-items-center rounded-xl border text-base"
        >
          →
        </Link>
        <div className="text-text-faint text-[13px] font-bold">قوانین و حریم خصوصی</div>
      </div>

      <TermsTabs
        initialTab={initialTab}
        version={TERMS_VERSION}
        termsSections={termsSections}
        privacySections={privacySections}
      />
    </main>
  );
}
