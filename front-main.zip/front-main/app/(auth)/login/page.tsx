import Link from "next/link";
import { LoginForm } from "./_components/login-form";

type LoginPageProps = {
  searchParams: Promise<{ next?: string; variant?: string; skip?: string; from?: string }>;
};

export default async function LoginPage({ searchParams }: LoginPageProps) {
  const { next, variant, skip, from } = await searchParams;
  const skipPath = skip && skip.startsWith("/") ? skip : null;

  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col gap-9 px-7 pt-6 pb-12">
      <div className="flex items-center gap-3">
        <Link
          href={skipPath ?? "/"}
          className="border-border text-muted-foreground bg-card grid size-10 place-items-center rounded-xl border text-base"
        >
          →
        </Link>
        <div className="text-text-faint text-[13px] font-bold">ورود</div>
      </div>

      <LoginForm
        nextPath={next && next.startsWith("/") ? next : "/dashboard"}
        reportReady={variant === "report-ready"}
        fromPreview={from === "preview"}
      />
    </main>
  );
}
