"use server";

import { cookies } from "next/headers";
import { ApiError } from "@/lib/api/client";
import { ACCESS_TOKEN_COOKIE, REFRESH_TOKEN_COOKIE } from "@/lib/api/constants";
import { UTM_COOKIE, parseUtmCookie } from "@/lib/analytics/utm";
import { sendOtp, verifyOtp, trackEvent } from "@/lib/api/endpoints";

type ActionResult = { ok: true } | { ok: false; message: string };

const GENERIC_ERROR = "خطای غیرمنتظره‌ای رخ داد. لطفاً دوباره تلاش کنید.";

// Backend message_key (error envelope) -> coarse reason for analytics.
function otpFailureReason(error: unknown): "throttled" | "sms_delivery_failed" | "other" {
  const data = error instanceof ApiError ? (error.data as { message_key?: unknown } | null) : null;
  if (data?.message_key === "otp_request_throttled") return "throttled";
  if (data?.message_key === "sms_send_failed") return "sms_delivery_failed";
  return "other";
}

export async function requestOtpAction(phoneNumber: string): Promise<ActionResult> {
  try {
    const store = await cookies();
    await sendOtp(phoneNumber, parseUtmCookie(store.get(UTM_COOKIE)?.value));
    void trackEvent({ event_name: "auth_code_requested" }).catch(() => {});
    return { ok: true };
  } catch (error) {
    void trackEvent({
      event_name: "auth_code_request_failed",
      properties: { reason: otpFailureReason(error) },
    }).catch(() => {});
    return { ok: false, message: error instanceof ApiError ? error.message : GENERIC_ERROR };
  }
}

export async function verifyOtpAction(
  phoneNumber: string,
  code: string,
  // For the auth_completed event. Tracked here, not from the client after this action returns: a
  // second server action fired from /login once the login cookie exists is POSTed to /login, and
  // proxy.ts answers that with a redirect to "/", which then overrides the push to `next`.
  tracking?: { source: "preview" | "direct"; nextPath: string },
): Promise<ActionResult> {
  try {
    const tokens = await verifyOtp(phoneNumber, code);
    const store = await cookies();
    const secure = process.env.NODE_ENV === "production";

    // Must match SIMPLE_JWT["ACCESS_TOKEN_LIFETIME"] / ["REFRESH_TOKEN_LIFETIME"] in
    // faraman-back/faraman_back/settings.py -- proxy.ts refreshes the access cookie
    // transparently before it outlives the refresh token.
    store.set(ACCESS_TOKEN_COOKIE, tokens.access, {
      httpOnly: true,
      secure,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 30,
    });
    store.set(REFRESH_TOKEN_COOKIE, tokens.refresh, {
      httpOnly: true,
      secure,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 7,
    });

    void trackEvent({
      event_name: "auth_completed",
      properties: { source: tracking?.source ?? "direct", next_path: (tracking?.nextPath ?? "").split("?")[0] },
    }).catch(() => {});

    return { ok: true };
  } catch (error) {
    return { ok: false, message: error instanceof ApiError ? error.message : GENERIC_ERROR };
  }
}
