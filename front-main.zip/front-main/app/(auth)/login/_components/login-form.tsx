"use client";

import { useEffect, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Spinner } from "@/components/ui/spinner";
import { toEnglishDigits, toPersianDigits } from "@/lib/utils/digits";
import { toastClientError } from "@/lib/analytics/client-error";
import { trackEventAction } from "@/lib/api/track-event-action";
import { SELF_KNOWLEDGE_ASSESSMENT_SLUG } from "@/lib/api/constants";
import { requestOtpAction, verifyOtpAction } from "../actions";

const RESEND_COOLDOWN_SECONDS = 120;
const JUST_RESENT_DISPLAY_MS = 2000;

const phoneSchema = z.object({
  phone: z
    .string()
    .transform((v) => toEnglishDigits(v).trim())
    .pipe(z.string().regex(/^09\d{9}$/, "شماره موبایل را به‌درستی وارد کنید؛ مثل ۰۹۱۲۳۴۵۶۷۸۹")),
});
type PhoneValues = z.infer<typeof phoneSchema>;

const OTP_LENGTH = 5;

const codeSchema = z.object({
  code: z
    .string()
    .transform((v) => toEnglishDigits(v).trim())
    .pipe(
      z.string().regex(new RegExp(`^\\d{${OTP_LENGTH}}$`), `کد باید ${toPersianDigits(OTP_LENGTH)} رقم باشد`),
    ),
});
type CodeValues = z.infer<typeof codeSchema>;

// Design System §5 — inputs: border 1.5px solid #EDE7DA, radius 16px, bg #fff, focus border primary.
const inputBase =
  "rounded-2xl border-[1.5px] bg-card font-sans text-foreground outline-none transition-colors";
const inputNormal = "border-border focus:border-primary";
const inputError = "border-[#D98A73] bg-[#F9EAE5]";

// Design System §4 — primary button: bg #2743C6, white, 800, radius 16px, padding 16px,
// shadow 0 6px 18px rgba(39,67,198,.22), min-height 44px; disabled: bg #C9CDDE, no shadow.
function primaryButtonClass(enabled: boolean, loading = false) {
  return `flex min-h-11 items-center justify-center gap-2.5 rounded-2xl p-4 text-[15px] font-extrabold text-white transition-colors disabled:cursor-not-allowed ${
    enabled
      ? "bg-primary shadow-[0_6px_18px_rgba(39,67,198,.22)] cursor-pointer hover:bg-primary/90"
      : loading
        ? "bg-primary shadow-[0_6px_18px_rgba(39,67,198,.22)] opacity-75"
        : "bg-disabled"
  }`;
}

// Preserves the post-login redirect across a trip to /terms and back.
function loginHref(nextPath: string) {
  return nextPath !== "/" ? `/login?next=${encodeURIComponent(nextPath)}` : "/login";
}

// Design reference §5 "Lead Capture" — shown instead of the generic login copy when arriving
// straight from a just-finished test (the preview page's "unlock full report" CTA).
function ReportReadyBanner() {
  return (
    <div className="flex items-center gap-3">
      <div className="bg-secondary grid size-10 place-items-center rounded-xl text-[17px]">✓</div>
      <div className="text-success text-[13px] font-bold">گزارش شما آماده است</div>
    </div>
  );
}

export function LoginForm({
  nextPath,
  reportReady = false,
  fromPreview = false,
}: {
  nextPath: string;
  reportReady?: boolean;
  fromPreview?: boolean;
}) {
  const router = useRouter();
  const [step, setStep] = useState<"phone" | "code">("phone");
  const [phone, setPhone] = useState("");
  const [cooldown, setCooldown] = useState(0);
  const [justResent, setJustResent] = useState(false);
  const [verifyFailed, setVerifyFailed] = useState(false);
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    void trackEventAction({ event_name: "auth_started" });
    if (fromPreview) {
      void trackEventAction({
        event_name: "login_after_preview",
        properties: { assessment_slug: SELF_KNOWLEDGE_ASSESSMENT_SLUG },
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setInterval(() => setCooldown((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(timer);
  }, [cooldown]);

  const phoneForm = useForm<PhoneValues>({
    resolver: zodResolver(phoneSchema),
    defaultValues: { phone: "" },
    mode: "onChange",
  });

  const codeForm = useForm<CodeValues>({
    resolver: zodResolver(codeSchema),
    defaultValues: { code: "" },
    mode: "onChange",
  });

  function submitPhone(values: PhoneValues) {
    startTransition(async () => {
      const result = await requestOtpAction(values.phone);
      if (!result.ok) {
        toastClientError("otp_request", result.message);
        return;
      }
      setPhone(values.phone);
      setStep("code");
      setCooldown(RESEND_COOLDOWN_SECONDS);
    });
  }

  function submitCode(values: CodeValues) {
    if (isPending) return;
    startTransition(async () => {
      const result = await verifyOtpAction(phone, values.code, {
        source: fromPreview ? "preview" : "direct",
        nextPath,
      });
      if (!result.ok) {
        setVerifyFailed(true);
        void trackEventAction({ event_name: "otp_verify_failed" });
        toastClientError("otp_verify", result.message);
        return;
      }
      router.push(nextPath);
      router.refresh();
    });
  }

  function resend() {
    if (cooldown > 0 || isPending) return;
    void trackEventAction({ event_name: "otp_resend_clicked" });
    startTransition(async () => {
      const result = await requestOtpAction(phone);
      if (!result.ok) {
        toastClientError("otp_resend", result.message);
        return;
      }
      setCooldown(RESEND_COOLDOWN_SECONDS);
      setJustResent(true);
      setTimeout(() => setJustResent(false), JUST_RESENT_DISPLAY_MS);
    });
  }

  if (step === "phone") {
    const hasError = Boolean(phoneForm.formState.errors.phone);
    const isValid = phoneForm.formState.isValid;

    return (
      <form onSubmit={phoneForm.handleSubmit(submitPhone)} className="flex flex-col gap-9">
        {reportReady && <ReportReadyBanner />}
        <div className="flex flex-col gap-4">
          <h1 className="text-[26px] leading-[1.65] font-extrabold text-pretty">
            {reportReady ? "گزارش‌تان را کجا ذخیره کنیم؟" : "ورود به فرامن"}
          </h1>
          {reportReady && (
            <p className="text-muted-foreground text-[14px] leading-[2]">
              برای اینکه گزارش ذخیره شود و بعداً بتوانید به آن برگردید، شمارهٔ موبایل‌تان را وارد کنید.
            </p>
          )}
        </div>

        <div className="flex flex-col gap-2.5">
          <label htmlFor="phone" className="text-muted-foreground text-[13px] font-bold">
            شمارهٔ موبایل
          </label>
          <input
            id="phone"
            dir="ltr"
            inputMode="tel"
            autoComplete="tel"
            placeholder="۰۹۱۲ ··· ····"
            className={`${inputBase} px-[18px] py-4 text-left text-[17px] ${
              hasError ? inputError : inputNormal
            }`}
            {...phoneForm.register("phone")}
          />
          {hasError ? (
            <p className="text-destructive text-xs">{phoneForm.formState.errors.phone?.message}</p>
          ) : (
            <p className="text-text-faint text-xs">کد تأیید برایتان پیامک می‌شود.</p>
          )}
        </div>

        <div className="flex flex-col gap-3.5">
          <button
            type="submit"
            disabled={!isValid || isPending}
            className={primaryButtonClass(isValid && !isPending, isPending)}
          >
            {isPending && <Spinner />}
            {isPending ? "در حال ارسال…" : "دریافت کد تأیید"}
          </button>
          {/* Digikala-style inline consent: no checkbox, nothing stored — proceeding implies acceptance. */}
          <div className="text-text-faint text-center text-xs leading-[1.9]">
            ورود یا ثبت‌نام شما به معنای پذیرش{" "}
            <Link
              href={`/terms?tab=terms&from=${encodeURIComponent(loginHref(nextPath))}`}
              className="text-primary font-bold no-underline"
            >
              شرایط استفاده فرامن
            </Link>{" "}
            و{" "}
            <Link
              href={`/terms?tab=privacy&from=${encodeURIComponent(loginHref(nextPath))}`}
              className="text-primary font-bold no-underline"
            >
              قوانین حریم‌خصوصی
            </Link>{" "}
            است
          </div>
        </div>
      </form>
    );
  }

  const codeHasError = Boolean(codeForm.formState.errors.code) || verifyFailed;
  const codeIsValid = codeForm.formState.isValid;
  const codeValue = codeForm.watch("code") ?? "";
  const digits = Array.from({ length: OTP_LENGTH }, (_, i) => codeValue[i] ?? "");

  return (
    <form onSubmit={codeForm.handleSubmit(submitCode)} className="flex flex-col gap-9">
      {reportReady && <ReportReadyBanner />}
      <div className="flex flex-col gap-4">
        <h1 className="text-[26px] leading-[1.65] font-extrabold">کد تأیید را وارد کنید</h1>
        <p className="text-muted-foreground text-[14px] leading-[2]">
          کد {toPersianDigits(OTP_LENGTH)} رقمی به شمارهٔ{" "}
          <span dir="ltr" className="text-foreground font-bold">
            {phone}
          </span>{" "}
          پیامک شد.
        </p>
      </div>

      <div className="flex flex-col gap-3.5">
        {/* Design System §5 — OTP boxes: OTP_LENGTH cells, 60px tall, border 1.5px, radius 14px; a
            transparent full-size input sits on top so mobile numeric keyboards & paste work. */}
        <div className="relative">
          <div dir="ltr" className="flex gap-2">
            {digits.map((char, i) => {
              const isActive = i === codeValue.length || Boolean(char);
              return (
                <div
                  key={i}
                  className={`flex h-[60px] flex-1 items-center justify-center rounded-[14px] border-[1.5px] bg-card text-[26px] font-extrabold text-foreground transition-colors ${
                    codeHasError ? inputError : isActive ? "border-primary" : "border-border"
                  }`}
                >
                  {char}
                </div>
              );
            })}
          </div>
          <input
            id="code"
            dir="ltr"
            inputMode="numeric"
            autoComplete="one-time-code"
            maxLength={OTP_LENGTH}
            autoFocus
            className="absolute inset-0 h-full w-full cursor-pointer font-sans opacity-0"
            {...codeForm.register("code", {
              onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
                setVerifyFailed(false);
                const value = toEnglishDigits(e.target.value).trim();
                if (new RegExp(`^\\d{${OTP_LENGTH}}$`).test(value)) {
                  codeForm.handleSubmit(submitCode)();
                }
              },
            })}
          />
        </div>
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={() => setStep("phone")}
            className="text-text-faint hover:text-foreground cursor-pointer text-[12.5px]"
          >
            تغییر شماره
          </button>
          <button
            type="button"
            onClick={resend}
            disabled={cooldown > 0 || isPending}
            className={`text-[12.5px] font-bold disabled:cursor-not-allowed ${
              cooldown > 0 ? "text-text-faint" : "text-primary cursor-pointer hover:underline"
            }`}
          >
            {justResent
              ? "کد دوباره ارسال شد ✓"
              : cooldown > 0
                ? `ارسال دوباره (${toPersianDigits(cooldown)})`
                : "ارسال دوبارهٔ کد"}
          </button>
        </div>
      </div>

      <button
        type="submit"
        disabled={!codeIsValid || isPending}
        className={primaryButtonClass(codeIsValid && !isPending, isPending)}
      >
        {isPending && <Spinner />}
        {isPending ? "در حال بررسی…" : "تأیید و ورود"}
      </button>
    </form>
  );
}
