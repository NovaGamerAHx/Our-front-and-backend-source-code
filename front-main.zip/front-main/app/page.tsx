import { cookies } from "next/headers";
import { ACCESS_TOKEN_COOKIE } from "@/lib/api/constants";
import { WorkspaceFrame } from "@/components/workspace/frame";
import { WorkspaceHome } from "@/components/workspace/home-view";
import { TrackOnMount } from "@/components/analytics/track-on-mount";
import { APP_URL } from "@/lib/api/constants";
import { AppHomeView } from "./_components/app-home-view";
import { LandingView } from "./_components/landing-view";

const JSON_LD = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: "فرامن",
  url: APP_URL,
  description: "یک ارزیابی کوتاه و محرمانه برای شناخت الگوها و نقاط قوت تو",
  inLanguage: "fa",
  publisher: {
    "@type": "Organization",
    name: "فرامن",
    url: APP_URL,
  },
};

export default async function LandingPage() {
  if ((await cookies()).has(ACCESS_TOKEN_COOKIE))
    return (
      <WorkspaceFrame>
        <WorkspaceHome />
      </WorkspaceFrame>
    );
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(JSON_LD) }}
      />
      <TrackOnMount event="landing_viewed" withUtm />
      <AppHomeView />
      <LandingView />
    </>
  );
}
