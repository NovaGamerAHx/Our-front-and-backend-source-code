import type { MetadataRoute } from "next";
import { APP_URL } from "@/lib/api/constants";

// Allow-list approach: everything is disallowed by default, and only the public marketing
// routes are explicitly allowed. Everything else here is either authenticated (dashboard,
// profile, chat, history, payment), a mid-flow step with no standalone SEO value (test/questions,
// test/analysis, checkin), or shows a specific visitor's personal assessment data (report,
// deep-report, preview, test/resume) and must never end up in a search index.
export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: "*",
      allow: ["/$", "/about", "/blog", "/test$", "/explore", "/terms"],
      disallow: "/",
    },
    sitemap: `${APP_URL}/sitemap.xml`,
  };
}
