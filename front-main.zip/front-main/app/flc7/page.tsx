import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { ACCESS_TOKEN_COOKIE } from "@/lib/api/constants";
import { getReportAttemptsHistory } from "@/lib/api/endpoints";
import { sanitizeSource } from "@/lib/analytics/source";
import {
  appendUtm,
  buildPaywallUrl,
  DEFAULT_PAY_UTM,
  readUtmFromSearchParams,
  sanitizeCoupon,
  shortLinkDefaultCoupon,
  withDefaultUtm,
} from "@/lib/constants/short-links";

type GoPayPageProps = {
  searchParams: Promise<{
    coupon?: string;
    source?: string;
    utm_source?: string;
    utm_medium?: string;
    utm_campaign?: string;
  }>;
};

/**
 * Payment short link (/flc7, alias of /go/pay): lands the visitor on the paywall for their finished deep
 * test, with the coupon pre-filled so they only have to confirm it.
 *
 * - Logged out -> /login with next back here (coupon + source preserved), so after login
 *   this page re-evaluates and sends them to the right place.
 * - Logged in with a deep attempt awaiting payment -> /paywall?deepAttemptId=<id>&coupon=<code>
 * - Logged in, already paid -> that deep report (nothing left to buy).
 * - Otherwise (no finished deep test yet) -> /deep-test intro: the backend only sells the
 *   deep report for a finished attempt, so there is no paywall to show yet.
 *
 * The coupon is pre-filled, never auto-applied -- the visitor still confirms it on the
 * paywall. An explicit ?coupon= wins (an empty ?coupon= means no pre-fill); without one,
 * SHORT_LINK_DEFAULT_COUPON applies (empty env value also means no pre-fill).
 *
 * UTM campaign params are forwarded through every redirect below; the faraman_utm cookie
 * itself is written by proxy.ts (UtmCapture never runs on this redirecting page).
 */
export default async function GoPayPage({ searchParams }: GoPayPageProps) {
  const rawParams = await searchParams;
  const { coupon: rawCoupon, source: rawSource } = rawParams;
  // Plain /flc7 (no UTM in URL) still registers under the default campaign; explicit
  // UTM params in the URL win per-key.
  const utm = withDefaultUtm(readUtmFromSearchParams(rawParams), DEFAULT_PAY_UTM);
  const source = sanitizeSource(rawSource);
  // Explicit ?coupon= always wins -- including an explicitly empty one (?coupon=), which
  // means "no pre-fill" for that link. Only when the param is absent entirely does the
  // env default (SHORT_LINK_DEFAULT_COUPON) apply. Never errors on a missing/blank code.
  const coupon = rawCoupon !== undefined ? sanitizeCoupon(rawCoupon) : shortLinkDefaultCoupon();

  const store = await cookies();
  if (!store.has(ACCESS_TOKEN_COOKIE)) {
    const nextParams = new URLSearchParams({ source });
    if (coupon) nextParams.set("coupon", coupon);
    for (const [key, value] of Object.entries(utm)) {
      if (value) nextParams.set(key, value);
    }
    redirect(`/login?${new URLSearchParams({ next: `/flc7?${nextParams.toString()}` }).toString()}`);
  }

  const attempts = await getReportAttemptsHistory().catch(() => []);
  const awaiting = attempts.find(
    (attempt) => attempt.report_type === "deep" && attempt.status === "awaiting_payment",
  );
  if (awaiting) {
    redirect(buildPaywallUrl(awaiting.attempt_id, coupon, utm));
  }

  const paid = attempts.find(
    (attempt) => attempt.report_type === "deep" && attempt.status === "ok",
  );
  if (paid) {
    redirect(appendUtm(`/deep-report?attemptId=${paid.attempt_id}`, utm));
  }

  redirect(appendUtm(`/deep-test?source=${encodeURIComponent(source)}`, utm));
}
