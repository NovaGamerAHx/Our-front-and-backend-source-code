import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { ImageResponse } from "next/og";

export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

// Kept text-free of Persian: satori (the renderer behind ImageResponse) only accepts ttf/otf/woff
// font data, and the site's Persian font ships as woff2 only, so Persian glyphs would render
// unshaped/broken here. The gradient matches the landing page hero and the mark is the brand logo; "faraman.app" is
// plain Latin text, which satori's default font renders fine.
export default async function Image() {
  const logo = await readFile(join(process.cwd(), "public/icons/logo-mark.png"));
  const logoSrc = `data:image/png;base64,${logo.toString("base64")}`;
  return new ImageResponse(
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 28,
        background: "linear-gradient(150deg, #1B2150 0%, #3A3D8F 55%, #8E6BA8 100%)",
      }}
    >
      <div
        style={{
          display: "flex",
          padding: 28,
          borderRadius: 48,
          background: "#ffffff",
        }}
      >
        <img src={logoSrc} width={200} height={200} alt="" />
      </div>
      <div style={{ display: "flex", fontSize: 56, fontWeight: 700, color: "#ffffff" }}>
        faraman.app
      </div>
    </div>,
    { ...size },
  );
}
