"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { LogoMark } from "@/components/site/logo-mark";
import { trackEventAction } from "@/lib/api/track-event-action";
import { completeAttemptAction, getReportAction } from "../../questions/actions";

// deep-report.md §5.1: report generation is up to 8 sequential/parallel paid model calls, so
// these rotate while polling instead of showing one static line for a potentially long wait.
const ANALYSIS_MESSAGES = [
  "داریم پاسخ‌هایت را دانه‌به‌دانه می‌خوانیم و کنار هم می‌گذاریم…",
  "روی این فکر می‌کنیم که این ویژگی‌ها کنار هم چه معنایی پیدا می‌کنند…",
  "الگوهای رفتاری‌ات را با هم می‌سنجیم تا تصویر درست را پیدا کنیم…",
  "حالا از دل همهٔ این‌ها گزارش نهایی را می‌نویسیم…",
];

// Absolute offsets (ms from mount) at which to advance to message 1, 2, 3. Paced to a typical
// end-to-end deep-report generation (~1 min) so the early lines don't flash past while the last
// line does most of the waiting -- polling still drives navigation, so a fast generation just
// cuts the sequence short and a slow one holds on "…گزارش نهایی را می‌نویسیم".
const MESSAGE_TIMINGS_MS = [16_000, 34_000, 54_000];

// However fast (or fast-failing) the request is, hold the loading screen up for at
// least this long so it reads as a real processing step instead of a flash.
const MIN_DISPLAY_MS = 2000;

// Report generation runs on a Celery worker (see faraman-back CLAUDE.md's async-tasks section)
// -- complete_attempt returns as soon as it's queued, so we poll until it's actually done.
const POLL_INTERVAL_MS = 3000;
// A deep report is up to 8 model calls, so give it noticeably longer than the initial report's
// budget before giving up and showing the "failed" retry screen.
const MAX_POLL_MS = 240_000;

export function DeepAnalysisLoader({ attemptId }: { attemptId: number | null }) {
  const router = useRouter();
  const [failed, setFailed] = useState(false);
  const [incomplete, setIncomplete] = useState(false);
  const [messageIdx, setMessageIdx] = useState(0);

  useEffect(() => {
    if (attemptId === null) {
      router.replace("/deep-test/questions");
    }
  }, [attemptId, router]);

  useEffect(() => {
    if (failed || incomplete) return;
    const timers = MESSAGE_TIMINGS_MS.map((at, i) => setTimeout(() => setMessageIdx(i + 1), at));
    return () => timers.forEach(clearTimeout);
  }, [failed, incomplete]);

  useEffect(() => {
    if (attemptId === null || failed || incomplete) return;

    let cancelled = false;
    let pollTimer: ReturnType<typeof setTimeout> | undefined;
    const minDisplay = new Promise<void>((resolve) => setTimeout(resolve, MIN_DISPLAY_MS));

    async function pollUntilReady(startedAt: number, properties: Record<string, unknown> | null) {
      const result = await getReportAction(attemptId as number);
      if (cancelled) return;

      // Pay-after-test: the answers are scored and saved, but the report itself is locked until
      // it is paid for. Nothing is being generated yet, so there is nothing to keep polling.
      if (result.ok && result.data.status === "awaiting_payment") {
        router.push(`/paywall?deepAttemptId=${attemptId}`);
        return;
      }

      if (result.ok && result.data.status !== "generating") {
        if (result.data.status === "ok" && properties) {
          void trackEventAction({ event_name: "report_generated", properties });
        }
        router.push(`/deep-report?attemptId=${attemptId}`);
        return;
      }

      if (Date.now() - startedAt > MAX_POLL_MS) {
        setFailed(true);
        return;
      }
      pollTimer = setTimeout(() => pollUntilReady(startedAt, properties), POLL_INTERVAL_MS);
    }

    Promise.all([completeAttemptAction(attemptId), minDisplay]).then(([result]) => {
      if (cancelled) return;
      if (!result.ok) {
        if (result.incomplete) {
          setIncomplete(true);
        } else {
          setFailed(true);
        }
        return;
      }
      // `data: null` means completeAttemptAction hit the 409-already-completed case
      // (a retry after a transient error) — the attempt was already counted as
      // completed the first time, so don't fire test_completed again here.
      let properties: Record<string, unknown> | null = null;
      if (result.data !== null) {
        const attempt = result.data;
        const durationMs =
          new Date(attempt.completed_at ?? Date.now()).getTime() -
          new Date(attempt.started_at).getTime();
        properties = {
          assessment_slug: attempt.assessment_slug,
          attempt_id: attempt.id,
          duration_ms: durationMs,
        };
        void trackEventAction({ event_name: "test_completed", properties });
      }
      void pollUntilReady(Date.now(), properties);
    });

    return () => {
      cancelled = true;
      if (pollTimer) clearTimeout(pollTimer);
    };
  }, [attemptId, failed, incomplete, router]);

  if (attemptId === null) return null;

  // e3 — the attempt was marked complete but required questions are still unanswered
  // (e.g. reached this page directly after skipping questions in the flow). Send the
  // user back to finish rather than showing the generic report-failure state.
  if (incomplete) {
    return (
      <main className="mx-auto box-border flex min-h-dvh w-full max-w-[390px] flex-col items-center justify-center gap-4 px-7 text-center">
        <div className="bg-secondary text-primary grid size-[72px] place-items-center rounded-full text-2xl">
          📝
        </div>
        <h1 className="text-lg font-extrabold">هنوز چند سؤال مانده</h1>
        <p className="text-muted-foreground max-w-[280px] text-[13px] leading-[2]">
          برای ساخت پروفایل دقیق باید به همهٔ سؤالات پاسخ دهید. پاسخ‌های شما محفوظ است.
        </p>
        <button
          onClick={() => router.push("/deep-test/questions")}
          className="bg-primary hover:bg-primary/90 min-h-11 w-full cursor-pointer rounded-2xl p-4 text-[15px] font-extrabold text-white"
        >
          ادامهٔ آزمون
        </button>
        <button
          onClick={() => router.push("/dashboard")}
          className="text-primary cursor-pointer text-[12.5px] font-bold hover:underline"
        >
          بعداً ادامه می‌دهم
        </button>
      </main>
    );
  }

  if (failed) {
    return (
      <main className="mx-auto box-border flex min-h-dvh w-full max-w-[390px] flex-col items-center justify-center gap-4 px-7 text-center">
        <div className="bg-danger-tint text-danger-text grid size-[72px] place-items-center rounded-full text-2xl">
          !
        </div>
        <h1 className="text-lg font-extrabold">در ساخت گزارش مشکلی پیش آمد</h1>
        <p className="text-muted-foreground max-w-[280px] text-[13px] leading-[2]">
          نگران نباشید — پاسخ‌هایتان محفوظ است و لازم نیست آزمون را دوباره بدهید.
        </p>
        <button
          onClick={() => setFailed(false)}
          className="bg-primary hover:bg-primary/90 min-h-11 w-full cursor-pointer rounded-2xl p-4 text-[15px] font-extrabold text-white"
        >
          تلاش دوباره
        </button>
        <button
          onClick={() => router.push("/dashboard")}
          className="text-primary cursor-pointer text-[12.5px] font-bold hover:underline"
        >
          بازگشت به داشبورد
        </button>
      </main>
    );
  }

  return (
    <main className="bg-gradient-dusk relative flex min-h-dvh flex-col items-center justify-center gap-[30px] overflow-hidden px-8">
      <div
        className="pointer-events-none absolute bottom-[-70px] left-[12%] size-[260px] rounded-full"
        style={{ background: "radial-gradient(circle, rgba(232,169,143,.4), transparent 70%)" }}
      />

      <div className="animate-fm-pulse grid size-28 place-items-center rounded-[32px] bg-white shadow-[0_12px_40px_rgba(0,0,0,.25)]">
        <LogoMark height={72} />
      </div>

      <div
        key={messageIdx}
        className="animate-fm-in max-w-[400px] text-center text-[17.5px] leading-[1.8] font-extrabold text-white"
      >
        {ANALYSIS_MESSAGES[messageIdx]}
      </div>

      <div className="flex gap-2">
        {ANALYSIS_MESSAGES.map((_, i) => (
          <div
            key={i}
            className="h-1 w-[34px] rounded-full transition-colors duration-400"
            style={{
              background: i <= messageIdx ? "rgba(255,255,255,.9)" : "rgba(255,255,255,.22)",
            }}
          />
        ))}
      </div>
      <div className="text-xs text-white/60">آماده‌سازی گزارش چند لحظه طول می‌کشد</div>
    </main>
  );
}
