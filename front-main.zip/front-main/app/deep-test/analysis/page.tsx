import { DeepAnalysisLoader } from "./_components/deep-analysis-loader";

type DeepAnalysisPageProps = {
  searchParams: Promise<{ attemptId?: string; retry?: string }>;
};

export default async function DeepAnalysisPage({ searchParams }: DeepAnalysisPageProps) {
  const { attemptId: raw, retry } = await searchParams;
  const attemptId = raw ? Number(raw) : NaN;

  return (
    <DeepAnalysisLoader
      attemptId={Number.isFinite(attemptId) ? attemptId : null}
      retry={retry === "1"}
    />
  );
}
