import { DeepAnalysisLoader } from "./_components/deep-analysis-loader";

type DeepAnalysisPageProps = {
  searchParams: Promise<{ attemptId?: string }>;
};

export default async function DeepAnalysisPage({ searchParams }: DeepAnalysisPageProps) {
  const { attemptId: raw } = await searchParams;
  const attemptId = raw ? Number(raw) : NaN;

  return <DeepAnalysisLoader attemptId={Number.isFinite(attemptId) ? attemptId : null} />;
}
