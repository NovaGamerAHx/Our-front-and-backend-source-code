import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { ACCESS_TOKEN_COOKIE, DEEP_ASSESSMENT_SLUG } from "@/lib/api/constants";
import { getPreStart } from "@/lib/api/endpoints";
import { TrackOnMount } from "@/components/analytics/track-on-mount";
import { sanitizeSource } from "@/lib/analytics/source";
import { DeepTestIntroView } from "./_components/deep-test-intro-view";

export default async function DeepTestPage({
  searchParams,
}: {
  searchParams: Promise<{ source?: string }>;
}) {
  const source = sanitizeSource((await searchParams).source);
  const store = await cookies();
  const isAuthenticated = store.has(ACCESS_TOKEN_COOKIE);

  // The test itself is free (pay-after-test): payment happens at /paywall once it is finished,
  // before the report opens. Login is still required up front -- the report is owner-only, and
  // the finished attempt has to belong to the account that will pay for it.
  if (!isAuthenticated) {
    redirect(`/login?${new URLSearchParams({ next: `/deep-test?source=${source}` }).toString()}`);
  }

  // Best-effort, same as the free intro (app/test/page.tsx): never block this screen on this
  // call failing.
  const preStart = await getPreStart(DEEP_ASSESSMENT_SLUG).catch(
    (): { remaining_attempts_today: number; attempt_limit: number } | null => null,
  );
  const capped = preStart !== null && preStart.remaining_attempts_today <= 0;

  return (
    <>
      <TrackOnMount event="deep_intro_viewed" properties={{ source }} />
      <DeepTestIntroView capped={capped} source={source} />
    </>
  );
}
