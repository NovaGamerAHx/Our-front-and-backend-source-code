import Link from "next/link";
import { Check, Clock } from "lucide-react";

const CHECKLIST = [
  { tile: "۳۰", label: "۳۰ کارت پنج‌سؤالی — حدود ۲۵ دقیقه در کل" },
  { icon: Clock, label: "هر جا خواستی توقف کن؛ پاسخ‌ها نگه داشته می‌شوند" },
  { icon: Check, label: "پاسخ درست و غلط ندارد — نزدیک‌ترین گزینه به این چند ماهت را انتخاب کن" },
];

export function DeepTestIntroView({ capped, source }: { capped: boolean; source: string }) {
  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col gap-[30px] px-7 pt-6 pb-12">
      <div className="flex items-center gap-3">
        <Link
          href="/explore"
          className="border-border text-muted-foreground bg-card grid size-10 place-items-center rounded-xl border text-base"
        >
          →
        </Link>
        <div className="text-text-faint text-[13px] font-bold">آزمون تکمیلی</div>
      </div>

      <div className="flex flex-col gap-3.5">
        <h1 className="text-[26px] leading-[1.6] font-extrabold text-pretty">۱۵۰ سؤال</h1>
        <p className="text-muted-foreground text-[13.5px] leading-[2.05]">
          هر صفحه فقط پنج سؤال دارد. لازم نیست یک‌جا تمامش کنی — هر کارت که تمام شود، ذخیره می‌شود و
          می‌توانی بعداً از همان‌جا ادامه بدهی.
        </p>
      </div>

      <div className="flex flex-col gap-0.5">
        {CHECKLIST.map((item, index) => (
          <div
            key={item.label}
            className={`flex items-center gap-[13px] py-[15px] ${
              index < CHECKLIST.length - 1 ? "border-border border-b" : ""
            }`}
          >
            <div className="text-primary bg-secondary grid size-9 flex-none place-items-center rounded-xl text-[13px] font-extrabold">
              {"tile" in item ? item.tile : <item.icon size={18} strokeWidth={1.8} />}
            </div>
            <div className="text-[13.5px] leading-[1.6] font-semibold">{item.label}</div>
          </div>
        ))}
      </div>

      <div className="flex flex-col gap-3">
        {capped ? (
          <>
            <p className="text-text-faint text-center text-[12.5px] leading-[1.9]">
              امروز به سقف آزمون‌های تازه رسیده‌اید — پاسخ‌های در حال انجام محفوظ است. فردا دوباره
              تلاش کنید.
            </p>
            <button
              type="button"
              disabled
              className="bg-disabled min-h-11 cursor-not-allowed rounded-2xl p-4 text-center text-base font-extrabold text-white"
            >
              شروع کارت اول
            </button>
          </>
        ) : (
          <Link
            href={`/deep-test/questions?source=${source}`}
            className="bg-primary shadow-cta min-h-12 rounded-2xl p-[17px] text-center text-base font-extrabold text-white"
          >
            شروع کارت اول
          </Link>
        )}
      </div>

      <div className="bg-muted flex flex-col gap-2 rounded-[18px] px-5 py-[18px]">
        <div className="text-[12.5px] font-extrabold">راهنمای پاسخ</div>
        <p className="text-text-faint text-[12.5px] leading-[1.95]">
          بر اساس اینکه هر عبارت در چند ماه اخیر و در بیشتر موقعیت‌ها چقدر تو را توصیف می‌کند پاسخ
          بده، نه بر اساس اینکه دوست داری چطور باشی.
        </p>
      </div>
    </main>
  );
}
