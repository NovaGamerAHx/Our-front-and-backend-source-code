import { toPersianDigits } from "@/lib/utils/digits";

export function DeepMilestoneView({
  pct,
  title,
  body,
  onContinue,
  onLater,
}: {
  pct: number;
  title: string;
  body: string;
  onContinue: () => void;
  onLater: () => void;
}) {
  return (
    <main className="bg-gradient-dusk relative flex min-h-dvh flex-col items-center justify-center gap-[26px] overflow-hidden px-8 py-12">
      <div
        className="pointer-events-none absolute -bottom-[60px] -left-[60px] size-[280px] rounded-full"
        style={{ background: "radial-gradient(circle, rgba(232,169,143,.35), transparent 70%)" }}
      />
      <div
        className="relative grid size-[158px] flex-none place-items-center rounded-full"
        style={{
          background: `conic-gradient(#E8B98F 0 ${pct}%, rgba(255,255,255,.14) ${pct}% 100%)`,
          boxShadow: "0 18px 40px rgba(12,16,48,.35)",
        }}
      >
        <div className="flex size-[132px] flex-col items-center justify-center gap-0.5 rounded-full border border-white/12 bg-[#242B62]">
          <div className="flex items-baseline gap-0.5">
            <div className="text-[42px] leading-none font-black tracking-[-1px] text-white">
              {toPersianDigits(pct)}
            </div>
            <div className="text-[17px] leading-none font-extrabold text-[#E8B98F]">٪</div>
          </div>
          <div className="text-[10.5px] font-bold tracking-[.3px] text-white/55">تکمیل شده</div>
        </div>
      </div>
      <div className="relative flex max-w-[420px] flex-col items-center gap-3.5 text-center">
        <div className="text-[22px] leading-[1.6] font-extrabold text-white">{title}</div>
        <p className="text-[13.5px] leading-[2.05] text-white/82">{body}</p>
      </div>
      <div className="relative flex w-full max-w-[340px] flex-col gap-3">
        <button
          type="button"
          onClick={onContinue}
          className="text-primary-deep min-h-12 cursor-pointer rounded-2xl bg-white p-4 text-[15.5px] font-extrabold"
        >
          ادامه می‌دهم
        </button>
        <button
          type="button"
          onClick={onLater}
          className="min-h-9 cursor-pointer self-center bg-transparent p-1.5 text-[12.5px] font-bold text-white/62"
        >
          بعداً ادامه می‌دهم
        </button>
      </div>
    </main>
  );
}
