"use client";

import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { toPersianDigits } from "@/lib/utils/digits";
import { Spinner } from "@/components/ui/spinner";
import type { AssessmentQuestion } from "@/lib/api/schemas";
import { trackEventAction } from "@/lib/api/track-event-action";
import {
  completeAttemptAction,
  getReportAction,
  startAttemptAction,
  submitAnswerAction,
} from "../actions";
import { DeepMilestoneView } from "./deep-milestone-view";

const SCALE_VALUES = [1, 2, 3, 4, 5];
const PER_CARD = 5;

// Not tied to real scored domains yet (the level a card unlocks isn't known until the whole
// attempt is scored) -- these are pacing checkpoints only, keyed by the card index a "next"
// click is about to land on (mirrors the design reference's deepMilestones[card+1] convention).
// Percent is of total *questions* answered, not cards, since that's what the copy promises.
const MILESTONES: Record<number, { pct: number; title: string; body: string }> = {
  6: {
    pct: 20,
    title: "خوب شروع کردی",
    body: "همین که نشستی و با خودت روراست جواب دادی، یعنی می‌خواهی خودت را بهتر بشناسی. پاسخ‌هایت ذخیره شده؛ حالا که راه افتادی، ادامه بده.",
  },
  15: {
    pct: 50,
    title: "نصف راه را آمدی",
    body: "تا اینجا کم‌کم دارد تصویری از تو شکل می‌گیرد. نیمهٔ دوم همان چیزی است که این تصویر را از یک برداشت کلی به شناختی دقیق از خودت تبدیل می‌کند.",
  },
  23: {
    pct: 75,
    title: "چیزی نمانده",
    body: "بیشتر راه را آمده‌ای و سخت‌ترش گذشته است. فقط چند کارت دیگر مانده تا پروفایل کامل توسعهٔ فردی‌ات آماده شود؛ کاری را که شروع کردی، تمام کن.",
  },
};

function scaleButtonClass(selected: boolean) {
  return `h-[50px] flex-1 cursor-pointer rounded-[14px] text-[15px] font-extrabold transition-all ${
    selected
      ? "border-2 border-primary bg-primary text-white"
      : "border-[1.5px] border-border bg-white text-text-secondary hover:border-primary/50"
  }`;
}

export function DeepQuestionFlow({ questions }: { questions: AssessmentQuestion[] }) {
  const router = useRouter();
  const [attemptId, setAttemptId] = useState<number | null>(null);
  const [attemptFailed, setAttemptFailed] = useState(false);
  const [cardIndex, setCardIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [milestoneKey, setMilestoneKey] = useState<number | null>(null);
  const [seenMilestones, setSeenMilestones] = useState<Record<number, boolean>>({});
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    startAttemptAction().then((result) => {
      if (!result.ok) {
        setAttemptFailed(true);
        toast.error(result.message);
        return;
      }
      setAttemptId(result.data.id);
      if (result.data.answers.length === 0) {
        void trackEventAction({
          event_name: "test_started",
          properties: { assessment_slug: result.data.assessment_slug, attempt_id: result.data.id },
        });
        return;
      }

      const resumedAnswers: Record<number, number> = {};
      for (const answer of result.data.answers) {
        resumedAnswers[answer.question_id] = answer.value;
      }
      setAnswers(resumedAnswers);

      const firstUnanswered = questions.findIndex((q) => !(q.id in resumedAnswers));
      const startIndex = firstUnanswered === -1 ? questions.length - 1 : firstUnanswered;
      setCardIndex(Math.floor(startIndex / PER_CARD));
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (questions.length === 0) {
    return (
      <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[600px] flex-col items-center justify-center gap-4 px-7 text-center">
        <p className="text-muted-foreground text-[14.5px] leading-[2.05]">
          سؤالی برای این آزمون یافت نشد.
        </p>
      </main>
    );
  }

  if (attemptFailed) {
    return (
      <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[600px] flex-col items-center justify-center gap-5 px-7 text-center">
        <p className="text-muted-foreground text-[14.5px] leading-[2.05]">
          شروع آزمون با خطا مواجه شد.
        </p>
        <button
          onClick={() => window.location.reload()}
          className="bg-primary hover:bg-primary/90 min-h-11 cursor-pointer rounded-2xl px-6 py-3 text-[14px] font-extrabold text-white"
        >
          تلاش دوباره
        </button>
      </main>
    );
  }

  const cardsTotal = Math.ceil(questions.length / PER_CARD);
  const cardQuestions = questions.slice(cardIndex * PER_CARD, cardIndex * PER_CARD + PER_CARD);
  const answeredCount = Object.keys(answers).length;
  const cardDone = cardQuestions.every((q) => q.id in answers);
  const remaining = cardQuestions.filter((q) => !(q.id in answers)).length;
  const isLastCard = cardIndex === cardsTotal - 1;
  const ready = attemptId !== null;

  function selectValue(questionId: number, value: number) {
    if (!attemptId || isPending) return;
    setAnswers((prev) => ({ ...prev, [questionId]: value }));
    startTransition(async () => {
      const result = await submitAnswerAction(attemptId, questionId, value);
      if (!result.ok) {
        toast.error(result.message);
        setAnswers((prev) => {
          const next = { ...prev };
          delete next[questionId];
          return next;
        });
      }
    });
  }

  /** Completes the attempt, then goes where the report is: the paywall while it is still locked
   * (pay-after-test: the payment screen comes straight after the last question and the analysis
   * screen only after paying), or the analysis screen when generation already started (e.g. a
   * pre-existing purchase was spent on this attempt). */
  function finishTest() {
    if (!attemptId) return;
    startTransition(async () => {
      const completed = await completeAttemptAction(attemptId);
      if (!completed.ok) {
        if (completed.incomplete) {
          toast.error("هنوز به همهٔ سؤالات پاسخ نداده‌ای.");
        } else {
          toast.error(completed.message);
        }
        return;
      }
      // `data: null` is the 409 already-completed case (a retry) -- the event fired the first time.
      if (completed.data !== null) {
        const attempt = completed.data;
        void trackEventAction({
          event_name: "test_completed",
          properties: {
            assessment_slug: attempt.assessment_slug,
            attempt_id: attempt.id,
            duration_ms:
              new Date(attempt.completed_at ?? Date.now()).getTime() -
              new Date(attempt.started_at).getTime(),
          },
        });
      }

      const report = await getReportAction(attemptId);
      if (report.ok && report.data.status === "awaiting_payment") {
        router.push(`/paywall?deepAttemptId=${attemptId}`);
      } else {
        router.push(`/deep-test/analysis?attemptId=${attemptId}`);
      }
    });
  }

  /** Lands on `nextCard` — either the next card of 5, or the end of the test once every card is
   * done. Shared by the plain "next" path and the milestone screen's "continue". */
  function landOn(nextCard: number) {
    if (nextCard >= cardsTotal) {
      finishTest();
      return;
    }
    setCardIndex(nextCard);
    setMilestoneKey(null);
    window.scrollTo({ top: 0 });
  }

  function goNext() {
    if (!cardDone) return;
    const nextCard = cardIndex + 1;
    if (MILESTONES[nextCard] && !seenMilestones[nextCard]) {
      setSeenMilestones((prev) => ({ ...prev, [nextCard]: true }));
      setMilestoneKey(nextCard);
      return;
    }
    landOn(nextCard);
  }

  function goBack() {
    if (cardIndex === 0) {
      router.push("/deep-test");
      return;
    }
    setCardIndex((i) => i - 1);
    window.scrollTo({ top: 0 });
  }

  if (milestoneKey !== null) {
    const milestone = MILESTONES[milestoneKey];
    return (
      <DeepMilestoneView
        pct={milestone.pct}
        title={milestone.title}
        body={milestone.body}
        onContinue={() => landOn(milestoneKey)}
        onLater={() => router.push("/dashboard")}
      />
    );
  }

  return (
    <main className="mx-auto box-border flex min-h-dvh w-full max-w-[600px] flex-col gap-[22px] px-7 pb-10">
      <div className="bg-background sticky top-0 z-10 flex flex-col gap-3 py-[18px]">
        <div className="flex items-center gap-3">
          <button
            onClick={goBack}
            className="border-border text-muted-foreground bg-card grid size-[38px] flex-none cursor-pointer place-items-center rounded-xl border text-base"
          >
            →
          </button>
          <div className="flex flex-1 flex-col gap-0.5">
            <div className="text-[13.5px] font-extrabold">
              کارت {toPersianDigits(cardIndex + 1)} از {toPersianDigits(cardsTotal)}
            </div>
            <div className="text-text-faint text-[11.5px] font-bold">
              {toPersianDigits(answeredCount)} از {toPersianDigits(questions.length)} سؤال
            </div>
          </div>
          <button
            onClick={() => router.push("/dashboard")}
            className="text-primary cursor-pointer text-xs font-extrabold whitespace-nowrap"
          >
            ذخیره و خروج
          </button>
        </div>
        <div className="bg-border h-1.5 overflow-hidden rounded-full">
          <div
            className="bg-gradient-meter h-full rounded-full transition-all"
            style={{ width: `${(answeredCount / questions.length) * 100}%` }}
          />
        </div>
      </div>

      <div key={cardIndex} className="animate-fm-in flex flex-col gap-3.5">
        {cardQuestions.map((question, k) => {
          const selected = answers[question.id];
          return (
            <div
              key={question.id}
              className="shadow-card border-border flex flex-col gap-4 rounded-[20px] border bg-white p-5"
            >
              <div className="flex items-start gap-3">
                <div className="text-primary bg-secondary mt-0.5 grid size-7 flex-none place-items-center rounded-[9px] text-xs font-extrabold">
                  {toPersianDigits(k + 1)}
                </div>
                <div className="text-[15px] leading-[1.95] font-bold">
                  {question.text}
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <div className="flex gap-2">
                  {SCALE_VALUES.map((value) => (
                    <button
                      key={value}
                      onClick={() => selectValue(question.id, value)}
                      disabled={!ready || isPending}
                      className={scaleButtonClass(selected === value)}
                    >
                      {toPersianDigits(value)}
                    </button>
                  ))}
                </div>
                <div className="flex justify-between">
                  <span className="text-text-faint text-[11.5px]">کاملاً مخالفم</span>
                  <span className="text-text-faint text-[11.5px]">کاملاً موافقم</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-auto pt-2">
        <button
          onClick={goNext}
          disabled={!ready || !cardDone || isPending}
          className={`flex min-h-[50px] w-full items-center justify-center gap-2.5 rounded-2xl p-4 text-[15.5px] font-extrabold text-white transition-colors ${
            ready && cardDone && !isPending
              ? "bg-primary hover:bg-primary/90 cursor-pointer"
              : cardDone && isPending
                ? "bg-primary opacity-75"
                : "bg-disabled cursor-not-allowed"
          }`}
        >
          {isPending && cardDone && <Spinner />}
          {cardDone
            ? isLastCard
              ? "پایان"
              : "کارت بعدی"
            : `به ${toPersianDigits(remaining)} سؤال باقی‌مانده پاسخ بده`}
        </button>
      </div>
    </main>
  );
}
