import { ApiError } from "@/lib/api/client";
import { getAssessment } from "@/lib/api/endpoints";
import { DEEP_ASSESSMENT_SLUG } from "@/lib/api/constants";
import { TrackOnMount } from "@/components/analytics/track-on-mount";
import { sanitizeSource } from "@/lib/analytics/source";
import { DeepQuestionFlow } from "./_components/deep-question-flow";

export default async function DeepTestQuestionsPage({
  searchParams,
}: {
  searchParams: Promise<{ source?: string }>;
}) {
  const source = sanitizeSource((await searchParams).source);
  let questions;
  try {
    const assessment = await getAssessment(DEEP_ASSESSMENT_SLUG);
    questions = assessment.questions
      .filter((q) => q.question_type === "likert")
      .sort((a, b) => a.order - b.order);
  } catch (error) {
    const message = error instanceof ApiError ? error.message : "آزمون در حال حاضر در دسترس نیست.";
    return (
      <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col items-center justify-center gap-4 px-7 text-center">
        <p className="text-muted-foreground text-[14.5px] leading-[2.05]">{message}</p>
      </main>
    );
  }

  return (
    <>
      <TrackOnMount event="deep_questions_viewed" properties={{ source }} />
      <DeepQuestionFlow questions={questions} />
    </>
  );
}
