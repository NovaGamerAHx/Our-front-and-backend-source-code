import type { Metadata } from "next";
import { Newspaper } from "lucide-react";
import { NotifyButton } from "./_components/notify-button";

export const metadata: Metadata = {
  title: "فرابلاگ",
  description:
    "به‌زودی: نوشته‌هایی دربارهٔ شناخت خود، تصمیم‌گیری و عادت‌های کوچک — کوتاه، قابل‌اجرا و هم‌راستا با گزارش فرامن.",
};

const BLOG_QUEUE = [
  { title: "چرا برچسب شخصیتی کافی نیست", bar: "72%", status: "در ویرایش" },
  { title: "تصمیم‌های کوچک، اثر بزرگ", bar: "48%", status: "در نگارش" },
  { title: "چطور گزارش‌تان را بخوانید", bar: "26%", status: "طرح اولیه" },
];

export default function BlogPage() {
  return (
    <main className="mx-auto box-border flex w-full max-w-[880px] flex-col gap-[30px] px-7 pt-11 pb-[72px]">
      <div className="flex max-w-[560px] flex-col gap-3">
        <div className="self-start rounded-full bg-[#F1EAF5] px-3.5 py-[7px] text-[11.5px] font-extrabold text-[#6C4F86]">
          به‌زودی
        </div>
        <h1 className="text-[29px] leading-[1.6] font-extrabold text-pretty">
          فرابلاگ در حال ساخت است
        </h1>
        <p className="text-[14px] leading-[2.1] text-pretty text-[#5D5C55]">
          اینجا به‌زودی نوشته‌هایی دربارهٔ شناخت خود، تصمیم‌گیری و عادت‌های کوچک منتشر می‌شود —
          کوتاه، قابل‌اجرا و هم‌راستا با همان چیزی که در گزارش‌تان می‌بینید.
        </p>
      </div>

      <div className="border-border flex flex-col gap-5 rounded-[24px] border bg-white p-[26px] shadow-[0_10px_30px_rgba(80,70,40,.05)]">
        <div className="flex items-center gap-3.5">
          <div className="bg-secondary grid size-[46px] flex-none place-items-center rounded-[15px]">
            <Newspaper size={22} strokeWidth={1.8} className="text-primary" />
          </div>
          <div className="flex flex-col gap-0.5">
            <div className="text-[15px] font-extrabold">اولین نوشته‌ها در راه‌اند</div>
            <div className="text-text-faint text-[12.5px]">سه مقالهٔ نخست در دست تحریریه است</div>
          </div>
        </div>

        <div className="flex flex-col gap-3">
          {BLOG_QUEUE.map((item) => (
            <div
              key={item.title}
              className="flex items-center gap-3.5 rounded-2xl border border-dashed border-[#E3DCCC] bg-[#FCFAF4] px-[17px] py-[15px]"
            >
              <div
                className="size-14 flex-none rounded-xl"
                style={{ background: "linear-gradient(150deg,#EDEAF6,#E5E9F7)" }}
              />
              <div className="flex flex-1 flex-col gap-[7px]">
                <div className="text-[13.5px] font-bold text-[#3B3A34]">{item.title}</div>
                <div className="h-[7px] overflow-hidden rounded-full bg-[#EDE7DA]">
                  <div className="bg-primary h-full rounded-full" style={{ width: item.bar }} />
                </div>
              </div>
              <div className="text-text-faint flex-none text-[11.5px] font-bold">{item.status}</div>
            </div>
          ))}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 border-t border-[#F2EDE1] pt-5">
          <div className="max-w-[320px] text-[12.5px] leading-[1.9] text-[#5D5C55]">
            می‌خواهید وقتی منتشر شد خبردار شوید؟
          </div>
          <NotifyButton />
        </div>
      </div>
    </main>
  );
}
