"use client";

import { useState } from "react";
import { Check } from "lucide-react";

export function NotifyButton() {
  const [notified, setNotified] = useState(false);

  if (notified) {
    return (
      <div className="flex items-center gap-2.5 rounded-full bg-[#EAF3EC] px-5 py-3 text-[12.5px] font-extrabold text-[#2F6B45]">
        <Check size={16} strokeWidth={2.2} />
        <span>وقتی منتشر شد خبرتان می‌کنیم</span>
      </div>
    );
  }

  return (
    <button
      type="button"
      onClick={() => setNotified(true)}
      className="bg-primary hover:bg-primary/90 min-h-11 cursor-pointer rounded-full px-6 py-[13px] text-[13px] font-extrabold text-white"
    >
      خبرم کن
    </button>
  );
}
