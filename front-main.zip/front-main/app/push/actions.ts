"use server";

import { ApiError } from "@/lib/api/client";
import { registerPushSubscription } from "@/lib/api/endpoints";

type ActionResult<T> = { ok: true; data: T } | { ok: false; message: string };

const GENERIC_ERROR = "خطای غیرمنتظره‌ای رخ داد. لطفاً دوباره تلاش کنید.";

function toResult<T>(fn: () => Promise<T>) {
  return fn()
    .then((data): ActionResult<T> => ({ ok: true, data }))
    .catch((error): ActionResult<T> => ({
      ok: false,
      message: error instanceof ApiError ? error.message : GENERIC_ERROR,
    }));
}

export async function registerPushSubscriptionAction(
  token: string,
): Promise<ActionResult<{ tokenWasInactive: boolean }>> {
  return toResult(() =>
    registerPushSubscription({ token }).then((result) => ({ tokenWasInactive: result?.token_was_inactive ?? false })),
  );
}
