import { redirect } from "next/navigation";
import { sanitizeSource } from "@/lib/analytics/source";
import {
  appendUtm,
  DEFAULT_DEEP_UTM,
  readUtmFromSearchParams,
  shortLinkDeepSource,
  withDefaultUtm,
} from "@/lib/constants/short-links";

type GoDeepPageProps = {
  searchParams: Promise<{
    source?: string;
    utm_source?: string;
    utm_medium?: string;
    utm_campaign?: string;
  }>;
};

/**
 * Deep-test short link (/c9, alias of /go/deep): for SMS invites to people who took the initial test.
 * Forwards to the deep-test intro (/deep-test), which itself handles the login redirect
 * (with next preserved) for logged-out visitors. An explicit ?source= wins; without one,
 * SHORT_LINK_DEEP_SOURCE (default "sms") applies.
 *
 * UTM campaign params are forwarded to /deep-test; the faraman_utm cookie itself is
 * written by proxy.ts (UtmCapture never runs on this redirecting page).
 */
export default async function GoDeepPage({ searchParams }: GoDeepPageProps) {
  const rawParams = await searchParams;
  const { source: rawSource } = rawParams;
  // Plain /c9 (no UTM in URL) still registers under the default campaign; explicit
  // UTM params in the URL win per-key.
  const utm = withDefaultUtm(readUtmFromSearchParams(rawParams), DEFAULT_DEEP_UTM);
  const source = rawSource ? sanitizeSource(rawSource) : shortLinkDeepSource();
  redirect(appendUtm(`/deep-test?source=${encodeURIComponent(source)}`, utm));
}
