import { cookies } from "next/headers";
import Link from "next/link";
import { redirect } from "next/navigation";
import { ACCESS_TOKEN_COOKIE } from "@/lib/api/constants";
import { ApiError } from "@/lib/api/client";
import { getActionStep } from "@/lib/api/endpoints";
import { StepNotificationCard } from "@/components/action-steps/step-notification-card";
import { TrackOnMount } from "@/components/analytics/track-on-mount";

type CheckinPageProps = {
  params: Promise<{ actionStepId: string }>;
  searchParams: Promise<{ kind?: string }>;
};

// Notification-tap deep link (chat_spec_v2, action_steps_spec_v2 §7). `kind` on the query string
// (set by NotificationService._send_one on the backend) tells us whether this was a reminder or
// a followup push, since both point at the same /checkin/:id route.
export default async function CheckinPage({ params, searchParams }: CheckinPageProps) {
  const { actionStepId } = await params;
  const { kind: rawKind } = await searchParams;
  const kind = rawKind === "reminder" ? "reminder" : "followup";

  const store = await cookies();
  if (!store.has(ACCESS_TOKEN_COOKIE)) {
    redirect(`/login?${new URLSearchParams({ next: `/checkin/${actionStepId}` }).toString()}`);
  }

  let step = null;
  try {
    step = await getActionStep(actionStepId);
  } catch (error) {
    if (error instanceof ApiError && error.status === 401) {
      redirect(`/login?${new URLSearchParams({ next: `/checkin/${actionStepId}` }).toString()}`);
    }
    // 403/404 (not owned, or already answered/reactivated) -- fall through to the unavailable
    // card below rather than an error page.
  }

  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col gap-6 px-7 pt-8 pb-12">
      <TrackOnMount event="checkin_notif_opened" properties={{ action_step_id: actionStepId }} />
      {step && step.status === "pending" ? (
        <StepNotificationCard step={step} kind={kind} channel="notif" />
      ) : (
        <div className="shadow-card border-border bg-card flex flex-col gap-3 rounded-2xl border p-5">
          <div className="text-[14px] font-extrabold">این قدم دیگر در دسترس نیست</div>
          <p className="text-muted-foreground m-0 text-[12.5px] leading-[1.95]">
            پاسخش را قبلاً ثبت کرده‌اید یا قدم تازه‌ای جایگزینش شده است.
          </p>
          <Link
            href="/dashboard"
            className="bg-primary min-h-11 max-w-max self-start rounded-2xl px-[22px] py-3 text-[13.5px] font-extrabold text-white"
          >
            بازگشت به خانه
          </Link>
        </div>
      )}
    </main>
  );
}
