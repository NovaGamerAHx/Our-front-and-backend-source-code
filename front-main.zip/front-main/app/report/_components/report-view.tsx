"use client";

import { useEffect, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { ChevronDown, Mail, MessageCircle } from "lucide-react";
import { Spinner } from "@/components/ui/spinner";
import {
  ACTION_TYPE_LABELS,
  DIMENSION_ICONS,
  DIMENSION_LABELS,
  DIMENSION_LEVEL_COLORS,
  DIMENSION_LEVEL_LABELS,
  LIFE_PATTERN_LABELS,
  RADAR_AXES,
  computeRadarPolygonPoints,
  sortDimensionsByScore,
} from "@/lib/utils/report";
import { toPersianDigits } from "@/lib/utils/digits";
import { ComingSoonButton } from "@/components/report/coming-soon-button";
import { sendReportEmailAction } from "@/components/report/actions";
import { TopEmailStrip } from "@/components/report/top-email-strip";
import { TrackOnMount } from "@/components/analytics/track-on-mount";
import { ActionStepProposalSheet } from "@/components/action-steps/action-step-proposal-sheet";
import { SELF_KNOWLEDGE_ASSESSMENT_SLUG } from "@/lib/api/constants";
import type { FullDimensionScore, ReportData, SuggestedStep } from "@/lib/api/schemas";

// Design handoff's send-button icon (a plain arrow shape, not lucide's paper-plane Send) --
// mirrored via -scale-x-100 since it's authored pointing up-left but every composer here sits
// in an RTL layout with the button on the input's leading (right) edge.
function SendIcon({ size = 18, color = "#fff" }: { size?: number; color?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke={color}
      strokeWidth={1.9}
      strokeLinecap="round"
      strokeLinejoin="round"
      className="-scale-x-100"
    >
      <path d="m22 2-7 20-4-9-9-4Z" />
      <path d="M22 2 11 13" />
    </svg>
  );
}

const DEEP_TEST_BENEFITS = [
  { title: "۳۰ ویژگی شخصیتی", desc: "از نظم و اضطراب تا کنجکاوی و صراحت" },
  { title: "گزارش کامل", desc: "سبک تصمیم‌گیری، ارتباط، کار، استرس، یادگیری و روابط" },
  { title: "نقاط قوت و نقاط کور", desc: "چیزهایی که بهشون تکیه می‌کنی، و چیزهایی که ممکنه نبینی" },
  { title: "گفتگو با هوش مصنوعی", desc: "دربارهٔ هر بخش از گزارش سؤال بپرس" },
];

const STRENGTH_ICON_CONFIG = [
  { bg: "#E9EBF8", src: "/report-icons/strength-1.png" },
  { bg: "#F3EBF6", src: "/report-icons/strength-2.png" },
  { bg: "#FBF3E4", src: "/report-icons/strength-3.png" },
];

const RADAR_LABEL_POSITIONS: Record<FullDimensionScore["key"], React.CSSProperties> = {
  emotional_stability: {
    top: 0,
    left: "50%",
    transform: "translateX(-50%)",
    textAlign: "center",
    whiteSpace: "nowrap",
  },
  extraversion: { top: "30%", right: 0, maxWidth: "34%", textAlign: "center" },
  openness: { bottom: 0, right: 0, textAlign: "center", whiteSpace: "nowrap" },
  agreeableness: { bottom: 0, left: 0, textAlign: "center", whiteSpace: "nowrap" },
  conscientiousness: { top: "30%", left: 0, maxWidth: "34%", textAlign: "center" },
};

function SectionHeading({ icon, title }: { icon: string; title: string }) {
  return (
    <div className="flex items-center gap-2">
      <img src={icon} alt="" className="size-[26px] flex-none object-contain" />
      <div className="text-xl font-extrabold">{title}</div>
    </div>
  );
}

function RadarCard({ dimensionScores }: { dimensionScores: FullDimensionScore[] }) {
  const scoresByKey = new Map(dimensionScores.map((d) => [d.key, d.score_percent]));
  const levelsByKey = new Map(dimensionScores.map((d) => [d.key, d.level]));
  const radarPoints = computeRadarPolygonPoints(scoresByKey);

  return (
    <div
      className="border-border relative -mt-[78px] flex flex-col gap-1.5 overflow-hidden rounded-[24px] border bg-white px-5 pt-[22px] pb-[18px]"
      style={{ boxShadow: "0 14px 34px rgba(27,33,80,.16)" }}
    >
      <div
        className="pointer-events-none absolute top-[-30px] left-[-30px] size-[120px] rounded-full"
        style={{ background: "radial-gradient(circle, rgba(142,107,168,.12), transparent 70%)" }}
      />
      <div className="relative flex items-center gap-2">
        <div className="bg-primary size-1.5 rounded-full" />
        <div className="text-[13px] font-extrabold">نقشهٔ پنج‌بُعدی شخصیت تو</div>
      </div>
      <div className="relative mx-auto aspect-[1/0.92] w-full max-w-[330px]">
        <svg
          viewBox="0 0 200 200"
          className="absolute top-1/2 left-1/2 h-auto w-[56%] -translate-x-1/2 -translate-y-1/2 overflow-visible"
        >
          <polygon
            points="100,24 172.28,76.51 144.67,161.49 55.33,161.49 27.72,76.51"
            fill="#FBF8F1"
            stroke="#EDE7DA"
            strokeWidth="1"
          />
          <polygon
            points="100,43 154.21,82.38 133.5,146.12 66.5,146.12 45.79,82.38"
            fill="none"
            stroke="#EDE7DA"
            strokeWidth="1"
          />
          <polygon
            points="100,62 136.14,88.26 122.34,130.75 77.66,130.75 63.86,88.26"
            fill="none"
            stroke="#EDE7DA"
            strokeWidth="1"
          />
          <polygon
            points="100,81 118.07,94.13 111.17,115.37 88.83,115.37 81.93,94.13"
            fill="none"
            stroke="#EDE7DA"
            strokeWidth="1"
          />
          <path
            d="M100,100 L100,24 M100,100 L172.28,76.51 M100,100 L144.67,161.49 M100,100 L55.33,161.49 M100,100 L27.72,76.51"
            stroke="#EDE7DA"
            strokeWidth="1"
          />
          <polygon
            points={radarPoints}
            fill="rgba(39,67,198,.16)"
            stroke="#2743C6"
            strokeWidth="2"
            strokeLinejoin="round"
          />
        </svg>
        {RADAR_AXES.map(({ key }) => {
          const level = levelsByKey.get(key);
          return (
            <div
              key={key}
              className="absolute text-[10.5px] font-extrabold text-[#5D5C55]"
              style={RADAR_LABEL_POSITIONS[key]}
            >
              {DIMENSION_LABELS[key]}{" "}
              {level && (
                <span style={{ color: DIMENSION_LEVEL_COLORS[level].color }}>
                  {toPersianDigits(scoresByKey.get(key) ?? 0)}٪
                </span>
              )}
            </div>
          );
        })}
      </div>
      <div className="text-text-faint relative text-center text-[11px] leading-[1.85]">
        هرچه شکل به بیرون نزدیک‌تر باشد، آن ویژگی در تو پررنگ‌تر است.
      </div>
    </div>
  );
}

function DimensionCard({
  dimension,
  note,
}: {
  dimension: FullDimensionScore;
  note: string | undefined;
}) {
  const colors = DIMENSION_LEVEL_COLORS[dimension.level];
  return (
    <div className="shadow-card border-border bg-card flex flex-col gap-3 rounded-2xl border p-5">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <img
            src={DIMENSION_ICONS[dimension.key]}
            alt=""
            className="size-[22px] flex-none object-contain"
          />
          <div className="text-[13.5px] font-extrabold">{DIMENSION_LABELS[dimension.key]}</div>
          <div className="text-[11px] font-extrabold" style={{ color: colors.color }}>
            {toPersianDigits(dimension.score_percent)}٪
          </div>
        </div>
        <span
          className="flex-none rounded-full px-2.5 py-1 text-[11px] font-bold whitespace-nowrap"
          style={{ color: colors.color, background: colors.bg }}
        >
          {DIMENSION_LEVEL_LABELS[dimension.level]}
        </span>
      </div>
      <div className="bg-border relative h-1.5 overflow-hidden rounded-full">
        <div
          className="bg-gradient-meter h-full rounded-full"
          style={{ width: `${dimension.score_percent}%` }}
        />
        <div className="absolute inset-0 grid grid-cols-4">
          <div className="border-l border-white/70" />
          <div className="border-l border-white/70" />
          <div className="border-l border-white/70" />
          <div />
        </div>
      </div>
      {note && <p className="text-muted-foreground text-[12.5px] leading-[1.9]">{note}</p>}
    </div>
  );
}

function LifePatternAccordion({
  card,
  index,
  isOpen,
  onToggle,
}: {
  card: ReportData["life_pattern_cards"][number];
  index: number;
  isOpen: boolean;
  onToggle: () => void;
}) {
  return (
    <div className="shadow-card border-border bg-card overflow-hidden rounded-2xl border">
      <button
        type="button"
        onClick={onToggle}
        className="flex min-h-11 w-full cursor-pointer items-center gap-3 p-5 text-right"
      >
        <div
          className={`flex size-[30px] flex-none items-center justify-center rounded-[10px] text-[12px] font-extrabold ${
            isOpen ? "bg-primary text-white" : "text-text-faint"
          }`}
          style={!isOpen ? { background: "#F1EEE5" } : undefined}
        >
          {toPersianDigits(index + 1)}
        </div>
        <div className="flex flex-1 flex-col gap-1">
          <div className="text-[15px] font-extrabold">{LIFE_PATTERN_LABELS[card.key]}</div>
          <div className="text-muted-foreground text-[13.5px] leading-[1.95]">{card.summary}</div>
        </div>
        <ChevronDown
          size={18}
          strokeWidth={2.5}
          className={`text-muted-foreground flex-none transition-transform duration-200 ${
            isOpen ? "rotate-180" : ""
          }`}
        />
      </button>
      {isOpen && (
        <div className="animate-fm-in flex flex-col gap-3.5 px-5 pb-5">
          <div className="flex flex-col gap-[5px]">
            <div className="text-success text-[13px] font-extrabold">بهترین شرایط برای شما</div>
            <p className="text-[13.5px] leading-[2] text-[#3C4150]">{card.best_when}</p>
          </div>
          <div className="flex flex-col gap-[5px]">
            <div className="text-[13px] font-extrabold text-[#B0762A]">حواس‌تان باشد</div>
            <p className="text-[13.5px] leading-[2] text-[#3C4150]">{card.watch_out}</p>
          </div>
        </div>
      )}
    </div>
  );
}

export function reportChatHref(attemptId: number, message?: string) {
  const from = `/report?attemptId=${attemptId}`;
  const base = `/chat?entry_source=report_cta&attempt_id=${attemptId}&from=${encodeURIComponent(from)}`;
  return message ? `${base}&initial_message=${encodeURIComponent(message)}` : base;
}

// Pill button that opens a fresh chat about the report with a ready-made question.
function AskInChatButton({ attemptId, question }: { attemptId: number; question: string }) {
  const router = useRouter();
  return (
    <button
      type="button"
      onClick={() => router.push(reportChatHref(attemptId, question))}
      className="border-[#C7CEF0] bg-[#F4F6FD] text-primary flex min-h-11 cursor-pointer items-center gap-2 self-start rounded-full border-[1.5px] px-4 py-[9px] text-right text-[13px] leading-[1.7] font-bold transition-colors hover:bg-[#E9EBF8]"
    >
      <svg
        width="16"
        height="16"
        viewBox="0 0 24 24"
        fill="none"
        stroke="#2743C6"
        strokeWidth={1.9}
        strokeLinecap="round"
        strokeLinejoin="round"
        className="flex-none"
      >
        <path d="M20 11.5a7.5 7.5 0 0 1-10.9 6.7L4.5 19.5l1.3-4.6A7.5 7.5 0 1 1 20 11.5Z" />
      </svg>
      <span>{question}</span>
    </button>
  );
}

// Sticky in-report chat dock (design handoff Phase 5 §B). Sits as the last child of the page's
// flex column with margin-top:auto so it rests at the bottom, then `sticky` pins it over the
// content scrolling past underneath, faded in via the gradient so the cut isn't hard. The bottom
// offset clears the mobile tab bar (67px: 8 + 48 + 10 + 1 border); desktop has no tab bar, so it sits
// flush. Sending hands the text to a fresh chat via ?initial_message= so the answer is already
// streaming when the chat screen appears.
function ReportChatDock({ attemptId }: { attemptId: number }) {
  const router = useRouter();
  const [input, setInput] = useState("");
  // Stays out of the way at the top of the report; slides in once the reader has scrolled past
  // the hero.
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const update = () => setVisible(window.scrollY > 320);
    update();
    window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, []);

  function send() {
    const value = input.trim();
    if (!value) return;
    router.push(reportChatHref(attemptId, value));
  }

  return (
    <div
      className={`sticky bottom-[67px] z-30 mt-auto px-4 pt-2.5 pb-3 transition-[opacity,transform] duration-250 md:bottom-0 ${
        visible ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-3 opacity-0"
      }`}
    >
      <form
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
        className="mx-auto flex w-full max-w-[680px] items-center gap-2 rounded-full border-[1.5px] border-[#C7CEF0] bg-white py-1 pr-1 pl-4 shadow-[0_10px_26px_-12px_rgba(27,33,80,.4)]"
      >
        <button
          type="submit"
          aria-label="ارسال"
          disabled={!input.trim()}
          className="bg-primary grid size-10 flex-none cursor-pointer place-items-center rounded-[14px] disabled:opacity-40"
        >
          <SendIcon />
        </button>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          dir="rtl"
          placeholder="سؤالی دربارهٔ گزارشت داری؟ همین‌جا بپرس…"
          className="text-foreground min-h-10 min-w-0 flex-1 border-none bg-transparent text-[13px] outline-none"
        />
      </form>
    </div>
  );
}

export function EmailReportCard({ attemptId }: { attemptId: number }) {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [isPending, startTransition] = useTransition();

  function submit() {
    if (!email.trim() || isPending) return;
    startTransition(async () => {
      const result = await sendReportEmailAction(attemptId, email.trim());
      if (!result.ok) {
        toast.error(result.message);
        return;
      }
      setSent(true);
    });
  }

  return (
    <section className="shadow-card border-border bg-card flex flex-col gap-3 rounded-2xl border-[1.5px] p-6">
      <div className="grid size-[38px] flex-none place-items-center rounded-xl" style={{ background: "#E9EBF8" }}>
        <Mail size={19} strokeWidth={1.8} className="text-primary" />
      </div>
      <div className="text-[16.5px] font-extrabold">این گزارش را برای خودت ایمیل کن</div>
      <p className="text-muted-foreground text-[13px] leading-[1.95]">
        یک نسخهٔ کامل از گزارش را به ایمیلت می‌فرستیم تا هر وقت خواستی به آن برگردی.
      </p>
      {sent ? (
        <p className="text-success text-[13.5px] font-bold">به ایمیلت ارسال شد ✓</p>
      ) : (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
          className="border-border flex min-w-[210px] flex-1 items-center gap-2 rounded-xl border-[1.5px] bg-[#FBF8F1] py-1 pr-1 pl-3.5"
        >
          <button
            type="submit"
            aria-label="ارسال"
            disabled={!email.trim() || isPending}
            className="bg-primary grid size-[38px] flex-none cursor-pointer place-items-center rounded-xl disabled:opacity-50"
          >
            {isPending ? <Spinner /> : <SendIcon />}
          </button>
          <input
            type="email"
            dir="rtl"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="ایمیلت را وارد کن"
            className="text-foreground min-h-[38px] min-w-0 flex-1 border-none bg-transparent text-[13.5px] outline-none"
          />
        </form>
      )}
    </section>
  );
}

export function ReportView({
  attemptId,
  reportId,
  dimensionScores,
  report,
}: {
  attemptId: number;
  reportId: number | undefined;
  dimensionScores: FullDimensionScore[];
  report: ReportData;
}) {
  const [openPatternIndex, setOpenPatternIndex] = useState(0);
  const [proposal, setProposal] = useState<{ kicker: string; index: number; step: SuggestedStep } | null>(null);
  const sortedDimensions = sortDimensionsByScore(dimensionScores);
  const notesByKey = new Map(report.snapshot_interpretations.map((s) => [s.key, s.text]));
  const narrativeParagraphs = report.core_narrative.body.split("\n\n");

  return (
    <main className="flex min-h-dvh flex-col">
      <TrackOnMount
        event="full_report_viewed"
        properties={{ assessment_slug: SELF_KNOWLEDGE_ASSESSMENT_SLUG, attempt_id: attemptId }}
      />
      <div className="bg-gradient-dusk relative overflow-hidden">
        <div
          className="pointer-events-none absolute -bottom-20 left-[-40px] size-[240px] rounded-full"
          style={{ background: "radial-gradient(circle, rgba(232,169,143,.45), transparent 70%)" }}
        />
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              "repeating-linear-gradient(115deg, rgba(255,255,255,.05) 0 1px, transparent 1px 13px)",
          }}
        />
        <div className="pointer-events-none absolute top-[-90px] right-[-70px] size-[230px] rounded-full border border-white/14" />
        <div className="pointer-events-none absolute top-[-40px] right-[-20px] size-[130px] rounded-full border border-white/10" />
        <div className="relative mx-auto box-border flex w-full max-w-[680px] flex-col gap-7 px-7 pt-7 pb-12">
          <div className="h-[52px] flex-none" />
          <div className="animate-fm-in flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <div className="h-[2px] w-[22px] rounded-sm" style={{ background: "#E8A98F" }} />
              <div className="text-[12.5px] font-extrabold text-white/70">
                پروفایل اولیه شخصیت تو
              </div>
            </div>
            <h1 className="text-[clamp(21px,3vw,26px)] leading-[1.75] font-extrabold text-pretty text-white">
              {report.summary.one_line}
            </h1>
            <div className="flex flex-wrap items-center gap-1.5 text-[11.5px] leading-[1.8] text-white/70">
              <span>تصویری اولیه بر پایهٔ پنج بُعد اصلی.</span>
              <Link
                href={`/paywall?source=report_upsell`}
                className="border-b border-white/40 font-bold text-white"
              >
                دربارهٔ نسخهٔ کامل ←
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto box-border flex w-full max-w-[680px] flex-col gap-12 px-7 pt-11 pb-16">
        <RadarCard dimensionScores={dimensionScores} />

        <TopEmailStrip
          attemptId={attemptId}
          label="یک نسخه از گزارش را برایت ایمیل می‌کنیم"
          className="-mt-[30px]"
        />

        <section className="flex flex-col gap-[18px]">
          <SectionHeading icon="/report-icons/personality.png" title="تصویر کلی شخصیت" />
          <div className="grid [grid-template-columns:repeat(auto-fit,minmax(260px,1fr))] gap-3">
            {sortedDimensions.map((dim) => (
              <DimensionCard key={dim.key} dimension={dim} note={notesByKey.get(dim.key)} />
            ))}
          </div>
        </section>

        <section className="shadow-card border-border bg-card flex flex-col gap-4 rounded-2xl border p-6">
          <SectionHeading
            icon="/report-icons/personality-pattern.png"
            title="الگوی اصلی شخصیت تو"
          />
          <div className="flex flex-col gap-4">
            {narrativeParagraphs.map((paragraph, i) => (
              <p key={i} className="text-[14.5px] leading-[2.15]">
                {paragraph}
              </p>
            ))}
          </div>
          <AskInChatButton
            attemptId={attemptId}
            question="این الگو در محیط کارم چطور دیده می‌شود؟"
          />
          <Link
            href={`/paywall?source=report_upsell`}
            className="hover:text-primary flex items-start gap-2.5 border-t border-[#F2EDE1] pt-3.5 text-[12.5px] leading-[1.95] text-[#7C7768] transition-colors"
          >
            <span className="text-primary flex-none font-extrabold">در نسخهٔ کامل</span>
            <span>این الگو در کار، روابط و زیر فشار جداگانه تحلیل می‌شود ←</span>
          </Link>
        </section>

        <section className="flex flex-col gap-[18px]">
          <SectionHeading icon="/report-icons/key-strengths.png" title="نقاط قوت کلیدی" />
          <div className="grid [grid-template-columns:repeat(auto-fit,minmax(190px,1fr))] [grid-template-rows:auto_auto_1fr_auto] gap-3">
            {report.key_strengths.map((strength, i) => {
              const cfg = STRENGTH_ICON_CONFIG[i % STRENGTH_ICON_CONFIG.length];
              return (
                <div
                  key={strength.title}
                  className="shadow-card border-border bg-card box-border grid [grid-row:span_4] [grid-template-rows:subgrid] gap-2.5 rounded-2xl border p-[22px]"
                >
                  <div
                    className="flex size-11 flex-none items-center justify-center rounded-[14px]"
                    style={{ background: cfg.bg }}
                  >
                    <img src={cfg.src} alt="" className="size-7 object-contain" />
                  </div>
                  <div className="text-[15px] leading-[1.7] font-extrabold">{strength.title}</div>
                  <div className="text-muted-foreground text-[13.5px] leading-[2]">
                    {strength.description}
                  </div>
                  <div
                    className="pt-3 text-[13px] leading-[1.95] text-[#7C7768]"
                    style={{ borderTop: "1px solid #F2EDE1" }}
                  >
                    <span className="text-purple-accent font-bold">چرا مهم است: </span>
                    {strength.why_it_matters}
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        <section className="flex flex-col gap-[18px]">
          <div className="flex flex-col gap-1">
            <SectionHeading icon="/report-icons/watch-out.png" title="چیزهایی که بهتر است مراقبشان باشی" />
            <div className="text-[13.5px] leading-[1.9] text-[#8B8676]">
              نه نقطه‌ضعف — جاهایی که رشد از آن‌جا شروع می‌شود.
            </div>
          </div>
          <div className="grid [grid-template-columns:repeat(auto-fit,minmax(260px,1fr))] [grid-template-rows:auto_1fr_auto] gap-3">
            {report.growth_edges.map((edge) => (
              <div
                key={edge.title}
                className="bg-lavender-tint border-lavender-border box-border grid [grid-row:span_3] [grid-template-rows:subgrid] gap-2.5 rounded-2xl border p-5"
              >
                <div className="text-lavender-text text-[15px] leading-[1.7] font-extrabold">
                  {edge.title}
                </div>
                <div className="text-[13.5px] leading-[2]">{edge.description}</div>
                <div className="text-lavender-text rounded-xl bg-[#EBE7F7] px-3.5 py-3 text-[13px] leading-[1.95]">
                  <span className="font-bold">💡 یادآوری رشد: </span>
                  {edge.growth_reframe}
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="flex flex-col gap-[18px]">
          <SectionHeading icon="/report-icons/real-situations.png" title="شخصیت تو در موقعیت‌های واقعی" />
          <div className="flex flex-col gap-2.5">
            {report.life_pattern_cards.map((card, i) => (
              <LifePatternAccordion
                key={card.key}
                card={card}
                index={i}
                isOpen={openPatternIndex === i}
                onToggle={() => setOpenPatternIndex((cur) => (cur === i ? -1 : i))}
              />
            ))}
          </div>
          <AskInChatButton
            attemptId={attemptId}
            question="موقعیتی دارم که این‌جا نیست؛ بررسی‌اش کنیم؟"
          />
          <Link
            href={`/paywall?source=report_upsell`}
            className="hover:text-primary px-1 pt-1 text-[12.5px] leading-[1.95] text-[#7C7768] transition-colors"
          >
            سبک تصمیم‌گیری، یادگیری و واکنش به استرس در نسخهٔ کامل با جزئیات بیشتری بررسی می‌شوند ←
          </Link>
        </section>

        <section id="advice" className="flex flex-col gap-[18px]">
          <SectionHeading icon="/report-icons/growth-path.png" title="مسیر رشد پیشنهادی تو" />
          <div
            className="relative flex flex-col gap-4 overflow-hidden rounded-[22px] p-[26px]"
            style={{ background: "#22307E" }}
          >
            <div className="relative flex flex-col gap-1">
              <div className="text-[11px] font-extrabold tracking-[.04em] text-[#B9C2F0]">
                تمرکز اصلی رشد تو
              </div>
              <div className="text-lg font-extrabold text-white">{report.growth_path.main_growth_focus}</div>
            </div>
            <p className="relative text-[13px] leading-[1.95] text-white/82">
              {report.growth_path.why_this_matters}
            </p>
            <p className="relative text-[12.5px] font-extrabold text-[#E8B98F]">
              ✨ {report.growth_path.growth_principle}
            </p>
            <div className="relative flex flex-col gap-2">
              <div className="text-[12px] font-extrabold text-[#9BA6E8]">۳ توصیه برای شروع</div>
              {report.growth_path.recommendations.map((rec, i) => (
                <div
                  key={rec.title}
                  className="flex items-start gap-3 rounded-[14px] border border-white/14 bg-white/8 px-4 py-[13px]"
                  title={ACTION_TYPE_LABELS[rec.action_type]}
                >
                  <div
                    className="mt-0.5 flex size-[26px] flex-none items-center justify-center rounded-full border text-[12px] font-extrabold text-[#E8B98F]"
                    style={{ background: "rgba(232,185,143,.18)", borderColor: "rgba(232,185,143,.55)" }}
                  >
                    {toPersianDigits(i + 1)}
                  </div>
                  <div className="flex flex-1 flex-col gap-1">
                    <div className="text-[13px] font-extrabold text-white">{rec.title}</div>
                    <p className="text-[12px] leading-[1.85] text-[#C3CAF2]">{rec.description}</p>
                    {rec.suggested_step && (
                      <button
                        type="button"
                        onClick={() => setProposal({ kicker: rec.title, index: i + 1, step: rec.suggested_step! })}
                        className="mt-1.5 min-h-[38px] cursor-pointer self-start rounded-full border border-[#E8B98F]/50 px-4 py-[9px] text-xs font-bold text-[#E8B98F]"
                      >
                        قدم اولش را بگیر
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="flex flex-col gap-4 rounded-[22px] bg-[#2743C6] p-[28px_24px] text-white">
          <div className="flex flex-col gap-2">
            <div className="text-[12.5px] font-bold text-[#C9D1F4]">گام بعدی</div>
            <div className="text-[21px] leading-[1.6] font-extrabold text-pretty">
              تصویر کامل‌تری از خودت
            </div>
            <div className="max-w-[520px] text-[13.5px] leading-[2] text-[#DDE2F7] text-pretty">
              این گزارش اولیه پنج بُعد کلی را نشان می‌دهد. نسخهٔ کامل، با تست تکمیلی، هر بُعد را به
              ویژگی‌های جزئی‌تر می‌شکند و نشان می‌دهد هر کدام در زندگی واقعی‌ات چطور عمل می‌کنند.
            </div>
          </div>
          <div className="flex flex-col gap-2.5">
            {DEEP_TEST_BENEFITS.map((b) => (
              <div key={b.title} className="flex items-start gap-2.5">
                <div className="mt-[3px] grid size-5 flex-none place-items-center rounded-full bg-white/18 text-[11px]">
                  ✓
                </div>
                <div className="text-sm leading-[1.8]">
                  <span className="font-extrabold">{b.title}</span>{" "}
                  <span className="text-[#DDE2F7]">— {b.desc}</span>
                </div>
              </div>
            ))}
          </div>
          <Link
            href={`/paywall?source=report_upsell`}
            className="mt-1 min-h-[54px] w-full rounded-[14px] bg-white px-5 py-4 text-center text-[15.5px] font-extrabold text-[#2743C6] transition-colors hover:bg-[#F3F1FB]"
          >
            آشنایی با نسخهٔ کامل ←
          </Link>
        </section>

        <div className="grid [grid-template-columns:repeat(auto-fit,minmax(260px,1fr))] gap-3.5">
          <EmailReportCard attemptId={attemptId} />

          <section className="shadow-card border-border bg-card flex flex-col gap-3 rounded-2xl border-[1.5px] p-6">
            <div className="grid size-[38px] flex-none place-items-center rounded-xl" style={{ background: "#E9EBF8" }}>
              <MessageCircle size={19} strokeWidth={1.8} className="text-primary" />
            </div>
            <div className="text-[16.5px] font-extrabold">چقدر این گزارش تو را درست شناخته؟</div>
            <p className="text-muted-foreground text-[13.5px] leading-[2]">
              نظر شما دقت گزارش‌های بعدی را بالاتر می‌برد. کمتر از یک دقیقه وقت می‌گیرد.
            </p>
            {reportId !== undefined ? (
              <Link
                href={`/report/feedback?attemptId=${attemptId}&reportId=${reportId}`}
                className="bg-primary min-h-12 self-start rounded-2xl px-[26px] py-[15px] text-center text-[14.5px] font-extrabold text-white"
              >
                نظرم را می‌گویم
              </Link>
            ) : (
              <ComingSoonButton className="bg-primary min-h-12 self-start rounded-2xl px-[26px] py-[15px] text-[14.5px] font-extrabold text-white">
                نظرم را می‌گویم
              </ComingSoonButton>
            )}
          </section>
        </div>

        <p className="text-text-faintest text-[11.5px] leading-[1.9]">
          این گزارش برای خودشناسی و رشد فردی است و جایگزین ارزیابی تخصصی یا درمانی نیست.
        </p>
      </div>

      <ReportChatDock attemptId={attemptId} />

      {proposal && (
        <ActionStepProposalSheet
          open
          onClose={() => setProposal(null)}
          kicker={proposal.kicker}
          suggestedStep={proposal.step}
          attemptId={attemptId}
          index={proposal.index}
        />
      )}
    </main>
  );
}
