"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Bell, Check, ChevronDown, Clock, Download, Mail, Pencil } from "lucide-react";
import { acceptReportStepAction } from "@/components/action-steps/actions";
import { TrackOnMount } from "@/components/analytics/track-on-mount";
import { ComingSoonButton } from "@/components/report/coming-soon-button";
import { ReportChatSection } from "@/components/report/report-v2-chat";
import { ReportV2StepEditSheet } from "@/components/report/report-v2-step-edit-sheet";
import { ReportV2Feedback } from "@/components/report/report-v2-feedback";
import { sendReportEmailAction } from "@/components/report/actions";
import {
  V2_BODY,
  V2_CARD,
  V2_DISCLAIMER,
  V2_GRID,
  V2_PAGE,
  V2_WRAP,
  V2ChatIcon,
  V2FindingsHeader,
  V2Hero,
  V2_IMAGES,
  V2Illustration,
  V2Pill,
  V2RadarCard,
  V2StrengthCard,
  findingPill,
  findingsEyebrow,
} from "@/components/report/report-v2-parts";
import { SELF_KNOWLEDGE_ASSESSMENT_SLUG } from "@/lib/api/constants";
import { DIRECT_DOWNLOAD_HREF } from "@/lib/constants/app-download";
import { DENIED_HINT, shouldAskForPush, subscribeToPush } from "@/lib/push/subscribe";
import { DEADLINE_TEXT } from "@/lib/utils/action-step";
import type {
  DeadlineType,
  FullDimensionScore,
  ReportV2Data,
  ReportV2Finding,
} from "@/lib/api/schemas";
import { reportChatHref } from "./report-view";

const EMAIL_PATTERN = /\S+@\S+\.\S+/;

function openQuestionChatHref(attemptId: number) {
  const from = `/report?attemptId=${attemptId}`;
  return `/chat?entry_source=report_open_question&attempt_id=${attemptId}&from=${encodeURIComponent(from)}`;
}

// The chat button inside a finding card: tells the chat which finding (0 or 1) it came from, and
// hands the chat a first message so the answer is already there on arrival -- same as the deep
// report's section prompts (?initial_message=, auto-sent once on a fresh chat).
function findingChatHref(attemptId: number, findingIndex: number, title: string) {
  const from = `/report?attemptId=${attemptId}`;
  const message = `می‌خواهم درباره‌ی «${title}» بیشتر حرف بزنم.`;
  return `/chat?entry_source=report_finding_focus:${findingIndex}&attempt_id=${attemptId}&from=${encodeURIComponent(from)}&initial_message=${encodeURIComponent(message)}`;
}

function EmailBar({ attemptId }: { attemptId: number }) {
  const [email, setEmail] = useState("");
  const [sentTo, setSentTo] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();
  const valid = EMAIL_PATTERN.test(email);

  function submit() {
    if (!valid || isPending) return;
    const address = email.trim();
    startTransition(async () => {
      const result = await sendReportEmailAction(attemptId, address);
      if (!result.ok) {
        toast.error(result.message);
        return;
      }
      setSentTo(address);
    });
  }

  return (
    <div className="-mt-2 flex flex-wrap items-center gap-3.5 rounded-[18px] border border-white/10 bg-[#1C1724] py-2.5 pr-[18px] pl-3 md:-mt-4">
      <div className="flex flex-none items-center gap-2.5">
        <div className="grid size-8 flex-none place-items-center rounded-[10px] bg-[rgba(195,174,235,.14)]">
          <Mail size={16} strokeWidth={1.8} className="text-[#C3AEEB]" />
        </div>
        <div className="text-sm font-extrabold">یک نسخه از گزارش را برایت ایمیل می‌کنیم</div>
      </div>
      {sentTo ? (
        <div className="flex min-h-[46px] min-w-[220px] flex-1 items-center gap-2.5 rounded-xl bg-[rgba(195,174,235,.12)] px-3.5 py-2.5">
          <span className="text-sm text-[#C3AEEB]">✓</span>
          <div className="truncate text-[13px] font-bold text-[#E4DAF5]" dir="rtl">
            به {sentTo} فرستاده شد.
          </div>
          <button
            type="button"
            onClick={() => setSentTo(null)}
            className="mr-auto cursor-pointer text-[12.5px] font-extrabold whitespace-nowrap text-[#C3AEEB] hover:text-[#F3EFE8]"
          >
            تغییر ایمیل
          </button>
        </div>
      ) : (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
          className="flex min-w-[220px] flex-1 items-center gap-2 rounded-xl border border-white/14 bg-[#15121B] py-1 pr-1 pl-3.5"
        >
          <button
            type="submit"
            aria-label="ارسال"
            disabled={!valid || isPending}
            className="grid size-10 flex-none cursor-pointer place-items-center rounded-[10px] disabled:cursor-default"
            style={{ background: valid ? "#C3AEEB" : "rgba(255,255,255,.08)" }}
          >
            <svg
              width="17"
              height="17"
              viewBox="0 0 24 24"
              fill="none"
              stroke={valid ? "#1E1428" : "#8E879A"}
              strokeWidth="1.9"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="-scale-x-100"
            >
              <path d="m22 2-7 20-4-9-9-4Z" />
              <path d="M22 2 11 13" />
            </svg>
          </button>
          <input
            type="email"
            dir="rtl"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="ایمیلت را وارد کن"
            className="min-h-10 min-w-0 flex-1 border-none bg-transparent text-sm text-[#F3EFE8] outline-none placeholder:text-[#8E879A]"
          />
        </form>
      )}
    </div>
  );
}

function FindingCard({
  finding,
  index,
  open,
  onToggle,
  attemptId,
  onRejectStep,
  chatHref,
}: {
  finding: ReportV2Finding;
  index: number;
  open: boolean;
  onToggle: () => void;
  attemptId: number;
  onRejectStep: () => void;
  chatHref: string;
}) {
  const [stepOpen, setStepOpen] = useState(false);
  const step = finding.suggested_step;
  const [stepText, setStepText] = useState(step?.text ?? "");
  const [deadlineType, setDeadlineType] = useState<DeadlineType | undefined>(step?.deadline_type);
  const [edited, setEdited] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [phase, setPhase] = useState<"idle" | "submitting" | "accepted">("idle");
  const [pushAsk, setPushAsk] = useState(false);
  const [pushBusy, setPushBusy] = useState(false);

  // Accepting is inline: the step is created right here (with the user's edit, if any), and the box
  // turns into a confirmation. The popup is only for editing.
  async function acceptStep() {
    if (phase !== "idle") return;
    setPhase("submitting");
    const edits = edited ? { step_text: stepText, deadline_type: deadlineType } : undefined;
    const result = await acceptReportStepAction(attemptId, index + 1, edits);
    if (!result.ok) {
      toast.error(result.message);
      setPhase("idle");
      return;
    }
    setPhase("accepted");
    setPushAsk(shouldAskForPush());
  }

  async function allowPush() {
    setPushBusy(true);
    const result = await subscribeToPush();
    setPushBusy(false);
    if (result === "error") toast.error("فعال‌سازی اعلان‌ها موفق نبود.");
    if (result === "denied" && Notification.permission === "denied") toast.error(DENIED_HINT);
    setPushAsk(false);
  }

  return (
    <article
      className={`${V2_CARD} flex flex-col gap-4 px-[clamp(20px,2.4vw,30px)] pt-[clamp(20px,2.4vw,30px)] pb-0`}
    >
      <V2Illustration image={index === 0 ? V2_IMAGES.finding1 : V2_IMAGES.finding2} aspect="16/9" />
      <V2Pill>{findingPill(index, finding.area)}</V2Pill>
      <h3 className="text-[clamp(18.5px,1.8vw,22px)] leading-[1.65] font-extrabold text-balance text-[#F3EFE8]">
        {finding.title}
      </h3>
      <p className={V2_BODY}>{finding.what}</p>

      {open && (
        <div className="animate-fm-in flex flex-col gap-4">
          <p className="my-2 text-[clamp(16.5px,1.6vw,18px)] leading-[1.95] font-extrabold text-pretty text-[#F3EFE8]">
            {finding.cost}
          </p>
          <div className="flex items-start gap-3 rounded-2xl bg-white/[.035] px-4 py-3.5">
            <div
              aria-hidden="true"
              className="flex-none text-2xl leading-[1.2] font-light text-[#A995CF]"
            >
              ؟
            </div>
            <p className="text-sm leading-[2.1] text-pretty text-[#BDB3CE]">{finding.curiosity}</p>
          </div>

          {step && (
            <div className="flex flex-col rounded-2xl border border-white/8">
              <button
                type="button"
                onClick={() => setStepOpen((v) => !v)}
                aria-expanded={stepOpen}
                className="flex min-h-12 cursor-pointer items-center justify-between gap-2.5 px-4 py-3 text-right text-[13.5px] font-bold text-[#C9C2D3] hover:text-[#E4DAF5]"
              >
                <span>یک قدم کوچک برای امتحان</span>
                <ChevronDown
                  size={14}
                  strokeWidth={2.2}
                  className={`flex-none transition-transform duration-250 ${stepOpen ? "rotate-180" : ""}`}
                />
              </button>
              {stepOpen && (
                <div className="animate-fm-in mx-3 mb-3 flex flex-col gap-3 rounded-[14px] border border-[rgba(195,174,235,.16)] bg-[rgba(195,174,235,.07)] p-4">
                  <div className="flex items-center gap-[7px] text-xs font-bold text-[#A995CF]">
                    <Clock size={14} strokeWidth={2} className="flex-none" />
                    <span>
                      {deadlineType && edited ? DEADLINE_TEXT[deadlineType] : step.deadline_text}
                    </span>
                  </div>
                  <div className="text-[15.5px] leading-[2] font-bold text-pretty text-[#F3EFE8]">
                    {stepText}
                  </div>
                  {phase === "accepted" ? (
                    <div className="animate-fm-in mt-0.5 flex flex-col gap-3 border-t border-white/8 pt-3.5">
                      <div className="flex items-center gap-2 text-sm font-extrabold text-[#C3AEEB]">
                        <Check size={18} strokeWidth={2.4} className="flex-none" />
                        <span>ثبت شد. به قدم‌های جاری‌ات اضافه شد.</span>
                      </div>
                      {pushAsk && (
                        <div className="flex flex-wrap items-center gap-2">
                          <button
                            type="button"
                            onClick={allowPush}
                            disabled={pushBusy}
                            className="flex min-h-11 cursor-pointer items-center gap-2 rounded-xl bg-[#C3AEEB] px-4 py-2.5 text-[13px] font-extrabold text-[#1E1428] hover:bg-[#D4C3F2] disabled:cursor-not-allowed disabled:opacity-75"
                          >
                            <Bell size={15} strokeWidth={2} />
                            {pushBusy ? "در حال فعال‌سازی…" : "یادآوری کن"}
                          </button>
                          <button
                            type="button"
                            onClick={() => setPushAsk(false)}
                            className="min-h-11 cursor-pointer px-3 text-[13px] font-bold text-[#C9C2D3] hover:text-white"
                          >
                            لازم نیست
                          </button>
                        </div>
                      )}
                      <Link
                        href="/dashboard"
                        className="self-start py-1.5 text-[13px] font-bold text-[#A9BFE6] hover:text-white"
                      >
                        دیدن قدم‌هایم ←
                      </Link>
                    </div>
                  ) : (
                    <div className="mt-0.5 flex flex-wrap gap-2 border-t border-white/8 pt-3.5">
                      <button
                        type="button"
                        onClick={acceptStep}
                        disabled={phase === "submitting"}
                        className="min-h-[46px] flex-[1_1_180px] cursor-pointer rounded-xl bg-[#C3AEEB] px-[18px] py-[11px] text-sm font-extrabold text-[#1E1428] hover:bg-[#D4C3F2] disabled:cursor-not-allowed disabled:opacity-75"
                      >
                        {phase === "submitting" ? "در حال ثبت…" : "امتحانش می‌کنم"}
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditOpen(true)}
                        className="flex min-h-[46px] flex-[1_1_120px] cursor-pointer items-center justify-center gap-[7px] rounded-xl border border-white/14 px-3 py-2.5 text-[13px] font-bold text-[#D9D1E6] hover:border-white/25 hover:bg-white/5"
                      >
                        <Pencil size={14} strokeWidth={1.9} />
                        ویرایش
                      </button>
                      <button
                        type="button"
                        onClick={onRejectStep}
                        className="min-h-[46px] flex-[1_1_180px] cursor-pointer rounded-xl border border-white/14 px-3 py-2.5 text-[13px] font-bold whitespace-nowrap text-[#D9D1E6] hover:border-white/25 hover:bg-white/5"
                      >
                        این به من نمی‌خوره
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          <Link
            href={chatHref}
            className="flex min-h-11 items-center gap-2 self-start py-1.5 text-[13.5px] font-bold text-[#A9BFE6] hover:text-white"
          >
            <V2ChatIcon />
            <span>درباره‌ی این یافته با فرامن حرف بزن</span>
          </Link>
        </div>
      )}

      <button
        type="button"
        onClick={onToggle}
        aria-expanded={open}
        className="mt-auto mb-[clamp(12px,1.6vw,22px)] flex min-h-14 cursor-pointer items-center justify-between gap-2.5 rounded-2xl border border-[rgba(195,174,235,.28)] bg-[rgba(195,174,235,.1)] py-2.5 pr-[18px] pl-3 text-right text-sm font-extrabold text-[#E4DAF5] hover:bg-[rgba(195,174,235,.16)]"
      >
        <span>
          {open ? "بستن" : step ? "اثرش روی تو، یک سؤال و یک قدم کوچک" : "اثرش روی تو و یک سؤال"}
        </span>
        <ChevronDown
          size={20}
          strokeWidth={2.6}
          className={`size-[34px] flex-none rounded-full bg-[#C3AEEB] p-1.5 text-[#1A1422] transition-transform duration-250 ${open ? "rotate-180" : ""}`}
        />
      </button>
      {editOpen && step && deadlineType && (
        <ReportV2StepEditSheet
          text={stepText}
          deadlineType={deadlineType}
          onSave={(text, deadline) => {
            setStepText(text);
            setDeadlineType(deadline);
            setEdited(true);
            setEditOpen(false);
          }}
          onClose={() => setEditOpen(false)}
        />
      )}
    </article>
  );
}

export function ReportViewV2({
  attemptId,
  reportId,
  dimensionScores,
  report,
}: {
  attemptId: number;
  reportId: number | undefined;
  dimensionScores: FullDimensionScore[];
  report: ReportV2Data;
}) {
  const router = useRouter();
  const [openFindings, setOpenFindings] = useState<Record<number, boolean>>({});
  const chatHref = reportChatHref(attemptId);
  // Cards top-align only while exactly one is open (the open one is taller); with both open or
  // both closed they have similar heights and stretch to match (design: rv3GridAlign).
  const exactlyOneOpen = Boolean(openFindings[0]) !== Boolean(openFindings[1]);

  function rejectStep(index: number) {
    const from = encodeURIComponent(`/report?attemptId=${attemptId}`);
    router.push(
      `/chat?entry_source=action_rejected&attempt_id=${attemptId}&index=${index}&from=${from}`,
    );
  }

  return (
    <main className={V2_PAGE}>
      <TrackOnMount
        event="full_report_viewed"
        properties={{ assessment_slug: SELF_KNOWLEDGE_ASSESSMENT_SLUG, attempt_id: attemptId }}
      />
      <div className={V2_WRAP}>
        <V2Hero kicker="پروفایل اولیه شخصیت تو" hook={report.hook} />
        <EmailBar attemptId={attemptId} />
        <div className="-mt-[clamp(14px,2.4vw,28px)] flex justify-start">
          <a
            href={DIRECT_DOWNLOAD_HREF}
            download
            className="flex min-h-11 items-center gap-[7px] px-1 py-1.5 text-[13px] font-bold text-[#C3AEEB] hover:text-[#F3EFE8]"
          >
            <Download size={15} strokeWidth={2} />
            دانلود مستقیم اپلیکیشن
          </a>
        </div>

        <section className={`${V2_GRID} items-stretch`}>
          <V2RadarCard
            footnote="بر اساس ۳۰ پاسخ"
            dimensions={dimensionScores.map((d) => ({
              key: d.key,
              level: d.level,
              percent: d.score_percent,
            }))}
          />
          <V2StrengthCard title={report.strength.title} text={report.strength.text} />
        </section>

        <section className="mt-[clamp(12px,2vw,24px)] flex flex-col gap-[clamp(16px,2vw,24px)] border-t border-white/12 pt-[clamp(32px,4.5vw,56px)]">
          <V2FindingsHeader
            eyebrow={findingsEyebrow(report.findings.map((f) => f.area))}
            heading={report.findings_heading}
          />
          <div className={`${V2_GRID} ${exactlyOneOpen ? "items-start" : "items-stretch"}`}>
            {report.findings.map((finding, i) => (
              <FindingCard
                key={finding.title}
                finding={finding}
                index={i}
                open={Boolean(openFindings[i])}
                onToggle={() => setOpenFindings((prev) => ({ ...prev, [i]: !prev[i] }))}
                attemptId={attemptId}
                onRejectStep={() => rejectStep(i + 1)}
                chatHref={findingChatHref(attemptId, i, finding.title)}
              />
            ))}
          </div>
          <ReportChatSection
            attemptId={attemptId}
            questions={[
              `چرا «${report.findings[0]?.title}» برای من پیش می‌آید؟`,
              `چطور می‌توانم درباره‌ی «${report.findings[1]?.title}» حرف بزنم؟`,
              "این دو الگو به هم ربط دارند؟",
            ].slice(0, report.findings.length >= 2 ? 3 : 1)}
          />
        </section>

        <section className="flex flex-col items-center gap-5 pt-[clamp(40px,7vw,80px)] pb-[clamp(8px,2vw,16px)] text-center">
          <div className="h-px w-8 bg-[#C3AEEB]" />
          <div className="max-w-[760px] text-[clamp(21px,3vw,34px)] leading-[1.85] font-bold text-balance">
            {report.open_question.text}
          </div>
          <Link
            href={openQuestionChatHref(attemptId)}
            className="mt-1 flex min-h-[50px] items-center gap-2.5 rounded-full border border-[rgba(169,191,230,.38)] bg-[#1C2333] px-[22px] py-3 text-[14.5px] font-extrabold text-[#C9D7F0] hover:border-[rgba(169,191,230,.6)] hover:bg-[#212A3E]"
          >
            <V2ChatIcon size={18} />
            <span>جوابت را با فرامن در میان بگذار</span>
          </Link>
        </section>

        <section className="grid [grid-template-columns:repeat(auto-fit,minmax(min(100%,380px),1fr))] items-start gap-[clamp(32px,5vw,72px)] rounded-[32px] border border-[rgba(195,174,235,.35)] bg-[#2B2139] p-[clamp(28px,5vw,64px)] shadow-[0_30px_80px_rgba(0,0,0,.35)]">
          <div className="flex flex-col gap-4">
            <div className="text-[13px] font-bold text-[#C3AEEB]">یک سؤال هنوز باقی مانده</div>
            <h2 className="text-[clamp(24px,3.2vw,36px)] leading-[1.6] font-extrabold text-balance">
              شاید این دو رفتار، ریشه‌ی مشترکی داشته باشند.
            </h2>
            <p className="text-[clamp(16px,1.6vw,18px)] leading-[2] font-extrabold text-pretty text-[#E4DAF5]">
              {report.exit.bridge}
            </p>
            <div className="h-2" />
            <div className="text-[clamp(15px,1.5vw,17px)] leading-[1.8] font-bold text-[#C3AEEB]">
              اما چه چیزی پشت این رفتارهاست؟
            </div>
            <p className="text-[clamp(14.5px,1.4vw,16px)] leading-[2.1] text-pretty text-[#C9C2D3]">
              {report.exit.root_question}
            </p>
          </div>
          <div className="flex flex-col gap-4 rounded-3xl bg-[#F2EDF8] p-[clamp(22px,3vw,32px)] shadow-[0_20px_50px_rgba(0,0,0,.35)]">
            <div className="flex flex-col gap-1.5">
              <h3 className="text-[clamp(19px,2vw,23px)] leading-[1.6] font-extrabold text-balance text-[#1E1428]">
                آزمون خودشناسی عمیق فرامن
              </h3>
              <div className="text-sm font-bold text-[#6B4FA8]">یک قدم عمیق‌تر در شناخت خودت</div>
            </div>
            <div className="flex flex-col gap-1.5">
              <div className="text-[15px] leading-[1.9] font-extrabold text-pretty text-[#1E1428]">
                پشت این رفتارها چه الگوهایی پنهان شده؟
              </div>
              <p className="text-[14.5px] leading-[2.1] text-pretty text-[#4A4258]">
                با تست تکمیلی فرامن، الگوهای پنهان رفتارت و تأثیرشان بر تصمیم‌ها و روابطت را عمیق‌تر
                بشناس
              </p>
            </div>
            <Link
              href={`/paywall?source=report_upsell`}
              className="flex min-h-[60px] w-full items-center justify-center gap-2.5 rounded-full bg-[#2B2139] p-[18px] text-[17px] font-extrabold text-[#F7F3FC] hover:bg-[#3D2F52]"
            >
              <span>شناخت عمیق‌تر خودم</span>
              <span aria-hidden="true">←</span>
            </Link>
          </div>
        </section>

        <div className="flex flex-wrap items-center justify-center gap-x-2.5 gap-y-1.5 pt-1 text-center">
          <span className="text-[13.5px] text-[#A79FB3]">فعلاً نمی‌خواهی تست را ادامه بدهی؟</span>
          <Link
            href={chatHref}
            className="flex min-h-11 items-center gap-2 rounded-full border border-[rgba(169,191,230,.38)] bg-[#1C2333] px-[18px] py-2.5 text-[13.5px] font-extrabold text-[#C9D7F0] hover:bg-white/5 hover:text-white"
          >
            <V2ChatIcon />
            <span>گفتگو درباره‌ی گزارشم</span>
          </Link>
        </div>

        {reportId !== undefined ? (
          <ReportV2Feedback reportId={reportId} />
        ) : (
          <div className="flex flex-col items-center gap-2 pt-2 text-center text-[13px] text-[#A79FB3]">
            <span>چقدر این گزارش تو را درست شناخته؟</span>
            <ComingSoonButton className="font-extrabold text-[#C3AEEB]">
              نظرم را می‌گویم
            </ComingSoonButton>
          </div>
        )}

        <div className="pt-[clamp(16px,3vw,32px)] text-center text-[11.5px] leading-[1.9] text-pretty text-[#8E879A]">
          {V2_DISCLAIMER}
        </div>
      </div>
    </main>
  );
}
