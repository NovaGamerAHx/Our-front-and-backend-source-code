"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { toast } from "sonner";
import { toPersianDigits } from "@/lib/utils/digits";
import { Spinner } from "@/components/ui/spinner";
import { submitFeedbackAction } from "../actions";

const RATING_VALUES = [1, 2, 3, 4, 5];

const TAG_OPTIONS = [
  "دقیق بود",
  "کمی کلی بود",
  "بعضی بخش‌ها اشتباه بود",
  "لحنش خوب بود",
  "توصیه‌ها کاربردی بود",
];


function ratingButtonClass(selected: boolean) {
  return `flex h-14 min-w-11 flex-1 cursor-pointer items-center justify-center rounded-2xl text-[17px] font-extrabold transition-all ${selected
      ? "border-[1.5px] border-primary bg-primary text-white"
      : "border-[1.5px] border-border bg-card text-muted-foreground hover:border-primary/50"
    }`;
}

function tagButtonClass(selected: boolean) {
  return `min-h-11 cursor-pointer rounded-full border-[1.5px] px-[18px] py-2.5 text-[12.5px] font-bold transition-all ${selected
      ? "border-primary bg-primary text-white"
      : "border-border bg-card text-muted-foreground hover:border-primary/50"
    }`;
}

export function FeedbackView({
  reportId,
  backHref,
}: {
  reportId: number;
  backHref: string;
}) {
  const [rating, setRating] = useState(0);
  const [tags, setTags] = useState<string[]>([]);
  const [comment, setComment] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [isPending, startTransition] = useTransition();

  const canSubmit = rating > 0 && !isPending;

  function toggleTag(tag: string) {
    setTags((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]));
  }

  function submit() {
    if (!canSubmit) return;
    startTransition(async () => {
      const result = await submitFeedbackAction(reportId, rating, tags, comment.trim());
      if (!result.ok) {
        toast.error(result.message);
        return;
      }
      setSubmitted(true);
    });
  }

  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col gap-8 px-7 pt-6 pb-12">
      <div className="flex items-center gap-3">
        <Link
          href={backHref}
          className="border-border text-muted-foreground bg-card grid size-10 place-items-center rounded-xl border text-base"
        >
          →
        </Link>
        <div className="text-text-faint text-[13px] font-bold">بازخورد</div>
      </div>

      {submitted ? (
        <div className="animate-fm-in flex flex-col items-center gap-[18px] pt-16 text-center">
          <div className="bg-success-tint text-success grid size-[72px] place-items-center rounded-full text-[28px]">
            ✓
          </div>
          <div className="text-xl font-extrabold">ممنون از شما</div>
          <p className="text-muted-foreground max-w-[300px] text-[13.5px] leading-[2]">
            بازخوردتان به دقیق‌تر شدن گزارش‌های بعدی کمک می‌کند.
          </p>
          <Link
            href={backHref}
            className="border-border bg-card min-h-11 rounded-2xl border-[1.5px] px-8 py-3.5 text-[14px] font-bold"
          >
            بازگشت به گزارش
          </Link>
        </div>
      ) : (
        <>
          <div className="flex flex-col gap-7">
            <h1 className="text-[23px] leading-[1.7] font-extrabold text-pretty">
              چقدر حس کردید این گزارش شما را درست شناخته؟
            </h1>

            <div className="flex justify-between gap-2.5">
              {RATING_VALUES.map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setRating(value)}
                  className={ratingButtonClass(rating === value)}
                >
                  {toPersianDigits(value)}
                </button>
              ))}
            </div>

            <div className="flex flex-col gap-3">
              <div className="text-[13.5px] font-extrabold">کدام توصیف نزدیک‌تر است؟</div>
              <div className="flex flex-wrap gap-2">
                {TAG_OPTIONS.map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => toggleTag(tag)}
                    className={tagButtonClass(tags.includes(tag))}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-2.5">
              <div className="text-[13.5px] font-extrabold">
                چیز دیگری هست؟ <span className="text-text-faint font-medium">(اختیاری)</span>
              </div>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="مثلاً: بخش تصمیم‌گیری خیلی دقیق بود…"
                rows={3}
                className="border-border focus:border-primary rounded-2xl border-[1.5px] bg-card px-[18px] py-[14px] text-[13.5px] leading-[1.9] outline-none resize-none"
              />
            </div>
          </div>

          <button
            type="button"
            onClick={submit}
            disabled={!canSubmit}
            className={`mt-auto flex min-h-11 items-center justify-center gap-2.5 rounded-2xl p-[17px] text-[16px] font-extrabold text-white transition-colors disabled:cursor-not-allowed ${canSubmit ? "bg-primary hover:bg-primary/90 cursor-pointer" : isPending ? "bg-primary opacity-75" : "bg-disabled"
              }`}
          >
            {isPending && <Spinner />}
            {isPending ? "در حال ارسال…" : "ارسال بازخورد"}
          </button>
        </>
      )}
    </main>
  );
}
