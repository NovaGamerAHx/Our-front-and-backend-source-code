"use server";

import { ApiError } from "@/lib/api/client";
import { submitFeedback } from "@/lib/api/endpoints";

type ActionResult = { ok: true } | { ok: false; message: string };

const GENERIC_ERROR = "ثبت بازخورد با خطا مواجه شد. لطفاً دوباره تلاش کنید.";

export async function submitFeedbackAction(
  reportId: number,
  rating: number,
  tags: string[],
  comment: string,
): Promise<ActionResult> {
  const [reason, ...restTags] = tags;

  try {
    await submitFeedback({
      target_type: "report",
      target_id: String(reportId),
      rate: rating,
      reason: reason ?? "",
      comment: [...restTags, comment].filter(Boolean).join("، "),
    });
    return { ok: true };
  } catch (error) {
    return { ok: false, message: error instanceof ApiError ? error.message : GENERIC_ERROR };
  }
}
