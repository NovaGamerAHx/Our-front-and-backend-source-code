import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { ACCESS_TOKEN_COOKIE } from "@/lib/api/constants";
import { TrackOnMount } from "@/components/analytics/track-on-mount";
import { FeedbackView } from "./_components/feedback-view";

type FeedbackPageProps = {
  searchParams: Promise<{ attemptId?: string; reportId?: string; back?: string }>;
};

export default async function FeedbackPage({ searchParams }: FeedbackPageProps) {
  const { attemptId: rawAttemptId, reportId: rawReportId, back } = await searchParams;
  const attemptId = rawAttemptId ? Number(rawAttemptId) : NaN;
  if (!Number.isFinite(attemptId)) {
    redirect("/test");
  }

  // Where "بازگشت به گزارش" (and the header's back arrow) should land -- initial and deep
  // reports both feed into this same feedback form now, so the return trip has to be told which
  // one to go back to. Same in-app-path guard as /terms' `from`/chat's `from`.
  const defaultBackHref = `/report?attemptId=${attemptId}`;
  const backHref = back && back.startsWith("/") ? back : defaultBackHref;

  // reportId (the report's own id, distinct from attemptId) isn't derivable client-side today —
  // see the schema comment in lib/api/schemas.ts. Without it there's nothing to submit against,
  // so send the user back to the report instead of showing a form that can't work.
  const reportId = rawReportId ? Number(rawReportId) : NaN;
  if (!Number.isFinite(reportId)) {
    redirect(backHref);
  }

  const store = await cookies();
  if (!store.has(ACCESS_TOKEN_COOKIE)) {
    const params = new URLSearchParams({
      next: `/report/feedback?attemptId=${attemptId}&reportId=${reportId}&back=${backHref}`,
      skip: backHref,
    });
    redirect(`/login?${params.toString()}`);
  }

  return (
    <>
      <TrackOnMount event="feedback_form_opened" properties={{ target_type: "report" }} />
      <FeedbackView reportId={reportId} backHref={backHref} />
    </>
  );
}
