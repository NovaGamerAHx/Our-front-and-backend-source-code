import { redirect } from "next/navigation";
import { ApiError } from "@/lib/api/client";
import { getReport } from "@/lib/api/endpoints";
import { ReportUnavailable } from "@/components/report/report-unavailable";
import { isReportV2 } from "@/lib/utils/report";
import { ReportView } from "./_components/report-view";
import { ReportViewV2 } from "./_components/report-view-v2";

type ReportPageProps = {
  searchParams: Promise<{ attemptId?: string }>;
};

export default async function ReportPage({ searchParams }: ReportPageProps) {
  const { attemptId: raw } = await searchParams;
  const attemptId = raw ? Number(raw) : NaN;
  if (!Number.isFinite(attemptId)) {
    redirect("/test");
  }

  let result;
  try {
    result = await getReport(attemptId);
  } catch (error) {
    const message =
      error instanceof ApiError ? error.message : "گزارش در حال حاضر در دسترس نیست.";
    return <ReportUnavailable message={message} />;
  }

  if (result.status === "generating") {
    // Generation runs on a Celery worker now — send the visitor back into AnalysisLoader's
    // polling loop instead of rendering a page that assumes result.stage exists. Safe to
    // re-enter even though the attempt is already completed: completeAttemptAction's existing
    // 409-handling treats that as success and resumes polling immediately.
    redirect(`/test/analysis?attemptId=${attemptId}`);
  }

  if (result.status === "error") {
    return <ReportUnavailable message={result.error.user_message} attemptId={attemptId} />;
  }

  // This attempt is actually a deep report (no `stage` at all) -- send it to the route that
  // knows how to render that shape.
  if (!("stage" in result)) {
    redirect(`/deep-report?attemptId=${attemptId}`);
  }

  // The full report is gated server-side — an unauthenticated caller only ever gets the teaser
  // payload back, so send them there instead of rendering full-report UI with preview data.
  if (result.stage === "preview") {
    redirect(`/preview?attemptId=${attemptId}`);
  }

  // Each report keeps the version it was generated with, so v1 and v2 rows are both live.
  if (isReportV2(result)) {
    // Narrowed to the stage-"full" shape: the preview branch above already redirected.
    if (result.stage !== "full") redirect(`/preview?attemptId=${attemptId}`);
    return (
      <ReportViewV2
        attemptId={attemptId}
        reportId={result.report_id}
        dimensionScores={result.dimension_scores}
        report={result.report}
      />
    );
  }

  return (
    <ReportView
      attemptId={attemptId}
      reportId={result.report_id}
      dimensionScores={result.dimension_scores}
      report={result.report}
    />
  );
}
