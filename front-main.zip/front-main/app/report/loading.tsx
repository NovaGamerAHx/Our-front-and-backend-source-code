import { ReportV2Loading } from "@/components/report/report-v2-loading";

// Edge States §e4 — report loading, shown until report/page.tsx resolves getReport(attemptId).
export default function ReportLoading() {
  return <ReportV2Loading />;
}
