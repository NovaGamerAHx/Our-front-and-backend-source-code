"use server";
import { rejectReportFinding } from "@/lib/api/endpoints";
import { revalidatePath } from "next/cache";
export async function rejectFindingAction(attemptId: number, key: string) {
  try {
    await rejectReportFinding(attemptId, key);
    revalidatePath("/");
    revalidatePath("/chat");
    return { ok: true };
  } catch {
    return { ok: false };
  }
}
