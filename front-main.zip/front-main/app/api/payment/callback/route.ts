import { type NextRequest, NextResponse } from "next/server";
import { API_BASE_URL, APP_URL } from "@/lib/api/constants";
import { revalidateUserTag } from "@/lib/api/client";

/**
 * Where Zarinpal actually redirects the buyer's browser after payment -- this backend's own
 * BACKEND_BASE_URL isn't a thing on purpose: the Django backend is never exposed directly to the
 * browser (same as every other backend call in this app), so Zarinpal's callback_url is set to
 * this frontend route instead (see apps/payment/services/payment_service.py). This relays the
 * verification server-to-server, then turns the result into a browser redirect to
 * /payment/result -- same shape as app/api/chat/.../route.ts's streaming relay, just not a stream.
 *
 * The redirect target is built from APP_URL, not from this request's own URL/origin -- behind a
 * reverse proxy that doesn't forward the original Host header, request.url's origin reflects the
 * container's internal bind address (e.g. 0.0.0.0:3000), not the real public domain.
 *
 * Status code -> outcome mapping matches apps/payment/services/exceptions.py exactly:
 * 200 success, 400 PaymentCancelledException, everything else (404/422/502/...) is a hard failure.
 */
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const authority = searchParams.get("Authority") ?? "";
  const status = searchParams.get("Status") ?? "";

  const upstream = new URL("/api/payment/callback/", API_BASE_URL);
  upstream.searchParams.set("Authority", authority);
  upstream.searchParams.set("Status", status);

  const res = await fetch(upstream, { cache: "no-store" });
  const envelope = await res.json().catch(() => null);

  if (res.ok) {
    // Best-effort: unlocks the purchased assessment on the entitlements read without waiting
    // out its normal revalidate window. A failure here just means that window still applies.
    await revalidateUserTag("entitlements").catch(() => {});
    const assessmentSlug = (envelope?.data?.assessment_slug as string | undefined) ?? "";
    return NextResponse.redirect(
      new URL(`/payment/result?status=success&assessment=${assessmentSlug}`, APP_URL),
    );
  }

  const resultStatus = res.status === 400 ? "cancelled" : "failed";
  return NextResponse.redirect(new URL(`/payment/result?status=${resultStatus}`, APP_URL));
}
