import { cookies } from "next/headers";
import { type NextRequest, NextResponse } from "next/server";
import { ACCESS_TOKEN_COOKIE, API_BASE_URL } from "@/lib/api/constants";

/**
 * Proxies POST /api/chat/sessions/{sessionId}/messages/{messageId}/regenerate/, an SSE response
 * -- same shape and same httpOnly-cookie rationale as ../messages/route.ts (send-message).
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ sessionId: string; messageId: string }> },
) {
  const { sessionId, messageId } = await params;
  const store = await cookies();
  const access = store.get(ACCESS_TOKEN_COOKIE)?.value;
  if (!access) {
    return NextResponse.json({ code: 0, message: "نشست شما نامعتبر یا منقضی شده است.", data: null }, { status: 401 });
  }

  const upstream = await fetch(
    `${API_BASE_URL}/api/chat/sessions/${sessionId}/messages/${messageId}/regenerate/`,
    {
      method: "POST",
      headers: { Authorization: `Bearer ${access}` },
    },
  );

  // Same as send-message: a bad session_id/message_id fails before streaming with a normal
  // { code, message, data } JSON error, not SSE. Relay it as-is.
  if (!upstream.ok || !upstream.body) {
    const text = await upstream.text();
    return new NextResponse(text, {
      status: upstream.status,
      headers: { "Content-Type": upstream.headers.get("Content-Type") ?? "application/json" },
    });
  }

  return new NextResponse(upstream.body, {
    status: 200,
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
    },
  });
}
