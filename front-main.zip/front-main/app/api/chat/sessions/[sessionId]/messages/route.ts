import { cookies } from "next/headers";
import { type NextRequest, NextResponse } from "next/server";
import { ACCESS_TOKEN_COOKIE, API_BASE_URL } from "@/lib/api/constants";

/**
 * Proxies POST /api/chat/sessions/{id}/messages/ (chat_spec_v1.md §2), an SSE response.
 *
 * This exists only because the JWT lives in an httpOnly cookie (lib/api/constants.ts) that
 * client components can't read, and apiFetch/apiMutate (lib/api/client.ts) buffer a single JSON
 * envelope -- unusable for a stream. This route runs server-side (same as a Server Action),
 * attaches the Bearer token, and pipes Django's response body straight through untouched.
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ sessionId: string }> },
) {
  const { sessionId } = await params;
  const store = await cookies();
  const access = store.get(ACCESS_TOKEN_COOKIE)?.value;
  if (!access) {
    return NextResponse.json({ code: 0, message: "نشست شما نامعتبر یا منقضی شده است.", data: null }, { status: 401 });
  }

  const body = await request.text();

  const upstream = await fetch(`${API_BASE_URL}/api/chat/sessions/${sessionId}/messages/`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${access}`,
    },
    body,
  });

  // ChatMessageStreamAPIView (faraman-back) raises before streaming for a bad session_id or an
  // over-length message -- a normal { code, message, data } JSON error, not SSE. Relay it as-is.
  if (!upstream.ok || !upstream.body) {
    const text = await upstream.text();
    return new NextResponse(text, {
      status: upstream.status,
      headers: { "Content-Type": upstream.headers.get("Content-Type") ?? "application/json" },
    });
  }

  return new NextResponse(upstream.body, {
    status: 200,
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
    },
  });
}
