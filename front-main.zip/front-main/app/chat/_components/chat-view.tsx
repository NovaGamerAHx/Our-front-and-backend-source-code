"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Bookmark,
  Check,
  Copy,
  MessageCircle,
  PanelLeft,
  RotateCcw,
  SquarePen,
  ThumbsDown,
  ThumbsUp,
  Trash2,
  TriangleAlert,
  WifiOff,
} from "lucide-react";
import { toast } from "sonner";
import { Spinner } from "@/components/ui/spinner";
import { parseSseStream } from "@/lib/chat/parse-sse";
import { CHAT_SUGGESTED_PROMPTS } from "@/lib/chat/prompts";
import {
  CONNECTION_ERROR_MESSAGE,
  callAction,
  isConnectionError,
  isOffline,
} from "@/lib/utils/network";
import { TrackOnMount } from "@/components/analytics/track-on-mount";
import { trackEventAction } from "@/lib/api/track-event-action";
import { DENIED_HINT, shouldAskForPush, subscribeToPush } from "@/lib/push/subscribe";
import { DEADLINE_OPTIONS, DEADLINE_TEXT } from "@/lib/utils/action-step";
import {
  chatDoneEventSchema,
  chatErrorEventSchema,
  type ChatEntrySource,
  type ChatProposedAction,
  type ChatSessionMessage,
  type ChatSessionSummary,
  type DeadlineType,
} from "@/lib/api/schemas";
import {
  acceptChatActionAction,
  bookmarkMessageAction,
  createChatSessionAction,
  deleteChatSessionAction,
  getChatSessionMessagesAction,
  listChatSessionsAction,
  removeMessageBookmarkAction,
  removeMessageFeedbackAction,
  submitMessageFeedbackAction,
} from "../actions";
import { editActionStepAction } from "@/components/action-steps/actions";

// Design handoff's send-button icon (a plain arrow shape, not lucide's paper-plane Send) --
// mirrored via -scale-x-100 since it's authored pointing up-left but the composer's button sits
// on the input's leading (right) edge in this RTL layout.
function SendIcon({ size = 21 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="#fff"
      strokeWidth={1.9}
      strokeLinecap="round"
      strokeLinejoin="round"
      className="-scale-x-100"
    >
      <path d="m22 2-7 20-4-9-9-4Z" />
      <path d="M22 2 11 13" />
    </svg>
  );
}

type ChatRole = "user" | "ai";
type ChatMessage = {
  role: ChatRole;
  text: string;
  // Only set for real, persisted assistant messages -- needed to target accept-action.
  // Seed/local-only messages (and mock history) never have one.
  id?: number;
  proposedAction?: ChatProposedAction | null;
  actionAccepted?: boolean;
  quickReplies?: string[] | null;
  isError?: boolean;
  streaming?: boolean;
};
type MessageMeta = { vote?: "up" | "down"; copied?: boolean; saved?: boolean };

// Local, ephemeral UI state for one message's action card -- "declined" is never persisted
// (action_steps_spec_v2 §4: declining just continues the same conversation, no backend call),
// and "editing"/pre-accept edits only become real once the user taps accept.
type CardPhase = "view" | "editing" | "notifAsk" | "declined";
type CardDraft = { text: string; deadlineType: DeadlineType };

const DEFAULT_SEED: ChatMessage = {
  role: "ai",
  text: "سلام! من این‌جا هستم تا دربارهٔ گزارش‌تان صحبت کنیم. هر بخشی که مبهم بود یا خواستید عملی‌ترش کنید، بپرسید.",
};

const MANUAL_SEED: ChatMessage = {
  role: "ai",
  text: "سلام! این‌جا برای خودشناسی و رشدته — هر چی تو ذهنته بگو.",
};

// The single ready-made prompt shown instead of the normal chat-empty screen when the user
// arrives via the dashboard's "گفتگو با دستیار" card or the top nav's "گفت‌وگو" link (both plain
// MANUAL_SEED entries, no report/action context) -- these two entry points are meant to get the
// user straight to their next growth step, not into an open-ended chat.
const NEXT_STEP_PROMPT = "مناسب وضعیت فعلی من، یک قدم برای بهبود روند رشدم پیشنهاد بده";

const NEW_CHAT_SEED: ChatMessage = {
  role: "ai",
  text: "سلام! از هر جا دوست دارید شروع کنیم — دربارهٔ گزارش‌تان، یک تصمیم مشخص، یا هر چیزی که این روزها ذهن‌تان را درگیر کرده.",
};

// report_open_question: a placeholder, not a message. The question itself is rendered as
// display-only text on the empty screen (report_spec_v2_0 §9.2) and never sent, so the seed is
// dropped from the transcript when the user's first message goes out.
const OPEN_QUESTION_SEED: ChatMessage = { role: "ai", text: "" };

// report_cta without a ready-made question (the report's general "talk about my report" buttons):
// chat opens empty, as report_spec_v2_0 §9.1 says, instead of with a greeting from Faraman. A
// placeholder like OPEN_QUESTION_SEED -- it selects the empty screen and is dropped on first send.
const REPORT_CTA_SEED: ChatMessage = { role: "ai", text: "" };

const ACTION_REJECTED_SEED: ChatMessage = {
  role: "ai",
  text: "باشد، این قدم را کنار می‌گذاریم. بگو چی برایت جور نبود تا یک نسخهٔ مناسب‌تر پیدا کنیم.",
};

const ACTION_COMPLETED_SEED: ChatMessage = {
  role: "ai",
  text: "قدم قبلی را انجام دادی — عالی بود. هر وقت خواستی دربارهٔ آن حرف بزنیم یا قدم بعدی را بگیریم، همین‌جام.",
};

// chat_spec_v3 §1.4: a step the user accepted but did not do -- the conversation is about the
// step's size, not about the user. No blame, no "this time for sure".
const ACTION_MISSED_SEED: ChatMessage = {
  role: "ai",
  text: "برگشتی سراغ این قدم. بهم بگو چرا انجام نشد میخوام کمکت کنم",
};

// action_step.md §6.2 / chat_spec_v3 §1.4: the step is still pending (deadline not passed) --
// unlike the other three action entry sources, the mission here is not a new step. It's this
// same one: help the user do it or shrink it.
const ACTION_ACTIVE_SEED: ChatMessage = {
  role: "ai",
  text: "بگو ببینم، دربارهٔ این قدم چی تو ذهنته؟ می‌خوای انجامش بدیم یا کوچیک‌ترش کنیم؟",
};

function entrySeed(entrySource: string, sectionTitle?: string): ChatMessage[] {
  if (sectionTitle) {
    return [
      {
        role: "ai",
        text: `بخش «${sectionTitle}» از پروفایل توسعهٔ فردی‌ات را پیش رویم دارم. هر جا مبهم بود یا خواستی عملی‌ترش کنیم، بپرس.`,
      },
    ];
  }
  if (entrySource === "manual") return [MANUAL_SEED];
  if (entrySource === "report_open_question") return [OPEN_QUESTION_SEED];
  if (entrySource === "report_cta") return [REPORT_CTA_SEED];
  if (entrySource === "action_rejected") return [ACTION_REJECTED_SEED];
  if (entrySource === "action_completed") return [ACTION_COMPLETED_SEED];
  if (entrySource === "action_missed") return [ACTION_MISSED_SEED];
  if (entrySource === "action_active") return [ACTION_ACTIVE_SEED];
  return [DEFAULT_SEED];
}

const COPY_RESET_MS = 2000;
const GENERIC_ERROR_MESSAGE = "الان کمی شلوغ است. چند لحظه‌ی دیگر دوباره تلاش کنید.";

function bubbleRadius(role: ChatRole): React.CSSProperties {
  return role === "user"
    ? {
        borderTopLeftRadius: 18,
        borderTopRightRadius: 18,
        borderBottomRightRadius: 6,
        borderBottomLeftRadius: 18,
      }
    : {
        borderTopLeftRadius: 18,
        borderTopRightRadius: 18,
        borderBottomRightRadius: 18,
        borderBottomLeftRadius: 6,
      };
}

function mapSessionMessages(messages: ChatSessionMessage[]): ChatMessage[] {
  return messages.map((m) => ({
    role: m.role === "user" ? "user" : "ai",
    text: m.content,
    id: m.id,
    proposedAction: m.proposed_action,
    quickReplies: m.quick_replies,
    actionAccepted: m.action_accepted,
  }));
}

// Restores the requester's own thumbs-up/down and bookmark state on reopen -- indices must line
// up with mapSessionMessages' output, since MessageMeta is keyed by array index, not message id.
function mapSessionMeta(messages: ChatSessionMessage[]): Record<number, MessageMeta> {
  const meta: Record<number, MessageMeta> = {};
  messages.forEach((m, index) => {
    if (m.is_useful !== null || m.is_bookmarked) {
      meta[index] = { vote: m.is_useful === null ? undefined : m.is_useful ? "up" : "down", saved: m.is_bookmarked };
    }
  });
  return meta;
}

// Keeps ?session_id= pointing at the conversation currently on screen, so a reload -- or the
// OS restoring the tab days later -- resumes it instead of silently starting over. The App
// Router supports the native History API for exactly this: it rewrites the query without a
// server round-trip, so this screen is never remounted and the open stream survives.
function writeSessionIdToUrl(sessionId: string | null) {
  const params = new URLSearchParams(window.location.search);
  if (sessionId) params.set("session_id", sessionId);
  else params.delete("session_id");
  const query = params.toString();
  window.history.replaceState(null, "", `${window.location.pathname}${query ? `?${query}` : ""}`);
}

function iconButtonClass(active: boolean) {
  return `grid size-8 cursor-pointer place-items-center rounded-[9px] transition-colors ${
    active ? "" : "text-[#8B8676] hover:bg-[#F1EEE5]"
  }`;
}

type ChatViewProps = {
  initialEntrySource: ChatEntrySource;
  initialAttemptId?: number;
  // Required for entry_source action_completed/action_missed/action_active -- the ActionStep
  // this conversation is about (chat_spec_v3 §1.1/§1.4). Never sent with action_rejected:
  // rejection is only possible before accepting, so a rejected step has no row to point at
  // (action_step.md §3).
  initialActionStepId?: string;
  // action_rejected only: identifies the report suggested_step (with initialAttemptId) that was
  // rejected before it was ever accepted -- the only shape action_rejected ever takes.
  initialIndex?: number;
  // Set when arriving from a checkin followup (dashboard card or, later, a notification tap) --
  // resumes this existing session instead of creating a new one, per chat_spec_v1.md §1.1: "بازگشت
  // از پیگیری مقدار جدیدی ندارد — همان سشن با همان entry_source ادامه پیدا می‌کند."
  initialSessionId?: string;
  // Set by deep-report section CTAs (e.g. "«ذهن رشدگرا» در من چطور کار می‌کند؟") -- only changes
  // the local opening greeting bubble text, no backend/entry_source contract involved.
  initialSectionTitle?: string;
  // Where the user tapped into chat from (issue #92: closing chat always dropped them on the
  // dashboard regardless of entry point). Validated server-side to be an in-app path.
  initialFrom?: string;
  // A message to send automatically the moment the screen mounts, as if the user had typed it
  // and hit send -- the report's "دربارهٔ گزارشم سؤال دارم" box arrives this way, so the user
  // lands in chat with their question already on its way and the answer streaming in.
  initialMessage?: string;
  // Dashboard's "گفتگو با دستیار" card only (?intent=next_step) -- swaps the normal chatEmpty
  // screen for the single next-step prompt. The top nav's "گفت‌وگو" link shares the same
  // entry_source/from and must NOT set this, so it keeps the regular greeting + suggestions.
  isNextStepIntent?: boolean;
  // The profile's first name, for the empty-state greeting "سلام {name}" -- falls back to the
  // generic "دوست من" when the profile has none set.
  greetName?: string | null;
  // report_open_question only: the v2 report's open question, shown in the middle of the empty chat.
  openQuestion?: string | null;
};

export function ChatView({
  initialEntrySource,
  initialAttemptId,
  initialActionStepId,
  initialIndex,
  initialSessionId,
  initialSectionTitle,
  initialFrom,
  initialMessage,
  isNextStepIntent,
  greetName,
  openQuestion,
}: ChatViewProps) {
  const router = useRouter();
  const [sessionId, setSessionId] = useState<string | null>(null);
  // Why the chat has no usable session, or null while it is healthy. Keeping the reason (rather
  // than a bare boolean) is what lets a dropped connection read differently from a backend refusal.
  const [sessionError, setSessionError] = useState<string | null>(null);
  const [reconnecting, setReconnecting] = useState(false);
  // Skip the fixed opening seed bubble when a message is already on its way in (report chat
  // box / dashboard box): it would otherwise flash above the real conversation for no reason.
  const [messages, setMessages] = useState<ChatMessage[]>(() =>
    initialMessage ? [] : entrySeed(initialEntrySource, initialSectionTitle),
  );
  const [meta, setMeta] = useState<Record<number, MessageMeta>>({});
  const [text, setText] = useState("");
  const [typing, setTyping] = useState(false);
  // chat_spec's "chatEmpty" state (design handoff Phase 5 §E): shown only for a genuinely
  // context-free opening -- MANUAL_SEED/NEW_CHAT_SEED are the only seeds with nothing to say
  // about, so reference equality against those two module constants is a reliable, cheap check
  // (every other seed variant carries specific context and keeps its normal bubble instead).
  const isEmptyState =
    messages.length === 1 &&
    (messages[0] === MANUAL_SEED ||
      messages[0] === NEW_CHAT_SEED ||
      messages[0] === REPORT_CTA_SEED ||
      (messages[0] === OPEN_QUESTION_SEED && !openQuestion)) &&
    !typing;
  // MANUAL_SEED only means this screen was opened plain -- from the dashboard's "گفتگو با
  // دستیار" card or the top nav's "گفت‌وگو" link -- with nothing else going on yet, so it gets the
  // single next-step prompt instead of the full chatEmpty greeting + suggestion list.
  const isNextStepEntry = isEmptyState && messages[0] === MANUAL_SEED && Boolean(isNextStepIntent);
  // Without the question text there is nothing to show, so the seed falls back to the normal
  // empty screen (greeting + suggestions) instead of a blank one.
  const isOpenQuestionEntry = messages.length === 1 && messages[0] === OPEN_QUESTION_SEED && !typing;
  const isReportCtaEntry = messages.length === 1 && messages[0] === REPORT_CTA_SEED && !typing;
  const [panelOpen, setPanelOpen] = useState(false);
  const [sessions, setSessions] = useState<ChatSessionSummary[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<ChatSessionSummary | null>(null);
  const [deletingSession, setDeletingSession] = useState(false);
  const [pushSubscribing, setPushSubscribing] = useState(false);
  const [acceptingCard, setAcceptingCard] = useState<number | null>(null);
  const [cardPhase, setCardPhase] = useState<Record<number, CardPhase>>({});
  const [cardDraft, setCardDraft] = useState<Record<number, CardDraft>>({});
  const [editBuffer, setEditBuffer] = useState<Record<number, CardDraft>>({});

  // What the *next* session gets created from, whenever the user's first message finally
  // creates one. Fixed at the URL this screen was opened with; "گفتگوی تازه" repoints it at a
  // plain manual chat.
  const pendingSession = useRef<{
    entrySource: ChatEntrySource;
    attemptId?: number;
    actionStepId?: string;
    index?: number;
  }>({
    entrySource: initialEntrySource,
    attemptId: initialAttemptId,
    actionStepId: initialActionStepId,
    index: initialIndex,
  });

  const bottomRef = useRef<HTMLDivElement>(null);
  const copyTimeout = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const streamAbort = useRef<AbortController | null>(null);
  const cancelConnect = useRef(false);
  const autoSent = useRef(false);

  // Resumes the session named in the URL, if there is one. A screen opened *without* a
  // session_id connects to nothing here on purpose: the session is created by the user's first
  // message (see sendMessage), so opening chat and walking away never leaves an empty
  // conversation behind. Also the retry path -- the banner's button and the browser coming back
  // online both call it again after a failed attempt.
  const connectSession = useCallback((options?: { silent?: boolean }) => {
    // Nothing to resume, and nothing that could have failed: the banner (and with it the retry
    // that leads back here) only ever appears on the initialSessionId path below.
    if (!initialSessionId) return;

    // The retry that fires on "online" is not something the user asked for -- let the banner
    // speak for it instead of popping a toast they never triggered.
    const fail = (message: string) => {
      setSessionError(message);
      setReconnecting(false);
      if (!options?.silent) toast.error(message);
    };

    return callAction(
      getChatSessionMessagesAction(initialSessionId),
      GENERIC_ERROR_MESSAGE,
    ).then((result) => {
      if (cancelConnect.current) return;
      if (!result.ok) {
        fail(result.message);
        return;
      }
      const mapped = mapSessionMessages(result.data);
      setSessionError(null);
      setReconnecting(false);
      setSessionId(initialSessionId);
      setMessages(mapped.length > 0 ? mapped : entrySeed(initialEntrySource, initialSectionTitle));
      setMeta(mapped.length > 0 ? mapSessionMeta(result.data) : {});
    });
    // Only ever resumes one session per screen visit -- initialSessionId/initialEntrySource are
    // fixed for the lifetime of this component (they come from the URL that mounted it).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Retrying is the only path that shows a pending state -- the very first connect happens
  // behind the seed messages, with nothing on screen yet to put a spinner next to.
  const retryConnect = useCallback(
    (options?: { silent?: boolean }) => {
      setReconnecting(true);
      connectSession(options);
    },
    [connectSession],
  );

  useEffect(() => {
    cancelConnect.current = false;
    connectSession();
    return () => {
      cancelConnect.current = true;
    };
  }, [connectSession]);

  // The connection came back while the user sits on a chat that never opened -- reconnect for
  // them instead of leaving a dead screen that only a manual retry (or reload) can revive.
  useEffect(() => {
    if (!sessionError || sessionId) return;
    const reconnect = () => retryConnect({ silent: true });
    window.addEventListener("online", reconnect);
    return () => window.removeEventListener("online", reconnect);
  }, [sessionError, sessionId, retryConnect]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length, typing]);

  // Fire the message the user handed us on the way in (report chat box) exactly once -- there
  // is no session_id on this path, so sendMessage creates the session itself on this first send.
  useEffect(() => {
    if (autoSent.current || !initialMessage) return;
    autoSent.current = true;
    sendMessage(initialMessage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialMessage]);

  useEffect(() => {
    return () => {
      clearTimeout(copyTimeout.current);
      streamAbort.current?.abort();
    };
  }, []);

  function goBack() {
    // router.back() replays the browser's own back/forward cache, which Next.js exempts from
    // normal staleness rules -- it can restore a dashboard snapshot from before a step was
    // created/answered here. Navigate explicitly and always refresh so the destination pulls
    // fresh server data -- any chat can end in an accepted action step now (not just a fixed
    // action_preview flow), and listPendingActionSteps() is a plain read with no server-side
    // "showing" side effect to worry about inflating.
    const destination =
      initialFrom ?? (initialAttemptId ? `/report?attemptId=${initialAttemptId}#advice` : "/dashboard");
    router.replace(destination);
    router.refresh();
  }

  function updateLastMessage(patch: Partial<ChatMessage> | ((m: ChatMessage) => Partial<ChatMessage>)) {
    setMessages((prev) => {
      const next = [...prev];
      const last = next[next.length - 1];
      next[next.length - 1] = { ...last, ...(typeof patch === "function" ? patch(last) : patch) };
      return next;
    });
  }

  function updateMessageAt(
    index: number,
    patch: Partial<ChatMessage> | ((m: ChatMessage) => Partial<ChatMessage>),
  ) {
    setMessages((prev) => {
      const next = [...prev];
      const current = next[index];
      next[index] = { ...current, ...(typeof patch === "function" ? patch(current) : patch) };
      return next;
    });
  }

  async function sendMessage(raw: string, options?: { silent?: boolean }) {
    const value = raw.trim();
    if (!value || typing || sessionError) return;

    // Known-offline: fail before touching the transcript, so the user keeps what they typed and
    // can send it unchanged once they are back, with no half-sent message left on screen.
    if (isOffline()) {
      toast.error(CONNECTION_ERROR_MESSAGE);
      return;
    }

    setTyping(true);

    // The first message is what actually creates the session. Opening this screen only puts a
    // local seed bubble on it -- a chat the user opened and walked away from is not a
    // conversation, and must not show up in their history as an empty one.
    let targetSessionId = sessionId;
    // Only the dashboard/"گفت‌وگو با دستیار" next-step entry (MANUAL_SEED, isNextStepEntry) is a
    // throwaway placeholder with nothing to keep -- every other seed (report/action/deep-report
    // context lines, "گفتگوی تازه") is a real opening line for that conversation and stays put
    // once the user replies to it.
    const dropSeedOnSend = isNextStepEntry || isOpenQuestionEntry || isReportCtaEntry;
    if (!targetSessionId) {
      const { entrySource, attemptId, actionStepId, index } = pendingSession.current;
      const created = await callAction(
        createChatSessionAction(entrySource, attemptId, actionStepId, index),
        GENERIC_ERROR_MESSAGE,
      );
      if (!created.ok) {
        // Nothing was appended and `text` is untouched, so pressing send again is the whole
        // retry -- no half-sent message and no empty session left behind.
        setTyping(false);
        toast.error(created.message);
        return;
      }
      targetSessionId = created.data.session_id;
      setSessionId(targetSessionId);
      writeSessionIdToUrl(targetSessionId);
    }

    setMessages((prev) => [
      ...(dropSeedOnSend ? prev.filter((m) => m.id) : prev),
      ...(options?.silent ? [] : [{ role: "user" as const, text: value }]),
      { role: "ai" as const, text: "", streaming: true },
    ]);
    setText("");

    const controller = new AbortController();
    streamAbort.current = controller;
    // Whether any of the answer made it to the screen before a failure -- decides between
    // replacing the empty bubble with the error and toasting that a shown answer is unfinished.
    let streamed = false;

    try {
      const res = await fetch(`/api/chat/sessions/${targetSessionId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_message: value }),
        signal: controller.signal,
      });

      if (!res.ok || !res.body) {
        const envelope = await res.json().catch(() => null);
        setMessages((prev) => prev.slice(0, -1));
        toast.error(typeof envelope?.message === "string" ? envelope.message : GENERIC_ERROR_MESSAGE);
        return;
      }

      for await (const evt of parseSseStream(res.body)) {
        if (evt.event === "delta") {
          const delta = JSON.parse(evt.data) as { text: string };
          streamed = true;
          updateLastMessage((m) => ({ text: m.text + delta.text }));
        } else if (evt.event === "done") {
          const done = chatDoneEventSchema.parse(JSON.parse(evt.data));
          updateLastMessage({
            text: done.message,
            id: done.message_id,
            proposedAction: done.proposed_action,
            quickReplies: done.quick_replies,
            streaming: false,
          });
        } else if (evt.event === "error") {
          const err = chatErrorEventSchema.parse(JSON.parse(evt.data));
          updateLastMessage((m) => ({
            text: m.text || err.user_message,
            isError: !m.text,
            streaming: false,
          }));
          if (!controller.signal.aborted) toast.error(err.user_message);
        }
      }
    } catch (error) {
      if (controller.signal.aborted) return;
      // A request that never reached our own server, or a stream cut mid-answer, is the user's
      // connection -- saying "we are busy" here blames the backend for something it never saw.
      const message = isConnectionError(error) ? CONNECTION_ERROR_MESSAGE : GENERIC_ERROR_MESSAGE;
      updateLastMessage((m) => ({
        text: m.text || message,
        isError: !m.text,
        streaming: false,
      }));
      // A partial answer stays on screen looking finished -- the toast is the only thing telling
      // the user it was cut short. With nothing streamed, the bubble itself carries the message.
      if (streamed) toast.error(message);
    } finally {
      setTyping(false);
    }
  }

  async function acceptAction(index: number) {
    const message = messages[index];
    if (!message.id || acceptingCard !== null) return;

    setAcceptingCard(index);
    const result = await callAction(acceptChatActionAction(message.id), GENERIC_ERROR_MESSAGE);
    if (!result.ok) {
      setAcceptingCard(null);
      toast.error(result.message);
      return;
    }

    // A pre-accept local edit (the card's "editing" phase) has no backend row to PATCH until
    // now -- apply it as a follow-up edit against the step accept-action just created/revised.
    const draft = cardDraft[index];
    if (draft) {
      const editResult = await callAction(
        editActionStepAction(result.data.id, {
          step_text: draft.text,
          deadline_type: draft.deadlineType,
        }),
        GENERIC_ERROR_MESSAGE,
      );
      if (!editResult.ok) toast.error(editResult.message);
    }

    setMessages((prev) => prev.map((m, i) => (i === index ? { ...m, actionAccepted: true } : m)));
    setAcceptingCard(null);
    toast.success("به قدم‌های شما اضافه شد.");

    setCardPhase((prev) => ({ ...prev, [index]: shouldAskForPush() ? "notifAsk" : "view" }));
  }

  function declineAction(index: number) {
    setCardPhase((prev) => ({ ...prev, [index]: "declined" }));
    sendMessage("یک پیشنهاد دیگر بده");
  }

  // cardPhase/cardDraft/editBuffer are all keyed by message index, so they only mean anything
  // for the transcript currently on screen -- swapping conversations has to drop them, or index
  // 3's "editing" state reappears on an unrelated message of the next chat.
  function resetCardState() {
    setCardPhase({});
    setCardDraft({});
    setEditBuffer({});
  }

  // editBuffer holds the in-progress textarea/deadline-picker values while a card is in its
  // "editing" phase -- separate from cardDraft (the committed edit used for display and, at
  // accept time, the follow-up PATCH) so cancelling mid-edit never touches what's already saved.
  function startEditCard(index: number, current: ChatProposedAction) {
    const base = cardDraft[index] ?? { text: current.text, deadlineType: current.deadline_type };
    setEditBuffer((prev) => ({ ...prev, [index]: base }));
    setCardPhase((prev) => ({ ...prev, [index]: "editing" }));
  }

  function saveEditCard(index: number) {
    const buffered = editBuffer[index];
    if (buffered) setCardDraft((prev) => ({ ...prev, [index]: buffered }));
    setCardPhase((prev) => ({ ...prev, [index]: "view" }));
  }

  function cancelEditCard(index: number) {
    setCardPhase((prev) => ({ ...prev, [index]: "view" }));
  }

  async function allowNotifForCard(index: number) {
    setPushSubscribing(true);
    const result = await subscribeToPush();
    setPushSubscribing(false);
    void trackEventAction({ event_name: "push_permission_result", properties: { result } });
    if (result === "error") toast.error("فعال‌سازی اعلان‌ها موفق نبود.");
    if (result === "denied" && Notification.permission === "denied") toast.error(DENIED_HINT);
    setCardPhase((prev) => ({ ...prev, [index]: "view" }));
  }

  function denyNotifForCard(index: number) {
    setCardPhase((prev) => ({ ...prev, [index]: "view" }));
  }

  async function regenerateMessage(index: number) {
    const message = messages[index];
    // Seed/local-only messages have no backend id to regenerate, and only one regeneration
    // should ever be in flight at a time (shares streamAbort/typing with sendMessage).
    if (!message.id || !sessionId || typing) return;

    // Regenerating clears the existing answer first -- offline that trades a readable message
    // for an error bubble and loses it for nothing. Leave the transcript alone and say why.
    if (isOffline()) {
      toast.error(CONNECTION_ERROR_MESSAGE);
      return;
    }

    const originalText = message.text;
    const originalId = message.id;

    updateMessageAt(index, {
      text: "",
      streaming: true,
      isError: false,
      proposedAction: null,
      quickReplies: null,
      actionAccepted: undefined,
    });
    setMeta((prev) => ({ ...prev, [index]: {} }));
    setTyping(true);

    const controller = new AbortController();
    streamAbort.current = controller;

    try {
      const res = await fetch(`/api/chat/sessions/${sessionId}/messages/${originalId}/regenerate`, {
        method: "POST",
        signal: controller.signal,
      });

      if (!res.ok || !res.body) {
        const envelope = await res.json().catch(() => null);
        // Validation (unknown session/message) fails before the backend deletes anything --
        // put the original message back instead of leaving an empty bubble.
        updateMessageAt(index, { text: originalText, id: originalId, streaming: false });
        toast.error(typeof envelope?.message === "string" ? envelope.message : GENERIC_ERROR_MESSAGE);
        return;
      }

      for await (const evt of parseSseStream(res.body)) {
        if (evt.event === "delta") {
          const delta = JSON.parse(evt.data) as { text: string };
          updateMessageAt(index, (m) => ({ text: m.text + delta.text }));
        } else if (evt.event === "done") {
          const done = chatDoneEventSchema.parse(JSON.parse(evt.data));
          updateMessageAt(index, {
            text: done.message,
            id: done.message_id,
            proposedAction: done.proposed_action,
            quickReplies: done.quick_replies,
            streaming: false,
          });
        } else if (evt.event === "error") {
          const err = chatErrorEventSchema.parse(JSON.parse(evt.data));
          updateMessageAt(index, (m) => ({
            text: m.text || err.user_message,
            isError: !m.text,
            streaming: false,
          }));
          if (!controller.signal.aborted) toast.error(err.user_message);
        }
      }
    } catch (error) {
      if (controller.signal.aborted) return;
      const message = isConnectionError(error) ? CONNECTION_ERROR_MESSAGE : GENERIC_ERROR_MESSAGE;
      updateMessageAt(index, (m) => ({
        // Nothing streamed back before the failure -- put the answer the user already had back
        // rather than trading a readable message for an error bubble.
        text: m.text || originalText || message,
        isError: !m.text && !originalText,
        streaming: false,
      }));
      // The restored (or partial) text reads like a normal answer, so the toast is the only
      // thing telling the user the regeneration did not go through.
      toast.error(message);
    } finally {
      setTyping(false);
    }
  }

  function copyMessage(index: number, value: string) {
    navigator.clipboard?.writeText(value).catch(() => {});
    setMeta((prev) => ({ ...prev, [index]: { ...prev[index], copied: true } }));
    clearTimeout(copyTimeout.current);
    copyTimeout.current = setTimeout(() => {
      setMeta((prev) => ({ ...prev, [index]: { ...prev[index], copied: false } }));
    }, COPY_RESET_MS);
  }

  async function toggleVote(index: number, vote: "up" | "down") {
    const message = messages[index];
    if (!message.id) return; // template/seed message -- no feedback to record

    // A single `vote` field (rather than separate up/down flags) is what makes like and
    // dislike mutually exclusive -- selecting one always replaces the other, never both.
    const previousVote = meta[index]?.vote;
    const nextVote = previousVote === vote ? undefined : vote;
    setMeta((prev) => ({ ...prev, [index]: { ...prev[index], vote: nextVote } }));

    const result = await callAction(
      nextVote === undefined
        ? removeMessageFeedbackAction(message.id)
        : submitMessageFeedbackAction(message.id, nextVote === "up"),
      GENERIC_ERROR_MESSAGE,
    );
    if (!result.ok) {
      setMeta((prev) => ({ ...prev, [index]: { ...prev[index], vote: previousVote } }));
      toast.error(result.message);
    }
  }

  async function toggleSave(index: number) {
    const message = messages[index];
    if (!message.id) return; // seed/local-only message -- nothing to persist

    const wasSaved = Boolean(meta[index]?.saved);
    const nextSaved = !wasSaved;
    setMeta((prev) => ({ ...prev, [index]: { ...prev[index], saved: nextSaved } }));

    const result = await callAction(
      nextSaved ? bookmarkMessageAction(message.id) : removeMessageBookmarkAction(message.id),
      GENERIC_ERROR_MESSAGE,
    );
    if (!result.ok) {
      setMeta((prev) => ({ ...prev, [index]: { ...prev[index], saved: wasSaved } }));
      toast.error(result.message);
      return;
    }
    if (nextSaved) toast.success("به پیام‌های نشان‌شده اضافه شد.");
  }

  // No backend call: the new chat becomes a real session the moment the user sends into it,
  // not the moment they ask for one. Whatever they were reading stays gone from the screen
  // either way, so tapping this and changing their mind costs an empty session nothing.
  function startNewChat() {
    setPanelOpen(false);
    streamAbort.current?.abort();
    pendingSession.current = { entrySource: "manual" };
    setSessionId(null);
    setSessionError(null);
    setMessages([NEW_CHAT_SEED]);
    setMeta({});
    resetCardState();
    setText("");
    setTyping(false);
    writeSessionIdToUrl(null);
  }

  async function openHistoryPanel() {
    setPanelOpen(true);
    setLoadingHistory(true);
    const result = await callAction(listChatSessionsAction(), GENERIC_ERROR_MESSAGE);
    setLoadingHistory(false);
    if (result.ok) {
      setSessions(result.data);
    } else {
      toast.error(result.message);
    }
  }

  async function openConversation(session: ChatSessionSummary) {
    const result = await callAction(
      getChatSessionMessagesAction(session.session_id),
      GENERIC_ERROR_MESSAGE,
    );
    if (!result.ok) {
      toast.error(result.message);
      return;
    }

    const mapped = mapSessionMessages(result.data);

    setSessionId(session.session_id);
    setSessionError(null);
    setMessages(mapped.length > 0 ? mapped : entrySeed(session.entry_source));
    setMeta(mapped.length > 0 ? mapSessionMeta(result.data) : {});
    resetCardState();
    setText("");
    setTyping(false);
    setPanelOpen(false);
    writeSessionIdToUrl(session.session_id);
  }

  async function confirmDeleteSession() {
    if (!deleteTarget || deletingSession) return;
    const target = deleteTarget;
    setDeletingSession(true);
    const result = await callAction(
      deleteChatSessionAction(target.session_id),
      GENERIC_ERROR_MESSAGE,
    );
    setDeletingSession(false);
    if (!result.ok) {
      toast.error(result.message);
      return;
    }
    setSessions((prev) => prev.filter((s) => s.session_id !== target.session_id));
    setDeleteTarget(null);
    // The open conversation just got deleted out from under the user -- fall back to a fresh
    // manual chat instead of leaving stale messages of a session that no longer exists on screen.
    if (target.session_id === sessionId) {
      startNewChat();
    }
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    sendMessage(text);
  }

  return (
    <main className="animate-fm-in mx-auto flex h-dvh w-full max-w-[560px] flex-col">
      {/* Screen opened, before any session exists (one is created lazily on the first send). */}
      {!initialSessionId && (
        <TrackOnMount event="chat_opened" properties={{ entry_source: initialEntrySource }} />
      )}
      <div className="bg-background sticky top-0 z-10 flex flex-none items-center gap-2.5 px-[18px] py-3">
        <button
          type="button"
          aria-label="بستن"
          onClick={goBack}
          className="text-muted-foreground grid size-[42px] flex-none cursor-pointer place-items-center rounded-xl text-[20px]"
        >
          ✕
        </button>
        <div className="flex-1 text-center text-[15px] font-extrabold">گفتگو</div>
        <button
          type="button"
          aria-label="تاریخچهٔ گفتگوها"
          onClick={openHistoryPanel}
          className="border-foreground bg-card text-foreground grid size-[42px] flex-none cursor-pointer place-items-center rounded-xl border-[1.5px]"
        >
          <PanelLeft size={19} strokeWidth={1.8} />
        </button>
      </div>

      {isNextStepEntry ? (
        <div className="flex flex-1 flex-col items-center justify-center gap-6 overflow-y-auto px-[26px] pt-2 pb-5 text-center">
          <div
            className="grid size-16 flex-none place-items-center rounded-[20px]"
            style={{
              background: "linear-gradient(150deg,#2743C6,#8E6BA8)",
              boxShadow: "0 12px 26px -12px rgba(39,67,198,.65)",
            }}
          >
            <MessageCircle size={31} strokeWidth={1.7} className="text-white" />
          </div>
          <button
            type="button"
            onClick={() => sendMessage(NEXT_STEP_PROMPT)}
            className="flex w-full max-w-[340px] min-h-[54px] cursor-pointer items-center gap-3 rounded-full border-[1.5px] border-[#DCD3BE] bg-white px-[22px] py-[15px] text-right text-sm font-bold leading-[1.7] hover:border-primary hover:text-primary"
          >
            <span className="flex-1">{NEXT_STEP_PROMPT}</span>
            <span className="flex-none text-[15px] text-[#A9A597]">←</span>
          </button>
        </div>
      ) : isOpenQuestionEntry && openQuestion ? (
        <div className="flex flex-1 flex-col items-center justify-center gap-5 overflow-y-auto px-[26px] pt-2 pb-5 text-center">
          <div className="h-px w-7 bg-[#CFC6B4]" />
          <div className="max-w-[360px] text-[21px] leading-[1.95] font-bold text-pretty text-[#4A2F63]">
            {openQuestion}
          </div>
          <div className="text-[12.5px] text-[#8B8676]">جوابت را همین پایین بنویس</div>
        </div>
      ) : isEmptyState ? (
        <div className="flex flex-1 flex-col gap-[34px] overflow-y-auto px-[26px] pt-2 pb-5">
          <div className="mt-auto flex flex-col items-center gap-4 text-center">
            <div
              className="grid size-16 flex-none place-items-center rounded-[20px]"
              style={{
                background: "linear-gradient(150deg,#2743C6,#8E6BA8)",
                boxShadow: "0 12px 26px -12px rgba(39,67,198,.65)",
              }}
            >
              <MessageCircle size={31} strokeWidth={1.7} className="text-white" />
            </div>
            <div className="text-sm font-bold text-[#8B8676]">سلام {greetName || "دوست من"}</div>
            <div className="max-w-[340px] text-[25px] leading-[1.6] font-extrabold tracking-[-.01em] text-pretty">
              امروز از کجا شروع کنیم؟
            </div>
          </div>
          <div className="mb-auto flex flex-col gap-2.5">
            <div className="pb-0.5 text-center text-[13.5px] font-extrabold text-[#5D5C55]">
              می‌تونی با یکی از این‌ها شروع کنی
            </div>
            {CHAT_SUGGESTED_PROMPTS.map((prompt) => (
              <button
                key={prompt}
                type="button"
                onClick={() => sendMessage(prompt)}
                className="flex min-h-[54px] w-full cursor-pointer items-center gap-3 rounded-full border-[1.5px] border-[#DCD3BE] bg-white px-[22px] py-[15px] text-right text-sm font-bold leading-[1.7] hover:border-primary hover:text-primary"
              >
                <span className="flex-1">{prompt}</span>
                <span className="flex-none text-[15px] text-[#A9A597]">←</span>
              </button>
            ))}
          </div>
        </div>
      ) : (
      <div className="flex flex-1 flex-col gap-4 overflow-y-auto px-[22px] pt-2.5 pb-6">
        {messages.map((m, i) => {
          const mm = meta[i];
          const isLast = i === messages.length - 1;
          const showTypingDots = Boolean(m.streaming) && !m.text;
          const showQuickReplies = m.role === "ai" && isLast && !m.streaming && Boolean(m.quickReplies?.length);
          const showProposedAction = m.role === "ai" && m.proposedAction && !m.isError;
          // Requires a real persisted id -- the opening greeting is a fixed template, never
          // actually generated, so it gets no feedback/bookmark/regenerate controls at all.
          const showFeedback =
            m.role === "ai" && !m.isError && !(m.streaming && isLast) && m.text && Boolean(m.id)
            && !showQuickReplies && !showProposedAction;
          // Regenerating an older assistant turn deletes it while later turns in the same
          // session still stand on the context it originally set -- restrict it to the reply to
          // the user's last message, where there is nothing downstream to go stale (issue #93).
          const showRegenerate = showFeedback && isLast;
          return (
            <div
              key={i}
              className={`flex flex-col gap-1.5 ${m.role === "user" ? "items-start" : "items-end"}`}
            >
              {showTypingDots ? (
                <div
                  className="border-border bg-card flex w-fit items-center gap-1.5 border px-[18px] py-[15px]"
                  style={bubbleRadius("ai")}
                >
                  <span className="animate-fm-dot size-[7px] rounded-full bg-[#A9A597]" />
                  <span className="animate-fm-dot size-[7px] rounded-full bg-[#A9A597] [animation-delay:.2s]" />
                  <span className="animate-fm-dot size-[7px] rounded-full bg-[#A9A597] [animation-delay:.4s]" />
                </div>
              ) : (
                <div
                  className={`animate-fm-in max-w-[85%] px-[17px] py-[13px] text-[13.5px] leading-[2] ${
                    m.role === "user"
                      ? "bg-primary text-white"
                      : m.isError
                        ? "border-border bg-card border text-muted-foreground"
                        : "border-border bg-card border text-[#3C4150]"
                  }`}
                  style={bubbleRadius(m.role)}
                >
                  {m.text.split(/\n{2,}/).map((para, pi) => (
                    <p key={pi} className={`m-0 whitespace-pre-line ${pi > 0 ? "mt-2" : ""}`}>
                      {para}
                    </p>
                  ))}
                </div>
              )}

              {showProposedAction && m.proposedAction && (() => {
                const phase = cardPhase[i] ?? "view";
                const draft = cardDraft[i];
                const displayedText = draft?.text ?? m.proposedAction.text;
                const displayedDeadline = draft?.deadlineType ?? m.proposedAction.deadline_type;
                const buffer = editBuffer[i] ?? { text: displayedText, deadlineType: displayedDeadline };

                return (
                  <div
                    className="flex w-[85%] flex-col gap-3.5 rounded-[18px] border-[1.5px] bg-white p-5"
                    style={{ borderColor: "#8E6BA8", boxShadow: "0 4px 16px rgba(80,70,40,.08)" }}
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      <div className="text-[11px] font-extrabold" style={{ color: "#8E6BA8" }}>
                        قدم پیشنهادی
                      </div>
                      {draft && <span className="text-[10px] font-bold text-[#A9A597]">ویرایش‌شده</span>}
                    </div>

                    {phase === "declined" ? (
                      <div className="text-[12px] leading-[1.9] text-[#A9A597]">
                        این قدم ثبت نشد — در همین گفتگو سراغ نسخهٔ بهتر می‌رویم.
                      </div>
                    ) : phase === "editing" ? (
                      <div className="flex flex-col gap-3">
                        <textarea
                          value={buffer.text}
                          onChange={(e) =>
                            setEditBuffer((prev) => ({ ...prev, [i]: { ...buffer, text: e.target.value } }))
                          }
                          dir="rtl"
                          rows={3}
                          className="border-border focus:border-primary w-full resize-none rounded-2xl border-[1.5px] bg-[#FBF8F1] px-3.5 py-3 text-[13.5px] leading-[1.95] outline-none"
                        />
                        <div className="flex flex-col gap-2">
                          <div className="text-[11.5px] font-extrabold text-[#8B8676]">مهلت</div>
                          <div className="flex flex-wrap gap-1.5">
                            {DEADLINE_OPTIONS.map((opt) => (
                              <button
                                key={opt.value}
                                type="button"
                                onClick={() =>
                                  setEditBuffer((prev) => ({ ...prev, [i]: { ...buffer, deadlineType: opt.value } }))
                                }
                                className={
                                  opt.value === buffer.deadlineType
                                    ? "border-primary bg-secondary text-primary min-h-11 cursor-pointer rounded-full border-[1.5px] px-[15px] py-[10px] text-xs font-bold"
                                    : "border-border text-foreground min-h-11 cursor-pointer rounded-full border-[1.5px] bg-white px-[15px] py-[10px] text-xs font-bold"
                                }
                              >
                                {opt.label}
                              </button>
                            ))}
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => saveEditCard(i)}
                            className="min-h-11 flex-1 cursor-pointer rounded-[13px] bg-[#6B4FA8] p-3 text-[13px] font-extrabold text-white"
                          >
                            ثبت ویرایش
                          </button>
                          <button
                            type="button"
                            onClick={() => cancelEditCard(i)}
                            className="border-border min-h-11 flex-1 cursor-pointer rounded-[13px] border-[1.5px] bg-white p-3 text-[13px] font-bold text-[#8B8676]"
                          >
                            بی‌خیال
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <p className="m-0 text-[15px] leading-[2] font-bold text-pretty text-[#242A38]">
                          {displayedText}
                        </p>
                        <span
                          className="self-start rounded-full px-3 py-[5px] text-[11.5px] font-bold whitespace-nowrap"
                          style={{ background: "#E9EBF8", color: "#22307E" }}
                        >
                          مهلت: {DEADLINE_TEXT[displayedDeadline]}
                        </span>

                        {m.actionAccepted ? (
                          phase === "notifAsk" ? (
                            <div className="flex flex-col gap-2.5 border-t border-[#F1ECE1] pt-3">
                              <div className="text-[13px] font-extrabold text-[#242A38]">
                                یادآوری همین قدم را بفرستم؟
                              </div>
                              <div className="flex flex-col gap-2">
                                <button
                                  type="button"
                                  onClick={() => allowNotifForCard(i)}
                                  disabled={pushSubscribing}
                                  className="bg-primary flex min-h-11 cursor-pointer items-center justify-center gap-2.5 rounded-[13px] p-3 text-[13px] font-extrabold text-white disabled:cursor-not-allowed disabled:opacity-75"
                                >
                                  {pushSubscribing && <Spinner />}
                                  {pushSubscribing ? "در حال فعال‌سازی…" : "بله، یادآوری کن"}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => denyNotifForCard(i)}
                                  className="border-border min-h-11 cursor-pointer rounded-[13px] border-[1.5px] bg-white p-3 text-[13px] font-bold text-[#8B8676]"
                                >
                                  نه، لازم نیست
                                </button>
                              </div>
                            </div>
                          ) : (
                            <div className="flex flex-col gap-2 border-t border-[#F1ECE1] pt-3">
                              <div className="text-[13px] font-extrabold" style={{ color: "#2E8A5C" }}>
                                ثبت شد ✓
                              </div>
                              <div className="text-[12px] leading-[1.9] text-[#5D5C55]">
                                کار ما در این گفتگو تمام است. دفعهٔ بعد که وارد شدید، در خانه پیگیری همین قدم را می‌پرسم.
                              </div>
                            </div>
                          )
                        ) : (
                          <div className="flex flex-col gap-2.5">
                            <button
                              type="button"
                              onClick={() => acceptAction(i)}
                              disabled={acceptingCard !== null}
                              className="bg-primary flex min-h-11 cursor-pointer items-center justify-center gap-2.5 rounded-[14px] p-3.5 text-[14.5px] font-extrabold text-white disabled:cursor-not-allowed disabled:opacity-75"
                            >
                              {acceptingCard === i && <Spinner />}
                              قبول دارم
                            </button>
                            <div className="flex gap-2">
                              <button
                                type="button"
                                onClick={() => startEditCard(i, m.proposedAction!)}
                                className="min-h-11 flex-1 cursor-pointer rounded-[14px] border-[1.5px] border-[#EDE7DA] bg-white p-3 text-[13px] font-bold text-[#242A38]"
                              >
                                ویرایش
                              </button>
                              <button
                                type="button"
                                onClick={() => declineAction(i)}
                                className="min-h-11 flex-1 cursor-pointer rounded-[14px] border-[1.5px] border-[#EDE7DA] bg-[#FBF8F1] p-3 text-[13px] font-bold text-[#8B8676]"
                              >
                                یک پیشنهاد دیگر بده
                              </button>
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                );
              })()}

              {showQuickReplies && m.quickReplies && (
                <div className="flex max-w-[85%] flex-wrap gap-2">
                  {m.quickReplies.map((option) => (
                    <button
                      key={option}
                      type="button"
                      onClick={() => sendMessage(option)}
                      className="min-h-11 cursor-pointer rounded-full border-[1.5px] border-[#EDE7DA] bg-white px-[18px] py-[10px] text-[13px] font-bold text-[#242A38]"
                    >
                      {option}
                    </button>
                  ))}
                </div>
              )}

              {showFeedback && (
                <div className="flex items-center gap-1 px-0.5">
                  <button
                    type="button"
                    title="مفید بود"
                    onClick={() => toggleVote(i, "up")}
                    className={iconButtonClass(mm?.vote === "up")}
                    style={mm?.vote === "up" ? { background: "#E7EBFA", color: "#2743C6" } : undefined}
                  >
                    <ThumbsUp size={14} strokeWidth={1.8} />
                  </button>
                  <button
                    type="button"
                    title="مفید نبود"
                    onClick={() => toggleVote(i, "down")}
                    className={iconButtonClass(mm?.vote === "down")}
                    style={mm?.vote === "down" ? { background: "#F6E9E9", color: "#B4553F" } : undefined}
                  >
                    <ThumbsDown size={14} strokeWidth={1.8} />
                  </button>
                  <button
                    type="button"
                    title="کپی پاسخ"
                    onClick={() => copyMessage(i, m.text)}
                    className={iconButtonClass(Boolean(mm?.copied))}
                    style={mm?.copied ? { background: "#E7EBFA", color: "#2743C6" } : undefined}
                  >
                    {mm?.copied ? (
                      <Check size={14} strokeWidth={2.2} className="animate-fm-in" />
                    ) : (
                      <Copy size={14} strokeWidth={1.8} />
                    )}
                  </button>
                  <button
                    type="button"
                    title="نشان کردن"
                    onClick={() => toggleSave(i)}
                    className={iconButtonClass(Boolean(mm?.saved))}
                    style={mm?.saved ? { background: "#F3EBF6", color: "#8E6BA8" } : undefined}
                  >
                    <Bookmark size={14} strokeWidth={1.8} fill={mm?.saved ? "#8E6BA8" : "none"} />
                  </button>
                  {showRegenerate && (
                    <button
                      type="button"
                      title="پاسخ دوباره"
                      onClick={() => regenerateMessage(i)}
                      disabled={typing}
                      className="grid size-8 cursor-pointer place-items-center rounded-[9px] text-[#8B8676] hover:bg-[#F1EEE5] disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <RotateCcw size={14} strokeWidth={1.8} />
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>
      )}

      {sessionError && (
        <div
          role="alert"
          className="border-border bg-card mx-7 mb-2 flex flex-none items-center gap-2.5 rounded-[16px] border px-4 py-3"
        >
          {sessionError === CONNECTION_ERROR_MESSAGE ? (
            <WifiOff size={17} strokeWidth={1.8} className="text-muted-foreground flex-none" />
          ) : (
            <TriangleAlert size={17} strokeWidth={1.8} className="text-muted-foreground flex-none" />
          )}
          <p className="text-muted-foreground flex-1 text-[12px] leading-[1.9]">{sessionError}</p>
          <button
            type="button"
            onClick={() => retryConnect()}
            disabled={reconnecting}
            className="border-foreground text-foreground flex flex-none cursor-pointer items-center gap-2 rounded-[11px] border-[1.5px] px-3 py-1.5 text-[11.5px] font-bold disabled:opacity-50"
          >
            {reconnecting && <Spinner />}
            {reconnecting ? "در حال تلاش…" : "تلاش دوباره"}
          </button>
        </div>
      )}

      <form
        onSubmit={handleSubmit}
        autoComplete="off"
        className="border-border bg-background flex flex-none flex-col gap-3 border-t px-7 pt-3.5 pb-6"
      >
        <div className="flex items-center gap-2">
          <button
            type="submit"
            aria-label="ارسال"
            disabled={!text.trim() || typing || Boolean(sessionError)}
            className="bg-primary grid size-12 flex-none cursor-pointer place-items-center rounded-[16px] text-white disabled:cursor-not-allowed disabled:opacity-50"
          >
            {typing ? <Spinner /> : <SendIcon />}
          </button>
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            dir="rtl"
            // type="search" is what actually keeps the Android/Samsung autofill strip
            // (password/card/address shortcuts) off the top of the keyboard -- a lone type="text"
            // field in a <form> gets classified as a login box and autocomplete="off" alone
            // isn't always honoured. The extra opt-out hints cover third-party password managers.
            // ::-webkit-search-cancel-button is hidden so it stays visually a plain chat box.
            type="search"
            autoComplete="off"
            autoCorrect="off"
            autoCapitalize="sentences"
            spellCheck={false}
            enterKeyHint="send"
            data-1p-ignore
            data-lpignore="true"
            data-form-type="other"
            placeholder={sessionError ? "گفتگو در دسترس نیست…" : "هر چه در ذهنت هست بنویس…"}
            disabled={Boolean(sessionError)}
            className="border-border focus:border-primary min-w-0 flex-1 rounded-full border-[1.5px] bg-white px-5 py-[14px] text-[13.5px] outline-none transition-colors [&::-webkit-search-cancel-button]:hidden disabled:opacity-60"
          />
        </div>
      </form>

      {panelOpen && (
        <div dir="ltr" className="fixed inset-0 z-[70] flex justify-start">
          <div
            onClick={() => setPanelOpen(false)}
            className="animate-fm-fade absolute inset-0 bg-[rgba(20,18,14,.46)] backdrop-blur-[2px]"
          />
          <div
            dir="rtl"
            className="animate-fm-in border-border relative flex h-full w-[82%] max-w-[340px] flex-col gap-4 overflow-y-auto border-l p-5"
            style={{
              background: "linear-gradient(180deg,#FBF8F1,#F3EEE2)",
              boxShadow: "-8px 0 40px rgba(40,30,10,.2)",
            }}
          >
            <div className="flex items-center gap-2.5">
              <div className="text-primary flex-1 text-[19px] font-extrabold">دستیار فرامن</div>
              <button
                type="button"
                aria-label="بستن"
                onClick={() => setPanelOpen(false)}
                className="text-muted-foreground grid size-[38px] cursor-pointer place-items-center rounded-[11px] bg-white shadow-[0_1px_3px_rgba(40,30,10,.08)]"
              >
                ✕
              </button>
            </div>
            <button
              type="button"
              onClick={startNewChat}
              className="bg-primary flex min-h-[52px] cursor-pointer items-center justify-center gap-2.5 rounded-2xl p-[15px] text-[14.5px] font-extrabold text-white shadow-[0_6px_16px_rgba(39,67,198,.25)]"
            >
              <SquarePen size={17} strokeWidth={1.8} />
              گفتگوی تازه
            </button>
            <div className="text-text-faint px-1 text-xs font-extrabold tracking-[.02em]">
              همهٔ گفتگوها
            </div>
            {loadingHistory ? (
              <div className="text-text-faint px-1 text-xs font-semibold">در حال بارگذاری…</div>
            ) : sessions.length === 0 ? (
              <div className="text-text-faint px-1 text-xs leading-[1.9] font-semibold">
                هنوز گفتگویی ثبت نشده است.
              </div>
            ) : (
              <div className="flex flex-col gap-[3px]">
                {sessions.map((session) => {
                  const active = session.session_id === sessionId;
                  return (
                    <div
                      key={session.session_id}
                      className={`group flex min-h-12 items-center gap-1 rounded-[13px] pl-1.5 transition-colors ${
                        active ? "bg-[#F1EEE6]" : "bg-transparent hover:bg-[#F1EEE6]/60"
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => openConversation(session)}
                        className="flex min-w-0 flex-1 cursor-pointer items-center gap-3 rounded-[13px] px-3 py-[13px] text-right"
                      >
                        <MessageCircle
                          size={19}
                          strokeWidth={1.7}
                          className={active ? "text-primary flex-none" : "text-text-faint flex-none"}
                        />
                        <span
                          className={`flex-1 truncate text-sm ${
                            active ? "text-foreground font-extrabold" : "text-muted-foreground font-semibold"
                          }`}
                        >
                          {session.preview ?? "گفتگوی بدون پیام"}
                        </span>
                      </button>
                      <button
                        type="button"
                        aria-label="حذف گفتگو"
                        onClick={() => setDeleteTarget(session)}
                        className="text-text-faint hover:bg-danger-tint hover:text-destructive grid size-8 flex-none cursor-pointer place-items-center rounded-lg transition-colors"
                      >
                        <Trash2 size={16} strokeWidth={1.8} />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {deleteTarget && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center px-6" dir="rtl">
          <div
            onClick={() => !deletingSession && setDeleteTarget(null)}
            className="animate-fm-fade absolute inset-0 bg-[rgba(30,26,20,.42)]"
          />
          <div className="animate-fm-in border-border bg-card relative flex w-full max-w-[360px] flex-col items-center gap-4 rounded-[22px] border p-7 text-center shadow-[0_12px_40px_rgba(40,30,10,.18)]">
            <span className="bg-danger-tint text-destructive grid size-14 place-items-center rounded-full">
              <Trash2 size={24} strokeWidth={2} />
            </span>
            <div className="flex flex-col gap-2">
              <div className="text-[16px] font-extrabold">حذف گفتگو</div>
              <p className="text-muted-foreground text-[13px] leading-[1.95]">
                این گفتگو برای همیشه پاک می‌شود. این کار غیرقابل بازگشت است.
              </p>
            </div>
            <div className="mt-1 flex w-full flex-col gap-2.5">
              <button
                type="button"
                onClick={confirmDeleteSession}
                disabled={deletingSession}
                className="bg-destructive flex min-h-11 cursor-pointer items-center justify-center gap-2.5 rounded-2xl p-3.5 text-[14px] font-extrabold text-white transition-opacity disabled:cursor-not-allowed disabled:opacity-75"
              >
                {deletingSession && <Spinner />}
                {deletingSession ? "در حال حذف…" : "حذف گفتگو"}
              </button>
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                disabled={deletingSession}
                className="border-border text-muted-foreground min-h-11 cursor-pointer rounded-2xl border-[1.5px] bg-white p-3.5 text-[13.5px] font-bold disabled:cursor-not-allowed disabled:opacity-60"
              >
                انصراف
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
