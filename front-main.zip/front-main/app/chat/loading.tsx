import { Sk } from "@/components/ui/skeleton";

// Chat renders its own greeting/typing states once mounted; this is just the
// instant shell so tapping گفتگو swaps the screen with no wait on the old page.
export default function ChatLoading() {
  return (
    <main className="mx-auto flex h-dvh w-full max-w-[560px] flex-col">
      <div className="flex flex-none items-center gap-2.5 px-[18px] py-3">
        <Sk className="size-[42px] rounded-xl" />
        <Sk className="h-4 w-28" />
      </div>

      <div className="flex flex-1 flex-col gap-4 px-7 pt-4">
        <Sk className="h-16 w-[75%] self-start rounded-2xl" />
        <Sk className="h-12 w-[55%] self-end rounded-2xl" />
        <Sk className="h-20 w-[80%] self-start rounded-2xl" />
      </div>

      <div className="flex flex-none items-center gap-2 border-t border-border px-7 pt-3.5 pb-6">
        <Sk className="size-12 flex-none rounded-full" />
        <Sk className="h-12 flex-1 rounded-full" />
      </div>
    </main>
  );
}
