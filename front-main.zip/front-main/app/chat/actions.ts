"use server";

import { ApiError } from "@/lib/api/client";
import {
  acceptChatAction,
  bookmarkMessage,
  createChatSession,
  deleteChatSession,
  getChatSessionMessages,
  listChatSessions,
  removeMessageBookmark,
  removeMessageFeedback,
  submitMessageFeedback,
} from "@/lib/api/endpoints";
import type {
  ActionStep,
  ChatEntrySource,
  ChatSession,
  ChatSessionMessage,
  ChatSessionSummary,
} from "@/lib/api/schemas";

type ActionResult<T> = { ok: true; data: T } | { ok: false; message: string };

const GENERIC_ERROR = "خطای غیرمنتظره‌ای رخ داد. لطفاً دوباره تلاش کنید.";

function toResult<T>(fn: () => Promise<T>) {
  return fn()
    .then((data): ActionResult<T> => ({ ok: true, data }))
    .catch((error): ActionResult<T> => ({
      ok: false,
      message: error instanceof ApiError ? error.message : GENERIC_ERROR,
    }));
}

export async function createChatSessionAction(
  entrySource: ChatEntrySource,
  attemptId?: number,
  actionStepId?: string,
  index?: number,
): Promise<ActionResult<ChatSession>> {
  return toResult(() =>
    createChatSession({
      entry_source: entrySource, attempt_id: attemptId, action_step_id: actionStepId, index,
    }),
  );
}

export async function acceptChatActionAction(messageId: number): Promise<ActionResult<ActionStep>> {
  return toResult(() => acceptChatAction(messageId));
}

export async function listChatSessionsAction(): Promise<ActionResult<ChatSessionSummary[]>> {
  return toResult(() => listChatSessions());
}

export async function getChatSessionMessagesAction(
  sessionId: string,
): Promise<ActionResult<ChatSessionMessage[]>> {
  return toResult(() => getChatSessionMessages(sessionId));
}

export async function deleteChatSessionAction(sessionId: string): Promise<ActionResult<null>> {
  return toResult(() => deleteChatSession(sessionId).then(() => null));
}

export async function submitMessageFeedbackAction(
  messageId: number,
  isUseful: boolean,
): Promise<ActionResult<null>> {
  return toResult(() => submitMessageFeedback(messageId, { is_useful: isUseful }).then(() => null));
}

export async function removeMessageFeedbackAction(messageId: number): Promise<ActionResult<null>> {
  return toResult(() => removeMessageFeedback(messageId).then(() => null));
}

export async function bookmarkMessageAction(messageId: number): Promise<ActionResult<null>> {
  return toResult(() => bookmarkMessage(messageId).then(() => null));
}

export async function removeMessageBookmarkAction(messageId: number): Promise<ActionResult<null>> {
  return toResult(() => removeMessageBookmark(messageId).then(() => null));
}
