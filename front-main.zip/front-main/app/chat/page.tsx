import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { ACCESS_TOKEN_COOKIE } from "@/lib/api/constants";
import { getProfile, getReport } from "@/lib/api/endpoints";
import { isReportV2, isReportV3 } from "@/lib/utils/report";
import { chatEntrySourceSchema } from "@/lib/api/schemas";
import { ChatView } from "./_components/chat-view";
import { WorkspaceFrame } from "@/components/workspace/frame";
import { getWorkspaceData, getCanonicalContext } from "@/lib/workspace/data";

const DEEP_FOCUS_TITLES: Record<string, string> = {
  strengths: "نقطه‌های قوت",
  blind_spots: "نقطه‌های کور",
  patterns: "الگوهای رفتاری",
  domain_N: "ثبات هیجانی",
  domain_E: "برون‌گرایی",
  domain_O: "گشودگی",
  domain_A: "همراهی",
  domain_C: "وظیفه‌شناسی",
  decision_style: "سبک تصمیم‌گیری",
  communication_style: "سبک ارتباطی",
  work_style: "سبک کاری",
  stress_and_energy: "استرس و انرژی",
  close_relationships: "رابطه‌های نزدیک",
  learning_and_growth: "یادگیری و رشد",
  decisions: "سبک تصمیم‌گیری",
  communication: "سبک ارتباطی",
  work: "سبک کاری",
  stress_energy: "استرس و انرژی",
  relationships: "رابطه‌های نزدیک",
  growth: "مسیر رشد",
};

type ChatPageProps = {
  searchParams: Promise<{
    entry_source?: string;
    attempt_id?: string;
    action_step_id?: string;
    index?: string;
    session_id?: string;
    section?: string;
    from?: string;
    initial_message?: string;
    intent?: string;
    fresh?: string;
  }>;
};

export default async function ChatPage({ searchParams }: ChatPageProps) {
  const query = await searchParams;
  const store = await cookies();
  if (!store.has(ACCESS_TOKEN_COOKIE)) {
    const nextQuery = new URLSearchParams();
    const allowed = [
      "entry_source",
      "attempt_id",
      "action_step_id",
      "index",
      "session_id",
      "section",
      "from",
      "initial_message",
      "intent",
      "fresh",
    ] as const;
    for (const key of allowed) {
      const value = query[key];
      if (typeof value === "string") nextQuery.set(key, value.slice(0, 2000));
    }
    const next = `/chat${nextQuery.size ? `?${nextQuery}` : ""}`;
    redirect(`/login?${new URLSearchParams({ next }).toString()}`);
  }

  const {
    entry_source,
    attempt_id,
    action_step_id,
    index,
    session_id,
    section,
    from,
    initial_message,
    intent,
    fresh,
  } = query;
  const parsedEntrySource = chatEntrySourceSchema.safeParse(entry_source);
  const initialEntrySource = parsedEntrySource.success ? parsedEntrySource.data : "manual";
  const initialAttemptId = attempt_id ? Number(attempt_id) : undefined;
  const initialIndex = index ? Number(index) : undefined;
  const initialFrom =
    from &&
    from.startsWith("/") &&
    !from.startsWith("//") &&
    !from.includes(String.fromCharCode(92))
      ? from
      : undefined;

  const trimmedMessage = initial_message?.trim().slice(0, 2000);
  let synthesizedReportMessage: string | undefined;
  if (!session_id && !trimmedMessage) {
    if (initialEntrySource === "report_goal" && initialAttemptId) {
      synthesizedReportMessage = await getReport(initialAttemptId)
        .then((result) =>
          isReportV3(result) && result.stage === "full"
            ? `می‌خواهم «${result.report.goal_card.title}» را روی موقعیت الانم بررسی کنم.`
            : undefined,
        )
        .catch(() => undefined);
    } else if (
      (initialEntrySource === "report_finding_focus:0" ||
        initialEntrySource === "report_finding_focus:1") &&
      initialAttemptId
    ) {
      const findingIndex = Number(initialEntrySource.split(":")[1]);
      synthesizedReportMessage = await getReport(initialAttemptId)
        .then((result) => {
          if ((isReportV3(result) || isReportV2(result)) && result.stage === "full") {
            const title = result.report.findings[findingIndex]?.title;
            return title ? `می‌خواهم درباره‌ی «${title}» بیشتر حرف بزنم.` : undefined;
          }
          return undefined;
        })
        .catch(() => undefined);
    } else if (initialEntrySource.startsWith("deep_report_focus:")) {
      const focusKey = initialEntrySource.slice("deep_report_focus:".length);
      const sectionLabel = section?.trim() || DEEP_FOCUS_TITLES[focusKey];
      if (sectionLabel) {
        synthesizedReportMessage = `می‌خواهم درباره‌ی بخش «${sectionLabel}» گزارشم صحبت کنم.`;
      }
    } else if (initialEntrySource === "deep_report_cta" && section?.trim()) {
      synthesizedReportMessage = `می‌خواهم درباره‌ی بخش «${section.trim()}» گزارشم صحبت کنم.`;
    }
  }

  const initialMessage = !session_id ? trimmedMessage || synthesizedReportMessage : undefined;
  const isNextStepIntent = intent === "next_step";

  const greetName = await getProfile()
    .then((profile) => profile.name)
    .catch(() => null);

  const openQuestion =
    parsedEntrySource.success &&
    parsedEntrySource.data === "report_open_question" &&
    initialAttemptId
      ? await getReport(initialAttemptId)
          .then((result) =>
            isReportV2(result) && result.stage === "full" ? result.report.open_question.text : null,
          )
          .catch(() => null)
      : null;

  const workspace = await getWorkspaceData();
  const context = await getCanonicalContext();
  const resolvedSectionTitle =
    section?.trim() ||
    (initialEntrySource.startsWith("deep_report_focus:")
      ? DEEP_FOCUS_TITLES[initialEntrySource.slice("deep_report_focus:".length)]
      : undefined);

  return (
    <WorkspaceFrame>
      <ChatView
        key={
          session_id ||
          `${initialEntrySource}:${initialAttemptId ?? ""}:${action_step_id ?? ""}:${initialIndex ?? ""}:${initialMessage ?? ""}:${fresh ?? ""}`
        }
        initialTitle={
          workspace.sessions.find((s) => s.session_id === session_id)?.preview ?? undefined
        }
        contextReport={context?.report ?? null}
        recentSession={workspace.sessions.find((s) => s.preview)}
        openQuestion={openQuestion}
        initialEntrySource={initialEntrySource}
        initialAttemptId={initialAttemptId}
        initialActionStepId={action_step_id}
        initialIndex={initialIndex}
        initialSessionId={session_id}
        initialSectionTitle={resolvedSectionTitle}
        initialFrom={initialFrom}
        initialMessage={initialMessage}
        isNextStepIntent={isNextStepIntent}
        greetName={greetName}
      />
    </WorkspaceFrame>
  );
}
