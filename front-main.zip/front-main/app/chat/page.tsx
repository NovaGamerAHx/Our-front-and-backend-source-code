import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { ACCESS_TOKEN_COOKIE } from "@/lib/api/constants";
import { getProfile, getReport } from "@/lib/api/endpoints";
import { isReportV2, isReportV3 } from "@/lib/utils/report";
import { chatEntrySourceSchema } from "@/lib/api/schemas";
import { ChatView } from "./_components/chat-view";
import { WorkspaceFrame } from "@/components/workspace/frame";
import { getWorkspaceData, getCanonicalContext } from "@/lib/workspace/data";

type ChatPageProps = {
  searchParams: Promise<{
    entry_source?: string;
    attempt_id?: string;
    action_step_id?: string;
    index?: string;
    session_id?: string;
    section?: string;
    from?: string;
    initial_message?: string;
    intent?: string;
    fresh?: string;
  }>;
};

export default async function ChatPage({ searchParams }: ChatPageProps) {
  const query = await searchParams;
  const store = await cookies();
  if (!store.has(ACCESS_TOKEN_COOKIE)) {
    const nextQuery = new URLSearchParams();
    const allowed = [
      "entry_source",
      "attempt_id",
      "action_step_id",
      "index",
      "session_id",
      "section",
      "from",
      "initial_message",
      "intent",
      "fresh",
    ] as const;
    for (const key of allowed) {
      const value = query[key];
      if (typeof value === "string") nextQuery.set(key, value.slice(0, 2000));
    }
    const next = `/chat${nextQuery.size ? `?${nextQuery}` : ""}`;
    redirect(`/login?${new URLSearchParams({ next }).toString()}`);
  }

  const {
    entry_source,
    attempt_id,
    action_step_id,
    index,
    session_id,
    section,
    from,
    initial_message,
    intent,
    fresh,
  } = query;
  const parsedEntrySource = chatEntrySourceSchema.safeParse(entry_source);
  const initialEntrySource = parsedEntrySource.success ? parsedEntrySource.data : "manual";
  const initialAttemptId = attempt_id ? Number(attempt_id) : undefined;
  // Only meaningful alongside action_rejected + attempt_id, without action_step_id -- a report
  // suggested_step rejected before it was ever accepted (action_step.md §3).
  const initialIndex = index ? Number(index) : undefined;
  // Only accept an in-app path -- same guard as /terms' `from`, keeps this from ever bouncing
  // the user off to an attacker-controlled URL.
  const initialFrom =
    from &&
    from.startsWith("/") &&
    !from.startsWith("//") &&
    !from.includes(String.fromCharCode(92))
      ? from
      : undefined;
  // Only auto-send on a fresh chat (no session to resume) -- resuming a session and replaying a
  // message on top of it would double-post. Trimmed and length-capped so a hand-edited URL can't
  // shove an essay straight into the model.
  const trimmedMessage = initial_message?.trim().slice(0, 2000);
  const goalMessage =
    initialEntrySource === "report_goal" && initialAttemptId && !session_id && !trimmedMessage
      ? await getReport(initialAttemptId)
          .then((result) =>
            isReportV3(result) && result.stage === "full"
              ? `می‌خواهم «${result.report.goal_card.title}» را روی موقعیت الانم بررسی کنم.`
              : undefined,
          )
          .catch(() => undefined)
      : undefined;
  const initialMessage = !session_id ? trimmedMessage || goalMessage : undefined;
  // Dashboard's "گفت‌وگو با فرامن" card only -- distinguishes it from the top nav's plain
  // "گفت‌وگو" link, which lands on the same entry_source/from and must keep the normal
  // chatEmpty screen (greeting + suggested prompts).
  const isNextStepIntent = intent === "next_step";

  // Best-effort only -- the empty-state greeting falls back to a generic "دوست من" on failure,
  // so a name-fetch hiccup shouldn't block the chat screen the way an auth failure should.
  const greetName = await getProfile()
    .then((profile) => profile.name)
    .catch(() => null);

  // report_open_question: the question is read from the report itself (never from the URL), and
  // shown as display-only text on the empty chat screen. Best-effort -- without it the screen
  // simply falls back to the plain greeting.
  const openQuestion =
    parsedEntrySource.success &&
    parsedEntrySource.data === "report_open_question" &&
    initialAttemptId
      ? await getReport(initialAttemptId)
          .then((result) =>
            isReportV2(result) && result.stage === "full" ? result.report.open_question.text : null,
          )
          .catch(() => null)
      : null;

  const workspace = await getWorkspaceData();
  const context = await getCanonicalContext();
  return (
    <WorkspaceFrame>
      <ChatView
        key={
          session_id ||
          `${initialEntrySource}:${initialAttemptId ?? ""}:${action_step_id ?? ""}:${initialIndex ?? ""}:${initialMessage ?? ""}:${fresh ?? ""}`
        }
        initialTitle={
          workspace.sessions.find((s) => s.session_id === session_id)?.preview ?? undefined
        }
        contextReport={context?.report ?? null}
        recentSession={workspace.sessions.find((s) => s.preview)}
        openQuestion={openQuestion}
        initialEntrySource={initialEntrySource}
        initialAttemptId={initialAttemptId}
        initialActionStepId={action_step_id}
        initialIndex={initialIndex}
        initialSessionId={session_id}
        initialSectionTitle={section}
        initialFrom={initialFrom}
        initialMessage={initialMessage}
        isNextStepIntent={isNextStepIntent}
        greetName={greetName}
      />
    </WorkspaceFrame>
  );
}
