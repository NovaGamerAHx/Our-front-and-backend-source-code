import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { ACCESS_TOKEN_COOKIE } from "@/lib/api/constants";
import { ApiError } from "@/lib/api/client";
import { getReportAttemptsHistory } from "@/lib/api/endpoints";
import { ReportUnavailable } from "@/components/report/report-unavailable";
import { HistoryView } from "./_components/history-view";

export default async function HistoryPage() {
  const store = await cookies();
  if (!store.has(ACCESS_TOKEN_COOKIE)) {
    redirect(`/login?${new URLSearchParams({ next: "/history" }).toString()}`);
  }

  let items;
  try {
    items = await getReportAttemptsHistory();
  } catch (error) {
    if (error instanceof ApiError && error.status === 401) {
      redirect(`/login?${new URLSearchParams({ next: "/history" }).toString()}`);
    }
    const message = error instanceof ApiError ? error.message : "تاریخچهٔ تلاش‌ها در دسترس نیست.";
    return <ReportUnavailable message={message} />;
  }

  return <HistoryView items={items} />;
}
