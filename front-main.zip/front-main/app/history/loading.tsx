import { Sk } from "@/components/ui/skeleton";

// Instant fallback for the گزارش‌ها history list while report history is fetched.
export default function HistoryLoading() {
  return (
    <main className="mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col gap-6 px-7 pt-6 pb-14">
      <div className="flex items-center gap-3">
        <Sk className="size-10 rounded-xl" />
        <Sk className="h-4 w-28" />
      </div>

      <div className="flex flex-col gap-1.5">
        <Sk className="h-6 w-40" />
        <Sk className="h-4 w-full max-w-[360px]" />
      </div>

      <div className="flex flex-col gap-2.5">
        {[0, 1, 2].map((i) => (
          <Sk key={i} className="h-[86px] w-full rounded-2xl" />
        ))}
      </div>
    </main>
  );
}
