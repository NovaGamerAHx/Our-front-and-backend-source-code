import Link from "next/link";
import { AlertCircle, ChevronLeft, FileText, Loader2, RefreshCw } from "lucide-react";
import { formatJalali } from "@/lib/utils/date";
import type { ReportAttemptHistoryItem } from "@/lib/api/schemas";

function reportTypeLabel(item: ReportAttemptHistoryItem): string {
  return item.report_type === "deep" ? "آزمون تکمیلی" : "آزمون خودشناسی";
}

function OkRow({ item, isCurrent }: { item: ReportAttemptHistoryItem; isCurrent: boolean }) {
  return (
    <Link
      href={
        item.report_type === "deep"
          ? `/deep-report?attemptId=${item.attempt_id}`
          : `/report?attemptId=${item.attempt_id}`
      }
      className={`shadow-card flex items-center gap-3.5 rounded-2xl p-[18px] ${
        isCurrent
          ? "border-[1.5px] border-[#C7CEF0] bg-white"
          : "border border-[#DDDAD3] bg-[#E9E7E2]"
      }`}
    >
      <div
        className={`grid size-[42px] flex-none place-items-center rounded-2xl ${
          isCurrent ? "bg-secondary" : "bg-border"
        }`}
      >
        <FileText
          size={19}
          strokeWidth={1.8}
          className={isCurrent ? "text-primary" : "text-text-faint"}
        />
      </div>
      <div className="flex flex-1 flex-col gap-1">
        <div className="flex flex-wrap items-center gap-2">
          <div className="text-text-faint text-[11.5px]">{formatJalali(item.completed_at)}</div>
          <div className="text-text-faint text-[11px]">· {reportTypeLabel(item)}</div>
          {isCurrent && (
            <div className="bg-secondary text-primary rounded-full px-2.5 py-0.5 text-[10px] font-extrabold">
              فعلی
            </div>
          )}
        </div>
        <div className="text-[13px] leading-[1.75] font-bold">{item.summary_one_line}</div>
      </div>
      <ChevronLeft size={18} strokeWidth={2.5} className="text-muted-foreground flex-none" />
    </Link>
  );
}

function GeneratingRow({ item }: { item: ReportAttemptHistoryItem }) {
  return (
    <Link
      href={`/test/analysis?attemptId=${item.attempt_id}`}
      className="border-border shadow-card flex items-center gap-3.5 rounded-2xl border bg-white p-[18px]"
    >
      <div className="bg-muted grid size-[42px] flex-none place-items-center rounded-2xl">
        <Loader2 size={19} strokeWidth={1.8} className="text-muted-foreground animate-spin" />
      </div>
      <div className="flex flex-1 flex-col gap-1">
        <div className="flex flex-wrap items-center gap-2">
          <div className="text-text-faint text-[11.5px]">{formatJalali(item.completed_at)}</div>
          <div className="text-text-faint text-[11px]">· {reportTypeLabel(item)}</div>
        </div>
        <div className="text-[13px] leading-[1.75] font-bold">در حال ساخته شدن است…</div>
      </div>
      <ChevronLeft size={18} strokeWidth={2.5} className="text-muted-foreground flex-none" />
    </Link>
  );
}

function AwaitingPaymentRow({ item }: { item: ReportAttemptHistoryItem }) {
  return (
    <Link
      href={`/deep-report?attemptId=${item.attempt_id}`}
      className="border-border shadow-card flex items-center gap-3.5 rounded-2xl border bg-white p-[18px]"
    >
      <div className="bg-secondary grid size-[42px] flex-none place-items-center rounded-2xl">
        <FileText size={19} strokeWidth={1.8} className="text-primary" />
      </div>
      <div className="flex flex-1 flex-col gap-1">
        <div className="flex flex-wrap items-center gap-2">
          <div className="text-text-faint text-[11.5px]">{formatJalali(item.completed_at)}</div>
          <div className="text-text-faint text-[11px]">· {reportTypeLabel(item)}</div>
        </div>
        <div className="text-[13px] leading-[1.75] font-bold">گزارشت آمادهٔ باز شدن است</div>
      </div>
      <ChevronLeft size={18} strokeWidth={2.5} className="text-muted-foreground flex-none" />
    </Link>
  );
}

function ErrorRow({ item }: { item: ReportAttemptHistoryItem }) {
  return (
    <div className="border-danger-border bg-danger-tint flex items-center gap-3.5 rounded-2xl border p-[18px]">
      <div className="grid size-[42px] flex-none place-items-center rounded-2xl bg-white">
        <AlertCircle size={19} strokeWidth={1.8} className="text-danger-text" />
      </div>
      <div className="flex flex-1 flex-col gap-1">
        <div className="flex flex-wrap items-center gap-2">
          <div className="text-danger-text/70 text-[11.5px]">{formatJalali(item.completed_at)}</div>
          <div className="text-danger-text/70 text-[11px]">· {reportTypeLabel(item)}</div>
        </div>
        <div className="text-danger-text text-[13px] leading-[1.75] font-bold">
          ساخت گزارش این تلاش با مشکل مواجه شد
        </div>
        <p className="text-danger-text/80 text-[12px] leading-[1.8]">
          نگران نباشید — پاسخ‌هایتان محفوظ است و لازم نیست آزمون را دوباره بدهید.
        </p>
      </div>
      <Link
        href={`/test/analysis?attemptId=${item.attempt_id}&retry=1`}
        className="bg-destructive flex min-h-9 flex-none items-center gap-1.5 rounded-xl px-3.5 text-[12.5px] font-extrabold text-white"
      >
        <RefreshCw size={14} strokeWidth={2.2} />
        تلاش دوباره
      </Link>
    </div>
  );
}

export function HistoryView({ items }: { items: ReportAttemptHistoryItem[] }) {
  const firstOkIndex = items.findIndex((item) => item.status === "ok");

  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[560px] flex-col gap-6 px-7 pt-6 pb-14">
      <div className="flex items-center gap-3">
        <Link
          href="/dashboard"
          className="border-border text-muted-foreground bg-card grid size-10 place-items-center rounded-xl border text-base"
        >
          →
        </Link>
        <div className="text-text-faint text-[13px] font-bold">تاریخچهٔ تلاش‌ها</div>
      </div>

      <div className="flex flex-col gap-1.5">
        <h1 className="text-[23px] font-extrabold">تلاش‌های شما</h1>
        <p className="text-text-faint text-[13px] leading-[1.9]">
          هر بار که آزمونی را تمام می‌کنید، یک تلاش تازه این‌جا ثبت می‌شود — جدیدترین بالاست. اگر
          ساخت گزارشی با مشکل مواجه شود، بدون نیاز به دادن دوبارهٔ آزمون، از همین‌جا می‌توانید
          دوباره تلاش کنید.
        </p>
      </div>

      {items.length > 0 ? (
        <div className="flex flex-col gap-2.5">
          {items.map((item, index) => {
            if (item.status === "error") return <ErrorRow key={item.attempt_id} item={item} />;
            if (item.status === "generating")
              return <GeneratingRow key={item.attempt_id} item={item} />;
            if (item.status === "awaiting_payment")
              return <AwaitingPaymentRow key={item.attempt_id} item={item} />;
            return <OkRow key={item.attempt_id} item={item} isCurrent={index === firstOkIndex} />;
          })}
        </div>
      ) : (
        <div className="shadow-card border-border bg-card flex flex-col items-center gap-3 rounded-2xl border p-8 text-center">
          <div className="bg-muted grid size-11 place-items-center rounded-2xl">
            <FileText size={19} strokeWidth={1.8} className="text-text-faint" />
          </div>
          <p className="text-muted-foreground text-[13px] leading-[1.9]">
            هنوز تلاشی ندارید. با انجام آزمون، اولین تلاش‌تان این‌جا ثبت می‌شود.
          </p>
          <Link
            href="/test"
            className="bg-primary hover:bg-primary/90 min-h-11 rounded-2xl px-6 py-3 text-[13.5px] font-extrabold text-white"
          >
            شروع آزمون
          </Link>
        </div>
      )}
    </main>
  );
}
