import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { ACCESS_TOKEN_COOKIE, DEEP_ASSESSMENT_SLUG } from "@/lib/api/constants";
import { getProductPrices, getReport } from "@/lib/api/endpoints";
import { sanitizeSource } from "@/lib/analytics/source";
import { computePaywallPricing, paywallDiscountPercent } from "@/lib/utils/price";
import { sanitizeCoupon } from "@/lib/constants/short-links";
import { PaywallView } from "./_components/paywall-view";
import { WorkspaceFrame } from "@/components/workspace/frame";

type PaywallPageProps = {
  searchParams: Promise<{ deepAttemptId?: string; source?: string; coupon?: string }>;
};

/** One deep-test intro at /deep-test; this route only renders the post-test payment gate. */
export default async function PaywallPage({ searchParams }: PaywallPageProps) {
  const { deepAttemptId: rawDeep, source: rawSource, coupon: rawCoupon } = await searchParams;
  const deepAttemptId = rawDeep ? Number(rawDeep) : NaN;
  // Pre-filled coupon from a short link (/go/pay?coupon=...): shown in the promo box for the
  // visitor to confirm, never auto-applied. Malformed/absent means no pre-fill.
  const initialCoupon = sanitizeCoupon(rawCoupon);
  const store = await cookies();

  if (!Number.isInteger(deepAttemptId) || deepAttemptId <= 0) {
    redirect(`/deep-test?source=${encodeURIComponent(sanitizeSource(rawSource))}`);
  }

  if (!store.has(ACCESS_TOKEN_COOKIE)) {
    const nextParams = new URLSearchParams({ deepAttemptId: String(deepAttemptId) });
    if (initialCoupon) nextParams.set("coupon", initialCoupon);
    const next = `/paywall?${nextParams.toString()}`;
    redirect(`/login?${new URLSearchParams({ next }).toString()}`);
  }

  // Anything but awaiting_payment is not this screen's job: generating/ok/error all belong to
  // /deep-report (which polls, renders, or offers a retry). A failed lookup (not the owner,
  // no such attempt) also falls through to /deep-report, which shows the real error.
  const report = await getReport(deepAttemptId).catch(() => null);
  if (report === null || report.status !== "awaiting_payment") {
    redirect(`/deep-report?attemptId=${deepAttemptId}`);
  }

  const products = await getProductPrices().catch(() => null);
  const deepProduct = products?.find((p) => p.assessment_slug === DEEP_ASSESSMENT_SLUG);
  const pricing =
    deepProduct !== undefined
      ? computePaywallPricing(deepProduct.price, paywallDiscountPercent())
      : { price: "دریافت قیمت ممکن نشد", oldPrice: null, discountBadge: null };

  return (
    <WorkspaceFrame payment>
      <PaywallView
        deepAttemptId={deepAttemptId}
        pricing={pricing}
        teaser={report.teaser ?? null}
        priceAvailable={deepProduct !== undefined}
        initialCoupon={initialCoupon}
      />
    </WorkspaceFrame>
  );
}
