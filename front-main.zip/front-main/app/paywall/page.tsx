import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { ACCESS_TOKEN_COOKIE, DEEP_ASSESSMENT_SLUG } from "@/lib/api/constants";
import { getProductPrices, getReport, getReportAttemptsHistory } from "@/lib/api/endpoints";
import { sanitizeSource } from "@/lib/analytics/source";
import {
  computePaywallPricing,
  paywallDiscountPercent,
  type PaywallPricing,
} from "@/lib/utils/price";
import { DeepEntryView } from "./_components/deep-entry-view";
import { PaywallView } from "./_components/paywall-view";

// Shown only if the price call fails or the deep product has no price -- the real price comes
// from the backend (Product.price, Toman) in the normal path. Goes through the same discount
// math so the struck-through old price and badge still show.
const FALLBACK_PRICE_TOMAN = 199_000;

function fallbackPricing(): PaywallPricing {
  return computePaywallPricing(FALLBACK_PRICE_TOMAN, paywallDiscountPercent());
}

type PaywallPageProps = {
  searchParams: Promise<{ deepAttemptId?: string; source?: string }>;
};

/**
 * Two screens share this route (as in design handoff v34, where "Paywall" is the deep test's
 * entry page and "Deep Pay" the payment screen):
 *  - no `deepAttemptId`: the entry page that leads into the (free) deep test;
 *  - with `deepAttemptId`: pay-after-test -- the gate between finishing the test and opening
 *    that attempt's report.
 */
export default async function PaywallPage({ searchParams }: PaywallPageProps) {
  const { deepAttemptId: rawDeep, source: rawSource } = await searchParams;
  const deepAttemptId = rawDeep ? Number(rawDeep) : NaN;
  const store = await cookies();

  if (!Number.isInteger(deepAttemptId) || deepAttemptId <= 0) {
    // Public like the free-test intro; the login wall is /deep-test's. The history lookup only
    // powers the "your last deep report" shortcut, so it never blocks the page.
    let lastDeepReport: { attemptId: number; completedAt: string } | null = null;
    if (store.has(ACCESS_TOKEN_COOKIE)) {
      const history = await getReportAttemptsHistory().catch(() => []);
      const latest = history.find((item) => item.report_type === "deep" && item.status === "ok");
      if (latest)
        lastDeepReport = { attemptId: latest.attempt_id, completedAt: latest.completed_at };
    }
    return <DeepEntryView source={sanitizeSource(rawSource)} lastDeepReport={lastDeepReport} />;
  }

  if (!store.has(ACCESS_TOKEN_COOKIE)) {
    const next = `/paywall?deepAttemptId=${deepAttemptId}`;
    redirect(`/login?${new URLSearchParams({ next }).toString()}`);
  }

  // Anything but awaiting_payment is not this screen's job: generating/ok/error all belong to
  // /deep-report (which polls, renders, or offers a retry). A failed lookup (not the owner,
  // no such attempt) also falls through to /deep-report, which shows the real error.
  const report = await getReport(deepAttemptId).catch(() => null);
  if (report === null || report.status !== "awaiting_payment") {
    redirect(`/deep-report?attemptId=${deepAttemptId}`);
  }

  const products = await getProductPrices().catch(() => null);
  const deepProduct = products?.find((p) => p.assessment_slug === DEEP_ASSESSMENT_SLUG);
  const pricing =
    deepProduct !== undefined
      ? computePaywallPricing(deepProduct.price, paywallDiscountPercent())
      : fallbackPricing();

  return <PaywallView deepAttemptId={deepAttemptId} pricing={pricing} />;
}
