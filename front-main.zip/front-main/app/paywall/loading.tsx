import { Sk } from "@/components/ui/skeleton";

// Instant fallback for گزارش کامل while paywall/page.tsx resolves entitlements +
// report history (+ deep attempt progress).
export default function PaywallLoading() {
  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-[560px] flex-col gap-7 px-7 pt-7 pb-12">
      <div className="flex items-center gap-3">
        <Sk className="size-10 rounded-xl" />
        <Sk className="h-4 w-24" />
      </div>

      <div className="flex flex-col gap-3.5">
        <Sk className="size-[52px] rounded-[18px]" />
        <Sk className="h-6 w-52" />
        <Sk className="h-4 w-40" />
      </div>

      <div className="flex flex-col gap-3">
        {[0, 1, 2, 3].map((i) => (
          <Sk key={i} className="h-14 w-full rounded-xl" />
        ))}
      </div>

      <Sk className="h-[150px] w-full rounded-[20px]" />
    </main>
  );
}
