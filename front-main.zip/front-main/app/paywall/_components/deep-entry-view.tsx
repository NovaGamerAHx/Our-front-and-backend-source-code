"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  BarChart3,
  Compass,
  FileText,
  Heart,
  Layers,
  MessageCircle,
  MessagesSquare,
  Sparkles,
  Sprout,
  Users,
} from "lucide-react";
import { TrackOnMount } from "@/components/analytics/track-on-mount";
import { formatJalali } from "@/lib/utils/date";
import { toPersianDigits } from "@/lib/utils/digits";

const FEATURE_COLUMNS = [
  {
    icon: BarChart3,
    title: "شناخت چندبعدی",
    desc: "بررسی جنبه‌های مختلف شخصیت و سبک زندگی",
    tile: "bg-[#E9EBF8] text-[#5B6FD6]",
  },
  {
    icon: Users,
    title: "الگوهای رفتاری",
    desc: "درک بهتر سبک تصمیم‌گیری، ارتباطات و واکنش‌ها",
    tile: "bg-[#FBEBDD] text-[#C47A45]",
  },
  {
    icon: Sprout,
    title: "نقاط قوت و نقاط کور",
    desc: "شناخت توانمندی‌ها و فرصت‌های رشد",
    tile: "bg-[#E9EBF8] text-[#5B6FD6]",
  },
];

const REPORT_TOPICS = [
  { icon: Sparkles, label: "ویژگی‌های شخصیتی", row: "bg-[#F1EDFA]", chip: "text-[#8E6BA8]" },
  { icon: MessagesSquare, label: "سبک ارتباطی", row: "bg-[#EEF4FB]", chip: "text-[#4E9BD6]" },
  { icon: Compass, label: "سبک تصمیم‌گیری", row: "bg-[#FCF1E4]", chip: "text-[#E8A15C]" },
  { icon: Heart, label: "مدیریت احساسات", row: "bg-[#FCEDEA]", chip: "text-[#E06A55]" },
  { icon: Sprout, label: "سبک زندگی", row: "bg-[#EEF6EF]", chip: "text-[#5FA26F]" },
];

const CHAT_PREVIEW = [
  { from: "faraman", text: "دوست داری دربارهٔ کدام بخش از گزارش بیشتر صحبت کنیم؟" },
  { from: "user", text: "چرا در موقعیت‌های استرس‌زا تصمیم‌گیری‌ام تغییر می‌کند؟" },
  {
    from: "faraman",
    text: "این موضوع به سبک پردازش هیجانات و الگوی رفتاری‌ات مربوط است. بیا با هم دقیق‌تر بررسی‌اش کنیم…",
  },
] as const;

/**
 * The deep test's entry page ("Paywall" screen in design handoff v34, headed گزارش کامل in the
 * README): what the report gives you, then one CTA into the test. The test is free -- payment
 * only comes after the last question (see PaywallView) -- so this page never takes money.
 *
 * `source` is where the visitor came from; it is forwarded to /deep-test so that page's own
 * `deep_intro_viewed` event keeps attributing the visit correctly.
 */
export function DeepEntryView({
  source,
  lastDeepReport,
}: {
  source: string;
  lastDeepReport: { attemptId: number; completedAt: string } | null;
}) {
  const ctaHref = `/deep-test?source=${source}`;
  const ctaLabel = lastDeepReport ? "انجام دوبارهٔ آزمون عمیق" : "شروع آزمون عمیق";

  // Mobile-only sticky CTA: appears once the in-page CTA has scrolled up past the top.
  const ctaRef = useRef<HTMLDivElement>(null);
  const [ctaScrolledPast, setCtaScrolledPast] = useState(false);
  useEffect(() => {
    const el = ctaRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(([entry]) =>
      setCtaScrolledPast(!entry.isIntersecting && entry.boundingClientRect.bottom < 0),
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[880px] flex-col gap-[clamp(18px,3.5vw,30px)] px-[22px] pt-5 pb-[110px]">
      <TrackOnMount event="paywall_viewed" properties={{ stage: "intro", source }} />

      <div className="flex items-center gap-3">
        <Link
          href="/explore"
          aria-label="بازگشت"
          className="border-border flex size-10 flex-none items-center justify-center rounded-xl border bg-white text-base text-[#5D5C55]"
        >
          →
        </Link>
        <div className="text-[13px] font-bold text-[#A9A597]">آزمون خودشناسی عمیق</div>
      </div>

      <div className="flex flex-col items-center gap-2.5 text-center">
        <h1 className="max-w-[620px] text-[clamp(24px,5vw,40px)] leading-[1.6] font-black text-balance text-[#1E2440]">
          چیزی که از خودت شناختی، فقط شروع ماجراست.
        </h1>
        <div className="flex w-full max-w-[640px] items-center justify-center gap-[clamp(14px,3vw,28px)] pt-1">
          <div className="flex min-w-0 items-center gap-2.5 text-start">
            <span className="grid size-[34px] flex-none place-items-center rounded-full bg-[#E9EBF8] text-[#4F63D2]">
              <Layers size={16} strokeWidth={2} />
            </span>
            <div className="flex min-w-0 flex-col">
              <div className="text-[13.5px] leading-[1.7] font-extrabold text-[#242A38]">
                شناخت لایه‌های پنهان‌تر
              </div>
              <div className="text-[12px] leading-[1.75] text-pretty text-[#8C887B]">
                ویژگی‌ها، الگوهای رفتاری و سبک زندگی‌ات
              </div>
            </div>
          </div>
          <div className="w-px flex-none self-stretch bg-[#E4DFD3]" />
          <div className="flex min-w-0 items-center gap-2.5 text-start">
            <span className="grid size-[34px] flex-none place-items-center rounded-full bg-[#F3EBF6] text-[#8E6BA8]">
              <MessageCircle size={16} strokeWidth={2} />
            </span>
            <div className="flex min-w-0 flex-col">
              <div className="text-[13.5px] leading-[1.7] font-extrabold text-[#242A38]">
                گفت‌وگو با فرامن
              </div>
              <div className="text-[12px] leading-[1.75] text-pretty text-[#8C887B]">
                دربارهٔ نتیجه‌هایت، بعد از دریافت گزارش
              </div>
            </div>
          </div>
        </div>
      </div>

      <Image
        src="/deep-intro/compass.png"
        alt="آدمی با شنل قرمز روی صخره نشسته، قطب‌نما در دست، به راهی پیچان میان تپه‌ها نگاه می‌کند"
        width={1200}
        height={800}
        priority
        className="-my-1.5 block h-auto max-h-[38vh] w-full object-contain"
      />

      <div ref={ctaRef} className="mx-auto flex w-full max-w-[720px] flex-col gap-3">
        <Link
          href={ctaHref}
          className="flex min-h-14 w-full items-center justify-center gap-3 rounded-full bg-[#4F63D2] px-6 py-[18px] text-[17px] font-extrabold text-white shadow-[0_10px_26px_rgba(79,99,210,.26)] transition-transform hover:-translate-y-px active:scale-[.98]"
        >
          <span>{ctaLabel}</span>
          <span className="text-lg">←</span>
        </Link>
      </div>

      <div className="grid grid-cols-3 gap-3.5">
        {FEATURE_COLUMNS.map(({ icon: Icon, title, desc, tile }) => (
          <div key={title} className="flex flex-col items-center gap-2 text-center">
            <div className={`grid size-[60px] place-items-center rounded-full ${tile}`}>
              <Icon size={26} strokeWidth={1.9} />
            </div>
            <div className="text-[clamp(13.5px,2.4vw,16px)] leading-[1.7] font-extrabold text-[#242A38]">
              {title}
            </div>
            <div className="text-[clamp(11.5px,2vw,13px)] leading-[1.85] text-pretty text-[#8C887B]">
              {desc}
            </div>
          </div>
        ))}
      </div>

      <div className="grid gap-4 min-[620px]:grid-cols-2">
        <div className="border-border grid grid-cols-[1.1fr_1fr] items-center gap-3.5 rounded-[22px] border bg-white p-[18px] shadow-[0_8px_24px_rgba(80,70,40,.05)]">
          <div className="flex flex-col items-center gap-2.5">
            <div className="self-start text-[13px] font-extrabold text-[#1E2440]">
              گزارش جامع شخصیت
            </div>
            <svg viewBox="0 0 120 120" width="100%" style={{ maxWidth: 170, overflow: "visible" }}>
              <defs>
                <radialGradient id="entryRadarBg" cx="50%" cy="50%" r="50%">
                  <stop offset="0" stopColor="#E9EBF8" />
                  <stop offset="1" stopColor="#E9EBF8" stopOpacity="0" />
                </radialGradient>
                <linearGradient id="entryRadarFill" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0" stopColor="#9A86E0" />
                  <stop offset="1" stopColor="#5B6FD6" />
                </linearGradient>
              </defs>
              <circle cx="60" cy="60" r="58" fill="url(#entryRadarBg)" />
              <polygon
                points="60,14 103.7,45.8 87,97.2 33,97.2 16.3,45.8"
                fill="#fff"
                stroke="#E2DED3"
                strokeWidth="1"
              />
              <polygon
                points="60,29.3 89.2,50.5 78,84.8 42,84.8 30.8,50.5"
                fill="none"
                stroke="#ECE8DF"
                strokeWidth="1"
              />
              <polygon
                points="60,44.7 74.6,55.3 69,72.4 51,72.4 45.4,55.3"
                fill="none"
                stroke="#ECE8DF"
                strokeWidth="1"
              />
              <line x1="60" y1="60" x2="60" y2="14" stroke="#ECE8DF" strokeWidth="1" />
              <line x1="60" y1="60" x2="103.7" y2="45.8" stroke="#ECE8DF" strokeWidth="1" />
              <line x1="60" y1="60" x2="87" y2="97.2" stroke="#ECE8DF" strokeWidth="1" />
              <line x1="60" y1="60" x2="33" y2="97.2" stroke="#ECE8DF" strokeWidth="1" />
              <line x1="60" y1="60" x2="16.3" y2="45.8" stroke="#ECE8DF" strokeWidth="1" />
              <polygon
                points="60,18.6 95,48.6 77.6,84.2 39.7,87.9 33.8,51.5"
                fill="url(#entryRadarFill)"
                fillOpacity=".5"
                stroke="#5B6FD6"
                strokeWidth="1.8"
                strokeLinejoin="round"
              />
              <circle cx="60" cy="18.6" r="4.2" fill="#8E6BA8" stroke="#fff" strokeWidth="1.8" />
              <circle cx="95" cy="48.6" r="4.2" fill="#4E9BD6" stroke="#fff" strokeWidth="1.8" />
              <circle cx="77.6" cy="84.2" r="4.2" fill="#E8A15C" stroke="#fff" strokeWidth="1.8" />
              <circle cx="39.7" cy="87.9" r="4.2" fill="#E06A55" stroke="#fff" strokeWidth="1.8" />
              <circle cx="33.8" cy="51.5" r="4.2" fill="#5FA26F" stroke="#fff" strokeWidth="1.8" />
              <circle cx="60" cy="14" r="1.6" fill="#8E6BA8" opacity=".45" />
              <circle cx="103.7" cy="45.8" r="1.6" fill="#4E9BD6" opacity=".45" />
              <circle cx="87" cy="97.2" r="1.6" fill="#E8A15C" opacity=".45" />
              <circle cx="33" cy="97.2" r="1.6" fill="#E06A55" opacity=".45" />
              <circle cx="16.3" cy="45.8" r="1.6" fill="#5FA26F" opacity=".45" />
            </svg>
          </div>
          <div className="flex flex-col gap-[7px]">
            {REPORT_TOPICS.map(({ icon: Icon, label, row, chip }) => (
              <div
                key={label}
                className={`flex items-center gap-2.5 rounded-xl py-1.5 ps-3 pe-2 text-[12.5px] font-bold text-[#3C4150] ${row}`}
              >
                <span
                  className={`grid size-[26px] flex-none place-items-center rounded-lg bg-white shadow-[0_1px_3px_rgba(60,50,30,.08)] ${chip}`}
                >
                  <Icon size={15} strokeWidth={2} />
                </span>
                {label}
              </div>
            ))}
          </div>
        </div>

        <div className="border-border flex flex-col justify-center gap-3 rounded-[22px] border bg-white p-[18px] shadow-[0_8px_24px_rgba(80,70,40,.05)]">
          <div className="mb-0.5 flex flex-col gap-0.5 border-b border-[#F3EFE6] pb-1">
            <div className="flex items-center gap-2 text-[13px] font-extrabold text-[#1E2440]">
              <span className="size-[7px] flex-none rounded-full bg-[#5FA26F]" />
              گفت‌وگو با فرامن دربارهٔ گزارشت
            </div>
            <div className="text-[12px] leading-[1.8] text-[#8C887B]">
              بعد از دریافت گزارش، هر سؤالی دربارهٔ نتیجه‌هایت داری از فرامن بپرس.
            </div>
          </div>
          {CHAT_PREVIEW.map((message) => (
            <div
              key={message.text}
              className={`flex items-start gap-2.5 ${message.from === "user" ? "flex-row-reverse" : ""}`}
            >
              <div
                className={`grid flex-none place-items-center ${
                  message.from === "user"
                    ? "size-9 rounded-full bg-[#EFEBE2] text-[#A9A597]"
                    : "size-10 rounded-[14px] bg-[#E9EBF8] text-[#4F63D2]"
                }`}
              >
                {message.from === "user" ? <Users size={16} /> : <Sparkles size={18} />}
              </div>
              <div
                className={`px-[13px] py-2.5 text-[12.5px] leading-[1.9] ${
                  message.from === "user"
                    ? "rounded-[4px_14px_14px_14px] bg-[#F6F3EC] text-[#3C4150]"
                    : "rounded-[14px_4px_14px_14px] bg-[#EEF0FB] text-[#2D3350]"
                }`}
              >
                {message.text}
              </div>
            </div>
          ))}
        </div>
      </div>

      {lastDeepReport && (
        <div className="mx-auto flex w-full max-w-[560px] flex-col gap-[9px]">
          <div className="px-1 text-[11.5px] font-extrabold text-[#A9A597]">
            آخرین آزمون عمیقی که دادی
          </div>
          <div className="border-border overflow-hidden rounded-[18px] border bg-[#FFFDF8]">
            <Link
              href={`/deep-report?attemptId=${lastDeepReport.attemptId}`}
              className="box-border flex min-h-11 items-center gap-3 px-[17px] py-[15px]"
            >
              <div className="grid size-[34px] flex-none place-items-center rounded-[11px] bg-[#E9EBF8]">
                <FileText size={17} strokeWidth={2} className="text-primary" />
              </div>
              <div className="flex flex-1 flex-col gap-0.5">
                <div className="text-[14px] font-extrabold">دیدن نتیجهٔ آخرین آزمون عمیق</div>
                <div className="text-text-faint text-[11.5px] leading-[1.7]">
                  {toPersianDigits(formatJalali(lastDeepReport.completedAt))}
                </div>
              </div>
              <div className="flex-none text-base text-[#C9C3B4]">‹</div>
            </Link>
            {/* The deep report is the context here, so the session has to carry deep_report_cta +
                the deep attempt id -- otherwise the backend opens a blank manual chat. */}
            <Link
              href={`/chat?entry_source=deep_report_cta&attempt_id=${lastDeepReport.attemptId}&from=${encodeURIComponent("/paywall")}`}
              className="box-border flex min-h-11 items-center gap-3 border-t border-[#F3EFE6] px-[17px] py-[15px]"
            >
              <div className="grid size-[34px] flex-none place-items-center rounded-[11px] bg-[#F3EBF6]">
                <MessageCircle size={17} strokeWidth={2} className="text-purple-accent" />
              </div>
              <div className="flex flex-1 flex-col gap-0.5">
                <div className="text-[14px] font-extrabold">گفتگو دربارهٔ همین گزارش</div>
                <div className="text-text-faint text-[11.5px] leading-[1.7]">
                  سؤال‌هایت را از فرامن بپرس
                </div>
              </div>
              <div className="flex-none text-base text-[#C9C3B4]">‹</div>
            </Link>
          </div>
        </div>
      )}

      {ctaScrolledPast && (
        <div
          className="fixed inset-x-0 bottom-0 z-40 border-t border-[#EDE7DA] px-[18px] pt-3 pb-[calc(12px+env(safe-area-inset-bottom))] min-[860px]:hidden"
          style={{
            background: "rgba(251,249,244,.97)",
            boxShadow: "0 -6px 20px rgba(80,70,40,.08)",
            animation: "fmIn .25s ease",
          }}
        >
          <div className="mx-auto flex max-w-[560px]">
            <Link
              href={ctaHref}
              className="flex min-h-12 flex-1 items-center justify-center rounded-full bg-[#4F63D2] p-3.5 text-[15px] font-extrabold text-white"
            >
              {ctaLabel}
            </Link>
          </div>
        </div>
      )}
    </main>
  );
}
