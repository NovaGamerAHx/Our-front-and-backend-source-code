"use client";
import { useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Check, Lock } from "lucide-react";
import { TrackOnMount } from "@/components/analytics/track-on-mount";
import { trackEventAction } from "@/lib/api/track-event-action";
import { toastClientError } from "@/lib/analytics/client-error";
import { Spinner } from "@/components/ui/spinner";
import { LogoMark } from "@/components/site/logo-mark";
import { DeepBenefits } from "@/components/workspace/test-intro";
import type { PaywallPricing } from "@/lib/utils/price";
import { applyCouponAction, payContinueAction } from "../actions";
const PROMO_APPLIED_TRANSITION_MS = 900;
export function PaywallView({
  deepAttemptId,
  pricing,
  teaser,
  priceAvailable,
  initialCoupon = null,
}: {
  /** The finished deep attempt whose locked report this payment unlocks. */
  deepAttemptId: number;
  pricing: PaywallPricing;
  teaser: { title: string; level: string } | null;
  priceAvailable: boolean;
  /** Coupon pre-filled from a short link (?coupon=...): opens the promo box with the code
   * ready to confirm. Never auto-applied -- the visitor still clicks "اعمال". */
  initialCoupon?: string | null;
}) {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  const [promoOpen, setPromoOpen] = useState(initialCoupon !== null);
  const [promoInput, setPromoInput] = useState(initialCoupon ?? "");
  const [promoInvalid, setPromoInvalid] = useState(false);
  const [promoApplied, setPromoApplied] = useState(false);
  const [isApplyingPromo, startPromoTransition] = useTransition();

  const trackingProperties = { attempt_id: deepAttemptId, stage: "post_test" };

  function handlePayContinue() {
    startTransition(async () => {
      await trackEventAction({ event_name: "paywall_pay_clicked", properties: trackingProperties });
      const result = await payContinueAction(deepAttemptId);
      if (!result.ok) {
        toastClientError("paywall_payment", result.message);
      }
    });
  }

  function handleApplyPromo() {
    const code = promoInput.trim();
    if (!code) return;

    startPromoTransition(async () => {
      await trackEventAction({ event_name: "paywall_pay_clicked", properties: trackingProperties });
      const result = await applyCouponAction(code, deepAttemptId);
      if (!result.ok) {
        if (result.invalid) {
          setPromoInvalid(true);
        } else {
          toastClientError("paywall_coupon", result.message);
        }
        return;
      }

      setPromoInvalid(false);
      setPromoApplied(true);
      // Lets the "building the report..." message show before moving on; /deep-report then
      // hands over to the analysis screen while generation runs.
      setTimeout(
        () => router.push(`/deep-report?attemptId=${deepAttemptId}`),
        PROMO_APPLIED_TRANSITION_MS,
      );
    });
  }

  return (
    <main className="fm-payment-page">
      <TrackOnMount
        event="paywall_viewed"
        properties={{ attempt_id: deepAttemptId, stage: "post_test" }}
      />
      <header className="fm-payment-topbar">
        <Link className="fm-brand" href="/">
          <LogoMark height={34} />
          فرامن
        </Link>
        <span>آزمون خودشناسی عمیق</span>
        <span className="fm-payment-progress-track" aria-hidden="true">
          <i />
        </span>
        <span className="fm-progress-complete">۱۵۰ از ۱۵۰ ✓</span>
        <Link href="/explore">بعداً</Link>
      </header>
      <div className="fm-payment-layout">
        <div className="fm-payment-content">
          <div className="fm-payment-heading">
            <span className="fm-icon">
              <Check size={30} />
            </span>
            <div>
              <h1>تمام شد! گزارشت یک قدم تا ساخته شدن فاصله دارد.</h1>
              <p>
                جواب‌هایت ذخیره شد. بعد از پرداخت، فرامن گزارش عمیقت را می‌سازد و چند لحظه بعد آماده
                است.
              </p>
            </div>
          </div>
          {teaser && (
            <section className="fm-payment-teaser fm-gradient">
              <small>یک نگاه اول، از همین جواب‌ها</small>
              <span>پررنگ‌ترین ویژگی‌ات در این آزمون</span>
              <strong>{teaser.title}</strong>
              {(teaser.level === "high" || teaser.level === "mid" || teaser.level === "low") && (
                <div className="fm-teaser-meter">
                  <span className="fm-teaser-meter-track" aria-hidden="true">
                    <i
                      style={{
                        width:
                          teaser.level === "high"
                            ? "84%"
                            : teaser.level === "mid"
                              ? "56%"
                              : "28%",
                      }}
                    />
                  </span>
                  <small>
                    سطح در پاسخ‌هایت:{" "}
                    {teaser.level === "high" ? "بالا" : teaser.level === "mid" ? "متعادل" : "پایین"}
                  </small>
                </div>
              )}
              <p>
                اینکه این ویژگی در کار و رابطه‌هایت چطور دیده می‌شود، و ۲۹ ویژگی دیگر، در گزارش عمیق
                است.
              </p>
            </section>
          )}
          <DeepBenefits />
        </div>
        <aside className="fm-payment-aside">
          <div className="fm-price-card">
            <div className="fm-price-heading">
              <h2>گزارش عمیق</h2>
              {pricing.discountBadge && (
                <span className="fm-discount">{pricing.discountBadge}</span>
              )}
            </div>
            <div className="fm-price-value">
              {pricing.oldPrice && <del>{pricing.oldPrice}</del>}
              <strong>{pricing.price}</strong>
            </div>
            <button
              type="button"
              onClick={() => {
                if (priceAvailable) handlePayContinue();
                else router.refresh();
              }}
              disabled={isPending || isApplyingPromo || promoApplied}
              className="fm-button"
            >
              {isPending ? (
                <Spinner />
              ) : (
                <>
                  {priceAvailable ? "پرداخت و ساخت گزارش" : "تلاش دوباره برای دریافت قیمت"}{" "}
                  <ArrowLeft size={18} />
                </>
              )}
            </button>
            <p className="fm-price-secure">
              <Lock size={15} />
              پرداخت امن از طریق درگاه بانکی
            </p>
            {promoOpen ? (
              <div className="fm-coupon">
                <label htmlFor="fm-coupon-input" className="sr-only">
                  کد تخفیف
                </label>
                <div>
                  <input
                    id="fm-coupon-input"
                    value={promoInput}
                    onChange={(e) => {
                      setPromoInput(e.target.value);
                      setPromoInvalid(false);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        handleApplyPromo();
                      }
                    }}
                    placeholder="کد تخفیف"
                    disabled={isApplyingPromo || isPending || promoApplied}
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={handleApplyPromo}
                    disabled={isApplyingPromo || isPending || promoApplied || !promoInput.trim()}
                  >
                    {isApplyingPromo ? <Spinner /> : "اعمال"}
                  </button>
                </div>
                {promoInvalid && <p role="alert">این کد معتبر نیست.</p>}
                {promoApplied && <p role="status">کد اعمال شد — در حال ساخت گزارش…</p>}
              </div>
            ) : (
              <button className="fm-coupon-toggle" type="button" onClick={() => setPromoOpen(true)}>
                کد تخفیف داری؟
              </button>
            )}
          </div>
          <p className="fm-payment-note">
            جواب‌هایت ذخیره می‌ماند. هر وقت برگشتی، گزارشت را از همین‌جا بساز.
          </p>
        </aside>
      </div>
    </main>
  );
}
