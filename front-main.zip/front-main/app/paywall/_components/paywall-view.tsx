"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Check, Compass, Layers, Lock, MessageCircle, Sprout } from "lucide-react";
import { TrackOnMount } from "@/components/analytics/track-on-mount";
import { trackEventAction } from "@/lib/api/track-event-action";
import { toastClientError } from "@/lib/analytics/client-error";
import { Spinner } from "@/components/ui/spinner";
import type { PaywallPricing } from "@/lib/utils/price";
import { applyCouponAction, payContinueAction } from "../actions";

// How long the "✓ applied, building..." message stays up before moving on to the report --
// long enough to read, short enough not to feel stuck.
const PROMO_APPLIED_TRANSITION_MS = 900;

// Handoff v34 "Deep Pay" benefit tiles. Tints are the design's per-tile icon colours.
const BENEFITS = [
  {
    icon: Layers,
    title: "۳۰ ویژگی شخصیتی",
    desc: "از نظم و اضطراب تا کنجکاوی و صراحت",
    tile: "bg-[#F1EDFA] text-[#8E6BA8]",
  },
  {
    icon: Compass,
    title: "سبک تو در زندگی روزمره",
    desc: "تصمیم‌گیری، ارتباط، کار، استرس و روابط",
    tile: "bg-[#FCF1E4] text-[#D98A45]",
  },
  {
    icon: Sprout,
    title: "نقاط قوت و نقاط کور",
    desc: "چیزهایی که به آن تکیه می‌کنی و چیزهایی که کمتر می‌بینی",
    tile: "bg-[#EEF6EF] text-[#5FA26F]",
  },
  {
    icon: MessageCircle,
    title: "گفت‌وگو با فرامن",
    desc: "دربارهٔ هر بخش از گزارش سؤال بپرس",
    tile: "bg-[#EEF4FB] text-[#4E9BD6]",
  },
];

/**
 * Pay-after-test paywall ("Deep Pay" in the design handoff): shown right after the last question
 * and before the report. Two columns on desktop (what you get | price + pay), one on mobile.
 */
export function PaywallView({
  deepAttemptId,
  pricing,
}: {
  /** The finished deep attempt whose locked report this payment unlocks. */
  deepAttemptId: number;
  pricing: PaywallPricing;
}) {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  const [promoOpen, setPromoOpen] = useState(false);
  const [promoInput, setPromoInput] = useState("");
  const [promoInvalid, setPromoInvalid] = useState(false);
  const [promoApplied, setPromoApplied] = useState(false);
  const [isApplyingPromo, startPromoTransition] = useTransition();

  const trackingProperties = { attempt_id: deepAttemptId, stage: "post_test" };

  function handlePayContinue() {
    startTransition(async () => {
      await trackEventAction({ event_name: "paywall_pay_clicked", properties: trackingProperties });
      const result = await payContinueAction(deepAttemptId);
      if (!result.ok) {
        toastClientError("paywall_payment", result.message);
      }
    });
  }

  function handleApplyPromo() {
    const code = promoInput.trim();
    if (!code) return;

    startPromoTransition(async () => {
      await trackEventAction({ event_name: "paywall_pay_clicked", properties: trackingProperties });
      const result = await applyCouponAction(code, deepAttemptId);
      if (!result.ok) {
        if (result.invalid) {
          setPromoInvalid(true);
        } else {
          toastClientError("paywall_coupon", result.message);
        }
        return;
      }

      setPromoInvalid(false);
      setPromoApplied(true);
      // Lets the "building the report..." message show before moving on; /deep-report then
      // hands over to the analysis screen while generation runs.
      setTimeout(
        () => router.push(`/deep-report?attemptId=${deepAttemptId}`),
        PROMO_APPLIED_TRANSITION_MS,
      );
    });
  }

  return (
    <main className="animate-fm-in mx-auto box-border flex min-h-dvh w-full max-w-[1040px] flex-col gap-[clamp(18px,3.5vw,30px)] px-[22px] pt-6 pb-12 md:px-8">
      <TrackOnMount
        event="paywall_viewed"
        properties={{ attempt_id: deepAttemptId, stage: "post_test" }}
      />

      {/* The test is finished, so this is a progress bar that is already full; the arrow leaves
          rather than going back to the questions (which would start a new attempt). */}
      <div className="flex items-center gap-3">
        <Link
          href="/explore"
          aria-label="بازگشت"
          className="border-border flex size-10 flex-none items-center justify-center rounded-xl border bg-white text-base text-[#5D5C55]"
        >
          →
        </Link>
        <div className="flex flex-1 flex-col gap-1.5">
          <div className="flex justify-between text-[12px] font-bold text-[#A9A597]">
            <span>آزمون عمیق</span>
            <span className="text-[#2F6B47]">۱۵۰ از ۱۵۰ ✓</span>
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-[#CDE7D6]">
            <div className="h-full w-full rounded-full bg-[#4E9A6B]" />
          </div>
        </div>
      </div>

      <div className="grid items-center gap-[clamp(24px,4vw,56px)] md:grid-cols-2">
        <div className="flex flex-col gap-6">
          <div className="flex flex-col items-center gap-3 pt-1.5 text-center md:items-start md:text-start">
            <div className="grid size-16 place-items-center rounded-full bg-[#E9EBF8]">
              <Check size={30} strokeWidth={2.2} className="text-[#4F63D2]" />
            </div>
            <h1 className="text-[clamp(22px,3.4vw,34px)] leading-[1.6] font-black text-balance text-[#1E2440]">
              تمام شد! گزارشت یک قدم تا ساخته‌شدن فاصله دارد.
            </h1>
            <p className="max-w-[460px] text-[14px] leading-[2.05] text-pretty text-[#6B6A63]">
              پاسخ‌هایت ذخیره شد. بعد از پرداخت، فرامن تحلیل را شروع می‌کند و گزارش عمیقت چند لحظه
              بعد آماده است.
            </p>
          </div>

          <div className="grid gap-2.5 min-[480px]:grid-cols-2">
            {BENEFITS.map(({ icon: Icon, title, desc, tile }) => (
              <div
                key={title}
                className="border-border flex items-center gap-3 rounded-2xl border bg-white p-3.5"
              >
                <span className={`grid size-[38px] flex-none place-items-center rounded-xl ${tile}`}>
                  <Icon size={18} strokeWidth={2} />
                </span>
                <div className="flex min-w-0 flex-col gap-px">
                  <div className="text-[14px] font-extrabold text-[#242A38]">{title}</div>
                  <div className="text-[12.5px] leading-[1.8] text-[#8C887B]">{desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-3.5">
          <div className="flex flex-col gap-3.5 rounded-[22px] border-[1.5px] border-[#C7CEF0] bg-white p-[22px] shadow-[0_10px_28px_rgba(79,99,210,.10)]">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-col gap-1.5">
                <div className="text-[14.5px] font-extrabold text-[#242A38]">
                  گزارش کامل آزمون عمیق
                </div>
                {pricing.discountBadge && (
                  <div className="self-start rounded-[9px] bg-[#F5E3C4] px-2 py-[3px] text-[11.5px] font-extrabold text-[#8A5A18]">
                    {pricing.discountBadge}
                  </div>
                )}
              </div>
              <div className="flex flex-col items-end">
                {pricing.oldPrice && (
                  <div className="text-[13.5px] font-bold text-[#9A9890] line-through">
                    {pricing.oldPrice}
                  </div>
                )}
                <div className="text-2xl font-black text-[#242A38]">{pricing.price}</div>
              </div>
            </div>

            <button
              type="button"
              onClick={handlePayContinue}
              disabled={isPending || promoApplied}
              className="flex min-h-[54px] w-full items-center justify-center gap-2.5 rounded-full bg-[#4F63D2] px-[22px] py-[17px] text-[16px] font-extrabold text-white shadow-[0_10px_26px_rgba(79,99,210,.26)] transition-transform hover:-translate-y-px active:scale-[.98] disabled:cursor-not-allowed disabled:opacity-75"
            >
              {isPending ? <Spinner /> : null}
              <span>{isPending ? "در حال انتقال به درگاه پرداخت…" : "پرداخت و ساخت گزارش"}</span>
              {!isPending && <ArrowLeft size={18} strokeWidth={2.2} />}
            </button>

            <div className="flex items-center justify-center gap-[7px] text-[12px] text-[#8C887B]">
              <Lock size={14} strokeWidth={2} />
              <span>پرداخت امن از طریق درگاه بانکی</span>
            </div>

            {promoOpen ? (
              <div className="flex flex-col gap-1.5">
                <div
                  className={`flex items-center gap-1.5 rounded-xl border p-[3px] ${
                    promoInvalid ? "border-[#D98A73] bg-[#F9EAE5]" : "border-border bg-[#FBF9F4]"
                  }`}
                >
                  <input
                    type="text"
                    value={promoInput}
                    onChange={(e) => {
                      setPromoInput(e.target.value);
                      setPromoInvalid(false);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        handleApplyPromo();
                      }
                    }}
                    placeholder="کد تخفیف"
                    autoFocus
                    disabled={isApplyingPromo || promoApplied}
                    className="min-h-[38px] min-w-0 flex-1 bg-transparent px-2.5 text-[13px] font-bold text-[#242A38] outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleApplyPromo}
                    disabled={isApplyingPromo || promoApplied || !promoInput.trim()}
                    className="flex min-h-[38px] flex-none items-center rounded-[9px] px-3 text-[13px] font-extrabold text-[#2743C6] disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {isApplyingPromo ? <Spinner /> : "اعمال"}
                  </button>
                </div>
                {promoInvalid && (
                  <div className="px-1 text-[11.5px] font-bold text-[#B4412F]">
                    این کد معتبر نیست.
                  </div>
                )}
                {promoApplied && (
                  <div className="px-1 text-[11.5px] font-bold text-[#2F6B47]">
                    ✓ کد ۱۰۰٪ اعمال شد — در حال ساخت گزارش…
                  </div>
                )}
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setPromoOpen(true)}
                className="min-h-9 self-center px-2 py-1 text-[12.5px] font-bold text-[#5D5C55] underline decoration-[#CFCABD] underline-offset-4"
              >
                کد تخفیف داری؟
              </button>
            )}
          </div>

          <div className="text-center text-[12px] leading-[1.9] text-pretty text-[#A9A597]">
            پاسخ‌هایت ذخیره می‌ماند. هر وقت برگشتی، گزارشت را از همین‌جا بساز.
          </div>
        </div>
      </div>
    </main>
  );
}
