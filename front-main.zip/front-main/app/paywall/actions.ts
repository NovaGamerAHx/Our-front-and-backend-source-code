"use server";

import { redirect } from "next/navigation";
import { ApiError, updateUserTag } from "@/lib/api/client";
import { DEEP_ASSESSMENT_SLUG } from "@/lib/api/constants";
import { initiatePayment } from "@/lib/api/endpoints";

type InitiatePaymentResult = { ok: false; message: string };

const GENERIC_ERROR = "شروع پرداخت با خطا مواجه شد. لطفاً دوباره تلاش کنید.";

/** Redirects straight to Zarinpal's hosted pay page on success -- only returns when it fails.
 * `attemptId` is the finished deep attempt whose locked report this payment unlocks. */
export async function payContinueAction(attemptId: number): Promise<InitiatePaymentResult> {
  let paymentUrl: string | null;
  try {
    const result = await initiatePayment(DEEP_ASSESSMENT_SLUG, undefined, attemptId);
    paymentUrl = result.payment_url;
  } catch (error) {
    return { ok: false, message: error instanceof ApiError ? error.message : GENERIC_ERROR };
  }

  redirect(paymentUrl!);
}

type ApplyCouponResult =
  | { ok: true; unlocked: true }
  | { ok: false; invalid: true }
  | { ok: false; invalid: false; message: string };

/**
 * A 400 from /api/payment/initiate/ with a coupon_code always means InvalidCouponException --
 * assessment_slug is a fixed constant here, so there's no other validation error this call can
 * hit. Redirects to Zarinpal instead of returning when the coupon only partially covers the
 * price; only returns for the invalid-code and fully-unlocked cases.
 */
export async function applyCouponAction(
  couponCode: string,
  attemptId: number,
): Promise<ApplyCouponResult> {
  let result;
  try {
    result = await initiatePayment(DEEP_ASSESSMENT_SLUG, couponCode, attemptId);
  } catch (error) {
    if (error instanceof ApiError && error.status === 400) {
      return { ok: false, invalid: true };
    }
    return {
      ok: false,
      invalid: false,
      message: error instanceof ApiError ? error.message : GENERIC_ERROR,
    };
  }

  if (!result.unlocked) {
    redirect(result.payment_url!);
  }

  // Server Actions can only invalidate the cache with updateTag, not revalidateTag -- see
  // updateUserTag's doc comment. The report history lists this attempt as awaiting_payment
  // until now, so refresh it along with the entitlements.
  await updateUserTag("entitlements");
  await updateUserTag("report-history");
  return { ok: true, unlocked: true };
}
