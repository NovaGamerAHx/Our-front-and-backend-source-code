import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { ACCESS_TOKEN_COOKIE, REFRESH_TOKEN_COOKIE, API_BASE_URL } from "@/lib/api/constants";
import {
  buildUtmCookieValue,
  DEFAULT_DEEP_UTM,
  DEFAULT_PAY_UTM,
  readUtmFromSearch,
  UTM_COOKIE,
  UTM_COOKIE_MAX_AGE,
  withDefaultUtm,
} from "@/lib/analytics/utm";

// Must match SIMPLE_JWT["ACCESS_TOKEN_LIFETIME"] in faraman-back/faraman_back/settings.py.
const ACCESS_TOKEN_MAX_AGE = 60 * 30;

/** Calls the backend refresh endpoint directly (not lib/api/endpoints.ts -- that module is
 * "server-only" for Server Components/Actions, proxy is neither). Returns the new access
 * token, or null if the refresh token is missing/expired/invalid. */
async function refreshAccessToken(refreshToken: string): Promise<string | null> {
  try {
    const res = await fetch(`${API_BASE_URL}/api/account/token/refresh/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refresh: refreshToken }),
    });
    if (!res.ok) return null;
    const envelope = await res.json();
    return typeof envelope?.data === "string" ? envelope.data : null;
  } catch {
    return null;
  }
}

// Test-taking and viewing a report work anonymously (the backend links the
// anonymous session to an account on login), so /test and /report aren't gated
// here.
//
// This also transparently refreshes an expired access token using the still-valid refresh
// token, before any page or Server Action sees the request -- without this, the access cookie
// (30 min) outliving its own JWT would otherwise mean every user gets bounced to /login every
// 30 minutes even though their refresh token (7 days) is still perfectly good.
export async function proxy(request: NextRequest) {
  // Campaign cookie for short links (/flc7, /c9, /go/*): those pages redirect server-side
  // before UtmCapture (client) can run, so the faraman_utm cookie is written here instead --
  // the only place that can set cookies on redirect responses. Plain /flc7 and /c9 (no UTM
  // in URL) still register under their default campaign. A request without UTM leaves any
  // existing cookie untouched (buildUtmCookieValue returns null).
  const pathname = request.nextUrl.pathname;
  const urlUtm = readUtmFromSearch(request.nextUrl.searchParams);
  const effectiveUtm =
    pathname === "/flc7"
      ? withDefaultUtm(urlUtm, DEFAULT_PAY_UTM)
      : pathname === "/c9"
        ? withDefaultUtm(urlUtm, DEFAULT_DEEP_UTM)
        : urlUtm;
  const utmCookieValue = buildUtmCookieValue(effectiveUtm);
  // Set-Cookie is serialized by hand instead of response.cookies.set(): Next's cookie helper
  // percent-encodes the value as well, and on a plain 200 middleware response that encoding
  // lands twice, so parseUtmCookie (which decodes once) could not read it back. One manual
  // encode + one raw header behaves identically on redirect and plain responses.
  const setUtmCookie = (response: NextResponse) => {
    if (utmCookieValue) {
      const attributes = ["Path=/", `Max-Age=${UTM_COOKIE_MAX_AGE}`, "SameSite=lax"];
      if (process.env.NODE_ENV === "production") attributes.push("Secure");
      response.headers.append(
        "Set-Cookie",
        `${UTM_COOKIE}=${encodeURIComponent(utmCookieValue)}; ${attributes.join("; ")}`,
      );
    }
    return response;
  };

  const hasAccess = request.cookies.has(ACCESS_TOKEN_COOKIE);
  const refreshToken = request.cookies.get(REFRESH_TOKEN_COOKIE)?.value;

  if (!hasAccess && refreshToken) {
    const newAccess = await refreshAccessToken(refreshToken);

    if (newAccess) {
      // Inject the refreshed token into the request forwarded downstream too, so the
      // Server Component/Action handling *this* request also sees it via cookies() --
      // response.cookies.set() alone only reaches the browser on the *next* request.
      const requestHeaders = new Headers(request.headers);
      const existingCookie = requestHeaders.get("cookie") ?? "";
      requestHeaders.set(
        "cookie",
        existingCookie
          ? `${existingCookie}; ${ACCESS_TOKEN_COOKIE}=${newAccess}`
          : `${ACCESS_TOKEN_COOKIE}=${newAccess}`,
      );

      const response =
        request.nextUrl.pathname === "/login"
          ? NextResponse.redirect(new URL("/", request.url))
          : NextResponse.next({ request: { headers: requestHeaders } });

      response.cookies.set(ACCESS_TOKEN_COOKIE, newAccess, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        path: "/",
        maxAge: ACCESS_TOKEN_MAX_AGE,
      });
      return setUtmCookie(response);
    }

    return setUtmCookie(NextResponse.next());
  }

  // Never redirect a Server Action POST: actions are sent to the page URL they were called from,
  // so one fired from /login right after sign-in would otherwise be bounced to "/".
  if (hasAccess && request.nextUrl.pathname === "/login" && !request.headers.has("next-action")) {
    return setUtmCookie(NextResponse.redirect(new URL("/", request.url)));
  }

  // Fallthrough (no auth redirect): still persist the campaign when the URL carries UTM,
  // so short-link landings register even though the page itself redirects before UtmCapture.
  if (utmCookieValue) {
    return setUtmCookie(NextResponse.next());
  }
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\..*).*)"],
};
