import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { ACCESS_TOKEN_COOKIE, REFRESH_TOKEN_COOKIE, API_BASE_URL } from "@/lib/api/constants";

// Must match SIMPLE_JWT["ACCESS_TOKEN_LIFETIME"] in faraman-back/faraman_back/settings.py.
const ACCESS_TOKEN_MAX_AGE = 60 * 30;

/** Calls the backend refresh endpoint directly (not lib/api/endpoints.ts -- that module is
 * "server-only" for Server Components/Actions, proxy is neither). Returns the new access
 * token, or null if the refresh token is missing/expired/invalid. */
async function refreshAccessToken(refreshToken: string): Promise<string | null> {
  try {
    const res = await fetch(`${API_BASE_URL}/api/account/token/refresh/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refresh: refreshToken }),
    });
    if (!res.ok) return null;
    const envelope = await res.json();
    return typeof envelope?.data === "string" ? envelope.data : null;
  } catch {
    return null;
  }
}

// Test-taking and viewing a report work anonymously (the backend links the
// anonymous session to an account on login), so /test and /report aren't gated
// here.
//
// This also transparently refreshes an expired access token using the still-valid refresh
// token, before any page or Server Action sees the request -- without this, the access cookie
// (30 min) outliving its own JWT would otherwise mean every user gets bounced to /login every
// 30 minutes even though their refresh token (7 days) is still perfectly good.
export async function proxy(request: NextRequest) {
  const hasAccess = request.cookies.has(ACCESS_TOKEN_COOKIE);
  const refreshToken = request.cookies.get(REFRESH_TOKEN_COOKIE)?.value;

  if (!hasAccess && refreshToken) {
    const newAccess = await refreshAccessToken(refreshToken);

    if (newAccess) {
      // Inject the refreshed token into the request forwarded downstream too, so the
      // Server Component/Action handling *this* request also sees it via cookies() --
      // response.cookies.set() alone only reaches the browser on the *next* request.
      const requestHeaders = new Headers(request.headers);
      const existingCookie = requestHeaders.get("cookie") ?? "";
      requestHeaders.set(
        "cookie",
        existingCookie
          ? `${existingCookie}; ${ACCESS_TOKEN_COOKIE}=${newAccess}`
          : `${ACCESS_TOKEN_COOKIE}=${newAccess}`,
      );

      const response =
        request.nextUrl.pathname === "/login"
          ? NextResponse.redirect(new URL("/", request.url))
          : NextResponse.next({ request: { headers: requestHeaders } });

      response.cookies.set(ACCESS_TOKEN_COOKIE, newAccess, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        path: "/",
        maxAge: ACCESS_TOKEN_MAX_AGE,
      });
      return response;
    }

    return NextResponse.next();
  }

  // Never redirect a Server Action POST: actions are sent to the page URL they were called from,
  // so one fired from /login right after sign-in would otherwise be bounced to "/".
  if (hasAccess && request.nextUrl.pathname === "/login" && !request.headers.has("next-action")) {
    return NextResponse.redirect(new URL("/", request.url));
  }
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\..*).*)"],
};
