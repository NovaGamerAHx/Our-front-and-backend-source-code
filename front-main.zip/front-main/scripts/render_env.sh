#!/usr/bin/env bash
# Renders .env from GitLab CI/CD variables, using .env.example as the list of
# expected keys. Add a new var to .env.example and a matching CI/CD variable
# (Settings > CI/CD > Variables) of the same name — no other file to update.
set -euo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")/.."

: > .env
while IFS='=' read -r key _ || [[ -n "$key" ]]; do
    [[ -z "$key" || "$key" == \#* ]] && continue
    echo "${key}=${!key:-}" >> .env
done < .env.example
