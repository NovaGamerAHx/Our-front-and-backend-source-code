from django.contrib import admin

from apps.events.models import Event


@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ("id", "event_name", "user", "anonymous_id", "utm_source", "utm_campaign", "occurred_at", "created_at")
    list_filter = ("event_name", "utm_campaign")
    search_fields = ("anonymous_id", "user__phone_number", "utm_campaign", "utm_source")
    readonly_fields = [f.name for f in Event._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
