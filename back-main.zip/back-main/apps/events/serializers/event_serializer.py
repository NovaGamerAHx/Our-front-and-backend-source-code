from rest_framework import serializers

from apps.events.models import Event

# Restricts which `properties` keys are stored per event_name, so the frontend can't stuff
# arbitrary (potentially sensitive) data into an analytics event. Event names absent from this
# map are unrestricted, preserving existing behavior for the pre-auth funnel events.
UTM_KEYS = {"utm_source", "utm_medium", "utm_campaign"}

# Campaign attribution allowed on *every* restricted event, so any event (paywall_viewed,
# test_started, ...) can be filtered by campaign in Metabase without a per-campaign event name.
# utm_medium stays landing-only (UTM_KEYS above): it isn't kept in the frontend's cookie.
ATTRIBUTION_KEYS = {"utm_source", "utm_campaign"}
MAX_ATTRIBUTION_LENGTH = 100

ALLOWED_PROPERTY_KEYS = {
    Event.EventName.LANDING_VIEWED: UTM_KEYS,
    Event.EventName.TEST_INTRO_VIEWED: UTM_KEYS,
    Event.EventName.AUTH_CODE_REQUEST_FAILED: {"reason"},
    Event.EventName.PAYWALL_VIEWED: {"attempt_id", "stage", "source"},
    Event.EventName.PAYWALL_PAY_CLICKED: {"attempt_id", "stage"},
    Event.EventName.PAYWALL_LOGIN_REDIRECTED: {"attempt_id", "stage"},
    Event.EventName.PUSH_PERMISSION_RESULT: {"result"},
    Event.EventName.OTP_VERIFY_FAILED: set(),
    Event.EventName.OTP_RESEND_CLICKED: set(),
    Event.EventName.FEEDBACK_FORM_OPENED: {"target_type"},
    Event.EventName.CLIENT_ERROR_SHOWN: {"context", "message"},
    Event.EventName.TEST_STARTED: {"assessment_slug", "attempt_id"},
    Event.EventName.TEST_COMPLETED: {"assessment_slug", "attempt_id", "duration_ms"},
    Event.EventName.REPORT_GENERATED: {"assessment_slug", "attempt_id", "duration_ms", "status"},
    Event.EventName.PREVIEW_VIEWED: {"assessment_slug", "attempt_id"},
    Event.EventName.FULL_REPORT_VIEWED: {"assessment_slug", "attempt_id"},
    Event.EventName.LOGIN_AFTER_PREVIEW: {"assessment_slug"},
    Event.EventName.CHECKIN_NOTIF_OPENED: {"committed_step_id"},
    Event.EventName.RETURNED_TO_CHAT_AFTER_CHECKIN: {"committed_step_id"},
    Event.EventName.TEST_INTRO_START_CLICKED: set(),
    Event.EventName.AUTH_COMPLETED: {"source", "next_path"},
    Event.EventName.DEEP_INTRO_VIEWED: {"source"},
    Event.EventName.DEEP_QUESTIONS_VIEWED: {"source"},
    Event.EventName.CHAT_OPENED: {"entry_source"},
}


class TrackEventSerializer(serializers.Serializer):
    event_name = serializers.ChoiceField(choices=Event.EventName.choices)
    properties = serializers.JSONField(required=False, default=dict)
    occurred_at = serializers.DateTimeField(required=False, allow_null=True)

    def validate(self, attrs):
        allowed_keys = ALLOWED_PROPERTY_KEYS.get(attrs["event_name"])
        properties = attrs.get("properties")
        if allowed_keys is not None and isinstance(properties, dict):
            allowed_keys = allowed_keys | ATTRIBUTION_KEYS
            attrs["properties"] = {
                key: self._clean_value(key, value) for key, value in properties.items() if key in allowed_keys
            }
        return attrs

    @staticmethod
    def _clean_value(key, value):
        # Same cap the frontend applies when reading utm_* from the URL/cookie.
        if key in UTM_KEYS and isinstance(value, str):
            return value[:MAX_ATTRIBUTION_LENGTH]
        return value
