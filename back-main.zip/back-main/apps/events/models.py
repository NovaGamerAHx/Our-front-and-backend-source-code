from django.conf import settings
from django.db import models


class Event(models.Model):
    class EventName(models.TextChoices):
        LANDING_VIEWED = 'landing_viewed', 'Landing Viewed'
        START_TEST_CLICKED = 'start_test_clicked', 'Start Test Clicked'
        AUTH_STARTED = 'auth_started', 'Auth Started'
        AUTH_CODE_REQUESTED = 'auth_code_requested', 'Auth Code Requested'
        AUTH_CODE_REQUEST_FAILED = 'auth_code_request_failed', 'Auth Code Request Failed'
        TEST_STARTED = 'test_started', 'Test Started'
        TEST_COMPLETED = 'test_completed', 'Test Completed'
        REPORT_GENERATED = 'report_generated', 'Report Generated'
        PREVIEW_VIEWED = 'preview_viewed', 'Preview Viewed'
        FULL_REPORT_VIEWED = 'full_report_viewed', 'Full Report Viewed'
        LOGIN_AFTER_PREVIEW = 'login_after_preview', 'Login After Preview'
        CHECKIN_NOTIF_OPENED = 'checkin_notif_opened', 'Checkin Notif Opened'
        RETURNED_TO_CHAT_AFTER_CHECKIN = 'returned_to_chat_after_checkin', 'Returned To Chat After Checkin'
        TEST_INTRO_VIEWED = 'test_intro_viewed', 'Test Intro Viewed'
        PAYWALL_VIEWED = 'paywall_viewed', 'Paywall Viewed'
        PAYWALL_PAY_CLICKED = 'paywall_pay_clicked', 'Paywall Pay Clicked'
        PAYWALL_LOGIN_REDIRECTED = 'paywall_login_redirected', 'Paywall Login Redirected'
        PUSH_PERMISSION_RESULT = 'push_permission_result', 'Push Permission Result'
        OTP_VERIFY_FAILED = 'otp_verify_failed', 'Otp Verify Failed'
        OTP_RESEND_CLICKED = 'otp_resend_clicked', 'Otp Resend Clicked'
        FEEDBACK_FORM_OPENED = 'feedback_form_opened', 'Feedback Form Opened'
        CLIENT_ERROR_SHOWN = 'client_error_shown', 'Client Error Shown'
        TEST_INTRO_START_CLICKED = 'test_intro_start_clicked', 'Test Intro Start Clicked'
        AUTH_COMPLETED = 'auth_completed', 'Auth Completed'
        DEEP_INTRO_VIEWED = 'deep_intro_viewed', 'Deep Intro Viewed'
        DEEP_QUESTIONS_VIEWED = 'deep_questions_viewed', 'Deep Questions Viewed'
        CHAT_OPENED = 'chat_opened', 'Chat Opened'

    event_name = models.CharField(max_length=64, choices=EventName.choices, db_index=True)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name='events'
    )
    anonymous_id = models.CharField(max_length=64, null=True, blank=True, db_index=True)
    properties = models.JSONField(default=dict, blank=True)
    # Campaign attribution, copied out of `properties` at write time (EventRepository.create) so
    # per-campaign funnels filter on an indexed column instead of scanning the JSON. `properties`
    # keeps its own copy.
    utm_source = models.CharField(max_length=100, blank=True, default='')
    utm_campaign = models.CharField(max_length=100, blank=True, default='')
    occurred_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "events"
        indexes = [
            models.Index(fields=["event_name"]),
            models.Index(fields=["anonymous_id"]),
            models.Index(fields=["created_at"]),
            # Partial: most events carry no campaign, so leave them out of the index.
            models.Index(
                fields=["utm_campaign", "event_name", "created_at"],
                condition=~models.Q(utm_campaign=""),
                name="events_campaign_funnel_idx",
            ),
        ]

    def __str__(self):
        return f"{self.event_name} ({self.id})"
