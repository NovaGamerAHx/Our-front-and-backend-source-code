from drf_spectacular.utils import extend_schema
from rest_framework.permissions import AllowAny
from rest_framework.views import APIView

from apps.events.serializers.event_serializer import TrackEventSerializer
from apps.events.services.event_service import EventService
from faraman_back.lang.utils import get_message
from faraman_back.utils.responses import ApiResponse


class TrackEventAPIView(APIView):
    permission_classes = [AllowAny]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.event_service = EventService()

    @extend_schema(
        description="Receives a single behavioral event from the frontend and persists it. "
                    "Works both for anonymous (pre-auth) and authenticated requests.",
        tags=["Events"],
        request=TrackEventSerializer,
    )
    def post(self, request):
        ser = TrackEventSerializer(data=request.data)
        if not ser.is_valid():
            return ApiResponse.validation_error(data=ser.errors)

        user = request.user if request.user.is_authenticated else None

        self.event_service.track_event(user=user, anonymous_id=request.anonymous_id, **ser.validated_data)

        return ApiResponse.success(message=get_message('event_tracked'))
