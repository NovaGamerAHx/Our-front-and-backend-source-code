from datetime import datetime

from apps.account.models import User
from apps.events.models import Event


UTM_COLUMN_MAX_LENGTH = 100


def _utm_column(properties: dict, key: str) -> str:
    value = properties.get(key)
    return value[:UTM_COLUMN_MAX_LENGTH] if isinstance(value, str) else ""


class EventRepository:
    def create(
        self,
        *,
        event_name: str,
        user: User | None = None,
        anonymous_id: str | None = None,
        properties: dict | None = None,
        occurred_at: datetime | None = None,
    ) -> Event:
        properties = properties or {}
        return Event.objects.create(
            event_name=event_name,
            user=user,
            anonymous_id=anonymous_id,
            properties=properties,
            utm_source=_utm_column(properties, "utm_source"),
            utm_campaign=_utm_column(properties, "utm_campaign"),
            occurred_at=occurred_at,
        )
