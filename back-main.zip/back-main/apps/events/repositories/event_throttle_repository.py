import logging

import redis
from django.conf import settings

logger = logging.getLogger(__name__)

EVENT_RATE_LIMIT_COUNT = 120
EVENT_RATE_LIMIT_WINDOW_SECONDS = 60  # 1 minute


class EventThrottleRepository:
    """Fixed-window counter limiting how many events a single identity can submit per minute.
    Fails open on Redis errors so an outage doesn't block real tracking."""

    def __init__(self):
        self._client = None

    @property
    def client(self):
        if self._client is None:
            self._client = redis.StrictRedis(
                host=getattr(settings, 'REDIS_HOST', 'localhost'),
                port=getattr(settings, 'REDIS_PORT', 6379),
                db=getattr(settings, 'REDIS_DB', 0),
                password=getattr(settings, 'REDIS_PASSWORD', ''),
                decode_responses=True,
            )
        return self._client

    @staticmethod
    def _key(identity: str) -> str:
        return f"event_rate_limit:{identity}"

    def hit(self, identity: str) -> bool:
        """Increments the counter for identity and returns whether it is now over
        EVENT_RATE_LIMIT_COUNT within the current window."""
        try:
            key = self._key(identity)
            count = self.client.incr(key)
            if count == 1:
                self.client.expire(key, EVENT_RATE_LIMIT_WINDOW_SECONDS)
            return count > EVENT_RATE_LIMIT_COUNT
        except Exception:
            logger.exception(f"Failed to check event rate limit for {identity}")
            return False
