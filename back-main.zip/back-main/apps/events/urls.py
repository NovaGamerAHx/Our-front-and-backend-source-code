from django.urls import path

from apps.events.views.event_view import TrackEventAPIView

app_name = "events"

urlpatterns = [
    path("track/", TrackEventAPIView.as_view(), name="track_event"),
]
