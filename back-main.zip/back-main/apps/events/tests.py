from unittest.mock import MagicMock

import importlib

from django.apps import apps as django_apps
from django.test import TestCase

from apps.events.models import Event
from apps.events.repositories.event_repository import EventRepository
from apps.events.serializers.event_serializer import ALLOWED_PROPERTY_KEYS, TrackEventSerializer
from apps.events.services.event_service import EventService


class EventServiceTrackEventTests(TestCase):
    def setUp(self):
        self.event_repository = MagicMock()
        self.attempt_repository = MagicMock()
        self.event_throttle_repository = MagicMock()
        self.event_throttle_repository.hit.return_value = False
        self.service = EventService(
            event_repository=self.event_repository,
            attempt_repository=self.attempt_repository,
            event_throttle_repository=self.event_throttle_repository,
        )

    def test_creates_event_for_non_attempt_scoped_name(self):
        self.service.track_event(event_name=Event.EventName.LANDING_VIEWED, user=None, anonymous_id="anon-1")

        self.event_repository.create.assert_called_once()
        self.attempt_repository.get_by_id.assert_not_called()

    def test_creates_attempt_scoped_event_when_anonymous_owns_attempt(self):
        attempt = MagicMock(user_id=None, anonymous_id="anon-1")
        self.attempt_repository.get_by_id.return_value = attempt

        result = self.service.track_event(
            event_name=Event.EventName.TEST_STARTED,
            user=None,
            anonymous_id="anon-1",
            properties={"attempt_id": 7},
        )

        self.assertIsNotNone(result)
        self.event_repository.create.assert_called_once()

    def test_creates_attempt_scoped_event_when_user_owns_attempt(self):
        user = MagicMock(id=42)
        attempt = MagicMock(user_id=42)
        self.attempt_repository.get_by_id.return_value = attempt

        result = self.service.track_event(
            event_name=Event.EventName.TEST_COMPLETED,
            user=user,
            anonymous_id=None,
            properties={"attempt_id": 7},
        )

        self.assertIsNotNone(result)
        self.event_repository.create.assert_called_once()

    def test_drops_attempt_scoped_event_when_attempt_id_missing(self):
        result = self.service.track_event(
            event_name=Event.EventName.TEST_STARTED, user=None, anonymous_id="anon-1", properties={}
        )

        self.assertIsNone(result)
        self.event_repository.create.assert_not_called()

    def test_drops_attempt_scoped_event_when_attempt_not_found(self):
        self.attempt_repository.get_by_id.return_value = None

        result = self.service.track_event(
            event_name=Event.EventName.TEST_STARTED,
            user=None,
            anonymous_id="anon-1",
            properties={"attempt_id": 999},
        )

        self.assertIsNone(result)
        self.event_repository.create.assert_not_called()

    def test_drops_attempt_scoped_event_when_owned_by_different_anonymous_id(self):
        attempt = MagicMock(user_id=None, anonymous_id="someone-else")
        self.attempt_repository.get_by_id.return_value = attempt

        result = self.service.track_event(
            event_name=Event.EventName.TEST_STARTED,
            user=None,
            anonymous_id="anon-1",
            properties={"attempt_id": 7},
        )

        self.assertIsNone(result)
        self.event_repository.create.assert_not_called()

    def test_drops_attempt_scoped_event_when_owned_by_different_user(self):
        user = MagicMock(id=42)
        attempt = MagicMock(user_id=99)
        self.attempt_repository.get_by_id.return_value = attempt

        result = self.service.track_event(
            event_name=Event.EventName.REPORT_GENERATED,
            user=user,
            anonymous_id=None,
            properties={"attempt_id": 7},
        )

        self.assertIsNone(result)
        self.event_repository.create.assert_not_called()

    def test_drops_event_when_rate_limited(self):
        self.event_throttle_repository.hit.return_value = True

        result = self.service.track_event(
            event_name=Event.EventName.LANDING_VIEWED, user=None, anonymous_id="anon-1"
        )

        self.assertIsNone(result)
        self.event_repository.create.assert_not_called()

    def test_does_not_rate_limit_when_no_identity(self):
        result = self.service.track_event(event_name=Event.EventName.LANDING_VIEWED, user=None, anonymous_id=None)

        self.event_throttle_repository.hit.assert_not_called()
        self.event_repository.create.assert_called_once()


class TrackEventSerializerPropertyAllowlistTests(TestCase):
    def test_strips_disallowed_keys_for_attempt_scoped_event(self):
        ser = TrackEventSerializer(
            data={
                "event_name": Event.EventName.TEST_COMPLETED,
                "properties": {"attempt_id": 7, "duration_ms": 1200, "phone_number": "0912xxxxxxx"},
            }
        )

        self.assertTrue(ser.is_valid(), ser.errors)
        self.assertEqual(
            ser.validated_data["properties"], {"attempt_id": 7, "duration_ms": 1200}
        )

    def test_leaves_properties_unrestricted_for_legacy_event(self):
        ser = TrackEventSerializer(
            data={"event_name": Event.EventName.AUTH_STARTED, "properties": {"anything": "goes"}}
        )

        self.assertTrue(ser.is_valid(), ser.errors)
        self.assertEqual(ser.validated_data["properties"], {"anything": "goes"})

    def test_strips_disallowed_keys_for_checkin_notif_opened(self):
        ser = TrackEventSerializer(
            data={
                "event_name": Event.EventName.CHECKIN_NOTIF_OPENED,
                "properties": {"committed_step_id": 5, "phone_number": "0912xxxxxxx"},
            }
        )

        self.assertTrue(ser.is_valid(), ser.errors)
        self.assertEqual(ser.validated_data["properties"], {"committed_step_id": 5})

    def test_strips_disallowed_keys_for_returned_to_chat_after_checkin(self):
        ser = TrackEventSerializer(
            data={
                "event_name": Event.EventName.RETURNED_TO_CHAT_AFTER_CHECKIN,
                "properties": {"committed_step_id": 5, "chat_session_id": "session-1"},
            }
        )

        self.assertTrue(ser.is_valid(), ser.errors)
        self.assertEqual(ser.validated_data["properties"], {"committed_step_id": 5})

    def test_keeps_only_utm_keys_for_landing_viewed_and_test_intro_viewed(self):
        for event_name in (Event.EventName.LANDING_VIEWED, Event.EventName.TEST_INTRO_VIEWED):
            ser = TrackEventSerializer(
                data={
                    "event_name": event_name,
                    "properties": {"utm_source": "ig", "utm_medium": "cpc", "utm_campaign": "fall", "x": 1},
                }
            )

            self.assertTrue(ser.is_valid(), ser.errors)
            self.assertEqual(
                ser.validated_data["properties"],
                {"utm_source": "ig", "utm_medium": "cpc", "utm_campaign": "fall"},
            )

    def test_keeps_only_reason_for_auth_code_request_failed(self):
        ser = TrackEventSerializer(
            data={
                "event_name": Event.EventName.AUTH_CODE_REQUEST_FAILED,
                "properties": {"reason": "throttled", "phone_number": "0912xxxxxxx"},
            }
        )

        self.assertTrue(ser.is_valid(), ser.errors)
        self.assertEqual(ser.validated_data["properties"], {"reason": "throttled"})

    def test_strips_all_properties_for_otp_events(self):
        for event_name in (Event.EventName.OTP_VERIFY_FAILED, Event.EventName.OTP_RESEND_CLICKED):
            ser = TrackEventSerializer(data={"event_name": event_name, "properties": {"phone_number": "0912"}})

            self.assertTrue(ser.is_valid(), ser.errors)
            self.assertEqual(ser.validated_data["properties"], {})

    def test_strips_disallowed_keys_for_new_ui_events(self):
        cases = {
            Event.EventName.PAYWALL_VIEWED: ({"attempt_id": 3, "x": 1}, {"attempt_id": 3}),
            Event.EventName.PUSH_PERMISSION_RESULT: ({"result": "denied", "x": 1}, {"result": "denied"}),
            Event.EventName.FEEDBACK_FORM_OPENED: ({"target_type": "app", "x": 1}, {"target_type": "app"}),
            Event.EventName.CLIENT_ERROR_SHOWN: (
                {"context": "paywall", "message": "m", "x": 1},
                {"context": "paywall", "message": "m"},
            ),
        }
        for event_name, (given, expected) in cases.items():
            ser = TrackEventSerializer(data={"event_name": event_name, "properties": given})

            self.assertTrue(ser.is_valid(), ser.errors)
            self.assertEqual(ser.validated_data["properties"], expected)

    def test_keeps_campaign_attribution_on_every_restricted_event(self):
        for event_name in ALLOWED_PROPERTY_KEYS:
            ser = TrackEventSerializer(
                data={
                    "event_name": event_name,
                    "properties": {"utm_source": "sms", "utm_campaign": "deep_followup", "phone_number": "0912"},
                }
            )

            self.assertTrue(ser.is_valid(), ser.errors)
            properties = ser.validated_data["properties"]
            self.assertEqual(properties["utm_source"], "sms", event_name)
            self.assertEqual(properties["utm_campaign"], "deep_followup", event_name)
            self.assertNotIn("phone_number", properties, event_name)

    def test_utm_medium_is_only_kept_for_landing_events(self):
        given = {"utm_source": "sms", "utm_medium": "sms", "utm_campaign": "c", "attempt_id": 3}

        paywall = TrackEventSerializer(data={"event_name": Event.EventName.PAYWALL_VIEWED, "properties": given})
        landing = TrackEventSerializer(data={"event_name": Event.EventName.LANDING_VIEWED, "properties": given})

        self.assertTrue(paywall.is_valid(), paywall.errors)
        self.assertTrue(landing.is_valid(), landing.errors)
        self.assertEqual(
            paywall.validated_data["properties"], {"utm_source": "sms", "utm_campaign": "c", "attempt_id": 3}
        )
        self.assertIn("utm_medium", landing.validated_data["properties"])

    def test_truncates_overlong_utm_values(self):
        ser = TrackEventSerializer(
            data={"event_name": Event.EventName.PAYWALL_VIEWED, "properties": {"utm_campaign": "x" * 500}}
        )

        self.assertTrue(ser.is_valid(), ser.errors)
        self.assertEqual(len(ser.validated_data["properties"]["utm_campaign"]), 100)

    def test_paywall_funnel_events_keep_only_attempt_id_and_campaign(self):
        for event_name in (Event.EventName.PAYWALL_PAY_CLICKED, Event.EventName.PAYWALL_LOGIN_REDIRECTED):
            ser = TrackEventSerializer(
                data={
                    "event_name": event_name,
                    "properties": {"attempt_id": 3, "utm_campaign": "c", "phone_number": "0912"},
                }
            )

            self.assertTrue(ser.is_valid(), ser.errors)
            self.assertEqual(ser.validated_data["properties"], {"attempt_id": 3, "utm_campaign": "c"})

    def test_rejects_removed_unused_event_names(self):
        for name in ("checkin_shown", "checkin_responded", "step_expired"):
            self.assertFalse(TrackEventSerializer(data={"event_name": name}).is_valid())


class EventRepositoryUtmColumnTests(TestCase):
    def test_copies_campaign_from_properties_into_columns(self):
        event = EventRepository().create(
            event_name=Event.EventName.PAYWALL_VIEWED,
            anonymous_id="anon-1",
            properties={"utm_source": "sms", "utm_campaign": "deep_followup", "attempt_id": 3},
        )

        event.refresh_from_db()
        self.assertEqual((event.utm_source, event.utm_campaign), ("sms", "deep_followup"))
        self.assertEqual(event.properties["utm_campaign"], "deep_followup")

    def test_columns_default_to_empty_without_campaign_or_with_non_string_value(self):
        none = EventRepository().create(event_name=Event.EventName.PAYWALL_VIEWED, anonymous_id="a")
        bad = EventRepository().create(
            event_name=Event.EventName.PAYWALL_VIEWED, anonymous_id="a", properties={"utm_campaign": 5}
        )

        for event in (none, bad):
            event.refresh_from_db()
            self.assertEqual((event.utm_source, event.utm_campaign), ("", ""))

    def test_overlong_value_is_truncated_to_column_length(self):
        event = EventRepository().create(
            event_name=Event.EventName.PAYWALL_VIEWED, anonymous_id="a", properties={"utm_campaign": "x" * 500}
        )

        event.refresh_from_db()
        self.assertEqual(len(event.utm_campaign), 100)


class BackfillEventUtmColumnsTests(TestCase):
    def test_backfills_rows_recorded_before_the_columns_existed(self):
        old = Event.objects.create(
            event_name=Event.EventName.LANDING_VIEWED,
            properties={"utm_source": "ig", "utm_campaign": "c" * 300},
        )
        plain = Event.objects.create(event_name=Event.EventName.LANDING_VIEWED, properties={"x": 1})
        migration = importlib.import_module("apps.events.migrations.0008_backfill_event_utm_columns")

        migration.backfill_utm_columns(django_apps, None)

        old.refresh_from_db()
        plain.refresh_from_db()
        self.assertEqual(old.utm_source, "ig")
        self.assertEqual(old.utm_campaign, "c" * 100)
        self.assertEqual((plain.utm_source, plain.utm_campaign), ("", ""))
