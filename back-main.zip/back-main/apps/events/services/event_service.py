import logging
from datetime import datetime

from apps.account.models import User
from apps.assessment.repositories.attempt_repository import AttemptRepository
from apps.events.models import Event
from apps.events.repositories.event_repository import EventRepository
from apps.events.repositories.event_throttle_repository import EventThrottleRepository

logger = logging.getLogger(__name__)

# Events that carry an `attempt_id` property referencing a real Attempt. For these, ownership of
# that attempt is verified before the event is persisted, so a spoofed event_name/anonymous_id
# combination can't be used to fabricate analytics for someone else's attempt.
ATTEMPT_SCOPED_EVENT_NAMES = {
    Event.EventName.TEST_STARTED,
    Event.EventName.TEST_COMPLETED,
    Event.EventName.REPORT_GENERATED,
    Event.EventName.PREVIEW_VIEWED,
    Event.EventName.FULL_REPORT_VIEWED,
}


class EventService:
    def __init__(self, event_repository=None, attempt_repository=None, event_throttle_repository=None):
        self.event_repository = event_repository or EventRepository()
        self.attempt_repository = attempt_repository or AttemptRepository()
        self.event_throttle_repository = event_throttle_repository or EventThrottleRepository()

    @staticmethod
    def _identity(*, user: User | None, anonymous_id: str | None) -> str | None:
        if user is not None:
            return f"user:{user.id}"
        if anonymous_id is not None:
            return f"anon:{anonymous_id}"
        return None

    def _owns_attempt(self, attempt_id, *, user: User | None, anonymous_id: str | None) -> bool:
        attempt = self.attempt_repository.get_by_id(attempt_id)
        if attempt is None:
            return False
        if attempt.user_id is not None:
            return user is not None and attempt.user_id == user.id
        return anonymous_id is not None and attempt.anonymous_id == anonymous_id

    def track_event(
        self,
        *,
        event_name: str,
        user: User | None,
        anonymous_id: str | None = None,
        properties: dict | None = None,
        occurred_at: datetime | None = None,
    ) -> Event | None:
        """Persists a tracked event, or silently drops it (returning None) if it fails the rate
        limit or attempt-ownership check. Dropping rather than raising keeps this best-effort:
        analytics tracking should never surface as a broken request to the caller."""
        properties = properties or {}
        identity = self._identity(user=user, anonymous_id=anonymous_id)

        if identity is not None and self.event_throttle_repository.hit(identity):
            logger.info(f"Dropping event {event_name}: rate limit exceeded for {identity}")
            return None

        if event_name in ATTEMPT_SCOPED_EVENT_NAMES:
            attempt_id = properties.get("attempt_id")
            if attempt_id is None or not self._owns_attempt(attempt_id, user=user, anonymous_id=anonymous_id):
                logger.warning(f"Dropping event {event_name}: attempt {attempt_id} not owned by {identity}")
                return None

        return self.event_repository.create(
            event_name=event_name,
            user=user,
            anonymous_id=anonymous_id,
            properties=properties,
            occurred_at=occurred_at,
        )
