from django.db import migrations
from django.db.models import Value
from django.db.models.fields.json import KeyTextTransform
from django.db.models.functions import Coalesce, Substr


def backfill_utm_columns(apps, schema_editor):
    """Copies utm_source/utm_campaign out of `properties` for events recorded before the
    columns existed. One UPDATE per key, capped at the column length (events older than the
    attribution cap could hold longer values)."""
    Event = apps.get_model("events", "Event")
    for key in ("utm_source", "utm_campaign"):
        Event.objects.filter(**{f"properties__has_key": key}).update(
            **{key: Coalesce(Substr(KeyTextTransform(key, "properties"), 1, 100), Value(""))}
        )


class Migration(migrations.Migration):

    dependencies = [
        ("events", "0007_event_utm_columns"),
    ]

    operations = [
        migrations.RunPython(backfill_utm_columns, migrations.RunPython.noop),
    ]
