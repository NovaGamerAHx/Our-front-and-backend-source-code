from drf_spectacular.utils import extend_schema
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.views import APIView
from rest_framework_simplejwt.exceptions import TokenError
from rest_framework_simplejwt.serializers import TokenRefreshSerializer
from rest_framework_simplejwt.tokens import RefreshToken

from apps.account.repositories.user_repository import UserRepository
from apps.account.serializers.user_serializer import LogoutSerializer, ProfileSerializer
from apps.account.services.exceptions import InvalidTokenException
from apps.account.services.user_service import UserService
from faraman_back.lang.utils import get_message
from faraman_back.utils.responses import ApiResponse
from faraman_back.utils.schema import error_responses


class TokenRefreshAPIView(APIView):
    permission_classes = [AllowAny]

    @extend_schema(
        description="Takes a refresh token and returns a new access token.",
        tags=["Authentication"],
        request=TokenRefreshSerializer,
        responses=error_responses(InvalidTokenException),
    )
    def post(self, request):
        ser = TokenRefreshSerializer(data=request.data)
        try:
            if not ser.is_valid():
                return ApiResponse.validation_error(
                    data=ser.errors
                )
        except TokenError:
            raise InvalidTokenException()

        return ApiResponse.success(
            data=ser.validated_data['access'].strip(),
        )


class LogoutAPIView(APIView):
    permission_classes = [IsAuthenticated]

    @extend_schema(
        description="Accepts a refresh token and blacklists it to log out the user.",
        tags=["Authentication"],
        request=LogoutSerializer,
        responses=error_responses(InvalidTokenException),
    )
    def post(self, request):
        ser = LogoutSerializer(data=request.data)
        if not ser.is_valid():
            return ApiResponse.validation_error(
                data=ser.errors
            )
        refresh_token = ser.validated_data['refresh'].strip()
        try:
            token = RefreshToken(refresh_token)
            token.blacklist()
        except TokenError:
            raise InvalidTokenException()

        return ApiResponse.success(message=get_message('logout_successfully'))


class ProfileAPIView(APIView):
    permission_classes = [IsAuthenticated]
    serializer_class = ProfileSerializer

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.user_repository = UserRepository()

    @extend_schema(
        description="Retrieve the authenticated user's profile information.",
        operation_id='get_profile',
        tags=["Profile"],
    )
    def get(self, request):
        user = request.user
        serializer = ProfileSerializer(instance=user)
        return ApiResponse.success(
            message=get_message('fetched_successfully'),
            data=serializer.data
        )

    @extend_schema(
        description="Updates the authenticated user's profile. Any subset of the writable fields "
                    "may be sent; unset fields are left untouched.",
        operation_id='update_profile',
        tags=["Profile"],
        request=ProfileSerializer,
    )
    def patch(self, request):
        serializer = ProfileSerializer(instance=request.user, data=request.data, partial=True)
        if not serializer.is_valid():
            return ApiResponse.validation_error(data=serializer.errors)

        self.user_repository.update_profile(request.user, **serializer.validated_data)

        return ApiResponse.success(
            message=get_message('updated_successfully'),
            data=ProfileSerializer(instance=request.user).data
        )


class AcceptTermsAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.user_repository = UserRepository()

    @extend_schema(
        description="Records that the authenticated user has accepted the current Terms & Privacy Policy version.",
        tags=["Profile"],
    )
    def post(self, request):
        user = self.user_repository.accept_terms(request.user)
        serializer = ProfileSerializer(instance=user)
        return ApiResponse.success(
            message=get_message('terms_accepted_successfully'),
            data=serializer.data
        )


class DeleteAccountAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.user_service = UserService()

    @extend_schema(
        description="Soft-deletes the authenticated user's account and all of their data "
                    "(assessment attempts, memories, generation logs, feedback), and blacklists "
                    "all of their active JWT tokens.",
        tags=["Profile"],
    )
    def post(self, request):
        self.user_service.delete_account(request.user)
        return ApiResponse.success(message=get_message('account_deleted_successfully'))
