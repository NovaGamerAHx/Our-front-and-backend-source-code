from drf_spectacular.utils import extend_schema
from rest_framework.permissions import AllowAny
from rest_framework.views import APIView

from apps.account.serializers.demographics_serializer import DemographicsSerializer
from apps.account.services.demographics_service import DemographicsService
from faraman_back.lang.utils import get_message
from faraman_back.utils.responses import ApiResponse


class DemographicsAPIView(APIView):
    permission_classes = [AllowAny]
    serializer_class = DemographicsSerializer

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.demographics_service = DemographicsService()

    @extend_schema(
        description="Returns the demographic answers (birth year, gender, life situation, goal) "
                    "recorded so far for the authenticated user, or for anonymous_id before signup. "
                    "`answered` is true if any of them has been set, driving the front-end's choice "
                    "between the demographic form and the 'you already told us this' shortcut.",
        tags=["Profile"],
    )
    def get(self, request):
        user = request.user if request.user.is_authenticated else None
        data = self.demographics_service.get(user=user, anonymous_id=request.anonymous_id)

        return ApiResponse.success(data=data)

    @extend_schema(
        description="Submits (or updates) demographic answers. All fields are optional and can be "
                    "sent one at a time or together; unset fields are left untouched. Works before "
                    "signup (stored against anonymous_id) and after (stored on the user directly).",
        tags=["Profile"],
        request=DemographicsSerializer,
    )
    def patch(self, request):
        ser = DemographicsSerializer(data=request.data, partial=True)
        if not ser.is_valid():
            return ApiResponse.validation_error(data=ser.errors)

        user = request.user if request.user.is_authenticated else None
        data = self.demographics_service.submit(
            user=user, anonymous_id=request.anonymous_id, **ser.validated_data
        )

        return ApiResponse.success(message=get_message("updated_successfully"), data=data)
