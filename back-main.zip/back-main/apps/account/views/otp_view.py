from drf_spectacular.utils import extend_schema
from rest_framework.permissions import AllowAny
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken

from apps.account.serializers.otp_serializer import RequestOTPSerializer, VerifyOTPSerializer
from apps.account.serializers.user_serializer import ProfileSerializer
from apps.account.services.exceptions import (
    InvalidOTPException,
    OtpGenerationError,
    OtpRequestThrottledException,
    SmsDeliveryError,
    SmsServiceMisconfiguredException,
    UserNotFoundException,
)
from apps.account.services.otp_service import OtpService
from faraman_back.lang.utils import get_message
from faraman_back.utils.responses import ApiResponse
from faraman_back.utils.schema import error_responses


class RequestOTPAPIView(APIView):
    permission_classes = [AllowAny]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.otp_service = OtpService()

    @extend_schema(
        description="Receives a phone number and sends an OTP via SMS. Used for both signup and login.",
        tags=["Authentication"],
        request=RequestOTPSerializer,
        responses=error_responses(
            OtpGenerationError, SmsDeliveryError, SmsServiceMisconfiguredException, OtpRequestThrottledException,
        ),
    )
    def post(self, request):
        ser = RequestOTPSerializer(data=request.data)
        if not ser.is_valid():
            return ApiResponse.validation_error(data=ser.errors)

        phone_number = ser.validated_data['phone_number'].strip()

        self.otp_service.request_otp(
            phone_number,
            utm_source=ser.validated_data['utm_source'].strip(),
            utm_campaign=ser.validated_data['utm_campaign'].strip(),
        )

        return ApiResponse.success(message=get_message('sms_sent'))


class VerifyOTPAPIView(APIView):
    permission_classes = [AllowAny]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.otp_service = OtpService()

    @extend_schema(
        description="Verifies the provided phone number and OTP code, then returns JWT access and refresh tokens.",
        tags=["Authentication"],
        request=VerifyOTPSerializer,
        responses=error_responses(UserNotFoundException, InvalidOTPException),
    )
    def post(self, request):
        ser = VerifyOTPSerializer(data=request.data)
        if not ser.is_valid():
            return ApiResponse.validation_error(
                data=ser.errors
            )

        phone_number = ser.validated_data['phone_number'].strip()
        code = ser.validated_data['code'].strip()

        user = self.otp_service.verify_otp(phone_number, code, anonymous_id=request.anonymous_id)

        refresh = RefreshToken.for_user(user)
        access_token = str(refresh.access_token)
        refresh_token = str(refresh)

        profile = ProfileSerializer(instance=user)

        return ApiResponse.success(
            message=get_message('successful_login'),
            data={
                'access': access_token,
                'refresh': refresh_token,
                'user': profile.data,
            })
