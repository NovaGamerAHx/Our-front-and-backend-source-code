from django.contrib import admin

from apps.account.models import User


@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ("id", "phone_number", "name", "gender", "created_at", "last_login_at", "is_active", "is_staff", "is_deleted")
    list_filter = ("is_active", "is_staff", "is_deleted", "gender", "life_situation", "goal")
    search_fields = ("phone_number", "name", "reference_code")
    ordering = ("-created_at",)
    exclude = ("password", "groups", "user_permissions")
    readonly_fields = ("reference_code", "created_at", "last_login_at", "terms_accepted_at", "deleted_at")

    def has_add_permission(self, request):
        # Auth is phone + OTP; users are created by the login flow, not by hand.
        return False
