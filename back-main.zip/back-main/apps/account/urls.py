from django.urls import path

from apps.account.views.demographics_view import DemographicsAPIView
from apps.account.views.otp_view import RequestOTPAPIView, VerifyOTPAPIView
from apps.account.views.user_view import (
    AcceptTermsAPIView, DeleteAccountAPIView, TokenRefreshAPIView, LogoutAPIView, ProfileAPIView,
)

app_name = "account"

urlpatterns = [
    path("otp/send/", RequestOTPAPIView.as_view(), name="send_otp"),
    path("otp/verify/", VerifyOTPAPIView.as_view(), name="verify_otp"),
    path("token/refresh/", TokenRefreshAPIView.as_view(), name="refresh_token"),
    path("logout/", LogoutAPIView.as_view(), name="logout"),
    path("profile/", ProfileAPIView.as_view(), name="profile"),
    path("profile/demographics/", DemographicsAPIView.as_view(), name="demographics"),
    path("terms/accept/", AcceptTermsAPIView.as_view(), name="accept_terms"),
    path("delete/", DeleteAccountAPIView.as_view(), name="delete_account"),
]
