from django.conf import settings
from django.utils import timezone

from apps.account.models import User


class UserRepository:
    def get_or_create_by_phone(self, phone_number: str, utm_source: str = '', utm_campaign: str = '') -> User:
        # UTM values only apply when the row is created: attribution is first-touch, so a returning
        # user logging in through a different campaign link never overwrites it.
        user, _ = User.objects.get_or_create(
            phone_number=phone_number,
            defaults={'utm_source': utm_source, 'utm_campaign': utm_campaign},
        )
        return user

    def get_by_phone(self, phone_number: str) -> User | None:
        return User.objects.filter(phone_number=phone_number).first()

    def update_last_login(self, user: User) -> None:
        user.last_login_at = timezone.now()
        user.save(update_fields=['last_login_at'])

    def accept_terms(self, user: User) -> User:
        user.terms_version = settings.TERMS_VERSION
        user.terms_accepted_at = timezone.now()
        user.save(update_fields=['terms_version', 'terms_accepted_at'])
        return user

    def update_profile(self, user: User, **fields) -> User:
        for key, value in fields.items():
            setattr(user, key, value)
        user.save(update_fields=list(fields))
        return user

    def soft_delete(self, user: User) -> User:
        user.is_deleted = True
        user.deleted_at = timezone.now()
        user.is_active = False
        user.save(update_fields=['is_deleted', 'deleted_at', 'is_active'])
        return user

    def reactivate(self, user: User) -> User:
        user.is_deleted = False
        user.deleted_at = None
        user.is_active = True
        user.save(update_fields=['is_deleted', 'deleted_at', 'is_active'])
        return user
