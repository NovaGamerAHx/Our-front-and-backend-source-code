from rest_framework_simplejwt.token_blacklist.models import BlacklistedToken, OutstandingToken

from apps.account.models import User


class TokenRepository:
    def blacklist_all_for_user(self, user: User) -> None:
        already_blacklisted = BlacklistedToken.objects.filter(
            token__user=user
        ).values_list("token_id", flat=True)
        to_blacklist = [
            BlacklistedToken(token=token)
            for token in OutstandingToken.objects.filter(user=user).exclude(
                id__in=already_blacklisted
            )
        ]
        BlacklistedToken.objects.bulk_create(to_blacklist, ignore_conflicts=True)
