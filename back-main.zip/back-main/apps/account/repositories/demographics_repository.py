from apps.account.models import AnonymousDemographics


class DemographicsRepository:
    def get_anonymous(self, anonymous_id: str) -> AnonymousDemographics | None:
        return AnonymousDemographics.objects.filter(anonymous_id=anonymous_id).first()

    def upsert_anonymous(self, anonymous_id: str, **fields) -> AnonymousDemographics:
        record, _ = AnonymousDemographics.objects.update_or_create(
            anonymous_id=anonymous_id, defaults=fields
        )
        return record

    def delete_anonymous(self, anonymous_id: str) -> None:
        AnonymousDemographics.objects.filter(anonymous_id=anonymous_id).delete()
