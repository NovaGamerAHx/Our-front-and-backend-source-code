import logging

import redis
from django.conf import settings

logger = logging.getLogger(__name__)

OTP_TTL_SECONDS = 300  # 5min


class OtpRepository:
    def __init__(self):
        self._client = None

    @property
    def client(self):
        if self._client is None:
            self._client = redis.StrictRedis(
                host=getattr(settings, 'REDIS_HOST', 'localhost'),
                port=getattr(settings, 'REDIS_PORT', 6379),
                db=getattr(settings, 'REDIS_DB', 0),
                password=getattr(settings, 'REDIS_PASSWORD', ''),
                decode_responses=True,
            )
        return self._client

    @staticmethod
    def _key(phone_number: str) -> str:
        return f"otp:{phone_number}"

    @staticmethod
    def _attempts_key(phone_number: str) -> str:
        return f"otp_attempts:{phone_number}"

    def save(self, phone_number: str, hashed_code: str) -> bool:
        try:
            self.client.setex(self._key(phone_number), OTP_TTL_SECONDS, hashed_code)
            return True
        except Exception:
            logger.exception(f"Failed to save otp for: {phone_number}")
            return False

    def get(self, phone_number: str):
        try:
            return self.client.get(self._key(phone_number))
        except Exception:
            logger.exception(f"Failed to get otp for: {phone_number}")
            return None

    def exists(self, phone_number: str) -> bool:
        try:
            return bool(self.client.exists(self._key(phone_number)))
        except Exception:
            logger.exception(f"Failed to check otp existence for: {phone_number}")
            return False

    def delete(self, phone_number: str) -> bool:
        try:
            self.client.delete(self._key(phone_number), self._attempts_key(phone_number))
            return True
        except Exception:
            logger.exception(f"Failed to delete otp for: {phone_number}")
            return False

    def increment_attempts(self, phone_number: str) -> int:
        """Increment the wrong-attempt counter for a phone number's active OTP.

        The counter shares the OTP's TTL so it never outlives the code it's guarding.
        """
        try:
            key = self._attempts_key(phone_number)
            count = self.client.incr(key)
            if count == 1:
                self.client.expire(key, OTP_TTL_SECONDS)
            return count
        except Exception:
            logger.exception(f"Failed to increment otp attempts for: {phone_number}")
            return 0
