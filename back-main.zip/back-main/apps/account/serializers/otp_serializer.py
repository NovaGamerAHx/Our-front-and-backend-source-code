import re

from rest_framework import serializers

from faraman_back.lang.utils import get_message


def validate_phone_number(value):
    if not re.fullmatch(r'^09\d{9}$', value):
        raise serializers.ValidationError(
            get_message('invalid_phone_number')
        )
    return value


class RequestOTPSerializer(serializers.Serializer):
    phone_number = serializers.CharField(max_length=20, required=True, validators=[validate_phone_number])
    utm_source = serializers.CharField(max_length=100, required=False, allow_blank=True, default='')
    utm_campaign = serializers.CharField(max_length=100, required=False, allow_blank=True, default='')


class VerifyOTPSerializer(serializers.Serializer):
    phone_number = serializers.CharField(max_length=20, required=True, validators=[validate_phone_number])
    code = serializers.CharField(max_length=5, required=True)

    def validate_code(self, value):
        if not re.fullmatch(r'^\d{5}$', value):
            raise serializers.ValidationError(
                get_message('invalid_otp_code')
            )
        return value