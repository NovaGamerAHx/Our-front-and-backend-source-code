from rest_framework import serializers

from apps.account.models import User


class ProfileSerializer(serializers.ModelSerializer):
    name = serializers.CharField(max_length=100, allow_blank=True, allow_null=True)
    gender = serializers.ChoiceField(choices=User.Gender.choices, allow_blank=True, allow_null=True)
    age = serializers.IntegerField(allow_null=True)
    education = serializers.CharField(max_length=100, allow_blank=True, allow_null=True)
    job = serializers.CharField(max_length=100, allow_blank=True, allow_null=True)
    birth_year = serializers.IntegerField(required=False, allow_null=True, min_value=1300, max_value=1450)
    life_situation = serializers.ChoiceField(choices=User.LifeSituation.choices, required=False, allow_null=True)
    goal = serializers.ChoiceField(choices=User.Goal.choices, required=False, allow_null=True)

    class Meta:
        model = User
        fields = ['id', 'phone_number', 'name', 'gender', 'age', 'education', 'job', 'disorder',
                  'birth_year', 'life_situation', 'goal', 'reference_code',
                  'terms_version', 'terms_accepted_at']

        read_only_fields = ('id', 'phone_number', 'created_at', 'last_login_at',
                            'recommender', 'reference_code',
                            'used_reference_code', 'is_active', 'is_superuser', 'is_staff',
                            'terms_version', 'terms_accepted_at')


class LogoutSerializer(serializers.Serializer):
    refresh = serializers.CharField(required=True)
