from rest_framework import serializers

from apps.account.models import User


class DemographicsSerializer(serializers.Serializer):
    birth_year = serializers.IntegerField(required=False, allow_null=True, min_value=1300, max_value=1450)
    gender = serializers.ChoiceField(choices=User.Gender.choices, required=False, allow_null=True)
    life_situation = serializers.ChoiceField(choices=User.LifeSituation.choices, required=False, allow_null=True)
    goal = serializers.ChoiceField(choices=User.Goal.choices, required=False, allow_null=True)
