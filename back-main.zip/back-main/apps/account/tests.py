from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from django.test import TestCase, override_settings

from apps.account.services.demographics_service import DemographicsService
from apps.account.services.exceptions import (
    InvalidOTPException,
    OtpRequestThrottledException,
    SmsServiceMisconfiguredException,
)
from apps.account.services.otp_service import OtpService
from apps.account.services.user_service import UserService


class OtpServiceVerifyOtpLinksAnonymousAttemptsTests(TestCase):
    def setUp(self):
        self.user_repository = MagicMock()
        self.otp_repository = MagicMock()
        self.sms_service = MagicMock()
        self.attempt_service = MagicMock()
        self.demographics_service = MagicMock()
        self.service = OtpService(
            user_repository=self.user_repository,
            otp_repository=self.otp_repository,
            sms_service=self.sms_service,
            attempt_service=self.attempt_service,
            demographics_service=self.demographics_service,
        )
        self.user = MagicMock()
        self.user.is_deleted = False
        self.user_repository.get_by_phone.return_value = self.user
        self.otp_repository.get.return_value = self.service._hash_code('12345')

    def test_verify_otp_links_anonymous_attempts_to_user(self):
        result = self.service.verify_otp('09123456789', '12345', anonymous_id='anon-1')

        self.assertIs(result, self.user)
        self.attempt_service.link_anonymous_attempts.assert_called_once_with(user=self.user, anonymous_id='anon-1')
        self.demographics_service.claim_for_user.assert_called_once_with(user=self.user, anonymous_id='anon-1')
        self.user_repository.reactivate.assert_not_called()


class OtpServiceRequestThrottleTests(TestCase):
    def setUp(self):
        self.user_repository = MagicMock()
        self.otp_repository = MagicMock()
        self.sms_service = MagicMock()
        self.service = OtpService(
            user_repository=self.user_repository,
            otp_repository=self.otp_repository,
            sms_service=self.sms_service,
        )

    def test_request_otp_blocked_when_key_already_exists(self):
        self.otp_repository.exists.return_value = True

        with self.assertRaises(OtpRequestThrottledException):
            self.service.request_otp('09123456789')

        self.user_repository.get_or_create_by_phone.assert_not_called()
        self.otp_repository.save.assert_not_called()
        self.sms_service.send_single.assert_not_called()

    def test_request_otp_passes_utm_to_user_creation(self):
        self.otp_repository.exists.return_value = False
        self.otp_repository.save.return_value = True
        self.sms_service.send_single.return_value = True

        self.service.request_otp('09123456789', utm_source='telegram', utm_campaign='launch')

        self.user_repository.get_or_create_by_phone.assert_called_once_with('09123456789', 'telegram', 'launch')

    def test_request_otp_allowed_when_no_key_exists(self):
        self.otp_repository.exists.return_value = False
        self.otp_repository.save.return_value = True
        self.sms_service.send_single.return_value = True

        self.service.request_otp('09123456789')

        self.user_repository.get_or_create_by_phone.assert_called_once_with('09123456789', '', '')
        self.otp_repository.save.assert_called_once()
        self.sms_service.send_single.assert_called_once()


@override_settings(TEST_OTP_PHONE_NUMBERS=['09120000000'], TEST_OTP_CODE='12345')
class OtpServiceTestPhoneBypassTests(TestCase):
    def setUp(self):
        self.user_repository = MagicMock()
        self.otp_repository = MagicMock()
        self.sms_service = MagicMock()
        self.attempt_service = MagicMock()
        self.demographics_service = MagicMock()
        self.service = OtpService(
            user_repository=self.user_repository,
            otp_repository=self.otp_repository,
            sms_service=self.sms_service,
            attempt_service=self.attempt_service,
            demographics_service=self.demographics_service,
        )
        self.user = MagicMock()
        self.user.is_deleted = False
        self.user_repository.get_by_phone.return_value = self.user

    def test_request_otp_skips_redis_and_sms_for_test_number(self):
        self.service.request_otp('09120000000')

        self.user_repository.get_or_create_by_phone.assert_called_once_with('09120000000', '', '')
        self.otp_repository.exists.assert_not_called()
        self.otp_repository.save.assert_not_called()
        self.sms_service.send_single.assert_not_called()

    def test_verify_otp_accepts_fixed_code_for_test_number(self):
        result = self.service.verify_otp('09120000000', '12345', anonymous_id='anon-1')

        self.assertIs(result, self.user)
        self.otp_repository.get.assert_not_called()
        self.otp_repository.delete.assert_not_called()
        self.attempt_service.link_anonymous_attempts.assert_called_once_with(user=self.user, anonymous_id='anon-1')
        self.demographics_service.claim_for_user.assert_called_once_with(user=self.user, anonymous_id='anon-1')

    def test_verify_otp_rejects_wrong_code_for_test_number(self):
        with self.assertRaises(InvalidOTPException):
            self.service.verify_otp('09120000000', '00000')


class OtpServiceVerifyOtpReactivatesDeletedUserTests(TestCase):
    def setUp(self):
        self.user_repository = MagicMock()
        self.otp_repository = MagicMock()
        self.sms_service = MagicMock()
        self.attempt_service = MagicMock()
        self.demographics_service = MagicMock()
        self.service = OtpService(
            user_repository=self.user_repository,
            otp_repository=self.otp_repository,
            sms_service=self.sms_service,
            attempt_service=self.attempt_service,
            demographics_service=self.demographics_service,
        )
        self.user = MagicMock()
        self.user_repository.get_by_phone.return_value = self.user
        self.otp_repository.get.return_value = self.service._hash_code('12345')

    def test_verify_otp_reactivates_soft_deleted_user(self):
        self.user.is_deleted = True

        self.service.verify_otp('09123456789', '12345', anonymous_id=None)

        self.user_repository.reactivate.assert_called_once_with(self.user)

    def test_verify_otp_does_not_reactivate_active_user(self):
        self.user.is_deleted = False

        self.service.verify_otp('09123456789', '12345', anonymous_id=None)

        self.user_repository.reactivate.assert_not_called()


class OtpServiceVerifyOtpBruteForceProtectionTests(TestCase):
    def setUp(self):
        self.user_repository = MagicMock()
        self.otp_repository = MagicMock()
        self.sms_service = MagicMock()
        self.attempt_service = MagicMock()
        self.demographics_service = MagicMock()
        self.service = OtpService(
            user_repository=self.user_repository,
            otp_repository=self.otp_repository,
            sms_service=self.sms_service,
            attempt_service=self.attempt_service,
            demographics_service=self.demographics_service,
        )
        self.user = MagicMock()
        self.user.is_deleted = False
        self.user_repository.get_by_phone.return_value = self.user
        self.otp_repository.get.return_value = self.service._hash_code('12345')

    def test_wrong_code_registers_a_failed_attempt(self):
        self.otp_repository.increment_attempts.return_value = 1

        with self.assertRaises(InvalidOTPException):
            self.service.verify_otp('09123456789', '00000')

        self.otp_repository.increment_attempts.assert_called_once_with('09123456789')
        self.otp_repository.delete.assert_not_called()

    @override_settings(OTP_MAX_VERIFY_ATTEMPTS=5)
    def test_wrong_code_invalidates_otp_once_max_attempts_reached(self):
        self.otp_repository.increment_attempts.return_value = 5

        with self.assertRaises(InvalidOTPException):
            self.service.verify_otp('09123456789', '00000')

        self.otp_repository.delete.assert_called_once_with('09123456789')

    def test_no_stored_code_does_not_register_an_attempt(self):
        self.otp_repository.get.return_value = None

        with self.assertRaises(InvalidOTPException):
            self.service.verify_otp('09123456789', '00000')

        self.otp_repository.increment_attempts.assert_not_called()

    def test_correct_code_does_not_register_an_attempt(self):
        self.service.verify_otp('09123456789', '12345')

        self.otp_repository.increment_attempts.assert_not_called()


class OtpServiceLazySmsServiceTests(TestCase):
    def setUp(self):
        self.user_repository = MagicMock()
        self.otp_repository = MagicMock()
        self.service = OtpService(
            user_repository=self.user_repository,
            otp_repository=self.otp_repository,
        )

    @patch('apps.account.services.otp_service.SMSService')
    def test_sms_service_not_constructed_until_accessed(self, mock_sms_service_cls):
        OtpService(user_repository=self.user_repository, otp_repository=self.otp_repository)

        mock_sms_service_cls.assert_not_called()

    @patch('apps.account.services.otp_service.SMSService')
    def test_sms_service_constructed_lazily_on_first_access(self, mock_sms_service_cls):
        mock_instance = MagicMock()
        mock_sms_service_cls.return_value = mock_instance

        result = self.service.sms_service

        self.assertIs(result, mock_instance)
        mock_sms_service_cls.assert_called_once()

    @patch(
        'apps.account.services.otp_service.SMSService',
        side_effect=SmsServiceMisconfiguredException('missing creds'),
    )
    def test_request_otp_raises_domain_exception_when_sms_misconfigured(self, mock_sms_service_cls):
        self.otp_repository.exists.return_value = False

        with self.assertRaises(SmsServiceMisconfiguredException):
            self.service.request_otp('09123456789')


class UserServiceDeleteAccountTests(TestCase):
    def setUp(self):
        self.user_repository = MagicMock()
        self.token_repository = MagicMock()
        self.attempt_repository = MagicMock()
        self.memory_repository = MagicMock()
        self.generation_log_repository = MagicMock()
        self.feedback_repository = MagicMock()
        self.chat_generation_log_repository = MagicMock()
        self.report_email_delivery_repository = MagicMock()
        self.service = UserService(
            user_repository=self.user_repository,
            token_repository=self.token_repository,
            attempt_repository=self.attempt_repository,
            memory_repository=self.memory_repository,
            generation_log_repository=self.generation_log_repository,
            feedback_repository=self.feedback_repository,
            chat_generation_log_repository=self.chat_generation_log_repository,
            report_email_delivery_repository=self.report_email_delivery_repository,
        )
        self.user = MagicMock()

    def test_delete_account_soft_deletes_user_and_all_owned_data(self):
        self.service.delete_account(self.user)

        self.user_repository.soft_delete.assert_called_once_with(self.user)
        self.attempt_repository.soft_delete_for_user.assert_called_once_with(self.user)
        self.memory_repository.soft_delete_for_user.assert_called_once_with(self.user)
        self.generation_log_repository.soft_delete_for_user.assert_called_once_with(self.user)
        self.chat_generation_log_repository.soft_delete_for_user.assert_called_once_with(self.user)
        self.feedback_repository.soft_delete_for_user.assert_called_once_with(self.user)
        self.report_email_delivery_repository.soft_delete_for_user.assert_called_once_with(self.user)
        self.token_repository.blacklist_all_for_user.assert_called_once_with(self.user)


def _demographics(**overrides):
    fields = {'birth_year': None, 'gender': None, 'life_situation': None, 'goal': None}
    fields.update(overrides)
    return SimpleNamespace(**fields)


class DemographicsServiceGetTests(TestCase):
    def setUp(self):
        self.demographics_repository = MagicMock()
        self.user_repository = MagicMock()
        self.service = DemographicsService(
            demographics_repository=self.demographics_repository,
            user_repository=self.user_repository,
        )

    def test_reads_from_user_when_authenticated(self):
        user = _demographics(birth_year=1370, gender='male')

        result = self.service.get(user=user, anonymous_id='anon-1')

        self.assertEqual(result, {'birth_year': 1370, 'gender': 'male', 'life_situation': None, 'goal': None, 'answered': True})
        self.demographics_repository.get_anonymous.assert_not_called()

    def test_reads_from_anonymous_record_when_no_user(self):
        self.demographics_repository.get_anonymous.return_value = _demographics(goal='purpose')

        result = self.service.get(user=None, anonymous_id='anon-1')

        self.assertEqual(result['goal'], 'purpose')
        self.assertTrue(result['answered'])
        self.demographics_repository.get_anonymous.assert_called_once_with('anon-1')

    def test_answered_false_when_nothing_recorded(self):
        self.demographics_repository.get_anonymous.return_value = None

        result = self.service.get(user=None, anonymous_id='anon-1')

        self.assertFalse(result['answered'])

    def test_answered_false_when_no_anonymous_id_and_no_user(self):
        result = self.service.get(user=None, anonymous_id=None)

        self.assertFalse(result['answered'])
        self.demographics_repository.get_anonymous.assert_not_called()


class DemographicsServiceSubmitTests(TestCase):
    def setUp(self):
        self.demographics_repository = MagicMock()
        self.user_repository = MagicMock()
        self.service = DemographicsService(
            demographics_repository=self.demographics_repository,
            user_repository=self.user_repository,
        )

    def test_submit_updates_user_when_authenticated(self):
        user = _demographics(birth_year=1370)

        self.service.submit(user=user, anonymous_id=None, gender='female')

        self.user_repository.update_profile.assert_called_once_with(user, gender='female')
        self.demographics_repository.upsert_anonymous.assert_not_called()

    def test_submit_upserts_anonymous_record_when_no_user(self):
        self.demographics_repository.get_anonymous.return_value = _demographics(gender='female')

        self.service.submit(user=None, anonymous_id='anon-1', goal='stress')

        self.demographics_repository.upsert_anonymous.assert_called_once_with('anon-1', goal='stress')

    def test_submit_ignores_unknown_fields(self):
        user = _demographics()

        self.service.submit(user=user, anonymous_id=None, gender='female', unrelated='x')

        self.user_repository.update_profile.assert_called_once_with(user, gender='female')

    def test_submit_no_fields_does_not_touch_storage(self):
        self.service.submit(user=None, anonymous_id='anon-1')

        self.user_repository.update_profile.assert_not_called()
        self.demographics_repository.upsert_anonymous.assert_not_called()


class DemographicsServiceClaimForUserTests(TestCase):
    def setUp(self):
        self.demographics_repository = MagicMock()
        self.user_repository = MagicMock()
        self.service = DemographicsService(
            demographics_repository=self.demographics_repository,
            user_repository=self.user_repository,
        )
        self.user = _demographics()

    def test_noop_when_no_anonymous_id(self):
        self.service.claim_for_user(user=self.user, anonymous_id=None)

        self.demographics_repository.get_anonymous.assert_not_called()

    def test_noop_when_no_anonymous_record(self):
        self.demographics_repository.get_anonymous.return_value = None

        self.service.claim_for_user(user=self.user, anonymous_id='anon-1')

        self.user_repository.update_profile.assert_not_called()
        self.demographics_repository.delete_anonymous.assert_not_called()

    def test_copies_only_answered_fields_and_deletes_anonymous_record(self):
        self.demographics_repository.get_anonymous.return_value = _demographics(birth_year=1370, goal='stress')

        self.service.claim_for_user(user=self.user, anonymous_id='anon-1')

        self.user_repository.update_profile.assert_called_once_with(self.user, birth_year=1370, goal='stress')
        self.demographics_repository.delete_anonymous.assert_called_once_with('anon-1')
