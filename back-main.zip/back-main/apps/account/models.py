import random
import string
from django.contrib.auth.base_user import BaseUserManager
from django.db import models
from django.utils import timezone
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin


def generate_reference_code(length=10):
    """Generates a unique 10-character alphanumeric reference code."""
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))


class UserManager(BaseUserManager):
    def create_user(self, phone_number, password=None, **extra_fields):
        if not phone_number:
            raise ValueError("Phone number is required")
        user = self.model(phone_number=phone_number, **extra_fields)
        user.set_password(password)
        # Generate unique reference code on creation
        if not user.reference_code:
            while True:
                code = generate_reference_code()
                if not User.objects.filter(reference_code=code).exists():
                    user.reference_code = code
                    break
        user.save(using=self._db)
        return user

    def create_superuser(self, phone_number, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        return self.create_user(phone_number, password, **extra_fields)


class User(AbstractBaseUser, PermissionsMixin):
    class Gender(models.TextChoices):
        FEMALE = 'female', 'Female'
        MALE = 'male', 'Male'

    class LifeSituation(models.TextChoices):
        STUDENT = 'student', 'در حال تحصیل'
        EMPLOYED = 'employed', 'شاغل'
        SELF_EMPLOYED = 'self_employed', 'فریلنسر یا صاحب کسب‌وکار'
        JOB_SEEKING = 'job_seeking', 'در جست‌وجوی کار'
        TRANSITIONING = 'transitioning', 'در حال تغییر مسیر شغلی'
        FAMILY_CARE = 'family_care', 'مشغول رسیدگی به خانه و خانواده'
        OTHER = 'other', 'سایر'

    class Goal(models.TextChoices):
        DECISIONS = 'decisions', 'بهتر تصمیم بگیرم'
        MASTERY = 'mastery', 'منظم‌تر باشم'
        GROWTH = 'growth', 'یاد بگیرم و پیشرفت کنم'
        RELATIONSHIPS = 'relationships', 'روابط بهتری داشته باشم'
        PURPOSE = 'purpose', 'در کارم پیشرفت کنم'
        SELF_REGARD = 'self_regard', 'اعتمادبه‌نفس بیشتری داشته باشم'
        STRESS = 'stress', 'آرام‌تر باشم'
        UNSURE = 'unsure', 'هنوز مطمئن نیستم'

    phone_number = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=100, null=True, blank=True)
    gender = models.CharField(max_length=20, choices=Gender.choices, null=True, blank=True)
    age = models.CharField(max_length=10, null=True, blank=True)
    education = models.CharField(max_length=100, null=True, blank=True)
    job = models.CharField(max_length=100, null=True, blank=True)
    disorder = models.CharField(max_length=200, null=True, blank=True)
    birth_year = models.PositiveSmallIntegerField(null=True, blank=True)
    life_situation = models.CharField(max_length=30, choices=LifeSituation.choices, null=True, blank=True)
    goal = models.CharField(max_length=30, choices=Goal.choices, null=True, blank=True)
    created_at = models.DateTimeField(default=timezone.now)
    last_login_at = models.DateTimeField(null=True, blank=True)
    recommender = models.CharField(max_length=100, null=True, blank=True)
    reference_code = models.CharField(max_length=100, unique=True, editable=False)
    used_reference_code = models.CharField(max_length=100, null=True, blank=True)
    terms_version = models.CharField(max_length=50, null=True, blank=True)
    terms_accepted_at = models.DateTimeField(null=True, blank=True)
    # First-touch campaign attribution, captured from the signup request; blank when the visitor had no UTM params.
    utm_source = models.CharField(max_length=100, blank=True, default='')
    utm_campaign = models.CharField(max_length=100, blank=True, default='')

    # Django auth fields
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)

    objects = UserManager()

    USERNAME_FIELD = "phone_number"
    REQUIRED_FIELDS = []

    class Meta:
        db_table = "users"

    def __str__(self):
        return self.phone_number or f"User {self.id}"

    def save(self, *args, **kwargs):
        """Generate reference code only once for new users"""
        if not self.pk and not self.reference_code:
            while True:
                code = generate_reference_code()
                if not User.objects.filter(reference_code=code).exists():
                    self.reference_code = code
                    break
        super().save(*args, **kwargs)

    def to_dict(self, include_sensitive=False):
        """Return user data as dictionary."""
        data = {
            "id": self.id,
            "phone_number": self.phone_number,
            "name": self.name,
            "gender": self.gender,
            "age": self.age,
            "education": self.education,
            "job": self.job,
            "disorder": self.disorder,
            "created_at": self.created_at.isoformat(),
            "last_login_at": self.last_login_at.isoformat() if self.last_login_at else None,
            "profile_complete": bool(self.gender and self.age and self.education and self.job and self.disorder),
        }
        return data


class AnonymousDemographics(models.Model):
    """Demographic answers collected before signup, keyed by the AnonymousIdMiddleware cookie.

    One row per anonymous_id, overwritten in place — mirrors how a User's own demographic fields
    behave once they're logged in. Claimed (copied onto the User, then deleted) on login by
    DemographicsService.claim_for_user, the same pattern Attempt uses for anonymous test data."""

    anonymous_id = models.CharField(max_length=64, unique=True, db_index=True)
    birth_year = models.PositiveSmallIntegerField(null=True, blank=True)
    gender = models.CharField(max_length=20, choices=User.Gender.choices, null=True, blank=True)
    life_situation = models.CharField(max_length=30, choices=User.LifeSituation.choices, null=True, blank=True)
    goal = models.CharField(max_length=30, choices=User.Goal.choices, null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "anonymous_demographics"

    def __str__(self):
        return f"Demographics for anonymous {self.anonymous_id}"
