import os

from django.core.management.base import BaseCommand

from apps.account.models import User


class Command(BaseCommand):
    help = (
        "Ensures a default superuser exists, from DJANGO_SUPERUSER_PHONE_NUMBER / "
        "DJANGO_SUPERUSER_PASSWORD env vars. Idempotent: does nothing if a user with "
        "that phone number already exists, so it's safe to run on every deploy."
    )

    def handle(self, *args, **options):
        phone_number = os.getenv("DJANGO_SUPERUSER_PHONE_NUMBER")
        password = os.getenv("DJANGO_SUPERUSER_PASSWORD")

        if not phone_number or not password:
            self.stdout.write(self.style.WARNING(
                "DJANGO_SUPERUSER_PHONE_NUMBER / DJANGO_SUPERUSER_PASSWORD not set, skipping."
            ))
            return

        if User.objects.filter(phone_number=phone_number).exists():
            self.stdout.write(f"Superuser {phone_number} already exists, skipping.")
            return

        User.objects.create_superuser(phone_number=phone_number, password=password)
        self.stdout.write(self.style.SUCCESS(f"Created superuser {phone_number}."))
