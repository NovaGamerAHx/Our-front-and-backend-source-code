from django.db import transaction

from apps.account.models import User
from apps.account.repositories.token_repository import TokenRepository
from apps.account.repositories.user_repository import UserRepository
from apps.assessment.repositories.attempt_repository import AttemptRepository
from apps.chat.repositories.chat_generation_log_repository import ChatGenerationLogRepository
from apps.feedback.repositories.feedback_repository import FeedbackRepository
from apps.report.repositories.generation_log_repository import GenerationLogRepository
from apps.report.repositories.memory_repository import MemoryRepository
from apps.report.repositories.report_email_delivery_repository import ReportEmailDeliveryRepository


class UserService:
    def __init__(
        self, user_repository=None, token_repository=None, attempt_repository=None,
        memory_repository=None, generation_log_repository=None, feedback_repository=None,
        chat_generation_log_repository=None, report_email_delivery_repository=None,
    ):
        self.user_repository = user_repository or UserRepository()
        self.token_repository = token_repository or TokenRepository()
        self.attempt_repository = attempt_repository or AttemptRepository()
        self.memory_repository = memory_repository or MemoryRepository()
        self.generation_log_repository = generation_log_repository or GenerationLogRepository()
        self.feedback_repository = feedback_repository or FeedbackRepository()
        self.chat_generation_log_repository = (
            chat_generation_log_repository or ChatGenerationLogRepository()
        )
        self.report_email_delivery_repository = (
            report_email_delivery_repository or ReportEmailDeliveryRepository()
        )

    def delete_account(self, user: User) -> None:
        """Soft-deletes the user and every directly-owned row (Attempt, Memory, GenerationLog,
        ChatGenerationLog, Feedback, ReportEmailDelivery), then blacklists all of the user's outstanding JWT tokens.
        Report/Answer have no user FK of their own and become invisible once their parent
        Attempt is soft-deleted."""
        with transaction.atomic():
            self.user_repository.soft_delete(user)
            self.attempt_repository.soft_delete_for_user(user)
            self.memory_repository.soft_delete_for_user(user)
            self.generation_log_repository.soft_delete_for_user(user)
            self.chat_generation_log_repository.soft_delete_for_user(user)
            self.feedback_repository.soft_delete_for_user(user)
            self.report_email_delivery_repository.soft_delete_for_user(user)
            self.token_repository.blacklist_all_for_user(user)
