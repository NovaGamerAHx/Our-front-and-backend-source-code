import hashlib
import random

from django.conf import settings

from apps.account.models import User
from apps.account.repositories.otp_repository import OtpRepository
from apps.account.repositories.user_repository import UserRepository
from apps.account.services.exceptions import (
    InvalidOTPException,
    OtpGenerationError,
    OtpRequestThrottledException,
    SmsDeliveryError,
    UserNotFoundException,
)
from apps.account.services.demographics_service import DemographicsService
from apps.account.services.sms_service import SMSService
from apps.assessment.services.attempt_service import AttemptService
from faraman_back.observability.metrics import THROTTLE_REJECTED


class OtpService:
    def __init__(
        self, user_repository=None, otp_repository=None, sms_service=None, attempt_service=None,
        demographics_service=None,
    ):
        self.user_repository = user_repository or UserRepository()
        self.otp_repository = otp_repository or OtpRepository()
        self._sms_service = sms_service
        self.attempt_service = attempt_service or AttemptService()
        self.demographics_service = demographics_service or DemographicsService()

    @property
    def sms_service(self):
        """Built lazily so a misconfigured SMSService only raises once request_otp() actually runs.

        Views construct OtpService in __init__, which is outside DRF dispatch()'s try/except --
        raising here eagerly would bypass app_exception_handler and produce a raw 500.
        """
        if self._sms_service is None:
            self._sms_service = SMSService()
        return self._sms_service

    @staticmethod
    def _generate_code() -> str:
        return f"{random.randint(0, 99999):05d}"

    @staticmethod
    def _hash_code(code: str) -> str:
        return hashlib.sha256(code.encode()).hexdigest()

    @staticmethod
    def _is_test_phone_number(phone_number: str) -> bool:
        return phone_number in settings.TEST_OTP_PHONE_NUMBERS

    def request_otp(self, phone_number: str, utm_source: str = '', utm_campaign: str = '') -> None:
        """Ensure the user exists, issue a new OTP and deliver it via SMS.

        Test phone numbers (settings.TEST_OTP_PHONE_NUMBERS) skip Redis + SMS entirely;
        they're verified with the fixed settings.TEST_OTP_CODE instead.

        utm_source/utm_campaign are stored only if this call creates the user (first-touch).
        """
        if self._is_test_phone_number(phone_number):
            self.user_repository.get_or_create_by_phone(phone_number, utm_source, utm_campaign)
            return

        if self.otp_repository.exists(phone_number):
            THROTTLE_REJECTED.labels(scope="otp_request").inc()
            raise OtpRequestThrottledException(f"OTP already requested for {phone_number}")

        self.user_repository.get_or_create_by_phone(phone_number, utm_source, utm_campaign)

        code = self._generate_code()
        if not self.otp_repository.save(phone_number, self._hash_code(code)):
            raise OtpGenerationError(f"Failed to persist OTP for {phone_number}")

        if not self.sms_service.send_single(phone_number, code):
            raise SmsDeliveryError(f"Failed to deliver OTP SMS to {phone_number}")

    def _register_failed_attempt(self, phone_number: str) -> None:
        """Count a wrong verify attempt and invalidate the OTP once the limit is reached."""
        attempts = self.otp_repository.increment_attempts(phone_number)
        if attempts >= settings.OTP_MAX_VERIFY_ATTEMPTS:
            THROTTLE_REJECTED.labels(scope="otp_verify_lockout").inc()
            self.otp_repository.delete(phone_number)

    def verify_otp(self, phone_number: str, code: str, anonymous_id: str | None = None) -> User:
        """Validate the OTP for a phone number, consume it and return the matching user.

        Also claims any assessment attempts and demographic answers recorded anonymously under
        anonymous_id, so a test taken before signup stays attached to the account once the user
        logs in.
        """
        user = self.user_repository.get_by_phone(phone_number)
        if user is None:
            raise UserNotFoundException(f"No user found for {phone_number}")

        if self._is_test_phone_number(phone_number):
            if code != settings.TEST_OTP_CODE:
                raise InvalidOTPException(f"Invalid OTP code for {phone_number}")
        else:
            stored_code = self.otp_repository.get(phone_number)
            if not stored_code or stored_code != self._hash_code(code):
                if stored_code:
                    self._register_failed_attempt(phone_number)
                raise InvalidOTPException(f"Invalid OTP code for {phone_number}")

            self.otp_repository.delete(phone_number)

        if user.is_deleted:
            self.user_repository.reactivate(user)

        self.user_repository.update_last_login(user)
        self.attempt_service.link_anonymous_attempts(user=user, anonymous_id=anonymous_id)
        self.demographics_service.claim_for_user(user=user, anonymous_id=anonymous_id)

        return user
