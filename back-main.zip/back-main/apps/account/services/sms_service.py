import os
import logging

from melipayamak import Api

from apps.account.services.exceptions import SmsServiceMisconfiguredException

# .env loading now happens once, early, in faraman_back/settings.py -- this module is
# lazy-loaded on first use (see OtpService.sms_service), well after settings.py has already
# run, so calling load_dotenv() again here was redundant and, before that fix, was masking
# the fact that settings.py itself never saw .env outside Docker.
logger = logging.getLogger(__name__)


class SMSService:
    def __init__(self):
        username = os.getenv('MELIPAYAMAK_USERNAME')
        password = os.getenv('MELIPAYAMAK_PASSWORD')
        self.otp_template = os.getenv('MELIPAYAMAK_OTP_TEMPLATE')

        if not username or not password:
            logger.error("Melipayamak credentials missing")
            raise SmsServiceMisconfiguredException("Melipayamak credentials missing")

        api = Api(username, password)
        self.sms_rest = api.sms()

    def send_single(self, phone_number: str, data) -> bool:
        try:
            response = self.sms_rest.send_by_base_number(
                data, phone_number, self.otp_template
            )

            if response.get('StrRetStatus') != 'Ok':
                logger.error("SMS send failed: " + response.get('StrRetStatus'))
                return False

            return True

        except Exception as e:
            logger.exception(f"SMS send failed: {e}")
            return False

    def send_bulk(self, phone_numbers: list[str], data) -> bool:
        try:
            response = self.sms_rest.send_by_base_number(
                data, ','.join(phone_numbers), self.otp_template
            )

            if response.get('StrRetStatus') != 'Ok':
                logger.error("SMS send failed: " + response.get('StrRetStatus'))
                return False

            return True

        except Exception as e:
            logger.exception(f"SMS send failed: {e}")
            return False
