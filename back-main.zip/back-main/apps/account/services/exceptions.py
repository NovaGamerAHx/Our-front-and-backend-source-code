from rest_framework import status

from faraman_back.utils.exceptions import AppException


class OtpGenerationError(AppException):
    """Raised when an OTP could not be generated or persisted."""
    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    message_key = 'system_error'


class SmsDeliveryError(AppException):
    """Raised when an OTP SMS could not be delivered."""
    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    message_key = 'sms_send_failed'


class SmsServiceMisconfiguredException(AppException):
    """Raised when Melipayamak credentials are missing from the environment."""
    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    message_key = 'system_error'


class UserNotFoundException(AppException):
    """Raised when no user exists for the given phone number."""
    status_code = status.HTTP_404_NOT_FOUND
    message_key = 'user_not_found'


class InvalidOTPException(AppException):
    """Raised when the provided OTP code is missing, expired or does not match."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'invalid_code'


class OtpRequestThrottledException(AppException):
    """Raised when a new OTP is requested while a previous one for the same phone number is still active."""
    status_code = status.HTTP_429_TOO_MANY_REQUESTS
    message_key = 'otp_request_throttled'


class InvalidTokenException(AppException):
    """Raised when a refresh token is malformed, expired, or has been blacklisted."""
    status_code = status.HTTP_401_UNAUTHORIZED
    message_key = 'invalid_token'
