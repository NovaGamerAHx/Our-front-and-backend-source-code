from apps.account.models import User
from apps.account.repositories.demographics_repository import DemographicsRepository
from apps.account.repositories.user_repository import UserRepository

DEMOGRAPHIC_FIELDS = ("birth_year", "gender", "life_situation", "goal")


class DemographicsService:
    """Optional, skippable demographic answers (report_spec's post-test block): birth year,
    gender, life situation, current goal. Stored on the User once authenticated; stored on
    AnonymousDemographics (keyed by anonymous_id) before that, and claimed onto the User on
    login — the same shape as how AttemptService.link_anonymous_attempts handles Attempt."""

    def __init__(self, demographics_repository=None, user_repository=None):
        self.demographics_repository = demographics_repository or DemographicsRepository()
        self.user_repository = user_repository or UserRepository()

    def get(self, *, user: User | None, anonymous_id: str | None) -> dict:
        if user is not None:
            values = {field: getattr(user, field) for field in DEMOGRAPHIC_FIELDS}
        else:
            record = self.demographics_repository.get_anonymous(anonymous_id) if anonymous_id else None
            values = {field: getattr(record, field, None) for field in DEMOGRAPHIC_FIELDS}

        values["answered"] = any(value is not None for value in values.values())
        return values

    def submit(self, *, user: User | None, anonymous_id: str | None, **fields) -> dict:
        fields = {key: value for key, value in fields.items() if key in DEMOGRAPHIC_FIELDS}

        if user is not None:
            if fields:
                self.user_repository.update_profile(user, **fields)
        elif anonymous_id and fields:
            self.demographics_repository.upsert_anonymous(anonymous_id, **fields)

        return self.get(user=user, anonymous_id=anonymous_id)

    def claim_for_user(self, *, user: User, anonymous_id: str | None) -> None:
        """Called on login: copies whatever was answered anonymously onto the now-known user
        (most-recent-wins for those specific fields; anything not answered anonymously is left
        as whatever the user already had), then clears the anonymous row."""
        if not anonymous_id:
            return

        record = self.demographics_repository.get_anonymous(anonymous_id)
        if record is None:
            return

        answered = {
            field: getattr(record, field)
            for field in DEMOGRAPHIC_FIELDS
            if getattr(record, field) is not None
        }
        if answered:
            self.user_repository.update_profile(user, **answered)

        self.demographics_repository.delete_anonymous(anonymous_id)
