# Student label shortened: "دانشجو یا در حال تحصیل" said the same thing twice.
# Display label only, stored value ('student') is unchanged, so no data migration.

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('account', '0010_user_utm_attribution'),
    ]

    operations = [
        migrations.AlterField(
            model_name='anonymousdemographics',
            name='life_situation',
            field=models.CharField(blank=True, choices=[('student', 'در حال تحصیل'), ('employed', 'شاغل'), ('self_employed', 'فریلنسر یا صاحب کسب\u200cوکار'), ('job_seeking', 'در جست\u200cوجوی کار'), ('transitioning', 'در حال تغییر مسیر شغلی'), ('family_care', 'مشغول رسیدگی به خانه و خانواده'), ('other', 'سایر')], max_length=30, null=True),
        ),
        migrations.AlterField(
            model_name='user',
            name='life_situation',
            field=models.CharField(blank=True, choices=[('student', 'در حال تحصیل'), ('employed', 'شاغل'), ('self_employed', 'فریلنسر یا صاحب کسب\u200cوکار'), ('job_seeking', 'در جست\u200cوجوی کار'), ('transitioning', 'در حال تغییر مسیر شغلی'), ('family_care', 'مشغول رسیدگی به خانه و خانواده'), ('other', 'سایر')], max_length=30, null=True),
        ),
    ]
