from rest_framework import serializers


class ChatSessionListQuerySerializer(serializers.Serializer):
    """Query params for the history-panel session list: a most-recent-activity-first page. Only
    shape/bounds live here -- the default page size and the max clamp are ChatService's call
    (an absent `limit` is simply not forwarded, so the service default applies)."""

    limit = serializers.IntegerField(required=False, min_value=1)
    offset = serializers.IntegerField(required=False, min_value=0)


class ChatSessionCreateSerializer(serializers.Serializer):
    entry_source = serializers.CharField(max_length=40)
    # Required only for entry_source in (report_cta, report_open_question, deep_report_cta,
    # deep_report_focus:*) --
    # checked in ChatService.create_session, since it needs a DB lookup either way
    # (chat_spec_v2 §1.3/§6.1).
    attempt_id = serializers.IntegerField(required=False, allow_null=True)
    # Required only for entry_source in (action_rejected, action_completed, action_missed,
    # action_active) -- the ActionStep the conversation is about (chat_spec_v3 §1.1/§1.4).
    action_step_id = serializers.UUIDField(required=False, allow_null=True)
    # action_rejected only, and only when action_step_id is omitted: the 1-based index (with
    # attempt_id above) of a report suggested_step/small_action rejected before it was ever
    # accepted -- action_steps_spec_v2_2.md §3. Ignored for every other entry_source.
    index = serializers.IntegerField(required=False, allow_null=True)


class ChatMessageCreateSerializer(serializers.Serializer):
    # Length cap is enforced in ChatService (chat_spec_v3_1.md §6.3) so it raises
    # ChatMessageTooLongException, not a generic DRF validation_error.
    user_message = serializers.CharField(allow_blank=False, trim_whitespace=False)


class ChatSessionResponseSerializer(serializers.Serializer):
    session_id = serializers.UUIDField()
