from rest_framework import serializers


class MessageFeedbackSerializer(serializers.Serializer):
    is_useful = serializers.BooleanField()
