from types import SimpleNamespace
from unittest.mock import MagicMock

from django.test import TestCase
from django.utils import timezone

from apps.account.models import User
from apps.chat.models import CHAT_SESSION_TITLE_MAX_LENGTH, ChatMessage, ChatSession
from apps.chat.repositories.chat_message_repository import ChatMessageRepository
from apps.chat.repositories.chat_session_repository import ChatSessionRepository
from apps.chat.services.chat_service import MAX_SESSION_PAGE_SIZE, ChatService
from apps.chat.services.exceptions import (
    ActionRequiredForEntrySourceException,
    ActionStepNotActiveException,
    ActionStepNotMissedException,
    ChatMessageLimitExceededException,
    ChatMessageNotFoundException,
    ChatMessageTooLongException,
    ChatSessionNotFoundException,
    InvalidEntrySourceException,
    ProposedActionUnavailableException,
    RegenerateNotAllowedException,
    ReportRequiredForEntrySourceException,
    ReportTypeMismatchException,
    ReportVersionMismatchException,
)
from apps.chat.services.message_bookmark_service import MessageBookmarkService
from apps.chat.services.message_feedback_service import MessageFeedbackService
from apps.report.models import Report
from apps.report.services.exceptions import (
    ReportAccessDeniedException,
    ReportNotFoundException,
    ReportNotReadyException,
)
from faraman_back.observability.testing import read_metric


def _service(**overrides):
    message_feedback_repository = MagicMock()
    message_feedback_repository.get_feedback_map.return_value = {}
    message_bookmark_repository = MagicMock()
    message_bookmark_repository.get_bookmarked_message_ids.return_value = set()
    chat_message_throttle_repository = MagicMock()
    chat_message_throttle_repository.hit.return_value = False
    defaults = dict(
        chat_session_repository=MagicMock(),
        chat_message_repository=MagicMock(),
        memory_repository=MagicMock(),
        report_repository=MagicMock(),
        action_step_repository=MagicMock(),
        action_step_service=MagicMock(),
        message_feedback_repository=message_feedback_repository,
        message_bookmark_repository=message_bookmark_repository,
        chat_generation_log_repository=MagicMock(),
        chat_message_throttle_repository=chat_message_throttle_repository,
        ai_client=MagicMock(),
        report_service=MagicMock(),
    )
    defaults.update(overrides)
    return ChatService(**defaults), defaults


class ChatServiceCreateSessionTests(TestCase):
    def setUp(self):
        self.service, self.repos = _service()
        self.user = MagicMock(id=1)

    def test_manual_entry_source_does_not_touch_report_repository(self):
        self.service.create_session(user=self.user, entry_source="manual")

        self.repos["report_repository"].get_by_attempt_id.assert_not_called()
        self.repos["chat_session_repository"].create.assert_called_once_with(
            user=self.user, entry_source="manual", report=None, context_action_step=None,
            context_suggested_step=None,
        )

    def test_invalid_entry_source_raises(self):
        with self.assertRaises(InvalidEntrySourceException):
            self.service.create_session(user=self.user, entry_source="literally anything")

    def test_report_cta_without_attempt_id_raises(self):
        with self.assertRaises(ReportRequiredForEntrySourceException):
            self.service.create_session(user=self.user, entry_source="report_cta")

        self.repos["report_repository"].get_by_attempt_id.assert_not_called()

    def test_report_cta_with_unknown_attempt_raises_not_found(self):
        self.repos["report_repository"].get_by_attempt_id.return_value = None

        with self.assertRaises(ReportNotFoundException):
            self.service.create_session(user=self.user, entry_source="report_cta", attempt_id=99)

    def test_report_cta_with_someone_elses_attempt_raises_access_denied(self):
        report = MagicMock(attempt=MagicMock(user_id=999))
        self.repos["report_repository"].get_by_attempt_id.return_value = report

        with self.assertRaises(ReportAccessDeniedException):
            self.service.create_session(user=self.user, entry_source="report_cta", attempt_id=1)

    def test_report_cta_with_report_still_generating_raises_not_ready(self):
        report = MagicMock(attempt=MagicMock(user_id=self.user.id), status=Report.Status.GENERATING)
        self.repos["report_repository"].get_by_attempt_id.return_value = report

        with self.assertRaises(ReportNotReadyException):
            self.service.create_session(user=self.user, entry_source="report_cta", attempt_id=1)

        self.repos["chat_session_repository"].create.assert_not_called()

    def test_report_cta_with_deep_report_raises_type_mismatch(self):
        report = MagicMock(
            attempt=MagicMock(user_id=self.user.id), status=Report.Status.OK,
            report_type=Report.ReportType.DEEP,
        )
        self.repos["report_repository"].get_by_attempt_id.return_value = report

        with self.assertRaises(ReportTypeMismatchException):
            self.service.create_session(user=self.user, entry_source="report_cta", attempt_id=1)

        self.repos["chat_session_repository"].create.assert_not_called()

    def test_report_open_question_with_owned_v2_initial_report_creates_session_bound_to_it(self):
        report = MagicMock(
            attempt=MagicMock(user_id=self.user.id), status=Report.Status.OK,
            report_type=Report.ReportType.INITIAL, report_version="report_v2",
        )
        self.repos["report_repository"].get_by_attempt_id.return_value = report

        self.service.create_session(user=self.user, entry_source="report_open_question", attempt_id=1)

        self.repos["chat_session_repository"].create.assert_called_once_with(
            user=self.user, entry_source="report_open_question", report=report, context_action_step=None,
            context_suggested_step=None,
        )

    def test_report_finding_focus_with_owned_v2_report_creates_session_bound_to_it(self):
        report = MagicMock(
            attempt=MagicMock(user_id=self.user.id), status=Report.Status.OK,
            report_type=Report.ReportType.INITIAL, report_version="report_v2",
        )
        self.repos["report_repository"].get_by_attempt_id.return_value = report

        for entry_source in ("report_finding_focus:0", "report_finding_focus:1"):
            self.repos["chat_session_repository"].create.reset_mock()
            self.service.create_session(user=self.user, entry_source=entry_source, attempt_id=1)
            self.repos["chat_session_repository"].create.assert_called_once_with(
                user=self.user, entry_source=entry_source, report=report, context_action_step=None,
                context_suggested_step=None,
            )

    def test_report_finding_focus_rejects_unknown_index_missing_attempt_v1_and_deep(self):
        with self.assertRaises(InvalidEntrySourceException):
            self.service.create_session(user=self.user, entry_source="report_finding_focus:2", attempt_id=1)
        with self.assertRaises(ReportRequiredForEntrySourceException):
            self.service.create_session(user=self.user, entry_source="report_finding_focus:0")

        v1 = MagicMock(
            attempt=MagicMock(user_id=self.user.id), status=Report.Status.OK,
            report_type=Report.ReportType.INITIAL, report_version="report_v1",
        )
        self.repos["report_repository"].get_by_attempt_id.return_value = v1
        with self.assertRaises(ReportVersionMismatchException):
            self.service.create_session(user=self.user, entry_source="report_finding_focus:0", attempt_id=1)

        deep = MagicMock(
            attempt=MagicMock(user_id=self.user.id), status=Report.Status.OK,
            report_type=Report.ReportType.DEEP, report_version="deep_v1",
        )
        self.repos["report_repository"].get_by_attempt_id.return_value = deep
        with self.assertRaises(ReportTypeMismatchException):
            self.service.create_session(user=self.user, entry_source="report_finding_focus:0", attempt_id=1)

    def test_report_open_question_without_attempt_id_raises(self):
        with self.assertRaises(ReportRequiredForEntrySourceException):
            self.service.create_session(user=self.user, entry_source="report_open_question")

    def test_report_open_question_with_v1_report_raises_version_mismatch(self):
        report = MagicMock(
            attempt=MagicMock(user_id=self.user.id), status=Report.Status.OK,
            report_type=Report.ReportType.INITIAL, report_version="report_v1",
        )
        self.repos["report_repository"].get_by_attempt_id.return_value = report

        with self.assertRaises(ReportVersionMismatchException):
            self.service.create_session(user=self.user, entry_source="report_open_question", attempt_id=1)

        self.repos["chat_session_repository"].create.assert_not_called()

    def test_report_open_question_with_deep_report_raises_type_mismatch(self):
        report = MagicMock(
            attempt=MagicMock(user_id=self.user.id), status=Report.Status.OK,
            report_type=Report.ReportType.DEEP, report_version="deep_v1",
        )
        self.repos["report_repository"].get_by_attempt_id.return_value = report

        with self.assertRaises(ReportTypeMismatchException):
            self.service.create_session(user=self.user, entry_source="report_open_question", attempt_id=1)

    def test_report_cta_still_works_with_a_v1_report(self):
        report = MagicMock(
            attempt=MagicMock(user_id=self.user.id), status=Report.Status.OK,
            report_type=Report.ReportType.INITIAL, report_version="report_v1",
        )
        self.repos["report_repository"].get_by_attempt_id.return_value = report

        self.service.create_session(user=self.user, entry_source="report_cta", attempt_id=1)

        self.repos["chat_session_repository"].create.assert_called_once()

    def test_deep_report_cta_with_initial_report_raises_type_mismatch(self):
        report = MagicMock(
            attempt=MagicMock(user_id=self.user.id), status=Report.Status.OK,
            report_type=Report.ReportType.INITIAL,
        )
        self.repos["report_repository"].get_by_attempt_id.return_value = report

        with self.assertRaises(ReportTypeMismatchException):
            self.service.create_session(user=self.user, entry_source="deep_report_cta", attempt_id=1)

        self.repos["chat_session_repository"].create.assert_not_called()

    def test_deep_report_cta_with_owned_deep_report_creates_session_bound_to_it(self):
        report = MagicMock(
            attempt=MagicMock(user_id=self.user.id), status=Report.Status.OK,
            report_type=Report.ReportType.DEEP,
        )
        self.repos["report_repository"].get_by_attempt_id.return_value = report

        self.service.create_session(user=self.user, entry_source="deep_report_cta", attempt_id=1)

        self.repos["chat_session_repository"].create.assert_called_once_with(
            user=self.user, entry_source="deep_report_cta", report=report, context_action_step=None,
            context_suggested_step=None,
        )

    def test_deep_report_focus_domain_with_owned_deep_report_creates_session_bound_to_it(self):
        report = MagicMock(
            attempt=MagicMock(user_id=self.user.id), status=Report.Status.OK,
            report_type=Report.ReportType.DEEP,
        )
        self.repos["report_repository"].get_by_attempt_id.return_value = report

        self.service.create_session(user=self.user, entry_source="deep_report_focus:domain_N", attempt_id=1)

        self.repos["chat_session_repository"].create.assert_called_once_with(
            user=self.user, entry_source="deep_report_focus:domain_N", report=report, context_action_step=None,
            context_suggested_step=None,
        )

    def test_deep_report_focus_unknown_section_raises_invalid_entry_source(self):
        with self.assertRaises(InvalidEntrySourceException):
            self.service.create_session(user=self.user, entry_source="deep_report_focus:bogus_section", attempt_id=1)

        self.repos["report_repository"].get_by_attempt_id.assert_not_called()

    def test_action_rejected_without_action_step_id_raises(self):
        with self.assertRaises(ActionRequiredForEntrySourceException):
            self.service.create_session(user=self.user, entry_source="action_rejected")

        self.repos["action_step_repository"].get_for_user.assert_not_called()

    def test_action_rejected_with_unowned_step_raises(self):
        self.repos["action_step_repository"].get_for_user.return_value = None

        with self.assertRaises(ActionRequiredForEntrySourceException):
            self.service.create_session(user=self.user, entry_source="action_rejected", action_step_id="s1")

    def test_action_rejected_with_owned_step_creates_session_bound_to_it(self):
        step = MagicMock(id="s1")
        self.repos["action_step_repository"].get_for_user.return_value = step

        self.service.create_session(user=self.user, entry_source="action_rejected", action_step_id="s1")

        self.repos["chat_session_repository"].create.assert_called_once_with(
            user=self.user, entry_source="action_rejected", report=None, context_action_step=step,
            context_suggested_step=None,
        )

    def test_action_completed_with_owned_step_creates_session_bound_to_it(self):
        step = MagicMock(id="s1")
        self.repos["action_step_repository"].get_for_user.return_value = step

        self.service.create_session(user=self.user, entry_source="action_completed", action_step_id="s1")

        self.repos["chat_session_repository"].create.assert_called_once_with(
            user=self.user, entry_source="action_completed", report=None, context_action_step=step,
            context_suggested_step=None,
        )
        self.repos["report_repository"].get_by_attempt_id.assert_not_called()

    def test_action_missed_with_not_done_step_creates_session_bound_to_it(self):
        step = MagicMock(id="s1", status="not_done")
        self.repos["action_step_repository"].get_for_user.return_value = step

        self.service.create_session(user=self.user, entry_source="action_missed", action_step_id="s1")

        self.repos["chat_session_repository"].create.assert_called_once_with(
            user=self.user, entry_source="action_missed", report=None, context_action_step=step,
            context_suggested_step=None,
        )

    def test_action_missed_with_still_pending_step_raises(self):
        step = MagicMock(id="s1", status="pending")
        self.repos["action_step_repository"].get_for_user.return_value = step

        with self.assertRaises(ActionStepNotMissedException):
            self.service.create_session(user=self.user, entry_source="action_missed", action_step_id="s1")

        self.repos["chat_session_repository"].create.assert_not_called()

    def test_action_missed_without_action_step_id_raises(self):
        with self.assertRaises(ActionRequiredForEntrySourceException):
            self.service.create_session(user=self.user, entry_source="action_missed", attempt_id=1, index=1)

    def test_action_active_with_pending_step_creates_session_bound_to_it(self):
        step = MagicMock(id="s1", status="pending")
        self.repos["action_step_repository"].get_for_user.return_value = step

        self.service.create_session(user=self.user, entry_source="action_active", action_step_id="s1")

        self.repos["chat_session_repository"].create.assert_called_once_with(
            user=self.user, entry_source="action_active", report=None, context_action_step=step,
            context_suggested_step=None,
        )

    def test_action_active_with_non_pending_step_raises(self):
        step = MagicMock(id="s1", status="done")
        self.repos["action_step_repository"].get_for_user.return_value = step

        with self.assertRaises(ActionStepNotActiveException):
            self.service.create_session(user=self.user, entry_source="action_active", action_step_id="s1")

        self.repos["chat_session_repository"].create.assert_not_called()

    def test_action_active_without_action_step_id_raises(self):
        with self.assertRaises(ActionRequiredForEntrySourceException):
            self.service.create_session(user=self.user, entry_source="action_active", attempt_id=1, index=1)

        self.repos["report_service"].get_suggested_step.assert_not_called()

    def test_action_rejected_without_action_step_id_or_index_raises(self):
        with self.assertRaises(ActionRequiredForEntrySourceException):
            self.service.create_session(user=self.user, entry_source="action_rejected", attempt_id=1)

        self.repos["report_service"].get_suggested_step.assert_not_called()

    def test_action_completed_without_action_step_id_raises_even_with_attempt_and_index(self):
        # The ephemeral (no ActionStep row) path is action_rejected-only -- action_completed
        # always refers to a step the user actually completed, which can only be a real row.
        with self.assertRaises(ActionRequiredForEntrySourceException):
            self.service.create_session(
                user=self.user, entry_source="action_completed", attempt_id=1, index=1,
            )

        self.repos["report_service"].get_suggested_step.assert_not_called()

    def test_action_rejected_with_attempt_and_index_builds_ephemeral_context(self):
        self.repos["report_service"].get_suggested_step.return_value = {
            "text": "بنویس", "deadline_type": "tonight", "deadline_text": "امشب",
        }

        self.service.create_session(user=self.user, entry_source="action_rejected", attempt_id=1, index=2)

        self.repos["report_service"].get_suggested_step.assert_called_once_with(
            attempt_id=1, index=2, user=self.user,
        )
        self.repos["action_step_repository"].get_for_user.assert_not_called()
        self.repos["chat_session_repository"].create.assert_called_once_with(
            user=self.user, entry_source="action_rejected", report=None, context_action_step=None,
            context_suggested_step={"text": "بنویس", "deadline_type": "tonight", "deadline_text": "امشب"},
        )

    def test_action_rejected_prefers_action_step_id_over_attempt_and_index(self):
        step = MagicMock(id="s1")
        self.repos["action_step_repository"].get_for_user.return_value = step

        self.service.create_session(
            user=self.user, entry_source="action_rejected", action_step_id="s1", attempt_id=1, index=2,
        )

        self.repos["report_service"].get_suggested_step.assert_not_called()
        self.repos["chat_session_repository"].create.assert_called_once_with(
            user=self.user, entry_source="action_rejected", report=None, context_action_step=step,
            context_suggested_step=None,
        )


class ChatServiceSendMessageTests(TestCase):
    def setUp(self):
        self.service, self.repos = _service()
        self.user = MagicMock(id=1)
        self.session = MagicMock(
            id="session-1", user=self.user, entry_source="manual", report_id=None,
            context_action_step=None, context_suggested_step=None,
        )
        self.repos["chat_session_repository"].get_for_user.return_value = self.session
        self.repos["chat_message_repository"].get_recent_for_session.return_value = []
        self.repos["chat_message_repository"].create.return_value = MagicMock(id=42)
        self.repos["memory_repository"].get_for_user.return_value = []

    def test_unknown_session_raises_before_touching_the_ai_client(self):
        self.repos["chat_session_repository"].get_for_user.return_value = None

        with self.assertRaises(ChatSessionNotFoundException):
            self.service.send_message(user=self.user, session_id="nope", user_message="hi")

        self.repos["ai_client"].generate_stream.assert_not_called()

    def test_message_too_long_raises_before_touching_the_ai_client(self):
        with self.assertRaises(ChatMessageTooLongException):
            self.service.send_message(user=self.user, session_id="session-1", user_message="x" * 4001)

        self.repos["ai_client"].generate_stream.assert_not_called()

    def test_daily_message_limit_raises_before_touching_the_ai_client(self):
        self.repos["chat_message_throttle_repository"].hit.return_value = True

        with self.assertRaises(ChatMessageLimitExceededException):
            self.service.send_message(user=self.user, session_id="session-1", user_message="hi")

        self.repos["ai_client"].generate_stream.assert_not_called()
        self.repos["chat_message_throttle_repository"].hit.assert_called_once_with(self.user.id)

    def test_report_excluded_for_manual_entry_source(self):
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "delta", "text": "hi "},
            {"type": "done", "message": "hi", "proposed_action": None, "generation_meta": {}},
        ]

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        payload = self.repos["ai_client"].generate_stream.call_args.args[0]
        self.assertNotIn("report", payload)

    def test_report_included_minus_preview_when_entry_source_qualifies(self):
        report = MagicMock(
            report_data={"summary": {"one_line": "x"}, "preview": {"teaser_line": "y"}},
            report_type=Report.ReportType.INITIAL, report_version="report_v1",
        )
        self.session.entry_source = "report_cta"
        self.session.report_id = 7
        self.session.report = report
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "done", "message": "hi", "proposed_action": None, "generation_meta": {}},
        ]

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        payload = self.repos["ai_client"].generate_stream.call_args.args[0]
        self.assertEqual(payload["report"], {"summary": {"one_line": "x"}})
        self.assertEqual(payload["report_type"], Report.ReportType.INITIAL)
        self.assertEqual(payload["report_version"], "report_v1")
        self.assertNotIn("focus_section", payload)

    def test_blank_stored_version_on_an_initial_report_is_sent_as_v1(self):
        report = MagicMock(
            report_data={"summary": {"one_line": "x"}}, report_type=Report.ReportType.INITIAL, report_version="",
        )
        self.session.entry_source = "report_cta"
        self.session.report_id = 7
        self.session.report = report
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "done", "message": "hi", "proposed_action": None, "generation_meta": {}},
        ]

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        payload = self.repos["ai_client"].generate_stream.call_args.args[0]
        self.assertEqual(payload["report_version"], "report_v1")

    def test_v2_report_is_sent_whole_with_its_version_for_report_open_question(self):
        report_data = {"hook": "h", "findings": [], "open_question": {"text": "q", "finding_index": 0}}
        report = MagicMock(
            report_data=report_data, report_type=Report.ReportType.INITIAL, report_version="report_v2",
        )
        self.session.entry_source = "report_open_question"
        self.session.report_id = 7
        self.session.report = report
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "done", "message": "hi", "proposed_action": None, "generation_meta": {}},
        ]

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        payload = self.repos["ai_client"].generate_stream.call_args.args[0]
        self.assertEqual(payload["entry_source"], "report_open_question")
        self.assertEqual(payload["report"], report_data)
        self.assertEqual(payload["report_version"], "report_v2")

    def test_finding_focus_payload_carries_the_index_the_report_and_its_version(self):
        report_data = {"hook": "h", "findings": [{}, {}]}
        report = MagicMock(
            report_data=report_data, report_type=Report.ReportType.INITIAL, report_version="report_v2",
        )
        self.session.entry_source = "report_finding_focus:1"
        self.session.report_id = 7
        self.session.report = report
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "done", "message": "hi", "proposed_action": None, "generation_meta": {}},
        ]

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        payload = self.repos["ai_client"].generate_stream.call_args.args[0]
        self.assertEqual(payload["focus_finding"], 1)
        self.assertEqual(payload["report_version"], "report_v2")
        self.assertNotIn("focus_section", payload)

    def test_focus_finding_is_absent_for_every_other_entry_source(self):
        report = MagicMock(
            report_data={"hook": "h"}, report_type=Report.ReportType.INITIAL, report_version="report_v2",
        )
        self.session.entry_source = "report_open_question"
        self.session.report_id = 7
        self.session.report = report
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "done", "message": "hi", "proposed_action": None, "generation_meta": {}},
        ]

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        self.assertNotIn("focus_finding", self.repos["ai_client"].generate_stream.call_args.args[0])

    def test_deep_report_carries_no_report_version(self):
        report = MagicMock(
            report_data={"identity_line": "x"}, report_type=Report.ReportType.DEEP, report_version="deep_v1",
        )
        self.session.entry_source = "deep_report_cta"
        self.session.report_id = 7
        self.session.report = report
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "done", "message": "hi", "proposed_action": None, "generation_meta": {}},
        ]

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        payload = self.repos["ai_client"].generate_stream.call_args.args[0]
        self.assertNotIn("report_version", payload)

    def test_deep_report_included_minus_share_for_deep_report_cta(self):
        report = MagicMock(
            report_data={"identity_line": "x", "share": {"hook": "h", "line": "l"}},
            report_type=Report.ReportType.DEEP,
        )
        self.session.entry_source = "deep_report_cta"
        self.session.report_id = 7
        self.session.report = report
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "done", "message": "hi", "proposed_action": None, "generation_meta": {}},
        ]

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        payload = self.repos["ai_client"].generate_stream.call_args.args[0]
        self.assertEqual(payload["report"], {"identity_line": "x"})
        self.assertEqual(payload["report_type"], Report.ReportType.DEEP)
        self.assertNotIn("focus_section", payload)

    def test_deep_report_focus_entry_source_adds_focus_section(self):
        report = MagicMock(report_data={"identity_line": "x"}, report_type=Report.ReportType.DEEP)
        self.session.entry_source = "deep_report_focus:decision_style"
        self.session.report_id = 7
        self.session.report = report
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "done", "message": "hi", "proposed_action": None, "generation_meta": {}},
        ]

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        payload = self.repos["ai_client"].generate_stream.call_args.args[0]
        self.assertEqual(payload["focus_section"], "decision_style")

    def test_user_memory_drops_confidence_and_sensitivity(self):
        memory = MagicMock(memory_type="core_pattern", text_memory="text", source="initial_report")
        self.repos["memory_repository"].get_for_user.return_value = [memory]
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "done", "message": "hi", "proposed_action": None, "generation_meta": {}},
        ]

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        payload = self.repos["ai_client"].generate_stream.call_args.args[0]
        self.assertEqual(
            payload["user_memory"], [{"memory_type": "core_pattern", "text_memory": "text", "source": "initial_report"}],
        )

    def test_user_memory_drops_unsupported_memory_types(self):
        # A legacy `committed_action` row must never reach the chat generation service; nor an
        # `action_outcome` row -- retired in chat_spec_v3, the step result comes off the
        # ActionStep row now (action_context.recent), not memory.
        rows = [
            MagicMock(memory_type="core_pattern", text_memory="keep", source="initial_report"),
            MagicMock(memory_type="committed_action", text_memory="drop", source="chat"),
            MagicMock(memory_type="action_outcome", text_memory="drop", source="action_step:s1"),
        ]
        self.repos["memory_repository"].get_for_user.return_value = rows
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "done", "message": "hi", "proposed_action": None, "generation_meta": {}},
        ]

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        payload = self.repos["ai_client"].generate_stream.call_args.args[0]
        self.assertEqual(
            payload["user_memory"], [{"memory_type": "core_pattern", "text_memory": "keep", "source": "initial_report"}],
        )

    def test_context_action_absent_when_session_has_no_context_step(self):
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "done", "message": "hi", "proposed_action": None, "generation_meta": {}},
        ]

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        payload = self.repos["ai_client"].generate_stream.call_args.args[0]
        self.assertNotIn("context_action", payload)

    def test_action_context_recent_is_sent_on_every_turn(self):
        # chat_spec_v3 §1.4: the last 3 steps, unfiltered, on every entry_source incl. manual.
        self.repos["action_step_repository"].list_recent.return_value = [
            MagicMock(step_text="a", status="done", reflection="راحت بود", obstacle=""),
            MagicMock(step_text="b", status="not_done", reflection=None, obstacle="no_time"),
        ]
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "done", "message": "hi", "proposed_action": None, "generation_meta": {}},
        ]

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        payload = self.repos["ai_client"].generate_stream.call_args.args[0]
        self.repos["action_step_repository"].list_recent.assert_called_once_with(user=self.user)
        self.assertEqual(payload["action_context"], {"recent": [
            {"text": "a", "status": "done", "reflection": "راحت بود", "obstacle": None},
            {"text": "b", "status": "not_done", "reflection": None, "obstacle": "no_time"},
        ]})
        self.assertNotIn("current", payload["action_context"])

    def test_context_action_included_for_action_rejected_session(self):
        step = MagicMock(
            id="s1", step_text="talk to someone", deadline_type="tonight", source="initial_report:rec_2",
            status="not_done", obstacle="blocked",
        )
        self.session.entry_source = "action_rejected"
        self.session.context_action_step = step
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "done", "message": "hi", "proposed_action": None, "generation_meta": {}},
        ]

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        payload = self.repos["ai_client"].generate_stream.call_args.args[0]
        # chat_spec §1.4/§9: `status` and `obstacle` are dropped for action_rejected even when
        # the row happens to carry them -- a rejected step was never recorded, so neither has a
        # meaning, and ChatRequest fails the payload outright if either is sent.
        self.assertEqual(payload["context_action"], {
            "id": "s1", "text": "talk to someone", "deadline_type": "tonight",
            "source": "initial_report:rec_2",
        })
        # chat_spec_v3 §1.4: `current` mirrors context_action, `recent` is always present.
        self.assertEqual(payload["action_context"]["current"], payload["context_action"])
        self.assertIn("recent", payload["action_context"])

    def test_context_action_built_from_ephemeral_suggested_step_when_no_context_step(self):
        # action_rejected on a report suggestion that was never accepted (create_session's
        # attempt_id+index path) -- no ActionStep row, just the snapshot saved at creation.
        self.session.entry_source = "action_rejected"
        self.session.context_suggested_step = {"text": "بنویس", "deadline_type": "tonight"}
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "done", "message": "hi", "proposed_action": None, "generation_meta": {}},
        ]

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        payload = self.repos["ai_client"].generate_stream.call_args.args[0]
        # No "status": the snapshot is of a suggestion that was never accepted (chat_spec §1.4).
        self.assertEqual(payload["context_action"], {
            "id": f"report-suggestion:{self.session.id}", "text": "بنویس", "deadline_type": "tonight",
            "source": None,
        })

    def test_done_chunk_persists_assistant_message_and_emits_sse(self):
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "delta", "text": "hi "},
            {
                "type": "done", "message": "hi there", "proposed_action": None,
                "quick_replies": ["a", "b"], "generation_meta": {"model_used": "x"},
            },
        ]

        events = list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        self.assertIn("event: delta", events[0])
        self.assertIn("event: done", events[1])
        self.assertIn('"message_id": 42', events[1])
        self.assertIn('"message": "hi there"', events[1])
        self.assertIn('"quick_replies": ["a", "b"]', events[1])
        self.repos["chat_message_repository"].create.assert_any_call(
            session=self.session, role=ChatMessage.Role.ASSISTANT, content="hi there",
            proposed_action=None, quick_replies=["a", "b"], prompt_version="chat_v3",
            generation_meta={"model_used": "x"},
        )

    def test_done_chunk_writes_a_priced_generation_log(self):
        self.repos["ai_client"].generate_stream.return_value = [
            {
                "type": "done", "message": "hi", "proposed_action": None, "quick_replies": None,
                "generation_meta": {
                    "model_used": "gpt-5.4-mini (openai)", "attempts": 1, "input_tokens": 4200,
                    "cached_input_tokens": 3100, "output_tokens": 180, "latency_s": 3.2,
                },
            },
        ]

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        self.repos["chat_generation_log_repository"].create.assert_called_once()
        kwargs = self.repos["chat_generation_log_repository"].create.call_args.kwargs
        self.assertEqual(kwargs["session"], self.session)
        self.assertEqual(kwargs["user"], self.user)
        self.assertEqual(kwargs["model_used"], "gpt-5.4-mini (openai)")
        self.assertEqual(kwargs["input_tokens"], 4200)
        self.assertEqual(kwargs["cached_input_tokens"], 3100)
        self.assertEqual(kwargs["output_tokens"], 180)
        self.assertEqual(kwargs["prompt_version"], "chat_v3")
        # No ModelPricing row configured in this test -> cost can't be determined, stays None.
        self.assertIsNone(kwargs["cost"])

    def test_generation_log_not_written_when_meta_absent(self):
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "done", "message": "hi", "proposed_action": None, "quick_replies": None,
             "generation_meta": None},
        ]

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        self.repos["chat_generation_log_repository"].create.assert_not_called()

    def test_always_calls_the_ai_client(self):
        """chat_spec_v2: the templated action_preview:rec_<n> when/size/propose flow is gone --
        every turn goes straight to the AI service now."""
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "done", "message": "hi", "proposed_action": None, "quick_replies": None, "generation_meta": {}},
        ]

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        self.repos["ai_client"].generate_stream.assert_called_once()

    def test_mid_stream_failure_persists_partial_text_and_emits_error_event(self):
        def failing_stream(payload):
            yield {"type": "delta", "text": "partial "}
            raise RuntimeError("boom")

        self.repos["ai_client"].generate_stream.side_effect = failing_stream

        events = list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        self.assertIn("event: error", events[-1])
        self.repos["chat_message_repository"].create.assert_any_call(
            session=self.session, role=ChatMessage.Role.ASSISTANT, content="partial ", prompt_version="chat_v3",
        )


class ChatAnswerMetricsTests(TestCase):
    """faraman_chat_answer_* -- the explicit instrumentation in ChatService._stream. Metric
    objects are process-global, so assert on deltas."""

    def setUp(self):
        self.service, self.repos = _service()
        self.user = MagicMock(id=1)
        self.session = MagicMock(id="session-1", user=self.user, entry_source="manual", report_id=None,
                                 context_action_step=None, context_suggested_step=None)
        self.repos["chat_session_repository"].get_for_user.return_value = self.session
        self.repos["chat_message_repository"].get_recent_for_session.return_value = []
        self.repos["chat_message_repository"].create.return_value = MagicMock(id=42)
        self.repos["memory_repository"].get_for_user.return_value = []

    def _count(self, **labels):
        return read_metric("faraman_chat_answer_duration_seconds_count", **labels) or 0.0

    def _ttft_count(self, **labels):
        return read_metric("faraman_chat_answer_ttft_seconds_count", **labels) or 0.0

    def _in_progress(self, **labels):
        return read_metric("faraman_chat_answer_in_progress", **labels) or 0.0

    def test_success_records_duration_and_ttft(self):
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "delta", "text": "hi"},
            {"type": "done", "message": "hi", "proposed_action": None, "quick_replies": None,
             "generation_meta": None},
        ]
        d_before = self._count(kind="send", outcome="success")
        t_before = self._ttft_count(kind="send")
        gauge_before = self._in_progress(kind="send")

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        self.assertEqual(self._count(kind="send", outcome="success") - d_before, 1.0)
        self.assertEqual(self._ttft_count(kind="send") - t_before, 1.0)
        self.assertEqual(self._in_progress(kind="send"), gauge_before)

    def test_error_outcome_on_mid_stream_failure(self):
        def failing_stream(payload):
            yield {"type": "delta", "text": "partial "}
            raise RuntimeError("boom")

        self.repos["ai_client"].generate_stream.side_effect = failing_stream
        before = self._count(kind="send", outcome="error")

        list(self.service.send_message(user=self.user, session_id="session-1", user_message="hi"))

        self.assertEqual(self._count(kind="send", outcome="error") - before, 1.0)

    def test_client_disconnect_outcome(self):
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "delta", "text": "a"}, {"type": "delta", "text": "b"},
        ]
        before = self._count(kind="send", outcome="client_disconnect")

        gen = self.service.send_message(user=self.user, session_id="session-1", user_message="hi")
        next(gen)          # first delta
        gen.close()        # -> GeneratorExit into _stream

        self.assertEqual(self._count(kind="send", outcome="client_disconnect") - before, 1.0)

    def test_regenerate_uses_the_regenerate_kind(self):
        session = MagicMock(id="session-1", user=self.user, entry_source="manual", report_id=None,
                            context_action_step=None, context_suggested_step=None)
        self.repos["chat_session_repository"].get_for_user.return_value = session
        assistant = MagicMock(id=9, role=ChatMessage.Role.ASSISTANT)
        self.repos["chat_message_repository"].get_for_session.return_value = assistant
        self.repos["chat_message_repository"].get_last_for_session.return_value = assistant
        self.repos["chat_message_repository"].get_last_user_message_before.return_value = MagicMock(id=8, content="q")
        self.repos["chat_message_repository"].get_recent_for_session.return_value = []
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "done", "message": "hi", "proposed_action": None, "quick_replies": None,
             "generation_meta": None},
        ]
        before = self._count(kind="regenerate", outcome="success")

        list(self.service.regenerate_message(user=self.user, session_id="session-1", message_id=9))

        self.assertEqual(self._count(kind="regenerate", outcome="success") - before, 1.0)


class ChatServiceAcceptActionTests(TestCase):
    def setUp(self):
        self.service, self.repos = _service()
        self.user = MagicMock(id=1)

    def _message(self, **overrides):
        defaults = dict(
            proposed_action={"text": "do the thing", "deadline_text": "امشب", "deadline_type": "tonight"},
            action_accepted_at=None,
        )
        defaults.update(overrides)
        return MagicMock(**defaults)

    def test_message_without_proposed_action_raises(self):
        self.repos["chat_message_repository"].get_assistant_message_for_user.return_value = (
            self._message(proposed_action=None)
        )

        with self.assertRaises(ProposedActionUnavailableException):
            self.service.accept_action(user=self.user, message_id=1)

    def test_already_accepted_message_raises(self):
        self.repos["chat_message_repository"].get_assistant_message_for_user.return_value = (
            self._message(action_accepted_at=SimpleNamespace())
        )

        with self.assertRaises(ProposedActionUnavailableException):
            self.service.accept_action(user=self.user, message_id=1)

    def test_missing_message_raises(self):
        self.repos["chat_message_repository"].get_assistant_message_for_user.return_value = None

        with self.assertRaises(ProposedActionUnavailableException):
            self.service.accept_action(user=self.user, message_id=1)

    def test_fresh_proposal_creates_a_new_action_step_and_marks_message(self):
        message = self._message()
        self.repos["chat_message_repository"].get_assistant_message_for_user.return_value = message

        self.service.accept_action(user=self.user, message_id=1)

        self.repos["action_step_service"].create_step.assert_called_once_with(
            user=self.user, source="chat", step_text="do the thing", deadline_type="tonight", substeps=None,
        )
        self.repos["action_step_service"].edit_step.assert_not_called()
        self.repos["chat_message_repository"].mark_action_accepted.assert_called_once_with(message)

    def test_stray_id_on_proposed_action_is_ignored_and_a_new_step_is_created(self):
        # chat_spec_v3: chat output is always a new step -- a step can only be rejected before
        # it is accepted, so there is never a row to replace. Any id the model still emits is
        # dropped.
        message = self._message(
            proposed_action={
                "id": "s1", "text": "talk to someone else instead", "deadline_text": "امشب",
                "deadline_type": "tonight",
            },
        )
        self.repos["chat_message_repository"].get_assistant_message_for_user.return_value = message

        self.service.accept_action(user=self.user, message_id=1)

        self.repos["action_step_service"].create_step.assert_called_once_with(
            user=self.user, source="chat", step_text="talk to someone else instead",
            deadline_type="tonight", substeps=None,
        )
        self.repos["action_step_service"].edit_step.assert_not_called()
        self.repos["chat_message_repository"].mark_action_accepted.assert_called_once_with(message)


class ChatServiceRegenerateMessageTests(TestCase):
    def setUp(self):
        self.service, self.repos = _service()
        self.user = MagicMock(id=1)
        self.session = MagicMock(
            id="session-1", user=self.user, entry_source="manual", report_id=None,
            context_action_step=None, context_suggested_step=None,
        )
        self.repos["chat_session_repository"].get_for_user.return_value = self.session
        self.repos["memory_repository"].get_for_user.return_value = []

    def _assistant_message(self, **overrides):
        defaults = dict(id=42, role=ChatMessage.Role.ASSISTANT, created_at="t2")
        defaults.update(overrides)
        return MagicMock(**defaults)

    def test_unknown_session_raises_before_touching_messages(self):
        self.repos["chat_session_repository"].get_for_user.return_value = None

        with self.assertRaises(ChatSessionNotFoundException):
            self.service.regenerate_message(user=self.user, session_id="nope", message_id=42)

        self.repos["chat_message_repository"].get_for_session.assert_not_called()

    def test_unknown_message_raises(self):
        self.repos["chat_message_repository"].get_for_session.return_value = None

        with self.assertRaises(ChatMessageNotFoundException):
            self.service.regenerate_message(user=self.user, session_id="session-1", message_id=99)

        self.repos["chat_message_repository"].delete.assert_not_called()

    def test_user_role_message_raises(self):
        self.repos["chat_message_repository"].get_for_session.return_value = self._assistant_message(
            role=ChatMessage.Role.USER,
        )

        with self.assertRaises(ChatMessageNotFoundException):
            self.service.regenerate_message(user=self.user, session_id="session-1", message_id=42)

    def test_not_last_message_raises_regenerate_not_allowed(self):
        message = self._assistant_message()
        self.repos["chat_message_repository"].get_for_session.return_value = message
        self.repos["chat_message_repository"].get_last_for_session.return_value = self._assistant_message(id=43)

        with self.assertRaises(RegenerateNotAllowedException):
            self.service.regenerate_message(user=self.user, session_id="session-1", message_id=42)

        self.repos["chat_message_repository"].get_last_user_message_before.assert_not_called()
        self.repos["chat_message_repository"].delete.assert_not_called()

    def test_missing_trigger_user_message_raises(self):
        message = self._assistant_message()
        self.repos["chat_message_repository"].get_for_session.return_value = message
        self.repos["chat_message_repository"].get_last_for_session.return_value = message
        self.repos["chat_message_repository"].get_last_user_message_before.return_value = None

        with self.assertRaises(ChatMessageNotFoundException):
            self.service.regenerate_message(user=self.user, session_id="session-1", message_id=42)

        self.repos["chat_message_repository"].delete.assert_not_called()

    def test_daily_message_limit_raises_before_deleting_the_old_message(self):
        message = self._assistant_message()
        trigger = MagicMock(id=41, content="hi", role=ChatMessage.Role.USER)
        self.repos["chat_message_repository"].get_for_session.return_value = message
        self.repos["chat_message_repository"].get_last_for_session.return_value = message
        self.repos["chat_message_repository"].get_last_user_message_before.return_value = trigger
        self.repos["chat_message_throttle_repository"].hit.return_value = True

        with self.assertRaises(ChatMessageLimitExceededException):
            self.service.regenerate_message(user=self.user, session_id="session-1", message_id=42)

        self.repos["chat_message_repository"].delete.assert_not_called()
        self.repos["ai_client"].generate_stream.assert_not_called()

    def test_deletes_old_message_and_calls_the_chat_service_again(self):
        message = self._assistant_message()
        trigger = MagicMock(id=41, content="hi", role=ChatMessage.Role.USER)
        self.repos["chat_message_repository"].get_for_session.return_value = message
        self.repos["chat_message_repository"].get_last_for_session.return_value = message
        self.repos["chat_message_repository"].get_last_user_message_before.return_value = trigger
        self.repos["chat_message_repository"].get_recent_for_session.return_value = [trigger]
        self.repos["chat_message_repository"].create.return_value = MagicMock(id=43)
        self.repos["ai_client"].generate_stream.return_value = [
            {"type": "done", "message": "new reply", "proposed_action": None, "generation_meta": {}},
        ]

        events = list(self.service.regenerate_message(user=self.user, session_id="session-1", message_id=42))

        self.repos["chat_message_repository"].delete.assert_called_once_with(message)
        self.repos["ai_client"].generate_stream.assert_called_once()
        payload = self.repos["ai_client"].generate_stream.call_args.args[0]
        self.assertEqual(payload["user_message"], "hi")
        self.assertEqual(payload["history"], [])  # the trigger message isn't double-counted as history
        self.assertIn("event: done", events[-1])
        self.assertIn('"message_id": 43', events[-1])


class MessageFeedbackServiceTests(TestCase):
    def setUp(self):
        self.chat_message_repository = MagicMock()
        self.message_feedback_repository = MagicMock()
        self.service = MessageFeedbackService(
            chat_message_repository=self.chat_message_repository,
            message_feedback_repository=self.message_feedback_repository,
        )
        self.user = MagicMock(id=1)

    def test_unknown_or_inaccessible_message_raises(self):
        self.chat_message_repository.get_assistant_message_for_user.return_value = None

        with self.assertRaises(ChatMessageNotFoundException):
            self.service.submit(user=self.user, message_id=1, is_useful=True)

        self.message_feedback_repository.upsert.assert_not_called()

    def test_submit_upserts_feedback_for_the_message(self):
        message = MagicMock(id=1)
        self.chat_message_repository.get_assistant_message_for_user.return_value = message

        self.service.submit(user=self.user, message_id=1, is_useful=False)

        self.message_feedback_repository.upsert.assert_called_once_with(
            message=message, user=self.user, is_useful=False,
        )

    def test_remove_unknown_or_inaccessible_message_raises(self):
        self.chat_message_repository.get_assistant_message_for_user.return_value = None

        with self.assertRaises(ChatMessageNotFoundException):
            self.service.remove(user=self.user, message_id=1)

        self.message_feedback_repository.delete.assert_not_called()

    def test_remove_deletes_feedback_for_the_message(self):
        message = MagicMock(id=1)
        self.chat_message_repository.get_assistant_message_for_user.return_value = message

        self.service.remove(user=self.user, message_id=1)

        self.message_feedback_repository.delete.assert_called_once_with(message=message, user=self.user)


class MessageBookmarkServiceTests(TestCase):
    def setUp(self):
        self.chat_message_repository = MagicMock()
        self.message_bookmark_repository = MagicMock()
        self.service = MessageBookmarkService(
            chat_message_repository=self.chat_message_repository,
            message_bookmark_repository=self.message_bookmark_repository,
        )
        self.user = MagicMock(id=1)

    def test_bookmark_unknown_message_raises(self):
        self.chat_message_repository.get_assistant_message_for_user.return_value = None

        with self.assertRaises(ChatMessageNotFoundException):
            self.service.bookmark(user=self.user, message_id=1)

        self.message_bookmark_repository.create_if_missing.assert_not_called()

    def test_bookmark_creates_bookmark_for_the_message(self):
        message = MagicMock(id=1)
        self.chat_message_repository.get_assistant_message_for_user.return_value = message

        self.service.bookmark(user=self.user, message_id=1)

        self.message_bookmark_repository.create_if_missing.assert_called_once_with(message=message, user=self.user)

    def test_remove_bookmark_unknown_message_raises(self):
        self.chat_message_repository.get_assistant_message_for_user.return_value = None

        with self.assertRaises(ChatMessageNotFoundException):
            self.service.remove_bookmark(user=self.user, message_id=1)

        self.message_bookmark_repository.delete.assert_not_called()

    def test_remove_bookmark_deletes_the_bookmark(self):
        message = MagicMock(id=1)
        self.chat_message_repository.get_assistant_message_for_user.return_value = message

        self.service.remove_bookmark(user=self.user, message_id=1)

        self.message_bookmark_repository.delete.assert_called_once_with(message=message, user=self.user)

    def test_list_bookmarked_shapes_output(self):
        message = MagicMock(id=1, session_id="session-1", content="hi", created_at="created")
        bookmark = MagicMock(message_id=1, message=message, created_at="bookmarked")
        self.message_bookmark_repository.get_for_user.return_value = [bookmark]

        result = self.service.list_bookmarked(user=self.user)

        self.assertEqual(result, [{
            "message_id": 1, "session_id": "session-1", "content": "hi",
            "created_at": "created", "bookmarked_at": "bookmarked",
        }])


class ChatServiceListSessionsTests(TestCase):
    def setUp(self):
        self.service, self.repos = _service()
        self.user = MagicMock(id=1)

    def test_shapes_preview_from_session_title(self):
        session = MagicMock(
            id="session-1", entry_source="manual", created_at="created",
            title="سلام", last_message_at="updated",
        )
        self.repos["chat_session_repository"].get_list_for_user.return_value = [session]

        result = self.service.list_sessions(user=self.user)

        self.assertEqual(result, [{
            "session_id": "session-1", "entry_source": "manual", "created_at": "created",
            "preview": "سلام", "last_message_at": "updated",
        }])

    def test_untitled_session_has_no_preview(self):
        session = MagicMock(
            id="session-1", entry_source="manual", created_at="created",
            title="", last_message_at="created",
        )
        self.repos["chat_session_repository"].get_list_for_user.return_value = [session]

        result = self.service.list_sessions(user=self.user)

        self.assertEqual(result[0]["preview"], None)
        self.assertEqual(result[0]["last_message_at"], "created")

    def test_passes_pagination_through_to_repository(self):
        self.repos["chat_session_repository"].get_list_for_user.return_value = []

        self.service.list_sessions(user=self.user, limit=10, offset=20)

        self.repos["chat_session_repository"].get_list_for_user.assert_called_once_with(
            self.user, limit=10, offset=20,
        )

    def test_limit_is_clamped_to_the_max_page_size(self):
        self.repos["chat_session_repository"].get_list_for_user.return_value = []

        self.service.list_sessions(user=self.user, limit=10_000)

        _, kwargs = self.repos["chat_session_repository"].get_list_for_user.call_args
        self.assertEqual(kwargs["limit"], MAX_SESSION_PAGE_SIZE)


class ChatServiceDeleteSessionTests(TestCase):
    def setUp(self):
        self.service, self.repos = _service()
        self.user = MagicMock(id=1)

    def test_unknown_session_raises_before_deleting(self):
        self.repos["chat_session_repository"].get_for_user.return_value = None

        with self.assertRaises(ChatSessionNotFoundException):
            self.service.delete_session(user=self.user, session_id="nope")

        self.repos["chat_session_repository"].delete.assert_not_called()

    def test_deletes_the_requesters_session(self):
        session = MagicMock()
        self.repos["chat_session_repository"].get_for_user.return_value = session

        self.service.delete_session(user=self.user, session_id="session-1")

        self.repos["chat_session_repository"].delete.assert_called_once_with(session)


class ChatServiceGetSessionMessagesTests(TestCase):
    def setUp(self):
        self.service, self.repos = _service()
        self.user = MagicMock(id=1)

    def test_unknown_session_raises(self):
        self.repos["chat_session_repository"].get_for_user.return_value = None

        with self.assertRaises(ChatSessionNotFoundException):
            self.service.get_session_messages(user=self.user, session_id="nope")

    def test_shapes_messages_oldest_first(self):
        session = MagicMock()
        self.repos["chat_session_repository"].get_for_user.return_value = session
        message = MagicMock(
            id=5, role="assistant", content="hi", proposed_action={"text": "x"}, quick_replies=None,
            action_accepted_at=None, created_at="created",
        )
        self.repos["chat_message_repository"].get_all_for_session.return_value = [message]

        result = self.service.get_session_messages(user=self.user, session_id="session-1")

        self.assertEqual(result, [{
            "id": 5, "role": "assistant", "content": "hi", "proposed_action": {"text": "x"},
            "quick_replies": None, "action_accepted": False, "created_at": "created",
            "is_useful": None, "is_bookmarked": False,
        }])
        self.repos["message_feedback_repository"].get_feedback_map.assert_called_once_with(
            user=self.user, messages=[message],
        )
        self.repos["message_bookmark_repository"].get_bookmarked_message_ids.assert_called_once_with(
            user=self.user, messages=[message],
        )

    def test_surfaces_the_requesters_own_feedback_and_bookmark_state(self):
        session = MagicMock()
        self.repos["chat_session_repository"].get_for_user.return_value = session
        message = MagicMock(
            id=5, role="assistant", content="hi", proposed_action=None, quick_replies=None,
            action_accepted_at=None, created_at="created",
        )
        self.repos["chat_message_repository"].get_all_for_session.return_value = [message]
        self.repos["message_feedback_repository"].get_feedback_map.return_value = {5: True}
        self.repos["message_bookmark_repository"].get_bookmarked_message_ids.return_value = {5}

        result = self.service.get_session_messages(user=self.user, session_id="session-1")

        self.assertEqual(result[0]["is_useful"], True)
        self.assertEqual(result[0]["is_bookmarked"], True)




class ChatSessionDenormalizedColumnsTests(TestCase):
    """DB-backed: ChatMessageRepository.create keeps ChatSession.title / .last_message_at
    current, and ChatSessionRepository.get_list_for_user reads them back as one paged,
    activity-ordered query."""

    def setUp(self):
        self.user = User.objects.create_user(phone_number="09120000000")
        self.messages = ChatMessageRepository()
        self.sessions = ChatSessionRepository()

    def _session(self):
        return ChatSession.objects.create(user=self.user, entry_source="manual")

    def test_first_user_message_sets_title_and_bumps_last_message_at(self):
        session = self._session()

        self.messages.create(session=session, role=ChatMessage.Role.USER, content="سلام، یه سوال دارم")
        session.refresh_from_db()

        self.assertEqual(session.title, "سلام، یه سوال دارم")
        self.assertIsNotNone(session.last_message_at)

    def test_title_is_truncated_and_frozen_after_the_first_user_message(self):
        session = self._session()
        long_first = "x" * (CHAT_SESSION_TITLE_MAX_LENGTH + 50)

        self.messages.create(session=session, role=ChatMessage.Role.USER, content=long_first)
        self.messages.create(session=session, role=ChatMessage.Role.ASSISTANT, content="reply")
        self.messages.create(session=session, role=ChatMessage.Role.USER, content="second question")
        session.refresh_from_db()

        self.assertEqual(session.title, "x" * CHAT_SESSION_TITLE_MAX_LENGTH)

    def test_assistant_message_bumps_activity_without_setting_a_title(self):
        session = self._session()

        message = self.messages.create(session=session, role=ChatMessage.Role.ASSISTANT, content="hi")
        session.refresh_from_db()

        self.assertEqual(session.title, "")
        self.assertEqual(session.last_message_at, message.created_at)

    def test_list_is_ordered_by_activity_and_paginated(self):
        old = self._session()
        new = self._session()
        ChatSession.objects.filter(pk=old.pk).update(last_message_at=timezone.now() - timezone.timedelta(days=1))

        first_page = self.sessions.get_list_for_user(self.user, limit=1, offset=0)
        second_page = self.sessions.get_list_for_user(self.user, limit=1, offset=1)

        self.assertEqual([s.id for s in first_page], [new.id])
        self.assertEqual([s.id for s in second_page], [old.id])
