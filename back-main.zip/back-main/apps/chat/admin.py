from django.contrib import admin

from apps.chat.models import (
    ChatGenerationLog,
    ChatMessage,
    ChatSession,
    MessageBookmark,
    MessageFeedback,
)


@admin.register(ChatSession)
class ChatSessionAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "entry_source", "report", "created_at")
    list_filter = ("entry_source",)
    search_fields = ("id", "user__phone_number")
    readonly_fields = [f.name for f in ChatSession._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = ("id", "session", "role", "prompt_version", "action_accepted_at", "created_at")
    list_filter = ("role",)
    search_fields = ("session__id", "session__user__phone_number")
    readonly_fields = [f.name for f in ChatMessage._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


@admin.register(MessageFeedback)
class MessageFeedbackAdmin(admin.ModelAdmin):
    list_display = ("id", "message", "user", "is_useful", "created_at")
    list_filter = ("is_useful",)
    search_fields = ("user__phone_number",)
    readonly_fields = [f.name for f in MessageFeedback._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


@admin.register(ChatGenerationLog)
class ChatGenerationLogAdmin(admin.ModelAdmin):
    list_display = (
        "id", "session", "user", "model_used", "attempts", "input_tokens",
        "cached_input_tokens", "output_tokens", "cost", "created_at",
    )
    list_filter = ("model_used", "prompt_version")
    search_fields = ("session__id", "user__phone_number")
    readonly_fields = [f.name for f in ChatGenerationLog._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


@admin.register(MessageBookmark)
class MessageBookmarkAdmin(admin.ModelAdmin):
    list_display = ("id", "message", "user", "created_at")
    search_fields = ("user__phone_number",)
    readonly_fields = [f.name for f in MessageBookmark._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
