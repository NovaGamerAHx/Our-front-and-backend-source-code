from drf_spectacular.utils import extend_schema
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView

from apps.chat.serializers.message_serializer import MessageFeedbackSerializer
from apps.chat.services.exceptions import ChatMessageNotFoundException
from apps.chat.services.message_bookmark_service import MessageBookmarkService
from apps.chat.services.message_feedback_service import MessageFeedbackService
from faraman_back.lang.utils import get_message
from faraman_back.utils.responses import ApiResponse
from faraman_back.utils.schema import error_responses


class MessageFeedbackAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.message_feedback_service = MessageFeedbackService()

    @extend_schema(
        description="Submits an is_useful vote on one of the requester's own assistant "
                    "messages. Submitting again for the same message updates the existing vote "
                    "instead of creating a duplicate.",
        tags=["Chat"],
        request=MessageFeedbackSerializer,
        responses=error_responses(ChatMessageNotFoundException),
    )
    def post(self, request, message_id):
        ser = MessageFeedbackSerializer(data=request.data)
        if not ser.is_valid():
            return ApiResponse.validation_error(data=ser.errors)

        self.message_feedback_service.submit(
            user=request.user, message_id=message_id, **ser.validated_data,
        )

        return ApiResponse.success(message=get_message('feedback_submitted'))

    @extend_schema(
        description="Clears the requester's own is_useful vote on one of their assistant "
                    "messages, if any (undo). Idempotent -- clearing a message with no vote is "
                    "a no-op.",
        tags=["Chat"],
        responses=error_responses(ChatMessageNotFoundException),
    )
    def delete(self, request, message_id):
        self.message_feedback_service.remove(user=request.user, message_id=message_id)

        return ApiResponse.success(message=get_message('message_feedback_removed'))


class MessageBookmarkAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.message_bookmark_service = MessageBookmarkService()

    @extend_schema(
        description="Bookmarks one of the requester's own assistant messages. Idempotent -- "
                    "bookmarking an already-bookmarked message is a no-op.",
        tags=["Chat"],
        responses=error_responses(ChatMessageNotFoundException),
    )
    def post(self, request, message_id):
        self.message_bookmark_service.bookmark(user=request.user, message_id=message_id)

        return ApiResponse.success(message=get_message('message_bookmarked'))

    @extend_schema(
        description="Removes a bookmark from one of the requester's own assistant messages. "
                    "Idempotent -- removing a bookmark that doesn't exist is a no-op.",
        tags=["Chat"],
        responses=error_responses(ChatMessageNotFoundException),
    )
    def delete(self, request, message_id):
        self.message_bookmark_service.remove_bookmark(user=request.user, message_id=message_id)

        return ApiResponse.success(message=get_message('message_bookmark_removed'))


class BookmarkedMessagesAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.message_bookmark_service = MessageBookmarkService()

    @extend_schema(
        description="Lists the authenticated user's bookmarked messages, newest bookmark "
                    "first -- backs the frontend's existing bookmarked-messages page.",
        tags=["Chat"],
    )
    def get(self, request):
        data = self.message_bookmark_service.list_bookmarked(user=request.user)

        return ApiResponse.success(data=data)
