from django.http import StreamingHttpResponse
from drf_spectacular.types import OpenApiTypes
from drf_spectacular.utils import extend_schema
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView

from apps.action_steps.serializers.action_step_serializer import ActionStepSerializer
from apps.chat.serializers.chat_serializer import (
    ChatMessageCreateSerializer,
    ChatSessionCreateSerializer,
    ChatSessionListQuerySerializer,
    ChatSessionResponseSerializer,
)
from apps.chat.services.chat_service import ChatService
from apps.chat.services.exceptions import (
    ActionRequiredForEntrySourceException,
    ActionStepNotActiveException,
    ActionStepNotMissedException,
    ChatMessageNotFoundException,
    ChatSessionNotFoundException,
    InvalidEntrySourceException,
    ProposedActionUnavailableException,
    RegenerateNotAllowedException,
    ReportRequiredForEntrySourceException,
    ReportTypeMismatchException,
)
from apps.report.services.exceptions import (
    ReportAccessDeniedException,
    ReportNotFoundException,
    ReportNotReadyException,
    SuggestedStepNotFoundException,
)
from faraman_back.utils.responses import ApiResponse
from faraman_back.utils.schema import error_responses


def _sse_response(stream) -> StreamingHttpResponse:
    response = StreamingHttpResponse(stream, content_type="text/event-stream")
    response["Cache-Control"] = "no-cache"
    response["X-Accel-Buffering"] = "no"
    return response


class ChatSessionListCreateAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.chat_service = ChatService()

    @extend_schema(
        description="Lists the authenticated user's chat sessions, newest first. Not part of "
                    "chat_spec_v3_1.md -- purely a read endpoint over data the model already "
                    "persists, for a frontend history panel. Paginated via `limit` (default 30, "
                    "max 100) and `offset` query params.",
        tags=["Chat"],
        parameters=[ChatSessionListQuerySerializer],
    )
    def get(self, request):
        ser = ChatSessionListQuerySerializer(data=request.query_params)
        if not ser.is_valid():
            return ApiResponse.validation_error(data=ser.errors)

        data = self.chat_service.list_sessions(user=request.user, **ser.validated_data)

        return ApiResponse.success(data=data)

    @extend_schema(
        description="Starts a new chat session (chat_spec_v2 §1.1, deep_report_spec_v1_1.md "
                    "§1-§3). `entry_source` is fixed for the session's lifetime -- every distinct "
                    "entry_source starts a brand-new session. `attempt_id` is required for "
                    "report_cta/report_open_question/deep_report_cta/deep_report_focus:<section> (binds the session to "
                    "that attempt's report); `action_step_id` is required for "
                    "action_rejected/action_completed/action_missed/action_active (binds the "
                    "session to that ActionStep; action_missed additionally requires that step to "
                    "be not_done/partial, action_active requires it to still be pending) -- unless "
                    "entry_source is action_rejected and the step was never accepted, in which "
                    "case `attempt_id`+`index` identify the report suggestion instead, and no "
                    "ActionStep is created.",
        tags=["Chat"],
        request=ChatSessionCreateSerializer,
        responses=error_responses(
            InvalidEntrySourceException, ReportRequiredForEntrySourceException,
            ReportNotFoundException, ReportAccessDeniedException, ReportNotReadyException,
            ReportTypeMismatchException, ActionRequiredForEntrySourceException,
            ActionStepNotMissedException, ActionStepNotActiveException, SuggestedStepNotFoundException,
        ),
    )
    def post(self, request):
        ser = ChatSessionCreateSerializer(data=request.data)
        if not ser.is_valid():
            return ApiResponse.validation_error(data=ser.errors)

        session = self.chat_service.create_session(user=request.user, **ser.validated_data)

        return ApiResponse.success(data={"session_id": session.id})


class ChatSessionAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.chat_service = ChatService()

    @extend_schema(
        description="Deletes a chat session and its messages. Not part of chat_spec_v3_1.md -- "
                    "lets the frontend's history panel let the user remove a session.",
        tags=["Chat"],
        responses=error_responses(ChatSessionNotFoundException),
    )
    def delete(self, request, session_id):
        self.chat_service.delete_session(user=request.user, session_id=session_id)

        return ApiResponse.success()


class ChatSessionMessagesAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.chat_service = ChatService()

    @extend_schema(
        description="Full transcript for one session, oldest-first. Not part of chat_spec_v3_1.md "
                    "-- purely a read endpoint over data the model already persists.",
        tags=["Chat"],
        responses=error_responses(ChatSessionNotFoundException),
    )
    def get(self, request, session_id):
        data = self.chat_service.get_session_messages(user=request.user, session_id=session_id)

        return ApiResponse.success(data=data)

    @extend_schema(
        description="Sends a user message and streams the reply as SSE (chat_spec_v3_1.md §2): "
                    "`event: delta` chunks followed by one `event: done` (or `event: error`). "
                    "The response body is the raw event stream, not an ApiResponse envelope -- "
                    "that envelope is what this endpoint's wire format already is.",
        tags=["Chat"],
        request=ChatMessageCreateSerializer,
        responses={200: OpenApiTypes.OBJECT},
    )
    def post(self, request, session_id):
        ser = ChatMessageCreateSerializer(data=request.data)
        if not ser.is_valid():
            return ApiResponse.validation_error(data=ser.errors)

        # send_message() does all validation (session lookup, length cap) eagerly and raises
        # before returning the generator, so a ChatSessionNotFoundException/
        # ChatMessageTooLongException here still goes through the normal AppException ->
        # ApiResponse path (faraman_back/utils/exception_handler.py) instead of ever reaching
        # the stream -- only generation-time failures become an in-stream `event: error`.
        stream = self.chat_service.send_message(
            user=request.user, session_id=session_id, user_message=ser.validated_data["user_message"],
        )

        return _sse_response(stream)


class ChatMessageRegenerateAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.chat_service = ChatService()

    @extend_schema(
        description="Regenerates an assistant message: deletes it and streams a fresh reply "
                    "(same SSE shape as sending a message, `event: delta`/`event: done`) from a "
                    "real new call to the chat service -- not a cached response -- using the "
                    "user message that originally triggered it. The deleted message no longer "
                    "appears in this session's transcript. Only the session's last message can "
                    "be regenerated -- anything earlier would leave later turns standing on "
                    "context that's just been deleted.",
        tags=["Chat"],
        responses={200: OpenApiTypes.OBJECT, **error_responses(
            ChatSessionNotFoundException, ChatMessageNotFoundException, RegenerateNotAllowedException,
        )},
    )
    def post(self, request, session_id, message_id):
        stream = self.chat_service.regenerate_message(
            user=request.user, session_id=session_id, message_id=message_id,
        )

        return _sse_response(stream)


class ChatActionAcceptAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.chat_service = ChatService()

    @extend_schema(
        description="Accepts the proposed_action of an assistant message (chat_spec_v3 §2.4/§5.2): "
                    "always creates a new ActionStep (source=chat). Chat output is never a "
                    "replacement -- a step can only be rejected before it is accepted. Returns "
                    "the resulting ActionStep.",
        tags=["Chat"],
        responses={200: ActionStepSerializer, **error_responses(ProposedActionUnavailableException)},
    )
    def post(self, request, message_id):
        action_step = self.chat_service.accept_action(user=request.user, message_id=message_id)

        return ApiResponse.success(data=ActionStepSerializer(action_step).data)
