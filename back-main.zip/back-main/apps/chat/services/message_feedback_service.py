from apps.account.models import User
from apps.chat.repositories.chat_message_repository import ChatMessageRepository
from apps.chat.repositories.message_feedback_repository import MessageFeedbackRepository
from apps.chat.services.exceptions import ChatMessageNotFoundException


class MessageFeedbackService:
    def __init__(self, chat_message_repository=None, message_feedback_repository=None):
        self.chat_message_repository = chat_message_repository or ChatMessageRepository()
        self.message_feedback_repository = message_feedback_repository or MessageFeedbackRepository()

    def submit(self, *, user: User, message_id: int, is_useful: bool) -> None:
        """One is_useful vote per (message, user) -- a repeat submission updates the existing
        row instead of inserting a duplicate (MessageFeedbackRepository.upsert)."""
        message = self.chat_message_repository.get_assistant_message_for_user(message_id, user)
        if message is None:
            raise ChatMessageNotFoundException()

        self.message_feedback_repository.upsert(message=message, user=user, is_useful=is_useful)

    def remove(self, *, user: User, message_id: int) -> None:
        """Undoes a vote (chat UI: tapping the same thumbs-up/down again). Idempotent -- clearing
        a message with no vote is a no-op, same as bookmark removal."""
        message = self.chat_message_repository.get_assistant_message_for_user(message_id, user)
        if message is None:
            raise ChatMessageNotFoundException()

        self.message_feedback_repository.delete(message=message, user=user)
