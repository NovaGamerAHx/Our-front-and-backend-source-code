from apps.account.models import User
from apps.chat.repositories.chat_message_repository import ChatMessageRepository
from apps.chat.repositories.message_bookmark_repository import MessageBookmarkRepository
from apps.chat.services.exceptions import ChatMessageNotFoundException


class MessageBookmarkService:
    def __init__(self, chat_message_repository=None, message_bookmark_repository=None):
        self.chat_message_repository = chat_message_repository or ChatMessageRepository()
        self.message_bookmark_repository = message_bookmark_repository or MessageBookmarkRepository()

    def bookmark(self, *, user: User, message_id: int) -> None:
        message = self.chat_message_repository.get_assistant_message_for_user(message_id, user)
        if message is None:
            raise ChatMessageNotFoundException()

        self.message_bookmark_repository.create_if_missing(message=message, user=user)

    def remove_bookmark(self, *, user: User, message_id: int) -> None:
        message = self.chat_message_repository.get_assistant_message_for_user(message_id, user)
        if message is None:
            raise ChatMessageNotFoundException()

        self.message_bookmark_repository.delete(message=message, user=user)

    def list_bookmarked(self, *, user: User) -> list[dict]:
        return [
            {
                "message_id": bookmark.message_id,
                "session_id": bookmark.message.session_id,
                "content": bookmark.message.content,
                "created_at": bookmark.message.created_at,
                "bookmarked_at": bookmark.created_at,
            }
            for bookmark in self.message_bookmark_repository.get_for_user(user)
        ]
