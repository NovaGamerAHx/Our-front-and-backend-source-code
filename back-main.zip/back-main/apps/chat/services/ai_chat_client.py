"""apps.chat's adapter to the chat AI service (chat_spec_v3_1.md), mirroring the split between
apps.report.services.ai_report_client.AiReportClient and apps.ai.report_generation. Backed by a
mock today (apps.ai.chat_generation.client.ChatGenerationClient) -- this is the one file that
changes when the real service is wired in.
"""

from apps.ai.chat_generation.client import ChatGenerationClient


class AiChatClient:
    def __init__(self, client=None):
        # Optional injected client -- lets tests avoid depending on ChatGenerationClient's output.
        self._client = client or ChatGenerationClient()

    def generate_stream(self, payload: dict):
        """payload matches chat_spec_v3_1.md §1. Yields delta/done chunks (§2), pre-SSE-formatting."""
        return self._client.generate_stream(payload)
