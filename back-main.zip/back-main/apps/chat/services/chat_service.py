import json
import logging
import re
import time

from apps.account.models import User
from apps.action_steps.repositories.action_step_repository import ActionStepRepository
from apps.action_steps.services.action_step_service import ActionStepService, SOURCE_CHAT
from apps.ai.pricing import calculate_cost
from apps.chat.models import ChatMessage, ChatSession
from apps.chat.repositories.chat_generation_log_repository import ChatGenerationLogRepository
from apps.chat.repositories.chat_message_repository import ChatMessageRepository
from apps.chat.repositories.chat_message_throttle_repository import ChatMessageThrottleRepository
from apps.chat.repositories.chat_session_repository import ChatSessionRepository
from apps.chat.repositories.message_bookmark_repository import MessageBookmarkRepository
from apps.chat.repositories.message_feedback_repository import MessageFeedbackRepository
from apps.chat.services.ai_chat_client import AiChatClient
from apps.chat.services.exceptions import (
    ActionRequiredForEntrySourceException,
    ActionStepNotActiveException,
    ActionStepNotMissedException,
    ChatMessageLimitExceededException,
    ChatMessageNotFoundException,
    ChatMessageTooLongException,
    ChatSessionNotFoundException,
    InvalidEntrySourceException,
    ProposedActionUnavailableException,
    RegenerateNotAllowedException,
    ReportRequiredForEntrySourceException,
    ReportTypeMismatchException,
    ReportVersionMismatchException,
)
from apps.report.models import Report
from apps.report.repositories.memory_repository import MemoryRepository
from apps.report.repositories.report_repository import ReportRepository
from apps.report.services.exceptions import (
    ReportAccessDeniedException,
    ReportNotFoundException,
    ReportNotReadyException,
)
from apps.report.services.report_service import ReportService
from faraman_back.lang.utils import get_message
from faraman_back.observability.metrics import (
    CHAT_ANSWER_DURATION,
    CHAT_ANSWER_IN_PROGRESS,
    CHAT_ANSWER_TTFT,
    THROTTLE_REJECTED,
)

logger = logging.getLogger(__name__)

PROMPT_VERSION = "chat_v3"
MAX_MESSAGE_LENGTH = 4000  # chat_spec_v3_1.md §6.3: exact cap is the backend's call

# History-panel pagination (list_sessions). Not in any spec -- a sane page so the endpoint
# can't be made to load an unbounded number of sessions.
DEFAULT_SESSION_PAGE_SIZE = 30
MAX_SESSION_PAGE_SIZE = 100

# The memory types the chat generation service accepts. `action_outcome` was retired in
# chat_spec_v3: a step's result is no longer memory, it comes off the ActionStep row as
# `action_context.recent` (see _build_recent_steps). A row of any other type -- e.g. a legacy
# `committed_action` -- would fail the AI-side payload validation, so filter here.
CHAT_MEMORY_TYPES = frozenset({
    "core_pattern", "strength", "growth_edge", "growth_focus",
})

ENTRY_SOURCE_MANUAL = "manual"
ENTRY_SOURCE_REPORT_CTA = "report_cta"
# chat_spec_v3_1 §1.1: the button under the open question of a report_v2 initial report.
ENTRY_SOURCE_REPORT_OPEN_QUESTION = "report_open_question"
# The initial report shape written before report_v2. Rows that predate the version column's
# use may be blank; they are all this shape.
REPORT_V1 = "report_v1"
REPORT_V2 = "report_v2"
ENTRY_SOURCE_DEEP_REPORT_CTA = "deep_report_cta"
ENTRY_SOURCE_ACTION_REJECTED = "action_rejected"
ENTRY_SOURCE_ACTION_COMPLETED = "action_completed"
# chat_spec_v3 §1.1: dashboard -> chat for a step the user accepted but did not do.
ENTRY_SOURCE_ACTION_MISSED = "action_missed"
# action_steps_spec_v2_2.md §6.2: the pending-task card's "let's talk about it" button, before the
# step's deadline. Unlike the other three action entry sources, the mission is not a new
# step -- it's this same one, so create_session requires the bound step to still be pending.
ENTRY_SOURCE_ACTION_ACTIVE = "action_active"
DEEP_REPORT_FOCUS_PREFIX = "deep_report_focus:"
# The initial-report counterpart of deep_report_focus: the button inside one finding card of a
# report_v2 report. `<n>` is the 0-based index into report.findings (0 or 1), like open_question's
# finding_index.
REPORT_FINDING_FOCUS_PREFIX = "report_finding_focus:"
_REPORT_FINDING_FOCUS_ENTRY_SOURCE_RE = re.compile(rf"^{re.escape(REPORT_FINDING_FOCUS_PREFIX)}([01])$")
# deep_report_spec_v1_1.md: the 13 sections the deep-report page can deep-link a chat CTA to --
# 5 Big Five domains, strengths/blind_spots, and the 6 topic sections.
_DEEP_REPORT_FOCUS_SECTIONS = (
    "domain_N", "domain_E", "domain_O", "domain_A", "domain_C",
    "strengths", "blind_spots",
    "decision_style", "communication_style", "work_style",
    "stress_and_energy", "learning_and_growth", "close_relationships",
)
_DEEP_REPORT_FOCUS_ENTRY_SOURCE_RE = re.compile(
    rf"^{re.escape(DEEP_REPORT_FOCUS_PREFIX)}({'|'.join(_DEEP_REPORT_FOCUS_SECTIONS)})$"
)
_REPORT_ENTRY_SOURCES = (
    ENTRY_SOURCE_REPORT_CTA, ENTRY_SOURCE_REPORT_OPEN_QUESTION, ENTRY_SOURCE_DEEP_REPORT_CTA,
)
_ACTION_ENTRY_SOURCES = (
    ENTRY_SOURCE_ACTION_REJECTED, ENTRY_SOURCE_ACTION_COMPLETED, ENTRY_SOURCE_ACTION_MISSED,
    ENTRY_SOURCE_ACTION_ACTIVE,
)
# chat_spec_v3 §1.1: action_missed only makes sense for a step the user owned and did not
# finish -- the AI service enforces the same on context_action.status.
_ACTION_MISSED_STATUSES = ("not_done", "partial")
# action_steps_spec_v2_2.md §6.2: action_active only makes sense for a step still awaiting its deadline --
# the AI service enforces the same on context_action.status.
_ACTION_ACTIVE_STATUS = "pending"


class ChatService:
    def __init__(
        self, chat_session_repository=None, chat_message_repository=None, memory_repository=None,
        report_repository=None, action_step_repository=None, action_step_service=None,
        message_feedback_repository=None, message_bookmark_repository=None,
        chat_generation_log_repository=None, chat_message_throttle_repository=None,
        ai_client=None, report_service=None,
    ):
        self.chat_session_repository = chat_session_repository or ChatSessionRepository()
        self.chat_message_repository = chat_message_repository or ChatMessageRepository()
        self.chat_generation_log_repository = (
            chat_generation_log_repository or ChatGenerationLogRepository()
        )
        self.chat_message_throttle_repository = (
            chat_message_throttle_repository or ChatMessageThrottleRepository()
        )
        self.memory_repository = memory_repository or MemoryRepository()
        self.report_repository = report_repository or ReportRepository()
        self.action_step_repository = action_step_repository or ActionStepRepository()
        self.action_step_service = action_step_service or ActionStepService()
        self.message_feedback_repository = message_feedback_repository or MessageFeedbackRepository()
        self.message_bookmark_repository = message_bookmark_repository or MessageBookmarkRepository()
        self.ai_client = ai_client or AiChatClient()
        # Only used by create_session's ephemeral action_rejected path (a report suggestion
        # rejected pre-acceptance) -- see get_suggested_step().
        self.report_service = report_service or ReportService()

    @staticmethod
    def _entry_source_requires_report(entry_source: str) -> bool:
        return (
            entry_source in _REPORT_ENTRY_SOURCES
            or entry_source.startswith((DEEP_REPORT_FOCUS_PREFIX, REPORT_FINDING_FOCUS_PREFIX))
        )

    @staticmethod
    def _entry_source_requires_action(entry_source: str) -> bool:
        return entry_source in _ACTION_ENTRY_SOURCES

    @staticmethod
    def _is_valid_entry_source(entry_source: str) -> bool:
        return (
            entry_source in (
                ENTRY_SOURCE_MANUAL, ENTRY_SOURCE_REPORT_CTA, ENTRY_SOURCE_REPORT_OPEN_QUESTION,
                ENTRY_SOURCE_DEEP_REPORT_CTA,
                ENTRY_SOURCE_ACTION_REJECTED, ENTRY_SOURCE_ACTION_COMPLETED, ENTRY_SOURCE_ACTION_MISSED,
                ENTRY_SOURCE_ACTION_ACTIVE,
            )
            or bool(_DEEP_REPORT_FOCUS_ENTRY_SOURCE_RE.match(entry_source))
            or bool(_REPORT_FINDING_FOCUS_ENTRY_SOURCE_RE.match(entry_source))
        )

    @staticmethod
    def _expected_report_type(entry_source: str) -> str:
        """deep_report_spec_v1_1.md: deep_report_cta/deep_report_focus:<section> bind to the
        deep report; report_cta binds to the initial one. Only meaningful for entry sources that
        require a report at all (never called for "manual" or the action entry sources)."""
        if entry_source == ENTRY_SOURCE_DEEP_REPORT_CTA or entry_source.startswith(DEEP_REPORT_FOCUS_PREFIX):
            return Report.ReportType.DEEP
        return Report.ReportType.INITIAL

    @staticmethod
    def _extract_focus_finding(entry_source: str) -> int | None:
        """The 0-based finding index for report_finding_focus:<n>, absent for every other
        entry_source."""
        match = _REPORT_FINDING_FOCUS_ENTRY_SOURCE_RE.match(entry_source)
        return int(match.group(1)) if match else None

    @staticmethod
    def _extract_focus_section(entry_source: str) -> str | None:
        """deep_report_spec_v1_1.md §3: the section name for deep_report_focus:<section>, absent
        for every other entry_source."""
        if not entry_source.startswith(DEEP_REPORT_FOCUS_PREFIX):
            return None
        return entry_source[len(DEEP_REPORT_FOCUS_PREFIX):]

    def create_session(
        self, *, user: User, entry_source: str, attempt_id: int | None = None, action_step_id=None,
        index: int | None = None,
    ) -> ChatSession:
        """chat_spec_v3 §1.1/§6.1. `entry_source` is fixed for the session's lifetime -- unlike
        v1, every distinct entry_source (including switching from one action step to another)
        starts a brand-new session rather than reusing an existing one."""
        if not self._is_valid_entry_source(entry_source):
            raise InvalidEntrySourceException()

        report = None
        if self._entry_source_requires_report(entry_source):
            if attempt_id is None:
                raise ReportRequiredForEntrySourceException()

            report = self.report_repository.get_by_attempt_id(attempt_id)
            if report is None:
                raise ReportNotFoundException(f"No report found for attempt {attempt_id}")
            if report.attempt.user_id != user.id:
                raise ReportAccessDeniedException(
                    f"Report for attempt {attempt_id} does not belong to this requester"
                )
            if report.status != Report.Status.OK:
                raise ReportNotReadyException(f"Report for attempt {attempt_id} is not ready (status={report.status})")
            expected_report_type = self._expected_report_type(entry_source)
            if report.report_type != expected_report_type:
                raise ReportTypeMismatchException(
                    f"entry_source {entry_source!r} expects a {expected_report_type} report but "
                    f"attempt {attempt_id}'s report is {report.report_type}"
                )
            if (
                entry_source == ENTRY_SOURCE_REPORT_OPEN_QUESTION
                or entry_source.startswith(REPORT_FINDING_FOCUS_PREFIX)
            ) and report.report_version != REPORT_V2:
                # chat_spec_v3_1 §6.1: a v1 report has no open question and no findings[] to
                # focus on.
                raise ReportVersionMismatchException(
                    f"{entry_source} needs a report_v2 report; attempt {attempt_id}'s is "
                    f"{report.report_version!r}"
                )

        context_action_step = None
        context_suggested_step = None
        if self._entry_source_requires_action(entry_source):
            if action_step_id is not None:
                context_action_step = self.action_step_repository.get_for_user(action_step_id, user)
                if context_action_step is None:
                    raise ActionRequiredForEntrySourceException(
                        f"No action step {action_step_id} found for this requester"
                    )
                if (
                    entry_source == ENTRY_SOURCE_ACTION_MISSED
                    and context_action_step.status not in _ACTION_MISSED_STATUSES
                ):
                    raise ActionStepNotMissedException(
                        f"action_missed needs a not_done/partial step; "
                        f"{action_step_id} is {context_action_step.status}"
                    )
                if (
                    entry_source == ENTRY_SOURCE_ACTION_ACTIVE
                    and context_action_step.status != _ACTION_ACTIVE_STATUS
                ):
                    raise ActionStepNotActiveException(
                        f"action_active needs a pending step; "
                        f"{action_step_id} is {context_action_step.status}"
                    )
            elif entry_source == ENTRY_SOURCE_ACTION_REJECTED and attempt_id is not None and index is not None:
                # A report suggestion rejected before it was ever accepted -- action_steps_spec_v2_2.md §3:
                # rejecting only enters chat, it never registers a step. There is no ActionStep
                # row to bind to, so snapshot the suggestion's content instead (still enough for
                # _build_context_action to give the AI the step the conversation is about).
                step_data = self.report_service.get_suggested_step(attempt_id=attempt_id, index=index, user=user)
                context_suggested_step = {
                    "text": step_data["text"],
                    "deadline_type": step_data.get("deadline_type"),
                    "deadline_text": step_data.get("deadline_text"),
                }
            else:
                raise ActionRequiredForEntrySourceException()

        return self.chat_session_repository.create(
            user=user, entry_source=entry_source, report=report, context_action_step=context_action_step,
            context_suggested_step=context_suggested_step,
        )

    def list_sessions(
        self, *, user: User, limit: int = DEFAULT_SESSION_PAGE_SIZE, offset: int = 0,
    ) -> list[dict]:
        """Not part of chat_spec_v3_1.md (which has no such endpoint) -- this is purely for the
        frontend's history panel to read back sessions the model already persists. `preview` is
        the session `title` (the first user message, truncated; later an AI summary); `None` for
        a session that was created but never got a user message. Ordered by most recent activity
        and paginated so a user with hundreds of sessions doesn't pull them all in one
        response."""
        limit = min(limit, MAX_SESSION_PAGE_SIZE)
        sessions = self.chat_session_repository.get_list_for_user(user, limit=limit, offset=offset)
        return [
            {
                "session_id": session.id,
                "entry_source": session.entry_source,
                "created_at": session.created_at,
                "preview": session.title or None,
                "last_message_at": session.last_message_at,
            }
            for session in sessions
        ]

    def delete_session(self, *, user: User, session_id) -> None:
        """Not part of chat_spec_v3_1.md -- lets the frontend's history panel let the user remove
        a session they no longer want to keep. Cascades to its messages (ChatMessage.session's
        on_delete=CASCADE); ActionStep has no FK back to the message that proposed it, so any
        step already accepted out of this session survives untouched."""
        session = self.chat_session_repository.get_for_user(session_id, user)
        if session is None:
            raise ChatSessionNotFoundException()

        self.chat_session_repository.delete(session)

    def get_session_messages(self, *, user: User, session_id) -> list[dict]:
        """Full transcript for one session, oldest-first -- same not-in-spec rationale as
        list_sessions(). is_useful/is_bookmarked are the requester's own vote/bookmark on each
        message (never another user's -- messages only ever belong to the requester's own
        session anyway), so the frontend can restore that state when the user reopens a chat."""
        session = self.chat_session_repository.get_for_user(session_id, user)
        if session is None:
            raise ChatSessionNotFoundException()

        messages = self.chat_message_repository.get_all_for_session(session)
        feedback_map = self.message_feedback_repository.get_feedback_map(user=user, messages=messages)
        bookmarked_ids = self.message_bookmark_repository.get_bookmarked_message_ids(user=user, messages=messages)

        return [
            {
                "id": message.id,
                "role": message.role,
                "content": message.content,
                "proposed_action": message.proposed_action,
                "quick_replies": message.quick_replies,
                "action_accepted": message.action_accepted_at is not None,
                "created_at": message.created_at,
                "is_useful": feedback_map.get(message.id),
                "is_bookmarked": message.id in bookmarked_ids,
            }
            for message in messages
        ]

    def _build_user_memory(self, user: User) -> list[dict]:
        """chat_spec_v3_1.md §1.2. confidence/sensitivity_level are dropped -- unused here.

        No longer at most one row per memory_type: since the deep report landed, `Memory` is
        unique on (user, memory_type, source), so a user who took both tests carries two
        lineages -- e.g. a core_pattern from `initial_report` and another from
        `deep_report_v1`. Both are injected, which is why each row carries its `source`: the
        prompt has to attribute them rather than present two summaries of the same person as
        if they were one (deep_report_spec_v1_2.md §6.3).
        """
        return [
            {"memory_type": memory.memory_type, "text_memory": memory.text_memory, "source": memory.source}
            for memory in self.memory_repository.get_for_user(user)
            if memory.memory_type in CHAT_MEMORY_TYPES
        ]

    @staticmethod
    def _build_context_action(session: ChatSession) -> dict | None:
        """The specific step a conversation is about (chat_spec §1.4 `action_context.current`).
        Only present for the four action entry sources, read straight off the ActionStep row
        -- so it always has `status` and is there even for a step that was never completed.

        Emitted under the payload key `context_action` (see _build_payload): the frozen
        apps.ai.chat_generation contract still expects that name and a non-null `id`. `id` is a
        placeholder -- render_session_context() never puts it into the prompt text, so nothing
        downstream depends on it resolving. chat_spec_v3 drops `id` entirely; that lands when
        apps.ai moves to v3.

        action_rejected has a second source: context_suggested_step, a plain snapshot saved by
        create_session for a report suggestion rejected before it was ever accepted -- there is
        no ActionStep row for those (action_steps_spec_v2_2.md §3).
        """
        rejected = session.entry_source == ENTRY_SOURCE_ACTION_REJECTED

        step = session.context_action_step
        if step is not None:
            current = {
                "id": str(step.id),
                "text": step.step_text,
                "deadline_type": step.deadline_type,
                "source": step.source,
            }
            # chat_spec §1.4/§9: `status` is meaningful for any entry source but action_rejected
            # -- action_active's is always "pending" (no outcome yet), action_completed/
            # action_missed's is a recorded outcome. A rejected step was never written to
            # action_steps, so sending either one there is a hard ChatRequest validation error.
            if not rejected:
                current["status"] = step.status
                # action_completed / action_missed: the obstacle answer is already on the row,
                # so the model has it without asking again (chat_spec §1.4).
                if step.obstacle:
                    current["obstacle"] = step.obstacle
            return current

        suggested = session.context_suggested_step
        if suggested is not None:
            current = {
                "id": f"report-suggestion:{session.id}",
                "text": suggested["text"],
                "deadline_type": suggested.get("deadline_type"),
                "source": None,
            }
            # This branch only ever exists for action_rejected (create_session saves the snapshot
            # nowhere else), so it carries no status -- the snapshot is of a report suggestion
            # that was never accepted, and "pending" here was never a real recorded state.
            if not rejected:
                current["status"] = "pending"
            return current

        return None

    def _build_recent_steps(self, user: User) -> list[dict]:
        """chat_spec §1.4 `action_context.recent`: the user's last 3 steps, unfiltered, each
        with its own status and the user's own account of it. Sent on every turn (including
        `manual`) -- this is what replaced the `action_outcome` memory type. A still-`pending`
        step counts: the model should not hand a fourth step to someone juggling three."""
        return [
            {
                "text": step.step_text,
                "status": step.status,
                "reflection": step.reflection or None,
                "obstacle": step.obstacle or None,
            }
            for step in self.action_step_repository.list_recent(user=user)
        ]

    def _build_payload(
        self, *, session: ChatSession, user: User, user_message: str, history: list[ChatMessage],
    ) -> dict:
        payload = {
            "session_id": str(session.id),
            "entry_source": session.entry_source,
            "user_message": user_message,
            "history": [{"role": message.role, "content": message.content} for message in history],
            "user_memory": self._build_user_memory(user),
        }

        if session.report_id is not None:
            report_data = dict(session.report.report_data or {})
            report_data.pop("preview", None)
            if session.report.report_type == Report.ReportType.DEEP:
                # deep_report_spec_v1_1.md §2: deep report goes to chat without `share` -- that
                # card is for the report page's own sharing UI, not something the model needs.
                report_data.pop("share", None)
            payload["report"] = report_data
            payload["report_type"] = session.report.report_type
            if session.report.report_type == Report.ReportType.INITIAL:
                # chat_spec_v3_1 §1.3: stored next to the report, passed through untouched so the
                # AI service picks the matching renderer.
                payload["report_version"] = session.report.report_version or REPORT_V1

        focus_finding = self._extract_focus_finding(session.entry_source)
        if focus_finding is not None:
            payload["focus_finding"] = focus_finding

        focus_section = self._extract_focus_section(session.entry_source)
        if focus_section is not None:
            payload["focus_section"] = focus_section

        # chat_spec_v3 §1.4: `recent` on every turn, `current` only for the action sources.
        # apps.ai.chat_generation still reads the older flat `context_action` key (below); it
        # ignores `action_context` for now. Both are sent until apps.ai moves to v3.
        current = self._build_context_action(session)
        action_context = {"recent": self._build_recent_steps(user)}
        if current is not None:
            action_context["current"] = current
            payload["context_action"] = current
        payload["action_context"] = action_context

        return payload

    @staticmethod
    def _sse(event: str, data: dict) -> str:
        return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"

    def _resolve_chunks(self, payload: dict):
        """chat_spec_v2: the templated action_preview:rec_<n> when/how-much-time/propose flow is
        gone -- the report creates step 1 directly now, so every turn is ordinary AI-service
        generation."""
        return self.ai_client.generate_stream(payload)

    def _log_generation(self, *, session: ChatSession, message: ChatMessage, generation_meta: dict | None) -> None:
        """One ChatGenerationLog row per generation that reached the model (chat_spec_v3_1.md
        §2.6). Mirrors ReportService._log_generation: generation_meta is the AI service's raw
        usage, the cost is priced here against apps.ai.pricing with the cached-input discount
        applied. No row when there is no meta -- an all-attempts-failed turn that never
        produced a `done` chunk has no usage to record."""
        if not generation_meta:
            return

        try:
            cost = calculate_cost(
                generation_meta.get("model_used"),
                generation_meta.get("input_tokens", 0),
                generation_meta.get("output_tokens", 0),
                cached_input_tokens=generation_meta.get("cached_input_tokens", 0),
            )
            self.chat_generation_log_repository.create(
                session=session,
                message=message,
                user=session.user,
                model_used=generation_meta.get("model_used"),
                attempts=generation_meta.get("attempts", 0),
                input_tokens=generation_meta.get("input_tokens", 0),
                cached_input_tokens=generation_meta.get("cached_input_tokens", 0),
                output_tokens=generation_meta.get("output_tokens", 0),
                latency_s=generation_meta.get("latency_s", 0.0),
                cost=cost,
                prompt_version=PROMPT_VERSION,
            )
        except Exception:
            # The user already has their reply; a failed analytics write must not turn a good
            # turn into an error event. Log and move on.
            logger.exception("failed to write ChatGenerationLog for session %s", session.id)

    def _stream(self, *, session: ChatSession, payload: dict, kind: str = "send"):
        """The actual SSE body (chat_spec_v3_1.md §2/§4.1). A separate generator function from
        send_message() on purpose: send_message() does all validation eagerly (session lookup,
        length cap) so those fail as a normal ApiResponse error *before* any bytes go out --
        only generation-time failures become an in-stream `event: error`.

        Instrumented here rather than with the @observe decorator because (a) the except
        block below swallows generation errors and yields an `event: error` instead of
        raising -- the generator then ends normally, which a decorator would read as success
        -- and (b) time-to-first-token is captured mid-loop. `kind` is send|regenerate.
        The client-visible SSE output is unchanged by the metrics.
        """
        CHAT_ANSWER_IN_PROGRESS.labels(kind=kind).inc()
        started = time.perf_counter()
        first_token_seen = False
        outcome = "success"
        accumulated = ""
        try:
            for chunk in self._resolve_chunks(payload):
                if chunk["type"] == "delta":
                    if not first_token_seen:
                        first_token_seen = True
                        CHAT_ANSWER_TTFT.labels(kind=kind).observe(time.perf_counter() - started)
                    accumulated += chunk["text"]
                    yield self._sse("delta", {"text": chunk["text"]})
                elif chunk["type"] == "done":
                    message_text = chunk["message"]
                    proposed_action = chunk.get("proposed_action")
                    quick_replies = chunk.get("quick_replies")
                    generation_meta = chunk.get("generation_meta")
                    assistant_message = self.chat_message_repository.create(
                        session=session, role=ChatMessage.Role.ASSISTANT, content=message_text,
                        proposed_action=proposed_action, quick_replies=quick_replies,
                        prompt_version=PROMPT_VERSION, generation_meta=generation_meta,
                    )
                    self._log_generation(
                        session=session, message=assistant_message, generation_meta=generation_meta,
                    )
                    yield self._sse("done", {
                        "status": "ok",
                        "prompt_version": PROMPT_VERSION,
                        # Not part of chat_spec_v3_1.md §2's AI-service contract -- added on our
                        # backend->frontend leg only, since accept-action (§5.2) needs a message
                        # id to target and the AI service has no notion of our message rows.
                        "message_id": assistant_message.id,
                        "message": message_text,
                        "proposed_action": proposed_action,
                        # Also not in chat_spec_v3_1.md -- tap-able reply options for this turn,
                        # mutually exclusive with proposed_action (apps.ai.chat_generation.client).
                        "quick_replies": quick_replies,
                        "generation_meta": generation_meta,
                    })
        except GeneratorExit:
            # Client disconnected mid-stream; Django closed the response iterator.
            outcome = "client_disconnect"
            raise
        except Exception:
            outcome = "error"
            logger.exception("chat generation failed for session %s", session.id)
            if accumulated:
                # chat_spec_v3_1.md §4.1: whatever text reached the user is kept, not discarded.
                self.chat_message_repository.create(
                    session=session, role=ChatMessage.Role.ASSISTANT, content=accumulated,
                    prompt_version=PROMPT_VERSION,
                )
            yield self._sse("error", {
                "status": "error",
                "code": "generation_failed",
                "user_message": get_message('chat_generation_failed'),
                "generation_meta": None,
            })
        finally:
            CHAT_ANSWER_IN_PROGRESS.labels(kind=kind).dec()
            CHAT_ANSWER_DURATION.labels(kind=kind, outcome=outcome).observe(
                time.perf_counter() - started
            )

    def send_message(self, *, user: User, session_id, user_message: str):
        session = self.chat_session_repository.get_for_user(session_id, user)
        if session is None:
            raise ChatSessionNotFoundException()

        if len(user_message) > MAX_MESSAGE_LENGTH:
            raise ChatMessageTooLongException()

        # Per-user daily cap on chat AI calls (open item #15: chat had no rate limit and a
        # single valid JWT could spam paid OpenAI calls). regenerate_message hits the same
        # counter -- it's a real new AI call too, just replacing an existing reply.
        if self.chat_message_throttle_repository.hit(user.id):
            THROTTLE_REJECTED.labels(scope="chat_message").inc()
            raise ChatMessageLimitExceededException()

        history = self.chat_message_repository.get_recent_for_session(session, limit=30)
        payload = self._build_payload(session=session, user=user, user_message=user_message, history=history)

        self.chat_message_repository.create(session=session, role=ChatMessage.Role.USER, content=user_message)

        return self._stream(session=session, payload=payload, kind="send")

    def regenerate_message(self, *, user: User, session_id, message_id: int):
        """Deletes an assistant message and streams a fresh reply in its place, generated from
        a real new call to the chat service (same _stream/_resolve_chunks path as send_message,
        not a cached response) using the user turn that originally triggered it. Once the old
        message is gone, get_session_messages for this session only ever returns the new one."""
        session = self.chat_session_repository.get_for_user(session_id, user)
        if session is None:
            raise ChatSessionNotFoundException()

        message = self.chat_message_repository.get_for_session(message_id, session)
        if message is None or message.role != ChatMessage.Role.ASSISTANT:
            raise ChatMessageNotFoundException()

        last_message = self.chat_message_repository.get_last_for_session(session)
        if last_message is None or last_message.id != message.id:
            raise RegenerateNotAllowedException()

        trigger_message = self.chat_message_repository.get_last_user_message_before(session, message)
        if trigger_message is None:
            raise ChatMessageNotFoundException()

        # Shares send_message's per-user daily counter -- a regenerate is a real new AI call
        # just like a send, so it should count against the same cap rather than being a free
        # way around it.
        if self.chat_message_throttle_repository.hit(user.id):
            THROTTLE_REJECTED.labels(scope="chat_message").inc()
            raise ChatMessageLimitExceededException()

        self.chat_message_repository.delete(message)

        history = [
            m for m in self.chat_message_repository.get_recent_for_session(session, limit=30)
            if m.id != trigger_message.id
        ]
        payload = self._build_payload(
            session=session, user=user, user_message=trigger_message.content, history=history,
        )

        return self._stream(session=session, payload=payload, kind="regenerate")

    def accept_action(self, *, user: User, message_id: int):
        """chat_spec_v3 §2.4/§5.2. Chat output is always a *new* step: a step can only be
        rejected before it is accepted, so there is never an existing row to replace (the
        replace-by-`id` path and the in-chat edit button are both gone). Any `id` the model
        still emits is ignored. ActionStepService.create_step schedules the notifications.
        Returns the resulting ActionStep so the caller knows its id without a second round
        trip."""
        message = self.chat_message_repository.get_assistant_message_for_user(message_id, user)
        if message is None or message.proposed_action is None or message.action_accepted_at is not None:
            raise ProposedActionUnavailableException()

        proposed_action = message.proposed_action
        action_step = self.action_step_service.create_step(
            user=user, source=SOURCE_CHAT, step_text=proposed_action["text"],
            deadline_type=proposed_action.get("deadline_type"), substeps=proposed_action.get("substeps"),
        )

        self.chat_message_repository.mark_action_accepted(message)
        return action_step
