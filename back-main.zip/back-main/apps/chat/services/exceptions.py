from rest_framework import status

from faraman_back.utils.exceptions import AppException


class ChatSessionNotFoundException(AppException):
    """Raised when session_id doesn't exist or doesn't belong to the requester."""
    status_code = status.HTTP_404_NOT_FOUND
    message_key = 'chat_session_not_found'


class InvalidEntrySourceException(AppException):
    """entry_source outside the allowed set, or deep_report_focus:<section> with an unknown
    section (chat_spec_v2 §6.1)."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'chat_invalid_entry_source'


class ReportRequiredForEntrySourceException(AppException):
    """entry_source is report_cta/deep_report_cta/deep_report_focus:<section> but no
    attempt_id/report was provided, or that attempt has no report the requester owns
    (chat_spec_v2 §6.1)."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'chat_report_required_for_entry_source'


class ReportTypeMismatchException(AppException):
    """entry_source implies a specific report type (initial for report_cta, deep for
    deep_report_cta/deep_report_focus:<section>) but attempt_id's report is the other type --
    e.g. a deep-report page CTA pointed at an initial attempt's id."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'chat_report_type_mismatch'


class ReportVersionMismatchException(AppException):
    """entry_source is report_open_question but the attempt's initial report is report_v1,
    which has no open question (chat_spec_v3_1 §6.1)."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'chat_report_version_mismatch'


class ActionRequiredForEntrySourceException(AppException):
    """entry_source is action_rejected/action_completed/action_missed but no action_step_id was
    provided, or that step doesn't belong to the requester (chat_spec_v3 §1.1/§1.4)."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'chat_action_required_for_entry_source'


class ActionStepNotMissedException(AppException):
    """entry_source is action_missed but the bound step's status isn't not_done/partial
    (chat_spec_v3 §1.1). A pending step whose deadline passed without an answer has no chat
    button -- what happened has to be recorded first, or the model can't tell success from
    failure."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'chat_action_step_not_missed'


class ActionStepNotActiveException(AppException):
    """entry_source is action_active but the bound step's status isn't pending
    (action_steps_spec_v2_2.md §6.2). The "let's talk about it" button only exists on a step still
    awaiting its deadline -- once it's recorded done/not_done/partial, the conversation is
    action_completed/action_missed instead."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'chat_action_step_not_active'


class ChatMessageTooLongException(AppException):
    """user_message exceeds the backend-enforced length cap (chat_spec_v3_1.md §6.3)."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'chat_message_too_long'


class ChatMessageNotFoundException(AppException):
    """message_id doesn't exist, isn't an assistant message, or doesn't belong to the requester
    -- used by feedback/bookmark/regenerate, which all only ever act on the requester's own
    assistant messages."""
    status_code = status.HTTP_404_NOT_FOUND
    message_key = 'chat_message_not_found'


class ProposedActionUnavailableException(AppException):
    """accept-action called on a message with no proposed_action, or already accepted."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'chat_proposed_action_unavailable'


class ChatMessageLimitExceededException(AppException):
    """The requester has already sent CHAT_MESSAGE_LIMIT_COUNT messages within the current
    rolling window (see ChatMessageThrottleRepository) -- an unlimited chat send endpoint is
    a way to spam real, paid OpenAI calls off a single account."""
    status_code = status.HTTP_429_TOO_MANY_REQUESTS
    message_key = 'chat_message_limit_exceeded'


class RegenerateNotAllowedException(AppException):
    """regenerate called on an assistant message that isn't the session's last message.

    Regenerate deletes the message outright and re-streams a fresh reply in its place; doing
    that to anything but the last turn would leave later turns in the same session standing on
    context that no longer exists in the transcript.
    """
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'chat_regenerate_not_allowed'
