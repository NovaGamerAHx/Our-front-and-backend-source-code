from decimal import Decimal

from django.utils import timezone

from apps.account.models import User
from apps.chat.models import ChatGenerationLog, ChatMessage, ChatSession


class ChatGenerationLogRepository:
    def create(
        self, *, session: ChatSession, message: ChatMessage | None, user: User | None,
        model_used: str | None, attempts: int, input_tokens: int, cached_input_tokens: int,
        output_tokens: int, latency_s: float, cost: Decimal | None, prompt_version: str = "",
    ) -> ChatGenerationLog:
        return ChatGenerationLog.objects.create(
            session=session,
            message=message,
            user=user,
            model_used=model_used,
            attempts=attempts,
            input_tokens=input_tokens,
            cached_input_tokens=cached_input_tokens,
            output_tokens=output_tokens,
            latency_s=latency_s,
            cost=cost,
            prompt_version=prompt_version,
        )

    def soft_delete_for_user(self, user: User) -> int:
        return ChatGenerationLog.objects.filter(user=user, is_deleted=False).update(
            is_deleted=True, deleted_at=timezone.now()
        )
