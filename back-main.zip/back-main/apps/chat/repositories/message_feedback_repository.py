from apps.account.models import User
from apps.chat.models import ChatMessage, MessageFeedback


class MessageFeedbackRepository:
    def upsert(self, *, message: ChatMessage, user: User, is_useful: bool) -> MessageFeedback:
        feedback, _ = MessageFeedback.objects.update_or_create(
            message=message, user=user, defaults={"is_useful": is_useful},
        )
        return feedback

    def get_feedback_map(self, *, user: User, messages: list[ChatMessage]) -> dict[int, bool]:
        """message_id -> is_useful, for this user's own vote on each of `messages` -- lets a
        session transcript re-render which vote (if any) the requester already cast."""
        return dict(
            MessageFeedback.objects.filter(user=user, message__in=messages).values_list("message_id", "is_useful")
        )

    def delete(self, *, message: ChatMessage, user: User) -> None:
        MessageFeedback.objects.filter(message=message, user=user).delete()
