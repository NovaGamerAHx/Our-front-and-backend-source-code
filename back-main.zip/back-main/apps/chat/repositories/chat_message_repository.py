from django.utils import timezone

from apps.chat.models import CHAT_SESSION_TITLE_MAX_LENGTH, ChatMessage, ChatSession


class ChatMessageRepository:
    def create(
        self, *, session: ChatSession, role: str, content: str, proposed_action: dict | None = None,
        quick_replies: list[str] | None = None, prompt_version: str = "", generation_meta: dict | None = None,
    ) -> ChatMessage:
        message = ChatMessage.objects.create(
            session=session,
            role=role,
            content=content,
            proposed_action=proposed_action,
            quick_replies=quick_replies,
            prompt_version=prompt_version,
            generation_meta=generation_meta,
        )
        self._touch_session(session, message)
        return message

    @staticmethod
    def _touch_session(session: ChatSession, message: ChatMessage) -> None:
        """Keep ChatSession's denormalized history-panel columns current (see the model): bump
        `last_message_at` on every message, and set `title` from the first user message. Done
        with an UPDATE keyed on pk rather than session.save() so it can't clobber a concurrent
        write to another column."""
        updates = {"last_message_at": message.created_at}
        session.last_message_at = message.created_at
        if message.role == ChatMessage.Role.USER and not session.title:
            title = message.content[:CHAT_SESSION_TITLE_MAX_LENGTH]
            updates["title"] = title
            session.title = title
        ChatSession.objects.filter(pk=session.pk).update(**updates)

    def get_recent_for_session(self, session: ChatSession, limit: int = 30) -> list[ChatMessage]:
        """Oldest-first, capped at the last `limit` messages (chat_spec_v3_1.md §1 `history`)."""
        messages = list(ChatMessage.objects.filter(session=session).order_by("-created_at")[:limit])
        messages.reverse()
        return messages

    def get_all_for_session(self, session: ChatSession) -> list[ChatMessage]:
        """Oldest-first, unlimited -- for displaying a session's full transcript, as opposed to
        get_recent_for_session's 30-message cap for AI-payload assembly."""
        return list(ChatMessage.objects.filter(session=session).order_by("created_at"))

    def get_last_for_session(self, session: ChatSession) -> ChatMessage | None:
        return ChatMessage.objects.filter(session=session).order_by("-created_at").first()

    def get_for_session(self, message_id, session: ChatSession) -> ChatMessage | None:
        return ChatMessage.objects.filter(id=message_id, session=session).first()

    def get_assistant_message_for_user(self, message_id, user) -> ChatMessage | None:
        return ChatMessage.objects.select_related("session").filter(
            id=message_id, session__user=user, role=ChatMessage.Role.ASSISTANT,
        ).first()

    def mark_action_accepted(self, message: ChatMessage) -> None:
        message.action_accepted_at = timezone.now()
        message.save(update_fields=["action_accepted_at"])

    def get_last_user_message_before(self, session: ChatSession, message: ChatMessage) -> ChatMessage | None:
        """The user turn that triggered `message` -- what regenerate resends to the chat
        service (ChatService.regenerate_message)."""
        return ChatMessage.objects.filter(
            session=session, role=ChatMessage.Role.USER, created_at__lt=message.created_at,
        ).order_by("-created_at").first()

    def delete(self, message: ChatMessage) -> None:
        message.delete()
