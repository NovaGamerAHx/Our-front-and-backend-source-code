import logging

import redis
from django.conf import settings

logger = logging.getLogger(__name__)

CHAT_MESSAGE_LIMIT_WINDOW_SECONDS = 60 * 60 * 24  # 24h, rolling from the user's first message of the window


class ChatMessageThrottleRepository:
    """Fixed-window counter limiting how many messages a user can send into chat per day.

    Same shape as AttemptThrottleRepository (apps/assessment/repositories/attempt_throttle_repository.py):
    a rolling 24h window keyed off the first hit, not a calendar day. Fails open on Redis
    errors so an outage doesn't block chatting."""

    def __init__(self):
        self._client = None

    @property
    def client(self):
        if self._client is None:
            self._client = redis.StrictRedis(
                host=getattr(settings, 'REDIS_HOST', 'localhost'),
                port=getattr(settings, 'REDIS_PORT', 6379),
                db=getattr(settings, 'REDIS_DB', 0),
                password=getattr(settings, 'REDIS_PASSWORD', ''),
                decode_responses=True,
            )
        return self._client

    @staticmethod
    def _key(user_id: int) -> str:
        return f"chat_message_limit:{user_id}"

    def hit(self, user_id: int) -> bool:
        """Increments the counter for user_id and returns whether it is now over
        settings.CHAT_MESSAGE_LIMIT_COUNT within the current window."""
        try:
            key = self._key(user_id)
            count = self.client.incr(key)
            if count == 1:
                self.client.expire(key, CHAT_MESSAGE_LIMIT_WINDOW_SECONDS)
            return count > settings.CHAT_MESSAGE_LIMIT_COUNT
        except Exception:
            logger.exception(f"Failed to check chat message limit for user {user_id}")
            return False
