from apps.account.models import User
from apps.action_steps.models import ActionStep
from apps.chat.models import ChatSession
from apps.report.models import Report


class ChatSessionRepository:
    def create(
        self, *, user: User, entry_source: str, report: Report | None = None,
        context_action_step: ActionStep | None = None, context_suggested_step: dict | None = None,
    ) -> ChatSession:
        return ChatSession.objects.create(
            user=user, entry_source=entry_source, report=report, context_action_step=context_action_step,
            context_suggested_step=context_suggested_step,
        )

    def get_for_user(self, session_id, user: User) -> ChatSession | None:
        return (
            ChatSession.objects.select_related("report", "context_action_step")
            .filter(id=session_id, user=user)
            .first()
        )

    def get_list_for_user(self, user: User, *, limit: int, offset: int = 0) -> list[ChatSession]:
        """One newest-activity-first page of the user's sessions. `title` and `last_message_at`
        are denormalized columns kept current by ChatMessageRepository.create, so this is a
        single-table indexed read -- no per-session preview/last-message lookups (see
        ChatService.list_sessions)."""
        return list(
            ChatSession.objects.filter(user=user)
            .order_by("-last_message_at")[offset:offset + limit]
        )

    def delete(self, session: ChatSession) -> None:
        session.delete()
