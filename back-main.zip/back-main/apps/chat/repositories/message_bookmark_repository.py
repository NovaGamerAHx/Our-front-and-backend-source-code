from apps.account.models import User
from apps.chat.models import ChatMessage, MessageBookmark


class MessageBookmarkRepository:
    def create_if_missing(self, *, message: ChatMessage, user: User) -> None:
        MessageBookmark.objects.get_or_create(message=message, user=user)

    def delete(self, *, message: ChatMessage, user: User) -> None:
        MessageBookmark.objects.filter(message=message, user=user).delete()

    def get_for_user(self, user: User) -> list[MessageBookmark]:
        return list(
            MessageBookmark.objects.filter(user=user)
            .select_related("message", "message__session")
            .order_by("-created_at")
        )

    def get_bookmarked_message_ids(self, *, user: User, messages: list[ChatMessage]) -> set[int]:
        """Which of `messages` this user has bookmarked -- lets a session transcript re-render
        the bookmark state the requester already set."""
        return set(
            MessageBookmark.objects.filter(user=user, message__in=messages).values_list("message_id", flat=True)
        )
