from django.urls import path

from apps.chat.views.message_view import BookmarkedMessagesAPIView, MessageBookmarkAPIView, MessageFeedbackAPIView

# Literal contract paths under /api/messages/ -- outside apps/chat/urls.py's own /api/chat/
# convention, same rationale as apps/chat/checkin_urls.py.
app_name = "messages"

urlpatterns = [
    path("bookmarked/", BookmarkedMessagesAPIView.as_view(), name="bookmarked_messages"),
    path("<int:message_id>/feedback/", MessageFeedbackAPIView.as_view(), name="message_feedback"),
    path("<int:message_id>/bookmark/", MessageBookmarkAPIView.as_view(), name="message_bookmark"),
]
