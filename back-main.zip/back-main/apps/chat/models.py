import uuid

from django.conf import settings
from django.db import models
from django.utils import timezone

from apps.action_steps.models import ActionStep
from apps.report.models import Report

# History-panel title: the first user message, truncated, until an AI summary replaces it.
CHAT_SESSION_TITLE_MAX_LENGTH = 120


class ChatSession(models.Model):
    """One chat conversation (chat_spec_v2 §1). `id` doubles as the spec's `session_id`.

    `entry_source` is fixed at creation and never changes (chat_spec_v2 §1.1) -- continuing
    from history does not change it, and every distinct entry_source (including switching from
    one action step to another) starts a brand-new session. It's a plain CharField rather than
    TextChoices because `deep_report_focus:<section>` is a templated value, not a fixed enum
    member; validity is checked in ChatService.create_session.
    """

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="chat_sessions")
    entry_source = models.CharField(max_length=40)
    report = models.ForeignKey(Report, null=True, blank=True, on_delete=models.SET_NULL, related_name="chat_sessions")
    # Only set for action_rejected/action_completed/action_missed sessions (chat_spec_v3 §1.4)
    # -- the step the conversation is about, sent to the AI service as `context_action`.
    context_action_step = models.ForeignKey(
        ActionStep, null=True, blank=True, on_delete=models.SET_NULL, related_name="chat_sessions",
    )
    # action_rejected only, and mutually exclusive with context_action_step: a snapshot of a
    # report suggested_step/small_action the user rejected before ever accepting it, so there is
    # no ActionStep row to point at (action_steps_spec_v2_2.md §3 -- rejecting doesn't persist anything).
    # {"text", "deadline_type", "deadline_text"}, shaped straight from ReportService
    # .get_suggested_step(). See ChatService._build_context_action.
    context_suggested_step = models.JSONField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    # Denormalized for the history-panel list (ChatService.list_sessions) so it never has to
    # look at ChatMessage rows. Both are maintained by ChatMessageRepository.create on every
    # message insert: `title` is set once, from the first user message (truncated to
    # CHAT_SESSION_TITLE_MAX_LENGTH), and left alone after; `last_message_at` is bumped every
    # time. `title` is "" for a session that has no user message yet.
    title = models.CharField(max_length=CHAT_SESSION_TITLE_MAX_LENGTH, blank=True)
    last_message_at = models.DateTimeField(default=timezone.now)

    class Meta:
        indexes = [
            models.Index(fields=["user", "-last_message_at"], name="chat_session_user_activity_idx"),
        ]

    def __str__(self):
        return f"ChatSession {self.id} ({self.entry_source})"


class ChatMessage(models.Model):
    """One turn in a ChatSession (chat_spec_v3_1.md §2). `content` is always the clean display
    text -- never the `<<<ACTION>>>` separator or its JSON (§3, storage note)."""

    class Role(models.TextChoices):
        USER = "user", "User"
        ASSISTANT = "assistant", "Assistant"

    session = models.ForeignKey(ChatSession, on_delete=models.CASCADE, related_name="messages")
    role = models.CharField(max_length=10, choices=Role.choices)
    content = models.TextField()
    proposed_action = models.JSONField(null=True, blank=True)
    # Tap-able reply options for this turn (e.g. ["امشب", "فردا صبح", "فردا عصر"]). Not part of
    # chat_spec_v3_1.md's AI-service contract -- a backend<->frontend-only addition (like
    # message_id), mutually exclusive with proposed_action on any given message.
    quick_replies = models.JSONField(null=True, blank=True)
    prompt_version = models.CharField(max_length=20, blank=True)
    generation_meta = models.JSONField(null=True, blank=True)
    action_accepted_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.role} message #{self.id} in session {self.session_id}"


class MessageFeedback(models.Model):
    """A user's usefulness vote on one assistant ChatMessage. Deliberately just a boolean flag,
    no free-text field. The (message, user) unique constraint is what makes repeat submissions
    an update rather than a duplicate insert (MessageFeedbackRepository.upsert)."""

    message = models.ForeignKey(ChatMessage, on_delete=models.CASCADE, related_name="feedbacks")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="message_feedbacks")
    is_useful = models.BooleanField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["message", "user"], name="unique_message_feedback_per_user"),
        ]

    def __str__(self):
        return f"MessageFeedback #{self.id} on message {self.message_id} by user {self.user_id}"


class ChatGenerationLog(models.Model):
    """One row per chat AI generation call (chat_spec_v3_1.md §2.6), success or failure alike.

    The chat analogue of `apps.report.models.GenerationLog`: operational/analytics data about
    the *call*, kept off the `ChatMessage` row on purpose. `ChatMessage.generation_meta` is
    the AI service's raw usage feed; this is the priced, queryable copy of it -- one place to
    sum spend per user/model/day without unpacking a JSON column.

    `cost` is computed by `apps.ai.pricing.calculate_cost` against the shared
    `apps.ai.models.ModelPricing` table and *includes the discounted price of cached input
    tokens* (`cached_input_tokens`). It is `None` when `model_used` is `None` or that model
    has no configured price -- never a guess.

    `message` is `SET_NULL`, not `CASCADE`: regenerating an answer deletes the old
    `ChatMessage`, but the call it cost money for still happened and its row stays.
    """

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True,
        related_name="chat_generation_logs",
    )
    session = models.ForeignKey(ChatSession, on_delete=models.CASCADE, related_name="generation_logs")
    message = models.ForeignKey(
        ChatMessage, on_delete=models.SET_NULL, null=True, blank=True, related_name="generation_logs",
    )
    model_used = models.CharField(max_length=100, null=True, blank=True)
    attempts = models.PositiveIntegerField(default=0)
    input_tokens = models.PositiveIntegerField(default=0)
    # The slice of `input_tokens` the provider served from its prompt cache. If this is 0 on
    # every turn after the first, caching is not working (chat_spec_v3_1.md §2.6).
    cached_input_tokens = models.PositiveIntegerField(default=0)
    output_tokens = models.PositiveIntegerField(default=0)
    latency_s = models.FloatField(default=0.0)
    cost = models.DecimalField(max_digits=12, decimal_places=6, null=True, blank=True)
    prompt_version = models.CharField(max_length=20, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "chat_generation_logs"

    def __str__(self):
        return f"ChatGenerationLog for session {self.session_id} ({self.model_used or 'failed'})"


class MessageBookmark(models.Model):
    """A user's bookmark on one assistant ChatMessage, for the frontend's bookmarked-messages
    page. The (message, user) unique constraint makes bookmark/unbookmark idempotent."""

    message = models.ForeignKey(ChatMessage, on_delete=models.CASCADE, related_name="bookmarks")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="message_bookmarks")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["message", "user"], name="unique_message_bookmark_per_user"),
        ]

    def __str__(self):
        return f"MessageBookmark #{self.id} on message {self.message_id} by user {self.user_id}"
