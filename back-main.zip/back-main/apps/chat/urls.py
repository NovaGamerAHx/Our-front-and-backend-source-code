from django.urls import path

from apps.chat.views.chat_view import (
    ChatActionAcceptAPIView,
    ChatMessageRegenerateAPIView,
    ChatSessionAPIView,
    ChatSessionListCreateAPIView,
    ChatSessionMessagesAPIView,
)
app_name = "chat"

urlpatterns = [
    path("sessions/", ChatSessionListCreateAPIView.as_view(), name="session_list_create"),
    path("sessions/<uuid:session_id>/", ChatSessionAPIView.as_view(), name="session_detail"),
    path("sessions/<uuid:session_id>/messages/", ChatSessionMessagesAPIView.as_view(), name="session_messages"),
    path(
        "sessions/<uuid:session_id>/messages/<int:message_id>/regenerate/",
        ChatMessageRegenerateAPIView.as_view(),
        name="regenerate_message",
    ),
    path("messages/<int:message_id>/accept-action/", ChatActionAcceptAPIView.as_view(), name="accept_action"),
]
