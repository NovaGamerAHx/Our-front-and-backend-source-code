from drf_spectacular.utils import extend_schema
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView

from apps.notifications.serializers.push_subscription_serializer import (
    RegisterPushSubscriptionSerializer,
    UnregisterPushSubscriptionSerializer,
)
from apps.notifications.services.push_subscription_service import PushSubscriptionService
from faraman_back.lang.utils import get_message
from faraman_back.utils.responses import ApiResponse


class PushSubscriptionAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.push_subscription_service = PushSubscriptionService()

    @extend_schema(
        description="Registers (or reactivates) an FCM push token for the authenticated user's "
                    "current browser/device. `token_was_inactive` is true when this exact token "
                    "had been deactivated before (FCM rejected it) -- the client should discard it "
                    "and register a freshly minted one.",
        tags=["Notifications"],
        request=RegisterPushSubscriptionSerializer,
    )
    def post(self, request):
        ser = RegisterPushSubscriptionSerializer(data=request.data)
        if not ser.is_valid():
            return ApiResponse.validation_error(data=ser.errors)

        _, token_was_inactive = self.push_subscription_service.register(user=request.user, **ser.validated_data)

        return ApiResponse.success(
            data={"token_was_inactive": token_was_inactive},
            message=get_message("push_subscription_registered"),
        )

    @extend_schema(
        description="Deactivates a push token (e.g. the user turned notifications off).",
        tags=["Notifications"],
        request=UnregisterPushSubscriptionSerializer,
    )
    def delete(self, request):
        ser = UnregisterPushSubscriptionSerializer(data=request.data)
        if not ser.is_valid():
            return ApiResponse.validation_error(data=ser.errors)

        self.push_subscription_service.unregister(ser.validated_data["token"])

        return ApiResponse.success(message=get_message("push_subscription_removed"))
