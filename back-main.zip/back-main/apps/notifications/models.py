from django.conf import settings
from django.db import models

from apps.action_steps.models import ActionStep


class PushSubscription(models.Model):
    """One FCM registration token for one browser/device. `token` (not `(user, token)`) is the
    natural identity: if a different user logs into the same browser, re-registering correctly
    reassigns ownership rather than accumulating stale rows."""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="push_subscriptions")
    token = models.TextField(unique=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "push_subscriptions"
        indexes = [
            models.Index(fields=["user", "is_active"]),
        ]

    def __str__(self):
        return f"PushSubscription #{self.id} for user #{self.user_id} ({'active' if self.is_active else 'inactive'})"


class Notification(models.Model):
    """A scheduled push for one ActionStep. No title/body/deep-link fields on purpose -- those
    are computed at send time from `action_step.step_text`/`.id`, so there's one source of truth
    and nothing can go stale between scheduling and sending.

    Two rows per step now (action_steps_spec_v2 §7): a `reminder` at `action_step.remind_at`
    (before the deadline) and a `followup` at `action_step.followup_at` (right after it) --
    `kind` is what the old single-notification model didn't need to distinguish."""

    class Kind(models.TextChoices):
        REMINDER = "reminder", "Reminder"
        FOLLOWUP = "followup", "Followup"

    class Status(models.TextChoices):
        SCHEDULED = "scheduled", "Scheduled"
        SENT = "sent", "Sent"
        FAILED = "failed", "Failed"
        CANCELLED = "cancelled", "Cancelled"

    action_step = models.ForeignKey(ActionStep, on_delete=models.CASCADE, related_name="notifications")
    kind = models.CharField(max_length=10, choices=Kind.choices)
    scheduled_for = models.DateTimeField()
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.SCHEDULED)
    sent_at = models.DateTimeField(null=True, blank=True)
    # Why a `failed` row failed: `no_subscriptions`, `all_tokens_invalid`, or
    # `send_error: <ExceptionType>: <message>`. Empty for every other status.
    failure_reason = models.CharField(max_length=255, blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "notifications"
        indexes = [
            models.Index(fields=["status", "scheduled_for"]),
        ]

    def __str__(self):
        return f"Notification #{self.id} ({self.kind}) for step #{self.action_step_id} ({self.status})"
