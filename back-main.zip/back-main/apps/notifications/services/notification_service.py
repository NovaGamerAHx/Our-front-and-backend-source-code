import logging
from datetime import datetime

from apps.action_steps.models import ActionStep
from apps.notifications.models import Notification
from apps.notifications.repositories.notification_repository import NotificationRepository
from apps.notifications.repositories.push_subscription_repository import PushSubscriptionRepository
from apps.notifications.services.push_sender import PushSender, PushTokenInvalidException
from faraman_back.observability.metrics import NOTIFICATION_SEND_DURATION, observe

logger = logging.getLogger(__name__)


class NotificationService:
    def __init__(self, notification_repository=None, push_subscription_repository=None, push_sender=None):
        self.notification_repository = notification_repository or NotificationRepository()
        self.push_subscription_repository = push_subscription_repository or PushSubscriptionRepository()
        self.push_sender = push_sender or PushSender()

    def schedule_for_step(self, action_step: ActionStep) -> tuple[Notification, Notification]:
        """action_steps_spec_v2 §7: up to two notifications per step -- a reminder before the
        deadline and a followup right after it (both timestamps computed by
        apps.action_steps.services.deadline_calculator when the step was created/edited)."""
        reminder = self.notification_repository.create(
            action_step=action_step, kind=Notification.Kind.REMINDER, scheduled_for=action_step.remind_at,
        )
        followup = self.notification_repository.create(
            action_step=action_step, kind=Notification.Kind.FOLLOWUP, scheduled_for=action_step.followup_at,
        )
        return reminder, followup

    def cancel_for_step(self, action_step: ActionStep) -> None:
        """Cancels both still-scheduled rows -- called when the step is completed/answered so a
        stray reminder or followup doesn't fire after the fact."""
        self.notification_repository.cancel_scheduled_for_step(action_step)

    def reschedule_for_step(self, action_step: ActionStep) -> tuple[Notification, Notification]:
        """Called when an already-scheduled step's deadline_type is edited
        (ActionStepService.edit_step): cancels whichever reminder/followup rows are still
        scheduled -- a reminder that already fired stays `sent`, untouched -- and schedules fresh
        ones against the step's newly recomputed remind_at/followup_at."""
        self.cancel_for_step(action_step)
        return self.schedule_for_step(action_step)

    @observe(
        NOTIFICATION_SEND_DURATION,
        labels=lambda self, notification: {"kind": notification.kind},
        outcome=lambda result: result,
    )
    def _send_one(self, notification: Notification) -> str:
        step = notification.action_step
        subscriptions = self.push_subscription_repository.get_active_for_user(step.user)
        if not subscriptions:
            logger.warning("notification #%s (%s) for step #%s has no active push subscriptions -- "
                            "marking failed", notification.id, notification.kind, step.id)
            self.notification_repository.mark_failed(notification, "no_subscriptions")
            return "no_subscriptions"

        if notification.kind == Notification.Kind.REMINDER:
            title = "یادآوری"
            body = f"قدم «{step.step_text}» رو یادت نره"
        else:
            title = "پیگیری"
            body = f"قدم «{step.step_text}» — انجامش دادی؟"
        # `kind` on the query string so the checkin page shows the matching card (reminder's
        # "did you already do it" vs followup's done/partial/not_done) without a second lookup.
        url = f"/checkin/{step.id}?kind={notification.kind}"

        any_success = False
        any_invalid_token = False
        last_error: Exception | None = None
        for subscription in subscriptions:
            try:
                self.push_sender.send(token=subscription.token, title=title, body=body, url=url)
                any_success = True
                logger.info("push sent for notification #%s, token ending %s",
                            notification.id, subscription.token[-8:])
            except PushTokenInvalidException:
                any_invalid_token = True
                logger.warning("push token invalid for notification #%s, token ending %s -- deactivating",
                                notification.id, subscription.token[-8:])
                self.push_subscription_repository.deactivate_by_token(subscription.token)
            except Exception as exc:
                last_error = exc
                logger.exception("push send failed for notification #%s, token ending %s",
                                  notification.id, subscription.token[-8:])

        if any_success:
            self.notification_repository.mark_sent(notification)
            return "sent"

        if last_error is not None:
            # A real error outranks invalid tokens: it's the thing someone needs to go fix.
            self.notification_repository.mark_failed(
                notification, f"send_error: {type(last_error).__name__}: {last_error}",
            )
            return "send_error"
        self.notification_repository.mark_failed(notification, "all_tokens_invalid")
        logger.warning("notification #%s (%s) for step #%s failed -- every active subscription "
                        "had an invalid token", notification.id, notification.kind, step.id)
        return "all_tokens_invalid"

    def send_due(self, *, now: datetime | None = None) -> None:
        due = self.notification_repository.get_due(now=now)
        logger.info("send_due: %d notification(s) due", len(due))
        for notification in due:
            self._send_one(notification)
