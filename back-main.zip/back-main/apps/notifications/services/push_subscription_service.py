from apps.account.models import User
from apps.notifications.models import PushSubscription
from apps.notifications.repositories.push_subscription_repository import PushSubscriptionRepository


class PushSubscriptionService:
    def __init__(self, push_subscription_repository=None):
        self.push_subscription_repository = push_subscription_repository or PushSubscriptionRepository()

    def register(self, *, user: User, token: str) -> tuple[PushSubscription, bool]:
        return self.push_subscription_repository.upsert(user=user, token=token)

    def unregister(self, token: str) -> None:
        self.push_subscription_repository.deactivate_by_token(token)
