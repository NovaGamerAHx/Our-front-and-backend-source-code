class PushTokenInvalidException(Exception):
    """Not an AppException subclass -- this never crosses a view boundary, it's pure control
    flow inside the Celery send task (NotificationService.send_due)."""


def _ensure_firebase_app() -> None:
    """Lazy, once-per-process init -- guarded so it never runs at Django boot (manage.py test/
    migrate/shell would otherwise crash on any machine without a real credential file yet)."""
    import firebase_admin
    from django.conf import settings
    from firebase_admin import credentials

    if not firebase_admin._apps:
        firebase_admin.initialize_app(credentials.Certificate(settings.FCM_CREDENTIAL_PATH))


class PushSender:
    def send(self, *, token: str, title: str, body: str, url: str) -> None:
        from firebase_admin import messaging

        _ensure_firebase_app()

        # Data-only (no top-level `notification`) -- Firebase's Web SDK auto-displays its own
        # browser-native notification for any message that has a `notification` payload, on top
        # of onBackgroundMessage() in firebase-messaging-sw.js also calling showNotification(),
        # producing two visible notifications per push. Data-only keeps showNotification() the
        # single source of truth.
        message = messaging.Message(
            data={"title": title, "body": body, "url": url},
            token=token,
        )
        try:
            messaging.send(message)
        except messaging.UnregisteredError:
            raise PushTokenInvalidException()
