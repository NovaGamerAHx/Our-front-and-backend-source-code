from django.urls import path

from apps.notifications.views.push_subscription_view import PushSubscriptionAPIView

app_name = "notifications"

urlpatterns = [
    path("push-subscriptions/", PushSubscriptionAPIView.as_view(), name="push_subscriptions"),
]
