from celery import shared_task

from apps.notifications.services.notification_service import NotificationService


@shared_task(name="notifications.send_due_notifications")
def send_due_notifications():
    NotificationService().send_due()
