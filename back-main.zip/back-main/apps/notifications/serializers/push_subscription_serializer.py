from rest_framework import serializers


class RegisterPushSubscriptionSerializer(serializers.Serializer):
    token = serializers.CharField()


class UnregisterPushSubscriptionSerializer(serializers.Serializer):
    token = serializers.CharField()
