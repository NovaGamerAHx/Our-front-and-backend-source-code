from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('notifications', '0002_notification_action_step'),
    ]

    operations = [
        migrations.AddField(
            model_name='notification',
            name='failure_reason',
            field=models.CharField(blank=True, default='', max_length=255),
        ),
    ]
