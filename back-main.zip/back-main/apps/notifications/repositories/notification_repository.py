from datetime import datetime

from django.utils import timezone

from apps.action_steps.models import ActionStep
from apps.notifications.models import Notification


class NotificationRepository:
    def create(self, *, action_step: ActionStep, kind: str, scheduled_for: datetime) -> Notification:
        return Notification.objects.create(action_step=action_step, kind=kind, scheduled_for=scheduled_for)

    def cancel_scheduled_for_step(self, action_step: ActionStep) -> None:
        """Cancels every still-scheduled row for this step -- both `kind`s -- so completing/
        answering it doesn't leave a stray reminder or followup pending."""
        Notification.objects.filter(
            action_step=action_step, status=Notification.Status.SCHEDULED,
        ).update(status=Notification.Status.CANCELLED)

    def get_due(self, *, now: datetime | None = None) -> list[Notification]:
        return list(
            Notification.objects.select_related("action_step", "action_step__user")
            .filter(status=Notification.Status.SCHEDULED, scheduled_for__lte=now or timezone.now())
        )

    def mark_sent(self, notification: Notification) -> None:
        notification.status = Notification.Status.SENT
        notification.sent_at = timezone.now()
        notification.save(update_fields=["status", "sent_at"])

    def mark_failed(self, notification: Notification, reason: str = "") -> None:
        notification.status = Notification.Status.FAILED
        notification.failure_reason = reason[:255]
        notification.save(update_fields=["status", "failure_reason"])
