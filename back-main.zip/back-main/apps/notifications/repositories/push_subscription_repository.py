from apps.account.models import User
from apps.notifications.models import PushSubscription


class PushSubscriptionRepository:
    def upsert(self, *, user: User, token: str) -> tuple[PushSubscription, bool]:
        """Returns (subscription, was_inactive). `was_inactive` is True when this exact token
        already existed but had been deactivated (e.g. FCM reported it unregistered) -- the
        caller's cue that the browser is still handing out a dead token."""
        was_inactive = PushSubscription.objects.filter(token=token, is_active=False).exists()
        subscription, _ = PushSubscription.objects.update_or_create(
            token=token, defaults={"user": user, "is_active": True},
        )
        return subscription, was_inactive

    def deactivate_by_token(self, token: str) -> None:
        PushSubscription.objects.filter(token=token).update(is_active=False)

    def get_active_for_user(self, user: User) -> list[PushSubscription]:
        return list(PushSubscription.objects.filter(user=user, is_active=True))
