from unittest.mock import MagicMock, call

from django.test import TestCase

from apps.notifications.models import Notification
from apps.notifications.services.notification_service import NotificationService
from apps.notifications.services.push_sender import PushTokenInvalidException
from apps.notifications.services.push_subscription_service import PushSubscriptionService
from faraman_back.observability.testing import read_metric


def _notification_service(**overrides):
    defaults = dict(
        notification_repository=MagicMock(),
        push_subscription_repository=MagicMock(),
        push_sender=MagicMock(),
    )
    defaults.update(overrides)
    return NotificationService(**defaults), defaults


def _push_subscription_service(**overrides):
    defaults = dict(push_subscription_repository=MagicMock())
    defaults.update(overrides)
    return PushSubscriptionService(**defaults), defaults


class NotificationServiceScheduleTests(TestCase):
    def setUp(self):
        self.service, self.repos = _notification_service()

    def test_schedule_for_step_creates_reminder_and_followup_rows(self):
        action_step = MagicMock(remind_at="2026-01-01T09:00:00Z", followup_at="2026-01-01T12:00:00Z")

        self.service.schedule_for_step(action_step)

        self.repos["notification_repository"].create.assert_has_calls([
            call(action_step=action_step, kind=Notification.Kind.REMINDER, scheduled_for=action_step.remind_at),
            call(action_step=action_step, kind=Notification.Kind.FOLLOWUP, scheduled_for=action_step.followup_at),
        ])


class NotificationServiceCancelTests(TestCase):
    def setUp(self):
        self.service, self.repos = _notification_service()

    def test_cancel_for_step_cancels_scheduled_rows(self):
        action_step = MagicMock()

        self.service.cancel_for_step(action_step)

        self.repos["notification_repository"].cancel_scheduled_for_step.assert_called_once_with(action_step)


class NotificationServiceRescheduleTests(TestCase):
    def setUp(self):
        self.service, self.repos = _notification_service()

    def test_reschedule_for_step_cancels_then_creates_fresh_rows(self):
        action_step = MagicMock(remind_at="2026-01-02T09:00:00Z", followup_at="2026-01-02T12:00:00Z")

        self.service.reschedule_for_step(action_step)

        self.repos["notification_repository"].cancel_scheduled_for_step.assert_called_once_with(action_step)
        self.repos["notification_repository"].create.assert_has_calls([
            call(action_step=action_step, kind=Notification.Kind.REMINDER, scheduled_for=action_step.remind_at),
            call(action_step=action_step, kind=Notification.Kind.FOLLOWUP, scheduled_for=action_step.followup_at),
        ])


class NotificationServiceSendDueTests(TestCase):
    def setUp(self):
        self.service, self.repos = _notification_service()
        self.user = MagicMock(id=1)
        self.step = MagicMock(id=5, user=self.user, step_text="do the thing")
        self.notification = MagicMock(id=10, action_step=self.step, kind=Notification.Kind.REMINDER)
        self.repos["notification_repository"].get_due.return_value = [self.notification]

    def test_no_active_subscriptions_marks_failed_without_sending(self):
        self.repos["push_subscription_repository"].get_active_for_user.return_value = []

        self.service.send_due()

        self.repos["push_sender"].send.assert_not_called()
        self.repos["notification_repository"].mark_failed.assert_called_once_with(
            self.notification, "no_subscriptions",
        )

    def test_successful_reminder_send_marks_sent(self):
        subscription = MagicMock(token="tok-1")
        self.repos["push_subscription_repository"].get_active_for_user.return_value = [subscription]

        self.service.send_due()

        self.repos["push_sender"].send.assert_called_once_with(
            token="tok-1", title="یادآوری", body="قدم «do the thing» رو یادت نره", url="/checkin/5?kind=reminder",
        )
        self.repos["notification_repository"].mark_sent.assert_called_once_with(self.notification)
        self.repos["notification_repository"].mark_failed.assert_not_called()

    def test_successful_followup_send_uses_followup_copy(self):
        self.notification.kind = Notification.Kind.FOLLOWUP
        subscription = MagicMock(token="tok-1")
        self.repos["push_subscription_repository"].get_active_for_user.return_value = [subscription]

        self.service.send_due()

        self.repos["push_sender"].send.assert_called_once_with(
            token="tok-1", title="پیگیری", body="قدم «do the thing» — انجامش دادی؟", url="/checkin/5?kind=followup",
        )

    def test_invalid_token_deactivates_subscription_and_marks_failed_when_it_was_the_only_one(self):
        subscription = MagicMock(token="stale-tok")
        self.repos["push_subscription_repository"].get_active_for_user.return_value = [subscription]
        self.repos["push_sender"].send.side_effect = PushTokenInvalidException()

        self.service.send_due()

        self.repos["push_subscription_repository"].deactivate_by_token.assert_called_once_with("stale-tok")
        self.repos["notification_repository"].mark_failed.assert_called_once_with(
            self.notification, "all_tokens_invalid",
        )
        self.repos["notification_repository"].mark_sent.assert_not_called()

    def test_generic_send_error_records_exception_type_and_message_as_reason(self):
        subscription = MagicMock(token="tok-1")
        self.repos["push_subscription_repository"].get_active_for_user.return_value = [subscription]
        self.repos["push_sender"].send.side_effect = RuntimeError("boom")

        self.service.send_due()

        self.repos["notification_repository"].mark_failed.assert_called_once_with(
            self.notification, "send_error: RuntimeError: boom",
        )

    def test_send_error_outranks_invalid_token_in_failure_reason(self):
        stale, other = MagicMock(token="stale-tok"), MagicMock(token="tok-2")
        self.repos["push_subscription_repository"].get_active_for_user.return_value = [stale, other]
        self.repos["push_sender"].send.side_effect = [PushTokenInvalidException(), RuntimeError("quota")]

        self.service.send_due()

        self.repos["notification_repository"].mark_failed.assert_called_once_with(
            self.notification, "send_error: RuntimeError: quota",
        )

    def test_one_of_two_subscriptions_succeeding_still_marks_sent(self):
        good, stale = MagicMock(token="good-tok"), MagicMock(token="stale-tok")
        self.repos["push_subscription_repository"].get_active_for_user.return_value = [good, stale]
        self.repos["push_sender"].send.side_effect = [None, PushTokenInvalidException()]

        self.service.send_due()

        self.repos["push_subscription_repository"].deactivate_by_token.assert_called_once_with("stale-tok")
        self.repos["notification_repository"].mark_sent.assert_called_once_with(self.notification)


class NotificationSendMetricsTests(TestCase):
    """faraman_notification_send_duration_seconds -- the @observe decorator on
    NotificationService._send_one. Metric objects are process-global, so assert on deltas."""

    def setUp(self):
        self.service, self.repos = _notification_service()
        self.user = MagicMock(id=1)
        self.step = MagicMock(id=5, user=self.user, step_text="do the thing")
        self.notification = MagicMock(id=10, action_step=self.step, kind=Notification.Kind.REMINDER)
        self.repos["notification_repository"].get_due.return_value = [self.notification]

    def _count(self, kind, outcome):
        return read_metric(
            "faraman_notification_send_duration_seconds_count", kind=kind, outcome=outcome,
        ) or 0.0

    def test_no_subscriptions_records_no_subscriptions_outcome(self):
        self.repos["push_subscription_repository"].get_active_for_user.return_value = []

        before = self._count("reminder", "no_subscriptions")
        self.service.send_due()

        self.assertEqual(self._count("reminder", "no_subscriptions") - before, 1.0)

    def test_successful_send_records_sent_outcome(self):
        subscription = MagicMock(token="tok-1")
        self.repos["push_subscription_repository"].get_active_for_user.return_value = [subscription]

        before = self._count("reminder", "sent")
        self.service.send_due()

        self.assertEqual(self._count("reminder", "sent") - before, 1.0)

    def test_all_tokens_invalid_records_that_outcome(self):
        subscription = MagicMock(token="stale-tok")
        self.repos["push_subscription_repository"].get_active_for_user.return_value = [subscription]
        self.repos["push_sender"].send.side_effect = PushTokenInvalidException()

        before = self._count("reminder", "all_tokens_invalid")
        self.service.send_due()

        self.assertEqual(self._count("reminder", "all_tokens_invalid") - before, 1.0)

    def test_generic_send_error_records_send_error_outcome(self):
        subscription = MagicMock(token="tok-1")
        self.repos["push_subscription_repository"].get_active_for_user.return_value = [subscription]
        self.repos["push_sender"].send.side_effect = RuntimeError("boom")

        before = self._count("reminder", "send_error")
        self.service.send_due()

        self.assertEqual(self._count("reminder", "send_error") - before, 1.0)


class PushSubscriptionServiceTests(TestCase):
    def setUp(self):
        self.service, self.repos = _push_subscription_service()

    def test_register_upserts(self):
        user = MagicMock(id=1)

        self.service.register(user=user, token="tok-1")

        self.repos["push_subscription_repository"].upsert.assert_called_once_with(user=user, token="tok-1")

    def test_unregister_deactivates_by_token(self):
        self.service.unregister("tok-1")

        self.repos["push_subscription_repository"].deactivate_by_token.assert_called_once_with("tok-1")


class NotificationRepositoryFailureReasonTests(TestCase):
    def test_mark_failed_persists_status_and_reason(self):
        from apps.notifications.repositories.notification_repository import NotificationRepository
        notification = self._notification()

        NotificationRepository().mark_failed(notification, "no_subscriptions")

        notification.refresh_from_db()
        self.assertEqual(notification.status, Notification.Status.FAILED)
        self.assertEqual(notification.failure_reason, "no_subscriptions")

    def test_mark_failed_truncates_reason_to_column_width(self):
        from apps.notifications.repositories.notification_repository import NotificationRepository
        notification = self._notification()

        NotificationRepository().mark_failed(notification, "x" * 400)

        notification.refresh_from_db()
        self.assertEqual(len(notification.failure_reason), 255)

    def _notification(self):
        from django.utils import timezone
        from apps.account.models import User
        from apps.action_steps.models import ActionStep

        user = User.objects.create_user(phone_number="09120000000")
        now = timezone.now()
        step = ActionStep.objects.create(
            user=user, source="chat", step_text="x", deadline_type=ActionStep.DeadlineType.WITHIN_24H,
            deadline_at=now, remind_at=now, followup_at=now,
        )
        return Notification.objects.create(
            action_step=step, kind=Notification.Kind.REMINDER, scheduled_for=now,
        )


class PushSubscriptionRepositoryUpsertTests(TestCase):
    def setUp(self):
        from apps.account.models import User
        from apps.notifications.repositories.push_subscription_repository import PushSubscriptionRepository
        self.repo = PushSubscriptionRepository()
        self.user = User.objects.create_user(phone_number="09120000001")

    def test_new_token_is_not_reported_as_inactive(self):
        _, was_inactive = self.repo.upsert(user=self.user, token="tok-new")

        self.assertFalse(was_inactive)

    def test_already_active_token_is_not_reported_as_inactive(self):
        self.repo.upsert(user=self.user, token="tok-1")

        subscription, was_inactive = self.repo.upsert(user=self.user, token="tok-1")

        self.assertFalse(was_inactive)
        self.assertTrue(subscription.is_active)

    def test_deactivated_token_is_reactivated_and_reported_as_inactive(self):
        self.repo.upsert(user=self.user, token="tok-1")
        self.repo.deactivate_by_token("tok-1")

        subscription, was_inactive = self.repo.upsert(user=self.user, token="tok-1")

        self.assertTrue(was_inactive)
        self.assertTrue(subscription.is_active)
