from rest_framework import status

from faraman_back.utils.exceptions import AppException


class FeedbackTargetNotFoundException(AppException):
    """Raised when target_id doesn't reference an existing row of target_type."""
    status_code = status.HTTP_404_NOT_FOUND
    message_key = 'feedback_target_not_found'


class FeedbackTargetAccessDeniedException(AppException):
    """Raised when the target exists but doesn't belong to the requesting user."""
    status_code = status.HTTP_403_FORBIDDEN
    message_key = 'feedback_target_access_denied'
