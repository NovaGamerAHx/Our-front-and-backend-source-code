from apps.account.models import User
from apps.feedback.models import Feedback
from apps.feedback.repositories.feedback_repository import FeedbackRepository
from apps.feedback.services.exceptions import FeedbackTargetAccessDeniedException, FeedbackTargetNotFoundException
from apps.report.repositories.report_repository import ReportRepository


class FeedbackService:
    def __init__(self, feedback_repository=None, report_repository=None):
        self.feedback_repository = feedback_repository or FeedbackRepository()
        self.report_repository = report_repository or ReportRepository()

    def _validate_report_target(self, *, target_id: str, user: User) -> None:
        report = self.report_repository.get_by_id(int(target_id))
        if report is None:
            raise FeedbackTargetNotFoundException(f"No report found with id {target_id}")
        if report.attempt.user_id != user.id:
            raise FeedbackTargetAccessDeniedException(f"Report {target_id} does not belong to this user")

    def submit(
        self, *, user: User, target_type: str, target_id: str, rate: int | None, reason: str, comment: str,
    ) -> Feedback:
        if target_type == Feedback.TargetType.REPORT:
            self._validate_report_target(target_id=target_id, user=user)

        return self.feedback_repository.create(
            user=user, target_type=target_type, target_id=target_id, rate=rate, reason=reason, comment=comment,
        )
