from django.utils import timezone

from apps.account.models import User
from apps.feedback.models import Feedback


class FeedbackRepository:
    def create(
        self, *, user: User, target_type: str, target_id: str, rate: int | None, reason: str, comment: str,
    ) -> Feedback:
        return Feedback.objects.create(
            user=user,
            target_type=target_type,
            target_id=target_id,
            rate=rate,
            reason=reason,
            comment=comment,
        )

    def soft_delete_for_user(self, user: User) -> int:
        return Feedback.objects.filter(user=user, is_deleted=False).update(is_deleted=True, deleted_at=timezone.now())
