from django.urls import path

from apps.feedback.views.feedback_view import SubmitFeedbackAPIView

app_name = "feedback"

urlpatterns = [
    path("", SubmitFeedbackAPIView.as_view(), name="submit_feedback"),
]
