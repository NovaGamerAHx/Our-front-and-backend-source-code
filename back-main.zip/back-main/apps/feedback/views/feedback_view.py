from drf_spectacular.utils import extend_schema
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView

from apps.feedback.serializers.feedback_serializer import SubmitFeedbackSerializer
from apps.feedback.services.exceptions import FeedbackTargetAccessDeniedException, FeedbackTargetNotFoundException
from apps.feedback.services.feedback_service import FeedbackService
from faraman_back.lang.utils import get_message
from faraman_back.utils.responses import ApiResponse
from faraman_back.utils.schema import error_responses


class SubmitFeedbackAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.feedback_service = FeedbackService()

    @extend_schema(
        description="Submits feedback (rating/reason/comment). `target_type=report` submits feedback on a "
                    "report owned by the authenticated user (target_id is the report id). "
                    "`target_type=app` submits general app feedback not tied to any report "
                    "(target_id is ignored).",
        tags=["Feedback"],
        request=SubmitFeedbackSerializer,
        responses=error_responses(FeedbackTargetNotFoundException, FeedbackTargetAccessDeniedException),
    )
    def post(self, request):
        ser = SubmitFeedbackSerializer(data=request.data)
        if not ser.is_valid():
            return ApiResponse.validation_error(data=ser.errors)

        self.feedback_service.submit(user=request.user, **ser.validated_data)

        return ApiResponse.success(message=get_message('feedback_submitted'))
