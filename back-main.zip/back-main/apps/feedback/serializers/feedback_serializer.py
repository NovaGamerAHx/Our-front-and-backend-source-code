from rest_framework import serializers

from apps.feedback.models import Feedback


class SubmitFeedbackSerializer(serializers.Serializer):
    target_type = serializers.ChoiceField(choices=Feedback.TargetType.choices)
    target_id = serializers.CharField(max_length=100)
    rate = serializers.IntegerField(required=False, allow_null=True, min_value=0, max_value=5, default=None)
    reason = serializers.CharField(required=False, allow_blank=True, max_length=40, default="")
    comment = serializers.CharField(required=False, allow_blank=True, default="")

    def validate(self, attrs):
        if attrs["target_type"] == Feedback.TargetType.REPORT and not attrs["target_id"].isdigit():
            raise serializers.ValidationError({"target_id": "Must be a numeric report id."})
        return attrs
