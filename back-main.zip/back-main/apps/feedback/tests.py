from unittest.mock import MagicMock

from django.test import TestCase

from apps.account.models import User
from apps.feedback.models import Feedback
from apps.feedback.services.exceptions import FeedbackTargetAccessDeniedException, FeedbackTargetNotFoundException
from apps.feedback.services.feedback_service import FeedbackService


class FeedbackServiceSubmitTests(TestCase):
    def setUp(self):
        self.feedback_repository = MagicMock()
        self.report_repository = MagicMock()
        self.service = FeedbackService(
            feedback_repository=self.feedback_repository, report_repository=self.report_repository,
        )
        self.user = User.objects.create(phone_number='09120000000')

    def test_raises_when_report_target_not_found(self):
        self.report_repository.get_by_id.return_value = None

        with self.assertRaises(FeedbackTargetNotFoundException):
            self.service.submit(
                user=self.user, target_type=Feedback.TargetType.REPORT, target_id='1',
                rate=5, reason='', comment='',
            )

        self.feedback_repository.create.assert_not_called()

    def test_raises_when_report_target_belongs_to_another_user(self):
        report = MagicMock()
        report.attempt.user_id = self.user.id + 1
        self.report_repository.get_by_id.return_value = report

        with self.assertRaises(FeedbackTargetAccessDeniedException):
            self.service.submit(
                user=self.user, target_type=Feedback.TargetType.REPORT, target_id='1',
                rate=5, reason='', comment='',
            )

        self.feedback_repository.create.assert_not_called()

    def test_creates_feedback_when_report_target_belongs_to_user(self):
        report = MagicMock()
        report.attempt.user_id = self.user.id
        self.report_repository.get_by_id.return_value = report
        created = MagicMock()
        self.feedback_repository.create.return_value = created

        result = self.service.submit(
            user=self.user, target_type=Feedback.TargetType.REPORT, target_id='1',
            rate=5, reason='not_me', comment='hi',
        )

        self.assertIs(result, created)
        self.report_repository.get_by_id.assert_called_once_with(1)
        self.feedback_repository.create.assert_called_once_with(
            user=self.user, target_type=Feedback.TargetType.REPORT, target_id='1',
            rate=5, reason='not_me', comment='hi',
        )

    def test_creates_app_feedback_without_report_lookup(self):
        created = MagicMock()
        self.feedback_repository.create.return_value = created

        result = self.service.submit(
            user=self.user, target_type=Feedback.TargetType.APP, target_id='app',
            rate=4, reason='', comment='great app',
        )

        self.assertIs(result, created)
        self.report_repository.get_by_id.assert_not_called()
        self.feedback_repository.create.assert_called_once_with(
            user=self.user, target_type=Feedback.TargetType.APP, target_id='app',
            rate=4, reason='', comment='great app',
        )
