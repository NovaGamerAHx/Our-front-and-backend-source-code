from django.contrib import admin

from apps.feedback.models import Feedback


@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "target_type", "target_id", "rate", "reason", "created_at")
    list_filter = ("target_type", "rate", "reason")
    search_fields = ("user__phone_number", "target_id", "comment")
    readonly_fields = [f.name for f in Feedback._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
