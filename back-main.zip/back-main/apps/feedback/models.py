from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models


class Feedback(models.Model):
    class TargetType(models.TextChoices):
        REPORT = "report", "Report"
        APP = "app", "App"

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="feedbacks")
    target_type = models.CharField(max_length=30, choices=TargetType.choices)
    target_id = models.CharField(max_length=100)
    rate = models.SmallIntegerField(null=True, blank=True, validators=[MinValueValidator(0), MaxValueValidator(5)])
    reason = models.CharField(max_length=40, blank=True)
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "feedbacks"
        indexes = [
            models.Index(fields=["target_type", "target_id"]),
        ]

    def __str__(self):
        return f"Feedback #{self.id} on {self.target_type}:{self.target_id}"
