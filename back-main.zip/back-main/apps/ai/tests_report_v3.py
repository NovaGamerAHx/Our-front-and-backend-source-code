"""report_v3 tests for the AI layer (docs/report_spec_v3_0.md).

Everything here runs offline: the provider is always the injected _FakeOpenAIClient from
apps.ai.tests, so no paid call is ever made. Fixtures come from the two golden examples that
ship in fewshot_v3/, which are byte-identical to the ones in v3 help/V3_LLM_REFERENCE.md.

One standing caveat, asserted rather than worked around: golden example 1 cites `q20` in its
source_map but its input contains no q20 evidence (the answer was neutral). That is a defect
in the supplied reference, not in this code. The golden is still sent to the model verbatim --
rewriting the user's few-shot examples is out of scope -- so the test below pins the defect in
place: if someone "fixes" the fixture, this test tells them they changed the prompt.
"""

import hashlib
import json
import os
from pathlib import Path
from unittest.mock import patch

from django.test import TestCase
from pydantic import ValidationError

from apps.ai.report_generation import prompt_v3
from apps.ai.report_generation.client import ReportGenerationClient
from apps.ai.report_generation.generate import generate_report, initial_report_version, resolve_variant
from apps.ai.report_generation.memory_candidates import build_memory_candidates_v3
from apps.ai.report_generation.profile_input import ProfileInput
from apps.ai.report_generation.profile_input_v3 import (
    AnswerSheetV3,
    MIN_DISTINCT_EVIDENCE_QUESTIONS,
    detect_key_tensions,
    format_evidence,
    get_allowed_finding_areas,
    get_score_level,
    js_round,
)
from apps.ai.report_generation.question_map_v3 import (
    DIMENSION_ORDER_V3,
    MappedQuestion,
    QuestionMapError,
    V3_QUESTIONS,
    V3_QUESTION_IDS,
    map_questions,
)
from apps.ai.report_generation.schema_v3 import AIOutputV3, check_against_input, soft_check_v3
from apps.ai.tests import _DIMENSION_SCORES, _FakeOpenAIClient

_FEWSHOT_V3_DIR = Path(__file__).resolve().parent / "report_generation" / "fewshot_v3"

# The whole reference prompt, pinned. See prompt_v3.FINAL_ENGLISH_SYSTEM_PROMPT.
_SYSTEM_PROMPT_SHA256 = "9617edcdee843a0c89a8ef391a60d499ff8f2a91335c9d92f6749fc1717b561c"

_V3_ENV = {"REPORT_INITIAL_VERSION": "report_v3", "REPORT_AI_ENABLED": "true"}


def _golden(n: int, part: str) -> dict:
    return json.loads((_FEWSHOT_V3_DIR / f"golden_{n}_{part}.json").read_text(encoding="utf-8"))


def _golden_model_output(n: int = 2, mutate=None) -> str:
    """A valid raw model response string for golden n, optionally corrupted by `mutate`."""
    output = _golden(n, "output")
    if mutate:
        mutate(output)
    return json.dumps(output, ensure_ascii=False)


# Raw answers reconstructed from each golden input's evidence strings: every quoted sentence
# is matched back to its qN in the contract, and its Likert label back to 1/2/4/5 (strong =
# 1|5, moderate = 2|4). Questions with no evidence line were answered 3. Reconstruction is
# verified by test_golden_answers_reproduce_the_golden_payload below, which rebuilds each
# golden input from these and compares it to the shipped fixture.
_GOLDEN_1_ANSWERS = "524154424242434343434532535515"
_GOLDEN_2_ANSWERS = "332433535234454333344333223355"


def _answers(digits: str) -> dict[str, int]:
    return {f"q{i}": int(d) for i, d in enumerate(digits, start=1)}


def _contract_questions(**overrides) -> list[MappedQuestion]:
    """The 30 contract questions as a well-formed assessment would supply them. `overrides`
    maps a qN onto replacement MappedQuestion kwargs, to build one-field mismatches."""
    questions = []
    for spec in V3_QUESTIONS:
        order = (spec.num - 1) % 6 + 1
        fields = {
            "external_id": 1000 + spec.num,
            "dimension": spec.dim,
            "order": order,
            "text": spec.text,
            "reverse_scored": spec.reverse,
        }
        fields.update(overrides.get(spec.id, {}))
        questions.append(MappedQuestion(**fields))
    return questions


class QuestionMapV3Tests(TestCase):
    """Requirement 1: qN is a semantic id, verified against the real question, never a PK."""

    def test_contract_has_thirty_questions_in_the_scoring_dimension_order(self):
        self.assertEqual(len(V3_QUESTIONS), 30)
        self.assertEqual(V3_QUESTION_IDS, tuple(f"q{i}" for i in range(1, 31)))
        from apps.report.services.scoring_service import DIMENSION_ORDER

        self.assertEqual(list(DIMENSION_ORDER_V3), DIMENSION_ORDER)

    def test_maps_by_dimension_and_order_not_by_primary_key(self):
        # External ids deliberately run backwards, so a mapping that leaned on id order or on
        # the iteration order of the input list would produce the wrong answer.
        questions = _contract_questions()
        shuffled = list(reversed(questions))
        mapping = map_questions(shuffled)

        self.assertEqual(len(mapping), 30)
        for spec in V3_QUESTIONS:
            self.assertEqual(mapping[spec.id], 1000 + spec.num)

    def test_accepts_the_known_q1_plural_variant_only(self):
        """The supplied DB snapshot wrote q1 with «اتفاقات» where the contract has
        «اتفاق‌های». That one equivalence is whitelisted; nothing else is."""
        variant = V3_QUESTIONS[0].text.replace("اتفاق‌های", "اتفاقات")
        self.assertNotEqual(variant, V3_QUESTIONS[0].text)

        mapping = map_questions(_contract_questions(q1={"text": variant}))
        self.assertEqual(mapping["q1"], 1001)

        with self.assertRaises(QuestionMapError):
            map_questions(_contract_questions(q1={"text": "یک جمله‌ی کاملاً متفاوت."}))

    def test_reports_every_mismatch_at_once_and_never_guesses(self):
        with self.assertRaises(QuestionMapError) as ctx:
            map_questions(_contract_questions(
                q3={"text": "متن اشتباه"},
                q9={"reverse_scored": not V3_QUESTIONS[8].reverse},
                q27={"text": "متن اشتباه دیگر", "reverse_scored": not V3_QUESTIONS[26].reverse},
            ))

        problems = "\n".join(ctx.exception.problems)
        self.assertIn("q3: text mismatch", problems)
        self.assertIn("q9: reverse_scored", problems)
        self.assertIn("q27: text mismatch", problems)
        self.assertIn("q27: reverse_scored", problems)

    def test_missing_and_duplicated_positions_are_reported(self):
        questions = _contract_questions()
        del questions[4]
        with self.assertRaises(QuestionMapError) as ctx:
            map_questions(questions)
        problems = "\n".join(ctx.exception.problems)
        self.assertIn("5 active question positions", problems)
        self.assertIn("q5: no active question", problems)

        questions = _contract_questions()
        duplicate = MappedQuestion(
            external_id=9999, dimension=V3_QUESTIONS[0].dim, order=1,
            text=V3_QUESTIONS[0].text, reverse_scored=V3_QUESTIONS[0].reverse,
        )
        with self.assertRaises(QuestionMapError) as ctx:
            map_questions(questions + [duplicate])
        self.assertIn("2 active questions share", "\n".join(ctx.exception.problems))

    def test_sections_outside_the_big_five_are_ignored(self):
        extra = MappedQuestion(
            external_id=7777, dimension="General", order=1, text="یک سؤال نامربوط.",
            reverse_scored=False,
        )
        mapping = map_questions(_contract_questions() + [extra])
        self.assertEqual(len(mapping), 30)
        self.assertNotIn(7777, mapping.values())

    def test_the_seeded_test_assessment_does_not_match_and_says_why(self):
        """Documents the live blocker: seed_test_assessment.py's wording and reverse pattern
        are not the v3 contract's, so report_v3 must refuse that assessment rather than quote
        sentences the user never read."""
        from apps.assessment.management.commands.seed_test_assessment import DIMENSION_QUESTIONS

        seeded = [
            MappedQuestion(
                external_id=index, dimension=dimension, order=order,
                text=text, reverse_scored=reverse,
            )
            for index, (dimension, order, text, reverse) in enumerate(
                (dimension, order, text, reverse)
                for dimension in DIMENSION_ORDER_V3
                for order, (text, reverse) in enumerate(DIMENSION_QUESTIONS[dimension], start=1)
            )
        ]
        with self.assertRaises(QuestionMapError) as ctx:
            map_questions(seeded)
        self.assertIn("q1: text mismatch", "\n".join(ctx.exception.problems))


class ScoreParityV3Tests(TestCase):
    """Requirement 2: the studio's JS arithmetic, reproduced exactly."""

    def test_js_round_differs_from_python_round_on_half_ties(self):
        # Python's round() is bankers rounding: round(12.5) == 12, round(62.5) == 62.
        self.assertEqual(js_round(12.5), 13)
        self.assertEqual(js_round(62.5), 63)
        self.assertEqual(round(12.5), 12)
        self.assertEqual(round(62.5), 62)
        self.assertEqual(js_round(0.4), 0)
        self.assertEqual(js_round(100.0), 100)

    def test_the_two_factor_sums_that_actually_hit_a_half_tie(self):
        """(sum - 6) / 24 * 100 lands on .5 for factor sums 9 and 21."""
        for factor_sum, expected in ((9, 13), (21, 63)):
            self.assertEqual(js_round((factor_sum - 6) / 24 * 100), expected)

    def test_level_bands_match_the_scoring_service(self):
        from apps.report.services.scoring_service import ScoringService

        for score in range(0, 101):
            self.assertEqual(get_score_level(score), ScoringService._level_for(score), score)

    def test_scores_sent_to_the_model_equal_the_scores_persisted(self):
        """Requirement 2: for one v3 report, the five numbers in the payload and the five in
        dimension_scores must be the same numbers."""
        sheet = AnswerSheetV3(answers=_answers(_GOLDEN_1_ANSWERS))
        payload = sheet.to_smart_payload()
        persisted = {item["key"]: (item["score_percent"], item["level"]) for item in sheet.dimension_scores()}

        for key, block in payload["profile"].items():
            self.assertEqual((block["score"], block["level"]), persisted[key], key)

    def test_v2_scoring_is_untouched(self):
        """ScoringService still uses Python's round(); v3's js_round is additive only."""
        import inspect

        from apps.report.services.scoring_service import ScoringService

        source = inspect.getsource(ScoringService.score_attempt)
        self.assertIn("round((factor_sums[dimension] - 6) / 24 * 100)", source)
        self.assertNotIn("js_round", source)


class SmartPayloadV3Tests(TestCase):
    """Requirement 2: evidence labels, allowed areas, tensions, strict answers."""

    def test_evidence_label_format(self):
        self.assertEqual(
            format_evidence("q7", "بودن در جمع به من انرژی می‌دهد.", 5),
            "q7: بودن در جمع به من انرژی می‌دهد. (کاملاً موافقم)",
        )
        self.assertEqual(
            format_evidence("q7", "بودن در جمع به من انرژی می‌دهد.", 2),
            "q7: بودن در جمع به من انرژی می‌دهد. (مخالفم)",
        )

    def test_strong_moderate_and_neutral_split(self):
        answers = {f"q{i}": 3 for i in range(1, 31)}
        answers.update({"q1": 5, "q2": 4, "q3": 1, "q4": 2, "q5": 3})
        block = AnswerSheetV3(answers=answers).to_smart_payload()["profile"]["emotional_stability"]

        self.assertEqual(len(block["strong"]), 2)   # q1 (5) and q3 (1)
        self.assertEqual(len(block["moderate"]), 2)  # q2 (4) and q4 (2)
        joined = " ".join(block["strong"] + block["moderate"])
        self.assertNotIn("q5", joined)  # neutral is omitted entirely
        self.assertNotIn("q6", joined)

    def test_allowed_finding_areas_per_goal(self):
        self.assertEqual(get_allowed_finding_areas("decisions"), ["work", "relationship", "stress"])
        self.assertEqual(get_allowed_finding_areas("relationships"), ["work", "decision", "stress"])
        self.assertEqual(get_allowed_finding_areas("stress"), ["work", "relationship", "decision"])
        self.assertEqual(get_allowed_finding_areas("mastery"), ["relationship", "decision", "stress"])
        for goal in (None, "", "unsure", "something_else"):
            self.assertEqual(
                get_allowed_finding_areas(goal), ["work", "relationship", "decision", "stress"], goal,
            )

    def test_key_tensions_rules_and_fallback(self):
        neutral = {f"q{i}": 3 for i in range(1, 31)}

        # Rule 1: q25/q30 high together with q1/q5 high.
        answers = dict(neutral, q25=5, q1=4)
        self.assertEqual(len(detect_key_tensions(answers)), 1)

        # No rule fires -> exactly one fallback sentence, naming no dimension label.
        fallback = detect_key_tensions(dict(neutral, q7=5))
        self.assertEqual(len(fallback), 1)

        # The golden inputs' tensions are reproduced exactly.
        self.assertEqual(
            detect_key_tensions(_answers(_GOLDEN_1_ANSWERS)), _golden(1, "input")["key_tensions"],
        )
        self.assertEqual(
            detect_key_tensions(_answers(_GOLDEN_2_ANSWERS)), _golden(2, "input")["key_tensions"],
        )

    def test_golden_answers_reproduce_the_golden_payload(self):
        """Parity test: rebuilding each golden input from raw answers must give back exactly
        the fixture that is sent to the model."""
        for n, digits, context in (
            (1, _GOLDEN_1_ANSWERS, {"age": "29", "life_situation": "employed", "current_goal": "decisions"}),
            (2, _GOLDEN_2_ANSWERS, {"age": "21", "life_situation": "student", "current_goal": "unsure"}),
        ):
            with self.subTest(golden=n):
                built = AnswerSheetV3(
                    answers=_answers(digits), context_profile=context,
                ).to_smart_payload()
                self.assertEqual(built, _golden(n, "input"))

    def test_answers_are_strict(self):
        complete = _answers(_GOLDEN_2_ANSWERS)

        with self.assertRaises(ValidationError):  # missing q30
            AnswerSheetV3(answers={k: v for k, v in complete.items() if k != "q30"})
        with self.assertRaises(ValidationError):  # unknown id
            AnswerSheetV3(answers=dict(complete, q31=3))
        with self.assertRaises(ValidationError):  # out of range
            AnswerSheetV3(answers=dict(complete, q4=6))
        with self.assertRaises(ValidationError):  # not an int
            AnswerSheetV3(answers=dict(complete, q4="4"))
        with self.assertRaises(ValidationError):  # not a whole number
            AnswerSheetV3(answers=dict(complete, q4=4.5))
        with self.assertRaises(ValidationError):  # True is not an answer
            AnswerSheetV3(answers=dict(complete, q4=True))
        with self.assertRaises(ValidationError):  # empty
            AnswerSheetV3(answers={})

    def test_no_neutral_default_is_ever_substituted(self):
        """The studio's `currentAnswers[q.id] || 3` must not exist here: an absent answer is
        an error, not a shrug. Checked on the parsed code, so the module's own prose about
        the rule (docstrings and comments) cannot satisfy or break the test."""
        import ast
        import inspect

        from apps.ai.report_generation import profile_input_v3

        tree = ast.parse(inspect.getsource(profile_input_v3))
        defaulted_lookups = [
            node for node in ast.walk(tree)
            if isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr == "get"
            and len(node.args) == 2
            and isinstance(node.args[1], ast.Constant)
            and node.args[1].value == 3
        ]
        self.assertEqual(defaulted_lookups, [])

        # And behaviourally: a missing answer is refused, not filled in.
        with self.assertRaises(ValidationError):
            AnswerSheetV3(answers={f"q{i}": 4 for i in range(1, 30)})

    def test_context_omits_absent_fields_and_never_carries_identifiers(self):
        sheet = AnswerSheetV3(answers=_answers(_GOLDEN_2_ANSWERS))
        context = sheet.to_smart_payload()["context"]
        self.assertEqual(set(context), {"allowed_finding_areas"})

        with self.assertRaises(ValidationError):
            AnswerSheetV3(
                answers=_answers(_GOLDEN_2_ANSWERS),
                context_profile={"age": "29", "gender": "female"},
            )

    def test_insufficient_evidence_is_detected_before_any_call(self):
        answers = {f"q{i}": 3 for i in range(1, 31)}
        self.assertIsNotNone(AnswerSheetV3(answers=answers).insufficient_evidence_reason())

        for i in range(1, MIN_DISTINCT_EVIDENCE_QUESTIONS):
            answers[f"q{i}"] = 5
        self.assertIsNotNone(AnswerSheetV3(answers=answers).insufficient_evidence_reason())

        answers[f"q{MIN_DISTINCT_EVIDENCE_QUESTIONS}"] = 5
        self.assertIsNone(AnswerSheetV3(answers=answers).insufficient_evidence_reason())


class PromptV3Tests(TestCase):
    """Requirement 3: the reference prompt and message arrangement, byte for byte."""

    def test_system_prompt_is_the_reference_prompt_unchanged(self):
        prompt = prompt_v3.FINAL_ENGLISH_SYSTEM_PROMPT
        self.assertEqual(len(prompt), 11761)
        self.assertEqual(hashlib.sha256(prompt.encode("utf-8")).hexdigest(), _SYSTEM_PROMPT_SHA256)

    def test_six_messages_in_the_studio_role_order(self):
        payload = AnswerSheetV3(answers=_answers(_GOLDEN_2_ANSWERS)).to_smart_payload()
        messages = prompt_v3.build_messages(payload)

        self.assertEqual(
            [m["role"] for m in messages],
            ["system", "user", "assistant", "user", "assistant", "user"],
        )
        self.assertEqual(messages[0]["content"], prompt_v3.FINAL_ENGLISH_SYSTEM_PROMPT)
        self.assertEqual(json.loads(messages[1]["content"]), _golden(1, "input"))
        self.assertEqual(json.loads(messages[2]["content"]), _golden(1, "output"))
        self.assertEqual(json.loads(messages[3]["content"]), _golden(2, "input"))
        self.assertEqual(json.loads(messages[4]["content"]), _golden(2, "output"))
        self.assertEqual(json.loads(messages[5]["content"]), payload)

    def test_json_is_compact_and_not_ascii_escaped(self):
        messages = prompt_v3.build_messages(
            AnswerSheetV3(answers=_answers(_GOLDEN_2_ANSWERS)).to_smart_payload()
        )
        body = messages[5]["content"]
        self.assertNotIn(", ", body)
        self.assertNotIn('": ', body)
        self.assertNotIn("\\u", body)

    def test_golden_one_keeps_its_documented_defect(self):
        """Golden 1's coin_2 cites q20, which has no evidence in golden 1's input. The fixture
        is shipped verbatim anyway (it is the user's prompt), so this pins the known defect
        rather than hiding it -- and check_against_input downgrades it to a warning."""
        output = AIOutputV3.model_validate(_golden(1, "output"))
        self.assertIn("q20", output.system.source_map.coin_2.questions)

        result = check_against_input(output, _golden(1, "input"))
        self.assertEqual(result.errors, [])
        self.assertTrue(any("q20" in warning for warning in result.warnings))

    def test_golden_two_is_clean_and_is_the_fixture_to_reuse(self):
        output = AIOutputV3.model_validate(_golden(2, "output"))
        result = check_against_input(output, _golden(2, "input"))
        self.assertEqual(result.errors, [])
        self.assertEqual(result.warnings, [])


class SchemaV3Tests(TestCase):
    """Requirement 3: structural errors are hard, style deviations are warnings."""

    def test_both_goldens_validate(self):
        for n in (1, 2):
            with self.subTest(golden=n):
                AIOutputV3.model_validate(_golden(n, "output"))

    def test_soft_check_returns_warnings_and_never_raises(self):
        warnings = soft_check_v3(AIOutputV3.model_validate(_golden(1, "output")))
        self.assertTrue(warnings)
        self.assertTrue(all(isinstance(w, str) for w in warnings))

    def test_rejects_wrong_counts(self):
        for mutate, label in (
            (lambda d: d["report"]["coins"].pop(), "two coins"),
            (lambda d: d["report"]["findings"].pop(), "one finding"),
            (lambda d: d["report"]["dimension_insights"].pop("openness"), "four insights"),
            (lambda d: d["system"]["source_map"].pop("coin_3"), "five source_map sections"),
            (lambda d: d["system"].__setitem__("pattern_tags", []), "no pattern tags"),
        ):
            with self.subTest(case=label):
                data = _golden(2, "output")
                mutate(data)
                with self.assertRaises(ValidationError):
                    AIOutputV3.model_validate(data)

    def test_rejects_unknown_fields(self):
        data = _golden(2, "output")
        data["report"]["extra_section"] = "چیزی که در قرارداد نیست"
        with self.assertRaises(ValidationError):
            AIOutputV3.model_validate(data)

    def test_suggested_step_is_required_on_the_first_finding_and_null_on_the_second(self):
        data = _golden(2, "output")
        data["report"]["findings"][0]["suggested_step"] = None
        with self.assertRaises(ValidationError):
            AIOutputV3.model_validate(data)

        data = _golden(2, "output")
        data["report"]["findings"][1]["suggested_step"] = data["report"]["findings"][0]["suggested_step"]
        with self.assertRaises(ValidationError):
            AIOutputV3.model_validate(data)

    def test_findings_must_cover_two_different_areas(self):
        data = _golden(2, "output")
        data["report"]["findings"][1]["area"] = data["report"]["findings"][0]["area"]
        with self.assertRaises(ValidationError):
            AIOutputV3.model_validate(data)

    def test_source_map_question_reuse_is_capped_at_two_sections(self):
        data = _golden(2, "output")
        for section in ("coin_1", "coin_2", "coin_3"):
            data["system"]["source_map"][section]["questions"] = ["q14", "q15"]
        with self.assertRaises(ValidationError):
            AIOutputV3.model_validate(data)

    def test_finding_area_outside_the_allowed_list_is_a_hard_error(self):
        output = AIOutputV3.model_validate(_golden(1, "output"))
        narrowed = dict(_golden(1, "input"))
        narrowed["context"] = dict(narrowed["context"], allowed_finding_areas=["stress", "decision"])

        result = check_against_input(output, narrowed)
        self.assertTrue(result.errors)
        self.assertTrue(any("work" in e or "relationship" in e for e in result.errors))


class MemoryCandidatesV3Tests(TestCase):
    """Requirement 4: four rows, the studio's §9 mapping, this project's extra fields."""

    def _candidates(self, goal_chosen: bool):
        output = AIOutputV3.model_validate(_golden(1, "output"))
        return build_memory_candidates_v3(output.report, output.system, goal_chosen=goal_chosen)

    def test_four_rows_of_the_expected_types(self):
        candidates = self._candidates(goal_chosen=True)
        self.assertEqual(
            [c.memory_type for c in candidates],
            ["core_pattern", "strength", "growth_edge", "growth_focus"],
        )
        self.assertTrue(all(c.source == "initial_report" for c in candidates))
        self.assertTrue(all(c.should_store for c in candidates))

    def test_sources_follow_the_studio_mapping(self):
        report = AIOutputV3.model_validate(_golden(1, "output")).report
        candidates = self._candidates(goal_chosen=True)

        self.assertEqual(candidates[0].text_memory, report.hook)
        for coin in report.coins:
            self.assertIn(coin.front_title, candidates[1].text_memory)
            self.assertIn(coin.front_text, candidates[1].text_memory)
        for finding in report.findings:
            self.assertIn(finding.title, candidates[2].text_memory)
            self.assertIn(finding.what, candidates[2].text_memory)
        self.assertTrue(candidates[3].text_memory.endswith(report.goal_card.title))

    def test_growth_focus_prefix_depends_on_whether_the_user_chose_a_goal(self):
        self.assertTrue(self._candidates(goal_chosen=True).pop().text_memory.startswith("هدفی که خودش انتخاب کرد: "))
        self.assertTrue(self._candidates(goal_chosen=False).pop().text_memory.startswith("حوزه‌ای که گزارش پیشنهاد داد: "))

    def test_judgemental_and_internal_content_is_never_remembered(self):
        report = AIOutputV3.model_validate(_golden(1, "output")).report
        blob = "\n".join(c.text_memory for c in self._candidates(goal_chosen=True))

        for forbidden in (
            report.findings[0].cost, report.findings[0].curiosity,
            report.exit.root_question, report.mirror.blind_spot,
            report.coins[0].back_text,
        ):
            self.assertNotIn(forbidden, blob)


class GenerateV3Tests(TestCase):
    """Requirement 4: the dispatcher, the retry ladder and the failure paths."""

    def _sheet(self, digits=_GOLDEN_2_ANSWERS, **context):
        return AnswerSheetV3(answers=_answers(digits), context_profile=context or None)

    def test_version_dispatch(self):
        with patch.dict(os.environ, {"REPORT_INITIAL_VERSION": "report_v3"}):
            self.assertEqual(initial_report_version(), "report_v3")
        # An unknown pinned version falls back to the configured one rather than crashing.
        with patch.dict(os.environ, {"REPORT_INITIAL_VERSION": "report_v2"}):
            self.assertEqual(resolve_variant("report_v9").version, "report_v2")
            self.assertEqual(resolve_variant("report_v3").version, "report_v3")
            self.assertEqual(resolve_variant(None).version, "report_v2")

    def test_happy_path_returns_a_v3_response(self):
        client = _FakeOpenAIClient([_golden_model_output(2)])
        with patch.dict(os.environ, _V3_ENV):
            response = generate_report(self._sheet(), client=client)

        self.assertEqual(response.status, "ok")
        self.assertEqual(response.report_version, "report_v3")
        self.assertEqual(len(response.memory_candidates), 4)
        self.assertEqual(len(client.completions.calls), 1)
        self.assertEqual(len(client.completions.calls[0]["messages"]), 6)

    def test_bad_json_then_good_json_is_retried_with_the_error_fed_back(self):
        client = _FakeOpenAIClient(["not json at all", _golden_model_output(2)])
        with patch.dict(os.environ, _V3_ENV):
            response = generate_report(self._sheet(), client=client)

        self.assertEqual(response.status, "ok")
        self.assertEqual(response.generation_meta.attempts, 2)
        second_attempt = client.completions.calls[1]["messages"]
        self.assertEqual(second_attempt[-2]["role"], "assistant")
        self.assertEqual(second_attempt[-2]["content"], "not json at all")
        self.assertIn("failed schema validation", second_attempt[-1]["content"])

    def test_an_output_contradicting_its_input_is_retried_not_returned(self):
        """check_against_input's hard errors (a finding area outside the allowed list) go
        through the same correction loop as a schema failure. Golden 2's own areas are
        work/relationship, so goal "stress" (which removes only `stress`) leaves the clean
        retry valid while the mutated first attempt is not."""
        def forbid_area(data):
            data["report"]["findings"][0]["area"] = "stress"

        client = _FakeOpenAIClient([_golden_model_output(2, forbid_area), _golden_model_output(2)])
        with patch.dict(os.environ, _V3_ENV):
            response = generate_report(self._sheet(current_goal="stress"), client=client)

        self.assertEqual(response.status, "ok")
        self.assertEqual(response.generation_meta.attempts, 2)
        self.assertIn("stress", client.completions.calls[1]["messages"][-1]["content"])

    def test_all_attempts_failing_returns_a_controlled_error(self):
        client = _FakeOpenAIClient(["nope"] * 4)
        with patch.dict(os.environ, _V3_ENV):
            response = generate_report(self._sheet(), client=client)

        self.assertEqual(response.status, "error")
        self.assertEqual(response.report_version, "report_v3")
        self.assertEqual(response.error.code, "generation_failed")
        self.assertFalse(response.error.should_display_report)
        self.assertEqual(response.generation_meta.attempts, 4)

    def test_insufficient_evidence_never_reaches_the_provider(self):
        client = _FakeOpenAIClient([])
        sheet = AnswerSheetV3(answers={f"q{i}": 3 for i in range(1, 31)})
        with patch.dict(os.environ, _V3_ENV):
            response = generate_report(sheet, client=client)

        self.assertEqual(response.status, "error")
        self.assertEqual(response.error.code, "insufficient_evidence")
        self.assertEqual(response.generation_meta.attempts, 0)
        self.assertEqual(client.completions.calls, [])

    def test_wrong_input_type_for_the_version_fails_safely(self):
        """A v1/v2 ProfileInput handed to the v3 variant is a programming error, and must not
        raise into the Celery task."""
        client = _FakeOpenAIClient([])
        with patch.dict(os.environ, _V3_ENV):
            response = generate_report(
                ProfileInput(dimension_scores=_DIMENSION_SCORES), client=client,
            )

        self.assertEqual(response.status, "error")
        self.assertEqual(response.generation_meta.attempts, 0)
        self.assertEqual(client.completions.calls, [])

    def test_mock_mode_uses_a_marked_synthetic_report_not_a_golden(self):
        client = _FakeOpenAIClient([])
        with patch.dict(os.environ, {"REPORT_INITIAL_VERSION": "report_v3", "REPORT_AI_ENABLED": "false"}):
            result = ReportGenerationClient(openai_client=client).generate(
                _DIMENSION_SCORES, answers=_answers(_GOLDEN_2_ANSWERS),
            )

        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["report_version"], "report_v3")
        self.assertEqual(client.completions.calls, [])
        self.assertIn("نمونه‌ی آزمایشی", result["report"]["hook"])
        self.assertNotEqual(result["report"]["hook"], _golden(1, "output")["report"]["hook"])
        self.assertNotEqual(result["report"]["hook"], _golden(2, "output")["report"]["hook"])

    def test_client_rejects_a_v3_request_without_usable_answers(self):
        client = _FakeOpenAIClient([])
        with patch.dict(os.environ, _V3_ENV):
            result = ReportGenerationClient(openai_client=client).generate(_DIMENSION_SCORES)

        self.assertEqual(result["status"], "error")
        self.assertEqual(result["error"]["code"], "insufficient_evidence")
        self.assertEqual(client.completions.calls, [])

    def test_raw_answers_and_system_block_stay_out_of_the_logs(self):
        """Requirement 4: no raw prompt/answers in log output."""
        client = _FakeOpenAIClient([_golden_model_output(2)])
        with patch.dict(os.environ, _V3_ENV):
            with self.assertLogs("apps.ai.report_generation.generate", level="DEBUG") as logs:
                generate_report(self._sheet(), client=client)

        blob = "\n".join(logs.output)
        self.assertNotIn("کاملاً موافقم", blob)
        self.assertNotIn("source_map", blob)
        self.assertNotIn(prompt_v3.FINAL_ENGLISH_SYSTEM_PROMPT[:80], blob)


class VersionIsolationTests(TestCase):
    """Requirement: v1, v2 and deep must be untouched by all of the above."""

    def test_v1_and_v2_still_generate_from_dimension_scores_alone(self):
        from apps.ai.tests import _fewshot_model_output, _v2_model_output

        # v1 and v2 both build system + 3 few-shot pairs + the real payload = 8 messages.
        for version, raw, expected_messages in (
            ("report_v1", _fewshot_model_output(1), 8),
            ("report_v2", _v2_model_output("A"), 8),
        ):
            with self.subTest(version=version):
                client = _FakeOpenAIClient([raw])
                with patch.dict(os.environ, {"REPORT_INITIAL_VERSION": version, "REPORT_AI_ENABLED": "true"}):
                    result = ReportGenerationClient(openai_client=client).generate(_DIMENSION_SCORES)

                self.assertEqual(result["status"], "ok")
                self.assertEqual(result["report_version"], version)
                self.assertEqual(len(client.completions.calls[0]["messages"]), expected_messages)

    def test_v3_modules_are_not_imported_by_the_v1_v2_prompt_builders(self):
        import inspect

        from apps.ai.report_generation import prompt as prompt_v1
        from apps.ai.report_generation import prompt_v2

        for module in (prompt_v1, prompt_v2):
            with self.subTest(module=module.__name__):
                self.assertNotIn("v3", inspect.getsource(module).lower().replace("report_v3_", ""))
