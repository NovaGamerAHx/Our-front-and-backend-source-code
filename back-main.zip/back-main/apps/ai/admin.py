from django.contrib import admin

from apps.ai.models import ModelPricing


@admin.register(ModelPricing)
class ModelPricingAdmin(admin.ModelAdmin):
    """Editable (unlike apps.report's log-style admins) -- prices must be changeable without
    a deploy (report_spec_v1.4 §4.4)."""

    list_display = ("model_name", "input_price_per_million", "output_price_per_million", "updated_at")
    search_fields = ("model_name",)
