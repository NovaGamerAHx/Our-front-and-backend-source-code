## Persian punctuation

- **Never write the kasre/ezafe diacritic mark («ِ»)** on any word, in any field. Ordinary
  written Persian does not mark ezafe with this diacritic — write it the way a person
  actually would: «نمونه‌ی کار» not «نمونهِ کار», «سر دیگر» not «سرِ دیگر». If a sentence
  needs an ezafe construction, either write it with «ی» where that is natural, or rephrase so
  no diacritic is needed at all.
- **Never use the semicolon («؛»).** Replace it with whichever fits the sentence: end the
  first clause with a period («.») and start a new sentence, or join the two clauses with a
  comma («،») when they genuinely belong in one sentence.

Re-read every sentence you write before returning it and remove any «ِ» or «؛» you find.
