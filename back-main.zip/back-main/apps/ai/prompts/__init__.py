"""Prompt blocks shared across every AI service (chat, report, deep report).

Written once here instead of copied into each prompt, so the same rule can't drift into
two different versions two months later.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

_DIR = Path(__file__).parent


@lru_cache(maxsize=None)
def read_block(path: str) -> str:
    """Read a static prompt block from disk.

    Missing blocks raise rather than warn -- a prompt that silently assembles without a
    required block is the worst possible failure and looks completely normal in testing.
    """
    block = Path(path)
    if not block.exists():
        raise FileNotFoundError(
            f"missing prompt block: {block}. Static blocks are required; "
            f"a prompt must not silently assemble without them."
        )
    return block.read_text(encoding="utf-8").strip()


def safety_rules() -> str:
    """Governs how every service speaks about a person. Must stay byte-identical wherever
    it is used -- a divergence would be invisible in review and would mean two services
    operate under different safety rules."""
    return read_block(str(_DIR / "safety_rules.md"))


def step_quality_rules() -> str:
    """What makes an action step acceptable, needed by chat and both report prompts."""
    return read_block(str(_DIR / "step_quality_rules.md"))


def punctuation_rules() -> str:
    """No ezafe/kasre diacritic and no semicolon in output -- ordinary written Persian
    doesn't use either. Needed by chat and both report prompts, same reasoning as
    safety_rules."""
    return read_block(str(_DIR / "punctuation_rules.md"))
