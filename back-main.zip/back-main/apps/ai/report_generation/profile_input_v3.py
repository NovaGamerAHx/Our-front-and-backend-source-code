"""
profile_input_v3.py

Deterministic input preparation for report_v3: 30 raw answers -> the exact `smart payload`
the v3 prompt expects ({context, profile, key_tensions}), plus the dimension_scores the
backend stores for the same report.

This is a line-by-line port of the studio's `buildSmartUserInputPayload()` /
`detectKeyTensions()` / `getScoreLevel()` / `getAllowedFindingAreas()` (V3_LLM_REFERENCE.md
section 4), with three deliberate differences, all required by the task brief:

1. NO `currentAnswers[q.id] || 3`. The studio silently treats a missing answer as neutral;
   this module refuses to: AnswerSheetV3 requires exactly the 30 contract ids with values
   1..5. Fabricated evidence is worse than no report.
2. `age` is not derived from the studio's hardcoded `CURRENT_SHAMSI_YEAR = 1404`. The caller
   passes the backend's own calculation (AiReportClient._current_jalali_year), unchanged from
   v1/v2.
3. Rounding is explicitly JS-compatible (`js_round`), not Python's bankers rounding -- see
   that function. v1/v2 scoring is untouched.

Why the score arithmetic lives here and not only in ScoringService: for v3 the scores the
model is given and the scores persisted on the Report row must be identical, so both come
from this one function (apps.report.services.report_v3_input_service calls it for both).
"""

from __future__ import annotations

import math
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, StrictInt, field_validator

from apps.ai.report_generation.profile_input import ContextProfile, Level
from apps.ai.report_generation.question_map_v3 import (
    DIMENSION_ORDER_V3,
    LIKERT_LABELS,
    V3_QUESTIONS_BY_DIMENSION,
    V3_QUESTION_IDS,
)

# The four areas a finding may be written about, before the goal-based exclusion below.
ALL_FINDING_AREAS = ("work", "relationship", "decision", "stress")

# `current_goal` -> the one area that must NOT be offered as a finding, because the goal card
# already covers it (studio `getAllowedFindingAreas`). Goals missing from this map (growth,
# purpose, self_regard, unsure, or no goal at all) keep all four areas.
_GOAL_EXCLUDED_AREA = {
    "decisions": "decision",
    "relationships": "relationship",
    "stress": "stress",
    "mastery": "work",
}

# The literal rules of the prompt's <grounding_and_anti_repetition> block -- 6 source_map
# sections, at least 2 question ids each, no id used more than twice -- need at least
# 6 * 2 / 2 = 6 DISTINCT non-neutral questions to be satisfiable at all. Below that the model
# cannot comply without inventing evidence, so v3 refuses to call it (see generate.py).
MIN_DISTINCT_EVIDENCE_QUESTIONS = 6

# The fallback tension, used verbatim when no rule fires (studio `detectKeyTensions`).
KEY_TENSION_FALLBACK = "تضاد بین بالاترین و پایین‌ترین بُعد پروفایل را مبنای قلاب و یافته اول قرار بده."


def js_round(value: float) -> int:
    """JavaScript's `Math.round`: ties go to +infinity (`Math.round(12.5) === 13`).

    Python's built-in round() is bankers rounding (`round(12.5) == 12`, `round(37.5) == 38`),
    which disagrees with the studio on exactly two of the 25 reachable factor sums --
    score 12/13 and 62/63. The level band is the same either way, but the integer the user
    sees and the integer the model sees must not differ, so v3 uses this everywhere and
    ScoringService (v1/v2) keeps using round() untouched.
    """
    return math.floor(value + 0.5)


def get_score_level(score_percent: int) -> str:
    """Studio `getScoreLevel`. Identical bands to ScoringService.LEVEL_BANDS."""
    if score_percent <= 19:
        return "very_low"
    if score_percent <= 39:
        return "low"
    if score_percent <= 59:
        return "medium"
    if score_percent <= 79:
        return "medium_high"
    return "high"


def get_allowed_finding_areas(goal: str | None) -> list[str]:
    """Studio `getAllowedFindingAreas`. Order is preserved; it reaches the model as-is."""
    excluded = _GOAL_EXCLUDED_AREA.get(goal or "")
    return [area for area in ALL_FINDING_AREAS if area != excluded]


def format_evidence(question_id: str, text: str, raw_value: int) -> str:
    """The evidence string format of the reference: `q7: <متن سؤال> (موافقم)`."""
    return f"{question_id}: {text} ({LIKERT_LABELS[raw_value]})"


def detect_key_tensions(answers: dict[str, int]) -> list[str]:
    """Studio `detectKeyTensions`: six ordered rule checks over the RAW answers.

    The six sentences are copied verbatim (including the id lists inside them, which do not
    always match the ids the rule actually tests -- preserved as supplied, not corrected).
    The fallback sentence is appended only when nothing fired.
    """
    def r(question_id: str) -> int:
        return answers[question_id]

    tensions: list[str] = []

    if (r("q25") >= 4 or r("q30") >= 4) and (r("q1") >= 4 or r("q5") >= 4):
        tensions.append(
            "q25/q30/q6 vs q1/q5: کارها را دقیق و تا پایان انجام می‌دهد و ظاهر آرامی دارد، "
            "اما از درون اتفاق‌های کوچک و نگرانی آینده مدت‌ها ذهنش را درگیر نگه می‌دارد."
        )
    if r("q30") >= 4 and (r("q29") >= 4 or r("q25") <= 2 or r("q26") <= 2):
        tensions.append(
            "q30 vs q29/q25/q26: اگر مسئولیتی بپذیرد تا پایان به آن پایبند می‌ماند، اما طبق "
            "برنامه جلو نمی‌رود، کارها را عقب می‌اندازد و از روی لحظه عمل می‌کند."
        )
    if (r("q19") >= 4 or r("q20") >= 4 or r("q22") >= 4) and (r("q21") >= 4 or r("q24") >= 4):
        tensions.append(
            "q19/q20/q22 vs q21: قابل اعتماد است و دغدغه درک احساسات دیگران را دارد، اما وقتی "
            "مطمئن است حق با اوست به‌ندرت کوتاه می‌آید."
        )
    if (r("q7") >= 4 or r("q8") >= 4 or r("q11") >= 4) and (r("q9") >= 4 or r("q10") <= 2 or r("q12") >= 4):
        tensions.append(
            "q7/q11 vs q9/q10/q12: بودن در جمع به او انرژی می‌دهد و حس مثبتش را بروز می‌دهد، "
            "اما از جمع‌های شلوغ خسته می‌شود و به خلوت و تنهایی نیاز دارد."
        )
    if (r("q13") >= 4 or r("q14") >= 4 or r("q17") >= 4) and r("q15") >= 4:
        tensions.append(
            "q13/q14/q17 vs q15: مشتاق یادگیری موضوعات جدید و مفاهیم عمیق است، اما هم‌زمان "
            "ترجیح می‌دهد روال همیشگی و آشنایش حفظ شود."
        )
    if (r("q2") >= 4 or r("q6") >= 4) and (r("q1") >= 4 or r("q3") >= 4 or r("q5") >= 4):
        tensions.append(
            "q2/q6 vs q1/q3/q5: در ظاهر احساساتش از کنترل خارج نمی‌شود، اما تغییرات ناگهانی یا "
            "اتفاق‌های کوچک مدت‌ها فکرش را مشغول می‌کند."
        )

    if not tensions:
        tensions.append(KEY_TENSION_FALLBACK)
    return tensions


class DimensionProfileV3(BaseModel):
    """One of the five blocks of the payload's `profile`."""
    model_config = ConfigDict(extra="forbid")

    score: int = Field(ge=0, le=100)
    level: Level
    # Evidence strings for raw 1/5 answers (direct claims allowed) and raw 2/4 answers
    # (single hedge). Raw 3 appears in neither: a neutral answer is not evidence.
    strong: list[str]
    moderate: list[str]


class AnswerSheetV3(BaseModel):
    """The v3 pipeline's input: the raw answers plus the same optional context block v1/v2 use.

    Validation is strict by design (task brief 1): exactly the 30 contract ids, every value an
    integer 1..5. A missing or out-of-range answer is an error, never a neutral default.
    """
    model_config = ConfigDict(extra="forbid")

    # StrictInt, not int: pydantic's lax mode would turn the string "4" (or True) into 4.
    # An answer that arrives as anything but a JSON integer means the caller mapped something
    # wrong, and silently coercing it would hide that.
    answers: dict[str, StrictInt]
    context_profile: ContextProfile | None = None

    @field_validator("answers")
    @classmethod
    def _exactly_the_thirty_contract_questions(cls, value: dict[str, int]):
        missing = [qid for qid in V3_QUESTION_IDS if qid not in value]
        unknown = sorted(set(value) - set(V3_QUESTION_IDS))
        if missing or unknown:
            raise ValueError(
                f"answers must be exactly q1..q30; missing={missing}, unknown={unknown}"
            )
        bad = sorted(qid for qid, raw in value.items() if not 1 <= raw <= 5)
        if bad:
            raise ValueError(f"answers must be integers 1..5; invalid for {bad}")
        return value

    # ---------------------------------------------------------------- payload

    def _context(self) -> dict:
        """`context`, in the studio's key order. Only present fields are included; gender can
        not reach here at all (ContextProfile forbids unknown keys)."""
        profile = self.context_profile
        context: dict = {}
        if profile is not None:
            if profile.age:
                context["age"] = profile.age
            if profile.life_situation:
                context["life_situation"] = profile.life_situation
            if profile.current_goal:
                context["current_goal"] = profile.current_goal
        context["allowed_finding_areas"] = get_allowed_finding_areas(
            profile.current_goal if profile is not None else None
        )
        return context

    def _profile(self) -> dict[str, DimensionProfileV3]:
        profile: dict[str, DimensionProfileV3] = {}
        for dimension in DIMENSION_ORDER_V3:
            factor_sum = 0
            strong: list[str] = []
            moderate: list[str] = []
            for spec in V3_QUESTIONS_BY_DIMENSION[dimension]:
                raw = self.answers[spec.id]
                factor_sum += (6 - raw) if spec.reverse else raw
                if raw in (1, 5):
                    strong.append(format_evidence(spec.id, spec.text, raw))
                elif raw in (2, 4):
                    moderate.append(format_evidence(spec.id, spec.text, raw))
                # raw == 3 is strictly omitted (reference section 4)

            score = js_round((factor_sum - 6) / 24 * 100)
            profile[dimension] = DimensionProfileV3(
                score=score, level=get_score_level(score), strong=strong, moderate=moderate,
            )
        return profile

    def to_smart_payload(self) -> dict:
        """The final user message's body: {context, profile, key_tensions}, in that order."""
        return {
            "context": self._context(),
            "profile": {key: block.model_dump() for key, block in self._profile().items()},
            "key_tensions": detect_key_tensions(self.answers),
        }

    # ------------------------------------------------------- derived, for backend

    def dimension_scores(self) -> list[dict]:
        """The backend's own `dimension_scores` shape, computed from the SAME numbers that go
        to the model (report_spec_v3_0 section 3.4). Order is DIMENSION_ORDER_V3."""
        return [
            {"key": key, "score_percent": block.score, "level": block.level}
            for key, block in self._profile().items()
        ]

    def evidence_question_ids(self) -> set[str]:
        """The non-neutral question ids -- the only ones the model may cite in source_map."""
        return {qid for qid, raw in self.answers.items() if raw != 3}

    def insufficient_evidence_reason(self) -> str | None:
        """Why this answer set cannot produce a rule-compliant v3 report, or None.

        Only one cause today: fewer than MIN_DISTINCT_EVIDENCE_QUESTIONS non-neutral answers.
        The string is for operators (logs); it is never shown to the user.
        """
        count = len(self.evidence_question_ids())
        if count < MIN_DISTINCT_EVIDENCE_QUESTIONS:
            return (
                f"{count} non-neutral answers (need at least {MIN_DISTINCT_EVIDENCE_QUESTIONS}): "
                "the source_map rules cannot be satisfied without inventing evidence"
            )
        return None


Area = Literal["work", "relationship", "decision", "stress"]

__all__ = [
    "ALL_FINDING_AREAS",
    "AnswerSheetV3",
    "Area",
    "DimensionProfileV3",
    "KEY_TENSION_FALLBACK",
    "MIN_DISTINCT_EVIDENCE_QUESTIONS",
    "detect_key_tensions",
    "format_evidence",
    "get_allowed_finding_areas",
    "get_score_level",
    "js_round",
]
