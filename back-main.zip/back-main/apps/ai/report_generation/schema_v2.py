"""
schema_v2.py

Pydantic models for the report_v2 output, per report_spec_v2_0 section 4. report_v1's models
stay in schema.py untouched: stored v1 reports are still read (preview, chat, email), and v1
generation is still reachable via REPORT_INITIAL_VERSION=report_v1.

Same two-tier validation as v1:
  HARD (Pydantic rejects, retried) -- counts, enums, null/required rules of section 4.3.
  SOFT (logged, never rejected)    -- word-count bands and forbidden words of section 4.3.
"""

from __future__ import annotations

import logging
import re
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from apps.ai.report_generation.schema import (
    DeadlineType,
    MemoryCandidate,
    ReportResponse,
    SystemBlock,
)

logger = logging.getLogger(__name__)

REPORT_VERSION_V2 = "report_v2"

FindingArea = Literal["work", "relationship", "decision", "stress"]


class StrengthV2(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str
    text: str


class SuggestedStepV2(BaseModel):
    """Same shape as v1's SuggestedStep (the front-end card and action_steps are shared) but
    substeps is hard-pinned to null: a report knows the scores and nothing about the week
    behind them (report_spec_v2_0 section 6.7)."""
    model_config = ConfigDict(extra="forbid")

    text: str
    deadline_text: str
    deadline_type: DeadlineType
    substeps: None = None


class FindingV2(BaseModel):
    model_config = ConfigDict(extra="forbid")

    area: FindingArea
    title: str
    what: str
    cost: str
    curiosity: str
    suggested_step: SuggestedStepV2 | None = None


class OpenQuestionV2(BaseModel):
    model_config = ConfigDict(extra="forbid")

    text: str
    finding_index: Literal[0, 1]


class ExitV2(BaseModel):
    model_config = ConfigDict(extra="forbid")

    bridge: str
    root_question: str


class ReportV2(BaseModel):
    model_config = ConfigDict(extra="forbid")

    hook: str = Field(min_length=1)
    strength: StrengthV2
    findings_heading: str = Field(min_length=1)
    findings: list[FindingV2] = Field(min_length=2, max_length=2)
    open_question: OpenQuestionV2
    exit: ExitV2

    @model_validator(mode="after")
    def _finding_rules(self):
        first, second = self.findings
        if first.area == second.area:
            raise ValueError("findings[0].area and findings[1].area must differ")
        if first.suggested_step is None:
            raise ValueError("findings[0].suggested_step is required")
        if second.suggested_step is not None:
            raise ValueError("findings[1].suggested_step must be null")
        return self


class AIOutputV2(BaseModel):
    """Exactly what the model is asked to return."""
    model_config = ConfigDict(extra="forbid")

    report: ReportV2
    system: SystemBlock


class ReportResponseV2(ReportResponse):
    report_version: str = REPORT_VERSION_V2
    report: ReportV2 | None = None  # type: ignore[assignment]


# --------------------------------------------------------------------------
# Soft validation -- logged, never raises
# --------------------------------------------------------------------------

# (min, max) words; None = unbounded on that side. Section 4.3 table.
_LENGTH_BANDS = {
    "hook": (6, 15),
    "strength.title": (3, 7),
    "strength.text": (25, 40),
    "findings_heading": (4, 10),
    "finding.title": (3, 7),
    "finding.what": (30, 50),
    "finding.cost": (None, 20),
    "finding.curiosity": (25, 40),
    "open_question.text": (None, 20),
    "exit.bridge": (4, 15),
    "exit.root_question": (20, 40),
}
_TOTAL_BAND = (260, 340)

# Section 4.3 forbidden-word table. Matched as substrings on the plain Persian text; digits are
# handled separately (any Persian or Latin digit).
_FORBIDDEN = {
    "product": ["تست", "گزارش", "فرامن", "نسخه‌ی کامل"],
    "dimension": ["ثبات هیجانی", "برون‌گرایی", "گشودگی", "توافق‌پذیری", "وظیفه‌شناسی"],
    "certainty": ["همیشه", "هیچ‌وقت", "قطعاً"],
    "clinical": ["اضطراب", "افسردگی", "اختلال", "وسواس", "کمال‌گرایی"],
}
_DIGIT_RE = re.compile(r"[0-9۰-۹]")

# The prompt tells the model the questions already leave room to disagree, so an explicit
# disclaimer (esp. inside the scene) is a defect, not a safety feature.
_DISCLAIMER_PHRASES = ["بر اساس پاسخ", "نمی‌خورد", "نادیده‌اش بگیر", "نادیده بگیر"]
# A half-space (ZWNJ) typed as a plain space: a standalone «می» before a verb, or a plural
# «ها»/«های» detached from its noun.
_MISSING_ZWNJ_RE = re.compile(r"(?:^|\s)می\s+\S|\s+ها(?:ی\S*)?(?:\s|$)")


def _words(text: str) -> int:
    return len(text.split())


def generated_texts(report: ReportV2) -> dict[str, str]:
    """Every model-written string, keyed for log messages."""
    texts = {
        "hook": report.hook,
        "strength.title": report.strength.title,
        "strength.text": report.strength.text,
        "findings_heading": report.findings_heading,
        "open_question.text": report.open_question.text,
        "exit.bridge": report.exit.bridge,
        "exit.root_question": report.exit.root_question,
    }
    for i, f in enumerate(report.findings):
        texts[f"findings[{i}].title"] = f.title
        texts[f"findings[{i}].what"] = f.what
        texts[f"findings[{i}].cost"] = f.cost
        texts[f"findings[{i}].curiosity"] = f.curiosity
        if f.suggested_step:
            texts[f"findings[{i}].suggested_step.text"] = f.suggested_step.text
    return texts


def soft_check_v2(output: AIOutputV2) -> list[str]:
    """Length bands and forbidden words from section 4.3. Warns, never raises."""
    warnings: list[str] = []
    r = output.report

    def band(label: str, text: str, key: str):
        lo, hi = _LENGTH_BANDS[key]
        n = _words(text)
        if (lo is not None and n < lo) or (hi is not None and n > hi):
            warnings.append(f"{label} is {n} words (expected {lo or 0}-{hi or 'any'})")

    band("hook", r.hook, "hook")
    band("strength.title", r.strength.title, "strength.title")
    band("strength.text", r.strength.text, "strength.text")
    band("findings_heading", r.findings_heading, "findings_heading")
    for i, f in enumerate(r.findings):
        band(f"findings[{i}].title", f.title, "finding.title")
        band(f"findings[{i}].what", f.what, "finding.what")
        band(f"findings[{i}].cost", f.cost, "finding.cost")
        band(f"findings[{i}].curiosity", f.curiosity, "finding.curiosity")
    band("open_question.text", r.open_question.text, "open_question.text")
    band("exit.bridge", r.exit.bridge, "exit.bridge")
    band("exit.root_question", r.exit.root_question, "exit.root_question")

    # Total counts the same fields the user reads (the step lives in a collapsed section but
    # is still model-written text; the spec's 260-340 band is measured on the sample's fields,
    # which exclude the step).
    total = sum(
        _words(t) for k, t in generated_texts(r).items() if not k.endswith("suggested_step.text")
    )
    if not _TOTAL_BAND[0] <= total <= _TOTAL_BAND[1]:
        warnings.append(f"total generated text is {total} words (expected {_TOTAL_BAND[0]}-{_TOTAL_BAND[1]})")

    for label, text in generated_texts(r).items():
        for category, words in _FORBIDDEN.items():
            for word in words:
                if word in text:
                    warnings.append(f"{label} contains forbidden {category} word {word!r}")
        if _DIGIT_RE.search(text):
            warnings.append(f"{label} contains a digit")
        for phrase in _DISCLAIMER_PHRASES:
            if phrase in text:
                warnings.append(f"{label} contains a disclaimer phrase {phrase!r}")
        if _MISSING_ZWNJ_RE.search(text):
            warnings.append(f"{label} has a plain space where a half-space (ZWNJ) belongs")

    step = r.findings[0].suggested_step
    n = _words(step.text)
    if not 8 <= n <= 30:
        warnings.append(f"findings[0].suggested_step.text is {n} words (expected 8-30)")

    for w in warnings:
        logger.warning("soft validation (v2): %s", w)
    return warnings


__all__ = [
    "AIOutputV2", "ReportV2", "ReportResponseV2", "REPORT_VERSION_V2", "soft_check_v2",
    "MemoryCandidate",
]
