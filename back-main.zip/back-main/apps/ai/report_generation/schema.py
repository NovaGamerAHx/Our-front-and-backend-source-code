"""
report_schema.py  (card 18)

Pydantic models for the report service output, per report_spec_v1.3 section 4.

Two distinct models, because the LLM and the service return different things:
  - AIOutput       -> what the model returns: {report, system}
  - ReportResponse -> what the service returns to backend:
                      {status, report_version, report, system, memory_candidates, error,
                      generation_meta}

memory_candidates are built deterministically in code (see memory_candidates.py),
never by the model -- which is why they are absent from AIOutput by design.

Validation is deliberately two-tier for the MVP:
  HARD (Pydantic rejects) -- item counts, enum values, key correctness and uniqueness.
       Getting these wrong breaks the UI, so they are worth a retry.
  SOFT (logged, never rejected) -- text length limits. A 145-word narrative instead of
       150 is not worth a retry and another paid call.
"""

from __future__ import annotations

import logging
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

logger = logging.getLogger(__name__)


# --------------------------------------------------------------------------
# Enums (closed sets from the spec)
# --------------------------------------------------------------------------

DimensionKey = Literal[
    "emotional_stability", "extraversion", "openness",
    "agreeableness", "conscientiousness",
]

LifePatternKey = Literal[
    "decision_style", "relationship_style",
    "work_learning_style", "stress_energy_pattern",
]

ActionType = Literal[
    "decision", "execution", "relationship",
    "learning", "wellbeing", "communication",
]

PatternTag = Literal[
    "responsible_executor", "growth_oriented_learner",
    "analytical_decision_maker", "social_connector",
    "empathic_supporter", "steady_resilient",
    "novelty_seeker", "independent_thinker",
]

MemoryType = Literal["core_pattern", "strength", "growth_edge", "growth_focus"]
ConfidenceLevel = Literal["low", "medium", "high"]
SensitivityLevel = Literal["low", "medium", "high"]

EXPECTED_DIMENSION_KEYS = {
    "emotional_stability", "extraversion", "openness",
    "agreeableness", "conscientiousness",
}
EXPECTED_LIFE_PATTERN_KEYS = {
    "decision_style", "relationship_style",
    "work_learning_style", "stress_energy_pattern",
}


# --------------------------------------------------------------------------
# Report sub-models
# --------------------------------------------------------------------------

class Summary(BaseModel):
    one_line: str


class SnapshotInterpretation(BaseModel):
    key: DimensionKey
    text: str


class CoreNarrative(BaseModel):
    body: str


class KeyStrength(BaseModel):
    title: str
    description: str
    why_it_matters: str


class GrowthEdge(BaseModel):
    title: str
    description: str
    growth_reframe: str


class LifePatternCard(BaseModel):
    key: LifePatternKey
    summary: str
    best_when: str
    watch_out: str


DeadlineType = Literal["tonight", "tomorrow_morning", "tomorrow_evening", "within_24h"]


class SuggestedStep(BaseModel):
    """A ready-made first step for a recommendation, generated in the same call as the
    report (report_spec §5.5): the user taps «این را قدمِ امروز کن» and the step is already
    there, nothing left to decide.

    Storing it beside the report is not a commitment -- it becomes an action step only when
    the user accepts it, at which point backend writes an action_steps row.
    """

    text: str
    deadline_text: str
    deadline_type: DeadlineType
    # Always null in a report. A report knows the scores and nothing about the week behind
    # them, so decomposing a step here is guesswork. The field exists only because the
    # front-end card is shared with chat, where substeps are occasionally real.
    substeps: list[str] | None = None


class Recommendation(BaseModel):
    title: str
    description: str
    action_type: ActionType
    suggested_step: SuggestedStep


class GrowthPath(BaseModel):
    main_growth_focus: str
    why_this_matters: str
    growth_principle: str
    recommendations: list[Recommendation] = Field(min_length=3, max_length=3)
    next_action_prompt: str


class Preview(BaseModel):
    teaser_line: str


class Share(BaseModel):
    hook: str
    line: str


class Report(BaseModel):
    summary: Summary
    snapshot_interpretations: list[SnapshotInterpretation] = Field(min_length=5, max_length=5)
    core_narrative: CoreNarrative
    key_strengths: list[KeyStrength] = Field(min_length=3, max_length=3)
    growth_edges: list[GrowthEdge] = Field(min_length=2, max_length=2)
    life_pattern_cards: list[LifePatternCard] = Field(min_length=4, max_length=4)
    growth_path: GrowthPath
    preview: Preview
    # Optional (spec v1.5 §4.1/§4.3): the prompt/fewshot examples don't emit this yet,
    # so it must not hard-fail validation until that AI-side work lands.
    share: Share | None = None

    @field_validator("snapshot_interpretations")
    @classmethod
    def _dimension_keys_complete(cls, v: list[SnapshotInterpretation]):
        # Literal already restricts each key to the valid set; this catches duplicates
        # (e.g. "openness" twice and "agreeableness" missing), which the type alone allows.
        keys = {item.key for item in v}
        if keys != EXPECTED_DIMENSION_KEYS:
            missing = EXPECTED_DIMENSION_KEYS - keys
            raise ValueError(f"snapshot_interpretations must cover all 5 dimensions; missing: {missing}")
        return v

    @field_validator("life_pattern_cards")
    @classmethod
    def _life_pattern_keys_complete(cls, v: list[LifePatternCard]):
        keys = {item.key for item in v}
        if keys != EXPECTED_LIFE_PATTERN_KEYS:
            missing = EXPECTED_LIFE_PATTERN_KEYS - keys
            raise ValueError(f"life_pattern_cards must cover all 4 keys; missing: {missing}")
        return v


class SystemBlock(BaseModel):
    pattern_tags: list[PatternTag] = Field(min_length=1, max_length=3)


class AIOutput(BaseModel):
    """Exactly what the model is asked to return -- nothing more."""
    model_config = ConfigDict(extra="forbid")

    report: Report
    system: SystemBlock


# --------------------------------------------------------------------------
# Service response models
# --------------------------------------------------------------------------

class MemoryCandidate(BaseModel):
    memory_type: MemoryType
    text_memory: str
    source: str
    confidence: ConfidenceLevel
    sensitivity_level: SensitivityLevel
    should_store: bool


class ErrorInfo(BaseModel):
    code: Literal["generation_failed"]
    user_message: str
    should_display_report: bool = False


class GenerationMeta(BaseModel):
    """Raw generation stats -- no cost. Backend prices and stores this, since model
    pricing lives with backend/business logic, not in this service (and the model
    isn't even finalized yet -- card 15 is still open).

    Token/latency totals are summed across every attempt that actually got a response
    from the provider (even ones that then failed JSON/schema validation), because
    those attempts were still paid for. Attempts that raised before any response came
    back (network/auth/rate-limit errors) contribute nothing, since no usage exists
    for them.
    """
    # model_used starts with "model_", pydantic's default protected prefix for its own
    # model_* methods -- not relevant here since GenerationMeta has none, so this just
    # silences the false-positive warning.
    model_config = ConfigDict(protected_namespaces=())

    model_used: str | None = None  # None if every attempt failed
    attempts: int
    input_tokens: int = 0
    output_tokens: int = 0
    latency_s: float = 0.0


class ReportResponse(BaseModel):
    """What the service hands back to backend (spec 4.1 / 4.2).

    On error, report / system / memory_candidates are all absent -- a hard rule
    from the spec: no partial report is ever displayed. generation_meta is still
    included even on error, since attempts that reached the provider still cost
    money and backend should be able to record that regardless of outcome.
    """
    status: Literal["ok", "error"]
    report_version: str = "report_v1"
    report: Report | None = None
    system: SystemBlock | None = None
    memory_candidates: list[MemoryCandidate] | None = None
    error: ErrorInfo | None = None
    generation_meta: GenerationMeta | None = None


# --------------------------------------------------------------------------
# Soft validation -- logged, never raises
# --------------------------------------------------------------------------

def _word_count(text: str) -> int:
    return len(text.split())


def soft_check(output: AIOutput) -> list[str]:
    """Length rules from spec 4.3. Returns warnings; does NOT raise.

    These are quality signals worth logging and feeding into eval (card 25),
    but not worth rejecting a report and paying for another generation.
    """
    warnings: list[str] = []
    r = output.report

    n = _word_count(r.summary.one_line)
    if n > 35:
        warnings.append(f"summary.one_line is {n} words (limit 35)")

    body = r.core_narrative.body
    paragraphs = body.split("\n\n")
    if len(paragraphs) != 3:
        warnings.append(f"core_narrative has {len(paragraphs)} paragraphs (expected 3)")

    n = _word_count(body.replace("\n\n", " "))
    if not 150 <= n <= 220:
        warnings.append(f"core_narrative is {n} words (expected 150-220)")

    n = _word_count(r.preview.teaser_line)
    if n > 20:
        warnings.append(f"preview.teaser_line is {n} words (limit 20)")

    for i, rec in enumerate(r.growth_path.recommendations, start=1):
        step = rec.suggested_step
        n = _word_count(step.text)
        if not 8 <= n <= 30:
            warnings.append(
                f"recommendation {i} suggested_step.text is {n} words (expected 8-30)"
            )
        # Soft, not hard: a step with substeps is wrong for a report but still usable, and
        # rejecting the whole report over it would cost another full generation.
        if step.substeps:
            warnings.append(
                f"recommendation {i} suggested_step has substeps; report steps must not"
            )

    for w in warnings:
        logger.warning("soft validation: %s", w)
    return warnings