"""
question_map_v3.py

The canonical q1..q30 contract of the initial report v3 (`V3_LLM_REFERENCE.md` section 3),
and the explicit, versioned mapping from a real assessment's questions onto it.

Why this file exists at all: the v3 prompt sends the model *evidence strings* built from the
question wording («q7: بودن در جمع به من انرژی می‌دهد. (موافقم)») and the model answers with a
`source_map` that cites `qN` ids. A `qN` is therefore a semantic identity, NOT a database
primary key and NOT a row number: two assessments (or two environments) can hold the same 30
items under completely different ids. Mapping by section (= dimension) + order and then
VERIFYING text and reverse flag is the only safe way to produce that payload.

Pure data + pure functions on purpose: no Django import, so apps.ai stays usable (and
testable) without the database. apps.report owns the translation from DB rows into the
`MappedQuestion` entries this module verifies -- see
apps.report.services.report_v3_input_service.ReportV3InputService.

Any mismatch raises QuestionMapError. It is never "repaired" by guessing: a wrong mapping
would send the model evidence that does not match what the user actually read on screen.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

# Dimension order of the contract: q1-q6 emotional_stability, q7-q12 extraversion,
# q13-q18 openness, q19-q24 agreeableness, q25-q30 conscientiousness. Identical to
# apps.report.services.scoring_service.DIMENSION_ORDER (asserted in the tests), which is also
# the section order the 30-item assessment is seeded in.
DIMENSION_ORDER_V3 = (
    "emotional_stability",
    "extraversion",
    "openness",
    "agreeableness",
    "conscientiousness",
)

QUESTIONS_PER_DIMENSION = 6

# V3_LLM_REFERENCE.md section 3: shown to the model inside every evidence string, never
# translated or reworded.
LIKERT_LABELS = {
    1: "کاملاً مخالفم",
    2: "مخالفم",
    3: "نه موافق نه مخالف",
    4: "موافقم",
    5: "کاملاً موافقم",
}

# Display labels of the five dimensions (reference section 3). They are NOT sent to the model
# (the v3 prompt forbids writing them); they exist so operational tooling can print a
# human-readable dimension name.
DIMENSION_LABELS_V3 = {
    "emotional_stability": "ثبات هیجانی",
    "extraversion": "انرژی اجتماعی",
    "openness": "ذهن رشدگرا",
    "agreeableness": "همدلی و همکاری",
    "conscientiousness": "مسئولیت\u200cپذیری",
}


@dataclass(frozen=True)
class QuestionSpec:
    """One row of the v3 contract. `id` is the studio's semantic id, `num` its 1-based
    position, `dim` the dimension it scores, `reverse` whether 6-value scoring applies."""

    id: str
    num: int
    dim: str
    reverse: bool
    text: str


@dataclass(frozen=True)
class MappedQuestion:
    """One real assessment question, as apps.report hands it over for verification.

    `external_id` is whatever the caller uses to key answers (the DB primary key in
    production); this module only passes it through, it never interprets it.
    """

    external_id: object
    dimension: str
    order: int
    text: str
    reverse_scored: bool


class QuestionMapError(Exception):
    """The assessment does not match the v3 question contract.

    Operational (configuration) error, never a user error: it means v3 was pointed at an
    assessment whose items differ from the ones the v3 prompt describes. `problems` lists
    every mismatch at once so one run of the checker fixes everything, instead of one
    mismatch per deploy.
    """

    def __init__(self, problems: list[str]):
        self.problems = problems
        super().__init__("; ".join(problems))


# ---------------------------------------------------------------------------
# The contract itself -- verbatim from V3_LLM_REFERENCE.md section 3.
# ---------------------------------------------------------------------------

V3_QUESTIONS: tuple[QuestionSpec, ...] = (
    QuestionSpec(id="q1", num=1, dim="emotional_stability", reverse=True, text="حتی اتفاق\u200cهای کوچک هم می\u200cتوانند مدت زیادی ذهنم را درگیر کنند."),
    QuestionSpec(id="q2", num=2, dim="emotional_stability", reverse=False, text="در شرایط پراسترس معمولاً آرامش خود را حفظ می\u200cکنم."),
    QuestionSpec(id="q3", num=3, dim="emotional_stability", reverse=True, text="تغییرات ناگهانی باعث نگرانی من می\u200cشود."),
    QuestionSpec(id="q4", num=4, dim="emotional_stability", reverse=False, text="بعد از شکست، سریع به حالت عادی برمی\u200cگردم."),
    QuestionSpec(id="q5", num=5, dim="emotional_stability", reverse=True, text="معمولاً نگران آینده هستم."),
    QuestionSpec(id="q6", num=6, dim="emotional_stability", reverse=False, text="احساسات من به\u200cراحتی از کنترل خارج نمی\u200cشوند."),
    QuestionSpec(id="q7", num=7, dim="extraversion", reverse=False, text="بودن در جمع به من انرژی می\u200cدهد."),
    QuestionSpec(id="q8", num=8, dim="extraversion", reverse=False, text="معمولاً آغازکننده\u200cی گفتگو با افراد جدید هستم."),
    QuestionSpec(id="q9", num=9, dim="extraversion", reverse=True, text="ترجیح می\u200cدهم بیشتر اوقات تنها باشم."),
    QuestionSpec(id="q10", num=10, dim="extraversion", reverse=False, text="حضور در جمع\u200cهای شلوغ برایم لذت\u200cبخش است."),
    QuestionSpec(id="q11", num=11, dim="extraversion", reverse=False, text="به\u200cراحتی احساسات مثبت خود را بروز می\u200cدهم."),
    QuestionSpec(id="q12", num=12, dim="extraversion", reverse=True, text="در موقعیت\u200cهای اجتماعی معمولاً ساکت می\u200cمانم."),
    QuestionSpec(id="q13", num=13, dim="openness", reverse=False, text="از یادگیری موضوعات کاملاً جدید لذت می\u200cبرم."),
    QuestionSpec(id="q14", num=14, dim="openness", reverse=False, text="دوست دارم روش\u200cهای متفاوت را امتحان کنم."),
    QuestionSpec(id="q15", num=15, dim="openness", reverse=True, text="ترجیح می\u200cدهم همه\u200cچیز طبق روال همیشگی باشد."),
    QuestionSpec(id="q16", num=16, dim="openness", reverse=False, text="ایده\u200cهای غیرمعمول برایم جذاب هستند."),
    QuestionSpec(id="q17", num=17, dim="openness", reverse=False, text="به هنر، فلسفه یا مفاهیم عمیق علاقه دارم."),
    QuestionSpec(id="q18", num=18, dim="openness", reverse=False, text="تغییر را فرصتی برای رشد می\u200cبینم."),
    QuestionSpec(id="q19", num=19, dim="agreeableness", reverse=False, text="معمولاً سعی می\u200cکنم احساسات دیگران را درک کنم."),
    QuestionSpec(id="q20", num=20, dim="agreeableness", reverse=False, text="کمک کردن به دیگران برایم رضایت\u200cبخش است."),
    QuestionSpec(id="q21", num=21, dim="agreeableness", reverse=True, text="اگر حق با من باشد، به\u200cندرت کوتاه می\u200cآیم."),
    QuestionSpec(id="q22", num=22, dim="agreeableness", reverse=False, text="مردم معمولاً مرا فردی قابل اعتماد می\u200cدانند."),
    QuestionSpec(id="q23", num=23, dim="agreeableness", reverse=False, text="قبل از قضاوت دیگران، شرایطشان را در نظر می\u200cگیرم."),
    QuestionSpec(id="q24", num=24, dim="agreeableness", reverse=True, text="رقابت برایم مهم\u200cتر از همکاری است."),
    QuestionSpec(id="q25", num=25, dim="conscientiousness", reverse=False, text="کارهایم را معمولاً طبق برنامه انجام می\u200cدهم."),
    QuestionSpec(id="q26", num=26, dim="conscientiousness", reverse=False, text="به\u200cندرت انجام کارها را به تعویق می\u200cاندازم."),
    QuestionSpec(id="q27", num=27, dim="conscientiousness", reverse=False, text="محیط کار یا زندگی من معمولاً منظم است."),
    QuestionSpec(id="q28", num=28, dim="conscientiousness", reverse=False, text="قبل از تصمیم\u200cگیری، جوانب مختلف را بررسی می\u200cکنم."),
    QuestionSpec(id="q29", num=29, dim="conscientiousness", reverse=True, text="گاهی بدون برنامه و از روی لحظه عمل می\u200cکنم."),
    QuestionSpec(id="q30", num=30, dim="conscientiousness", reverse=False, text="اگر مسئولیتی بپذیرم، تا پایان به آن پایبند می\u200cمانم."),
)


V3_QUESTIONS_BY_ID: dict[str, QuestionSpec] = {q.id: q for q in V3_QUESTIONS}
V3_QUESTION_IDS: tuple[str, ...] = tuple(q.id for q in V3_QUESTIONS)
V3_QUESTIONS_BY_DIMENSION: dict[str, tuple[QuestionSpec, ...]] = {
    dimension: tuple(q for q in V3_QUESTIONS if q.dim == dimension)
    for dimension in DIMENSION_ORDER_V3
}

# Known, explicitly approved wording equivalences, per question id. A production snapshot of
# `test-likert-v2` matched 29/30 texts and all 30 reverse flags; q1 differed only in the plural
# form («اتفاقات» instead of «اتفاق\u200cهای»), which is the same sentence for a reader and
# therefore the same evidence string semantically. Listed one by one on purpose: an arbitrary
# "close enough" comparison would silently accept a genuinely different item.
ACCEPTED_TEXT_VARIANTS: dict[str, tuple[str, ...]] = {
    "q1": ("حتی اتفاقات کوچک هم می\u200cتوانند مدت زیادی ذهنم را درگیر کنند.",),
}

_WHITESPACE_RE = re.compile(r"\s+")
# Arabic forms that are visually identical to the Persian ones and routinely enter a database
# through copy/paste or a different keyboard layout.
_CHAR_FOLD = {
    "\u064a": "\u06cc",  # ARABIC YEH    -> FARSI YEH
    "\u0649": "\u06cc",  # ALEF MAKSURA  -> FARSI YEH
    "\u0643": "\u06a9",  # ARABIC KAF    -> KEHEH
    "\u200c": " ",        # ZWNJ (نیم\u200cفاصله) -> space, then collapsed
    "\u200f": "",         # RLM
    "\u200e": "",         # LRM
}
# Trailing sentence punctuation carries no meaning for item identity.
_TRAILING_PUNCTUATION = ".!?\u060c\u061b\u061f"


def normalize_question_text(text: str) -> str:
    """Fold a question's text to the form used for identity comparison.

    Deliberately conservative: unicode NFC, Arabic/Persian letter folding, ZWNJ treated as a
    space, collapsed whitespace, no trailing punctuation. It does NOT fold different words,
    different word order, or different plural forms -- those go through
    ACCEPTED_TEXT_VARIANTS, one approved variant at a time.
    """
    folded = unicodedata.normalize("NFC", text)
    for source, replacement in _CHAR_FOLD.items():
        folded = folded.replace(source, replacement)
    folded = _WHITESPACE_RE.sub(" ", folded).strip()
    return folded.rstrip(_TRAILING_PUNCTUATION).strip()


def text_matches(spec: QuestionSpec, text: str) -> bool:
    candidate = normalize_question_text(text)
    accepted = (spec.text,) + ACCEPTED_TEXT_VARIANTS.get(spec.id, ())
    return any(candidate == normalize_question_text(variant) for variant in accepted)


def map_questions(questions: list[MappedQuestion]) -> dict[str, object]:
    """Map a real assessment's questions onto q1..q30.

    Returns {"q1": external_id, ...} for all 30 ids, or raises QuestionMapError listing every
    problem found. Only question metadata is inspected -- never a user's answers -- so the
    error text is safe to log.
    """
    problems: list[str] = []
    by_position: dict[tuple[str, int], list[MappedQuestion]] = {}
    for question in questions:
        if question.dimension not in V3_QUESTIONS_BY_DIMENSION:
            # Not part of the Big Five sections (e.g. a presentational section): ignored here,
            # exactly like ScoringService ignores it. Count mismatches are caught below.
            continue
        by_position.setdefault((question.dimension, question.order), []).append(question)

    for dimension in DIMENSION_ORDER_V3:
        found = sum(1 for (dim, _order) in by_position if dim == dimension)
        if found != QUESTIONS_PER_DIMENSION:
            problems.append(
                f"dimension {dimension!r} has {found} active question positions, "
                f"expected {QUESTIONS_PER_DIMENSION}"
            )

    mapping: dict[str, object] = {}
    for spec in V3_QUESTIONS:
        position = (spec.dim, (spec.num - 1) % QUESTIONS_PER_DIMENSION + 1)
        candidates = by_position.get(position, [])
        if not candidates:
            problems.append(f"{spec.id}: no active question at {spec.dim} order {position[1]}")
            continue
        if len(candidates) > 1:
            problems.append(
                f"{spec.id}: {len(candidates)} active questions share {spec.dim} order {position[1]}"
            )
            continue

        question = candidates[0]
        if not text_matches(spec, question.text):
            problems.append(
                f"{spec.id}: text mismatch at {spec.dim} order {position[1]} "
                f"(expected {spec.text!r}, found {question.text!r})"
            )
        if bool(question.reverse_scored) != spec.reverse:
            problems.append(
                f"{spec.id}: reverse_scored is {bool(question.reverse_scored)}, expected {spec.reverse}"
            )
        mapping[spec.id] = question.external_id

    if problems:
        raise QuestionMapError(problems)
    return mapping


__all__ = [
    "ACCEPTED_TEXT_VARIANTS",
    "DIMENSION_LABELS_V3",
    "DIMENSION_ORDER_V3",
    "LIKERT_LABELS",
    "MappedQuestion",
    "QUESTIONS_PER_DIMENSION",
    "QuestionMapError",
    "QuestionSpec",
    "V3_QUESTIONS",
    "V3_QUESTIONS_BY_DIMENSION",
    "V3_QUESTIONS_BY_ID",
    "V3_QUESTION_IDS",
    "map_questions",
    "normalize_question_text",
    "text_matches",
]
