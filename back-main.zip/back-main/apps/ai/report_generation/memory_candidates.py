"""
Builds memory_candidates deterministically from an already-generated report.
This is a plain field mapping, NOT an LLM call: the report is already structured, and
the model already made every judgement worth making. Re-asking it "what should be
remembered?" would spend money to make a solved decision unreliable.

KNOWN LIMIT OF (2), not a solved problem: pattern_tags count conflates "one sharp
pattern" with "one vague catch-all pattern". example_3.json is an intentionally flat
profile that still got a single tag (steady_resilient) -- because nothing specific
fit, not because one thing fit clearly -- and therefore scores "high" here. This is
still strictly better than a hardcoded constant, but it is a proxy, not a measurement.

STILL A PLACEHOLDER: confidence for "strength" and "growth_edge" is a constant. These
have no linkable signal today -- report_schema.py does not tag which dimension each
item came from, so there is nothing to derive from. Now that each is an aggregate of
several items, a per-item confidence would not fit the row anyway; a real fix means
deciding what confidence means for a merged row first. Do not let downstream code
treat this value as a real judgement.

sensitivity_level is unchanged. It is a category-level claim ("a growth_edge is
inherently more delicate than a one-line strength"), which holds regardless of user --
unlike confidence, it isn't pretending to measure something per-item that it has no
data for. Known limit, not a bug: it can't distinguish a mildly sensitive growth_edge
from a more sensitive one within the same category.

Note the growth_edge wording: it is stored REFRAMED, not raw. A memory that reads
"user overthinks" would make chat sound judgemental months later; the reframe keeps it
constructive. This is a Domain Expert call, not a technical one.
"""

from __future__ import annotations

from apps.ai.report_generation.schema import MemoryCandidate, Report, SystemBlock
from apps.ai.report_generation.schema_v2 import ReportV2

SOURCE = "initial_report"

# Placeholder only -- see module docstring. Not derived from any per-item signal.
_STRENGTH_EDGE_CONFIDENCE_PLACEHOLDER = "medium"

# Separator between merged items inside a single text_memory. Newline-delimited
# bullets keep the items distinguishable when the row is rendered into the Persian
# <user_memory> block, instead of running together into one sentence.
_ITEM_PREFIX = "- "
_ITEM_SEPARATOR = "\n"


def _core_pattern_confidence(system: SystemBlock) -> str:
    """Derive confidence from how many pattern_tags the model assigned.

    Fewer tags -> the model converged on one clear pattern -> higher confidence.
    More tags -> a blended/diffuse profile -> lower confidence. Real signal the
    model already produced, not a guess. See the docstring for its known limit.
    """
    n = len(system.pattern_tags)
    if n <= 1:
        return "high"
    if n == 2:
        return "medium"
    return "low"


def _merge(items: list[str]) -> str:
    """Merge several report items into one text_memory value."""
    return _ITEM_SEPARATOR.join(f"{_ITEM_PREFIX}{item}" for item in items)


def build_memory_candidates(report: Report, system: SystemBlock) -> list[MemoryCandidate]:
    """Map report fields -> memory candidates. Deterministic, no model involved.

    Always returns exactly 4 candidates -- one per memory_type -- regardless of how
    many strengths or growth_edges the report contains.
    """
    return [
        MemoryCandidate(
            memory_type="core_pattern",
            text_memory=report.summary.one_line,
            source=SOURCE,
            confidence=_core_pattern_confidence(system),
            sensitivity_level="low",
            should_store=True,
        ),
        MemoryCandidate(
            # all 3 strengths in one row
            memory_type="strength",
            text_memory=_merge([f"{s.title}: {s.description}" for s in report.key_strengths]),
            source=SOURCE,
            confidence=_STRENGTH_EDGE_CONFIDENCE_PLACEHOLDER,
            sensitivity_level="low",
            should_store=True,
        ),
        MemoryCandidate(
            # both growth_edges in one row
            memory_type="growth_edge",
            text_memory=_merge([f"{ge.title}: {ge.growth_reframe}" for ge in report.growth_edges]),
            source=SOURCE,
            confidence=_STRENGTH_EDGE_CONFIDENCE_PLACEHOLDER,
            sensitivity_level="medium",
            should_store=True,
        ),
        MemoryCandidate(
            memory_type="growth_focus",
            text_memory=report.growth_path.main_growth_focus,
            source=SOURCE,
            confidence="medium",
            sensitivity_level="low",
            should_store=True,
        ),
    ]


def build_memory_candidates_v2(report: ReportV2, system: SystemBlock) -> list[MemoryCandidate]:
    """report_v2 mapping (report_spec_v2_0 section 4.5). Still exactly 4 rows, same types, same
    source as v1 so a new report's rows take over the v1 lineage (user_id + memory_type + source).

    growth_edge stores each finding's `what` (a descriptive scene), never `cost` -- cost is the
    judgemental line, and this text is read by chat months later. curiosity and root_question
    are questions put to the user, not facts about them, so they are never stored.
    """
    return [
        MemoryCandidate(
            memory_type="core_pattern",
            text_memory=report.hook,
            source=SOURCE,
            confidence=_core_pattern_confidence(system),
            sensitivity_level="low",
            should_store=True,
        ),
        MemoryCandidate(
            memory_type="strength",
            text_memory=f"{report.strength.title}: {report.strength.text}",
            source=SOURCE,
            confidence=_STRENGTH_EDGE_CONFIDENCE_PLACEHOLDER,
            sensitivity_level="low",
            should_store=True,
        ),
        MemoryCandidate(
            memory_type="growth_edge",
            text_memory=_merge([f"{f.title}: {f.what}" for f in report.findings]),
            source=SOURCE,
            confidence=_STRENGTH_EDGE_CONFIDENCE_PLACEHOLDER,
            sensitivity_level="medium",
            should_store=True,
        ),
        MemoryCandidate(
            memory_type="growth_focus",
            text_memory=report.findings[0].title,
            source=SOURCE,
            confidence="medium",
            sensitivity_level="low",
            should_store=True,
        ),
    ]
