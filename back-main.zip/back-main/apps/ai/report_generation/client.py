"""Public entry point for the report-generation AI pipeline (report_spec_v1.3 §3 request /
§4 response contract).

This is the boundary consuming apps are meant to depend on: a plain
dimension_scores + optional context_profile in, a plain dict out. Nothing here knows
about any particular consumer's domain (attempts, demographics rows, etc.) -- that
translation belongs in the consumer's own adapter (see apps.report.services
.ai_report_client.AiReportClient for the report app's).
"""

import logging

from apps.ai.report_generation.generate import generate_report
from apps.ai.report_generation.profile_input import ProfileInput
from apps.ai.report_generation.schema import ReportResponse

logger = logging.getLogger(__name__)


class ReportGenerationClient:
    def __init__(self, openai_client=None):
        # Optional injected OpenAI-shaped client -- lets tests avoid real network calls.
        # None means generate_report() will build the real client itself, lazily, only
        # once generate() actually runs (never at construction time: callers may build a
        # ReportGenerationClient() by default even on paths that never call generate() at
        # all, and those must keep working without an API key set).
        self._openai_client = openai_client

    @staticmethod
    def _to_dict(response: ReportResponse) -> dict:
        generation_meta = response.generation_meta.model_dump() if response.generation_meta else None
        logger.info("ai generation_meta: %s", generation_meta)

        result = {"status": response.status, "report_version": response.report_version}
        if response.status == "ok":
            result["report"] = response.report.model_dump()
            result["system"] = response.system.model_dump()
            result["memory_candidates"] = [candidate.model_dump() for candidate in response.memory_candidates]
        else:
            result["error"] = response.error.model_dump()
        # Present in both branches (report_spec_v1.4 §4.2): attempts that reached the
        # provider cost money even when generation ultimately failed.
        result["generation_meta"] = generation_meta
        return result

    def generate(self, dimension_scores: list[dict], context_profile: dict | None = None) -> dict:
        """dimension_scores: list of 5 {"key","score_percent","level"} dicts.
        context_profile: optional {"age","life_situation","current_goal"} dict -- never
            include "gender", ProfileInput rejects it outright if it slips in.

        Returns report_spec_v1.3 §4.1 (status="ok") or §4.2 (status="error") shaped dict.
        """
        profile = ProfileInput(dimension_scores=dimension_scores, context_profile=context_profile)
        response = generate_report(profile, client=self._openai_client)
        return self._to_dict(response)
