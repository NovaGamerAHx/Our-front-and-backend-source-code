"""Public entry point for the report-generation AI pipeline (report_spec_v1.3 §3 request /
§4 response contract, extended for report_v3 by docs/report_spec_v3_0.md §3).

This is the boundary consuming apps are meant to depend on: plain dimension_scores +
optional context_profile (plus, for report_v3, the raw answers) in, a plain dict out.
Nothing here knows about any particular consumer's domain (attempts, demographics rows,
etc.) -- that translation belongs in the consumer's own adapter (see apps.report.services
.ai_report_client.AiReportClient for the report app's).
"""

import logging

from apps.ai.report_generation.generate import REPORT_V3, generate_report, initial_report_version
from apps.ai.report_generation.profile_input import ProfileInput
from apps.ai.report_generation.profile_input_v3 import AnswerSheetV3
from apps.ai.report_generation.schema import ReportResponse
from faraman_back.lang.utils import get_message

logger = logging.getLogger(__name__)


class ReportGenerationClient:
    def __init__(self, openai_client=None):
        # Optional injected OpenAI-shaped client -- lets tests avoid real network calls.
        # None means generate_report() will build the real client itself, lazily, only
        # once generate() actually runs (never at construction time: callers may build a
        # ReportGenerationClient() by default even on paths that never call generate() at
        # all, and those must keep working without an API key set).
        self._openai_client = openai_client

    @staticmethod
    def _to_dict(response: ReportResponse) -> dict:
        generation_meta = response.generation_meta.model_dump() if response.generation_meta else None
        logger.info("ai generation_meta: %s", generation_meta)

        result = {"status": response.status, "report_version": response.report_version}
        if response.status == "ok":
            result["report"] = response.report.model_dump()
            result["system"] = response.system.model_dump()
            result["memory_candidates"] = [candidate.model_dump() for candidate in response.memory_candidates]
        else:
            result["error"] = response.error.model_dump()
        # Present in both branches (report_spec_v1.4 §4.2): attempts that reached the
        # provider cost money even when generation ultimately failed.
        result["generation_meta"] = generation_meta
        return result

    def generate(
        self,
        dimension_scores: list[dict],
        context_profile: dict | None = None,
        answers: dict[str, int] | None = None,
        version: str | None = None,
    ) -> dict:
        """dimension_scores: list of 5 {"key","score_percent","level"} dicts.
        context_profile: optional {"age","life_situation","current_goal"} dict -- never
            include "gender", ProfileInput rejects it outright if it slips in.
        answers: report_v3 only -- {"q1".."q30": 1..5}, the raw Likert answers in the v3
            question contract's ID space (apps.ai.report_generation.question_map_v3 maps
            this assessment's questions onto it; never pass DB primary keys). v3 derives its
            own scores from these, so dimension_scores is ignored for v3 -- it stays in the
            signature because the caller computes it anyway for storage, and because v1/v2
            still need it.
        version: optional explicit version (a pinned Report.report_version). Unset = whatever
            REPORT_INITIAL_VERSION says.

        Returns report_spec_v1.3 §4.1 (status="ok") or §4.2 (status="error") shaped dict.
        """
        resolved = version or initial_report_version()

        if resolved == REPORT_V3:
            # Let a missing/invalid answer set surface as a normal error response rather than
            # an exception: this runs inside a Celery task whose job is to mark the report
            # errored, not to crash. AnswerSheetV3 is strict on purpose (exactly q1..q30,
            # ints 1..5, no silent `|| 3` default) -- see docs/report_spec_v3_0.md §2.2.
            try:
                profile = AnswerSheetV3(answers=answers or {}, context_profile=context_profile)
            except Exception as e:
                logger.error("report_v3 answers rejected: %s: %s", type(e).__name__, e)
                return {
                    "status": "error",
                    "report_version": REPORT_V3,
                    "error": {
                        "code": "insufficient_evidence",
                        "user_message": get_message("report_generation_failed"),
                        "should_display_report": False,
                    },
                    "generation_meta": None,
                }
        else:
            profile = ProfileInput(dimension_scores=dimension_scores, context_profile=context_profile)

        response = generate_report(profile, client=self._openai_client, version=resolved)
        return self._to_dict(response)
