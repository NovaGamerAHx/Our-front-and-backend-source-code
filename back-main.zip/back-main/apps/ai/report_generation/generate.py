"""
generate.py

The full path: ProfileInput -> messages -> model call -> parse -> ReportResponse.

Attempt ladder (worst case REPORT_MAX_PRIMARY_ATTEMPTS + 2 paid calls):
    1..N. primary model via OpenAI direct   (models are non-deterministic; a retry
          often just works -- N = REPORT_MAX_PRIMARY_ATTEMPTS)
    N+1.  backup model via OpenAI direct    (different tier, in case the primary is degraded)
    N+2.  backup model via AvalAI           (same model, different provider/infra path --
          in case OpenAI itself is down or rate-limiting, not the model)
    -> all failed: ReportResponse(status="error", code="generation_failed")

AvalAI re-sells the same OpenAI models under the same model IDs (see the AI repo's
compare_models.py spike) -- no model-name translation needed for the GPT family used here,
only a different base_url/api_key. See apps.ai.openai_client.PROVIDERS.

REPORT_AI_ENABLED=false skips all of the above and returns a fixed mock report instead (see
_mock_response) -- for testing the rest of the pipeline (DB writes, API shape) quickly,
e.g. on production, without waiting on or paying for a real generation. Defaults to true.

Two MVP simplicity decisions worth knowing:

1. JSON is requested via the prompt, not native Structured Outputs. While several
   providers are still being compared (OpenAI direct + AvalAI proxy), prompt-level JSON
   keeps this code provider-independent. Once the model is settled, switching to native
   structured output is a contained change here and should reduce retries.

2. Code fences are stripped before parsing. Models sometimes wrap JSON in ```json
   despite being told not to. Stripping costs nothing and avoids a wasted paid retry
   for a formatting quirk that isn't a real failure.

Model names, keys, and endpoints all come from the environment via os.getenv, read at the
point of use -- same convention as apps.account.services.sms_service -- never hardcoded,
never committed.
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
from pathlib import Path

from pydantic import ValidationError

from apps.ai.openai_client import client_for
from apps.ai.report_generation import prompt as prompt_v1
from apps.ai.report_generation import prompt_v2
from apps.ai.report_generation.memory_candidates import build_memory_candidates, build_memory_candidates_v2
from apps.ai.report_generation.profile_input import ProfileInput
from apps.ai.report_generation.schema import AIOutput, ErrorInfo, GenerationMeta, ReportResponse, soft_check
from apps.ai.report_generation.schema_v2 import AIOutputV2, ReportResponseV2, soft_check_v2
from faraman_back.lang.utils import get_message
from faraman_back.observability.metrics import AI_CALL_DURATION

logger = logging.getLogger(__name__)

_FENCE_RE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", re.IGNORECASE)
_FEWSHOT_DIR = Path(__file__).parent / "fewshot"
_FEWSHOT_V2_DIR = Path(__file__).parent / "fewshot_v2"

REPORT_V1 = "report_v1"
REPORT_V2 = "report_v2"
# What new generations use when REPORT_INITIAL_VERSION is unset/empty. v1 until the front-end
# renders v2: flipping this is a deploy-wide product change, not a code default to tweak.
DEFAULT_INITIAL_VERSION = REPORT_V1


class _Variant:
    """Everything that differs between report versions; the attempt ladder below is shared."""

    def __init__(self, version, build_messages, output_model, soft_check, build_memory, response_model):
        self.version = version
        self.build_messages = build_messages
        self.output_model = output_model
        self.soft_check = soft_check
        self.build_memory = build_memory
        self.response_model = response_model


_VARIANTS = {
    REPORT_V1: _Variant(
        REPORT_V1, prompt_v1.build_messages, AIOutput, soft_check, build_memory_candidates, ReportResponse,
    ),
    REPORT_V2: _Variant(
        REPORT_V2, prompt_v2.build_messages, AIOutputV2, soft_check_v2, build_memory_candidates_v2,
        ReportResponseV2,
    ),
}


def initial_report_version() -> str:
    """Which report shape new generations produce, from REPORT_INITIAL_VERSION (report_v1 |
    report_v2; unset/empty = DEFAULT_INITIAL_VERSION). The switch between the two products.
    Reports already stored keep their own version -- this only decides what the model is asked
    to write for new ones. `or` rather than a getenv default: an empty line
    from render_env.sh must fall back too (known issue #24)."""
    version = (os.getenv("REPORT_INITIAL_VERSION") or DEFAULT_INITIAL_VERSION).strip()
    if version not in _VARIANTS:
        logger.warning("unknown REPORT_INITIAL_VERSION %r; using %s", version, DEFAULT_INITIAL_VERSION)
        return DEFAULT_INITIAL_VERSION
    return version


def _strip_fences(text: str) -> str:
    """Remove ```json ... ``` wrappers if the model added them."""
    return _FENCE_RE.sub("", text.strip()).strip()


def _ai_enabled() -> bool:
    return os.getenv("REPORT_AI_ENABLED", "true").strip().lower() not in ("false", "0", "no")


def _mock_response(variant: _Variant) -> ReportResponse:
    """REPORT_AI_ENABLED=false path: skip the real model entirely and return one of the
    golden few-shot reports as-is. For quickly testing the rest of the pipeline (DB writes,
    memory persistence, the API response shape) without waiting on -- or paying for -- a
    real generation. Never personalized to the actual submitted scores; that's the point:
    it's a fixed placeholder, not a real report.

    REPORT_MOCK_DELAY_MS (default 0, today's exact instant behavior) optionally simulates the
    real call's latency -- this runs inside a Celery task (apps/report/tasks.py), not a web-tier
    request, so unlike the chat mock's delay this doesn't hold a gevent connection open; it's
    useful instead for exercising Celery worker occupancy duration under
    CELERY_WORKER_CONCURRENCY (known issue #21) during a load test. See loadtest/README.md."""
    delay_ms = int(os.getenv("REPORT_MOCK_DELAY_MS", "0"))
    if delay_ms > 0:
        time.sleep(delay_ms / 1000)

    fixture = _FEWSHOT_V2_DIR / "example_A.json" if variant.version == REPORT_V2 else _FEWSHOT_DIR / "example_1.json"
    example = json.loads(fixture.read_text(encoding="utf-8"))
    output = variant.output_model.model_validate({"report": example["report"], "system": example["system"]})

    logger.warning("REPORT_AI_ENABLED=false -- returning a mock report instead of calling a real model")

    return variant.response_model(
        status="ok",
        report=output.report,
        system=output.system,
        memory_candidates=variant.build_memory(output.report, output.system),
        generation_meta=GenerationMeta(
            model_used="mock",
            attempts=0,
            input_tokens=0,
            output_tokens=0,
            latency_s=0.0,
        ),
    )


def _call_once(client, model: str, messages: list[dict]) -> tuple[str, dict]:
    """One model call. Returns (raw_text, usage_dict). Raises on API failure."""
    started = time.perf_counter()
    resp = client.chat.completions.create(model=model, messages=messages)
    latency = time.perf_counter() - started

    text = resp.choices[0].message.content or ""
    usage = {}
    if getattr(resp, "usage", None):
        usage = {
            "input_tokens": resp.usage.prompt_tokens,
            "output_tokens": resp.usage.completion_tokens,
        }
    usage["latency_s"] = round(latency, 2)
    return text, usage


def generate_report(profile: ProfileInput, client=None, version: str | None = None) -> ReportResponse:
    """Generate a report. Always returns a ReportResponse -- never raises, never crashes.

    profile: validated ProfileInput (see profile_input.py)
    client:  optional injected OpenAI-shaped client, so tests can run without hitting a
             real API (dependency injection -- this is what makes this module's tests
             free). When given, it's used for every attempt regardless of provider --
             the provider distinction only matters for building the real client.
    """
    variant = _VARIANTS[version or initial_report_version()]

    if not _ai_enabled():
        return _mock_response(variant)

    generate_started = time.perf_counter()

    messages_started = time.perf_counter()
    scores, ctx = profile.to_prompt_payload()
    messages = variant.build_messages(scores, context_profile=ctx)
    logger.info("prompt messages built in %.2fs", time.perf_counter() - messages_started)

    primary_model = os.getenv("REPORT_PRIMARY_MODEL", "gpt-5.4-mini")
    backup_model = os.getenv("REPORT_BACKUP_MODEL", "gpt-5.4")
    # AvalAI is the last resort, after OpenAI has failed twice; it runs the full model, not the mini.
    avalai_model = os.getenv("REPORT_AVALAI_MODEL") or "gpt-5.4"
    max_primary_attempts = int(os.getenv("REPORT_MAX_PRIMARY_ATTEMPTS", "2"))

    # (provider, model) per attempt: primary on OpenAI (retried N times), then the
    # backup model on OpenAI, then the full model via AvalAI -- a different infra path in
    # case OpenAI itself (not the model) is the problem, so it gets the strongest model
    # rather than the cheaper backup.
    attempts = (
        [("openai", primary_model)] * max_primary_attempts
        + [("openai", backup_model), ("avalai", avalai_model)]
    )

    total_input_tokens = 0
    total_output_tokens = 0
    total_latency_s = 0.0
    attempts_made = 0

    for i, (provider, model) in enumerate(attempts, start=1):
        attempts_made = i
        attempt_started = time.perf_counter()
        try:
            # client_for is cached per provider (apps.ai.openai_client) -- no network call,
            # and reusing the connection pool avoids paying a cold TLS connect per attempt.
            call_client = client if client is not None else client_for(provider)

            raw, usage = _call_once(call_client, model, messages)
            total_input_tokens += usage.get("input_tokens", 0)
            total_output_tokens += usage.get("output_tokens", 0)
            total_latency_s += usage.get("latency_s", 0.0)

            output = variant.output_model.model_validate_json(_strip_fences(raw))

        except (json.JSONDecodeError, ValidationError) as e:
            # Model produced something, but it was malformed or off-schema.
            # Usage was already added above -- this attempt still cost money.
            attempt_elapsed = time.perf_counter() - attempt_started
            AI_CALL_DURATION.labels(
                purpose="report_initial", call="report", provider=provider, outcome="validation_error",
            ).observe(attempt_elapsed)
            logger.warning("attempt %d/%d (%s via %s) failed validation after %.2fs: %s",
                           i, len(attempts), model, provider, attempt_elapsed, e)
            # Feed the mistake back in for the next attempt (even across a model/provider
            # switch, since each call is a stateless one-shot with no memory of prior
            # attempts) -- otherwise every attempt in the ladder repeats the identical
            # error, since they'd otherwise see the exact same prompt.
            messages = messages + [
                {"role": "assistant", "content": raw},
                {"role": "user", "content": (
                    "That response failed schema validation:\n"
                    f"{e}\n\n"
                    "Return the corrected, complete JSON only -- no explanation, no markdown "
                    "fences. Double-check every enum/Literal field uses one of its exact "
                    "allowed values and no others."
                )},
            ]
            continue

        except Exception as e:
            # Network / auth / rate limit / provider error -- including the client
            # itself failing to build (e.g. a missing API key for this provider).
            # Broad on purpose: any failure should fall through to the next attempt,
            # never crash the caller. No usage to add here -- the exception means no
            # response came back.
            attempt_elapsed = time.perf_counter() - attempt_started
            AI_CALL_DURATION.labels(
                purpose="report_initial", call="report", provider=provider, outcome="error",
            ).observe(attempt_elapsed)
            logger.warning("attempt %d/%d (%s via %s) call failed after %.2fs: %s: %s",
                           i, len(attempts), model, provider, attempt_elapsed,
                           type(e).__name__, e)
            continue

        # Success. Length deviations are logged, not fatal (see schema.soft_check).
        attempt_elapsed = time.perf_counter() - attempt_started
        AI_CALL_DURATION.labels(
            purpose="report_initial", call="report", provider=provider, outcome="ok",
        ).observe(attempt_elapsed)
        total_elapsed = time.perf_counter() - generate_started
        warnings = variant.soft_check(output)
        logger.info(
            "report generated: model=%s provider=%s attempt=%d attempt_elapsed=%.2fs "
            "total_elapsed=%.2fs usage=%s soft_warnings=%d",
            model, provider, i, attempt_elapsed, total_elapsed, usage, len(warnings),
        )

        return variant.response_model(
            status="ok",
            report=output.report,
            system=output.system,
            memory_candidates=variant.build_memory(output.report, output.system),
            generation_meta=GenerationMeta(
                model_used=f"{model} ({provider})",
                attempts=attempts_made,
                input_tokens=total_input_tokens,
                output_tokens=total_output_tokens,
                latency_s=round(total_latency_s, 2),
            ),
        )

    total_elapsed = time.perf_counter() - generate_started
    logger.error("all %d attempts failed after %.2fs; returning generation_failed",
                 len(attempts), total_elapsed)
    return variant.response_model(
        status="error",
        error=ErrorInfo(
            code="generation_failed",
            user_message=get_message("report_generation_failed"),
            should_display_report=False,
        ),
        generation_meta=GenerationMeta(
            model_used=None,
            attempts=attempts_made,
            input_tokens=total_input_tokens,
            output_tokens=total_output_tokens,
            latency_s=round(total_latency_s, 2),
        ),
    )
