"""
generate.py

The full path: ProfileInput -> messages -> model call -> parse -> ReportResponse.

Attempt ladder (worst case REPORT_MAX_PRIMARY_ATTEMPTS + 2 paid calls):
    1..N. primary model via OpenAI direct   (models are non-deterministic; a retry
          often just works -- N = REPORT_MAX_PRIMARY_ATTEMPTS)
    N+1.  backup model via OpenAI direct    (different tier, in case the primary is degraded)
    N+2.  backup model via AvalAI           (same model, different provider/infra path --
          in case OpenAI itself is down or rate-limiting, not the model)
    -> all failed: ReportResponse(status="error", code="generation_failed")

AvalAI re-sells the same OpenAI models under the same model IDs (see the AI repo's
compare_models.py spike) -- no model-name translation needed for the GPT family used here,
only a different base_url/api_key. See apps.ai.openai_client.PROVIDERS.

REPORT_AI_ENABLED=false skips all of the above and returns a fixed mock report instead (see
_mock_response) -- for testing the rest of the pipeline (DB writes, API shape) quickly,
e.g. on production, without waiting on or paying for a real generation. Defaults to true.

Two MVP simplicity decisions worth knowing:

1. JSON is requested via the prompt, not native Structured Outputs. While several
   providers are still being compared (OpenAI direct + AvalAI proxy), prompt-level JSON
   keeps this code provider-independent. Once the model is settled, switching to native
   structured output is a contained change here and should reduce retries.

2. Code fences are stripped before parsing. Models sometimes wrap JSON in ```json
   despite being told not to. Stripping costs nothing and avoids a wasted paid retry
   for a formatting quirk that isn't a real failure.

Model names, keys, and endpoints all come from the environment via os.getenv, read at the
point of use -- same convention as apps.account.services.sms_service -- never hardcoded,
never committed.
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
from pathlib import Path

from pydantic import ValidationError

from apps.ai.openai_client import client_for
from apps.ai.report_generation import prompt as prompt_v1
from apps.ai.report_generation import prompt_v2, prompt_v3
from apps.ai.report_generation.memory_candidates import (
    build_memory_candidates,
    build_memory_candidates_v2,
    build_memory_candidates_v3,
)
from apps.ai.report_generation.profile_input import ProfileInput
from apps.ai.report_generation.profile_input_v3 import AnswerSheetV3
from apps.ai.report_generation.schema import AIOutput, ErrorInfo, GenerationMeta, ReportResponse, soft_check
from apps.ai.report_generation.schema_v2 import AIOutputV2, ReportResponseV2, soft_check_v2
from apps.ai.report_generation.schema_v3 import (
    AIOutputV3,
    ReportResponseV3,
    check_against_input,
    soft_check_v3,
)
from faraman_back.lang.utils import get_message
from faraman_back.observability.metrics import AI_CALL_DURATION

logger = logging.getLogger(__name__)

_FENCE_RE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", re.IGNORECASE)
_FEWSHOT_DIR = Path(__file__).parent / "fewshot"
_FEWSHOT_V2_DIR = Path(__file__).parent / "fewshot_v2"
_FEWSHOT_V3_DIR = Path(__file__).parent / "fewshot_v3"

REPORT_V1 = "report_v1"
REPORT_V2 = "report_v2"
REPORT_V3 = "report_v3"
# What new generations use when REPORT_INITIAL_VERSION is unset, empty or unrecognized.
#
# report_v2, not report_v1 (changed with the v3 work): v2 has been the deployed product for a
# while, so an environment that loses the variable -- scripts/render_env.sh writes an empty
# line for every key the CI does not set, known issue #24 -- must keep producing the shape the
# front-end actually renders, not silently fall back to the old long report. report_v3 is
# deliberately NOT reachable this way: it is only ever produced when REPORT_INITIAL_VERSION is
# set to exactly "report_v3", never by accident.
DEFAULT_INITIAL_VERSION = REPORT_V2


class _Variant:
    """Everything that differs between report versions; the attempt ladder below is shared.

    `prepare(model_input)` is the one piece that had to change shape for v3: v1/v2 send
    dimension scores only, while v3 sends a whole smart payload built from the raw answers.
    It returns (messages, payload) where `payload` is the final user turn's body, or None for
    the versions that have no input-dependent checks. The public build_messages() functions of
    prompt.py / prompt_v2.py are untouched.
    """

    def __init__(
        self, version, prepare, input_model, output_model, soft_check, build_memory, response_model,
        mock_fixture, cross_check=None, precheck=None,
    ):
        self.version = version
        self.prepare = prepare
        self.input_model = input_model
        self.output_model = output_model
        self.soft_check = soft_check
        self.build_memory = build_memory
        self.response_model = response_model
        self.mock_fixture = mock_fixture
        # (output, payload) -> CrossCheckResult. Rules that need this user's input.
        self.cross_check = cross_check
        # model_input -> reason string | None. Refuses to spend a paid call on an input that
        # cannot produce a compliant report (v3's insufficient-evidence case).
        self.precheck = precheck


def _prepare_v1(profile: ProfileInput):
    scores, context_profile = profile.to_prompt_payload()
    return prompt_v1.build_messages(scores, context_profile=context_profile), None


def _prepare_v2(profile: ProfileInput):
    scores, context_profile = profile.to_prompt_payload()
    return prompt_v2.build_messages(scores, context_profile=context_profile), None


def _prepare_v3(sheet: AnswerSheetV3):
    payload = sheet.to_smart_payload()
    return prompt_v3.build_messages(payload), payload


def _memory_v1(report, system, payload):
    return build_memory_candidates(report, system)


def _memory_v2(report, system, payload):
    return build_memory_candidates_v2(report, system)


def _memory_v3(report, system, payload):
    goal = ((payload or {}).get("context") or {}).get("current_goal")
    return build_memory_candidates_v3(report, system, goal_chosen=bool(goal) and goal != "unsure")


_VARIANTS = {
    REPORT_V1: _Variant(
        REPORT_V1, _prepare_v1, ProfileInput, AIOutput, soft_check, _memory_v1, ReportResponse,
        _FEWSHOT_DIR / "example_1.json",
    ),
    REPORT_V2: _Variant(
        REPORT_V2, _prepare_v2, ProfileInput, AIOutputV2, soft_check_v2, _memory_v2, ReportResponseV2,
        _FEWSHOT_V2_DIR / "example_A.json",
    ),
    REPORT_V3: _Variant(
        REPORT_V3, _prepare_v3, AnswerSheetV3, AIOutputV3, soft_check_v3, _memory_v3, ReportResponseV3,
        # A dedicated, obviously-synthetic mock -- NOT one of the golden few-shot examples, so a
        # mock report can never be mistaken for a real personalized one (every string is marked
        # «[نمونه‌ی آزمایشی]»).
        _FEWSHOT_V3_DIR / "mock_report.json",
        cross_check=check_against_input,
        precheck=lambda sheet: sheet.insufficient_evidence_reason(),
    ),
}


def initial_report_version() -> str:
    """Which report shape new generations produce, from REPORT_INITIAL_VERSION (report_v1 |
    report_v2 | report_v3; unset/empty/unknown = DEFAULT_INITIAL_VERSION = report_v2).

    Reports already stored keep their own version -- this only decides what the model is asked
    to write for new ones, and (since the v3 work) what gets pinned onto a newly queued row;
    see ReportRepository.create_generating_initial. `or` rather than a getenv default: an empty
    line from render_env.sh must fall back too (known issue #24)."""
    version = (os.getenv("REPORT_INITIAL_VERSION") or DEFAULT_INITIAL_VERSION).strip()
    if version not in _VARIANTS:
        logger.warning("unknown REPORT_INITIAL_VERSION %r; using %s", version, DEFAULT_INITIAL_VERSION)
        return DEFAULT_INITIAL_VERSION
    return version


def resolve_variant(version: str | None) -> _Variant:
    """The variant for an explicitly requested version (a pinned Report.report_version, say),
    falling back to the environment's version for anything unknown.

    Unknown rather than invalid on purpose: a row pinned to a version this build does not know
    (rolled back code, hand-edited row) must still generate something rather than crash the
    worker, and must do so under the version the operator currently has configured.
    """
    if version and version in _VARIANTS:
        return _VARIANTS[version]
    if version:
        logger.warning("unknown pinned report version %r; using the configured one instead", version)
    return _VARIANTS[initial_report_version()]


def _strip_fences(text: str) -> str:
    """Remove ```json ... ``` wrappers if the model added them."""
    return _FENCE_RE.sub("", text.strip()).strip()


def _ai_enabled() -> bool:
    # `or`, not a getenv default: render_env.sh writes an empty line for every key the CI
    # does not set, and "" must mean "unset" here (known issue #24).
    return (os.getenv("REPORT_AI_ENABLED") or "true").strip().lower() not in ("false", "0", "no")


def _mock_response(variant: _Variant) -> ReportResponse:
    """REPORT_AI_ENABLED=false path: skip the real model entirely and return one of the
    golden few-shot reports as-is. For quickly testing the rest of the pipeline (DB writes,
    memory persistence, the API response shape) without waiting on -- or paying for -- a
    real generation. Never personalized to the actual submitted scores; that's the point:
    it's a fixed placeholder, not a real report.

    REPORT_MOCK_DELAY_MS (default 0, today's exact instant behavior) optionally simulates the
    real call's latency -- this runs inside a Celery task (apps/report/tasks.py), not a web-tier
    request, so unlike the chat mock's delay this doesn't hold a gevent connection open; it's
    useful instead for exercising Celery worker occupancy duration under
    CELERY_WORKER_CONCURRENCY (known issue #21) during a load test. See loadtest/README.md."""
    delay_ms = int(os.getenv("REPORT_MOCK_DELAY_MS") or "0")
    if delay_ms > 0:
        time.sleep(delay_ms / 1000)

    example = json.loads(variant.mock_fixture.read_text(encoding="utf-8"))
    output = variant.output_model.model_validate({"report": example["report"], "system": example["system"]})

    logger.warning("REPORT_AI_ENABLED=false -- returning a mock report instead of calling a real model")

    return variant.response_model(
        status="ok",
        report=output.report,
        system=output.system,
        memory_candidates=variant.build_memory(output.report, output.system, None),
        generation_meta=GenerationMeta(
            model_used="mock",
            attempts=0,
            input_tokens=0,
            output_tokens=0,
            latency_s=0.0,
        ),
    )


def _call_once(client, model: str, messages: list[dict]) -> tuple[str, dict]:
    """One model call. Returns (raw_text, usage_dict). Raises on API failure."""
    started = time.perf_counter()
    resp = client.chat.completions.create(model=model, messages=messages)
    latency = time.perf_counter() - started

    text = resp.choices[0].message.content or ""
    usage = {}
    if getattr(resp, "usage", None):
        usage = {
            "input_tokens": resp.usage.prompt_tokens,
            "output_tokens": resp.usage.completion_tokens,
        }
    usage["latency_s"] = round(latency, 2)
    return text, usage


_ERROR_MESSAGE_KEY = {
    "generation_failed": "report_generation_failed",
    # Deliberately NOT a different wording for the user: the reason this report could not be
    # written (too few non-neutral answers) is about how they answered, and saying so would
    # both leak the scoring rules and read as blame. Operators get the real reason in the logs
    # and in error_code; see docs/report_spec_v3_0.md section 6.4.
    "insufficient_evidence": "report_generation_failed",
}


def _error_response(
    variant: _Variant, *, attempts: int, code: str = "generation_failed",
    input_tokens: int = 0, output_tokens: int = 0, latency_s: float = 0.0,
) -> ReportResponse:
    """The version-tagged error shape (report_spec_v1.4 section 4.2), with generation_meta
    even when no call was made (attempts=0, no tokens)."""
    return variant.response_model(
        status="error",
        error=ErrorInfo(
            code=code,
            user_message=get_message(_ERROR_MESSAGE_KEY[code]),
            should_display_report=False,
        ),
        generation_meta=GenerationMeta(
            model_used=None,
            attempts=attempts,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            latency_s=latency_s,
        ),
    )


class _CrossCheckFailed(ValueError):
    """An output that parsed and passed the schema, but contradicts the input it was given
    (see schema_v3.check_against_input). Handled exactly like a schema failure: the reason is
    fed back and the ladder retries."""


def generate_report(profile, client=None, version: str | None = None) -> ReportResponse:
    """Generate a report. Always returns a ReportResponse -- never raises, never crashes.

    profile: the version's input model. ProfileInput (dimension scores + optional context)
             for report_v1/report_v2, AnswerSheetV3 (the 30 raw answers + the same optional
             context) for report_v3. Passing the wrong one for the resolved version is a
             programming error and returns a generation_failed response rather than raising.
    client:  optional injected OpenAI-shaped client, so tests can run without hitting a
             real API (dependency injection -- this is what makes this module's tests
             free). When given, it's used for every attempt regardless of provider --
             the provider distinction only matters for building the real client.
    version: an explicit version (e.g. the one pinned on the Report row). Unknown values fall
             back to the configured one -- see resolve_variant.
    """
    variant = resolve_variant(version)

    if not isinstance(profile, variant.input_model):
        # Never a user-visible condition: it means a caller used the wrong entry point for the
        # configured version (e.g. ReportGenerationClient.generate() while report_v3 is on).
        logger.error(
            "report %s expects %s input, got %s",
            variant.version, variant.input_model.__name__, type(profile).__name__,
        )
        return _error_response(variant, attempts=0)

    if not _ai_enabled():
        return _mock_response(variant)

    if variant.precheck is not None:
        reason = variant.precheck(profile)
        if reason:
            # No provider call at all: the input cannot produce a rule-compliant report, and
            # retrying identical answers would fail identically. Reason is operational only.
            logger.error("report %s refused before generation: %s", variant.version, reason)
            return _error_response(variant, attempts=0, code="insufficient_evidence")

    generate_started = time.perf_counter()

    messages_started = time.perf_counter()
    messages, payload = variant.prepare(profile)
    logger.info("prompt messages built in %.2fs", time.perf_counter() - messages_started)

    # `or`, not a getenv default, for every one of these: render_env.sh writes an empty line
    # for each key the CI does not set, so os.getenv(key, default) returns "" rather than the
    # default -- and int("") raises (known issue #24).
    primary_model = os.getenv("REPORT_PRIMARY_MODEL") or "gpt-5.4-mini"
    backup_model = os.getenv("REPORT_BACKUP_MODEL") or "gpt-5.4"
    # AvalAI is the last resort, after OpenAI has failed twice; it runs the full model, not the mini.
    avalai_model = os.getenv("REPORT_AVALAI_MODEL") or "gpt-5.4"
    max_primary_attempts = int(os.getenv("REPORT_MAX_PRIMARY_ATTEMPTS") or "2")

    # (provider, model) per attempt: primary on OpenAI (retried N times), then the
    # backup model on OpenAI, then the full model via AvalAI -- a different infra path in
    # case OpenAI itself (not the model) is the problem, so it gets the strongest model
    # rather than the cheaper backup.
    attempts = (
        [("openai", primary_model)] * max_primary_attempts
        + [("openai", backup_model), ("avalai", avalai_model)]
    )

    total_input_tokens = 0
    total_output_tokens = 0
    total_latency_s = 0.0
    attempts_made = 0

    for i, (provider, model) in enumerate(attempts, start=1):
        attempts_made = i
        attempt_started = time.perf_counter()
        try:
            # client_for is cached per provider (apps.ai.openai_client) -- no network call,
            # and reusing the connection pool avoids paying a cold TLS connect per attempt.
            call_client = client if client is not None else client_for(provider)

            raw, usage = _call_once(call_client, model, messages)
            total_input_tokens += usage.get("input_tokens", 0)
            total_output_tokens += usage.get("output_tokens", 0)
            total_latency_s += usage.get("latency_s", 0.0)

            output = variant.output_model.model_validate_json(_strip_fences(raw))

            if variant.cross_check is not None:
                cross = variant.cross_check(output, payload)
                if cross.errors:
                    raise _CrossCheckFailed("; ".join(cross.errors))

        except (json.JSONDecodeError, ValidationError, _CrossCheckFailed) as e:
            # Model produced something, but it was malformed, off-schema, or contradicted its
            # own input (v3 cross-check).
            # Usage was already added above -- this attempt still cost money.
            attempt_elapsed = time.perf_counter() - attempt_started
            AI_CALL_DURATION.labels(
                purpose="report_initial", call="report", provider=provider, outcome="validation_error",
            ).observe(attempt_elapsed)
            logger.warning("attempt %d/%d (%s via %s) failed validation after %.2fs: %s",
                           i, len(attempts), model, provider, attempt_elapsed, e)
            # Feed the mistake back in for the next attempt (even across a model/provider
            # switch, since each call is a stateless one-shot with no memory of prior
            # attempts) -- otherwise every attempt in the ladder repeats the identical
            # error, since they'd otherwise see the exact same prompt.
            messages = messages + [
                {"role": "assistant", "content": raw},
                {"role": "user", "content": (
                    "That response failed schema validation:\n"
                    f"{e}\n\n"
                    "Return the corrected, complete JSON only -- no explanation, no markdown "
                    "fences. Double-check every enum/Literal field uses one of its exact "
                    "allowed values and no others."
                )},
            ]
            continue

        except Exception as e:
            # Network / auth / rate limit / provider error -- including the client
            # itself failing to build (e.g. a missing API key for this provider).
            # Broad on purpose: any failure should fall through to the next attempt,
            # never crash the caller. No usage to add here -- the exception means no
            # response came back.
            attempt_elapsed = time.perf_counter() - attempt_started
            AI_CALL_DURATION.labels(
                purpose="report_initial", call="report", provider=provider, outcome="error",
            ).observe(attempt_elapsed)
            logger.warning("attempt %d/%d (%s via %s) call failed after %.2fs: %s: %s",
                           i, len(attempts), model, provider, attempt_elapsed,
                           type(e).__name__, e)
            continue

        # Success. Length deviations are logged, not fatal (see schema.soft_check).
        attempt_elapsed = time.perf_counter() - attempt_started
        AI_CALL_DURATION.labels(
            purpose="report_initial", call="report", provider=provider, outcome="ok",
        ).observe(attempt_elapsed)
        total_elapsed = time.perf_counter() - generate_started
        warnings = variant.soft_check(output)
        logger.info(
            "report generated: model=%s provider=%s attempt=%d attempt_elapsed=%.2fs "
            "total_elapsed=%.2fs usage=%s soft_warnings=%d",
            model, provider, i, attempt_elapsed, total_elapsed, usage, len(warnings),
        )

        return variant.response_model(
            status="ok",
            report=output.report,
            system=output.system,
            memory_candidates=variant.build_memory(output.report, output.system, payload),
            generation_meta=GenerationMeta(
                model_used=f"{model} ({provider})",
                attempts=attempts_made,
                input_tokens=total_input_tokens,
                output_tokens=total_output_tokens,
                latency_s=round(total_latency_s, 2),
            ),
        )

    total_elapsed = time.perf_counter() - generate_started
    logger.error("all %d attempts failed after %.2fs; returning generation_failed",
                 len(attempts), total_elapsed)
    return _error_response(
        variant,
        attempts=attempts_made,
        input_tokens=total_input_tokens,
        output_tokens=total_output_tokens,
        latency_s=round(total_latency_s, 2),
    )
