"""
schema_v3.py

Pydantic models and validation for the report_v3 output (docs/report_spec_v3_0.md; contract
source: `v3 help/V3_LLM_REFERENCE.md`). schema.py (v1) and schema_v2.py are untouched: stored
v1/v2 reports are still read everywhere, and both versions are still generatable.

Three tiers, on purpose:

  HARD   -- Pydantic rejects, the attempt ladder retries with the error fed back.
            Everything whose violation would break a consumer or the product contract:
            key/field presence, counts, enums, null rules, the source_map question grammar
            and its reuse cap, and (with the input at hand) `area` outside
            `context.allowed_finding_areas`.
  SOFT   -- logged, never rejected: word-count bands, forbidden vocabulary, punctuation and
            the house-style rules of the prompt. A 19-word `mirror.outer` instead of 18 is
            not worth a second paid generation.
  SOFT+  -- `check_against_input`'s evidence grounding: a `source_map` entry citing a question
            the user answered neutrally (so no evidence string for it was ever sent). This is
            deliberately NOT hard -- see EVIDENCE_GROUNDING_IS_HARD below.

The only published golden example that violates the evidence rule is golden 1 (`q20` in
`coin_2`), supplied that way by the product owner and preserved verbatim. That is exactly why
this check exists and why its severity is a single, documented switch.
"""

from __future__ import annotations

import logging
import re
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from apps.ai.report_generation.schema import (
    DeadlineType,
    MemoryCandidate,
    PatternTag,
    ReportResponse,
)

logger = logging.getLogger(__name__)

REPORT_VERSION_V3 = "report_v3"

FindingAreaV3 = Literal["work", "relationship", "decision", "stress"]

# The six source_map sections, in prompt order.
SOURCE_MAP_SECTIONS = (
    "hook_and_finding_1", "coin_1", "coin_2", "coin_3", "goal_card", "finding_2",
)
# <grounding_and_anti_repetition> rule 2.
MAX_SECTIONS_PER_QUESTION = 2
_QUESTION_ID_RE = re.compile(r"^q(?:[1-9]|1\d|2\d|30)$")

# Severity of the "cited question has no evidence in the input" rule. Soft today:
#   * the source_map is internal -- it never reaches a user, so a wrong citation breaks no UI;
#   * the product owner's own golden 1 does it, so the few-shot examples actively teach it,
#     and hard-failing would burn the whole paid retry ladder on a defect we shipped;
#   * the report text itself is still grounded by the hard rules plus the soft vocabulary
#     checks.
# Flip to True (one line, no other change) once golden 1 is corrected and the model has been
# observed to comply. Documented in docs/report_spec_v3_0.md section 6.3.
EVIDENCE_GROUNDING_IS_HARD = False


# --------------------------------------------------------------------------
# system block
# --------------------------------------------------------------------------

class SourceMapEntryV3(BaseModel):
    model_config = ConfigDict(extra="forbid")

    questions: list[str] = Field(min_length=2, max_length=4)
    theme: str = Field(min_length=1)

    @model_validator(mode="after")
    def _question_ids(self):
        bad = [q for q in self.questions if not _QUESTION_ID_RE.match(q)]
        if bad:
            raise ValueError(f"source_map questions must be q1..q30; got {bad}")
        if len(set(self.questions)) != len(self.questions):
            raise ValueError(f"source_map questions must be distinct within a section; got {self.questions}")
        return self


class SourceMapV3(BaseModel):
    model_config = ConfigDict(extra="forbid")

    hook_and_finding_1: SourceMapEntryV3
    coin_1: SourceMapEntryV3
    coin_2: SourceMapEntryV3
    coin_3: SourceMapEntryV3
    goal_card: SourceMapEntryV3
    finding_2: SourceMapEntryV3

    def entries(self) -> list[tuple[str, SourceMapEntryV3]]:
        return [(name, getattr(self, name)) for name in SOURCE_MAP_SECTIONS]

    @model_validator(mode="after")
    def _reuse_cap(self):
        counts: dict[str, int] = {}
        for _name, entry in self.entries():
            for question in entry.questions:
                counts[question] = counts.get(question, 0) + 1
        over = sorted(q for q, n in counts.items() if n > MAX_SECTIONS_PER_QUESTION)
        if over:
            raise ValueError(
                f"no question may appear in more than {MAX_SECTIONS_PER_QUESTION} source_map "
                f"sections; {over} do"
            )
        return self


class SystemV3(BaseModel):
    """v3's internal block. Richer than v1/v2's SystemBlock (which is pattern_tags only), so
    it is its own model rather than an extension of it. Never leaves the backend: stored in
    Report.system_data and excluded from every API response."""
    model_config = ConfigDict(extra="forbid")

    source_map: SourceMapV3
    pattern_tags: list[PatternTag] = Field(min_length=1, max_length=3)


# --------------------------------------------------------------------------
# report block
# --------------------------------------------------------------------------

class MirrorV3(BaseModel):
    model_config = ConfigDict(extra="forbid")

    outer: str = Field(min_length=1)
    inner: str = Field(min_length=1)
    blind_spot: str = Field(min_length=1)


class DimensionInsightsV3(BaseModel):
    """Exactly the five dimension keys -- required and no others (extra="forbid")."""
    model_config = ConfigDict(extra="forbid")

    emotional_stability: str = Field(min_length=1)
    extraversion: str = Field(min_length=1)
    openness: str = Field(min_length=1)
    agreeableness: str = Field(min_length=1)
    conscientiousness: str = Field(min_length=1)


class CoinV3(BaseModel):
    model_config = ConfigDict(extra="forbid")

    front_title: str = Field(min_length=1)
    front_text: str = Field(min_length=1)
    back_title: str = Field(min_length=1)
    back_text: str = Field(min_length=1)


class GoalCardV3(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str = Field(min_length=1)
    bottleneck_insight: str = Field(min_length=1)
    helps: list[str] = Field(min_length=2, max_length=2)
    hard: list[str] = Field(min_length=2, max_length=2)


class SuggestedStepV3(BaseModel):
    """Same shape as v1/v2's step (the action-steps row and the front-end card are shared),
    with substeps pinned to null exactly as the prompt requires."""
    model_config = ConfigDict(extra="forbid")

    text: str = Field(min_length=1)
    deadline_text: str = Field(min_length=1)
    deadline_type: DeadlineType
    substeps: None = None


class FindingV3(BaseModel):
    model_config = ConfigDict(extra="forbid")

    area: FindingAreaV3
    title: str = Field(min_length=1)
    what: str = Field(min_length=1)
    cost: str = Field(min_length=1)
    curiosity: str = Field(min_length=1)
    suggested_step: SuggestedStepV3 | None = None


class ExitV3(BaseModel):
    model_config = ConfigDict(extra="forbid")

    bridge: str = Field(min_length=1)
    root_question: str = Field(min_length=1)


class ReportV3(BaseModel):
    model_config = ConfigDict(extra="forbid")

    hook: str = Field(min_length=1)
    mirror: MirrorV3
    dimension_insights: DimensionInsightsV3
    coins: list[CoinV3] = Field(min_length=3, max_length=3)
    goal_card: GoalCardV3
    findings: list[FindingV3] = Field(min_length=2, max_length=2)
    exit: ExitV3

    @model_validator(mode="after")
    def _finding_rules(self):
        first, second = self.findings
        if first.area == second.area:
            raise ValueError("findings[0].area and findings[1].area must differ")
        if first.suggested_step is None:
            raise ValueError("findings[0].suggested_step is required")
        if second.suggested_step is not None:
            raise ValueError("findings[1].suggested_step must be null")
        return self


class AIOutputV3(BaseModel):
    """Exactly what the v3 model is asked to return: {"system": ..., "report": ...}."""
    model_config = ConfigDict(extra="forbid")

    system: SystemV3
    report: ReportV3


class ReportResponseV3(ReportResponse):
    report_version: str = REPORT_VERSION_V3
    report: ReportV3 | None = None  # type: ignore[assignment]
    system: SystemV3 | None = None  # type: ignore[assignment]


# --------------------------------------------------------------------------
# Input-dependent integrity checks
# --------------------------------------------------------------------------

class CrossCheckResult:
    """Outcome of comparing one model output against the exact payload it was given."""

    def __init__(self, errors: list[str], warnings: list[str]):
        self.errors = errors
        self.warnings = warnings

    def __bool__(self) -> bool:
        return not self.errors


def check_against_input(output: AIOutputV3, smart_payload: dict) -> CrossCheckResult:
    """Rules that only make sense with this user's payload in hand.

    HARD: a finding whose `area` is not in `context.allowed_finding_areas` (the goal card
    would then duplicate the finding's subject -- the one rule here with a user-visible
    effect).
    SOFT: a source_map entry citing a question with no evidence string in `profile`
    (answered neutrally, or absent). See EVIDENCE_GROUNDING_IS_HARD.
    """
    errors: list[str] = []
    warnings: list[str] = []

    allowed = list((smart_payload.get("context") or {}).get("allowed_finding_areas") or [])
    if allowed:
        for i, finding in enumerate(output.report.findings):
            if finding.area not in allowed:
                errors.append(
                    f"findings[{i}].area {finding.area!r} is not in context.allowed_finding_areas {allowed}"
                )

    evidence_ids = set()
    for block in (smart_payload.get("profile") or {}).values():
        for item in list(block.get("strong") or []) + list(block.get("moderate") or []):
            evidence_ids.add(item.split(":", 1)[0].strip())

    if evidence_ids:
        ungrounded = [
            f"{name}:{question}"
            for name, entry in output.system.source_map.entries()
            for question in entry.questions
            if question not in evidence_ids
        ]
        if ungrounded:
            message = (
                "source_map cites questions with no evidence in the input "
                f"(answered neutrally or absent): {ungrounded}"
            )
            (errors if EVIDENCE_GROUNDING_IS_HARD else warnings).append(message)

    for warning in warnings:
        logger.warning("soft validation (v3, grounding): %s", warning)
    return CrossCheckResult(errors, warnings)


# --------------------------------------------------------------------------
# Soft validation -- logged, never raises
# --------------------------------------------------------------------------

# (min, max) words per field, from the prompt's "Section Rules". None = unbounded.
_LENGTH_BANDS = {
    "hook": (8, 16),
    "mirror": (14, 25),
    "dimension_insight": (10, 18),
    "coin.front_title": (2, 5),
    "coin.front_text": (20, 30),
    "coin.back_title": (2, 5),
    "coin.back_text": (15, 25),
    "goal_card.title": (4, 10),
    "goal_card.bottleneck_insight": (18, 32),
    "goal_card.helps": (10, 18),
    "goal_card.hard": (10, 20),
    "finding.title": (3, 7),
    "finding.what": (35, 55),
    "finding.cost": (12, 22),
    "finding.curiosity": (25, 42),
    "exit.bridge": (8, 16),
    "exit.root_question": (22, 42),
    "suggested_step.text": (8, 30),
}

# Vocabulary the prompt forbids across ALL fields.
_FORBIDDEN = {
    "product": ["تست", "آزمون", "گزارش", "فرامن", "نسخه‌ی کامل", "سؤال", "گزینه", "امتیاز", "درصد", "نمودار"],
    "dimension": [
        "ثبات هیجانی", "برون‌گرایی", "گشودگی به تجربه", "توافق‌پذیری", "وظیفه‌شناسی",
        "انرژی اجتماعی", "ذهن رشدگرا", "همدلی و همکاری",
    ],
    "certainty": [
        "همیشه", "هیچ‌وقت", "هرگز", "قطعاً", "صددرصد", "بیشتر از همه", "کمتر از بقیه",
        "برخلاف اکثر آدم‌ها",
    ],
    "clinical": [
        "افسردگی", "اضطراب", "وسواس", "اختلال", "کمال‌گرایی", "کمال‌گرا", "نشخوار فکری",
        "فرسودگی", "تروما", "دوقطبی", "بیش‌فعالی", "کودک درون", "مبتلا", "علائم", "تشخیص",
        "بیمار",
    ],
    # safety_rules 1 and 5: labelling the person, and shaming vocabulary.
    "labelling": ["ذاتاً", "ضعف", "نقص", "عیب", "مشکل", "باید", "چرا نکردی", "متأسفانه"],
}
# Single words are matched as whole tokens, multi-word phrases as substrings. Token matching
# keeps ZWNJ inside the token on purpose: «بی‌نقص‌تر» («more flawless») is one token and must
# not be reported as the shaming word «نقص», and «گزینه‌ها» («the options») is not the product
# word «گزینه». A looser substring match produced exactly those two false positives on the
# golden examples.
_TOKEN_SPLIT_RE = re.compile(r"[^\w\u200c]+", re.UNICODE)
_DIGIT_RE = re.compile(r"[0-9۰-۹]")
# <persian_style_and_constraints>: no kasre/ezafe diacritic, no semicolon, no em-dash.
_FORBIDDEN_PUNCTUATION = {"ِ": "kasre/ezafe diacritic", "؛": "semicolon", "—": "em-dash"}
# safety_rules 3: stacked hedges.
_DOUBLE_HEDGES = ["ممکن است گاهی", "معمولاً اغلب", "شاید گاهی", "گاهی ممکن است"]
# safety_rules 7: no meta-disclaimers.
_DISCLAIMER_PHRASES = ["بر اساس پاسخ", "نادیده‌اش بگیر", "نادیده بگیر"]
# A half-space (ZWNJ) typed as a plain space -- same heuristic as v2.
_MISSING_ZWNJ_RE = re.compile(r"(?:^|\s)می\s+\S|\s+ها(?:ی\S*)?(?:\s|$)")
# exit.bridge rule 7.
_BRIDGE_FORBIDDEN = ["شاید", "ریشه", "ربط", "این دو یافته"]


def _words(text: str) -> int:
    return len(text.split())


def _contains_forbidden(text: str, word: str) -> bool:
    if " " in word:
        return word in text
    return word in {token for token in _TOKEN_SPLIT_RE.split(text) if token}


def generated_texts(report: ReportV3) -> dict[str, str]:
    """Every model-written string of the report, keyed for log messages."""
    texts = {
        "hook": report.hook,
        "mirror.outer": report.mirror.outer,
        "mirror.inner": report.mirror.inner,
        "mirror.blind_spot": report.mirror.blind_spot,
        "goal_card.title": report.goal_card.title,
        "goal_card.bottleneck_insight": report.goal_card.bottleneck_insight,
        "exit.bridge": report.exit.bridge,
        "exit.root_question": report.exit.root_question,
    }
    for key, text in report.dimension_insights.model_dump().items():
        texts[f"dimension_insights.{key}"] = text
    for i, coin in enumerate(report.coins):
        texts[f"coins[{i}].front_title"] = coin.front_title
        texts[f"coins[{i}].front_text"] = coin.front_text
        texts[f"coins[{i}].back_title"] = coin.back_title
        texts[f"coins[{i}].back_text"] = coin.back_text
    for i, item in enumerate(report.goal_card.helps):
        texts[f"goal_card.helps[{i}]"] = item
    for i, item in enumerate(report.goal_card.hard):
        texts[f"goal_card.hard[{i}]"] = item
    for i, finding in enumerate(report.findings):
        texts[f"findings[{i}].title"] = finding.title
        texts[f"findings[{i}].what"] = finding.what
        texts[f"findings[{i}].cost"] = finding.cost
        texts[f"findings[{i}].curiosity"] = finding.curiosity
        if finding.suggested_step is not None:
            texts[f"findings[{i}].suggested_step.text"] = finding.suggested_step.text
    return texts


def soft_check_v3(output: AIOutputV3) -> list[str]:
    """Word bands, forbidden vocabulary and house style. Warns, never raises."""
    warnings: list[str] = []
    report = output.report

    def band(label: str, text: str, key: str):
        low, high = _LENGTH_BANDS[key]
        n = _words(text)
        if (low is not None and n < low) or (high is not None and n > high):
            warnings.append(f"{label} is {n} words (expected {low or 0}-{high or 'any'})")

    band("hook", report.hook, "hook")
    for part in ("outer", "inner", "blind_spot"):
        band(f"mirror.{part}", getattr(report.mirror, part), "mirror")
    for key, text in report.dimension_insights.model_dump().items():
        band(f"dimension_insights.{key}", text, "dimension_insight")
    for i, coin in enumerate(report.coins):
        band(f"coins[{i}].front_title", coin.front_title, "coin.front_title")
        band(f"coins[{i}].front_text", coin.front_text, "coin.front_text")
        band(f"coins[{i}].back_title", coin.back_title, "coin.back_title")
        band(f"coins[{i}].back_text", coin.back_text, "coin.back_text")
    band("goal_card.title", report.goal_card.title, "goal_card.title")
    band("goal_card.bottleneck_insight", report.goal_card.bottleneck_insight, "goal_card.bottleneck_insight")
    for i, item in enumerate(report.goal_card.helps):
        band(f"goal_card.helps[{i}]", item, "goal_card.helps")
    for i, item in enumerate(report.goal_card.hard):
        band(f"goal_card.hard[{i}]", item, "goal_card.hard")
    for i, finding in enumerate(report.findings):
        band(f"findings[{i}].title", finding.title, "finding.title")
        band(f"findings[{i}].what", finding.what, "finding.what")
        band(f"findings[{i}].cost", finding.cost, "finding.cost")
        band(f"findings[{i}].curiosity", finding.curiosity, "finding.curiosity")
    band("exit.bridge", report.exit.bridge, "exit.bridge")
    band("exit.root_question", report.exit.root_question, "exit.root_question")
    step = report.findings[0].suggested_step
    if step is not None:
        band("findings[0].suggested_step.text", step.text, "suggested_step.text")

    # Section rule 5: «برای...» opening, and both `hard` items opening with «وقتی».
    if not report.goal_card.title.lstrip().startswith("برای"):
        warnings.append("goal_card.title must start with «برای»")
    for i, item in enumerate(report.goal_card.hard):
        if not item.lstrip().startswith("وقتی"):
            warnings.append(f"goal_card.hard[{i}] must start with «وقتی»")
    for word in _BRIDGE_FORBIDDEN:
        if word in report.exit.bridge:
            warnings.append(f"exit.bridge contains forbidden word {word!r}")

    for label, text in generated_texts(report).items():
        for category, words in _FORBIDDEN.items():
            for word in words:
                if _contains_forbidden(text, word):
                    warnings.append(f"{label} contains forbidden {category} word {word!r}")
        if _DIGIT_RE.search(text):
            warnings.append(f"{label} contains a digit")
        for mark, name in _FORBIDDEN_PUNCTUATION.items():
            if mark in text:
                warnings.append(f"{label} contains a forbidden {name}")
        for phrase in _DOUBLE_HEDGES:
            if phrase in text:
                warnings.append(f"{label} stacks hedges ({phrase!r})")
        for phrase in _DISCLAIMER_PHRASES:
            if phrase in text:
                warnings.append(f"{label} contains a disclaimer phrase {phrase!r}")
        if _MISSING_ZWNJ_RE.search(text):
            warnings.append(f"{label} has a plain space where a half-space (ZWNJ) belongs")

    for warning in warnings:
        logger.warning("soft validation (v3): %s", warning)
    return warnings


__all__ = [
    "AIOutputV3",
    "CrossCheckResult",
    "EVIDENCE_GROUNDING_IS_HARD",
    "FindingV3",
    "MAX_SECTIONS_PER_QUESTION",
    "MemoryCandidate",
    "REPORT_VERSION_V3",
    "ReportResponseV3",
    "ReportV3",
    "SOURCE_MAP_SECTIONS",
    "SourceMapV3",
    "SystemV3",
    "check_against_input",
    "generated_texts",
    "soft_check_v3",
]
