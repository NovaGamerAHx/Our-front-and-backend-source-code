"""
profile_input.py

Pydantic model for the AI report pipeline's input, per report_spec_v1.3 section 3.

Deliberately small. ScoringService computes the scores and ReportService sends
dimension_scores, so this module never sees raw test answers -- there is no conversion
function to write. And because a report is only generated when all scored answers exist
(ScoringService.is_complete), there is no incomplete-input state to handle either.

This is an anti-corruption layer: it validates what AiReportClient builds before anything
reaches the prompt, so a malformed payload fails here with a clear error rather than
producing a subtly wrong report.

LifeSituation / CurrentGoal are aligned to the real DB choices (apps.account.models.User
.LifeSituation / .Goal) -- not the placeholder values the AI prototype originally shipped
with, since the database owns these enums.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from apps.ai.report_generation.schema import DimensionKey, EXPECTED_DIMENSION_KEYS

Level = Literal["very_low", "low", "medium", "medium_high", "high"]

LifeSituation = Literal[
    "student", "employed", "self_employed",
    "job_seeking", "transitioning", "family_care", "other",
]

CurrentGoal = Literal[
    "decisions", "mastery", "growth", "relationships",
    "purpose", "self_regard", "stress", "unsure",
]


class DimensionScore(BaseModel):
    key: DimensionKey
    score_percent: int = Field(ge=0, le=100)
    level: Level


class ContextProfile(BaseModel):
    """Optional demographic block (spec 3.5). Every field may be absent.

    extra="forbid" is load-bearing here, not stylistic: `gender` must never reach this
    service (spec 3.5, rule 1 -- AiReportClient filters it out). If it ever slips into the
    payload, this raises immediately instead of quietly passing it to the model.
    """
    model_config = ConfigDict(extra="forbid")

    age: str | None = None
    life_situation: LifeSituation | None = None
    current_goal: CurrentGoal | None = None


class ProfileInput(BaseModel):
    dimension_scores: list[DimensionScore] = Field(min_length=5, max_length=5)
    context_profile: ContextProfile | None = None

    @field_validator("dimension_scores")
    @classmethod
    def _all_five_dimensions_present(cls, v: list[DimensionScore]):
        # Catches duplicates -- five items whose Literal types are all valid can still
        # be the same dimension repeated, with another one missing.
        keys = {d.key for d in v}
        if keys != EXPECTED_DIMENSION_KEYS:
            missing = EXPECTED_DIMENSION_KEYS - keys
            raise ValueError(f"dimension_scores must cover all 5 dimensions; missing: {missing}")
        return v

    def to_prompt_payload(self) -> tuple[list[dict], dict | None]:
        """Shape for report_prompt.build_messages(dimension_scores, context_profile).

        context_profile is returned only if it has at least one non-null field --
        an empty block adds tokens and tells the model nothing.
        """
        scores = [d.model_dump() for d in self.dimension_scores]
        ctx = None
        if self.context_profile:
            filled = {k: v for k, v in self.context_profile.model_dump().items() if v is not None}
            ctx = filled or None
        return scores, ctx
