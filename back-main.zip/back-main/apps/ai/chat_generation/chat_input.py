"""Pydantic model for the chat generation service's input, per chat_spec_v2 sections 1 and
6.1 -- mirrors apps.ai.report_generation.profile_input.ProfileInput's role for reports.

This is an anti-corruption layer: a malformed payload fails here with a clear error instead
of reaching the prompt and producing a subtly wrong conversation. Most of the rules below
guard against the same failure mode -- a request that looks valid but makes the model talk
about the wrong thing, with no error anywhere.

CHANGED FROM v1:
- action_preview:rec_<n> removed; the first step is now built inside the report
- last_checkin removed; the login card no longer exists
- report_type and focus_section added

CHANGED (this revision):
- context_action replaced by action_context: current (the step under discussion) plus
  recent (the last three steps with their status), matching how the person's step history
  now reaches the model.
- Steps left memory entirely -- action_outcome is gone from MemoryRow.memory_type. Outcomes
  arrive in action_context.recent instead, capped by the field itself rather than by a
  separate validator.
- action_active added: the person comes back to talk about a step they already accepted,
  before its deadline -- unlike the other three action entry sources, the goal here is not a
  new step.
"""

from __future__ import annotations

import re
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

HISTORY_LIMIT = 30
RECENT_STEPS_LIMIT = 3

# Entry sources that carry a step instead of a report.
ACTION_ENTRY_SOURCES = frozenset(
    {"action_rejected", "action_active", "action_missed", "action_completed"}
)

# Entry sources that carry a report.
REPORT_ENTRY_SOURCES = frozenset({"report_cta", "report_open_question", "deep_report_cta"})

DEEP_SECTIONS = frozenset({
    "domain_N", "domain_E", "domain_O", "domain_A", "domain_C",
    "strengths", "blind_spots",
    "decision_style", "communication_style", "work_style",
    "stress_and_energy", "learning_and_growth", "close_relationships",
})

_ENTRY_RE = re.compile(
    r"^(report_cta|report_open_question|manual|deep_report_cta|report_finding_focus:[01]"
    r"|deep_report_focus:[a-z_]+(?:_[A-Z])?"
    r"|action_rejected|action_active|action_missed|action_completed)$"
)


class Message(BaseModel):
    role: Literal["user", "assistant"]
    content: str


class MemoryRow(BaseModel):
    """One row of current memory.

    extra="forbid" is load-bearing: confidence and sensitivity_level are stored in the
    database but must never reach this service. Nothing in the prompt depends on them, and
    for strength/growth_edge they are placeholder values -- if they slipped in, someone
    downstream would eventually treat them as real.
    """

    model_config = ConfigDict(extra="forbid")

    memory_type: Literal["core_pattern", "strength", "growth_edge", "growth_focus"]
    text_memory: str
    source: str


class ActionStepRow(BaseModel):
    """One step, as sent to the model -- either the one under discussion (`current`) or one
    of the last three (`recent`).

    No id: the model never returns one, because every step it produces is new. Rejection is
    only possible before accepting, so a rejected step was never written to action_steps.
    """

    text: str
    deadline_text: str | None = None
    deadline_type: Literal[
        "tonight", "tomorrow_morning", "tomorrow_evening", "within_24h"
    ] | None = None
    source: str | None = None
    # Absent for a rejected step -- it was never recorded, so it has no status.
    status: Literal["pending", "done", "partial", "not_done"] | None = None
    reflection: str | None = None
    obstacle: str | None = None


class ActionContext(BaseModel):
    """The person's steps.

    `recent` is always sent -- the last three rows of action_steps, unfiltered, so the model
    knows what this person currently has on their plate and how earlier steps went.

    `current` marks which step the conversation is about, and is present only for the three
    action entry sources.
    """

    current: ActionStepRow | None = None
    recent: list[ActionStepRow] = Field(default_factory=list, max_length=RECENT_STEPS_LIMIT)


class ChatRequest(BaseModel):
    session_id: str
    entry_source: str
    user_message: str
    history: list[Message] = Field(default_factory=list, max_length=HISTORY_LIMIT)
    user_memory: list[MemoryRow] = Field(default_factory=list)
    report_type: Literal["initial", "deep"] | None = None
    # chat_spec_v3_1 §1.3: which shape `report` has. Initial reports only -- the deep report has
    # one shape. Selects the renderer in the prompt.
    report_version: Literal["report_v1", "report_v2"] | None = None
    report: dict | None = None
    focus_section: str | None = None
    # report_finding_focus:<n> only -- which of the report_v2 findings the person came from.
    focus_finding: Literal[0, 1] | None = None
    action_context: ActionContext = Field(default_factory=ActionContext)

    @field_validator("entry_source")
    @classmethod
    def _known_entry_source(cls, v: str) -> str:
        if not _ENTRY_RE.match(v):
            raise ValueError(f"unknown entry_source: {v!r}")
        if v.startswith("deep_report_focus:"):
            section = v.split(":", 1)[1]
            if section not in DEEP_SECTIONS:
                raise ValueError(
                    f"unknown deep report section {section!r}; "
                    f"must be one of the 13 keys in deep_report_spec"
                )
        return v

    @model_validator(mode="after")
    def _report_matches_entry_source(self):
        """A report is required for report entry sources and forbidden for action ones.

        Sending both a report and a step is not a harmless extra: it doubles the prompt and
        leaves the model to decide which one the conversation is about.
        """
        needs_report = (
            self.entry_source in REPORT_ENTRY_SOURCES
            or self.entry_source.startswith(("deep_report_focus:", "report_finding_focus:"))
        )
        if needs_report and self.report is None:
            raise ValueError(f"{self.entry_source} requires a report")
        if self.entry_source in ACTION_ENTRY_SOURCES and self.report is not None:
            raise ValueError(
                f"{self.entry_source} must not carry a report; memory plus action_context "
                f"is the whole context"
            )
        if self.report is not None and self.report_type is None:
            raise ValueError("report_type is required whenever report is sent")

        expected = "deep" if self.entry_source.startswith("deep_report") else "initial"
        if self.report is not None and self.report_type != expected:
            raise ValueError(
                f"report_type={self.report_type!r} does not match "
                f"entry_source={self.entry_source!r} (expected {expected!r})"
            )
        return self

    @model_validator(mode="after")
    def _report_version_matches_report_type(self):
        """chat_spec_v3_1 §6.1. The version picks which renderer reads `report`; a missing or
        misplaced one would render a v2 report with the v1 template (or the reverse) and look
        like nothing worse than a strangely thin prompt."""
        if self.report_type == "initial" and self.report_version is None and self.report is not None:
            raise ValueError("report_version is required for an initial report")
        if self.report_version is not None and self.report_type != "initial":
            raise ValueError("report_version belongs only to report_type='initial'")
        if self.entry_source == "report_open_question" and self.report_version != "report_v2":
            raise ValueError(
                "report_open_question requires report_version='report_v2': a v1 report has no open question"
            )
        if self.entry_source.startswith("report_finding_focus:") and self.report_version != "report_v2":
            raise ValueError(
                "report_finding_focus requires report_version='report_v2': a v1 report has no findings"
            )
        return self

    @model_validator(mode="after")
    def _focus_finding_matches_entry_source(self):
        is_finding = self.entry_source.startswith("report_finding_focus:")
        if is_finding and self.focus_finding is None:
            raise ValueError("report_finding_focus entry requires focus_finding")
        if self.focus_finding is not None and not is_finding:
            raise ValueError(
                f"focus_finding was sent with entry_source={self.entry_source!r}; "
                f"it belongs only to report_finding_focus:*"
            )
        if is_finding and self.focus_finding != int(self.entry_source.split(":", 1)[1]):
            raise ValueError("focus_finding must match the index in entry_source")
        return self

    @model_validator(mode="after")
    def _focus_section_matches_entry_source(self):
        is_focus = self.entry_source.startswith("deep_report_focus:")
        if is_focus and not self.focus_section:
            raise ValueError("deep_report_focus entry requires focus_section")
        if self.focus_section and not is_focus:
            raise ValueError(
                f"focus_section was sent with entry_source={self.entry_source!r}; "
                f"it belongs only to deep_report_focus:*"
            )
        if is_focus and self.focus_section != self.entry_source.split(":", 1)[1]:
            raise ValueError("focus_section must match the section in entry_source")
        return self

    @model_validator(mode="after")
    def _current_matches_entry_source(self):
        current = self.action_context.current
        if self.entry_source in ACTION_ENTRY_SOURCES and current is None:
            raise ValueError(f"{self.entry_source} requires action_context.current")
        if current is not None and self.entry_source not in ACTION_ENTRY_SOURCES:
            raise ValueError(
                f"action_context.current was sent with entry_source={self.entry_source!r}; "
                f"it belongs only to {sorted(ACTION_ENTRY_SOURCES)}"
            )
        if current is None:
            return self

        # A missed step must actually be missed. Getting this wrong would have the model
        # commiserate about a step the person completed, or congratulate a failure.
        if self.entry_source == "action_missed" and current.status not in {"not_done", "partial"}:
            raise ValueError(
                f"action_missed requires status not_done or partial; got {current.status!r}"
            )
        # A rejected step was never written to action_steps, so it has no recorded outcome.
        if self.entry_source == "action_rejected" and (current.status or current.obstacle):
            raise ValueError(
                "a rejected step has no status or obstacle: rejection happens before the "
                "step is ever recorded"
            )
        if self.entry_source == "action_completed" and current.status != "done":
            raise ValueError(
                f"action_completed requires status done; got {current.status!r}"
            )
        # An active step has been accepted but its deadline has not passed.
        if self.entry_source == "action_active" and current.status != "pending":
            raise ValueError(
                f"action_active requires status pending; got {current.status!r}"
            )
        return self

    @property
    def is_action_entry(self) -> bool:
        return self.entry_source in ACTION_ENTRY_SOURCES
