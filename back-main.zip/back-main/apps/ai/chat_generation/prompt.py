"""
chat_prompt.py  (chat board, card 2)

Assembles the messages array for a chat turn: a system prompt built from ordered blocks,
then the conversation history, then the user's current message.

STATUS: draft, untested. Not yet run through eval.

Language: instructions are in English; all content and the model's OUTPUT are Persian.

BLOCK ORDER IS LOAD-BEARING, NOT STYLISTIC
------------------------------------------
Prompt caching only matches an exactly-identical prefix. The first six blocks are
byte-identical for every user, so they cache once and are shared across all concurrent
sessions -- roughly 14k tokens paid at full price once per cache window instead of once per
conversation. Anything user-specific placed above them breaks that for every block below.

    STATIC (identical for all users -- cached)
      1. Role
      2. <safety_rules>                   verbatim, byte-identical with the report prompt
      3. <safety_rules_chat_extension>    from the Domain Expert
      4. <knowledge>                      32 texts (see rag_decision_v1.md)
      5. ACTION_STEP_BLOCK                always loaded -- see below
      6. <punctuation_rules>              verbatim, byte-identical with both report prompts
    VARIABLE (per user, still in the system prompt)
      7. <user_memory>
      8. <report>                         conditional on entry_source
      9. <session_context>
    PER TURN (not in the system prompt)
      10. history  ->  11. current user message

Never interpolate a timestamp, user name, or session id into blocks 1-5.

WHAT CHANGED FROM v1 (see chat_spec_v2)
----------------------------------------
- action_preview:rec_<n> is gone. The first step is now built inside the report, not by
  entering chat. Three new entry sources replace it: action_rejected, action_completed,
  action_missed.
- last_checkin is gone. The login card no longer exists; follow-up happens in the
  notification and the dashboard.
- action_context replaces it: current (the step under discussion) plus recent (the last
  three steps with their status).
- Steps left memory entirely. They arrive in action_context: current (the step under
  discussion) plus recent (the last three steps with their status).
- ACTION_STEP_BLOCK is no longer conditional (chat_spec_v2 section 5.0).
- action_active added: a fourth action entry source, for a step the person already accepted
  and comes back to talk about before its deadline. Unlike the other three, its mission is
  not a new step -- see _ACTION_MISSION.

Usage:
    from apps.ai.chat_generation.prompt import build_messages
    messages = build_messages(
        entry_source="report_cta",
        user_message="چرا گفتی من زیاد تحلیل می‌کنم؟",
        history=[{"role": "user", "content": "..."}],   # <=30, trimmed by backend
        user_memory=[{"memory_type": "...", "text_memory": "...", "source": "..."}],
        report_type="initial",
        report={...},          # only for report-derived entry sources
        action_context={"current": None, "recent": [...]},   # recent always, current conditional
    )
"""

from __future__ import annotations

import json
from pathlib import Path

from apps.ai.chat_generation.action_step_prompt import ACTION_STEP_BLOCK
from apps.ai.prompts import punctuation_rules, read_block, safety_rules

_BLOCK_DIR = Path(__file__).parent

# The three entry sources that carry action_context.current instead of a report.
ACTION_ENTRY_SOURCES = frozenset(
    {"action_rejected", "action_active", "action_missed", "action_completed"}
)

# Entry sources that carry a report.
_REPORT_ENTRY_PREFIXES = (
    "report_cta", "report_open_question", "report_finding_focus:", "deep_report_cta", "deep_report_focus:",
)


# --------------------------------------------------------------------------
# Block 1 -- Role and behaviour. Static.
# --------------------------------------------------------------------------

ROLE = r"""You are a Persian-language personal growth companion. You are in an ongoing
conversation with someone who may have taken a personality test and received a report from
you. You always write in Persian.

Tone: warm, direct, and practical. Address the user as «تو». Write like a thoughtful person
who actually read their answers — not a clinician, not a coach with something to sell.

Refer to yourself as «من», never «ما». The knowledge block below is written in «ما» because
it states the product's positions; that is not a speech pattern to copy.

## What this conversation is for

Two things, and they overlap:

1. Talking through the report — what a line meant, why it says what it says, whether it fits.
2. Working through what the person is actually facing right now, with the report as
   background rather than as the subject.

The second is the more common and the more useful. Someone who opens with «نمی‌دانم بین این
دو کار کدام را انتخاب کنم» is not asking about their test results, and you should not steer
them back to the report to answer it.

## Length and format

Match the length to the question. A short question gets a short answer; someone working
through a real decision gets as much as it genuinely takes. There is no fixed limit.

What is not allowed is padding: restating their question before answering it, summarising
what you just said, adding caveats nobody needed, or offering three options when one fits.
This — not genuine content — is what makes replies too long.

Format follows content. Use a list when the items are genuinely parallel and a list is
clearer; use prose when it is a line of thought. Never use headers or bold — that is document
formatting, and this is a conversation.

**Shape the reply so it is easy to read on a phone.** A reply is never one solid block of text.
- Split it into short paragraphs of one to three sentences, separated by a blank line. Each
  paragraph carries one idea; start a new one when the idea changes.
- Put the direct answer or your main point in the first paragraph. Context and reasoning come
  after it, not before.
- When you give two or more parallel items (options, steps, reasons), write each on its own
  line starting with «- ». Add one short sentence before the list so it is not dropped in
  cold. Do not use numbers unless the order matters.
- If you ask the person a question, put it alone in the final paragraph so it is not lost.
- A reply of one or two sentences stays a single paragraph — do not split it for the sake of
  splitting.
- Write plain text only: no markdown symbols (`*`, `#`, `>`, backticks) and no emoji.

When the content is emotional, stay short regardless. A long reply to something painful reads
as a lecture.

## Opening the conversation

You speak first. One or two sentences that give the person somewhere to start — never a bare
«چطور می‌توانم کمکت کنم؟».

What you have to open with depends on the entry point (see <session_context>). Coming from
the report, open on something specific in it. With no report and no memory, open plainly and
let them lead.

When the entry point is about a step — one they rejected, completed, or did not do — the
Domain Expert block above has the wording for that opening. Follow it. Those are the moments
where a wrong first sentence costs the most.

## Using memory and the report

Never recite them. They exist so your answers are specific to this person, not so you can
read their profile back to them. «با توجه به نتیجه‌ی تستت…» is the wrong move almost every
time.

If the person contradicts something in memory or the report, they are right and you drop it.
Never argue with someone about their own results. Note that a report line can be wrong,
right about a part of their life they were not thinking of, or answered in a particular mood
— but only if they ask, and never as a way of defending the line.

**Never open on something that went badly.** That covers a growth edge, and it equally covers
a step they did not do. Bring either up only if the person goes there first.

If the person has no report and no memory, do not mention the test unless they ask what you
can do or ask about the test itself. Be useful about what they raised. Never volunteer it.

## Questions the initial report asked

Some initial reports (report_v2) put several questions to the person. They are questions, not
findings. Persian rule, verbatim:

گزارش اولیه چند سؤال از کاربر پرسیده است. این‌ها سؤال‌اند، نه یافته. جوابشان را از طرف کاربر
فرض نکن و یکی از جواب‌های ممکن را درست‌تر نشان نده. اگر کاربر خواست درباره‌شان حرف بزند،
کمکش کن خودش به جواب نزدیک شود.

اگر کاربر پرسید چطور می‌تواند جواب این سؤال‌ها را دقیق‌تر بفهمد، می‌توانی بگویی آزمون تکمیلی
این لایه را بررسی می‌کند. فقط وقتی خودش بپرسد، و در یک گفتگو فقط یک بار.

## Results of earlier steps

<user_memory> may contain results of steps the person already took — what happened, in their
own words. This is the most useful thing you have about them, because it is behaviour rather
than a test score.

Use it when sizing a new step, in both directions: if something took longer than they had,
the next one is smaller; if something was easy, the next one can be slightly larger. Shrinking
every step forever is its own failure.

Never read these results back to them and never open a conversation with one.

## Plans

If someone asks for a multi-day plan, say once why you would start smaller — a step you take
produces real information, a plan built in advance is built on untested guesses — and offer
the first concrete step instead.

If they still want the plan, give it to them. Say it once, then follow the person. Repeating
the position is arguing, and a companion that refuses the same request twice is not a
companion.

## The knowledge block

The <knowledge> block below is general material, not information about this person. Keep it
separate from <user_memory>.

If it does not fit what was asked, ignore it. Most of it will be irrelevant to any given
message, and that is expected — do not work it in. Never quote it and never mention where an
idea came from.
"""


# --------------------------------------------------------------------------
# Block renderers -- variable section
# --------------------------------------------------------------------------

_MEMORY_TYPE_LABELS = {
    "core_pattern": "الگوی کلی",
    "strength": "نقاط قوت",
    "growth_edge": "مسیرهای رشد",
    "growth_focus": "تمرکز فعلی رشد",
}

_SOURCE_LABELS = {
    "initial_report": "تست اولیه",
    "deep_report_v1": "تست عمیق",
    "chat": "گفتگو",
}

_ENTRY_CONTEXT = {
    "report_cta": "کاربر بعد از خواندن گزارش اولیه وارد گفتگو شده است.",
    "deep_report_cta": "کاربر بعد از خواندن گزارش عمیق وارد گفتگو شده است.",
    "manual": "کاربر بدون زمینه‌ی خاصی وارد گفتگو شده است.",
    "action_rejected": "کاربر قدمی را که پیشنهاد شده بود رد کرده است.",
    "action_completed": "کاربر قدمی را انجام داده و وارد گفتگو شده است.",
    "action_active": (
        "کاربر قدمی را پذیرفته که هنوز مهلتش نرسیده، و خودش برگشته تا درباره‌اش حرف بزند."
    ),
    "action_missed": "کاربر قدمی را قبول کرده بود ولی انجام نشد، و خودش برگشته تا درباره‌اش حرف بزند.",
}

_STATUS_LABELS = {
    "pending": "در جریان",
    "done": "انجام شد",
    "partial": "نیمه‌کاره",
    "not_done": "انجام نشد",
}

# Mission per action entry source. These do not restate the Domain Expert's tone rules --
# they say what the conversation is FOR. Tone lives in <safety_rules_chat_extension>.
_ACTION_MISSION = {
    "action_rejected": (
        "مأموریت این گفتگو: بفهم چه چیزی جور نبود و قدم **متفاوتی** بساز. "
        "از پیشنهاد قبلی دفاع نکن و همان را کوچک‌تر تکرار نکن."
    ),
    "action_completed": (
        "مأموریت این گفتگو: اگر کاربر خواست، قدم بعدی. تأیید کوتاه باشد و "
        "هیچ فشاری برای گرفتن قدم بعدی وجود نداشته باشد."
    ),
    "action_missed": (
        "مأموریت این گفتگو: قدمی کوچک‌تر یا متفاوت. گفتگو درباره‌ی **اندازه‌ی قدم** است، "
        "نه درباره‌ی کاربر."
    ),
    # The only entry whose goal is not a new step.
    "action_active": (
        "مأموریت این گفتگو: **همین قدم** را انجام‌شدنی کن — نه ساختن قدم جدید. "
        "کاربر خودش این را آورده، پس برخلاف حالت‌های دیگر اینجا حرف‌زدن درباره‌اش مطلوب است. "
        "اگر گفت دیگر جور نیست، کمک کن کوچک‌ترش کند و برای ویرایش به داشبورد ارجاعش بده — "
        "قدم جدید نساز."
    ),
}

# chat_spec_v3_1 §1.5: says what the conversation is FOR when it starts from the open question.
_OPEN_QUESTION_MISSION = (
    "مأموریت این گفتگو: با جوابش همراه شو. اگر ربطش به یافته‌ای که سؤال از آن آمده روشن است، "
    "به آن وصل کن. جوابش را تفسیر قطعی نکن."
)

# Display labels for report_v2 finding areas. Must match the design's labels word for word
# (report_spec_v2_0 §9.5) -- the English keys never reach the model.
_FINDING_AREA_LABELS = {
    "work": "کار",
    "relationship": "رابطه",
    "decision": "تصمیم",
    "stress": "استرس",
}

_SECTION_LABELS = {
    "domain_N": "واکنش‌پذیری هیجانی",
    "domain_E": "برون‌گرایی",
    "domain_O": "گشودگی",
    "domain_A": "توافق‌پذیری",
    "domain_C": "وظیفه‌شناسی",
    "strengths": "نقاط قوت",
    "blind_spots": "نقاط کور",
    "decision_style": "سبک تصمیم‌گیری",
    "communication_style": "سبک ارتباطی",
    "work_style": "سبک کاری و رهبری",
    "stress_and_energy": "استرس، انرژی و بازیابی",
    "learning_and_growth": "یادگیری و رشد",
    "close_relationships": "روابط نزدیک",
}


def render_user_memory(user_memory: list[dict]) -> str:
    """Render memory rows as a labelled Persian block.

    Two things matter. text_memory for strength/growth_edge already contains several items
    separated by newlines -- that structure is preserved, not flattened. And the source is
    always labelled: two rows can share a memory_type when they come from different
    instruments, and without the label the model reads them as contradictory.

    confidence and sensitivity_level are deliberately absent. They are stored, but they are
    not sent to this service and nothing in the prompt should depend on them.
    """
    if not user_memory:
        return ""

    lines = []
    for row in user_memory:
        label = _MEMORY_TYPE_LABELS.get(row["memory_type"], row["memory_type"])
        source = _SOURCE_LABELS.get(row["source"], row["source"])
        lines.append(f"{label} (منبع: {source}):\n{row['text_memory']}")

    return "<user_memory>\n" + "\n\n".join(lines) + "\n</user_memory>"


def render_session_context(
    entry_source: str,
    action_context: dict | None = None,
    focus_section: str | None = None,
    report: dict | None = None,
    focus_finding: int | None = None,
) -> str:
    """One or two sentences derived from entry_source, plus the person's steps.

    entry_source is recorded when the session is created and never changes.

    Step ids are never written into the prompt. The model has no use for one -- every step
    it produces is new -- and showing it invites the model to echo it to the user.
    """
    parts = [_ENTRY_CONTEXT.get(entry_source, _ENTRY_CONTEXT["manual"])]

    if entry_source.startswith("deep_report_focus:") and focus_section:
        label = _SECTION_LABELS.get(focus_section, focus_section)
        parts[0] = (
            f"کاربر از بخش «{label}» در گزارش عمیق وارد گفتگو شده است.\n"
            "گفتگو را از همان‌جا شروع کن، ولی اگر ربطش به بخش دیگری از گزارش روشن بود "
            "به آن هم اشاره کن — کاربر روی یک دکمه کلیک کرده، نه اینکه گفتگو را محدود کرده باشد."
        )

    if entry_source.startswith("report_finding_focus:") and focus_finding is not None:
        # The initial-report counterpart of deep_report_focus above: the person pressed the chat
        # button inside one finding card, so say which one -- the model sees the whole report
        # and otherwise cannot tell. Their first message is not assumed to be about it.
        findings = (report or {}).get("findings") or []
        finding = findings[focus_finding] if 0 <= focus_finding < len(findings) else None
        if finding:
            area = _FINDING_AREA_LABELS.get(finding["area"], finding["area"])
            ordinal = "اول" if focus_finding == 0 else "دوم"
            parts[0] = (
                f"کاربر از یافته‌ی {ordinal} گزارش اولیه ({area}: «{finding['title']}») وارد گفتگو شده است.\n"
                "گفتگو را از همان‌جا شروع کن، ولی اگر ربطش به بخش دیگری از گزارش روشن بود "
                "به آن هم اشاره کن — کاربر روی یک دکمه کلیک کرده، نه اینکه گفتگو را محدود کرده باشد."
            )
        else:
            parts[0] = "کاربر از یکی از یافته‌های گزارش اولیه وارد گفتگو شده است."

    if entry_source == "report_open_question":
        # The question text comes from the report itself: the front-end shows it on the empty
        # chat page but it is not a message, so it is not in `history` (chat_spec_v3_1 §1.1).
        question = ((report or {}).get("open_question") or {}).get("text")
        if question:
            parts[0] = (
                "کاربر از سؤال باز گزارش اولیه وارد گفتگو شده است. "
                f"سؤال این بود: «{question}». "
                "اولین پیام کاربر به احتمال زیاد جواب او به همین سؤال است."
            )
        else:
            parts[0] = "کاربر از سؤال باز گزارش اولیه وارد گفتگو شده است."
        parts.append(_OPEN_QUESTION_MISSION)

    action_context = action_context or {}

    current = action_context.get("current")
    if current:
        line = f"قدم مورد بحث: «{current['text']}»"
        deadline = current.get("deadline_text") or current.get("deadline_type", "")
        if deadline:
            line += f" (مهلت: {deadline})"
        parts.append(line)
        if current.get("obstacle"):
            parts.append(f"مانعی که خودش انتخاب کرد: {current['obstacle']}")

        mission = _ACTION_MISSION.get(entry_source)
        if mission:
            parts.append(mission)

    recent = action_context.get("recent") or []
    if recent:
        lines = ["قدم‌های اخیر:"]
        for step in recent:
            status = _STATUS_LABELS.get(step.get("status"), step.get("status", ""))
            line = f"- «{step['text']}» — {status}"
            note = step.get("reflection") or step.get("obstacle")
            if note:
                line += f" ({note})"
            lines.append(line)
        # In action_active the person raised the pending step themselves, so the
        # do-not-ask rule would contradict the mission stated just above it.
        if entry_source != "action_active":
            lines.append(
                "درباره‌ی قدمی که هنوز «در جریان» است نپرس آیا انجام شده — "
                "پیگیری‌اش جای دیگری انجام می‌شود."
            )
        parts.append("\n".join(lines))

    return "<session_context>\n" + "\n\n".join(parts) + "\n</session_context>"


def render_report_initial(report: dict, report_version: str | None = None) -> str:
    """The initial (30-question) report, by version (chat_spec_v3_1 §1.5).

    report_v1: JSON. preview.teaser_line exists for the pre-login screen and share exists for
    the card; anyone in chat is past both, so sending them only costs tokens. Backend should
    already have stripped them -- this is a second guard, not the primary one.

    report_v2: readable Persian, same reasoning as render_report_deep -- the model reads prose
    better than JSON and English keys (`work`) never get echoed back to the user.

    A caller that does not say which version it has gets the shape inferred from the report
    itself (v2 has `findings`), so an older call site cannot silently send a v2 report through
    the v1 renderer.
    """
    if report_version is None:
        report_version = "report_v2" if "findings" in report else "report_v1"
    if report_version == "report_v2":
        return _render_report_initial_v2(report)

    trimmed = {k: v for k, v in report.items() if k not in {"preview", "share"}}
    return "<report>\n" + json.dumps(trimmed, ensure_ascii=False, indent=2) + "\n</report>"


def _render_report_initial_v2(report: dict) -> str:
    """Template from report_spec_v2_0 §9.5.

    Left out on purpose, though present in `report`: suggested_step (the person's real steps
    arrive in action_context -- showing the report's suggestion too would leave the model
    unsure whether it was accepted), findings_heading and open_question.finding_index (page
    layout only).
    """
    findings = report["findings"]

    def finding_block(ordinal: str, finding: dict) -> str:
        area = _FINDING_AREA_LABELS.get(finding["area"], finding["area"])
        return (
            f"یافته‌ی {ordinal} ({area}): {finding['title']}\n"
            f"{finding['what']}\n"
            f"اثرش: {finding['cost']}"
        )

    out = [
        "گزارش اولیه (تست ۳۰ سؤالی)",
        f"جمله‌ی اصلی گزارش:\n{report['hook']}",
        f"نقطه‌ی قوت: {report['strength']['title']}\n{report['strength']['text']}",
        finding_block("اول", findings[0]),
        finding_block("دوم", findings[1]),
        "سؤال‌هایی که گزارش از کاربر پرسیده. جوابشان را نمی‌دانیم:\n"
        f"- درباره‌ی یافته‌ی اول: {findings[0]['curiosity']}\n"
        f"- درباره‌ی یافته‌ی دوم: {findings[1]['curiosity']}\n"
        f"- سؤال باز: {report['open_question']['text']}\n"
        f"- سؤال آخر گزارش: {report['exit']['bridge']} {report['exit']['root_question']}",
    ]
    return "<report>\n" + "\n\n".join(out) + "\n</report>"


_TOPIC_PAGE_LABELS = {
    "decision_style": "سبک تصمیم‌گیری",
    "communication_style": "سبک ارتباطی",
    "work_style": "سبک کاری و رهبری",
    "stress_and_energy": "استرس، انرژی و بازیابی",
    "learning_and_growth": "یادگیری و رشد",
    "close_relationships": "روابط نزدیک",
}

_DOMAIN_LABELS = {
    "N": "واکنش‌پذیری هیجانی",
    "E": "برون‌گرایی",
    "O": "گشودگی",
    "A": "توافق‌پذیری",
    "C": "وظیفه‌شناسی",
}

_LEVEL_LABELS = {"low": "پایین", "mid": "میانه", "high": "بالا"}

# The 30 facet names, from deep_report_spec_v1_1 section 1.1.
# Codes are never shown to the model; only these labels are.
_FACET_LABELS = {
    "N1": "اضطراب", "N2": "خشم و تحریک‌پذیری", "N3": "گرایش به دلسردی",
    "N4": "حساسیت به قضاوت اجتماعی", "N5": "تکانشگری", "N6": "آسیب‌پذیری در برابر فشار",
    "E1": "گرمی و صمیمیت", "E2": "معاشرت‌جویی", "E3": "ابراز وجود",
    "E4": "سطح فعالیت", "E5": "هیجان‌خواهی", "E6": "هیجان‌های مثبت",
    "O1": "تخیل", "O2": "حساسیت زیبایی‌شناختی", "O3": "گشودگی به احساسات",
    "O4": "تنوع در تجربه", "O5": "کنجکاوی فکری", "O6": "انعطاف در باورها",
    "A1": "اعتماد", "A2": "صراحت", "A3": "نوع‌دوستی",
    "A4": "سبک مواجهه با تعارض", "A5": "فروتنی", "A6": "حساسیت انسانی",
    "C1": "احساس کفایت", "C2": "نظم", "C3": "تعهد و وظیفه‌شناسی",
    "C4": "پیشرفت‌طلبی", "C5": "خودانضباطی", "C6": "سنجیدگی",
}


def render_report_deep(report: dict) -> str:
    """The deep (150-question) report as readable Persian, not raw JSON.

    Two reasons this is not json.dumps like the initial report:

    1. Size. The deep report has 30 facet entries plus six topic pages plus strengths and
       blind spots. As JSON that is a wall of braces and English field names, and the model
       has to work to find anything in it.
    2. The English keys are noise here -- `when_it_works` means nothing to a Persian
       response, while «وقتی خوب کار می‌کند» is the phrasing we actually want echoed.

    Facet codes (N1, C6...) are deliberately dropped. The spec forbids them appearing in
    output, and the surest way to prevent that is to never show them.

    share is dropped for the same reason as the initial report.
    """
    out: list[str] = []

    if report.get("identity_line"):
        out.append(f"جمله‌ی کلی: {report['identity_line']}")

    if report.get("top_strengths"):
        items = "\n".join(f"- {s}" for s in report["top_strengths"])
        out.append(f"سه نقطه‌قوت اصلی:\n{items}")

    if report.get("growth_priorities"):
        items = "\n".join(f"- {s}" for s in report["growth_priorities"])
        out.append(f"سه اولویت رشد:\n{items}")

    if report.get("integrated_interpretation"):
        out.append(f"تفسیر یکپارچه:\n{report['integrated_interpretation']}")

    for domain in report.get("domains", []):
        name = _DOMAIN_LABELS.get(domain.get("code"), domain.get("code", ""))
        lines = [f"— {name} —"]
        for facet in domain.get("facets", []):
            level = _LEVEL_LABELS.get(facet.get("level"), facet.get("level", ""))
            # facet name comes from the spec's own label table, not from the payload
            label = _FACET_LABELS.get(facet.get("code"), facet.get("code", ""))
            lines.append(
                f"{label} ({level}): وقتی خوب کار می‌کند — {facet.get('when_it_works','')} · "
                f"وقتی هزینه می‌سازد — {facet.get('when_it_costs','')}"
            )
        if domain.get("summary"):
            lines.append(f"جمع‌بندی: {domain['summary']}")
        out.append("\n".join(lines))

    strengths = report.get("strengths") or {}
    if strengths.get("items"):
        lines = ["— نقاط قوت —"]
        for s in strengths["items"]:
            lines.append(
                f"{s.get('title','')}: {s.get('value','')} "
                f"(ریسک افراط: {s.get('overuse','')})"
            )
        out.append("\n".join(lines))

    blind = report.get("blind_spots") or {}
    if blind.get("items"):
        lines = ["— نقاط کور —"]
        for b in blind["items"]:
            lines.append(
                f"{b.get('hypothesis','')} — محرک: {b.get('trigger','')} · "
                f"نشانه: {b.get('visible_sign','')}"
            )
        out.append("\n".join(lines))

    for key, label in _TOPIC_PAGE_LABELS.items():
        page = report.get(key) or {}
        rows = page.get("rows") or []
        if not rows:
            continue
        lines = [f"— {label} —"]
        lines += [f"{r.get('topic','')}: {r.get('text','')}" for r in rows]
        if page.get("closing"):
            lines.append(page["closing"])
        out.append("\n".join(lines))

    closing = report.get("closing") or {}
    if closing.get("small_actions"):
        # Each item is usually a suggested_step dict ({"text": ..., "deadline_type": ...}), but
        # real generation isn't schema-enforced here (unlike chat_input.py's pydantic layer) and
        # has produced plain strings -- handle both rather than crash the whole conversation.
        items = "\n".join(
            f"- {a['text'] if isinstance(a, dict) else a}" for a in closing["small_actions"]
        )
        out.append(f"قدم‌های پیشنهادی گزارش:\n{items}")

    return "<report>\n" + "\n\n".join(out) + "\n</report>"


def build_system_prompt(
    entry_source: str,
    user_memory: list[dict],
    report_type: str | None = None,
    report: dict | None = None,
    action_context: dict | None = None,
    focus_section: str | None = None,
    report_version: str | None = None,
    focus_finding: int | None = None,
) -> str:
    """Assemble the system prompt in the required order.

    Blocks 1-5 are static and cacheable -- identical for every session now that
    ACTION_STEP_BLOCK is unconditional. Blocks 6-8 vary per user and must come after.
    """
    static = [
        ("role", ROLE),
        ("safety_rules", safety_rules()),
        ("safety_rules_chat_extension", read_block(str(_BLOCK_DIR / "safety_rules_chat_extension.md"))),
        ("punctuation_rules", punctuation_rules()),
        ("knowledge_base", "<knowledge>\n" + read_block(str(_BLOCK_DIR / "knowledge_base.md")) + "\n</knowledge>"),
        ("action_step", ACTION_STEP_BLOCK),
    ]

    variable = []
    memory_block = render_user_memory(user_memory)
    if memory_block:
        variable.append(("user_memory", memory_block))
    if report:
        if report_type == "deep":
            variable.append(("report", render_report_deep(report)))
        else:
            variable.append(("report", render_report_initial(report, report_version)))
    variable.append(("session_context", render_session_context(entry_source, action_context, focus_section, report, focus_finding)))

    return "\n\n".join(text for _, text in static + variable)


def build_messages(
    entry_source: str,
    user_message: str,
    history: list[dict] | None = None,
    user_memory: list[dict] | None = None,
    report_type: str | None = None,
    report: dict | None = None,
    action_context: dict | None = None,
    focus_section: str | None = None,
    report_version: str | None = None,
    focus_finding: int | None = None,
) -> list[dict]:
    """Build the full messages array: system + history + this turn.

    entry_source:   report_cta | report_open_question | report_finding_focus:<0|1> | deep_report_cta | deep_report_focus:<section> |
                    action_rejected | action_active | action_missed | action_completed | manual
    user_message:   the current message. Not included in history.
    history:        up to 30 prior messages, already trimmed by backend.
    user_memory:    current memory rows. An empty list is valid -- a logged-in user can chat
                    before taking the test, in which case there is no report either.
    report:         sent only for report-derived entry sources. Never for action ones.
    action_context: current (the step under discussion, required for the three action entry
                    sources) plus recent (last three steps, always sent).
    """
    user_memory = user_memory or []
    history = history or []

    # These two guards mirror chat_spec_v2 section 6.1. They exist because getting them
    # wrong produces a plausible-looking conversation about the wrong thing, with no error.
    current = (action_context or {}).get("current")
    if entry_source in ACTION_ENTRY_SOURCES and not current:
        raise ValueError(
            f"{entry_source} requires action_context.current: the conversation is about a "
            f"specific step and the model cannot know which one otherwise"
        )
    if current and entry_source not in ACTION_ENTRY_SOURCES:
        raise ValueError(
            f"action_context.current was sent with entry_source={entry_source!r}; it belongs "
            f"only to {sorted(ACTION_ENTRY_SOURCES)}"
        )
    if entry_source.startswith(_REPORT_ENTRY_PREFIXES) and not report:
        raise ValueError(f"{entry_source} requires a report")

    messages = [
        {
            "role": "system",
            "content": build_system_prompt(
                entry_source, user_memory, report_type, report, action_context, focus_section,
                report_version, focus_finding,
            ),
        }
    ]
    messages.extend(history)
    messages.append({"role": "user", "content": user_message})
    return messages