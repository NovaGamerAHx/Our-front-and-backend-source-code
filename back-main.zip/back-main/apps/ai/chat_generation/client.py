"""Public entry point for the chat-generation AI pipeline, mirroring
apps.ai.report_generation.client.ReportGenerationClient's role for reports.

This is the boundary consuming apps are meant to depend on: a plain dict in (chat_input
.ChatRequest's shape), delta/done chunk dicts out. apps.chat.services.ai_chat_client
.AiChatClient is the only consumer.
"""

from apps.ai.chat_generation.chat_input import ChatRequest
from apps.ai.chat_generation.generate import PROMPT_VERSION, generate_chat_stream


class ChatGenerationClient:
    def __init__(self, client=None):
        # Optional injected OpenAI-shaped client -- lets tests avoid real network calls.
        self._client = client

    def generate_stream(self, payload: dict):
        """payload matches chat_input.ChatRequest's shape. A malformed payload raises
        pydantic's ValidationError here rather than reaching the prompt.

        Yields delta/done chunks; done includes proposed_action when the model emitted the
        <<<ACTION>>> marker."""
        request = ChatRequest.model_validate(payload)
        return generate_chat_stream(request, client=self._client)
