from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

DeadlineType = Literal["tonight", "tomorrow_morning", "tomorrow_evening", "within_24h"]


class ProposedAction(BaseModel):
    """A step the model is offering.

    Always a NEW step. There is no `id` and no replacement path: rejecting a step is only
    possible before accepting it, so a rejected step was never written to action_steps and
    there is nothing to replace.

    `substeps` is null for almost every step. Most steps do not decompose, and breaking an
    atomic action into pieces is condescending -- see action_step_prompt for the rule the
    model is given.
    """

    text: str
    deadline_text: str
    deadline_type: DeadlineType
    substeps: list[str] | None = None
