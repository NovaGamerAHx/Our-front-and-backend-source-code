"""The full path: ChatRequest -> messages -> streaming model call -> chunks.

Yields delta chunks as text arrives, then exactly one done chunk.

Two things differ from apps.ai.report_generation.generate, and both make this simpler:

1. The output is free text, so there is no schema to validate and no reason to retry for a
   malformed response. The attempt ladder exists only for network and provider errors.

2. Because text is streamed, a retry after the first delta would re-send text the user has
   already read. So: retry only before the first delta. After that, any failure propagates
   and ChatService keeps whatever text already reached the user.

The <<<ACTION>>> marker is stripped here and never reaches the caller -- delta chunks carry
only display text.

Clients (and their timeout/retry settings, which matter a lot on this network) come from
apps.ai.openai_client -- shared with report generation.
"""

from __future__ import annotations

import json
import logging
import os
import random
import time
from collections.abc import Iterator

from pydantic import ValidationError

from apps.ai.chat_generation.chat_input import ChatRequest
from apps.ai.chat_generation.prompt import build_messages
from apps.ai.chat_generation.schema import ProposedAction
from apps.ai.openai_client import client_for

logger = logging.getLogger(__name__)

MARKER = "<<<ACTION>>>"

# Single source of truth for the prompt's version -- bump this whenever ROLE, safety_rules,
# knowledge_base.md, action_step_prompt.py, or safety_rules_chat_extension.md changes.
# Reused below for the cache key and re-exported via client.py for apps.chat to stamp on
# persisted messages, so the two never drift apart.
PROMPT_VERSION = "chat_v3"

# prompt_cache_key is a *routing* hint: same key -> same backend -> the shared static prefix
# stays warm. It is deliberately NOT session_id -- a per-session key gives each session its
# own bucket and defeats exactly the caching the prompt's fixed block order exists for
# ("once per cache window, not once per conversation", shared across concurrent sessions).
# Only one key is needed now: ACTION_STEP_BLOCK is unconditional (chat_spec_v2), so every
# entry_source shares the same static prefix.
PROMPT_CACHE_KEY = PROMPT_VERSION


_MOCK_REPLY = "به نظرم این الگو که توی پیامت دیده می‌شود، همان چیزی است که قبلاً هم بهش اشاره شده بود."


def _ai_enabled() -> bool:
    return os.getenv("CHAT_AI_ENABLED", "true").strip().lower() not in ("false", "0", "no")


def _is_rate_limit(exc: Exception) -> bool:
    return getattr(exc, "status_code", None) == 429 or type(exc).__name__ == "RateLimitError"


def _retry_delay(exc: Exception, attempt: int) -> float:
    """Honour the provider's own backoff hint; otherwise exponential with jitter.

    Retrying a 429 immediately just adds load to a quota that is already exhausted.
    """
    headers = getattr(getattr(exc, "response", None), "headers", None) or {}
    for key, scale in (("retry-after-ms", 1000.0), ("retry-after", 1.0)):
        raw = headers.get(key)
        if raw:
            try:
                return min(float(raw) / scale, 30.0)
            except ValueError:
                pass
    return min(2**attempt, 30.0) + random.uniform(0, 0.5)


def _parse_action(raw: str) -> ProposedAction | None:
    """Parse the JSON that follows the marker.

    A failure here must not break the conversation: the user already has their text, and
    losing the step card is a much smaller problem than losing the reply.
    """
    text = raw.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[-1].rsplit("```", 1)[0]
    try:
        return ProposedAction.model_validate_json(text)
    except (json.JSONDecodeError, ValidationError) as e:
        logger.warning("proposed_action parse failed: %s", e)
        return None


class _MarkerSplitter:
    """Splits streamed text at the action marker.

    The marker can straddle two chunks, so the tail of the buffer is held back until it is
    long enough to rule out a partial match. Once the marker is seen, nothing more is
    emitted -- the rest is the JSON payload.
    """

    def __init__(self) -> None:
        self.pending = ""
        self.after_marker = ""
        self.emitted = ""      # everything sent as a delta -- becomes the done message
        self.found = False

    def feed(self, chunk: str) -> str:
        """Add a chunk; return whatever is now safe to emit."""
        if self.found:
            self.after_marker += chunk
            return ""

        self.pending += chunk
        idx = self.pending.find(MARKER)
        if idx >= 0:
            out = self.pending[:idx]
            self.after_marker = self.pending[idx + len(MARKER):]
            self.pending = ""
            self.found = True
            return self._record(out)

        # Hold back enough characters that a split marker cannot be missed.
        safe = len(self.pending) - (len(MARKER) - 1)
        if safe <= 0:
            return ""
        out, self.pending = self.pending[:safe], self.pending[safe:]
        return self._record(out)

    def flush(self) -> str:
        """Emit whatever is left once the stream ends."""
        if self.found:
            return ""
        out, self.pending = self.pending, ""
        return self._record(out)

    def _record(self, out: str) -> str:
        self.emitted += out
        return out


def _mock_stream() -> Iterator[dict]:
    """CHAT_AI_ENABLED=false: skip the real model entirely, for exercising the rest of the
    pipeline (SSE, persistence, the API shape) without waiting on or paying for a call.

    CHAT_MOCK_STREAM_DELAY_MS (simulated time-to-first-token) and
    CHAT_MOCK_STREAM_CHUNK_COUNT/_CHUNK_INTERVAL_MS (split the reply into N deltas with a pause
    between them, simulating token-by-token streaming) all default to 0/1/0 -- today's exact
    instant single-delta behavior -- everywhere except a load test that opts in (see
    loadtest/README.md). A real model holds its web-tier gevent connection open for the whole
    generation (5-25s, CLAUDE.md known issue #23); the default mock doesn't reproduce that, which
    is fine for measuring pure infra throughput but not for measuring long-held-connection
    effects. time.sleep is gevent-monkeypatched cooperative under gunicorn's gevent worker
    (entrypoint.sh), so this never blocks other requests on the same worker."""
    logger.warning("CHAT_AI_ENABLED=false -- returning a mock reply instead of calling a real model")
    started = time.perf_counter()

    delay_ms = int(os.getenv("CHAT_MOCK_STREAM_DELAY_MS", "0"))
    if delay_ms > 0:
        time.sleep(delay_ms / 1000)

    chunk_count = max(1, int(os.getenv("CHAT_MOCK_STREAM_CHUNK_COUNT", "1")))
    interval_ms = int(os.getenv("CHAT_MOCK_STREAM_CHUNK_INTERVAL_MS", "0"))
    chunk_size = max(1, -(-len(_MOCK_REPLY) // chunk_count))  # ceil division

    for i in range(0, len(_MOCK_REPLY), chunk_size):
        if i > 0 and interval_ms > 0:
            time.sleep(interval_ms / 1000)
        yield {"type": "delta", "text": _MOCK_REPLY[i:i + chunk_size]}

    yield {
        "type": "done",
        "message": _MOCK_REPLY,
        "proposed_action": None,
        "generation_meta": {
            "model_used": "mock", "attempts": 0, "input_tokens": 0, "output_tokens": 0,
            "latency_s": round(time.perf_counter() - started, 2),
        },
    }


def generate_chat_stream(request: ChatRequest, client=None) -> Iterator[dict]:
    """request: validated ChatRequest (see chat_input.py).

    Yields {"type": "delta", "text": ...} chunks then exactly one {"type": "done", ...}.
    Raises when every attempt failed before any delta was sent, or when a failure happens
    after one -- ChatService turns either into an in-stream error event.

    client: optional injected OpenAI-shaped client, used for every attempt regardless of
    provider -- lets tests run without network access.
    """
    if not _ai_enabled():
        yield from _mock_stream()
        return

    messages = build_messages(
        entry_source=request.entry_source,
        user_message=request.user_message,
        history=[m.model_dump() for m in request.history],
        user_memory=[m.model_dump() for m in request.user_memory],
        report_type=request.report_type,
        report_version=request.report_version,
        report=request.report,
        action_context=request.action_context.model_dump(exclude_none=True),
        focus_section=request.focus_section,
        focus_finding=request.focus_finding,
    )

    primary_model = os.getenv("CHAT_PRIMARY_MODEL", "gpt-5.4")
    backup_model = os.getenv("CHAT_BACKUP_MODEL", "gpt-5.4-mini")
    # AvalAI is the last resort, after OpenAI has failed twice; it runs the full model, not the mini.
    avalai_model = os.getenv("CHAT_AVALAI_MODEL") or "gpt-5.4"
    max_primary_attempts = int(os.getenv("CHAT_MAX_PRIMARY_ATTEMPTS", "2"))

    # Primary on OpenAI (retried N times), then the backup model on OpenAI, then that same
    # backup via AvalAI -- a different infra path in case OpenAI itself is the problem.
    attempts = (
        [("openai", primary_model)] * max_primary_attempts
        + [("openai", backup_model), ("avalai", avalai_model)]
    )

    logger.info(
        "chat generate start: entry_source=%s cache_key=%s user_memory_rows=%d has_report=%s "
        "report_type=%s has_current_action=%s recent_steps=%d focus_section=%s "
        "history_len=%d message_chars=%d",
        request.entry_source, PROMPT_CACHE_KEY, len(request.user_memory), request.report is not None,
        request.report_type, request.action_context.current is not None,
        len(request.action_context.recent), request.focus_section,
        len(request.history), len(request.user_message),
    )

    started = time.perf_counter()
    sent_delta = False

    for i, (provider, model) in enumerate(attempts, start=1):
        splitter = _MarkerSplitter()
        usage = None
        try:
            call_client = client or client_for(provider)
            stream = call_client.chat.completions.create(
                model=model,
                messages=messages,
                stream=True,
                stream_options={"include_usage": True},
                prompt_cache_key=PROMPT_CACHE_KEY,
            )

            for chunk in stream:
                if getattr(chunk, "usage", None):
                    usage = chunk.usage
                if not chunk.choices:
                    continue
                piece = chunk.choices[0].delta.content
                if not piece:
                    continue
                out = splitter.feed(piece)
                if out:
                    sent_delta = True
                    yield {"type": "delta", "text": out}

            tail = splitter.flush()
            if tail:
                sent_delta = True
                yield {"type": "delta", "text": tail}

        except Exception as e:
            if sent_delta:
                # Text is already on the user's screen; a retry would duplicate it.
                logger.error("attempt %d (%s via %s) failed mid-stream: %s", i, model, provider, e)
                raise

            logger.warning("attempt %d/%d (%s via %s) failed: %s: %s",
                           i, len(attempts), model, provider, type(e).__name__, e)
            if _is_rate_limit(e) and i < len(attempts):
                time.sleep(_retry_delay(e, i))
            continue

        action = _parse_action(splitter.after_marker) if splitter.found else None
        cached = getattr(getattr(usage, "prompt_tokens_details", None), "cached_tokens", 0) or 0
        input_tokens = getattr(usage, "prompt_tokens", 0) or 0
        output_tokens = getattr(usage, "completion_tokens", 0) or 0

        logger.info(
            "chat generated: model=%s provider=%s attempt=%d action=%s "
            "action_deadline_type=%s input_tokens=%d cached_input_tokens=%d output_tokens=%d "
            "message_chars=%d",
            model, provider, i, action is not None,
            action.deadline_type if action else None,
            input_tokens, cached, output_tokens, len(splitter.emitted),
        )

        yield {
            "type": "done",
            "message": splitter.emitted,
            "proposed_action": action.model_dump() if action else None,
            "generation_meta": {
                "model_used": f"{model} ({provider})",
                "attempts": i,
                "input_tokens": input_tokens,
                "cached_input_tokens": cached,
                "output_tokens": output_tokens,
                "latency_s": round(time.perf_counter() - started, 2),
            },
        }
        return

    raise RuntimeError(f"chat generation failed after {len(attempts)} attempts")
