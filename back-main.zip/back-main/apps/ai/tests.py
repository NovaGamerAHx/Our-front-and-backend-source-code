import json
import os
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from django.test import TestCase
from pydantic import ValidationError

from apps.ai.chat_generation.client import ChatGenerationClient
from apps.ai.models import ModelPricing
from apps.ai.pricing import calculate_cost
from apps.ai.report_generation.client import ReportGenerationClient
from apps.ai.report_generation.generate import _ai_enabled
from apps.ai.report_generation.schema import AIOutput
from apps.ai.report_generation.schema_v2 import AIOutputV2, soft_check_v2
from apps.ai.chat_generation.chat_input import ChatRequest
from apps.ai.chat_generation.prompt import build_messages as build_chat_messages

_FEWSHOT_DIR = Path(__file__).resolve().parent / "report_generation" / "fewshot"
_FEWSHOT_V2_DIR = Path(__file__).resolve().parent / "report_generation" / "fewshot_v2"


class _FakeCompletions:
    """Stands in for openai's client.chat.completions -- returns one canned response (or
    raises one canned exception) per call, in order, so generate_report()'s attempt ladder
    can be exercised without any real network access or API key."""

    def __init__(self, responses):
        self._responses = list(responses)
        self.calls = []

    def create(self, model, messages):
        self.calls.append({"model": model, "messages": messages})
        item = self._responses.pop(0)
        if isinstance(item, Exception):
            raise item
        return SimpleNamespace(
            choices=[SimpleNamespace(message=SimpleNamespace(content=item))],
            usage=SimpleNamespace(prompt_tokens=10, completion_tokens=20),
        )


class _FakeOpenAIClient:
    def __init__(self, responses):
        self.completions = _FakeCompletions(responses)
        self.chat = SimpleNamespace(completions=self.completions)


def _fewshot_model_output(n: int) -> str:
    """A valid raw model response string: {"report": ..., "system": ...} from example_n.json."""
    example = json.loads((_FEWSHOT_DIR / f"example_{n}.json").read_text(encoding="utf-8"))
    return json.dumps({"report": example["report"], "system": example["system"]}, ensure_ascii=False)


def _v2_example(key: str) -> dict:
    """One of the golden report_v2 examples ("A" | "B" | "C"): {"report": ..., "system": ...}."""
    return json.loads((_FEWSHOT_V2_DIR / f"example_{key}.json").read_text(encoding="utf-8"))


def _v2_model_output(key: str = "A", mutate=None) -> str:
    example = _v2_example(key)
    if mutate:
        mutate(example)
    return json.dumps(example, ensure_ascii=False)


_DIMENSION_SCORES = [
    {'key': 'emotional_stability', 'score_percent': 72, 'level': 'medium_high'},
    {'key': 'extraversion', 'score_percent': 58, 'level': 'medium'},
    {'key': 'openness', 'score_percent': 84, 'level': 'high'},
    {'key': 'agreeableness', 'score_percent': 66, 'level': 'medium_high'},
    {'key': 'conscientiousness', 'score_percent': 88, 'level': 'high'},
]


_REPORT_MODEL_ENV = {
    # These classes exercise the report_v1 pipeline; report_v2 (the default) has its own below.
    "REPORT_INITIAL_VERSION": "report_v1",
    "REPORT_PRIMARY_MODEL": "gpt-5.4-mini",
    "REPORT_BACKUP_MODEL": "gpt-5.4",
    "REPORT_MAX_PRIMARY_ATTEMPTS": "2",
}


class ReportGenerationClientTests(TestCase):
    """Exercises the real AI pipeline (schema validation, retry ladder, prompt building)
    against a fake OpenAI-shaped client -- no real network access or API key needed.

    Model names/attempt count are pinned here rather than left to the environment: this
    module reads them from os.getenv at call time, so a local .env with different values
    (as this project's does) would otherwise make these assertions flaky per-developer."""

    def setUp(self):
        patcher = patch.dict(os.environ, _REPORT_MODEL_ENV)
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_success_on_first_attempt(self):
        fake_client = _FakeOpenAIClient([_fewshot_model_output(1)])

        result = ReportGenerationClient(openai_client=fake_client).generate(_DIMENSION_SCORES)

        self.assertEqual(result['status'], 'ok')
        self.assertEqual(result['report_version'], 'report_v1')
        self.assertIn('summary', result['report'])
        self.assertEqual(len(result['memory_candidates']), 4)
        self.assertEqual(len(fake_client.completions.calls), 1)

    def test_retries_after_malformed_response_then_succeeds(self):
        fake_client = _FakeOpenAIClient(['not valid json', _fewshot_model_output(2)])

        result = ReportGenerationClient(openai_client=fake_client).generate(_DIMENSION_SCORES)

        self.assertEqual(result['status'], 'ok')
        self.assertEqual(len(fake_client.completions.calls), 2)

    def test_all_attempts_failing_returns_generation_failed_error(self):
        fake_client = _FakeOpenAIClient(['not valid json', 'still not valid', 'nope', 'nope again'])

        result = ReportGenerationClient(openai_client=fake_client).generate(_DIMENSION_SCORES)

        self.assertEqual(result['status'], 'error')
        self.assertEqual(result['error']['code'], 'generation_failed')
        self.assertFalse(result['error']['should_display_report'])
        # every attempt in the ladder (primary x2 + openai backup + avalai backup) was tried
        self.assertEqual(len(fake_client.completions.calls), 4)

    def test_context_profile_reaches_the_final_prompt_turn(self):
        fake_client = _FakeOpenAIClient([_fewshot_model_output(1)])

        ReportGenerationClient(openai_client=fake_client).generate(
            _DIMENSION_SCORES, context_profile={'life_situation': 'employed', 'current_goal': 'purpose', 'age': '30'},
        )

        final_user_turn = json.loads(fake_client.completions.calls[0]['messages'][-1]['content'])
        self.assertEqual(final_user_turn['context_profile'], {
            'life_situation': 'employed', 'current_goal': 'purpose', 'age': '30',
        })

    def test_success_response_includes_generation_meta(self):
        fake_client = _FakeOpenAIClient([_fewshot_model_output(1)])

        result = ReportGenerationClient(openai_client=fake_client).generate(_DIMENSION_SCORES)

        self.assertEqual(result['generation_meta'], {
            'model_used': 'gpt-5.4-mini (openai)', 'attempts': 1,
            'input_tokens': 10, 'output_tokens': 20, 'latency_s': 0.0,
        })

    def test_error_response_still_includes_generation_meta_with_null_model(self):
        # every attempt in the ladder produced malformed JSON -- each still reached the
        # provider and burned tokens, so generation_meta must reflect that even on error
        # (report_spec_v1.4 §4.2).
        fake_client = _FakeOpenAIClient(['not valid json', 'still not valid', 'nope', 'nope again'])

        result = ReportGenerationClient(openai_client=fake_client).generate(_DIMENSION_SCORES)

        self.assertEqual(result['status'], 'error')
        self.assertEqual(result['generation_meta']['model_used'], None)
        self.assertEqual(result['generation_meta']['attempts'], 4)
        self.assertEqual(result['generation_meta']['input_tokens'], 40)
        self.assertEqual(result['generation_meta']['output_tokens'], 80)


class ReportV2SchemaTests(TestCase):
    """report_spec_v2_0 §4.3 hard rules, and the soft checks the golden examples must pass."""

    def test_golden_examples_pass_hard_and_soft_validation(self):
        for key in "ABC":
            with self.subTest(example=key):
                output = AIOutputV2.model_validate(_v2_example(key))
                self.assertEqual(soft_check_v2(output), [])

    def _rejects(self, mutate):
        example = _v2_example("A")
        mutate(example)
        with self.assertRaises(ValidationError):
            AIOutputV2.model_validate(example)

    def test_soft_check_flags_disclaimers_and_missing_half_spaces(self):
        example = _v2_example("A")
        example["report"]["findings"][0]["what"] = (
            "کار آماده است. بر اساس پاسخ‌هایت، اگر این به تو نمی‌خورد، نادیده‌اش بگیر."
        )
        example["report"]["findings"][1]["cost"] = "تصمیم ها و می کنی هم عقب می‌افتد."
        joined = " ".join(soft_check_v2(AIOutputV2.model_validate(example)))

        self.assertIn("disclaimer phrase", joined)
        self.assertIn("half-space", joined)

    def test_golden_example_inputs_are_valid_profile_inputs(self):
        """Few-shot inputs must use the database's enums, or the model is taught values the
        real pipeline would reject."""
        from apps.ai.report_generation.profile_input import ProfileInput

        for key in "ABC":
            with self.subTest(example=key):
                inp = json.loads((_FEWSHOT_V2_DIR / f"example_{key}_input.json").read_text(encoding="utf-8"))
                ProfileInput(**inp)

    def test_rejects_same_area_on_both_findings(self):
        self._rejects(lambda e: e["report"]["findings"][1].update(area="work"))

    def test_rejects_missing_step_on_first_finding(self):
        self._rejects(lambda e: e["report"]["findings"][0].update(suggested_step=None))

    def test_rejects_step_on_second_finding(self):
        def mutate(e):
            e["report"]["findings"][1]["suggested_step"] = e["report"]["findings"][0]["suggested_step"]
        self._rejects(mutate)

    def test_rejects_substeps(self):
        self._rejects(lambda e: e["report"]["findings"][0]["suggested_step"].update(substeps=["a"]))

    def test_rejects_wrong_finding_count(self):
        self._rejects(lambda e: e["report"]["findings"].append(e["report"]["findings"][0]))

    def test_rejects_unknown_area_deadline_and_finding_index(self):
        self._rejects(lambda e: e["report"]["findings"][0].update(area="health"))
        self._rejects(lambda e: e["report"]["findings"][0]["suggested_step"].update(deadline_type="next_week"))
        self._rejects(lambda e: e["report"]["open_question"].update(finding_index=2))

    def test_rejects_extra_and_missing_fields(self):
        self._rejects(lambda e: e["report"].update(summary={"one_line": "x"}))
        self._rejects(lambda e: e["report"].pop("findings_heading"))
        self._rejects(lambda e: e["report"]["exit"].pop("root_question"))

    def test_soft_check_flags_forbidden_words_and_digits(self):
        example = _v2_example("A")
        example["report"]["hook"] = "این تست نشان می‌دهد ۳ بار همیشه نگران می‌شوی."
        warnings = soft_check_v2(AIOutputV2.model_validate(example))
        joined = " ".join(warnings)
        self.assertIn("تست", joined)
        self.assertIn("همیشه", joined)
        self.assertIn("digit", joined)


@patch.dict(os.environ, {**_REPORT_MODEL_ENV, "REPORT_INITIAL_VERSION": "report_v2"})
class ReportV2GenerationTests(TestCase):
    """The default generation path: same attempt ladder as v1, v2 schema and memory mapping."""

    def test_success_returns_v2_report_and_four_memory_candidates(self):
        fake_client = _FakeOpenAIClient([_v2_model_output("A")])

        result = ReportGenerationClient(openai_client=fake_client).generate(_DIMENSION_SCORES)

        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["report_version"], "report_v2")
        self.assertEqual(result["report"]["hook"], _v2_example("A")["report"]["hook"])
        self.assertEqual(len(result["memory_candidates"]), 4)

    def test_prompt_is_v2_with_three_golden_pairs_and_no_gender(self):
        fake_client = _FakeOpenAIClient([_v2_model_output("A")])

        ReportGenerationClient(openai_client=fake_client).generate(_DIMENSION_SCORES)

        messages = fake_client.completions.calls[0]["messages"]
        self.assertEqual([m["role"] for m in messages], ["system"] + ["user", "assistant"] * 3 + ["user"])
        self.assertIn("findings_heading", messages[0]["content"])
        self.assertNotIn("gender", messages[0]["content"])

    def test_retries_when_the_model_breaks_a_hard_rule(self):
        def same_area(e):
            e["report"]["findings"][1]["area"] = e["report"]["findings"][0]["area"]

        fake_client = _FakeOpenAIClient([_v2_model_output("A", same_area), _v2_model_output("A")])

        result = ReportGenerationClient(openai_client=fake_client).generate(_DIMENSION_SCORES)

        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["generation_meta"]["attempts"], 2)
        # The validation error is fed back into the retry.
        self.assertIn("must differ", fake_client.completions.calls[1]["messages"][-1]["content"])

    def test_the_avalai_rung_runs_the_full_model_not_the_backup(self):
        fake_client = _FakeOpenAIClient([RuntimeError("down")] * 4)

        with patch.dict(os.environ, {"REPORT_PRIMARY_MODEL": "gpt-5.4", "REPORT_BACKUP_MODEL": "gpt-5.4-mini",
                                     "REPORT_MAX_PRIMARY_ATTEMPTS": "1", "REPORT_AVALAI_MODEL": ""}):
            ReportGenerationClient(openai_client=fake_client).generate(_DIMENSION_SCORES)

        # openai primary, openai backup (mini), then avalai on the full model -- never the mini.
        self.assertEqual([c["model"] for c in fake_client.completions.calls],
                         ["gpt-5.4", "gpt-5.4-mini", "gpt-5.4"])

    def test_all_attempts_failing_is_an_error_tagged_report_v2(self):
        fake_client = _FakeOpenAIClient([RuntimeError("down")] * 4)

        result = ReportGenerationClient(openai_client=fake_client).generate(_DIMENSION_SCORES)

        self.assertEqual(result["status"], "error")
        self.assertEqual(result["report_version"], "report_v2")
        self.assertNotIn("report", result)

    def test_memory_mapping(self):
        fake_client = _FakeOpenAIClient([_v2_model_output("A")])
        example = _v2_example("A")["report"]

        result = ReportGenerationClient(openai_client=fake_client).generate(_DIMENSION_SCORES)

        by_type = {c["memory_type"]: c for c in result["memory_candidates"]}
        self.assertEqual(by_type["core_pattern"]["text_memory"], example["hook"])
        self.assertEqual(
            by_type["strength"]["text_memory"], f"{example['strength']['title']}: {example['strength']['text']}",
        )
        f0, f1 = example["findings"]
        self.assertEqual(
            by_type["growth_edge"]["text_memory"],
            f"- {f0['title']}: {f0['what']}\n- {f1['title']}: {f1['what']}",
        )
        self.assertEqual(by_type["growth_focus"]["text_memory"], f0["title"])
        # cost and the questions are never remembered.
        stored = " ".join(c["text_memory"] for c in result["memory_candidates"])
        self.assertNotIn(f0["cost"], stored)
        self.assertNotIn(f0["curiosity"], stored)
        self.assertNotIn(example["exit"]["root_question"], stored)
        self.assertTrue(all(c["source"] == "initial_report" for c in result["memory_candidates"]))

    def test_mock_mode_returns_a_valid_v2_report(self):
        fake_client = _FakeOpenAIClient([])

        with patch.dict(os.environ, {"REPORT_AI_ENABLED": "false"}):
            result = ReportGenerationClient(openai_client=fake_client).generate(_DIMENSION_SCORES)

        self.assertEqual(result["report_version"], "report_v2")
        self.assertIn("hook", result["report"])
        self.assertEqual(len(result["memory_candidates"]), 4)
        self.assertEqual(fake_client.completions.calls, [])

    def test_unset_or_empty_version_defaults_to_v1_and_unknown_falls_back(self):
        from apps.ai.report_generation.generate import initial_report_version

        with patch.dict(os.environ, {"REPORT_INITIAL_VERSION": ""}):
            self.assertEqual(initial_report_version(), "report_v1")
        with patch.dict(os.environ, {"REPORT_INITIAL_VERSION": "report_v9"}):
            self.assertEqual(initial_report_version(), "report_v1")
        with patch.dict(os.environ, {"REPORT_INITIAL_VERSION": "report_v2"}):
            self.assertEqual(initial_report_version(), "report_v2")
        env = {k: v for k, v in os.environ.items() if k != "REPORT_INITIAL_VERSION"}
        with patch.dict(os.environ, env, clear=True):
            self.assertEqual(initial_report_version(), "report_v1")


class ChatReportV2Tests(TestCase):
    """chat_spec_v3_1: report_open_question, report_version, and the v2 report renderer."""

    def _request(self, **overrides):
        payload = {
            "session_id": "s1", "entry_source": "report_open_question", "user_message": "hi",
            "report_type": "initial", "report_version": "report_v2",
            "report": _v2_example("A")["report"],
        }
        payload.update(overrides)
        return payload

    def test_open_question_entry_validates(self):
        ChatRequest.model_validate(self._request())

    def test_open_question_requires_report_v2(self):
        with self.assertRaises(ValidationError):
            ChatRequest.model_validate(self._request(report_version="report_v1"))

    def test_open_question_requires_a_report_and_the_initial_type(self):
        with self.assertRaises(ValidationError):
            ChatRequest.model_validate(self._request(report=None, report_type=None, report_version=None))
        with self.assertRaises(ValidationError):
            ChatRequest.model_validate(self._request(report_type="deep", report_version=None))

    def test_report_version_rules(self):
        with self.assertRaises(ValidationError):
            ChatRequest.model_validate(self._request(entry_source="report_cta", report_version=None))
        with self.assertRaises(ValidationError):
            ChatRequest.model_validate(
                self._request(entry_source="deep_report_cta", report_type="deep", report={}),
            )
        # v1 initial reports still validate.
        ChatRequest.model_validate(
            self._request(entry_source="report_cta", report_version="report_v1", report={"summary": {}}),
        )

    def test_v2_report_is_rendered_as_readable_persian_without_steps_or_layout_fields(self):
        report = _v2_example("A")["report"]
        messages = build_chat_messages(**{
            "entry_source": "report_cta", "user_message": "hi", "report_type": "initial",
            "report_version": "report_v2", "report": report,
        })
        system = messages[0]["content"]

        self.assertIn(report["hook"], system)
        self.assertIn("یافته‌ی اول (کار): " + report["findings"][0]["title"], system)
        self.assertIn("یافته‌ی دوم (رابطه): " + report["findings"][1]["title"], system)
        self.assertIn("اثرش: " + report["findings"][0]["cost"], system)
        self.assertIn(report["open_question"]["text"], system)
        self.assertIn(report["exit"]["root_question"], system)
        self.assertNotIn(report["findings"][0]["suggested_step"]["text"], system)
        self.assertNotIn(report["findings_heading"], system)
        self.assertNotIn('"area"', system)

    def test_v1_report_is_still_rendered_as_json(self):
        v1 = json.loads((_FEWSHOT_DIR / "example_1.json").read_text(encoding="utf-8"))["report"]
        system = build_chat_messages(
            entry_source="report_cta", user_message="hi", report_type="initial",
            report_version="report_v1", report=v1,
        )[0]["content"]

        self.assertIn('"snapshot_interpretations"', system)
        self.assertNotIn('"preview"', system)

    def test_report_version_is_inferred_when_a_caller_omits_it(self):
        v2 = _v2_example("A")["report"]
        system = build_chat_messages(
            entry_source="report_cta", user_message="hi", report_type="initial", report=v2,
        )[0]["content"]

        self.assertIn("جمله‌ی اصلی گزارش", system)

    def test_open_question_session_context_quotes_the_question_and_states_the_mission(self):
        report = _v2_example("A")["report"]
        system = build_chat_messages(
            entry_source="report_open_question", user_message="hi", report_type="initial",
            report_version="report_v2", report=report,
        )[0]["content"]

        self.assertIn("کاربر از سؤال باز گزارش اولیه وارد گفتگو شده است", system)
        self.assertIn(f"«{report['open_question']['text']}»", system)
        self.assertIn("مأموریت این گفتگو: با جوابش همراه شو", system)

    def _finding_request(self, n=1, **overrides):
        return self._request(**{"entry_source": f"report_finding_focus:{n}", "focus_finding": n, **overrides})

    def test_finding_focus_entry_validates_for_both_findings(self):
        ChatRequest.model_validate(self._finding_request(0))
        ChatRequest.model_validate(self._finding_request(1))

    def test_finding_focus_rules(self):
        with self.assertRaises(ValidationError):  # needs focus_finding
            ChatRequest.model_validate(self._request(entry_source="report_finding_focus:1"))
        with self.assertRaises(ValidationError):  # must match the entry source
            ChatRequest.model_validate(self._finding_request(1, focus_finding=0))
        with self.assertRaises(ValidationError):  # only two findings
            ChatRequest.model_validate(self._request(entry_source="report_finding_focus:2", focus_finding=1))
        with self.assertRaises(ValidationError):  # v1 reports have no findings
            ChatRequest.model_validate(self._finding_request(1, report_version="report_v1"))
        with self.assertRaises(ValidationError):  # belongs only to the finding entry source
            ChatRequest.model_validate(self._request(entry_source="report_cta", focus_finding=1))
        with self.assertRaises(ValidationError):  # needs the report
            ChatRequest.model_validate(self._finding_request(1, report=None, report_type=None, report_version=None))

    def test_finding_focus_session_context_names_the_finding_and_does_not_confine_the_chat(self):
        report = _v2_example("A")["report"]
        for n, ordinal, finding in ((0, "اول", report["findings"][0]), (1, "دوم", report["findings"][1])):
            with self.subTest(finding=n):
                system = build_chat_messages(
                    entry_source=f"report_finding_focus:{n}", user_message="hi", report_type="initial",
                    report_version="report_v2", report=report, focus_finding=n,
                )[0]["content"]
                self.assertIn(f"از یافته‌ی {ordinal} گزارش اولیه", system)
                self.assertIn(f"«{finding['title']}»", system)
                self.assertIn("نه اینکه گفتگو را محدود کرده باشد", system)

    def test_the_questions_rule_is_in_the_static_prompt_for_every_session(self):
        system_a = build_chat_messages(entry_source="manual", user_message="hi")[0]["content"]
        system_b = build_chat_messages(
            entry_source="report_open_question", user_message="hi", report_type="initial",
            report_version="report_v2", report=_v2_example("B")["report"],
        )[0]["content"]

        rule = "این‌ها سؤال‌اند، نه یافته"
        self.assertIn(rule, system_a)
        self.assertIn(rule, system_b)
        # Static part identical => the prompt cache is not split by this rule.
        self.assertEqual(system_a.split("<session_context>")[0].split("<user_memory>")[0][:4000],
                         system_b.split("<session_context>")[0].split("<report>")[0][:4000])

    def test_open_question_without_a_report_is_refused_by_the_prompt_builder(self):
        with self.assertRaises(ValueError):
            build_chat_messages(entry_source="report_open_question", user_message="hi")


class ReportSchemaShareFieldTests(TestCase):
    """report_spec_v1.5 §4.1/§4.3: `share` is optional so today's fewshot examples (which
    don't include it) keep validating, but is captured and threaded through when present."""

    def _report_payload(self, n: int) -> dict:
        example = json.loads((_FEWSHOT_DIR / f"example_{n}.json").read_text(encoding="utf-8"))
        return {"report": example["report"], "system": example["system"]}

    def test_validates_without_share(self):
        output = AIOutput.model_validate(self._report_payload(1))

        self.assertIsNone(output.report.share)

    def test_captures_share_when_present(self):
        payload = self._report_payload(1)
        payload["report"]["share"] = {"hook": "قبل از تصمیم، همه‌چیز را می‌سنجم", "line": "همین دقت باعث می‌شود کمتر پشیمان شوم."}

        output = AIOutput.model_validate(payload)

        self.assertEqual(output.report.share.hook, "قبل از تصمیم، همه‌چیز را می‌سنجم")
        self.assertEqual(output.report.share.line, "همین دقت باعث می‌شود کمتر پشیمان شوم.")


class AiEnabledFlagTests(TestCase):
    def test_defaults_to_true_when_unset(self):
        with patch.dict(os.environ):
            os.environ.pop('REPORT_AI_ENABLED', None)
            self.assertTrue(_ai_enabled())

    def test_false_values_disable_it(self):
        for value in ('false', 'False', 'FALSE', '0', 'no', 'NO'):
            with patch.dict(os.environ, {'REPORT_AI_ENABLED': value}):
                self.assertFalse(_ai_enabled(), f'expected {value!r} to disable it')

    def test_other_values_leave_it_enabled(self):
        for value in ('true', 'True', '1', 'yes', 'anything-else'):
            with patch.dict(os.environ, {'REPORT_AI_ENABLED': value}):
                self.assertTrue(_ai_enabled(), f'expected {value!r} to leave it enabled')


class ReportGenerationClientMockModeTests(TestCase):
    """REPORT_AI_ENABLED=false: skip the real model entirely, for testing the rest of the
    pipeline quickly (e.g. on production) without waiting on -- or paying for -- generation."""

    def test_returns_a_mock_report_without_ever_calling_the_client(self):
        fake_client = _FakeOpenAIClient([])  # empty on purpose -- would IndexError if ever called

        with patch.dict(os.environ, {'REPORT_AI_ENABLED': 'false', 'REPORT_INITIAL_VERSION': 'report_v1'}):
            result = ReportGenerationClient(openai_client=fake_client).generate(_DIMENSION_SCORES)

        self.assertEqual(result['status'], 'ok')
        self.assertEqual(result['report_version'], 'report_v1')
        self.assertIn('summary', result['report'])
        self.assertEqual(len(result['memory_candidates']), 4)
        self.assertEqual(fake_client.completions.calls, [])


class CalculateCostTests(TestCase):
    def test_returns_none_when_model_used_is_none(self):
        self.assertIsNone(calculate_cost(None, input_tokens=1000, output_tokens=1000))

    def test_returns_none_when_model_has_no_configured_price(self):
        self.assertIsNone(calculate_cost('unpriced-model', input_tokens=1000, output_tokens=1000))

    def test_computes_cost_from_configured_price(self):
        ModelPricing.objects.create(
            model_name='gpt-5.4-mini (openai)',
            input_price_per_million=Decimal('2.00'),
            output_price_per_million=Decimal('8.00'),
        )

        cost = calculate_cost('gpt-5.4-mini (openai)', input_tokens=500_000, output_tokens=250_000)

        self.assertEqual(cost, Decimal('1.00') + Decimal('2.00'))

    def test_a_price_change_takes_effect_without_any_code_change(self):
        pricing = ModelPricing.objects.create(
            model_name='gpt-5.4-mini (openai)',
            input_price_per_million=Decimal('2.00'),
            output_price_per_million=Decimal('8.00'),
        )

        pricing.input_price_per_million = Decimal('4.00')
        pricing.save(update_fields=['input_price_per_million'])

        cost = calculate_cost('gpt-5.4-mini (openai)', input_tokens=1_000_000, output_tokens=0)

        self.assertEqual(cost, Decimal('4.00'))

    def test_cached_input_tokens_billed_at_the_cached_rate(self):
        ModelPricing.objects.create(
            model_name='gpt-5.4-mini (openai)',
            input_price_per_million=Decimal('2.00'),
            output_price_per_million=Decimal('8.00'),
            cached_input_price_per_million=Decimal('0.50'),
        )

        # 1M input, 750k of it cached: 250k @ $2 + 750k @ $0.50 + 0 output = 0.50 + 0.375
        cost = calculate_cost(
            'gpt-5.4-mini (openai)', input_tokens=1_000_000, output_tokens=0,
            cached_input_tokens=750_000,
        )

        self.assertEqual(cost, Decimal('0.875'))

    def test_cached_slice_falls_back_to_full_input_rate_when_no_cached_price_configured(self):
        ModelPricing.objects.create(
            model_name='gpt-5.4-mini (openai)',
            input_price_per_million=Decimal('2.00'),
            output_price_per_million=Decimal('8.00'),
        )

        with_cache = calculate_cost(
            'gpt-5.4-mini (openai)', input_tokens=1_000_000, output_tokens=0,
            cached_input_tokens=750_000,
        )
        without_cache = calculate_cost('gpt-5.4-mini (openai)', input_tokens=1_000_000, output_tokens=0)

        self.assertEqual(with_cache, without_cache)

    def test_cached_input_tokens_clamped_to_the_input_total(self):
        ModelPricing.objects.create(
            model_name='gpt-5.4-mini (openai)',
            input_price_per_million=Decimal('2.00'),
            output_price_per_million=Decimal('8.00'),
            cached_input_price_per_million=Decimal('0.50'),
        )

        # cached reported higher than input -> treated as "all cached", never a negative charge
        cost = calculate_cost(
            'gpt-5.4-mini (openai)', input_tokens=1_000_000, output_tokens=0,
            cached_input_tokens=5_000_000,
        )

        self.assertEqual(cost, Decimal('0.50'))


MARKER = "<<<ACTION>>>"

_CHAT_MODEL_ENV = {
    "CHAT_PRIMARY_MODEL": "gpt-5.4-mini",
    "CHAT_BACKUP_MODEL": "gpt-5.4",
    "CHAT_MAX_PRIMARY_ATTEMPTS": "2",
    "CHAT_AI_ENABLED": "true",
}


class _FakeStreamChunk:
    """One chunk.choices[0].delta.content-shaped item, or a usage-only trailer (stream
    _options={'include_usage': True} sends usage on a final chunk with empty choices)."""

    def __init__(self, content=None, usage=None):
        self.choices = [SimpleNamespace(delta=SimpleNamespace(content=content))] if content is not None else []
        self.usage = usage


def _stream(*items):
    """Build a chunk iterator. An Exception in `items` is raised mid-iteration, after the
    chunks before it were already yielded -- simulates a stream that fails partway through."""
    def gen():
        for item in items:
            if isinstance(item, Exception):
                raise item
            yield item
    return gen()


class _FakeStreamingCompletions:
    def __init__(self, streams):
        """streams: list of items, each either an Exception (attempt fails before any chunk)
        or an iterator built by _stream() (attempt streams, maybe failing partway)."""
        self._streams = list(streams)
        self.calls = []

    def create(self, model, messages, stream, stream_options, prompt_cache_key):
        self.calls.append({"model": model, "messages": messages, "prompt_cache_key": prompt_cache_key})
        item = self._streams.pop(0)
        if isinstance(item, Exception):
            raise item
        return item


class _FakeStreamingClient:
    def __init__(self, streams):
        self.completions = _FakeStreamingCompletions(streams)
        self.chat = SimpleNamespace(completions=self.completions)


def _usage(prompt_tokens=100, completion_tokens=20, cached_tokens=0):
    return SimpleNamespace(
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        prompt_tokens_details=SimpleNamespace(cached_tokens=cached_tokens),
    )


class ChatGenerationClientTests(TestCase):
    """apps/ai/chat_generation/client.py -- the real streaming AI pipeline (chat_input
    validation, prompt building, marker-splitting, retry ladder) against a fake
    OpenAI-shaped streaming client, no real network access or API key needed."""

    def setUp(self):
        patcher = patch.dict(os.environ, _CHAT_MODEL_ENV)
        patcher.start()
        self.addCleanup(patcher.stop)

    @staticmethod
    def _manual_payload(**overrides):
        payload = {
            "session_id": "s1", "entry_source": "manual", "user_message": "سلام",
        }
        payload.update(overrides)
        return payload

    @staticmethod
    def _action_payload(**overrides):
        payload = {
            "session_id": "s1", "entry_source": "action_completed", "user_message": "انجامش دادم",
            "action_context": {
                "current": {
                    "text": "امشب به سارا پیام بده",
                    "deadline_type": "tonight", "deadline_text": "امشب", "status": "done",
                },
            },
        }
        payload.update(overrides)
        return payload

    def test_ordinary_reply_returns_message_with_no_action(self):
        client = _FakeStreamingClient([_stream(
            _FakeStreamChunk("سلام، چطوری؟"), _FakeStreamChunk(None, usage=_usage()),
        )])

        chunks = list(ChatGenerationClient(client).generate_stream(self._manual_payload()))
        done = chunks[-1]

        self.assertEqual(done["type"], "done")
        self.assertIsNone(done["proposed_action"])
        self.assertEqual(done["message"], "سلام، چطوری؟")

    def test_marker_splits_into_message_and_proposed_action(self):
        action_json = (
            '{"text": "فردا صبح ۲۰ دقیقه روی آن فایل کار کن", "deadline_text": "فردا صبح", '
            '"deadline_type": "tomorrow_morning", "substeps": null}'
        )
        client = _FakeStreamingClient([_stream(
            _FakeStreamChunk(f"باشه، قدم بعدی{MARKER}{action_json}"),
            _FakeStreamChunk(None, usage=_usage()),
        )])

        chunks = list(ChatGenerationClient(client).generate_stream(self._action_payload()))
        done = chunks[-1]

        self.assertEqual(done["message"], "باشه، قدم بعدی")
        self.assertEqual(done["proposed_action"]["deadline_type"], "tomorrow_morning")
        # delta chunks never carry the marker or the JSON after it
        deltas = "".join(c["text"] for c in chunks if c["type"] == "delta")
        self.assertNotIn(MARKER, deltas)
        self.assertNotIn("deadline_type", deltas)

    def test_malformed_json_after_marker_drops_action_but_keeps_message(self):
        client = _FakeStreamingClient([_stream(
            _FakeStreamChunk(f"باشه{MARKER}not valid json"),
            _FakeStreamChunk(None, usage=_usage()),
        )])

        chunks = list(ChatGenerationClient(client).generate_stream(self._action_payload()))
        done = chunks[-1]

        self.assertEqual(done["message"], "باشه")
        self.assertIsNone(done["proposed_action"])

    def test_generation_meta_reports_usage(self):
        client = _FakeStreamingClient([_stream(
            _FakeStreamChunk("سلام"),
            _FakeStreamChunk(None, usage=_usage(prompt_tokens=11000, completion_tokens=40, cached_tokens=10800)),
        )])

        chunks = list(ChatGenerationClient(client).generate_stream(self._manual_payload()))
        meta = chunks[-1]["generation_meta"]

        self.assertEqual(meta["model_used"], "gpt-5.4-mini (openai)")
        self.assertEqual(meta["attempts"], 1)
        self.assertEqual(meta["input_tokens"], 11000)
        self.assertEqual(meta["cached_input_tokens"], 10800)
        self.assertEqual(meta["output_tokens"], 40)

    def test_retries_before_first_delta_then_succeeds(self):
        client = _FakeStreamingClient([
            ConnectionError("cold connect timed out"),
            _stream(_FakeStreamChunk("سلام"), _FakeStreamChunk(None, usage=_usage())),
        ])

        chunks = list(ChatGenerationClient(client).generate_stream(self._manual_payload()))

        self.assertEqual(chunks[-1]["generation_meta"]["attempts"], 2)
        self.assertEqual(len(client.completions.calls), 2)

    def test_failure_after_delta_is_raised_not_retried(self):
        client = _FakeStreamingClient([_stream(
            _FakeStreamChunk("نیمه‌ی اول پاسخ"), ConnectionError("dropped mid-stream"),
        )])

        with self.assertRaises(ConnectionError):
            list(ChatGenerationClient(client).generate_stream(self._manual_payload()))

        # a retry here would duplicate text already shown to the user -- only one call made
        self.assertEqual(len(client.completions.calls), 1)

    def test_all_attempts_failing_raises(self):
        client = _FakeStreamingClient([
            ConnectionError("1"), ConnectionError("2"), ConnectionError("3"), ConnectionError("4"),
        ])

        with self.assertRaises(RuntimeError):
            list(ChatGenerationClient(client).generate_stream(self._manual_payload()))

        # primary x2 + openai backup + avalai backup, per _CHAT_MODEL_ENV
        self.assertEqual(len(client.completions.calls), 4)

    def test_ai_disabled_returns_mock(self):
        with patch.dict(os.environ, {"CHAT_AI_ENABLED": "false"}):
            chunks = list(ChatGenerationClient().generate_stream(self._manual_payload()))

        self.assertEqual(chunks[-1]["generation_meta"]["model_used"], "mock")

    def test_invalid_payload_raises_validation_error(self):
        # action_completed requires action_context.current -- chat_input.ChatRequest's job is
        # to catch exactly this before it ever reaches the prompt.
        payload = self._manual_payload(entry_source="action_completed")

        with self.assertRaises(ValidationError):
            list(ChatGenerationClient().generate_stream(payload))

    def test_action_active_accepts_a_still_pending_step(self):
        # action_active is the person coming back to talk about a step they already accepted,
        # before its deadline -- unlike the other three action entry sources, status must be
        # pending, not done/not_done/partial.
        client = _FakeStreamingClient([_stream(
            _FakeStreamChunk("باشه، بگو کجا گیر کردی"), _FakeStreamChunk(None, usage=_usage()),
        )])
        payload = self._action_payload(
            entry_source="action_active",
            action_context={
                "current": {
                    "text": "امشب به سارا پیام بده",
                    "deadline_type": "tonight", "deadline_text": "امشب", "status": "pending",
                },
            },
        )

        chunks = list(ChatGenerationClient(client).generate_stream(payload))

        self.assertEqual(chunks[-1]["message"], "باشه، بگو کجا گیر کردی")


# ==========================================================================
# Deep (150-item) report -- the eight-call pipeline
# ==========================================================================

from apps.ai.deep_report_generation.client import DeepReportGenerationClient  # noqa: E402
from apps.ai.deep_report_generation.facet_vocabulary import DOMAIN_NAMES as _DEEP_DOMAIN_NAMES  # noqa: E402

_DEEP_EX_DIR = Path(__file__).resolve().parent / "deep_report_generation" / "fewshot"
_DEEP_A = json.loads((_DEEP_EX_DIR / "example_deep_A.json").read_text(encoding="utf-8"))

_DEEP_MODEL_ENV = {
    "DEEP_REPORT_AI_ENABLED": "true",
    "DEEP_REPORT_PRIMARY_MODEL": "gpt-5.4-mini",
    "DEEP_REPORT_BACKUP_MODEL": "gpt-5.4",
    "DEEP_REPORT_MAX_PRIMARY_ATTEMPTS": "2",
}

_DEEP_TOPIC_KEYS = (
    "decision_style", "communication_style", "work_style",
    "stress_and_energy", "learning_and_growth", "close_relationships",
)
_DEEP_CLOSING_KEYS = (
    "identity_line", "top_strengths", "growth_priorities", "confidence_note",
    "domains_overview", "integrated_interpretation", "strengths", "blind_spots",
    "closing", "share", "pattern_tags",
)


def _deep_payload():
    return {
        "report_type": "deep",
        "facet_scores": [
            {"code": f["code"], "score": 55, "level": f["level"]}
            for d in _DEEP_A["domains"] for f in d["facets"]
        ],
        "domain_scores": [
            {"code": o["code"], "score": 55, "level": o["level"]}
            for o in _DEEP_A["domains_overview"]
        ],
        "active_patterns": [],
        "context_profile": {},
    }


def _deep_partial_for(messages):
    """Return the correct partial (as a JSON string) for whichever of the eight calls this
    is, sliced straight out of example_deep_A -- a known-valid whole report."""
    content = messages[-1]["content"]
    if "identity_line" in content:
        return json.dumps({k: _DEEP_A[k] for k in _DEEP_CLOSING_KEYS}, ensure_ascii=False)
    for d in _DEEP_A["domains"]:
        if f'عامل «{_DEEP_DOMAIN_NAMES[d["code"]]}»' in content:
            return json.dumps(d, ensure_ascii=False)
    # a topic group -- return exactly the pages this call asked for
    pages = [k for k in _DEEP_TOPIC_KEYS if f'"{k}":' in content]
    return json.dumps({k: _DEEP_A[k] for k in pages}, ensure_ascii=False)


class _FakeDeepCompletions:
    def __init__(self):
        self.calls = []

    def create(self, model, messages, **kwargs):
        self.calls.append({"model": model, "messages": messages, "kwargs": kwargs})
        return SimpleNamespace(
            choices=[SimpleNamespace(message=SimpleNamespace(
                content=_deep_partial_for(messages)))],
            usage=SimpleNamespace(
                prompt_tokens=100, completion_tokens=200,
                prompt_tokens_details=SimpleNamespace(cached_tokens=30),
            ),
        )


class _FakeDeepClient:
    def __init__(self):
        self.completions = _FakeDeepCompletions()
        self.chat = SimpleNamespace(completions=self.completions)


class DeepReportGenerationClientTests(TestCase):
    def setUp(self):
        patcher = patch.dict(os.environ, _DEEP_MODEL_ENV)
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_disabled_flag_serves_the_mock(self):
        with patch.dict(os.environ, {"DEEP_REPORT_AI_ENABLED": "false"}):
            result = DeepReportGenerationClient().generate(_deep_payload())
        self.assertEqual(result["generation_meta"]["model_used"], "mock")

    def test_eight_calls_assemble_into_one_report(self):
        fake = _FakeDeepClient()

        result = DeepReportGenerationClient(openai_client=fake).generate(_deep_payload())

        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["report_version"], "deep_v1")
        self.assertEqual(len(fake.completions.calls), 8)
        self.assertEqual(len(result["report"]["domains"]), 5)
        self.assertEqual(result["system"]["pattern_tags"], _DEEP_A["pattern_tags"])
        self.assertEqual(result["generation_meta"]["cached_input_tokens"], 8 * 30)

    def test_one_failing_call_fails_the_whole_report(self):
        fake = _FakeDeepClient()
        fake.completions.create = lambda model, messages, **kw: (_ for _ in ()).throw(
            RuntimeError("provider down"))

        result = DeepReportGenerationClient(openai_client=fake).generate(_deep_payload())

        self.assertEqual(result["status"], "error")
        self.assertEqual(result["error"]["code"], "generation_failed")

    def test_real_levels_pass_through_to_the_payload(self):
        payload = _deep_payload()
        DeepReportGenerationClient(openai_client=_FakeDeepClient()).generate(payload)
        # facet_scores in the payload are what the prompt builder sees -- unchanged by us
        self.assertEqual(len(payload["facet_scores"]), 30)

    def test_a_miscopied_level_is_corrected_from_the_scores(self):
        """Levels belong to the backend (deep_report_spec_v1_2.md §2), and the schema cannot catch the
        model copying one wrong -- low/mid/high are all valid whichever facet they land on.
        The fake returns example A's own levels (a mix); the payload says every facet is low,
        so every level in the assembled report must come out low."""
        payload = _deep_payload()
        for facet in payload["facet_scores"]:
            facet["score"], facet["level"] = 10, "low"
        for domain in payload["domain_scores"]:
            domain["score"], domain["level"] = 10, "low"

        result = DeepReportGenerationClient(openai_client=_FakeDeepClient()).generate(payload)

        self.assertEqual(result["status"], "ok")
        report = result["report"]
        self.assertEqual(
            {f["level"] for d in report["domains"] for f in d["facets"]}, {"low"},
        )
        self.assertEqual({o["level"] for o in report["domains_overview"]}, {"low"})
