"""One place that builds OpenAI-compatible clients, shared by every AI service.

Two settings here are not the SDK defaults, and both matter on this deployment's network:

`connect` timeout -- the SDK default is 5s. A cold TLS handshake to api.openai.com from here
measured ~21s (warm reconnects are ~2s), so a 5s connect budget fails every time the pooled
connection has gone idle and closed. That is exactly the "first message works, the rest time
out" symptom.

`max_retries=0` -- the SDK retries twice by default, which multiplies against the attempt
ladder each service already runs (3 SDK tries x 3-4 attempts = up to 12 requests, ~45s of
the user staring at nothing). Retries belong to the ladder, in one place, not both.

Clients are cached per provider: each carries its own connection pool, and rebuilding one per
request would pay the cold-connect cost above on every single message.
"""

from __future__ import annotations

import os
from functools import lru_cache

# provider -> (api_key env var, base_url env var, official default base_url).
# Both are OpenAI-compatible chat.completions endpoints -- only these two values change.
PROVIDERS = {
    "openai": ("OPENAI_API_KEY", "OPENAI_BASE_URL", "https://api.openai.com/v1"),
    "avalai": ("AVALAI_API_KEY", "AVALAI_BASE_URL", "https://api.avalai.ir/v1"),
}


def _timeout():
    import httpx

    return httpx.Timeout(
        connect=float(os.getenv("AI_CONNECT_TIMEOUT", "30")),
        read=float(os.getenv("AI_READ_TIMEOUT", "90")),
        write=30.0,
        pool=30.0,
    )


@lru_cache(maxsize=None)
def client_for(provider: str):
    from openai import OpenAI

    api_key_env, base_url_env, default_base_url = PROVIDERS[provider]

    # The openai SDK also reads *_BASE_URL-shaped env vars itself in some versions,
    # independent of what's passed here -- and treats "present but empty" (which is
    # exactly what docker-compose's env_file gives an unset-but-declared .env line)
    # differently from "absent", never falling back to its own default. Passing a
    # concrete string here always wins over any such SDK-internal env lookup.
    base_url = os.getenv(base_url_env) or default_base_url

    return OpenAI(
        api_key=os.getenv(api_key_env),
        base_url=base_url,
        timeout=_timeout(),
        max_retries=0,
    )
