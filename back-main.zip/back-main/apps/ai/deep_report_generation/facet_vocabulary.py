"""Persian names for the 30 facets, the 5 domains, the 3 levels, and the 6 topic pages.

WHY THIS IS ITS OWN FILE
-------------------------
The deep report prompt needs these so the model writes «اضطراب» rather than «N1». The names
are the contract with deep_report_spec section 1.1 -- if a name changes there it changes
here, once. The same labels also appear (privately) in apps.ai.chat_generation.prompt for
rendering a deep report into a conversation; the two must not drift, and the assertion at
the bottom of this module is the guard against a facet being added to the schema without a
name here -- it fails at import rather than rendering as a bare code.
"""

from __future__ import annotations

from apps.ai.deep_report_generation.structure import SECTION_TOPICS

FACET_NAMES: dict[str, str] = {
    "N1": "اضطراب", "N2": "خشم و تحریک‌پذیری", "N3": "گرایش به دلسردی",
    "N4": "حساسیت به قضاوت اجتماعی", "N5": "تکانشگری", "N6": "آسیب‌پذیری در برابر فشار",
    "E1": "گرمی و صمیمیت", "E2": "معاشرت‌جویی", "E3": "ابراز وجود",
    "E4": "سطح فعالیت", "E5": "هیجان‌خواهی", "E6": "هیجان‌های مثبت",
    "O1": "تخیل", "O2": "حساسیت زیبایی‌شناختی", "O3": "گشودگی به احساسات",
    "O4": "تنوع در تجربه", "O5": "کنجکاوی فکری", "O6": "انعطاف در باورها",
    "A1": "اعتماد", "A2": "صراحت", "A3": "نوع‌دوستی",
    "A4": "سبک مواجهه با تعارض", "A5": "فروتنی", "A6": "حساسیت انسانی",
    "C1": "احساس کفایت", "C2": "نظم", "C3": "تعهد و وظیفه‌شناسی",
    "C4": "پیشرفت‌طلبی", "C5": "خودانضباطی", "C6": "سنجیدگی",
}

DOMAIN_NAMES: dict[str, str] = {
    "N": "واکنش‌پذیری هیجانی",
    "E": "برون‌گرایی",
    "O": "گشودگی",
    "A": "توافق‌پذیری",
    "C": "وظیفه‌شناسی",
}

LEVEL_NAMES: dict[str, str] = {"low": "پایین", "mid": "میانه", "high": "بالا"}

# Titles of the six topic pages (deep_report_spec_v1_2.md §9). Kept aligned with
# apps.ai.chat_generation.prompt._SECTION_LABELS.
PAGE_TITLES: dict[str, str] = {
    "decision_style": "سبک تصمیم‌گیری",
    "communication_style": "سبک ارتباطی",
    "work_style": "سبک کاری و رهبری",
    "stress_and_energy": "استرس، انرژی و بازیابی",
    "learning_and_growth": "یادگیری و رشد",
    "close_relationships": "روابط نزدیک",
}


def _check() -> None:
    from apps.ai.deep_report_generation.schema import FACET_CODES

    missing = [c for c in FACET_CODES if c not in FACET_NAMES]
    extra = [c for c in FACET_NAMES if c not in FACET_CODES]
    if missing or extra:
        raise RuntimeError(
            f"facet vocabulary out of sync with the schema: missing={missing} extra={extra}"
        )
    if set(PAGE_TITLES) != set(SECTION_TOPICS):
        raise RuntimeError("PAGE_TITLES out of sync with structure.SECTION_TOPICS")


_check()
