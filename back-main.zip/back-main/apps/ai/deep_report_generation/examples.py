"""Golden examples for the deep report, and the slicing logic that decides what each of the
eight calls sees (deep_report_spec_v1_2.md §5).

Two complete reports of one coherent person each live in fewshot/example_deep_A.json and
fewshot/example_deep_B.json:

A: strong internal tension -- Conscientiousness high, several facets at the extremes. Shows
   how to write intensity and how to name a contradiction between two facets in one domain.
B: every one of the 30 facets at mid. The hardest case for the model: with no dominant
   trait it drifts into horoscope prose, so B demonstrates that a flat profile still has
   findings -- about pattern and consequence rather than intensity.

WHAT EACH CALL SEES
-------------------
Never the whole report. A domain call gets one domain from each example (and never the
domain it is writing -- showing the N example to the N call produces copied content instead
of learned shape); a topic call gets the matching pages; the closing call gets the closing
bundles.
"""

from __future__ import annotations

import json
from pathlib import Path

_DIR = Path(__file__).parent / "fewshot"

_A = json.loads((_DIR / "example_deep_A.json").read_text(encoding="utf-8"))
_B = json.loads((_DIR / "example_deep_B.json").read_text(encoding="utf-8"))

EXAMPLES = {"A": _A, "B": _B}

# Which domain each example contributes when a given domain is being written. Both entries
# differ from the target, so neither example can be copied wholesale.
_SUBSTITUTE = {"N": ("C", "E"), "E": ("C", "N"), "O": ("C", "N"),
               "A": ("C", "N"), "C": ("E", "N")}


def _domain(report: dict, code: str) -> dict:
    return next(d for d in report["domains"] if d["code"] == code)


def domain_examples(target_domain: str) -> list[dict]:
    """One domain from each example report, neither of them the target."""
    a_code, b_code = _SUBSTITUTE[target_domain]
    return [_domain(_A, a_code), _domain(_B, b_code)]


def topic_examples(pages: tuple[str, ...]) -> list[dict]:
    """The requested pages from each example -- only the pages this call is writing."""
    return [{p: r[p] for p in pages} for r in (_A, _B)]


_CLOSING_KEYS = (
    "identity_line", "top_strengths", "growth_priorities", "confidence_note",
    "domains_overview", "integrated_interpretation", "strengths", "blind_spots",
    "closing", "share", "pattern_tags",
)


def closing_examples() -> list[dict]:
    """The closing bundle from each example, without the domain and topic sections."""
    return [{k: r[k] for k in _CLOSING_KEYS} for r in (_A, _B)]
