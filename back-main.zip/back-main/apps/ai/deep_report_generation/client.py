"""Public entry point for the deep-report AI pipeline (deep_report_spec_v1_2.md §4 request / §6 response).

This is the boundary consuming apps depend on: a §4-shaped payload in, a §6-shaped dict out.
It mirrors apps.ai.report_generation.client.ReportGenerationClient, and like that one it
knows nothing about attempts, demographics rows or any other consumer's domain -- that
translation belongs in the consumer's adapter (apps.report.services.deep_ai_report_client).

DEEP_REPORT_AI_ENABLED (default false): when off, `generate()` serves a fixed mock so
everything downstream of the boundary (the Celery task, the DB writes, the API shape, memory
persistence, level rendering) is exercisable end to end without a model and without a bill.
When on, it runs the eight-call pipeline in apps.ai.deep_report_generation.generate.

It defaults to false, not true like the initial report's flag: the eight-call prompts are
still a draft and have not been through eval. Flip DEEP_REPORT_AI_ENABLED=true (and add it
as a CI/CD variable, see docs/infrastructure.md) once they have.
"""

import json
import logging
import os
import time
from pathlib import Path

from apps.ai.deep_report_generation.generate import generate_deep_report
from apps.ai.deep_report_generation.schema import DeepProfileInput

logger = logging.getLogger(__name__)

# Public so tests can assert on the fixture's shape without recomputing a relative path.
MOCK_PATH = Path(__file__).parent / "mock" / "deep_report_mock.json"

REPORT_VERSION = "deep_v1"


def _ai_enabled() -> bool:
    return (os.getenv("DEEP_REPORT_AI_ENABLED") or "false").strip().lower() not in ("false", "0", "no")


class DeepReportGenerationClient:
    def __init__(self, openai_client=None):
        # Optional injected OpenAI-shaped client -- lets tests avoid real network calls.
        # None means generate_deep_report() builds the real client itself, lazily.
        self._openai_client = openai_client

    # ---- mock path -------------------------------------------------------

    @staticmethod
    def _load_mock() -> dict:
        return json.loads(MOCK_PATH.read_text(encoding="utf-8"))

    @staticmethod
    def _apply_real_levels(report: dict, payload: dict) -> None:
        """Overwrite the fixture's placeholder levels with this user's actual ones.

        The mock's prose is fixed and not personalised. The levels are different: they come
        from the backend's own deterministic scoring (§2), so carrying the real ones through
        costs nothing and makes the end-to-end check meaningful.
        """
        facet_levels = {f["code"]: f["level"] for f in payload.get("facet_scores", [])}
        domain_levels = {d["code"]: d["level"] for d in payload.get("domain_scores", [])}

        for overview in report.get("domains_overview", []):
            if overview["code"] in domain_levels:
                overview["level"] = domain_levels[overview["code"]]

        for domain in report.get("domains", []):
            for facet in domain.get("facets", []):
                if facet["code"] in facet_levels:
                    facet["level"] = facet_levels[facet["code"]]

    def _mock_response(self, payload: dict) -> dict:
        # DEEP_REPORT_MOCK_DELAY_MS (default 0, today's exact instant behavior) optionally
        # simulates the real eight-call pipeline's latency -- runs inside a Celery task
        # (apps/report/tasks.py), so this is for exercising worker occupancy duration under
        # CELERY_WORKER_CONCURRENCY (known issue #21) during a load test, not web-tier
        # connection effects. See loadtest/README.md.
        delay_ms = int(os.getenv("DEEP_REPORT_MOCK_DELAY_MS", "0"))
        if delay_ms > 0:
            time.sleep(delay_ms / 1000)

        mock = self._load_mock()
        report = mock["report"]
        self._apply_real_levels(report, payload)
        logger.warning(
            "DEEP_REPORT_AI_ENABLED=false -- returning the fixed mock report "
            "(%d facets, %d active patterns in payload)",
            len(payload.get("facet_scores", [])), len(payload.get("active_patterns", [])),
        )
        return {
            "status": "ok",
            "report_version": REPORT_VERSION,
            "report": report,
            "system": mock["system"],
            # model_used="mock" keeps cost accounting honest: apps.ai.pricing has no price
            # for it, so calculate_cost returns None rather than inventing a number.
            "generation_meta": {
                "model_used": "mock",
                "attempts": 0,
                "input_tokens": 0,
                "cached_input_tokens": 0,
                "output_tokens": 0,
                "latency_s": 0.0,
            },
        }

    # ---- real path ------------------------------------------------------

    def _real_response(self, payload: dict) -> dict:
        profile = DeepProfileInput.model_validate(payload)
        response = generate_deep_report(profile, client=self._openai_client)

        meta = response.generation_meta.model_dump() if response.generation_meta else None
        if meta is not None:
            # per_call is useful in logs but not part of the §6 contract the consumer reads.
            per_call = meta.pop("per_call", None)
            logger.info("deep ai per-call outcomes: %s", per_call)
        logger.info("deep ai generation_meta: %s", meta)

        result = {"status": response.status, "report_version": REPORT_VERSION}
        if response.status == "ok":
            result["report"] = response.report.model_dump()
            result["system"] = response.system or {}
        else:
            result["error"] = {
                "code": response.error.code,
                "user_message": response.error.user_message,
            }
        result["generation_meta"] = meta
        return result

    # ---- boundary ------------------------------------------------------

    def generate(self, payload: dict) -> dict:
        """payload: deep_report_spec_v1_2.md §4 -- report_type, facet_scores (30), domain_scores (5),
        active_patterns, context_profile. Never contains Core Domain Raw (§2.3).

        Returns a §6-shaped dict: status ok/error, report_version, report, system,
        generation_meta. `memory_candidates` is deliberately absent -- the backend derives
        those from the report's own fields (§6.3), no model call involved.
        """
        if not _ai_enabled():
            return self._mock_response(payload)
        return self._real_response(payload)
