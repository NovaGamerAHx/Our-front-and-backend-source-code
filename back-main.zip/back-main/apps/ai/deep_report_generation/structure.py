"""The deep report's output contract (deep_report_spec_v1_2.md §6.1) as data.

Kept separate from any prompt or model code because three different things need it: the mock
generator, the tests that guard the mock from drifting, and — once the real 8-call generation
lands — its response validation. Encoding it once keeps those three from disagreeing.

The `topic` values below are fixed product copy, not model output. §6.1: the model fills in
`text` only, and the topics must appear verbatim and in this exact order, because pages 11–16
are one repeated UI component driven by these rows (§9).
"""

DOMAIN_ORDER = ["N", "E", "O", "A", "C"]

FACETS_PER_DOMAIN = 6
DOMAIN_COUNT = 5

# field -> exact item count
EXACT_COUNTS = {
    "top_strengths": 3,
    "growth_priorities": 3,
    "domains_overview": 5,
    "domains": 5,
    # Five, not three: the report template's strengths page has five rows (§6.1).
    "strengths.items": 5,
    "blind_spots.reflection_questions": 3,
    "closing.small_actions": 3,
}

# field -> (min, max)
RANGE_COUNTS = {
    "blind_spots.items": (2, 4),
}

# The six themed pages (§9 pages 11-16), each a fixed topic list plus a closing block.
SECTION_TOPICS = {
    "decision_style": [
        "سرعت در برابر سنجیدگی",
        "تحمل ابهام",
        "اثر هیجان و فشار",
        "ریسک‌پذیری",
        "بازنگری در فرض‌ها",
        "نقطه توقف تحلیل",
    ],
    "communication_style": [
        "گرمی و نزدیکی",
        "میزان نیاز به تعامل",
        "قاطعیت",
        "اعتماد اولیه",
        "صراحت",
        "واکنش در تعارض",
        "همدلی و ملاحظه انسانی",
    ],
    "work_style": [
        "ساختار و نظم",
        "هدف‌گذاری و جاه‌طلبی",
        "تصمیم و اختیار",
        "تعامل تیمی",
        "نوآوری و تغییر",
        "واگذاری و اعتماد",
    ],
    "stress_and_energy": [
        "محرک فشار",
        "کشش به پاداش فوری",
        "منابع انرژی اجتماعی",
        "منابع انرژی شناختی",
        "بازیابی از فشار",
    ],
    "learning_and_growth": [
        "شیوه ترجیحی یادگیری",
        "پذیرش تجربه تازه",
        "عمق کنجکاوی",
        "بازنگری باورها",
        "تبدیل یادگیری به اجرا",
        "موانع رشد",
    ],
    "close_relationships": [
        "نزدیکی عاطفی",
        "اعتماد",
        "کمک و مراقبت",
        "مرزبندی و قاطعیت",
        "نیاز به دیده‌شدن",
    ],
}
