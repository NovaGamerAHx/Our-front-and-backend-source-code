"""Prompts for the eight calls that produce the deep report (deep_report_spec_v1_2.md §5).

STATUS: draft, untested. Not yet run through eval.

CACHE LAYOUT -- THE REASON THE SYSTEM MESSAGE IS IDENTICAL EVERY TIME
----------------------------------------------------------------------
All eight calls send the *same* system message, byte for byte. Everything that varies --
which domain, which pages, which prior output -- goes in the user message. Prompt caching
matches on an exact prefix, so an identical system message is written to cache once and read
cheaply by the other seven calls (and by every other user's report inside the cache window).
Move one word of per-call instruction into the system message and that call misses the cache.

THE EIGHT CALLS
---------------
    1-5  one per domain: six facets + a domain summary
    6    pages 11-13   (decision, communication, work)
    7    pages 14-16   (stress, learning, relationships)
    8    everything needing the whole picture -- runs last, reads 1-7's output
"""

from __future__ import annotations

import json

from apps.ai.deep_report_generation.examples import (
    closing_examples,
    domain_examples,
    topic_examples,
)
from apps.ai.deep_report_generation.facet_vocabulary import (
    DOMAIN_NAMES,
    FACET_NAMES,
    LEVEL_NAMES,
    PAGE_TITLES,
)
from apps.ai.deep_report_generation.schema import DeepProfileInput
from apps.ai.deep_report_generation.structure import SECTION_TOPICS
from apps.ai.prompts import punctuation_rules, safety_rules, step_quality_rules

TOPIC_GROUP_A = ("decision_style", "communication_style", "work_style")
TOPIC_GROUP_B = ("stress_and_energy", "learning_and_growth", "close_relationships")


# --------------------------------------------------------------------------
# Static system message -- identical for all eight calls
# --------------------------------------------------------------------------

_ROLE = r"""You are a Persian-language personal development writer. You are producing one
section of a long profile built from a 150-item personality questionnaire. You always write
in Persian.

Tone: warm, direct, concrete. Address the reader as «تو». Write like someone who read their
answers carefully — not a clinician, not a coach with something to sell.

The document is called «پروفایل توسعه فردی». It is not a test result and not a diagnosis, and
nothing you write may suggest otherwise."""


# §8 of the spec, with one correction the spec itself requires: it defines high/low against
# T-scores after norming, and norming has not happened. Passing that through unchanged would
# ask the model to do something impossible, so the constraint is stated instead.
_INTERPRETATION_LOGIC = r"""## How to interpret

- **No trait is good or bad in itself.** Its value depends on intensity, situation, and how
  it combines with the rest. Never write a facet as an asset or a defect.
- **Facet scores carry the behavioural detail; domain scores carry the overall picture.**
- **Recommendations come from combinations**, not from a single score in isolation.

⚠️ **Norming has not been done.** There is no T-score and no percentile for this instrument
yet, so «بالا» and «پایین» here are *relative description only* — they say where this person
sits among their own traits, never where they sit among other people. Never write a
normative verdict, and never compare to others, to an average, or to "typical".

## Rules for everything you write

- **Never write a number.** No score, no percentage, no percentile, no «از ۱۰۰». The scores
  you are given are input to your reasoning and must not appear in the output.
- **Never write a facet code.** The reader sees «اضطراب», never «N1». Codes appear in your
  input and in the JSON keys; they never appear inside a Persian sentence.
- **Every facet gets both halves, weighted the same.** «وقتی خوب کار می‌کند» and «وقتی هزینه
  می‌سازد» are two true things, not a positive and a caveat. If one runs long and the other
  is a clause, you have written a verdict.
- **Blind spots are behavioural probabilities, not rulings.** «ممکن است در این موقعیت…»,
  never «تو این‌طوری هستی».
- **Every strength arrives with its overused form.** A strength without its cost is praise,
  not analysis.
- Hedged language: «به نظر می‌رسد»، «ممکن است»، «بر اساس پاسخ‌هایت».
- Forbidden: «همیشه»، «هیچ‌وقت»، «قطعاً»، «نتیجه‌ی قطعی».

## Output

Return one JSON object and nothing else — no prose before or after, no markdown fence. It
must be strictly valid JSON: double-quoted keys and strings, no trailing commas, no
comments, no «...». Every field named in the request must be present. Use the exact English
tokens the request gives for `code` and `level` fields — never their Persian labels."""


def build_static_system() -> str:
    """The system message. Identical for all eight calls -- see the module docstring."""
    return "\n\n".join([_ROLE, safety_rules(), punctuation_rules(), _INTERPRETATION_LOGIC])


# --------------------------------------------------------------------------
# User-message helpers
# --------------------------------------------------------------------------

# Which facet groups feed each topic page, from the report template. Given per page so the
# model reasons from the intended evidence rather than whatever looks related -- a row must
# come from the same facets in every report or two profiles stop being comparable.
_PAGE_EVIDENCE: dict[str, str] = {
    "decision_style": "N1، N5، N6، O5، O6، C6",
    "communication_style": "E1، E2، E3، E4، A1، A2، A4، A6، N2",
    "work_style": "C1، C2، C4، C5، C6، E2، E3، O4، O5، O6، A1، A4",
    "stress_and_energy": "N1، N2، N4، N6، N5، E2، E6، O4، O5، ترکیب N و C",
    "learning_and_growth": "O و C، و در صورت لزوم N",
    "close_relationships": "E1، E3، E6، O3، A1، A3، A4، A5، A6",
}


def _example_block(payloads: list[dict], note: str) -> str:
    """Render the golden example slices for one call -- only the slice this call needs.

    Two examples rather than one: a high-tension profile and a completely flat one, so the
    pair shows both how to write intensity and how to write its absence. A single example
    teaches the model to reproduce that example's register regardless of the profile in
    front of it.
    """
    parts = [
        "دو نمونه‌ی هدف، از دو پروفایل متفاوت. ساختار، طول و لحن را از آن‌ها بردار — "
        f"محتوا را نه ({note}):"
    ]
    for i, payload in enumerate(payloads, start=1):
        parts.append(f"\n— نمونه‌ی {i} —\n" + json.dumps(payload, ensure_ascii=False, indent=2))
    return "\n".join(parts)


def _facet_line(f) -> str:
    # The English `level` token is shown explicitly: it is what must be copied verbatim into
    # any `level` field of the output. The Persian label and the 0-100 score are context for
    # judging intensity only and must never appear in generated prose.
    return f"- {FACET_NAMES[f.code]} ({f.code}): level={f.level} ({LEVEL_NAMES[f.level]})، شدت {f.score}"


def _patterns_block(profile: DeepProfileInput) -> str:
    if not profile.active_patterns:
        return "الگوی ترکیبی فعالی برای این فرد شناسایی نشده است."
    items = "\n".join(f"- {p}" for p in profile.active_patterns)
    return (
        "الگوهای ترکیبی فعال (توسط سیستم محاسبه شده، نه توسط تو):\n" + items +
        "\nاین‌ها فرضیه‌اند، نه مقیاس رسمی. با زبان احتمالی درباره‌شان بنویس."
    )


def _context_block(profile: DeepProfileInput) -> str:
    if not profile.context_profile:
        return ""
    ctx = profile.context_profile.model_dump(exclude_none=True)
    if not ctx:
        return ""
    return (
        "زمینه‌ی فرد: " + json.dumps(ctx, ensure_ascii=False) +
        "\nاین فقط بر لحن و مصداق مثال‌ها اثر می‌گذارد، نه بر تفسیر نمره‌ها."
    )


# --------------------------------------------------------------------------
# Calls 1-5 -- one domain each
# --------------------------------------------------------------------------

def build_domain_user(profile: DeepProfileInput, domain: str) -> str:
    """User message for one domain. Only this domain's six facets are included -- it keeps
    the variable part small and stops the model reaching for evidence from another domain.
    active_patterns is deliberately absent for the same reason; patterns belong to calls
    6-8."""
    facets = profile.facets_for(domain)
    dom = next(d for d in profile.domain_scores if d.code == domain)
    name = DOMAIN_NAMES[domain]

    return f"""بخشی که الان می‌نویسی: عامل «{name}».

نمره‌ی کلی این عامل: {LEVEL_NAMES[dom.level]} — {dom.score}

شش خرده‌ویژگی این عامل:
{chr(10).join(_facet_line(f) for f in facets)}

{_context_block(profile)}

برای هر شش خرده‌ویژگی بنویس:
- `when_it_works` — این ویژگی در کدام موقعیت‌ها به این فرد کمک می‌کند
- `when_it_costs` — در کدام موقعیت‌ها برایش هزینه می‌سازد

و یک `summary` برای کل عامل که ترکیب این شش را در یک تصویر جمع کند. اگر بین خرده‌ویژگی‌ها
تنشی هست — مثلاً یکی بالا و دیگری پایین — همان‌جا نامش را ببر، آن تنش معمولاً جالب‌ترین
چیز این صفحه است.

فقط درباره‌ی همین عامل بنویس. به عامل‌های دیگر ارجاع نده.

{_example_block(domain_examples(domain), "هر دو نمونه از عاملی غیر از عامل تست")}

قالب خروجی:
{{"code": "{domain}",
  "facets": [{{"code": "...", "level": "...", "when_it_works": "...", "when_it_costs": "..."}}],
  "summary": "..."}}

`facets` دقیقاً شش آیتم، به همان ترتیب بالا. `code` را عیناً از ورودی بردار. `level` باید
دقیقاً یکی از `low` / `mid` / `high` باشد — همان مقدار `level=` بالا، نه معادل فارسی."""


# --------------------------------------------------------------------------
# Calls 6 and 7 -- three topic pages each
# --------------------------------------------------------------------------

def _page_spec(page: str) -> str:
    topics = "\n".join(f"  - {t}" for t in SECTION_TOPICS[page])
    return (
        f"**{page}** — «{PAGE_TITLES[page]}»\n"
        f"  شواهد اصلی: {_PAGE_EVIDENCE[page]}\n"
        f"  ردیف‌ها (عیناً و به همین ترتیب):\n{topics}"
    )


def build_topic_user(profile: DeepProfileInput, pages: tuple[str, ...]) -> str:
    """User message for call 6 or 7. Unlike the domain calls, these see all thirty facets:
    a topic row is fed by facets scattered across several domains."""
    all_facets = "\n".join(_facet_line(f) for f in profile.facet_scores)
    specs = "\n\n".join(_page_spec(p) for p in pages)

    return f"""بخشی که الان می‌نویسی: {len(pages)} صفحه‌ی موضوعی.

هر سی خرده‌ویژگی:
{all_facets}

{_patterns_block(profile)}

{_context_block(profile)}

صفحه‌هایی که باید بنویسی:

{specs}

⚠️ **عنوان‌های `topic` ثابت‌اند.** عیناً همان‌ها را بنویس، به همان ترتیب. نه تغییرشان بده، نه
اضافه کن، نه حذف. فقط `text` هر ردیف را تو می‌نویسی.

هر `text` یک تا دو جمله. برای هر ردیف از همان شواهدی استفاده کن که به آن تعلق دارد.

`closing` هر صفحه یک بند است که موضوع بالا را جمع می‌کند، نه تکرار ردیف‌ها.

{_example_block(topic_examples(pages), "همان صفحه‌هایی که تو می‌نویسی، از دو پروفایل دیگر")}

قالب خروجی:
{{{", ".join(f'"{p}": {{"rows": [{{"topic": "...", "text": "..."}}], "closing": "..."}}' for p in pages)}}}"""


# --------------------------------------------------------------------------
# Call 8 -- everything that needs the whole picture
# --------------------------------------------------------------------------

def build_closing_user(
    profile: DeepProfileInput,
    domain_outputs: list,
    topic_pages: dict,
) -> str:
    """User message for call 8. This call reads the *text* the previous seven produced, not
    the scores again -- identity_line and integrated_interpretation have to agree with what
    the rest of the report already says."""
    domains = "\n\n".join(
        f"— {DOMAIN_NAMES[d.code]} —\n"
        + "\n".join(
            f"{FACET_NAMES[f.code]} ({LEVEL_NAMES[f.level]}): "
            f"خوب کار می‌کند — {f.when_it_works} · هزینه می‌سازد — {f.when_it_costs}"
            for f in d.facets
        )
        + f"\nجمع‌بندی: {d.summary}"
        for d in domain_outputs
    )

    pages = "\n\n".join(
        f"— {PAGE_TITLES[key]} —\n"
        + "\n".join(f"{r.topic}: {r.text}" for r in page.rows)
        + f"\n{page.closing}"
        for key, page in topic_pages.items()
    )

    # domains_overview needs the raw code + level per domain; call 8 only sees prose
    # otherwise, and the model copies the Persian label into the `level` field.
    domain_levels = "\n".join(
        f"- {d.code} ({DOMAIN_NAMES[d.code]}): level={d.level}" for d in profile.domain_scores
    )

    return f"""بخشی که الان می‌نویسی: صفحه‌های جمع‌بندی گزارش.

بقیه‌ی گزارش از قبل نوشته شده و در پایین آمده. کار تو **جمع‌بندی همین متن** است، نه تفسیر
دوباره‌ی نمره‌ها. هرچه می‌نویسی باید با آنچه پایین آمده بخواند.

## متن عامل‌ها

{domains}

## متن صفحه‌های موضوعی

{pages}

{_patterns_block(profile)}

## سطح عامل‌ها (برای `domains_overview` عیناً همین‌ها را بگذار)

{domain_levels}

## آنچه باید بنویسی

- `identity_line` — یک جمله. بدون برچسب و بدون اسم تیپ.
- `top_strengths` — دقیقاً ۳ مورد، کوتاه.
- `growth_priorities` — دقیقاً ۳ مورد، کوتاه.
- `confidence_note` — یک بند درباره‌ی اینکه این تفسیر تا چه حد قابل اتکاست و چرا. صادق باش:
  این ابزار هنجاریابی نشده.
- `domains_overview` — دقیقاً پنج آیتم، هرکدام با: `code` (یکی از `N`/`E`/`O`/`A`/`C`)،
  `title` (نام فارسی عامل)، `level` (عیناً از جدول «سطح عامل‌ها» بالا — یکی از
  `low`/`mid`/`high`، نه فارسی)، و `description` (یک جمله).
- `integrated_interpretation` — پنج عامل را **کنار هم** بخوان. این تنها جایی است که تعامل
  بین عامل‌ها نوشته می‌شود.
- `strengths` — یک آبجکت با `items` (دقیقاً ۵ مورد، هرکدام با `title`، `evidence`، `value`،
  و `overuse`) و یک `development_message` برای کل صفحه.
- `blind_spots` — یک آبجکت با `items` (۲ تا ۴ الگو، هرکدام با `hypothesis`، `evidence`،
  `trigger`، `visible_sign` — با زبان احتمالی، نه حکم) و `reflection_questions` (دقیقاً ۳).
- `closing` — یک آبجکت با `at_my_best`، `under_pressure`، و `small_actions` (دقیقاً ۳ مورد،
  هرکدام با `text`، `deadline_text`، `deadline_type`، و `substeps`).
- `share` — `hook` (۳ تا ۶ کلمه) و `line` (یک جمله، زیر ۱۴ کلمه).
- `pattern_tags` — یک تا سه برچسب کوتاه انگلیسی برای تحلیل داخلی، مثل
  `high_conscientiousness_low_assertiveness`. **به کاربر نمایش داده نمی‌شود.**

### `small_actions` — سه قدم عملی

{step_quality_rules()}

سه قدم باید از هم متمایز باشند — نه یک کار با سه جمله‌بندی.

⚠️ در گزارش `substeps` **همیشه `null`** است.

### `share`

`hook` از زبان **خود فرد** نوشته می‌شود، نه درباره‌ی گزارش. بدون برچسب، بدون عدد، بدون
نام عامل.

{_example_block(closing_examples()[:1], "بخش‌های پایانی یک پروفایل دیگر")}

قالب خروجی — دقیقاً همین کلیدها، هیچ‌کدام جا نیفتد:
{{
  "identity_line": "...",
  "top_strengths": ["...", "...", "..."],
  "growth_priorities": ["...", "...", "..."],
  "confidence_note": "...",
  "domains_overview": [{{"code": "N", "title": "...", "level": "low|mid|high", "description": "..."}}],
  "integrated_interpretation": "...",
  "strengths": {{"items": [{{"title": "...", "evidence": "...", "value": "...", "overuse": "..."}}], "development_message": "..."}},
  "blind_spots": {{"items": [{{"hypothesis": "...", "evidence": "...", "trigger": "...", "visible_sign": "..."}}], "reflection_questions": ["...", "...", "..."]}},
  "closing": {{"at_my_best": "...", "under_pressure": "...", "small_actions": [{{"text": "...", "deadline_text": "...", "deadline_type": "tonight", "substeps": null}}]}},
  "share": {{"hook": "...", "line": "..."}},
  "pattern_tags": ["..."]
}}"""


# --------------------------------------------------------------------------
# Message builders
# --------------------------------------------------------------------------

def build_domain_messages(profile: DeepProfileInput, domain: str) -> list[dict]:
    return [
        {"role": "system", "content": build_static_system()},
        {"role": "user", "content": build_domain_user(profile, domain)},
    ]


def build_topic_messages(profile: DeepProfileInput, pages: tuple[str, ...]) -> list[dict]:
    return [
        {"role": "system", "content": build_static_system()},
        {"role": "user", "content": build_topic_user(profile, pages)},
    ]


def build_closing_messages(
    profile: DeepProfileInput, domain_outputs: list, topic_pages: dict
) -> list[dict]:
    return [
        {"role": "system", "content": build_static_system()},
        {"role": "user", "content": build_closing_user(profile, domain_outputs, topic_pages)},
    ]
