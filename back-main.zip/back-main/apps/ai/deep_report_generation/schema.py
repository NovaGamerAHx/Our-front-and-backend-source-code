"""Input and output models for the deep (150-item) report (deep_report_spec_v1_2.md §4 and §6).

WHY THE OUTPUT IS SPLIT INTO EIGHT MODELS
------------------------------------------
The report is produced by eight separate calls (§5.1), not one. A single call would mean
one schema violation anywhere -- in any of ~90 facet texts -- invalidates the whole report
and costs a full regeneration. So the model never returns `DeepReport` directly: it returns
one partial per call, each validated on its own, and `generate.py` assembles them.

SHARED PIECES ARE IMPORTED, NOT REDEFINED
------------------------------------------
`SuggestedStep` and `Share` come from apps.ai.report_generation.schema, and the topic lists
from apps.ai.deep_report_generation.structure -- both already the single source of truth for
their shape. `ContextProfile` is the initial report's, reused unchanged.
"""

from __future__ import annotations

import logging as _logging
from typing import ClassVar, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from apps.ai.deep_report_generation.structure import DOMAIN_ORDER, SECTION_TOPICS
from apps.ai.report_generation.profile_input import ContextProfile
from apps.ai.report_generation.schema import Share as ShareCard
from apps.ai.report_generation.schema import SuggestedStep

DomainCode = Literal["N", "E", "O", "A", "C"]
Level = Literal["low", "mid", "high"]

FACET_CODES: tuple[str, ...] = (
    "N1", "N2", "N3", "N4", "N5", "N6",
    "E1", "E2", "E3", "E4", "E5", "E6",
    "O1", "O2", "O3", "O4", "O5", "O6",
    "A1", "A2", "A3", "A4", "A5", "A6",
    "C1", "C2", "C3", "C4", "C5", "C6",
)

FacetCode = Literal[
    "N1", "N2", "N3", "N4", "N5", "N6",
    "E1", "E2", "E3", "E4", "E5", "E6",
    "O1", "O2", "O3", "O4", "O5", "O6",
    "A1", "A2", "A3", "A4", "A5", "A6",
    "C1", "C2", "C3", "C4", "C5", "C6",
]

_DOMAIN_OF_FACET = {c: c[0] for c in FACET_CODES}


# --------------------------------------------------------------------------
# Input (§4)
# --------------------------------------------------------------------------

class FacetScore(BaseModel):
    model_config = ConfigDict(extra="forbid")

    code: FacetCode
    # Facet Provisional 0-100. Sent so the model can judge intensity; it must never appear
    # in the output text (§8).
    score: int = Field(ge=0, le=100)
    level: Level


class DomainScore(BaseModel):
    model_config = ConfigDict(extra="forbid")

    code: DomainCode
    score: int = Field(ge=0, le=100)
    level: Level


class DeepProfileInput(BaseModel):
    """What backend sends. Core Domain Raw is deliberately absent -- quality signal for
    backend only, never reaches the model (§2.3)."""

    model_config = ConfigDict(extra="forbid")

    report_type: Literal["deep"] = "deep"
    facet_scores: list[FacetScore] = Field(min_length=30, max_length=30)
    domain_scores: list[DomainScore] = Field(min_length=5, max_length=5)
    active_patterns: list[str] = Field(default_factory=list)
    context_profile: ContextProfile | None = None

    @field_validator("facet_scores")
    @classmethod
    def _all_thirty_facets_present(cls, v: list[FacetScore]) -> list[FacetScore]:
        seen = [f.code for f in v]
        if len(set(seen)) != 30:
            dupes = sorted({c for c in seen if seen.count(c) > 1})
            raise ValueError(f"duplicate facet codes: {dupes}")
        missing = [c for c in FACET_CODES if c not in seen]
        if missing:
            raise ValueError(f"missing facet codes: {missing}")
        return v

    @field_validator("domain_scores")
    @classmethod
    def _all_five_domains_present(cls, v: list[DomainScore]) -> list[DomainScore]:
        seen = {d.code for d in v}
        missing = [c for c in DOMAIN_ORDER if c not in seen]
        if missing:
            raise ValueError(f"missing domain codes: {missing}")
        return v

    def facets_for(self, domain: str) -> list[FacetScore]:
        """The six facets of one domain, in spec order."""
        order = [c for c in FACET_CODES if _DOMAIN_OF_FACET[c] == domain]
        by_code = {f.code: f for f in self.facet_scores}
        return [by_code[c] for c in order]


# --------------------------------------------------------------------------
# Output -- calls 1 to 5, one domain each
# --------------------------------------------------------------------------

class FacetOutput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    code: FacetCode
    level: Level
    when_it_works: str
    when_it_costs: str


class DomainOutput(BaseModel):
    """One of calls 1-5."""

    model_config = ConfigDict(extra="forbid")

    code: DomainCode
    facets: list[FacetOutput] = Field(min_length=6, max_length=6)
    summary: str

    @model_validator(mode="after")
    def _facets_belong_to_domain(self):
        wrong = [f.code for f in self.facets if _DOMAIN_OF_FACET[f.code] != self.code]
        if wrong:
            raise ValueError(f"facets {wrong} do not belong to domain {self.code}")
        expected = [c for c in FACET_CODES if _DOMAIN_OF_FACET[c] == self.code]
        if [f.code for f in self.facets] != expected:
            raise ValueError(
                f"domain {self.code} facets must be exactly {expected}, in that order"
            )
        return self


# --------------------------------------------------------------------------
# Output -- calls 6 and 7, the six topic pages
# --------------------------------------------------------------------------
#
# The topic list per page is fixed product copy (structure.SECTION_TOPICS): the model fills
# `text` only, and the topics must appear verbatim and in order because pages 11-16 are one
# repeated UI component. A free-form topic renders fine and reads fine and is the one
# failure review cannot catch, so it is rejected here.

class _Row(BaseModel):
    model_config = ConfigDict(extra="forbid")
    topic: str
    text: str


class _TopicPage(BaseModel):
    model_config = ConfigDict(extra="forbid")
    rows: list[_Row]
    closing: str

    # set on each concrete subclass
    _page_key: ClassVar[str] = ""

    @model_validator(mode="after")
    def _topics_complete_and_ordered(self):
        expected = tuple(SECTION_TOPICS[self._page_key])
        got = tuple(r.topic for r in self.rows)
        if got != expected:
            raise ValueError(
                f"{self._page_key} topics must be exactly {list(expected)}, in that order; "
                f"got {list(got)}"
            )
        return self


def _page(key: str):
    n = len(SECTION_TOPICS[key])

    class Page(_TopicPage):
        _page_key: ClassVar[str] = key
        rows: list[_Row] = Field(min_length=n, max_length=n)

    Page.__name__ = f"{key}_page"
    return Page


DecisionStylePage = _page("decision_style")
CommunicationStylePage = _page("communication_style")
WorkStylePage = _page("work_style")
StressEnergyPage = _page("stress_and_energy")
LearningGrowthPage = _page("learning_and_growth")
CloseRelationshipsPage = _page("close_relationships")


class TopicPagesA(BaseModel):
    """Call 6 -- pages 11 to 13."""

    model_config = ConfigDict(extra="forbid")

    decision_style: DecisionStylePage
    communication_style: CommunicationStylePage
    work_style: WorkStylePage


class TopicPagesB(BaseModel):
    """Call 7 -- pages 14 to 16."""

    model_config = ConfigDict(extra="forbid")

    stress_and_energy: StressEnergyPage
    learning_and_growth: LearningGrowthPage
    close_relationships: CloseRelationshipsPage


# --------------------------------------------------------------------------
# Output -- call 8, everything that needs the whole picture
# --------------------------------------------------------------------------

class DomainOverview(BaseModel):
    model_config = ConfigDict(extra="forbid")

    code: DomainCode
    title: str
    level: Level
    description: str


class StrengthItem(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str
    evidence: str
    value: str
    overuse: str


class Strengths(BaseModel):
    model_config = ConfigDict(extra="forbid")

    items: list[StrengthItem] = Field(min_length=5, max_length=5)
    development_message: str


class BlindSpotItem(BaseModel):
    model_config = ConfigDict(extra="forbid")

    hypothesis: str
    evidence: str
    trigger: str
    visible_sign: str


class BlindSpots(BaseModel):
    model_config = ConfigDict(extra="forbid")

    items: list[BlindSpotItem] = Field(min_length=2, max_length=4)
    reflection_questions: list[str] = Field(min_length=3, max_length=3)


class ClosingPage(BaseModel):
    model_config = ConfigDict(extra="forbid")

    at_my_best: str
    under_pressure: str
    small_actions: list[SuggestedStep] = Field(min_length=3, max_length=3)


class ClosingBundleOutput(BaseModel):
    """Call 8. Runs after 1-7 and takes their text as input, so identity_line and
    integrated_interpretation agree with what the rest of the report says."""

    model_config = ConfigDict(extra="forbid")

    identity_line: str
    top_strengths: list[str] = Field(min_length=3, max_length=3)
    growth_priorities: list[str] = Field(min_length=3, max_length=3)
    confidence_note: str
    domains_overview: list[DomainOverview] = Field(min_length=5, max_length=5)
    integrated_interpretation: str
    strengths: Strengths
    blind_spots: BlindSpots
    closing: ClosingPage
    share: ShareCard
    # Analytics tags, not user-facing (§6). Produced in call 8 because it is the only call
    # that has seen the whole report.
    pattern_tags: list[str] = Field(min_length=1, max_length=3)

    @model_validator(mode="after")
    def _overview_covers_five_domains(self):
        seen = {d.code for d in self.domains_overview}
        missing = [c for c in DOMAIN_ORDER if c not in seen]
        if missing:
            raise ValueError(f"domains_overview missing: {missing}")
        return self


# --------------------------------------------------------------------------
# The assembled report (§6.1)
# --------------------------------------------------------------------------

class DeepReport(BaseModel):
    """Built by generate.py from the eight partials. The model never returns this directly."""

    model_config = ConfigDict(extra="forbid")

    identity_line: str
    top_strengths: list[str] = Field(min_length=3, max_length=3)
    growth_priorities: list[str] = Field(min_length=3, max_length=3)
    confidence_note: str
    domains_overview: list[DomainOverview] = Field(min_length=5, max_length=5)
    integrated_interpretation: str
    domains: list[DomainOutput] = Field(min_length=5, max_length=5)
    strengths: Strengths
    blind_spots: BlindSpots
    decision_style: DecisionStylePage
    communication_style: CommunicationStylePage
    work_style: WorkStylePage
    stress_and_energy: StressEnergyPage
    learning_and_growth: LearningGrowthPage
    close_relationships: CloseRelationshipsPage
    closing: ClosingPage
    share: ShareCard

    @model_validator(mode="after")
    def _thirty_distinct_facets(self):
        codes = [f.code for d in self.domains for f in d.facets]
        if sorted(codes) != sorted(FACET_CODES):
            raise ValueError("assembled report does not cover the 30 facets exactly once")
        return self


# --------------------------------------------------------------------------
# Soft validation -- logged, never raises (same split as the initial report)
# --------------------------------------------------------------------------

_logger = _logging.getLogger(__name__)

_FORBIDDEN_ABSOLUTES = ("همیشه", "هیچ‌وقت", "قطعاً", "نتیجه‌ی قطعی")
_DIGITS = "0123456789۰۱۲۳۴۵۶۷۸۹"


def _all_text(report: DeepReport) -> list[tuple[str, str]]:
    out: list[tuple[str, str]] = [
        ("identity_line", report.identity_line),
        ("integrated_interpretation", report.integrated_interpretation),
        ("confidence_note", report.confidence_note),
    ]
    for d in report.domains:
        out.append((f"domains.{d.code}.summary", d.summary))
        for f in d.facets:
            out.append((f"domains.{d.code}.{f.code}.when_it_works", f.when_it_works))
            out.append((f"domains.{d.code}.{f.code}.when_it_costs", f.when_it_costs))
    for i, s in enumerate(report.strengths.items, start=1):
        out.append((f"strengths.{i}.value", s.value))
        out.append((f"strengths.{i}.overuse", s.overuse))
    for i, b in enumerate(report.blind_spots.items, start=1):
        out.append((f"blind_spots.{i}.hypothesis", b.hypothesis))
    for key in SECTION_TOPICS:
        page = getattr(report, key)
        for row in page.rows:
            out.append((f"{key}.{row.topic}", row.text))
        out.append((f"{key}.closing", page.closing))
    for i, a in enumerate(report.closing.small_actions, start=1):
        out.append((f"closing.small_actions.{i}", a.text))
    out.append(("share.hook", report.share.hook))
    out.append(("share.line", report.share.line))
    return out


def soft_check(report: DeepReport) -> list[str]:
    """Warnings that do not reject the report. Returns the list and logs each one."""
    warnings: list[str] = []

    for where, text in _all_text(report):
        for code in FACET_CODES:
            if code in text:
                warnings.append(f"{where} contains the facet code {code}")
                break
        if any(ch in text for ch in _DIGITS):
            warnings.append(f"{where} contains a digit; scores must never reach the text")
        for word in _FORBIDDEN_ABSOLUTES:
            if word in text:
                warnings.append(f"{where} uses the absolute «{word}»")
                break

    for d in report.domains:
        for f in d.facets:
            works, costs = len(f.when_it_works.split()), len(f.when_it_costs.split())
            if works and costs and (works > costs * 2.5 or costs > works * 2.5):
                warnings.append(
                    f"domains.{d.code}.{f.code} is lopsided "
                    f"({works} vs {costs} words between the two halves)"
                )

    n = len(report.share.hook.split())
    if not 3 <= n <= 6:
        warnings.append(f"share.hook is {n} words (expected 3-6)")
    n = len(report.share.line.split())
    if n > 14:
        warnings.append(f"share.line is {n} words (limit 14)")

    for i, a in enumerate(report.closing.small_actions, start=1):
        if a.substeps:
            warnings.append(f"closing.small_actions.{i} has substeps; report steps must not")

    for w in warnings:
        _logger.warning("soft validation: %s", w)
    return warnings
