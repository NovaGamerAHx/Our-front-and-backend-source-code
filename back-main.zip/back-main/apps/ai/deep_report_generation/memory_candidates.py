"""Builds the deep report's memory_candidates from an already-generated report (§6.3).

A plain field mapping, not a model call — same reasoning as the initial report's version: the
report is already structured and every judgement worth making has been made, so re-asking
"what should be remembered?" would spend money to make a solved decision unreliable.

Three rules from §6.3 that are easy to get wrong:

1. `source` is "deep_report_v1". Supersession is keyed on (user, memory_type, source), so
   these rows sit ALONGSIDE the initial report's rather than replacing them.
2. Still exactly four types. Memory is injected into every chat turn, and a user who took
   both tests already carries 8 rows; each new type is more tokens on every turn, forever.
3. Blind spots never become memories, even though they are the sharpest content in the
   report. Permanently injecting them raises the risk of chat opening on someone's weak
   point, which the chat prompt rules forbid outright. `share` is excluded too.
"""

SOURCE = "deep_report_v1"

# No per-item signal exists to derive these from -- same known placeholder as the initial
# report's builder. Do not let downstream code read them as real measurements.
_STRENGTH_EDGE_CONFIDENCE_PLACEHOLDER = "medium"

_ITEM_PREFIX = "- "
_ITEM_SEPARATOR = "\n"


def _merge(items: list[str]) -> str:
    """Merge several report items into one text_memory value, one bullet per line so they stay
    distinguishable when rendered into the Persian <user_memory> block."""
    return _ITEM_SEPARATOR.join(f"{_ITEM_PREFIX}{item}" for item in items)


def build_memory_candidates(report: dict) -> list[dict]:
    """Map report fields -> memory candidates. Deterministic, no model involved.

    Always exactly four -- one per memory_type -- regardless of report content.
    """
    top_strengths = report.get("top_strengths", [])
    growth_priorities = report.get("growth_priorities", [])

    return [
        {
            "memory_type": "core_pattern",
            "text_memory": report["identity_line"],
            "source": SOURCE,
            "confidence": "medium",
            "sensitivity_level": "low",
            "should_store": True,
        },
        {
            "memory_type": "strength",
            "text_memory": _merge(top_strengths),
            "source": SOURCE,
            "confidence": _STRENGTH_EDGE_CONFIDENCE_PLACEHOLDER,
            "sensitivity_level": "low",
            "should_store": True,
        },
        {
            "memory_type": "growth_edge",
            "text_memory": _merge(growth_priorities),
            "source": SOURCE,
            "confidence": _STRENGTH_EDGE_CONFIDENCE_PLACEHOLDER,
            "sensitivity_level": "medium",
            "should_store": True,
        },
        {
            # §6.3: "the most important growth priority" -- the report lists them in priority
            # order, so the first one is it.
            "memory_type": "growth_focus",
            "text_memory": growth_priorities[0] if growth_priorities else "",
            "source": SOURCE,
            "confidence": "medium",
            "sensitivity_level": "low",
            "should_store": bool(growth_priorities),
        },
    ]
