"""The full path: DeepProfileInput -> eight calls -> one DeepReportResponse.

Same attempt ladder as apps.ai.report_generation.generate, applied per call rather than
once: primary model on OpenAI (retried N times), then the backup model on OpenAI, then that
same backup via AvalAI -- a different infra path in case OpenAI itself is the problem.

WHY EIGHT CALLS
---------------
The report is ~90 facet texts plus six topic pages plus the closing bundle. In a single
call, one schema violation anywhere invalidates all of it and costs a full regeneration.
Split, only the failing part is retried.

Calls 1-7 are independent and run in parallel (threads -- the work is I/O-bound and the
callers are synchronous). Call 8 runs after them because it reads their text.

PARTIAL FAILURE
---------------
If one of calls 1-7 exhausts its ladder, the others are NOT cancelled -- they have already
been paid for. They finish, everything is logged, and the whole report comes back as
generation_failed. A half-report is never returned.

DEEP_REPORT_AI_ENABLED=false is handled one level up, in client.py, which serves the fixed
mock instead of calling this module at all.
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
from concurrent.futures import ThreadPoolExecutor

from pydantic import BaseModel, ConfigDict, ValidationError

from apps.ai.deep_report_generation.prompt import (
    TOPIC_GROUP_A,
    TOPIC_GROUP_B,
    build_closing_messages,
    build_domain_messages,
    build_topic_messages,
)
from apps.ai.deep_report_generation.schema import (
    ClosingBundleOutput,
    DeepProfileInput,
    DeepReport,
    DomainOutput,
    TopicPagesA,
    TopicPagesB,
    soft_check,
)
from apps.ai.openai_client import client_for
from faraman_back.lang.utils import get_message
from faraman_back.observability.metrics import AI_CALL_DURATION

logger = logging.getLogger(__name__)

_FENCE_RE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", re.IGNORECASE)
# A trailing comma before } or ] is the single most common way a model breaks otherwise-fine
# JSON. Repairing it is far cheaper than a full eight-call regeneration.
_TRAILING_COMMA_RE = re.compile(r",(\s*[}\]])")

DOMAINS = ("N", "E", "O", "A", "C")

# Prompt caching: all eight calls share one byte-identical system message, so one routing
# key keeps that shared prefix warm across the eight (and across users, in the cache window).
PROMPT_CACHE_KEY = "deep_v1"


def _strip_fences(text: str) -> str:
    return _FENCE_RE.sub("", text.strip()).strip()


def _loads_lenient(raw: str) -> dict:
    """Parse the model's JSON, repairing a trailing comma if that is the only problem.

    Raises json.JSONDecodeError like plain json.loads on anything it cannot fix, so the
    caller's attempt ladder still handles a genuinely broken response.
    """
    cleaned = _strip_fences(raw)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        return json.loads(_TRAILING_COMMA_RE.sub(r"\1", cleaned))


def _attempt_ladder() -> list[tuple[str, str]]:
    # Default to the mini model: the deep report is eight calls, each with a large few-shot
    # prompt, so the full model here is a per-report cost in dollars, not cents.
    primary_model = os.getenv("DEEP_REPORT_PRIMARY_MODEL") or "gpt-5.4"
    backup_model = os.getenv("DEEP_REPORT_BACKUP_MODEL") or "gpt-5.4-mini"
    # AvalAI is the last resort, after OpenAI has failed twice; it runs the full model, not the mini.
    avalai_model = os.getenv("DEEP_REPORT_AVALAI_MODEL") or "gpt-5.4"
    max_primary = int(os.getenv("DEEP_REPORT_MAX_PRIMARY_ATTEMPTS") or "2")
    return (
        [("openai", primary_model)] * max_primary
        + [("openai", backup_model), ("avalai", avalai_model)]
    )


class CallResult(BaseModel):
    """One call's outcome. Carries usage even on failure -- attempts that reached the
    provider were paid for."""

    model_config = ConfigDict(protected_namespaces=())

    name: str
    ok: bool
    attempts: int
    model_used: str | None = None
    input_tokens: int = 0
    cached_input_tokens: int = 0
    output_tokens: int = 0
    latency_s: float = 0.0
    error: str | None = None


class DeepGenerationMeta(BaseModel):
    model_config = ConfigDict(protected_namespaces=())

    model_used: str | None = None
    attempts: int
    input_tokens: int = 0
    cached_input_tokens: int = 0
    output_tokens: int = 0
    # End-to-end wall clock, not the sum of the eight -- calls 1-7 overlap.
    latency_s: float = 0.0
    per_call: list[CallResult] = []


class DeepErrorInfo(BaseModel):
    code: str
    user_message: str
    should_display_report: bool = False


class DeepReportResponse(BaseModel):
    status: str
    report_version: str = "deep_v1"
    report: DeepReport | None = None
    system: dict | None = None
    error: DeepErrorInfo | None = None
    generation_meta: DeepGenerationMeta | None = None


def _call_with_ladder(client, name: str, messages: list[dict], model_cls):
    """One logical call, with its own attempt ladder. Returns (parsed_or_None, CallResult).
    Never raises: a failure here must not take down the six calls running beside it."""
    ladder = _attempt_ladder()
    started = time.perf_counter()
    totals = {"input_tokens": 0, "cached_input_tokens": 0, "output_tokens": 0}
    last_error = "no attempt ran"

    for i, (provider, model) in enumerate(ladder, start=1):
        attempt_started = time.perf_counter()
        try:
            call_client = client if client is not None else client_for(provider)
            resp = call_client.chat.completions.create(
                model=model, messages=messages, prompt_cache_key=PROMPT_CACHE_KEY,
            )
            usage = getattr(resp, "usage", None)
            if usage:
                totals["input_tokens"] += getattr(usage, "prompt_tokens", 0) or 0
                totals["output_tokens"] += getattr(usage, "completion_tokens", 0) or 0
                details = getattr(usage, "prompt_tokens_details", None)
                totals["cached_input_tokens"] += getattr(details, "cached_tokens", 0) or 0

            raw = resp.choices[0].message.content or ""
            parsed = model_cls.model_validate(_loads_lenient(raw))

        except (json.JSONDecodeError, ValidationError) as e:
            AI_CALL_DURATION.labels(
                purpose="report_deep", call=name, provider=provider, outcome="validation_error",
            ).observe(time.perf_counter() - attempt_started)
            last_error = f"{type(e).__name__}: {e}"
            logger.warning("%s attempt %d/%d (%s via %s) failed validation: %s",
                           name, i, len(ladder), model, provider, e)
            # Feed the mistake back in for the next attempt (even across a model/provider
            # switch, since each call is a stateless one-shot with no memory of prior
            # attempts) -- otherwise every attempt in the ladder repeats the identical
            # error. Appending only at the end keeps the shared system/few-shot prefix
            # byte-identical, so prompt_cache_key's cache hit on that prefix still applies.
            messages = messages + [
                {"role": "assistant", "content": raw},
                {"role": "user", "content": (
                    "That response failed schema validation:\n"
                    f"{e}\n\n"
                    "Return the corrected, complete JSON only -- no explanation, no markdown "
                    "fences. Double-check every enum/Literal field uses one of its exact "
                    "allowed values and no others."
                )},
            ]
            continue

        except Exception as e:
            AI_CALL_DURATION.labels(
                purpose="report_deep", call=name, provider=provider, outcome="error",
            ).observe(time.perf_counter() - attempt_started)
            last_error = f"{type(e).__name__}: {e}"
            logger.warning("%s attempt %d/%d (%s via %s) call failed: %s: %s",
                           name, i, len(ladder), model, provider, type(e).__name__, e)
            continue

        AI_CALL_DURATION.labels(
            purpose="report_deep", call=name, provider=provider, outcome="ok",
        ).observe(time.perf_counter() - attempt_started)
        result = CallResult(
            name=name, ok=True, attempts=i, model_used=f"{model} ({provider})",
            latency_s=round(time.perf_counter() - started, 2), **totals,
        )
        logger.info("%s ok on attempt %d (%s via %s) in %.2fs",
                    name, i, model, provider, result.latency_s)
        return parsed, result

    result = CallResult(
        name=name, ok=False, attempts=len(ladder),
        latency_s=round(time.perf_counter() - started, 2), error=last_error, **totals,
    )
    logger.error("%s failed after %d attempts: %s", name, len(ladder), last_error)
    return None, result


def _enforce_levels(profile: DeepProfileInput, domains: list[DomainOutput],
                    closing: ClosingBundleOutput) -> None:
    """Overwrite every `level` in the model's output with the backend's own.

    Levels are ours (deep_report_spec_v1_2.md §2: the AI produces no number and changes no number). The
    prompt asks the model to copy them verbatim and it usually does, but nothing in the schema
    can catch it getting one wrong -- `low`/`mid`/`high` are all valid literals whichever facet
    they land on. An uncaught miscopy ships a report whose text says «بالا» for a facet the
    user actually scored mid, with status=ok and no error anywhere.

    So this does not validate and reject; it restores. Rejecting would throw away eight paid
    calls of otherwise-good prose over a field the model was never the source of truth for.
    Miscopies are logged because they are a prompt-quality signal worth watching.
    """
    facet_levels = {f.code: f.level for f in profile.facet_scores}
    domain_levels = {d.code: d.level for d in profile.domain_scores}

    corrected = []
    for domain in domains:
        for facet in domain.facets:
            if facet.level != facet_levels[facet.code]:
                corrected.append(f"{facet.code} {facet.level}->{facet_levels[facet.code]}")
                facet.level = facet_levels[facet.code]

    for overview in closing.domains_overview:
        if overview.level != domain_levels[overview.code]:
            corrected.append(f"domain {overview.code} {overview.level}->{domain_levels[overview.code]}")
            overview.level = domain_levels[overview.code]

    if corrected:
        logger.warning("deep report: model miscopied %d level(s), corrected: %s",
                       len(corrected), ", ".join(corrected))


def _assemble(
    profile: DeepProfileInput,
    domains: list[DomainOutput],
    topics_a: TopicPagesA,
    topics_b: TopicPagesB,
    closing: ClosingBundleOutput,
) -> DeepReport:
    """Merge the eight partials into the final report. Each partial was already validated;
    what this still catches is an assembly mistake -- a domain arriving twice, or one going
    missing (DeepReport checks the 30 facets appear exactly once)."""
    _enforce_levels(profile, domains, closing)
    payload = closing.model_dump()
    payload.pop("pattern_tags", None)  # pattern_tags travels in `system`, not the report
    return DeepReport(
        **payload,
        domains=domains,
        **topics_a.model_dump(),
        **topics_b.model_dump(),
    )


def _meta(results: list[CallResult], started: float) -> DeepGenerationMeta:
    primary_model = os.getenv("DEEP_REPORT_PRIMARY_MODEL") or "gpt-5.4"
    ok_models = [r.model_used for r in results if r.ok and r.model_used]
    return DeepGenerationMeta(
        model_used=(ok_models[0] if ok_models else primary_model),
        attempts=sum(r.attempts for r in results),
        input_tokens=sum(r.input_tokens for r in results),
        cached_input_tokens=sum(r.cached_input_tokens for r in results),
        output_tokens=sum(r.output_tokens for r in results),
        latency_s=round(time.perf_counter() - started, 2),
        per_call=results,
    )


def _log_usage(meta: DeepGenerationMeta) -> None:
    """One line so a deep report's real token cost is always visible in the worker log,
    ok or failed. The deep report is eight calls with large few-shot prompts; a run that
    balloons past the expected envelope should stand out, not hide in an INFO line."""
    total = meta.input_tokens + meta.output_tokens
    line = (
        "deep report usage: model=%s attempts=%d input=%d (cached=%d) output=%d total=%d"
        % (meta.model_used, meta.attempts, meta.input_tokens,
           meta.cached_input_tokens, meta.output_tokens, total)
    )
    # A clean run is ~8-16 calls' worth of prompt; well past that means retries piled up.
    (logger.warning if total > 250_000 or meta.attempts > 16 else logger.info)(line)


def _failed(results: list[CallResult], started: float) -> DeepReportResponse:
    # One line that tells the whole story: which of the eight calls broke and why. The
    # per-call CallResults never reach the DB (client.py drops them from the response), so
    # this log is the only place the detail survives.
    for r in results:
        if r.ok:
            logger.error("deep report call %-9s OK   (%d attempts)", r.name, r.attempts)
        else:
            logger.error("deep report call %-9s FAIL (%d attempts) -- %s",
                         r.name, r.attempts, r.error)
    _log_usage(_meta(results, started))
    return DeepReportResponse(
        status="error",
        error=DeepErrorInfo(
            code="generation_failed",
            user_message=get_message("report_generation_failed"),
        ),
        generation_meta=_meta(results, started),
    )


def generate_deep_report(profile: DeepProfileInput, client=None) -> DeepReportResponse:
    """Generate the deep report. Always returns a response -- never raises.

    profile: validated DeepProfileInput
    client:  optional injected OpenAI-shaped client, so tests run without a real API. When
             given it is used for every attempt regardless of provider.
    """
    started = time.perf_counter()

    jobs = [
        (f"domain_{d}", build_domain_messages(profile, d), DomainOutput) for d in DOMAINS
    ] + [
        ("topics_a", build_topic_messages(profile, TOPIC_GROUP_A), TopicPagesA),
        ("topics_b", build_topic_messages(profile, TOPIC_GROUP_B), TopicPagesB),
    ]

    with ThreadPoolExecutor(max_workers=len(jobs)) as pool:
        futures = [
            pool.submit(_call_with_ladder, client, name, messages, cls)
            for name, messages, cls in jobs
        ]
        outcomes = [f.result() for f in futures]

    parsed = {r.name: p for p, r in outcomes}
    results = [r for _, r in outcomes]

    failed = [r.name for r in results if not r.ok]
    if failed:
        logger.error("deep report failed: %s did not complete", failed)
        return _failed(results, started)

    domains = [parsed[f"domain_{d}"] for d in DOMAINS]
    topics_a, topics_b = parsed["topics_a"], parsed["topics_b"]
    pages = {
        **{k: getattr(topics_a, k) for k in TOPIC_GROUP_A},
        **{k: getattr(topics_b, k) for k in TOPIC_GROUP_B},
    }

    closing, closing_result = _call_with_ladder(
        client, "closing", build_closing_messages(profile, domains, pages),
        ClosingBundleOutput,
    )
    results.append(closing_result)

    if closing is None:
        logger.error("deep report failed: closing call did not complete")
        return _failed(results, started)

    try:
        report = _assemble(profile, domains, topics_a, topics_b, closing)
    except ValidationError as e:
        logger.error("deep report assembly failed: %s", e)
        return _failed(results, started)

    warnings = soft_check(report)
    meta = _meta(results, started)
    _log_usage(meta)
    logger.info(
        "deep report ok: %d calls, %d total attempts, %.2fs wall, %d soft warnings",
        len(results), meta.attempts, meta.latency_s, len(warnings),
    )
    return DeepReportResponse(
        status="ok",
        report=report,
        system={"pattern_tags": closing.pattern_tags},
        generation_meta=meta,
    )
