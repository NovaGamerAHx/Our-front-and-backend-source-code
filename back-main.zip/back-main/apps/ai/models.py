from django.db import models


class ModelPricing(models.Model):
    """USD price per model, editable via admin so a price change never needs a deploy
    (report_spec_v1.4 §4.4). Shared config: every AI feature that reports token usage
    (report generation today, chat later) prices its generation_meta against this same
    table instead of hardcoding its own numbers.
    """

    model_name = models.CharField(max_length=100, unique=True)
    input_price_per_million = models.DecimalField(max_digits=10, decimal_places=4)
    output_price_per_million = models.DecimalField(max_digits=10, decimal_places=4)
    # Discounted price for input tokens served from the provider's prompt cache
    # (chat_spec_v3_1.md §2.6 `cached_input_tokens`). Nullable: when unset, cached tokens are
    # priced at the full `input_price_per_million` -- overcounting a little beats guessing a
    # discount that may not match the provider's.
    cached_input_price_per_million = models.DecimalField(
        max_digits=10, decimal_places=4, null=True, blank=True
    )
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "ai_model_pricing"

    def __str__(self):
        return self.model_name
