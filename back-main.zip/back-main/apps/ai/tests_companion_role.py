"""Tests for the base companion role and tone block (docs/companion_role_tone_v1.md).

These are contract tests on the assembled system prompt, not on the model's replies. They
answer: is the block present, is it in the position its precedence depends on, does it carry
every operative rule the spec defines, and does it avoid the things the rest of the prompt
forbids. The model's actual behaviour is an eval question and cannot be asserted here.

The spec is a PM-owned document. Where a rule is quoted verbatim below, that is deliberate:
if someone edits the wording in companion_role.md, the test should fail and send them back
to the spec rather than let the change pass silently.
"""

import re
import unittest
from pathlib import Path

from apps.ai.chat_generation.generate import PROMPT_VERSION
from apps.ai.chat_generation.prompt import build_system_prompt
from apps.ai.prompts import read_block

_BLOCK_PATH = Path(__file__).parent / "chat_generation" / "companion_role.md"
_KNOWLEDGE_PATH = Path(__file__).parent / "chat_generation" / "knowledge_base.md"

_KASRE = "\u0650"


def _block() -> str:
    return read_block(str(_BLOCK_PATH))


def _system_prompt(**kwargs) -> str:
    kwargs.setdefault("entry_source", "manual")
    kwargs.setdefault("user_memory", [])
    return build_system_prompt(**kwargs)


class CompanionBlockPresenceTests(unittest.TestCase):
    def test_the_block_is_in_every_system_prompt(self):
        """It is static: no entry source, report or memory can leave it out."""
        for entry_source in ("manual", "report_cta", "report_goal", "report_finding_focus:0",
                             "deep_report_cta", "action_rejected", "action_completed"):
            with self.subTest(entry_source=entry_source):
                prompt = _system_prompt(entry_source=entry_source)
                self.assertIn("<companion_role>", prompt)
                self.assertIn("</companion_role>", prompt)

    def test_the_wrapper_is_balanced_and_appears_once(self):
        prompt = _system_prompt()
        self.assertEqual(prompt.count("<companion_role>\n"), 1)
        self.assertEqual(prompt.count("</companion_role>"), 1)

    def test_nothing_user_specific_leaks_into_the_block(self):
        """It sits inside the cached prefix. A single interpolated value would break the
        cache for every block below it, for every concurrent session."""
        plain = _system_prompt()
        with_memory = _system_prompt(user_memory=[{
            "memory_type": "core_pattern", "text_memory": "یک الگوی خاص",
            "source": "initial_report",
        }])
        self.assertEqual(_extract(plain), _extract(with_memory))

    def test_the_block_is_identical_across_entry_sources(self):
        a = _extract(_system_prompt(entry_source="manual"))
        b = _extract(_system_prompt(entry_source="action_missed"))
        self.assertEqual(a, b)


def _bounds(prompt: str) -> tuple[int, int]:
    """Where the block actually starts and ends in the assembled prompt.

    Not a bare index("<companion_role>"): ROLE mentions the tag by name several times, and
    the first of those mentions is ~300 chars into the prompt. An order test written against
    that would pass no matter where the real block sat.
    """
    start = prompt.index("\n<companion_role>\n")
    end = prompt.index("</companion_role>") + len("</companion_role>")
    return start, end


def _extract(prompt: str) -> str:
    start, end = _bounds(prompt)
    return prompt[start:end]


class CompanionBlockOrderTests(unittest.TestCase):
    """Order is precedence. The block says the safety blocks outrank it and that it outranks
    <knowledge>; if the physical order contradicts that, the claim is just a claim."""

    def test_it_comes_after_both_safety_blocks(self):
        prompt = _system_prompt()
        start, _ = _bounds(prompt)
        self.assertLess(prompt.index("</safety_rules>"), start)
        self.assertLess(prompt.index("</safety_rules_chat_extension>"), start)

    def test_it_comes_before_the_knowledge_corpus_and_the_action_block(self):
        prompt = _system_prompt()
        _, end = _bounds(prompt)
        self.assertLess(end, prompt.index("<knowledge>\n###"))
        self.assertLess(end, prompt.index("## Proposing a step"))

    def test_the_role_block_still_comes_first(self):
        prompt = _system_prompt()
        start, _ = _bounds(prompt)
        self.assertLess(
            prompt.index("You are a Persian-language personal growth companion"), start,
        )

    def test_the_variable_blocks_still_come_after_every_static_one(self):
        """The cache depends on it: one user-specific block above the static tail would
        break the shared prefix for every session."""
        prompt = _system_prompt(entry_source="manual", user_memory=[{
            "memory_type": "core_pattern", "text_memory": "یک الگو", "source": "initial_report",
        }])
        _, end = _bounds(prompt)
        memory = prompt.index("\n<user_memory>\n")
        context = prompt.index("\n<session_context>\n")
        self.assertLess(end, memory)
        self.assertLess(memory, context)


class CompanionBlockContentTests(unittest.TestCase):
    """Every section of the spec has to survive into the prompt."""

    def setUp(self):
        self.block = _block()

    def test_all_ten_sections_are_present(self):
        for heading in (
            "## ۱. همراه چه کسی هست و چه کسی نیست",
            "## ۲. نگاه همراه به کاربر",
            "## ۳. همراه به چه چیزهایی گوش می‌دهد",
            "## ۴. روش‌ها",
            "## ۵. زبان",
            "## ۶. پیشنهاد دادن",
            "## ۷. چه وقت فقط گوش می‌دهد، و مرزها",
            "## ۸. قواعد فارسی",
            "## ۹. قواعد قطعی",
            "## ۱۰. نمونه‌گفت‌وگوها",
        ):
            with self.subTest(heading=heading):
                self.assertIn(heading, self.block)

    def test_all_twelve_beliefs_about_the_user_are_present(self):
        section = self._section("## ۲.", "## ۳.")
        numbered = re.findall(r"(?m)^(\d+)\. ", section)
        self.assertEqual(numbered, [str(n) for n in range(1, 13)])

    def test_the_beliefs_are_marked_as_never_spoken_aloud(self):
        self.assertIn("به کاربر گفته نمی‌شوند", self.block)

    def test_all_eight_deep_methods_are_present(self):
        for label in ("**الف)", "**ب)", "**ج)", "**د)", "**ه)", "**و)", "**ز)", "**ح)"):
            with self.subTest(label=label):
                self.assertIn(label, self.block)

    def test_deep_methods_carry_four_start_conditions_and_four_stop_conditions(self):
        self.assertIn("**شرط شروع — هر چهار تا با هم:**", self.block)
        self.assertIn("**شرط توقف — هر کدام به‌تنهایی کافی است:**", self.block)
        start = self.block.index("**شرط شروع")
        stop = self.block.index("**شرط توقف")
        after = self.block.index("**بعد از توقف:**")
        self.assertEqual(len(re.findall(r"(?m)^\d+\. ", self.block[start:stop])), 4)
        self.assertEqual(len(re.findall(r"(?m)^\d+\. ", self.block[stop:after])), 4)

    def test_all_nine_absolute_rules_are_present_and_marked_as_overriding(self):
        section = self._section("## ۹.", "## ۱۰.")
        self.assertEqual(re.findall(r"(?m)^(\d+)\. ", section), [str(n) for n in range(1, 10)])
        self.assertIn("این‌ها مقدم‌اند", section)

    def test_all_eight_worked_examples_are_present(self):
        section = self._section("## ۱۰.", None)
        for n in ("**۱.", "**۲.", "**۳.", "**۴.", "**۵.", "**۶.", "**۷.", "**۸."):
            with self.subTest(example=n):
                self.assertIn(n, section)

    def test_the_examples_are_marked_as_illustrations_not_canned_replies(self):
        self.assertIn("متن ثابت نیستند و عیناً تکرار نمی‌شوند", self.block)

    def test_the_register_rule_is_explicit(self):
        """Section 5.1: polite colloquial, with the exact word pairs the spec names."""
        for word in ("می‌خوای", "«چی»", "«یه»", "می‌خواهی", "چه چیزی", "«یک»"):
            with self.subTest(word=word):
                self.assertIn(word, self.block)

    def test_the_three_permission_moments_are_present(self):
        section = self._section("### ۵.۴", "## ۶.")
        self.assertEqual(len(re.findall(r"(?m)^\d+\. ", section)), 3)
        self.assertIn("اگر کاربر اجازه نداد، همراه جلو نمی‌رود", section)

    def test_the_only_constraint_on_suggesting_is_stated(self):
        """Section 6 deliberately frees the companion to suggest. The single limit is that
        it must first know what matters to the person -- losing that line turns the
        companion into the advice bot the spec is written against."""
        section = self._section("## ۶.", "## ۷.")
        self.assertIn("آزاد است پیشنهاد بدهد", section)
        self.assertIn("پیش از اینکه بفهمد چه چیزی برای کاربر مهم است، پیشنهاد نمی‌دهد", section)

    def test_the_jargon_translation_table_is_present(self):
        for term in ("برداشت", "واقعیت", "زاویه", "روح"):
            with self.subTest(term=term):
                self.assertIn(term, self.block)
        self.assertIn("کلمه‌های تخصصی این بلاک هیچ‌وقت به کاربر گفته نمی‌شوند", self.block)

    def test_the_persian_culture_table_covers_every_situation_in_the_spec(self):
        section = self._section("## ۸.", "## ۹.")
        for situation in (
            "«باشه» و «چشم»", "«ان‌شاءالله»", "درخواست مستقیم", "«ببخشید مزاحم شدم»",
            "«باید خودش بفهمه»", "«نه» گفتن به بزرگ‌تر", "حدس زدن نیت دیگران", "درد دل",
            "حرف زدن درباره‌ی دیگران", "باور و پیام خانواده", "ضرب‌المثل", "«چشم می‌خوری»",
            "«از خود تعریف کردن زشته»", "«ما ایرانی‌ها…»", "شروع یک حرف سخت", "قدردانی",
            "«معیارت چیه؟»",
        ):
            with self.subTest(situation=situation):
                self.assertIn(situation, section)

    def test_the_forbidden_phrases_are_listed(self):
        section = self._section("### ۵.۳", "### ۵.۴")
        for phrase in (
            "«واقعیت اینه که…»", "«اشتباه می‌کنی.»", "«مشکل تو اینه که…»",
            "«بهترین کار برات اینه که…»", "«تقصیر خودته.»",
        ):
            with self.subTest(phrase=phrase):
                self.assertIn(phrase, section)

    def _section(self, start: str, end: str | None) -> str:
        i = self.block.index(start)
        return self.block[i:self.block.index(end)] if end else self.block[i:]


class ListenOnlyIsAnIndependentChoiceTests(unittest.TestCase):
    """coach_roadmap_v2.html makes listening an independent option the router can select in
    phase 3, and is explicit that it must NOT be "the state that happens when nothing else
    fires". Today listening lives in <companion_role> section 7.1, and it is already written
    as a positive choice with its own entry conditions -- which is what makes the phase-3
    move a relocation rather than a rewrite. These tests keep it that way."""

    def setUp(self):
        self.block = _block()
        i = self.block.index("### ۷.۱")
        self.section = self.block[i:self.block.index("### ۷.۲")]

    def test_listening_has_explicit_positive_entry_conditions(self):
        self.assertIn("**همراه فقط گوش می‌دهد وقتی:**", self.section)
        self.assertGreaterEqual(len(re.findall(r"(?m)^- ", self.section)), 5)

    def test_listening_has_a_definition_of_its_own(self):
        """Not just "do less" -- it names what the companion actively does while listening."""
        self.assertIn("**«فقط گوش دادن» یعنی:**", self.section)

    def test_listening_has_explicit_exit_conditions(self):
        self.assertIn("**همراه می‌تواند جلوتر برود وقتی:**", self.section)

    def test_the_companion_asks_when_it_cannot_tell(self):
        """The roadmap's concern is listening being a silent default. Asking makes it a
        deliberate, visible choice instead."""
        self.assertIn("**وقتی مطمئن نیست، می‌پرسد:**", self.section)

    def test_listening_is_not_described_as_a_fallback(self):
        """Guards the exact framing the roadmap rules out."""
        for phrase in ("در غیر این صورت", "اگر هیچ‌کدام", "پیش‌فرض این است که فقط گوش"):
            with self.subTest(phrase=phrase):
                self.assertNotIn(phrase, self.section)


class CompanionBlockSafetyPrecedenceTests(unittest.TestCase):
    """The spec's single hardest rule: any mental-health signal stops every method here and
    hands the turn to the safety block. It appears three times in the spec (7.2, 9.1 and
    worked example 6) and all three have to survive, because this is the rule a summariser
    would be most tempted to deduplicate."""

    def setUp(self):
        self.block = _block()

    def test_the_boundary_is_stated_in_its_own_section(self):
        self.assertIn("### ۷.۲ مرز سلامت روان", self.block)
        self.assertIn("**این قاعده استثنا ندارد.**", self.block)

    def test_the_boundary_is_also_the_first_absolute_rule(self):
        section = self.block[self.block.index("## ۹."):]
        self.assertRegex(section, r"1\. \*\*سلامت روان:\*\*")

    def test_the_boundary_has_a_worked_example(self):
        self.assertIn("**اینجا هیچ‌کدام از روش‌های این بلاک به کار نمی‌رود.**", self.block)

    def test_each_statement_of_the_boundary_names_who_takes_over(self):
        """Not just \"stop\" -- each place the boundary is stated has to say who takes over,
        or the model is left with nothing to do.

        Asserted per location rather than as a global count of the tag: the tag legitimately
        appears elsewhere too (the preamble's precedence note, and the register carve-out in
        5.1), and a count would break every time one of those is touched.
        """
        section_7_2 = self.block[self.block.index("### ۷.۲"):self.block.index("### ۷.۳")]
        self.assertIn("<safety_rules_chat_extension>", section_7_2)

        rule_9_1 = self.block[self.block.index("## ۹."):self.block.index("## ۱۰.")]
        self.assertIn("قواعد ایمنی جایشان را می‌گیرند", rule_9_1)

        example_6 = self.block[self.block.index("**۶. نشانه‌ی سلامت روان**"):]
        self.assertIn("<safety_rules_chat_extension>", example_6[:600])

    def test_the_deep_belief_method_refuses_to_start_on_a_diagnosis(self):
        self.assertIn(
            "اگر جمله‌ی کاربر به تشخیص، اختلال یا نشانه‌ی روانی مربوط است", self.block,
        )

    def test_the_block_defers_to_the_safety_blocks_in_its_preamble(self):
        preamble = self.block[:self.block.index("## ۱.")]
        self.assertIn("outrank this block", preamble)

    def test_the_block_claims_precedence_over_knowledge_and_the_report(self):
        preamble = self.block[:self.block.index("## ۱.")]
        self.assertIn("This block outranks <knowledge>, the report, memory", preamble)


class CompanionBlockHygieneTests(unittest.TestCase):
    """The block is read by the same model that must obey <punctuation_rules>. A rulebook
    that breaks those rules in its own text teaches the opposite by example."""

    def setUp(self):
        self.block = _block()

    def test_no_kasre_diacritic(self):
        self.assertNotIn(_KASRE, self.block)

    def test_no_persian_semicolon(self):
        self.assertNotIn("؛", self.block)

    def test_the_only_kasre_and_semicolon_in_the_prompt_are_the_rule_quoting_itself(self):
        """<punctuation_rules> has to print the two marks it bans in order to ban them
        («نمونهِ کار» as the counter-example). Those are the only legitimate occurrences --
        anywhere else, a block is teaching the model the habit the rule forbids."""
        from apps.ai.prompts import punctuation_rules

        prompt = _system_prompt()
        rules = punctuation_rules()
        self.assertEqual(prompt.count(_KASRE), rules.count(_KASRE))
        self.assertEqual(prompt.count("؛"), rules.count("؛"))
        self.assertGreater(rules.count(_KASRE), 0)  # guards against a vacuous pass

    def test_the_block_tells_the_model_not_to_copy_its_third_person_voice(self):
        """The block says «همراه» throughout. Without this warning the model can start
        describing itself in the third person."""
        preamble = self.block[:self.block.index("## ۱.")]
        self.assertIn("third person", preamble)
        self.assertIn("«من»", preamble)

    def test_the_block_points_at_its_source_document(self):
        self.assertIn("docs/companion_role_tone_v1.md", self.block)


class KnowledgeCorpusIntegrityTests(unittest.TestCase):
    """The corpus must stay at its full 32 texts.

    coach_roadmap_v2.html section 5 decided it: the corpus gets a separate Domain Expert
    review and stays in the base-companion prompt untouched until that review reports back.
    The PM5 spec claims to replace texts 1-28, but acting on that claim is the DE's call,
    not the implementer's -- and a literal reading would delete the five action-step texts
    (23-27) that the spec itself puts out of scope.

    docs/knowledge_corpus_de_review_v1.md carries the overlap analysis as a recommendation.
    These tests exist so that applying it is a deliberate act with a failing test to answer,
    rather than something that can drift in unnoticed.
    """

    def setUp(self):
        self.corpus = read_block(str(_KNOWLEDGE_PATH))
        self.titles = re.findall(r"(?m)^### (.+)$", self.corpus)

    def test_the_corpus_still_has_all_thirty_two_texts(self):
        self.assertEqual(len(self.titles), 32)

    def test_the_texts_the_spec_overlaps_are_still_present(self):
        """The seven the DE review may eventually remove. Until it does, they stay."""
        for title in (
            "«نه» گفتن، و هزینه‌ی نگفتنش",
            "وقتی حس می‌کنی گزارش درباره‌ی تو نیست",
            "وقتی می‌پرسی این حرف از کجا آمده",
            "وقتی فقط می‌خواهی حرف بزنی، نه اینکه قدمی برداری",
            "وقتی با خودت طوری حرف می‌زنی که با هیچ‌کس دیگر نمی‌زنی",
            "وقتی مسئله بیرون از توست، نه در الگوی تو",
            "چرا رفتار را توصیف می‌کنیم، نه آدم را",
        ):
            with self.subTest(title=title):
                self.assertIn(title, self.titles)

    def test_the_action_step_texts_are_present(self):
        """These sit inside the spec's claimed 1-28 range but the spec puts the action-step
        feature out of scope, so nothing would replace them."""
        for title in (
            "چرا یک قدم کوچک را به یک نقشه‌ی کامل ترجیح می‌دهیم",
            "چرا قدم برگشت‌پذیر را به قدم درست ترجیح می‌دهیم",
            "قدمی که واقعاً انجام می‌شود چه شکلی است",
            "چرا قبل از هر پیشنهادی از موقعیت الانت می‌پرسیم",
            "وقتی قدمی انجام نشده، چه می‌کنیم",
        ):
            with self.subTest(title=title):
                self.assertIn(title, self.titles)

    def test_the_four_test_and_big_five_texts_are_last(self):
        self.assertEqual(self.titles[-4:], [
            "این تست چه می‌سنجد و چه نمی‌سنجد",
            "گرایش‌ها سرنوشت نیستند",
            "وقتی نتیجه متعادل است و هیچ‌چیز برجسته نیست",
            "درباره‌ی تغییر رفتار چه چیزی نسبتاً روشن است",
        ])

    def test_every_text_still_has_a_body(self):
        for chunk in self.corpus.split("### ")[1:]:
            title, _, body = chunk.partition("\n")
            with self.subTest(title=title):
                self.assertGreater(len(body.strip()), 100)

    def test_the_corpus_stays_under_the_rag_threshold(self):
        """coach_roadmap_v2.html section 5 puts the RAG revisit trigger at ~90 texts or
        ~15,000 tokens. Crossing it should reopen docs/rag_decision_v1.md, not pass quietly.
        Chars are used rather than a tokenizer so the suite keeps no extra dependency;
        ~3.1 chars/token measured on this Persian corpus, so 15k tokens is ~46k chars."""
        self.assertLess(len(self.titles), 90)
        self.assertLess(len(self.corpus), 46_000)


# Written-register forms that spec section 5.1 rules out of the companion's speech. Matched
# as whole tokens, never as substrings: «این رابطه» contains «این را», «کدامین» contains
# «کدام». Persian substring matching produces false positives like this constantly.
_WRITTEN_REGISTER = {
    "می‌خواهی", "می‌توانی", "می‌توانم", "می‌شود", "نمی‌شود", "نمی‌دانم", "می‌دانی",
    "بگویی", "می‌آید", "برایت", "کدام", "اکنون", "چگونه", "می‌باشد", "نمایید",
}
_WRITTEN_PHRASES = ("چه چیزی", "این را", "آن را", "خودت را")

# At least one of these should appear in any stretch of real companion speech.
_COLLOQUIAL = ("می‌خوای", "می‌تونی", "می‌تونم", "می‌شه", "نمی‌شه", "نمی‌دونم", "چی",
               "یه ", "رو ", "برات", "بهش", "اینو", "همون", "چطوره", "کدوم", "الان")


def _written_register_hits(sentence: str) -> list[str]:
    tokens = set(re.split(r"[^\w\u200c]+", sentence))
    hits = sorted(tokens & _WRITTEN_REGISTER)
    hits += [p for p in _WRITTEN_PHRASES
             if re.search(rf"(?<![\w\u200c]){re.escape(p)}(?![\w\u200c])", sentence)]
    return hits


def _companion_sentences(text: str) -> list[str]:
    """Quoted strings that are a full sentence the companion says, not a term or a label."""
    return [q for q in re.findall(r"«([^»]{10,})»", text)
            if q.rstrip().endswith(("؟", ".", "…"))]


class RegisterCoherenceTests(unittest.TestCase):
    """Spec section 5.1 mandates polite colloquial Persian. The risk is not that the rule is
    missing -- it is that other blocks contradict it by example, and an example beats a rule.

    The action-step block used to do exactly that: its two worked dialogues had the person
    speaking colloquially and the assistant answering in written register, which is the split
    5.1 exists to prevent. These tests keep every block pulling the same way.
    """

    def test_every_sample_sentence_in_the_companion_block_is_colloquial(self):
        for sentence in _companion_sentences(_block()):
            with self.subTest(sentence=sentence[:48]):
                self.assertEqual(_written_register_hits(sentence), [])

    def test_the_assistant_turns_in_the_action_step_dialogues_are_colloquial(self):
        from apps.ai.chat_generation.action_step_prompt import ACTION_STEP_BLOCK

        turns = [l.split("assistant:", 1)[1].strip()
                 for l in ACTION_STEP_BLOCK.split("\n") if l.strip().startswith("assistant:")]
        self.assertGreaterEqual(len(turns), 5)
        for turn in turns:
            with self.subTest(turn=turn[:48]):
                self.assertEqual(_written_register_hits(turn), [])
                self.assertTrue(any(c in turn for c in _COLLOQUIAL), turn)

    def test_the_sample_step_text_is_colloquial(self):
        """Step text is companion speech. It is also the place the register slips most,
        because the step block is about mechanics and reads as a different register."""
        from apps.ai.chat_generation.action_step_prompt import ACTION_STEP_BLOCK

        self.assertIn("یه پیام به مدیرت بنویس", ACTION_STEP_BLOCK)
        self.assertIn("می‌خوای درباره‌ی این پروژه", ACTION_STEP_BLOCK)
        self.assertNotIn("می‌خواهی درباره‌ی این پروژه", ACTION_STEP_BLOCK)

    def test_the_action_step_block_defers_to_section_5_1_for_step_text(self):
        from apps.ai.chat_generation.action_step_prompt import ACTION_STEP_BLOCK

        self.assertIn("<companion_role> section 5.1", ACTION_STEP_BLOCK)

    def test_no_either_or_questions_in_the_worked_dialogues(self):
        """5.1: «سؤال دوگزینه‌ای نمی‌پرسد». Both action-step dialogues used to end a turn
        with one."""
        from apps.ai.chat_generation.action_step_prompt import ACTION_STEP_BLOCK

        for forbidden in ("سر کار، یا جاهای دیگر", "پیام، یا حضوری"):
            with self.subTest(forbidden=forbidden):
                self.assertNotIn(forbidden, ACTION_STEP_BLOCK)

    def test_role_states_the_register_rule_and_points_at_the_spec(self):
        from apps.ai.chat_generation.prompt import ROLE

        self.assertIn("**Register.**", ROLE)
        self.assertIn("<companion_role> section 5.1", ROLE)

    def test_role_warns_that_the_rule_blocks_are_not_the_output_voice(self):
        """The blocks below ROLE are formal Persian because they are rules. Without this
        note the model has 25k tokens of formal Persian and one rule saying otherwise."""
        from apps.ai.chat_generation.prompt import ROLE

        self.assertIn("that is not the voice you write in", ROLE)

    def test_section_5_1_lists_enough_word_pairs_to_act_on(self):
        """Three pairs are not a register, they are three words."""
        block = _block()
        for pair in ("می‌تونی", "می‌شه", "نمی‌دونم", "بهش", "اینو", "برات", "کدوم"):
            with self.subTest(pair=pair):
                self.assertIn(pair, block)

    def test_section_5_1_says_the_rule_covers_step_text(self):
        self.assertIn("از جمله متن قدم عملی", _block())

    def test_the_safety_block_wording_is_an_explicit_exception(self):
        """<safety_rules_chat_extension> hands the model 64 ready-to-say Persian sentences
        and 16 are in written register. That block outranks this one, so without an explicit
        carve-out the two rules simply contradict each other and the model picks arbitrarily.
        The carve-out is deliberately narrow: crisis and boundary moments only."""
        block = _block()
        self.assertIn("یک استثنا", block)
        self.assertIn("آنجا دقت بر لحن مقدم است", block)
        self.assertIn("این استثنا فقط برای بحران و مرز است", block)


class SpecFidelityTests(unittest.TestCase):
    """Places where an earlier pass drifted from the PM text and was corrected back."""

    def test_the_beliefs_are_hedged_exactly_as_the_spec_hedges_them(self):
        """The spec says «بیشترشان» -- most of them. Belief 5 is why: the companion does
        state an opinion about the person, with permission. Absolutising it was wrong."""
        self.assertIn("بیشترشان به کاربر گفته نمی‌شوند", _block())

    def test_the_self_check_keeps_its_rationale(self):
        """Without the opening sentence the three questions in 3.4 look arbitrary."""
        self.assertIn("همراه هم حرف کاربر را از دید خودش می‌فهمد", _block())


class PromptVersionTests(unittest.TestCase):
    def test_the_prompt_version_was_bumped(self):
        """A changed prompt under an unchanged version would both poison the prompt cache
        and make stored messages unattributable in a quality comparison."""
        self.assertEqual(PROMPT_VERSION, "chat_v4")

    def test_the_chat_app_reads_the_version_from_the_ai_boundary(self):
        """apps.chat used to keep its own literal copy, which could silently drift."""
        from apps.chat.services import chat_service

        self.assertEqual(chat_service.PROMPT_VERSION, PROMPT_VERSION)

    def test_the_cache_key_follows_the_version(self):
        from apps.ai.chat_generation.generate import PROMPT_CACHE_KEY

        self.assertEqual(PROMPT_CACHE_KEY, PROMPT_VERSION)


class RoleBlockHandoffTests(unittest.TestCase):
    """ROLE used to own tone and identity. It now defers to the companion block, and must
    not contradict it."""

    def setUp(self):
        from apps.ai.chat_generation.prompt import ROLE

        self.role = ROLE

    def test_role_hands_identity_and_tone_to_the_companion_block(self):
        self.assertIn("<companion_role>", self.role)

    def test_role_keeps_what_the_spec_leaves_to_the_engineer(self):
        """The spec states that reply length is the engineer's call, so ROLE must keep it."""
        self.assertIn("## Length and format", self.role)

    def test_role_warns_against_copying_both_non_first_person_voices(self):
        self.assertIn("«ما»", self.role)
        self.assertIn("«همراه»", self.role)

    def test_role_no_longer_duplicates_the_memory_precedence_rule(self):
        """Section 3.4 of the companion block owns it. Two copies would drift."""
        self.assertIn("section 3.4", self.role)
        self.assertNotIn("they are right and you drop it", self.role)
