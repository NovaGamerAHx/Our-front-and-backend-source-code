"""Cost calculation for AI generation_meta (report_spec_v1.4 §4.4).

AI generation services (apps.ai.report_generation today, chat later) intentionally return
only raw usage -- model_used/input_tokens/output_tokens -- never a cost, because pricing is
business logic, not AI logic, and the model lineup isn't finalized yet. This is the one place
that turns that raw usage into a cost, against the config-driven ModelPricing table so a
price change is an admin edit, not a deploy.
"""

from decimal import Decimal

from apps.ai.models import ModelPricing


def calculate_cost(
    model_used: str | None, input_tokens: int, output_tokens: int, cached_input_tokens: int = 0,
) -> Decimal | None:
    """None whenever a cost can't be determined -- no model was used, or this model has no
    configured price -- never a guessed number.

    `cached_input_tokens` is the slice of `input_tokens` that the provider served from its
    prompt cache (chat_spec_v3_1.md §2.6). Providers report it as a subset of the input total,
    not on top of it, so it is billed at the cached rate and the rest at the full input rate.
    A model with no `cached_input_price_per_million` configured falls back to the full input
    rate for the cached slice too.
    """
    if not model_used:
        return None

    pricing = ModelPricing.objects.filter(model_name=model_used).first()
    if pricing is None:
        return None

    cached = max(0, min(cached_input_tokens, input_tokens))
    uncached = input_tokens - cached
    cached_price = (
        pricing.cached_input_price_per_million
        if pricing.cached_input_price_per_million is not None
        else pricing.input_price_per_million
    )

    return (
        Decimal(uncached) * pricing.input_price_per_million
        + Decimal(cached) * cached_price
        + Decimal(output_tokens) * pricing.output_price_per_million
    ) / Decimal(1_000_000)
