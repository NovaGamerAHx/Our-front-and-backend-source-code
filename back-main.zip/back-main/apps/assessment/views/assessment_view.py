from drf_spectacular.utils import extend_schema
from rest_framework.permissions import AllowAny
from rest_framework.views import APIView

from apps.assessment.serializers.assessment_serializer import AssessmentSerializer
from apps.assessment.services.assessment_service import AssessmentService
from apps.assessment.services.exceptions import AssessmentNotFoundException
from faraman_back.lang.utils import get_message
from faraman_back.utils.responses import ApiResponse
from faraman_back.utils.schema import error_responses


class AssessmentDetailAPIView(APIView):
    permission_classes = [AllowAny]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.assessment_service = AssessmentService()

    @extend_schema(
        description="Returns an active assessment and its active questions by slug. "
                    "Public endpoint — usable before signup for the anonymous test flow.",
        tags=["Assessment"],
        responses=error_responses(AssessmentNotFoundException),
    )
    def get(self, request, slug):
        assessment = self.assessment_service.get_assessment(slug)

        return ApiResponse.success(
            data=AssessmentSerializer(instance=assessment).data,
            message=get_message('fetched_successfully'),
        )
