from drf_spectacular.utils import extend_schema
from rest_framework.permissions import AllowAny
from rest_framework.views import APIView

from apps.assessment.serializers.attempt_serializer import (
    AnswerSerializer,
    AttemptSerializer,
    StartAttemptSerializer,
    SubmitAnswerSerializer,
)
from apps.assessment.services.attempt_service import AttemptService
from apps.assessment.services.exceptions import (
    AnswerNotFoundException,
    AssessmentNotFoundException,
    AttemptAccessDeniedException,
    AttemptAlreadyCompletedException,
    AttemptIncompleteException,
    AttemptLimitExceededException,
    AttemptNotFoundException,
    InvalidAnswerValueException,
    PurchaseRequiredException,
    QuestionNotFoundException,
)
from faraman_back.lang.utils import get_message
from faraman_back.utils.responses import ApiResponse
from faraman_back.utils.schema import error_responses


class PreStartAttemptAPIView(APIView):
    permission_classes = [AllowAny]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.attempt_service = AttemptService()

    @extend_schema(
        description="Info to show before starting an assessment: the identity's latest report for "
                    "it (if any, gated the same way as GET report detail — preview for anonymous, "
                    "full for authenticated) and how many new attempts remain in today's limit, plus whether an unfinished "
                    "attempt exists (resuming it doesn't use up the limit). "
                    "Works before signup.",
        tags=["Assessment"],
        responses=error_responses(AssessmentNotFoundException),
    )
    def get(self, request, slug):
        user = request.user if request.user.is_authenticated else None

        data = self.attempt_service.get_pre_start(
            assessment_slug=slug,
            user=user,
            anonymous_id=request.anonymous_id,
        )

        return ApiResponse.success(data=data)


class StartAttemptAPIView(APIView):
    permission_classes = [AllowAny]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.attempt_service = AttemptService()

    @extend_schema(
        description="Starts a new attempt for an assessment, or resumes an existing in-progress one "
                    "for the same user/anonymous_id. Works before signup. When resuming, the response "
                    "includes the answers already recorded for the attempt.",
        tags=["Assessment"],
        request=StartAttemptSerializer,
        responses=error_responses(AssessmentNotFoundException, AttemptLimitExceededException, PurchaseRequiredException),
    )
    def post(self, request):
        ser = StartAttemptSerializer(data=request.data)
        if not ser.is_valid():
            return ApiResponse.validation_error(data=ser.errors)

        user = request.user if request.user.is_authenticated else None

        attempt = self.attempt_service.start_attempt(
            assessment_slug=ser.validated_data["assessment_slug"],
            user=user,
            anonymous_id=request.anonymous_id,
            source=ser.validated_data.get("source"),
        )

        return ApiResponse.success(
            data=AttemptSerializer(instance=attempt).data,
            message=get_message("created_successfully"),
        )


class SubmitAnswerAPIView(APIView):
    permission_classes = [AllowAny]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.attempt_service = AttemptService()

    @extend_schema(
        description="Submits (or overwrites) the answer to one question of an in-progress attempt.",
        tags=["Assessment"],
        request=SubmitAnswerSerializer,
        responses=error_responses(
            AttemptNotFoundException,
            AttemptAccessDeniedException,
            AttemptAlreadyCompletedException,
            QuestionNotFoundException,
            InvalidAnswerValueException,
        ),
    )
    def post(self, request, attempt_id):
        ser = SubmitAnswerSerializer(data=request.data)
        if not ser.is_valid():
            return ApiResponse.validation_error(data=ser.errors)

        user = request.user if request.user.is_authenticated else None

        answer = self.attempt_service.submit_answer(
            attempt_id=attempt_id,
            question_id=ser.validated_data["question_id"],
            value=ser.validated_data["value"],
            user=user,
            anonymous_id=request.anonymous_id,
        )

        return ApiResponse.success(
            data=AnswerSerializer(instance=answer).data,
            message=get_message("created_successfully"),
        )


class UndoAnswerAPIView(APIView):
    permission_classes = [AllowAny]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.attempt_service = AttemptService()

    @extend_schema(
        description="Undoes (deletes) the answer to one question of an in-progress attempt.",
        tags=["Assessment"],
        responses=error_responses(
            AttemptNotFoundException,
            AttemptAccessDeniedException,
            AttemptAlreadyCompletedException,
            QuestionNotFoundException,
            AnswerNotFoundException,
        ),
    )
    def delete(self, request, attempt_id, question_id):
        user = request.user if request.user.is_authenticated else None

        self.attempt_service.undo_answer(
            attempt_id=attempt_id,
            question_id=question_id,
            user=user,
            anonymous_id=request.anonymous_id,
        )

        return ApiResponse.success(message=get_message("deleted_successfully"))


class CompleteAttemptAPIView(APIView):
    permission_classes = [AllowAny]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.attempt_service = AttemptService()

    @extend_schema(
        description="Marks an in-progress attempt as completed.",
        tags=["Assessment"],
        responses=error_responses(
            AttemptNotFoundException,
            AttemptAccessDeniedException,
            AttemptAlreadyCompletedException,
            AttemptIncompleteException,
        ),
    )
    def post(self, request, attempt_id):
        user = request.user if request.user.is_authenticated else None

        attempt = self.attempt_service.complete_attempt(
            attempt_id=attempt_id,
            user=user,
            anonymous_id=request.anonymous_id,
        )

        return ApiResponse.success(
            data=AttemptSerializer(instance=attempt).data,
            message=get_message("updated_successfully"),
        )
