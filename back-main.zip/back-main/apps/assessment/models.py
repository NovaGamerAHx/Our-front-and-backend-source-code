from django.conf import settings
from django.db import models


class Assessment(models.Model):
    class Kind(models.TextChoices):
        INITIAL = "initial", "Initial"
        SUPPLEMENTARY = "supplementary", "Supplementary"

    class ScoringProfile(models.TextChoices):
        """How this assessment's answers turn into scores -- picks the ScoringService.

        Not derivable from `kind` or `slug`: a later deep-150-v2 would be a different slug on
        the same scoring rules. ScoringRouter reads this field and nothing else.
        """
        BIG_FIVE_30 = "big_five_30", "Big Five (30 items, section title = dimension)"
        FACET_150 = "facet_150", "30 facets (150 items, per-question key)"

    slug = models.SlugField(unique=True)
    title = models.CharField(max_length=200)
    kind = models.CharField(max_length=20, choices=Kind.choices, default=Kind.INITIAL)
    scoring_profile = models.CharField(
        max_length=20, choices=ScoringProfile.choices, default=ScoringProfile.BIG_FIVE_30
    )
    version = models.PositiveIntegerField(default=1)
    is_active = models.BooleanField(default=True)
    requires_purchase = models.BooleanField(default=False)
    # Pay-after-test: the attempt is free to take, but the finished report stays locked
    # (Report.Status.AWAITING_PAYMENT) until a Payment bound to that attempt is paid.
    report_requires_purchase = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "assessments"

    def __str__(self):
        return f"{self.title} (v{self.version})"


class AssessmentSection(models.Model):
    assessment = models.ForeignKey(Assessment, on_delete=models.CASCADE, related_name="sections")
    title = models.CharField(max_length=200)
    order = models.PositiveSmallIntegerField()
    interstitial_message = models.TextField(blank=True)  # shown between sections, e.g. "Section 1 complete..."

    class Meta:
        db_table = "assessment_sections"
        ordering = ["order"]
        constraints = [
            models.UniqueConstraint(fields=["assessment", "order"], name="unique_section_order_per_assessment"),
        ]

    def __str__(self):
        return f"{self.assessment.slug} / {self.title}"


class Question(models.Model):
    class QuestionType(models.TextChoices):
        LIKERT = "likert", "Likert"
        SINGLE = "single", "Single choice"
        MULTI = "multi", "Multi choice"
        TEXT = "text", "Free text"

    section = models.ForeignKey(AssessmentSection, on_delete=models.CASCADE, related_name="questions")
    order = models.PositiveSmallIntegerField()
    text = models.TextField()
    question_type = models.CharField(max_length=20, choices=QuestionType.choices)
    options = models.JSONField(default=list, blank=True)  # [{value, label, weight...}]
    scoring = models.JSONField(default=dict, blank=True)  # trait weights, backend-only
    reverse_scored = models.BooleanField(default=False)  # if true, adjusted value = 6 - value
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "assessment_questions"
        ordering = ["order"]
        constraints = [
            models.UniqueConstraint(fields=["section", "order"], name="unique_question_order_per_section"),
        ]

    def __str__(self):
        return f"{self.section.assessment.slug} / {self.section.title} #{self.order}"


class Attempt(models.Model):
    class Status(models.TextChoices):
        IN_PROGRESS = "in_progress", "In progress"
        COMPLETED = "completed", "Completed"
        ABANDONED = "abandoned", "Abandoned"

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="attempts"
    )
    anonymous_id = models.CharField(max_length=64, null=True, blank=True, db_index=True)
    assessment = models.ForeignKey(Assessment, on_delete=models.PROTECT, related_name="attempts")
    status = models.CharField(max_length=15, choices=Status.choices, default=Status.IN_PROGRESS)
    current_section = models.ForeignKey(
        AssessmentSection, null=True, blank=True, on_delete=models.SET_NULL, related_name="+"
    )
    started_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    source = models.JSONField(default=dict, blank=True)  # utm / landing variant
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "assessment_attempts"
        indexes = [
            models.Index(fields=["anonymous_id"]),
            models.Index(fields=["user", "status"]),
        ]

    def __str__(self):
        return f"Attempt #{self.id} ({self.assessment.slug})"


class Answer(models.Model):
    attempt = models.ForeignKey(Attempt, on_delete=models.CASCADE, related_name="answers")
    question = models.ForeignKey(Question, on_delete=models.PROTECT, related_name="answers")
    value = models.JSONField()  # scalar, list, or text depending on question_type
    answered_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "assessment_answers"
        constraints = [
            models.UniqueConstraint(fields=["attempt", "question"], name="unique_answer_per_attempt_question"),
        ]

    def __str__(self):
        return f"Answer to Q{self.question_id} in Attempt #{self.attempt_id}"
