from django.core.management.base import BaseCommand

from apps.assessment.models import Assessment, AssessmentSection, Question
from apps.report.services.scoring_service import DIMENSION_ORDER

# 6 Likert questions per Big Five dimension (report_service.ScoringService assumes exactly 6
# answers per dimension: score_percent = (sum - 6) / 24 * 100). Section titles must be exactly
# one of DIMENSION_ORDER's keys for ScoringService.is_complete()/score_attempt() to pick them up.
DIMENSION_QUESTIONS = {
    "emotional_stability": [
        ("اغلب اوقات احساس آرامش می‌کنم.", False),
        ("به راحتی نگران می‌شوم.", True),
        ("در موقعیت‌های پراسترس خونسردی خود را حفظ می‌کنم.", False),
        ("خلق‌وخویم به سرعت تغییر می‌کند.", True),
        ("کمتر دچار افکار منفی می‌شوم.", False),
        ("وقتی برنامه‌هایم به هم می‌ریزد، به‌سختی آرامشم را حفظ می‌کنم.", True),
    ],
    "extraversion": [
        ("در جمع‌های اجتماعی پرانرژی هستم.", False),
        ("ترجیح می‌دهم بیشتر وقتم را تنها بگذرانم.", True),
        ("به راحتی با افراد غریبه صحبت می‌کنم.", False),
        ("در جمع‌های شلوغ احساس خستگی می‌کنم.", True),
        ("دوست دارم مرکز توجه باشم.", False),
        ("در جمع‌های جدید معمولاً شروع‌کنندهٔ گفتگو هستم.", False),
    ],
    "openness": [
        ("به ایده‌های جدید علاقه‌مندم.", False),
        ("تخیل قوی‌ای دارم.", False),
        ("ترجیح می‌دهم کارها را به روش‌های آشنا و همیشگی انجام دهم.", True),
        ("از هنر و زیبایی‌شناسی لذت می‌برم.", False),
        ("کنجکاوی زیادی دربارهٔ جهان اطرافم دارم.", False),
        ("تغییر و تنوع در زندگی برایم جذاب است.", False),
    ],
    "agreeableness": [
        ("به احساسات دیگران اهمیت می‌دهم.", False),
        ("به‌راحتی به دیگران اعتماد می‌کنم.", False),
        ("در بحث‌ها بیشتر به دنبال بردن هستم تا همدلی.", True),
        ("برای کمک به دیگران وقت می‌گذارم.", False),
        ("نیازهای دیگران را در اولویت بالایی قرار می‌دهم.", False),
        ("وقتی با کسی مخالفم، صریح و گاهی تند برخورد می‌کنم.", True),
    ],
    "conscientiousness": [
        ("کارهایم را از قبل برنامه‌ریزی می‌کنم.", False),
        ("به جزئیات توجه زیادی دارم.", False),
        ("اغلب کارها را به تعویق می‌اندازم.", True),
        ("در انجام تعهداتم دقیق و منظم هستم.", False),
        ("محیط اطرافم را مرتب نگه می‌دارم.", False),
        ("قبل از شروع یک کار، معمولاً منتظر شرایط ایده‌آل می‌مانم.", True),
    ],
}


class Command(BaseCommand):
    help = (
        "Creates (or updates) the 'test-likert-v2' assessment with 5 sections — one per Big Five "
        "dimension (emotional_stability/extraversion/openness/agreeableness/conscientiousness), "
        "6 Likert questions each — so completed attempts are scoreable and ReportService can "
        "actually generate a report (ScoringService.is_complete() requires section titles to match "
        "DIMENSION_ORDER). Idempotent: safe to run multiple times."
    )

    def handle(self, *args, **options):
        assessment, created = Assessment.objects.update_or_create(
            slug="test-likert-v2",
            defaults={
                "title": "Test Likert Assessment",
                "kind": Assessment.Kind.INITIAL,
                "version": 1,
                "is_active": True,
                "requires_purchase": False,
            },
        )

        total_questions = 0
        for section_order, dimension in enumerate(DIMENSION_ORDER, start=1):
            section, _ = AssessmentSection.objects.update_or_create(
                assessment=assessment,
                order=section_order,
                defaults={"title": dimension, "interstitial_message": ""},
            )

            for question_order, (text, reverse_scored) in enumerate(
                DIMENSION_QUESTIONS[dimension], start=1
            ):
                Question.objects.update_or_create(
                    section=section,
                    order=question_order,
                    defaults={
                        "text": text,
                        "question_type": Question.QuestionType.LIKERT,
                        "options": [],
                        "scoring": {},
                        "reverse_scored": reverse_scored,
                        "is_active": True,
                    },
                )
                total_questions += 1

            # Deactivate stale questions from earlier seed runs (e.g. the old 10-question
            # "General" section) so each dimension has exactly the 6 active questions
            # ScoringService expects. Deactivate rather than delete since Answer.question is a
            # protected FK — existing attempts may already have answered these.
            Question.objects.filter(
                section=section, order__gt=len(DIMENSION_QUESTIONS[dimension])
            ).update(is_active=False)

        verb = "Created" if created else "Updated"
        self.stdout.write(
            self.style.SUCCESS(
                f"{verb} assessment '{assessment.slug}' with {len(DIMENSION_ORDER)} sections "
                f"and {total_questions} questions."
            )
        )
