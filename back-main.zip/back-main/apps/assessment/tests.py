from unittest.mock import MagicMock

from django.test import TestCase

from apps.assessment.models import Answer, Assessment, AssessmentSection, Attempt, Question
from apps.assessment.repositories.attempt_repository import AttemptRepository
from apps.assessment.serializers.attempt_serializer import AttemptSerializer
from apps.assessment.services.assessment_service import AssessmentService
from apps.assessment.services.attempt_service import AttemptService
from apps.assessment.services.exceptions import (
    AnswerNotFoundException,
    AssessmentNotFoundException,
    AttemptAccessDeniedException,
    AttemptAlreadyCompletedException,
    AttemptIncompleteException,
    AttemptLimitExceededException,
    AttemptNotFoundException,
    InvalidAnswerValueException,
    PurchaseRequiredException,
    QuestionNotFoundException,
    ReportGenerationInProgressException,
)


class AssessmentServiceGetAssessmentTests(TestCase):
    def setUp(self):
        self.assessment_repository = MagicMock()
        self.service = AssessmentService(assessment_repository=self.assessment_repository)

    def test_raises_when_no_active_assessment_for_slug(self):
        self.assessment_repository.get_active_by_slug.return_value = None

        with self.assertRaises(AssessmentNotFoundException):
            self.service.get_assessment('unknown-slug')

    def test_returns_assessment_when_found(self):
        assessment = MagicMock()
        self.assessment_repository.get_active_by_slug.return_value = assessment

        result = self.service.get_assessment('initial-v1')

        self.assertIs(result, assessment)
        self.assessment_repository.get_active_by_slug.assert_called_once_with('initial-v1')


class AttemptServiceStartAttemptTests(TestCase):
    def setUp(self):
        self.attempt_repository = MagicMock()
        self.assessment_repository = MagicMock()
        self.attempt_throttle_repository = MagicMock()
        self.attempt_throttle_repository.hit.return_value = False
        self.report_service = MagicMock()
        self.report_service.has_report_generating.return_value = False
        self.service = AttemptService(
            attempt_repository=self.attempt_repository,
            assessment_repository=self.assessment_repository,
            attempt_throttle_repository=self.attempt_throttle_repository,
            report_service=self.report_service,
        )

    def test_raises_when_no_active_assessment_for_slug(self):
        self.assessment_repository.get_active_by_slug.return_value = None

        with self.assertRaises(AssessmentNotFoundException):
            self.service.start_attempt(assessment_slug='unknown-slug', user=None, anonymous_id='anon-1')

    def test_resumes_existing_in_progress_attempt(self):
        assessment = MagicMock()
        existing_attempt = MagicMock()
        self.assessment_repository.get_active_by_slug.return_value = assessment
        self.attempt_repository.get_in_progress.return_value = existing_attempt

        result = self.service.start_attempt(assessment_slug='test-likert-v1', user=None, anonymous_id='anon-1')

        self.assertIs(result, existing_attempt)
        self.attempt_repository.create.assert_not_called()

    def test_does_not_check_limit_when_resuming_in_progress_attempt(self):
        assessment = MagicMock()
        existing_attempt = MagicMock()
        self.assessment_repository.get_active_by_slug.return_value = assessment
        self.attempt_repository.get_in_progress.return_value = existing_attempt

        self.service.start_attempt(assessment_slug='test-likert-v1', user=None, anonymous_id='anon-1')

        self.attempt_throttle_repository.hit.assert_not_called()

    def test_creates_new_attempt_when_none_in_progress(self):
        assessment = MagicMock(requires_purchase=False)
        new_attempt = MagicMock()
        self.assessment_repository.get_active_by_slug.return_value = assessment
        self.attempt_repository.get_in_progress.return_value = None
        self.attempt_repository.create.return_value = new_attempt

        result = self.service.start_attempt(assessment_slug='test-likert-v1', user=None, anonymous_id='anon-1')

        self.assertIs(result, new_attempt)
        self.attempt_repository.create.assert_called_once_with(
            assessment=assessment, user=None, anonymous_id='anon-1', source=None
        )

    def test_checks_limit_keyed_by_anonymous_id(self):
        assessment = MagicMock(slug='test-likert-v1', requires_purchase=False)
        self.assessment_repository.get_active_by_slug.return_value = assessment
        self.attempt_repository.get_in_progress.return_value = None
        self.attempt_repository.create.return_value = MagicMock()

        self.service.start_attempt(assessment_slug='test-likert-v1', user=None, anonymous_id='anon-1')

        self.attempt_throttle_repository.hit.assert_called_once_with('anon:anon-1', 'test-likert-v1')

    def test_checks_limit_keyed_by_user_id_when_authenticated(self):
        assessment = MagicMock(slug='test-likert-v1', requires_purchase=False)
        user = MagicMock(id=42)
        self.assessment_repository.get_active_by_slug.return_value = assessment
        self.attempt_repository.get_in_progress.return_value = None
        self.attempt_repository.create.return_value = MagicMock()

        self.service.start_attempt(assessment_slug='test-likert-v1', user=user, anonymous_id='anon-1')

        self.attempt_throttle_repository.hit.assert_called_once_with('user:42', 'test-likert-v1')

    def test_raises_when_attempt_limit_exceeded(self):
        assessment = MagicMock(slug='test-likert-v1', requires_purchase=False)
        self.assessment_repository.get_active_by_slug.return_value = assessment
        self.attempt_repository.get_in_progress.return_value = None
        self.attempt_throttle_repository.hit.return_value = True

        with self.assertRaises(AttemptLimitExceededException):
            self.service.start_attempt(assessment_slug='test-likert-v1', user=None, anonymous_id='anon-1')

        self.attempt_repository.create.assert_not_called()

    def test_raises_when_a_previous_report_is_still_generating(self):
        assessment = MagicMock(slug='deep-150-v1', requires_purchase=False)
        self.assessment_repository.get_active_by_slug.return_value = assessment
        self.attempt_repository.get_in_progress.return_value = None
        self.report_service.has_report_generating.return_value = True

        with self.assertRaises(ReportGenerationInProgressException):
            self.service.start_attempt(assessment_slug='deep-150-v1', user=None, anonymous_id='anon-1')

        self.attempt_repository.create.assert_not_called()
        self.attempt_throttle_repository.hit.assert_not_called()


class AttemptServiceStartAttemptPurchaseGateTests(TestCase):
    def setUp(self):
        self.attempt_repository = MagicMock()
        self.assessment_repository = MagicMock()
        self.attempt_throttle_repository = MagicMock()
        self.attempt_throttle_repository.hit.return_value = False
        self.entitlement_service = MagicMock()
        self.report_service = MagicMock()
        self.report_service.has_report_generating.return_value = False
        self.service = AttemptService(
            attempt_repository=self.attempt_repository,
            assessment_repository=self.assessment_repository,
            attempt_throttle_repository=self.attempt_throttle_repository,
            entitlement_service=self.entitlement_service,
            report_service=self.report_service,
        )
        self.assessment = MagicMock(slug='deep-test-v1', requires_purchase=True)
        self.assessment_repository.get_active_by_slug.return_value = self.assessment
        self.attempt_repository.get_in_progress.return_value = None

    def test_raises_when_anonymous_requester_has_no_user(self):
        self.entitlement_service.has_access_to_assessment.return_value = False

        with self.assertRaises(PurchaseRequiredException):
            self.service.start_attempt(assessment_slug='deep-test-v1', user=None, anonymous_id='anon-1')

        self.attempt_repository.create.assert_not_called()

    def test_raises_when_authenticated_user_has_not_purchased(self):
        user = MagicMock(id=42)
        self.entitlement_service.has_access_to_assessment.return_value = False

        with self.assertRaises(PurchaseRequiredException):
            self.service.start_attempt(assessment_slug='deep-test-v1', user=user, anonymous_id=None)

        self.entitlement_service.has_access_to_assessment.assert_called_once_with(user=user, assessment=self.assessment)
        self.attempt_repository.create.assert_not_called()

    def test_creates_attempt_when_user_has_purchased(self):
        user = MagicMock(id=42)
        self.entitlement_service.has_access_to_assessment.return_value = True
        new_attempt = MagicMock()
        self.attempt_repository.create.return_value = new_attempt

        result = self.service.start_attempt(assessment_slug='deep-test-v1', user=user, anonymous_id=None)

        self.assertIs(result, new_attempt)

    def test_does_not_check_purchase_when_resuming_in_progress_attempt(self):
        existing_attempt = MagicMock()
        self.attempt_repository.get_in_progress.return_value = existing_attempt

        result = self.service.start_attempt(assessment_slug='deep-test-v1', user=None, anonymous_id='anon-1')

        self.assertIs(result, existing_attempt)
        self.entitlement_service.has_access_to_assessment.assert_not_called()


class AttemptServiceGetPreStartTests(TestCase):
    def setUp(self):
        self.attempt_repository = MagicMock()
        self.assessment_repository = MagicMock()
        self.report_service = MagicMock()
        self.attempt_throttle_repository = MagicMock()
        self.service = AttemptService(
            attempt_repository=self.attempt_repository,
            assessment_repository=self.assessment_repository,
            report_service=self.report_service,
            attempt_throttle_repository=self.attempt_throttle_repository,
        )

    def test_raises_when_no_active_assessment_for_slug(self):
        self.assessment_repository.get_active_by_slug.return_value = None

        with self.assertRaises(AssessmentNotFoundException):
            self.service.get_pre_start(assessment_slug='unknown-slug', user=None, anonymous_id='anon-1')

    def test_returns_no_previous_report_when_none_exists(self):
        assessment = MagicMock(slug='test-likert-v1')
        self.assessment_repository.get_active_by_slug.return_value = assessment
        self.report_service.get_latest_for_identity.return_value = None
        self.attempt_throttle_repository.remaining.return_value = 2

        result = self.service.get_pre_start(assessment_slug='test-likert-v1', user=None, anonymous_id='anon-1')

        self.assertFalse(result['has_previous_report'])
        self.assertIsNone(result['latest_report'])
        self.assertEqual(result['remaining_attempts_today'], 2)
        self.assertEqual(result['attempt_limit'], 2)
        self.report_service.get_latest_for_identity.assert_called_once_with(
            assessment=assessment, user=None, anonymous_id='anon-1'
        )

    def test_returns_previous_report_when_one_exists(self):
        assessment = MagicMock(slug='test-likert-v1')
        latest_report = {'attempt_id': 7, 'status': 'ok', 'stage': 'preview'}
        self.assessment_repository.get_active_by_slug.return_value = assessment
        self.report_service.get_latest_for_identity.return_value = latest_report
        self.attempt_throttle_repository.remaining.return_value = 1

        result = self.service.get_pre_start(assessment_slug='test-likert-v1', user=None, anonymous_id='anon-1')

        self.assertTrue(result['has_previous_report'])
        self.assertIs(result['latest_report'], latest_report)
        self.assertEqual(result['remaining_attempts_today'], 1)

    def test_reports_in_progress_attempt_even_when_quota_is_used_up(self):
        assessment = MagicMock(slug='test-likert-v1')
        self.assessment_repository.get_active_by_slug.return_value = assessment
        self.report_service.get_latest_for_identity.return_value = None
        self.attempt_throttle_repository.remaining.return_value = 0
        self.attempt_repository.get_in_progress.return_value = MagicMock()

        result = self.service.get_pre_start(assessment_slug='test-likert-v1', user=None, anonymous_id='anon-1')

        self.assertTrue(result['has_in_progress_attempt'])
        self.assertEqual(result['remaining_attempts_today'], 0)

    def test_checks_remaining_keyed_by_anonymous_id(self):
        assessment = MagicMock(slug='test-likert-v1')
        self.assessment_repository.get_active_by_slug.return_value = assessment
        self.report_service.get_latest_for_identity.return_value = None
        self.attempt_throttle_repository.remaining.return_value = 0

        result = self.service.get_pre_start(assessment_slug='test-likert-v1', user=None, anonymous_id='anon-1')

        self.attempt_throttle_repository.remaining.assert_called_once_with('anon:anon-1', 'test-likert-v1')
        self.assertEqual(result['remaining_attempts_today'], 0)

    def test_checks_remaining_keyed_by_user_id_when_authenticated(self):
        assessment = MagicMock(slug='test-likert-v1')
        user = MagicMock(id=42)
        self.assessment_repository.get_active_by_slug.return_value = assessment
        self.report_service.get_latest_for_identity.return_value = None
        self.attempt_throttle_repository.remaining.return_value = 2

        self.service.get_pre_start(assessment_slug='test-likert-v1', user=user, anonymous_id='anon-1')

        self.attempt_throttle_repository.remaining.assert_called_once_with('user:42', 'test-likert-v1')


class AttemptServiceSubmitAnswerTests(TestCase):
    def setUp(self):
        self.attempt_repository = MagicMock()
        self.assessment_repository = MagicMock()
        self.service = AttemptService(
            attempt_repository=self.attempt_repository, assessment_repository=self.assessment_repository
        )

    def _attempt(self, *, user_id=None, anonymous_id=None, status=Attempt.Status.IN_PROGRESS):
        attempt = MagicMock()
        attempt.user_id = user_id
        attempt.anonymous_id = anonymous_id
        attempt.status = status
        return attempt

    def test_raises_when_attempt_not_found(self):
        self.attempt_repository.get_by_id.return_value = None

        with self.assertRaises(AttemptNotFoundException):
            self.service.submit_answer(attempt_id=1, question_id=1, value=3, user=None, anonymous_id='anon-1')

    def test_raises_when_requester_does_not_own_attempt(self):
        self.attempt_repository.get_by_id.return_value = self._attempt(anonymous_id='someone-else')

        with self.assertRaises(AttemptAccessDeniedException):
            self.service.submit_answer(attempt_id=1, question_id=1, value=3, user=None, anonymous_id='anon-1')

    def test_raises_when_attempt_already_completed(self):
        self.attempt_repository.get_by_id.return_value = self._attempt(
            anonymous_id='anon-1', status=Attempt.Status.COMPLETED
        )

        with self.assertRaises(AttemptAlreadyCompletedException):
            self.service.submit_answer(attempt_id=1, question_id=1, value=3, user=None, anonymous_id='anon-1')

    def test_raises_when_question_not_found(self):
        self.attempt_repository.get_by_id.return_value = self._attempt(anonymous_id='anon-1')
        self.assessment_repository.get_active_question.return_value = None

        with self.assertRaises(QuestionNotFoundException):
            self.service.submit_answer(attempt_id=1, question_id=1, value=3, user=None, anonymous_id='anon-1')

    def test_raises_when_likert_value_out_of_range(self):
        self.attempt_repository.get_by_id.return_value = self._attempt(anonymous_id='anon-1')
        question = MagicMock(question_type=Question.QuestionType.LIKERT)
        self.assessment_repository.get_active_question.return_value = question

        with self.assertRaises(InvalidAnswerValueException):
            self.service.submit_answer(attempt_id=1, question_id=1, value=9, user=None, anonymous_id='anon-1')

    def test_upserts_answer_when_valid(self):
        attempt = self._attempt(anonymous_id='anon-1')
        self.attempt_repository.get_by_id.return_value = attempt
        question = MagicMock(question_type=Question.QuestionType.LIKERT)
        self.assessment_repository.get_active_question.return_value = question
        answer = MagicMock()
        self.attempt_repository.upsert_answer.return_value = answer

        result = self.service.submit_answer(attempt_id=1, question_id=1, value=4, user=None, anonymous_id='anon-1')

        self.assertIs(result, answer)
        self.attempt_repository.upsert_answer.assert_called_once_with(attempt=attempt, question=question, value=4)


class AttemptServiceUndoAnswerTests(TestCase):
    def setUp(self):
        self.attempt_repository = MagicMock()
        self.assessment_repository = MagicMock()
        self.service = AttemptService(
            attempt_repository=self.attempt_repository, assessment_repository=self.assessment_repository
        )

    def _attempt(self, *, user_id=None, anonymous_id=None, status=Attempt.Status.IN_PROGRESS):
        attempt = MagicMock()
        attempt.user_id = user_id
        attempt.anonymous_id = anonymous_id
        attempt.status = status
        return attempt

    def test_raises_when_attempt_not_found(self):
        self.attempt_repository.get_by_id.return_value = None

        with self.assertRaises(AttemptNotFoundException):
            self.service.undo_answer(attempt_id=1, question_id=1, user=None, anonymous_id='anon-1')

    def test_raises_when_requester_does_not_own_attempt(self):
        self.attempt_repository.get_by_id.return_value = self._attempt(anonymous_id='someone-else')

        with self.assertRaises(AttemptAccessDeniedException):
            self.service.undo_answer(attempt_id=1, question_id=1, user=None, anonymous_id='anon-1')

    def test_raises_when_attempt_already_completed(self):
        self.attempt_repository.get_by_id.return_value = self._attempt(
            anonymous_id='anon-1', status=Attempt.Status.COMPLETED
        )

        with self.assertRaises(AttemptAlreadyCompletedException):
            self.service.undo_answer(attempt_id=1, question_id=1, user=None, anonymous_id='anon-1')

    def test_raises_when_question_not_found(self):
        self.attempt_repository.get_by_id.return_value = self._attempt(anonymous_id='anon-1')
        self.assessment_repository.get_active_question.return_value = None

        with self.assertRaises(QuestionNotFoundException):
            self.service.undo_answer(attempt_id=1, question_id=1, user=None, anonymous_id='anon-1')

    def test_raises_when_no_answer_exists(self):
        self.attempt_repository.get_by_id.return_value = self._attempt(anonymous_id='anon-1')
        question = MagicMock()
        self.assessment_repository.get_active_question.return_value = question
        self.attempt_repository.delete_answer.return_value = False

        with self.assertRaises(AnswerNotFoundException):
            self.service.undo_answer(attempt_id=1, question_id=1, user=None, anonymous_id='anon-1')

    def test_deletes_answer_when_valid(self):
        attempt = self._attempt(anonymous_id='anon-1')
        self.attempt_repository.get_by_id.return_value = attempt
        question = MagicMock()
        self.assessment_repository.get_active_question.return_value = question
        self.attempt_repository.delete_answer.return_value = True

        self.service.undo_answer(attempt_id=1, question_id=1, user=None, anonymous_id='anon-1')

        self.attempt_repository.delete_answer.assert_called_once_with(attempt=attempt, question=question)


class AttemptRepositoryDeleteAnswerTests(TestCase):
    def setUp(self):
        self.assessment = Assessment.objects.create(slug='test-likert-v4', title='Test', kind=Assessment.Kind.INITIAL)
        self.section = AssessmentSection.objects.create(assessment=self.assessment, order=1, title='General')
        self.question = Question.objects.create(
            section=self.section, order=1, text='Q1', question_type=Question.QuestionType.LIKERT
        )
        self.attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-1')
        self.repository = AttemptRepository()

    def test_deletes_existing_answer_and_returns_true(self):
        Answer.objects.create(attempt=self.attempt, question=self.question, value=4)

        deleted = self.repository.delete_answer(attempt=self.attempt, question=self.question)

        self.assertTrue(deleted)
        self.assertFalse(Answer.objects.filter(attempt=self.attempt, question=self.question).exists())

    def test_returns_false_when_no_answer_exists(self):
        deleted = self.repository.delete_answer(attempt=self.attempt, question=self.question)

        self.assertFalse(deleted)


class AttemptServiceCompleteAttemptTests(TestCase):
    def setUp(self):
        self.attempt_repository = MagicMock()
        self.assessment_repository = MagicMock()
        self.report_service = MagicMock()
        self.scoring_service = MagicMock()
        self.entitlement_service = MagicMock()
        self.service = AttemptService(
            attempt_repository=self.attempt_repository,
            assessment_repository=self.assessment_repository,
            report_service=self.report_service,
            scoring_service=self.scoring_service,
            entitlement_service=self.entitlement_service,
        )

    def test_raises_when_already_completed(self):
        attempt = MagicMock(user_id=None, anonymous_id='anon-1', status=Attempt.Status.COMPLETED)
        self.attempt_repository.get_by_id.return_value = attempt

        with self.assertRaises(AttemptAlreadyCompletedException):
            self.service.complete_attempt(attempt_id=1, user=None, anonymous_id='anon-1')

        self.report_service.generate_for_attempt.assert_not_called()

    def test_raises_when_incomplete(self):
        attempt = MagicMock(user_id=None, anonymous_id='anon-1', status=Attempt.Status.IN_PROGRESS)
        self.attempt_repository.get_by_id.return_value = attempt
        self.scoring_service.is_complete.return_value = False

        with self.assertRaises(AttemptIncompleteException):
            self.service.complete_attempt(attempt_id=1, user=None, anonymous_id='anon-1')

        self.scoring_service.is_complete.assert_called_once_with(attempt)
        self.attempt_repository.mark_completed.assert_not_called()
        self.report_service.generate_for_attempt.assert_not_called()

    def test_marks_attempt_completed_and_triggers_report_generation(self):
        attempt = MagicMock(user_id=None, anonymous_id='anon-1', status=Attempt.Status.IN_PROGRESS)
        completed_attempt = MagicMock(assessment=MagicMock(requires_purchase=False, report_requires_purchase=False))
        self.attempt_repository.get_by_id.return_value = attempt
        self.attempt_repository.mark_completed.return_value = completed_attempt
        self.scoring_service.is_complete.return_value = True

        result = self.service.complete_attempt(attempt_id=1, user=None, anonymous_id='anon-1')

        self.assertIs(result, completed_attempt)
        self.attempt_repository.mark_completed.assert_called_once_with(attempt)
        self.report_service.generate_for_attempt.assert_called_once_with(completed_attempt, awaiting_payment=False)

    def test_consumes_purchase_when_requires_purchase_and_authenticated(self):
        user = MagicMock(id=7)
        assessment = MagicMock(requires_purchase=True, report_requires_purchase=False)
        attempt = MagicMock(user_id=7, anonymous_id=None, status=Attempt.Status.IN_PROGRESS, assessment=assessment)
        completed_attempt = MagicMock(user_id=7, assessment=assessment)
        self.attempt_repository.get_by_id.return_value = attempt
        self.attempt_repository.mark_completed.return_value = completed_attempt
        self.scoring_service.is_complete.return_value = True

        self.service.complete_attempt(attempt_id=1, user=user, anonymous_id=None)

        self.entitlement_service.consume_for_assessment.assert_called_once_with(user=user, assessment=assessment)

    def test_does_not_consume_purchase_when_assessment_does_not_require_purchase(self):
        user = MagicMock(id=7)
        assessment = MagicMock(requires_purchase=False, report_requires_purchase=False)
        attempt = MagicMock(user_id=7, anonymous_id=None, status=Attempt.Status.IN_PROGRESS, assessment=assessment)
        completed_attempt = MagicMock(user_id=7, assessment=assessment)
        self.attempt_repository.get_by_id.return_value = attempt
        self.attempt_repository.mark_completed.return_value = completed_attempt
        self.scoring_service.is_complete.return_value = True

        self.service.complete_attempt(attempt_id=1, user=user, anonymous_id=None)

        self.entitlement_service.consume_for_assessment.assert_not_called()

    def test_does_not_consume_purchase_for_anonymous_attempt(self):
        assessment = MagicMock(requires_purchase=True, report_requires_purchase=False)
        attempt = MagicMock(user_id=None, anonymous_id='anon-1', status=Attempt.Status.IN_PROGRESS, assessment=assessment)
        completed_attempt = MagicMock(user_id=None, assessment=assessment)
        self.attempt_repository.get_by_id.return_value = attempt
        self.attempt_repository.mark_completed.return_value = completed_attempt
        self.scoring_service.is_complete.return_value = True

        self.service.complete_attempt(attempt_id=1, user=None, anonymous_id='anon-1')

        self.entitlement_service.consume_for_assessment.assert_not_called()

    def _complete_pay_after_test(self, *, has_access):
        user = MagicMock(id=7)
        assessment = MagicMock(requires_purchase=False, report_requires_purchase=True)
        attempt = MagicMock(user_id=7, anonymous_id=None, status=Attempt.Status.IN_PROGRESS, assessment=assessment)
        completed_attempt = MagicMock(user_id=7, assessment=assessment)
        self.attempt_repository.get_by_id.return_value = attempt
        self.attempt_repository.mark_completed.return_value = completed_attempt
        self.scoring_service.is_complete.return_value = True
        self.entitlement_service.has_access_to_assessment.return_value = has_access

        self.service.complete_attempt(attempt_id=1, user=user, anonymous_id=None)
        return user, assessment, completed_attempt

    def test_pay_after_test_leaves_report_awaiting_payment_without_a_purchase(self):
        _, _, completed_attempt = self._complete_pay_after_test(has_access=False)

        self.entitlement_service.consume_for_assessment.assert_not_called()
        self.report_service.generate_for_attempt.assert_called_once_with(completed_attempt, awaiting_payment=True)

    def test_pay_after_test_spends_a_legacy_purchase_and_generates_immediately(self):
        user, assessment, completed_attempt = self._complete_pay_after_test(has_access=True)

        self.entitlement_service.consume_for_assessment.assert_called_once_with(user=user, assessment=assessment)
        self.report_service.generate_for_attempt.assert_called_once_with(completed_attempt, awaiting_payment=False)


class AttemptServiceLinkAnonymousAttemptsTests(TestCase):
    def setUp(self):
        self.attempt_repository = MagicMock()
        self.assessment_repository = MagicMock()
        self.report_service = MagicMock()
        self.service = AttemptService(
            attempt_repository=self.attempt_repository,
            assessment_repository=self.assessment_repository,
            report_service=self.report_service,
        )

    def test_does_nothing_when_anonymous_id_missing(self):
        user = MagicMock()

        self.service.link_anonymous_attempts(user=user, anonymous_id=None)

        self.attempt_repository.link_to_user.assert_not_called()
        self.report_service.persist_pending_memories_for_user.assert_not_called()

    def test_links_attempts_for_anonymous_id_to_user(self):
        user = MagicMock()

        self.service.link_anonymous_attempts(user=user, anonymous_id='anon-1')

        self.attempt_repository.link_to_user.assert_called_once_with(anonymous_id='anon-1', user=user)
        self.report_service.persist_pending_memories_for_user.assert_called_once_with(user)


class AttemptRepositoryLinkToUserTests(TestCase):
    def setUp(self):
        self.assessment = Assessment.objects.create(slug='test-likert-v3', title='Test', kind=Assessment.Kind.INITIAL)
        self.repository = AttemptRepository()

    def test_links_anonymous_attempt_to_user(self):
        from apps.account.models import User

        user = User.objects.create(phone_number='09120000000')
        attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-1')

        updated = self.repository.link_to_user(anonymous_id='anon-1', user=user)

        attempt.refresh_from_db()
        self.assertEqual(updated, 1)
        self.assertEqual(attempt.user_id, user.id)

    def test_does_not_relink_attempt_already_owned_by_another_user(self):
        from apps.account.models import User

        original_owner = User.objects.create(phone_number='09120000001')
        new_user = User.objects.create(phone_number='09120000002')
        attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-1', user=original_owner)

        updated = self.repository.link_to_user(anonymous_id='anon-1', user=new_user)

        attempt.refresh_from_db()
        self.assertEqual(updated, 0)
        self.assertEqual(attempt.user_id, original_owner.id)


class AttemptSerializerIncludesAnswersTests(TestCase):
    def setUp(self):
        self.assessment = Assessment.objects.create(slug='test-likert-v2', title='Test', kind=Assessment.Kind.INITIAL)
        self.section = AssessmentSection.objects.create(assessment=self.assessment, order=1, title='General')
        self.question = Question.objects.create(
            section=self.section, order=1, text='Q1', question_type=Question.QuestionType.LIKERT
        )
        self.attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-1')
        Answer.objects.create(attempt=self.attempt, question=self.question, value=4)

    def test_serialized_attempt_includes_previously_submitted_answers(self):
        data = AttemptSerializer(instance=self.attempt).data

        self.assertEqual(len(data['answers']), 1)
        self.assertEqual(data['answers'][0]['question_id'], self.question.id)
        self.assertEqual(data['answers'][0]['value'], 4)

    def test_resumed_attempt_from_repository_includes_answers(self):
        resumed = AttemptRepository().get_in_progress(
            assessment=self.assessment, user=None, anonymous_id='anon-1'
        )

        data = AttemptSerializer(instance=resumed).data

        self.assertEqual(resumed.id, self.attempt.id)
        self.assertEqual(len(data['answers']), 1)
        self.assertEqual(data['answers'][0]['value'], 4)
