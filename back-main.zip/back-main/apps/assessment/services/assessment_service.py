from apps.assessment.models import Assessment
from apps.assessment.repositories.assessment_repository import AssessmentRepository
from apps.assessment.services.exceptions import AssessmentNotFoundException


class AssessmentService:
    def __init__(self, assessment_repository=None):
        self.assessment_repository = assessment_repository or AssessmentRepository()

    def get_assessment(self, slug: str) -> Assessment:
        assessment = self.assessment_repository.get_active_by_slug(slug)
        if assessment is None:
            raise AssessmentNotFoundException(f"No active assessment found for slug {slug}")

        return assessment
