from rest_framework import status

from faraman_back.utils.exceptions import AppException


class AssessmentNotFoundException(AppException):
    """Raised when no active assessment exists for the given slug."""
    status_code = status.HTTP_404_NOT_FOUND
    message_key = 'assessment_not_found'


class AttemptNotFoundException(AppException):
    """Raised when no attempt exists for the given id."""
    status_code = status.HTTP_404_NOT_FOUND
    message_key = 'attempt_not_found'


class AttemptAccessDeniedException(AppException):
    """Raised when the requester (user or anonymous_id) does not own the attempt."""
    status_code = status.HTTP_403_FORBIDDEN
    message_key = 'attempt_access_denied'


class AttemptAlreadyCompletedException(AppException):
    """Raised when trying to answer or complete an attempt that is no longer in progress."""
    status_code = status.HTTP_409_CONFLICT
    message_key = 'attempt_already_completed'


class QuestionNotFoundException(AppException):
    """Raised when the given question does not belong to the attempt's assessment."""
    status_code = status.HTTP_404_NOT_FOUND
    message_key = 'question_not_found'


class AttemptIncompleteException(AppException):
    """Raised when trying to complete an attempt that still has unanswered required questions."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'attempt_incomplete'


class InvalidAnswerValueException(AppException):
    """Raised when an answer value doesn't match what its question type expects."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'invalid_answer_value'


class AnswerNotFoundException(AppException):
    """Raised when trying to undo an answer that was never submitted for the attempt."""
    status_code = status.HTTP_404_NOT_FOUND
    message_key = 'answer_not_found'


class AttemptLimitExceededException(AppException):
    """Raised when the requester has started too many new attempts for this assessment within the limit window."""
    status_code = status.HTTP_429_TOO_MANY_REQUESTS
    message_key = 'attempt_limit_exceeded'


class PurchaseRequiredException(AppException):
    """Raised when trying to start a requires_purchase assessment without an owned Purchase for it."""
    status_code = status.HTTP_402_PAYMENT_REQUIRED
    message_key = 'purchase_required'


class ReportGenerationInProgressException(AppException):
    """Raised when trying to start a new attempt while this identity's previous attempt on the
    same assessment still has a report generating (deep reports run async on Celery)."""
    status_code = status.HTTP_409_CONFLICT
    message_key = 'report_generation_in_progress'
