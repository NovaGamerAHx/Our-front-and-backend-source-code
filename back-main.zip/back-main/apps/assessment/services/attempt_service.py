from apps.account.models import User
from apps.assessment.models import Answer, Attempt, Question
from apps.assessment.repositories.assessment_repository import AssessmentRepository
from apps.assessment.repositories.attempt_repository import AttemptRepository
from apps.assessment.repositories.attempt_throttle_repository import ATTEMPT_LIMIT_COUNT, AttemptThrottleRepository
from apps.assessment.services.exceptions import (
    AnswerNotFoundException,
    AssessmentNotFoundException,
    AttemptAccessDeniedException,
    AttemptAlreadyCompletedException,
    AttemptIncompleteException,
    AttemptLimitExceededException,
    AttemptNotFoundException,
    InvalidAnswerValueException,
    PurchaseRequiredException,
    QuestionNotFoundException,
    ReportGenerationInProgressException,
)
from apps.payment.services.entitlement_service import EntitlementService
from apps.report.services.report_service import ReportService
from faraman_back.observability.metrics import THROTTLE_REJECTED
from apps.report.services.scoring_router import ScoringRouter
from apps.report.services.scoring_service import ScoringService

LIKERT_MIN = 1
LIKERT_MAX = 5


class AttemptService:
    def __init__(
        self,
        attempt_repository=None,
        assessment_repository=None,
        report_service=None,
        scoring_service=None,
        attempt_throttle_repository=None,
        entitlement_service=None,
        scoring_router=None,
    ):
        self.attempt_repository = attempt_repository or AttemptRepository()
        self.assessment_repository = assessment_repository or AssessmentRepository()
        self.report_service = report_service or ReportService()
        self.scoring_service = scoring_service or ScoringService()
        # See ReportService: built from self.scoring_service so an injected one is still used.
        self.scoring_router = scoring_router or ScoringRouter(scoring_service=self.scoring_service)
        self.attempt_throttle_repository = attempt_throttle_repository or AttemptThrottleRepository()
        self.entitlement_service = entitlement_service or EntitlementService()

    @staticmethod
    def _owns_attempt(attempt: Attempt, *, user: User | None, anonymous_id: str | None) -> bool:
        if attempt.user_id is not None:
            return user is not None and attempt.user_id == user.id
        return anonymous_id is not None and attempt.anonymous_id == anonymous_id

    @staticmethod
    def _identity(*, user: User | None, anonymous_id: str | None) -> str | None:
        if user is not None:
            return f"user:{user.id}"
        if anonymous_id is not None:
            return f"anon:{anonymous_id}"
        return None

    @staticmethod
    def _validate_value(question: Question, value) -> None:
        if question.question_type == Question.QuestionType.LIKERT:
            if not isinstance(value, int) or isinstance(value, bool) or not (LIKERT_MIN <= value <= LIKERT_MAX):
                raise InvalidAnswerValueException(
                    f"Likert answer must be an integer between {LIKERT_MIN} and {LIKERT_MAX}"
                )

    def _ensure_assessment_access(self, assessment, *, user: User | None) -> None:
        """Only gates starting a *new* attempt -- once an attempt exists, its owner already
        passed this check at creation, so downstream endpoints (answer/undo/complete) trust that
        invariant instead of re-checking it. Note that Purchase rows are no longer permanent: for
        requires_purchase assessments, complete_attempt below consumes the Purchase, so a later
        start_attempt call for a *new* attempt (not resuming this one) will hit this check again
        and correctly require a fresh payment."""
        if not assessment.requires_purchase:
            return

        if not self.entitlement_service.has_access_to_assessment(user=user, assessment=assessment):
            raise PurchaseRequiredException(f"Purchase required for assessment {assessment.slug}")

    def _get_owned_attempt(self, attempt_id: int, *, user: User | None, anonymous_id: str | None) -> Attempt:
        attempt = self.attempt_repository.get_by_id(attempt_id)
        if attempt is None:
            raise AttemptNotFoundException(f"No attempt found for id {attempt_id}")

        if not self._owns_attempt(attempt, user=user, anonymous_id=anonymous_id):
            raise AttemptAccessDeniedException(f"Attempt {attempt_id} does not belong to this requester")

        return attempt

    def start_attempt(
        self, *, assessment_slug: str, user: User | None, anonymous_id: str | None, source: dict | None = None
    ) -> Attempt:
        assessment = self.assessment_repository.get_active_by_slug(assessment_slug)
        if assessment is None:
            raise AssessmentNotFoundException(f"No active assessment found for slug {assessment_slug}")

        existing = self.attempt_repository.get_in_progress(assessment=assessment, user=user, anonymous_id=anonymous_id)
        if existing is not None:
            return existing

        # A completed attempt's deep report generates async (deep_report_spec_v1_2.md §5.1, up to 8 paid
        # model calls) -- get_in_progress above can't see it since the attempt itself is already
        # COMPLETED. Block a second attempt until that generation resolves (OK or ERROR),
        # otherwise the same purchase pays for two full generations in flight at once.
        if self.report_service.has_report_generating(assessment=assessment, user=user, anonymous_id=anonymous_id):
            raise ReportGenerationInProgressException(
                f"Report still generating for {self._identity(user=user, anonymous_id=anonymous_id)} "
                f"on assessment {assessment.slug}"
            )

        # Only gates creating a *new* attempt -- an already-in-progress one (returned above) was
        # necessarily allowed to start in the first place, purchased or not at the time.
        self._ensure_assessment_access(assessment, user=user)

        identity = self._identity(user=user, anonymous_id=anonymous_id)
        if identity is not None and self.attempt_throttle_repository.hit(identity, assessment.slug):
            THROTTLE_REJECTED.labels(scope="assessment_attempt").inc()
            raise AttemptLimitExceededException(
                f"Attempt limit exceeded for {identity} on assessment {assessment.slug}"
            )

        return self.attempt_repository.create(assessment=assessment, user=user, anonymous_id=anonymous_id, source=source)

    def get_pre_start(self, *, assessment_slug: str, user: User | None, anonymous_id: str | None) -> dict:
        """Info shown before starting an assessment: the identity's latest report for it (if any,
        gated the same way as the report detail endpoint) and how many new attempts remain today."""
        assessment = self.assessment_repository.get_active_by_slug(assessment_slug)
        if assessment is None:
            raise AssessmentNotFoundException(f"No active assessment found for slug {assessment_slug}")

        latest_report = self.report_service.get_latest_for_identity(
            assessment=assessment, user=user, anonymous_id=anonymous_id
        )

        identity = self._identity(user=user, anonymous_id=anonymous_id)
        remaining_attempts = (
            self.attempt_throttle_repository.remaining(identity, assessment.slug)
            if identity is not None
            else ATTEMPT_LIMIT_COUNT
        )

        in_progress = self.attempt_repository.get_in_progress(
            assessment=assessment, user=user, anonymous_id=anonymous_id
        )

        return {
            "assessment_slug": assessment.slug,
            "has_in_progress_attempt": in_progress is not None,
            "has_previous_report": latest_report is not None,
            "latest_report": latest_report,
            "remaining_attempts_today": remaining_attempts,
            "attempt_limit": ATTEMPT_LIMIT_COUNT,
        }

    def submit_answer(
        self, *, attempt_id: int, question_id: int, value, user: User | None, anonymous_id: str | None
    ) -> Answer:
        attempt = self._get_owned_attempt(attempt_id, user=user, anonymous_id=anonymous_id)
        if attempt.status != Attempt.Status.IN_PROGRESS:
            raise AttemptAlreadyCompletedException(f"Attempt {attempt_id} is no longer in progress")

        question = self.assessment_repository.get_active_question(assessment=attempt.assessment, question_id=question_id)
        if question is None:
            raise QuestionNotFoundException(f"No active question {question_id} for attempt {attempt_id}")

        self._validate_value(question, value)

        return self.attempt_repository.upsert_answer(attempt=attempt, question=question, value=value)

    def undo_answer(
        self, *, attempt_id: int, question_id: int, user: User | None, anonymous_id: str | None
    ) -> None:
        attempt = self._get_owned_attempt(attempt_id, user=user, anonymous_id=anonymous_id)
        if attempt.status != Attempt.Status.IN_PROGRESS:
            raise AttemptAlreadyCompletedException(f"Attempt {attempt_id} is no longer in progress")

        question = self.assessment_repository.get_active_question(assessment=attempt.assessment, question_id=question_id)
        if question is None:
            raise QuestionNotFoundException(f"No active question {question_id} for attempt {attempt_id}")

        deleted = self.attempt_repository.delete_answer(attempt=attempt, question=question)
        if not deleted:
            raise AnswerNotFoundException(f"No answer to question {question_id} exists for attempt {attempt_id}")

    def complete_attempt(self, *, attempt_id: int, user: User | None, anonymous_id: str | None) -> Attempt:
        attempt = self._get_owned_attempt(attempt_id, user=user, anonymous_id=anonymous_id)
        if attempt.status != Attempt.Status.IN_PROGRESS:
            raise AttemptAlreadyCompletedException(f"Attempt {attempt_id} is no longer in progress")

        # Routed, not fixed: the deep test scores off a per-question key rather than section
        # titles, so ScoringService would call a fully answered 150-item attempt incomplete.
        if not self.scoring_router.for_attempt(attempt).is_complete(attempt):
            raise AttemptIncompleteException(f"Attempt {attempt_id} still has unanswered required questions")

        attempt = self.attempt_repository.mark_completed(attempt)

        awaiting_payment = False
        if attempt.assessment.report_requires_purchase:
            # Pay-after-test: the attempt was free, the report is what's paid for. A user who paid
            # under the old pay-before-test flow still holds an unconsumed Purchase -- spend it
            # here so that report generates immediately; everyone else's report waits for payment.
            if self.entitlement_service.has_access_to_assessment(user=user, assessment=attempt.assessment):
                self.entitlement_service.consume_for_assessment(user=user, assessment=attempt.assessment)
            else:
                awaiting_payment = True
        elif attempt.assessment.requires_purchase and attempt.user_id is not None:
            # Retaking a purchased assessment needs a fresh payment -- consume the Purchase now so
            # the next start_attempt for a *new* attempt hits _ensure_assessment_access again.
            # Anonymous attempts can't have a Purchase in the first place (a requires_purchase
            # assessment is always purchase-gated to an authenticated owner).
            self.entitlement_service.consume_for_assessment(user=user, assessment=attempt.assessment)

        self.report_service.generate_for_attempt(attempt, awaiting_payment=awaiting_payment)
        return attempt

    def link_anonymous_attempts(self, *, user: User, anonymous_id: str | None) -> None:
        """Claims any anonymous attempts (in progress or completed) for anonymous_id on behalf of
        user, e.g. after a successful login. Attempts already linked to another user are left alone.

        Also persists any memory_candidates from reports generated while those attempts were still
        anonymous, now that they have a user to be keyed on (report_spec_v1.3 §4.5)."""
        if not anonymous_id:
            return

        self.attempt_repository.link_to_user(anonymous_id=anonymous_id, user=user)
        self.report_service.persist_pending_memories_for_user(user)
