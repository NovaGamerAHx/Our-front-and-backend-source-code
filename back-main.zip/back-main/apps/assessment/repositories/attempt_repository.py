from django.utils import timezone

from apps.account.models import User
from apps.assessment.models import Answer, Assessment, Attempt, Question


class AttemptRepository:
    def get_in_progress(self, *, assessment: Assessment, user: User | None, anonymous_id: str | None) -> Attempt | None:
        queryset = Attempt.objects.filter(
            assessment=assessment, status=Attempt.Status.IN_PROGRESS, is_deleted=False
        ).prefetch_related("answers")
        if user is not None:
            return queryset.filter(user=user).first()
        return queryset.filter(user__isnull=True, anonymous_id=anonymous_id).first()

    def create(
        self, *, assessment: Assessment, user: User | None, anonymous_id: str | None, source: dict | None = None
    ) -> Attempt:
        return Attempt.objects.create(
            assessment=assessment,
            user=user,
            anonymous_id=anonymous_id,
            current_section=assessment.sections.order_by("order").first(),
            source=source or {},
        )

    def get_by_id(self, attempt_id: int) -> Attempt | None:
        return (
            Attempt.objects.select_related("assessment")
            .prefetch_related("answers")
            .filter(id=attempt_id, is_deleted=False)
            .first()
        )

    def mark_completed(self, attempt: Attempt) -> Attempt:
        attempt.status = Attempt.Status.COMPLETED
        attempt.completed_at = timezone.now()
        attempt.save(update_fields=["status", "completed_at"])
        return attempt

    def link_to_user(self, *, anonymous_id: str, user: User) -> int:
        """Attaches every not-yet-claimed attempt for anonymous_id to user. Attempts already
        linked to a (different) user are excluded by the user__isnull filter and left untouched."""
        return Attempt.objects.filter(user__isnull=True, anonymous_id=anonymous_id).update(user=user)

    def soft_delete_for_user(self, user: User) -> int:
        return Attempt.objects.filter(user=user, is_deleted=False).update(is_deleted=True, deleted_at=timezone.now())

    def upsert_answer(self, *, attempt: Attempt, question: Question, value) -> Answer:
        answer, _ = Answer.objects.update_or_create(
            attempt=attempt, question=question, defaults={"value": value}
        )
        if attempt.current_section_id != question.section_id:
            attempt.current_section_id = question.section_id
            attempt.save(update_fields=["current_section"])
        return answer

    def delete_answer(self, *, attempt: Attempt, question: Question) -> bool:
        deleted_count, _ = Answer.objects.filter(attempt=attempt, question=question).delete()
        return deleted_count > 0
