import logging

import redis
from django.conf import settings

logger = logging.getLogger(__name__)

ATTEMPT_LIMIT_COUNT = 2
ATTEMPT_LIMIT_WINDOW_SECONDS = 60 * 60 * 24  # 24h


class AttemptThrottleRepository:
    """Fixed-window counter limiting how many new attempts an identity can start for a given
    assessment. Fails open on Redis errors so an outage doesn't block test-taking."""

    def __init__(self):
        self._client = None

    @property
    def client(self):
        if self._client is None:
            self._client = redis.StrictRedis(
                host=getattr(settings, 'REDIS_HOST', 'localhost'),
                port=getattr(settings, 'REDIS_PORT', 6379),
                db=getattr(settings, 'REDIS_DB', 0),
                password=getattr(settings, 'REDIS_PASSWORD', ''),
                decode_responses=True,
            )
        return self._client

    @staticmethod
    def _key(identity: str, assessment_slug: str) -> str:
        return f"attempt_limit:{identity}:{assessment_slug}"

    def hit(self, identity: str, assessment_slug: str) -> bool:
        """Increments the counter for identity/assessment_slug and returns whether it is now
        over ATTEMPT_LIMIT_COUNT within the current window."""
        try:
            key = self._key(identity, assessment_slug)
            count = self.client.incr(key)
            if count == 1:
                self.client.expire(key, ATTEMPT_LIMIT_WINDOW_SECONDS)
            return count > ATTEMPT_LIMIT_COUNT
        except Exception:
            logger.exception(f"Failed to check attempt limit for {identity}/{assessment_slug}")
            return False

    def remaining(self, identity: str, assessment_slug: str) -> int:
        """Reads (without incrementing) how many new attempts identity has left for assessment_slug
        in the current window. Fails open, returning the full quota, on Redis errors."""
        try:
            key = self._key(identity, assessment_slug)
            raw = self.client.get(key)
            count = int(raw) if raw is not None else 0
            return max(ATTEMPT_LIMIT_COUNT - count, 0)
        except Exception:
            logger.exception(f"Failed to read attempt count for {identity}/{assessment_slug}")
            return ATTEMPT_LIMIT_COUNT
