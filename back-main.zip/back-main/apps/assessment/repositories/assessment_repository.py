from apps.assessment.models import Assessment, Question


class AssessmentRepository:
    def get_active_by_slug(self, slug: str) -> Assessment | None:
        assessment = Assessment.objects.filter(slug=slug, is_active=True).first()
        if assessment is None:
            return None

        assessment.questions = list(
            Question.objects.filter(section__assessment=assessment, is_active=True)
            .select_related("section")
            .order_by("section__order", "order")
        )
        return assessment

    def get_active_question(self, *, assessment: Assessment, question_id: int) -> Question | None:
        return Question.objects.filter(section__assessment=assessment, id=question_id, is_active=True).first()

    def get_active_question_ids(self, assessment: Assessment) -> set[int]:
        """All active question ids for the assessment, regardless of section."""
        return set(
            Question.objects.filter(section__assessment=assessment, is_active=True).values_list("id", flat=True)
        )

    def get_active_question_ids_for_sections(self, assessment: Assessment, section_titles: list[str]) -> set[int]:
        """Active question ids restricted to sections whose title is in section_titles."""
        return set(
            Question.objects.filter(
                section__assessment=assessment, is_active=True, section__title__in=section_titles,
            ).values_list("id", flat=True)
        )
