import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('assessment', '0004_backfill_assessment_sections'),
    ]

    operations = [
        migrations.RemoveConstraint(
            model_name='question',
            name='unique_question_order_per_assessment',
        ),
        migrations.AlterField(
            model_name='question',
            name='section',
            field=models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='questions', to='assessment.assessmentsection'),
        ),
        migrations.RemoveField(
            model_name='question',
            name='assessment',
        ),
        migrations.AddConstraint(
            model_name='question',
            constraint=models.UniqueConstraint(fields=('section', 'order'), name='unique_question_order_per_section'),
        ),
    ]
