import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('assessment', '0002_add_attempt_and_answer'),
    ]

    operations = [
        migrations.CreateModel(
            name='AssessmentSection',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('title', models.CharField(max_length=200)),
                ('order', models.PositiveSmallIntegerField()),
                ('interstitial_message', models.TextField(blank=True)),
                ('assessment', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='sections', to='assessment.assessment')),
            ],
            options={
                'db_table': 'assessment_sections',
                'ordering': ['order'],
            },
        ),
        migrations.AddConstraint(
            model_name='assessmentsection',
            constraint=models.UniqueConstraint(fields=('assessment', 'order'), name='unique_section_order_per_assessment'),
        ),
        migrations.AddField(
            model_name='question',
            name='section',
            field=models.ForeignKey(null=True, on_delete=django.db.models.deletion.CASCADE, related_name='questions', to='assessment.assessmentsection'),
        ),
        migrations.AddField(
            model_name='attempt',
            name='current_section',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='+', to='assessment.assessmentsection'),
        ),
    ]
