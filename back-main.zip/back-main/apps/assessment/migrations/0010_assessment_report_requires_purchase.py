from django.db import migrations, models

DEEP_ASSESSMENT_SLUG = "deep-150-v1"


def move_deep_paywall_after_test(apps, schema_editor):
    """The deep test is now free to take and pays at the report (pay-after-test). Users who already
    paid under the old flow keep their unconsumed Purchase: complete_attempt honours it by
    unlocking that attempt's report directly (AttemptService.complete_attempt)."""
    Assessment = apps.get_model("assessment", "Assessment")
    Assessment.objects.filter(slug=DEEP_ASSESSMENT_SLUG).update(
        requires_purchase=False, report_requires_purchase=True
    )


def move_deep_paywall_before_test(apps, schema_editor):
    Assessment = apps.get_model("assessment", "Assessment")
    Assessment.objects.filter(slug=DEEP_ASSESSMENT_SLUG).update(
        requires_purchase=True, report_requires_purchase=False
    )


class Migration(migrations.Migration):

    dependencies = [
        ('assessment', '0009_assessment_scoring_profile'),
    ]

    operations = [
        migrations.AddField(
            model_name='assessment',
            name='report_requires_purchase',
            field=models.BooleanField(default=False),
        ),
        migrations.RunPython(move_deep_paywall_after_test, move_deep_paywall_before_test),
    ]
