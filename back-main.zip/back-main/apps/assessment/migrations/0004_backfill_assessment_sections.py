from django.db import migrations


def backfill_sections(apps, schema_editor):
    Assessment = apps.get_model('assessment', 'Assessment')
    AssessmentSection = apps.get_model('assessment', 'AssessmentSection')
    Question = apps.get_model('assessment', 'Question')

    for assessment in Assessment.objects.all():
        questions = Question.objects.filter(assessment=assessment)
        if not questions.exists():
            continue

        section = AssessmentSection.objects.create(
            assessment=assessment,
            order=1,
            title='General',
        )
        questions.update(section=section)


def noop_reverse(apps, schema_editor):
    # Sections/section assignments created here are dropped along with the
    # AssessmentSection table itself when 0003 is unapplied; nothing to undo here.
    pass


class Migration(migrations.Migration):

    dependencies = [
        ('assessment', '0003_add_assessment_section'),
    ]

    operations = [
        migrations.RunPython(backfill_sections, noop_reverse),
    ]
