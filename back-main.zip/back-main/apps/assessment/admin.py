from django.contrib import admin

from apps.assessment.models import Answer, Assessment, AssessmentSection, Attempt, Question


class SectionInline(admin.TabularInline):
    model = AssessmentSection
    extra = 1
    ordering = ("order",)
    fields = ("order", "title", "interstitial_message")
    show_change_link = True


@admin.register(Assessment)
class AssessmentAdmin(admin.ModelAdmin):
    list_display = (
        "id", "slug", "title", "kind", "scoring_profile", "version", "is_active", "requires_purchase", "report_requires_purchase", "created_at",
    )
    list_filter = ("kind", "scoring_profile", "is_active", "requires_purchase")
    search_fields = ("slug", "title")
    inlines = [SectionInline]


class QuestionInline(admin.TabularInline):
    model = Question
    extra = 1
    ordering = ("order",)
    fields = ("order", "text", "question_type", "options", "reverse_scored", "scoring", "is_active")


@admin.register(AssessmentSection)
class AssessmentSectionAdmin(admin.ModelAdmin):
    list_display = ("id", "assessment", "order", "title")
    list_filter = ("assessment",)
    search_fields = ("title", "assessment__slug", "assessment__title")
    inlines = [QuestionInline]


class AnswerInline(admin.TabularInline):
    model = Answer
    extra = 0
    fields = ("question", "value", "answered_at")
    readonly_fields = ("answered_at",)


@admin.register(Attempt)
class AttemptAdmin(admin.ModelAdmin):
    list_display = (
        "id", "assessment", "user", "anonymous_id", "status", "current_section", "started_at", "completed_at",
    )
    list_filter = ("status", "assessment")
    search_fields = ("anonymous_id", "user__phone_number")
    inlines = [AnswerInline]
