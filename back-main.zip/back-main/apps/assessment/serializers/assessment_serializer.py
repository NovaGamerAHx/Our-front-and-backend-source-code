from rest_framework import serializers

from apps.assessment.models import Question


class QuestionSerializer(serializers.ModelSerializer):
    options = serializers.SerializerMethodField()

    class Meta:
        model = Question
        fields = ["id", "order", "text", "question_type", "options"]

    def get_options(self, obj):
        # Never leak scoring/weight metadata to the client, only what's needed to render the question.
        return [{"value": option.get("value"), "label": option.get("label")} for option in obj.options]


class AssessmentSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    slug = serializers.SlugField()
    title = serializers.CharField()
    kind = serializers.CharField()
    version = serializers.IntegerField()
    requires_purchase = serializers.BooleanField()
    report_requires_purchase = serializers.BooleanField()
    questions = QuestionSerializer(many=True)
