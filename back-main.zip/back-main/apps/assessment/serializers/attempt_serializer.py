from rest_framework import serializers

from apps.assessment.models import Answer, Attempt


class StartAttemptSerializer(serializers.Serializer):
    assessment_slug = serializers.SlugField()
    source = serializers.JSONField(required=False, default=dict)


class SubmitAnswerSerializer(serializers.Serializer):
    question_id = serializers.IntegerField()
    value = serializers.JSONField()


class AnswerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Answer
        fields = ["id", "question_id", "value", "answered_at"]


class AttemptSerializer(serializers.ModelSerializer):
    assessment_slug = serializers.SlugField(source="assessment.slug", read_only=True)
    answers = AnswerSerializer(many=True, read_only=True)

    class Meta:
        model = Attempt
        fields = ["id", "assessment_slug", "status", "current_section_id", "started_at", "completed_at", "answers"]
