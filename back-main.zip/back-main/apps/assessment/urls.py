from django.urls import path

from apps.assessment.views.assessment_view import AssessmentDetailAPIView
from apps.assessment.views.attempt_view import (
    CompleteAttemptAPIView,
    PreStartAttemptAPIView,
    StartAttemptAPIView,
    SubmitAnswerAPIView,
    UndoAnswerAPIView,
)

app_name = "assessment"

urlpatterns = [
    path("attempts/", StartAttemptAPIView.as_view(), name="attempt_start"),
    path("attempts/<int:attempt_id>/answers/", SubmitAnswerAPIView.as_view(), name="attempt_submit_answer"),
    path(
        "attempts/<int:attempt_id>/answers/<int:question_id>/",
        UndoAnswerAPIView.as_view(),
        name="attempt_undo_answer",
    ),
    path("attempts/<int:attempt_id>/complete/", CompleteAttemptAPIView.as_view(), name="attempt_complete"),
    path("<slug:slug>/pre-start/", PreStartAttemptAPIView.as_view(), name="attempt_pre_start"),
    path("<slug:slug>/", AssessmentDetailAPIView.as_view(), name="assessment_detail"),
]
