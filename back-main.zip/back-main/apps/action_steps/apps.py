from django.apps import AppConfig


class ActionStepsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.action_steps"
