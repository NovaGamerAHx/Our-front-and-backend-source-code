from rest_framework import serializers

from apps.action_steps.models import ActionStep, ActionStepResponse


class ActionStepEditSerializer(serializers.Serializer):
    step_text = serializers.CharField(required=False)
    deadline_type = serializers.ChoiceField(choices=ActionStep.DeadlineType.choices, required=False)

    def validate(self, attrs):
        if not attrs:
            raise serializers.ValidationError("At least one of step_text or deadline_type is required.")
        return attrs


class ActionStepLatestResponseSerializer(serializers.Serializer):
    result = serializers.CharField()
    obstacle = serializers.CharField()
    channel = serializers.CharField()


class ActionStepSerializer(serializers.ModelSerializer):
    # Step History (action_steps_spec_v2_2.md §6.2): a not_done/partial row that's already been
    # answered (notif tap or dashboard "بگو چرا انجام نشد") shows that answer instead of the
    # reactivate/answer buttons; a done row shows the completion reflection, if any.
    latest_response = serializers.SerializerMethodField()
    reflection_text = serializers.SerializerMethodField()

    class Meta:
        model = ActionStep
        fields = [
            "id",
            "source",
            "step_text",
            "substeps",
            "deadline_type",
            "deadline_at",
            "remind_at",
            "followup_at",
            "status",
            "obstacle",
            "answered_at",
            "edit_count",
            "edited_at",
            "completed_at",
            "created_at",
            "latest_response",
            "reflection_text",
        ]

    def get_latest_response(self, obj: ActionStep) -> dict | None:
        response = obj.responses.order_by("-created_at").first()
        if response is None:
            return None
        return ActionStepLatestResponseSerializer(response).data

    def get_reflection_text(self, obj: ActionStep) -> str | None:
        # action_steps_spec_v2_2.md §8.1: the "چطور بود؟" answer lives on the step row now, not in memory.
        if obj.status != ActionStep.Status.DONE:
            return None
        return obj.reflection or None


class ActionStepCompleteSerializer(serializers.Serializer):
    """POST /api/action-steps/:id/complete/ -- the self-serve checkbox tick. `reflection_text`
    is the optional "چطور بود؟" answer (action_steps_spec_v2 §8.1); omitted/blank means the user
    tapped the explicit skip."""
    reflection_text = serializers.CharField(required=False, allow_blank=True, default="")


class ActionStepReflectionSerializer(serializers.Serializer):
    """POST /api/action-steps/:id/reflection/ -- the "چطور بود؟" answer for an already-done step
    (action_steps_spec_v2 §8.1). Unlike complete's reflection_text this is required: the skip
    path never calls this endpoint."""
    reflection_text = serializers.CharField()


class ActionStepFollowupSerializer(serializers.Serializer):
    """POST /api/action-steps/:id/followup/ -- shared by notif taps and the dashboard history's
    "بگو چرا انجام نشد" (channel differentiates)."""
    result = serializers.ChoiceField(choices=ActionStepResponse.Result.choices)
    obstacle = serializers.ChoiceField(
        choices=ActionStepResponse.Obstacle.choices, required=False, allow_null=True, default=None,
    )
    channel = serializers.ChoiceField(choices=ActionStepResponse.Channel.choices)


class ActionStepReactivateSerializer(serializers.Serializer):
    deadline_type = serializers.ChoiceField(choices=ActionStep.DeadlineType.choices)
