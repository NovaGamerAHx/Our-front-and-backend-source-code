# Generated manually 2026-08-30

from django.db import migrations, models


def backfill_from_memory_and_responses(apps, schema_editor):
    """action_step.md v2.2 §8.0: the step row is now the single source of a step's whole
    story. Two answers that used to live elsewhere move onto the row:

    - `reflection` + `answered_at` from the `action_outcome` Memory rows written by the old
      `ActionStepService._record_action_outcome` (source=`action_step:<id>`). These rows are
      soft-deleted right after, by `report/0010_retire_action_outcome_memory` -- read them
      here first.
    - `obstacle` + `answered_at` from each step's latest ActionStepResponse that carries a
      non-blank obstacle. The ActionStepResponse rows stay (they also hold `channel`).
    """
    ActionStep = apps.get_model("action_steps", "ActionStep")
    ActionStepResponse = apps.get_model("action_steps", "ActionStepResponse")
    Memory = apps.get_model("report", "Memory")

    for step in ActionStep.objects.all():
        memory = (
            Memory.objects.filter(
                user_id=step.user_id, memory_type="action_outcome",
                source=f"action_step:{step.id}", is_deleted=False,
            )
            .order_by("-created_at")
            .first()
        )
        if memory is not None:
            step.reflection = memory.text_memory
            step.answered_at = memory.created_at

        response = (
            ActionStepResponse.objects.filter(action_step_id=step.id)
            .exclude(obstacle="")
            .order_by("-created_at")
            .first()
        )
        if response is not None:
            step.obstacle = response.obstacle
            if step.answered_at is None:
                step.answered_at = response.created_at

        if memory is not None or response is not None:
            step.save(update_fields=["reflection", "obstacle", "answered_at"])


class Migration(migrations.Migration):

    dependencies = [
        ("action_steps", "0003_rename_action_step_user_id_a5f9c1_idx_action_step_user_id_20db9c_idx_and_more"),
        ("report", "0008_retire_committed_action_memory"),
    ]

    operations = [
        migrations.AddField(
            model_name="actionstep",
            name="reflection",
            field=models.TextField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="actionstep",
            name="obstacle",
            field=models.CharField(
                blank=True, max_length=30,
                choices=[
                    ("no_time", "No time"),
                    ("didnt_know_where_to_start", "Didn't know where to start"),
                    ("wanted_to_think_more", "Wanted to think more"),
                    ("lost_importance", "Lost importance"),
                    ("other", "Other"),
                ],
            ),
        ),
        migrations.AddField(
            model_name="actionstep",
            name="answered_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.RunPython(backfill_from_memory_and_responses, migrations.RunPython.noop),
    ]
