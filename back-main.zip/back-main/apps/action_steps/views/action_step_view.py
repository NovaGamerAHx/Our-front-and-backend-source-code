from drf_spectacular.utils import extend_schema
from rest_framework.views import APIView

from apps.action_steps.serializers.action_step_serializer import (
    ActionStepCompleteSerializer,
    ActionStepEditSerializer,
    ActionStepFollowupSerializer,
    ActionStepReactivateSerializer,
    ActionStepReflectionSerializer,
    ActionStepSerializer,
)
from apps.action_steps.services.action_step_service import ActionStepService
from apps.action_steps.services.exceptions import (
    ActionStepAccessDeniedException,
    ActionStepNotDoneException,
    ActionStepNotFoundException,
    ActionStepNotPendingException,
    ActionStepObstacleRequiredException,
    ActionStepReactivateRequiresNotDoneException,
)
from faraman_back.lang.utils import get_message
from faraman_back.utils.responses import ApiResponse
from faraman_back.utils.schema import error_responses


class ActionStepListAPIView(APIView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.action_step_service = ActionStepService()

    @extend_schema(
        description="Lists the authenticated user's pending action steps (action_steps_spec_v2 "
                    "§6.1), ordered by deadline_at. Optionally filtered to one `source`.",
        tags=["Action Steps"],
        responses={200: ActionStepSerializer(many=True)},
    )
    def get(self, request):
        source = request.query_params.get("source") or None
        steps = self.action_step_service.list_pending(user=request.user, source=source)

        return ApiResponse.success(data=ActionStepSerializer(steps, many=True).data)


class ActionStepHistoryAPIView(APIView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.action_step_service = ActionStepService()

    @extend_schema(
        description="Lists the authenticated user's action-step history (done/partial/not_done, "
                    "action_steps_spec_v2 §6.2), newest first.",
        tags=["Action Steps"],
        responses={200: ActionStepSerializer(many=True)},
    )
    def get(self, request):
        steps = self.action_step_service.list_history(user=request.user)

        return ApiResponse.success(data=ActionStepSerializer(steps, many=True).data)


class ActionStepDetailAPIView(APIView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.action_step_service = ActionStepService()

    @extend_schema(
        description="A single action step -- backs the Step Detail sheet and the checkin "
                    "notification deep-link.",
        tags=["Action Steps"],
        responses={
            200: ActionStepSerializer,
            **error_responses(ActionStepNotFoundException, ActionStepAccessDeniedException),
        },
    )
    def get(self, request, action_step_id):
        action_step = self.action_step_service.get_step(action_step_id, user=request.user)

        return ApiResponse.success(data=ActionStepSerializer(action_step).data)

    @extend_schema(
        description="Edits an action step's text and/or deadline. Overwrites step_text in "
                    "place (no versioning) and bumps edit_count. Editing text alone never "
                    "changes the deadline; only sending a new deadline_type recomputes "
                    "deadline_at, remind_at and followup_at.",
        tags=["Action Steps"],
        request=ActionStepEditSerializer,
        responses={
            200: ActionStepSerializer,
            **error_responses(ActionStepNotFoundException, ActionStepAccessDeniedException),
        },
    )
    def patch(self, request, action_step_id):
        ser = ActionStepEditSerializer(data=request.data, partial=True)
        if not ser.is_valid():
            return ApiResponse.validation_error(data=ser.errors)

        action_step = self.action_step_service.edit_step(
            action_step_id=action_step_id,
            user=request.user,
            **ser.validated_data,
        )

        return ApiResponse.success(
            message=get_message("updated_successfully"),
            data=ActionStepSerializer(action_step).data,
        )


class ActionStepCompleteAPIView(APIView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.action_step_service = ActionStepService()

    @extend_schema(
        description="Self-serve completion (action_steps_spec_v2_2.md §8): marks the step done, "
                    "cancels its remaining notifications, and -- if `reflection_text` is given "
                    "-- stores it on the step row (`reflection`, `answered_at`).",
        tags=["Action Steps"],
        request=ActionStepCompleteSerializer,
        responses={
            200: ActionStepSerializer,
            **error_responses(ActionStepNotFoundException, ActionStepAccessDeniedException, ActionStepNotPendingException),
        },
    )
    def post(self, request, action_step_id):
        ser = ActionStepCompleteSerializer(data=request.data)
        if not ser.is_valid():
            return ApiResponse.validation_error(data=ser.errors)

        action_step = self.action_step_service.complete_step(
            action_step_id=action_step_id,
            user=request.user,
            reflection_text=ser.validated_data["reflection_text"] or None,
        )

        return ApiResponse.success(data=ActionStepSerializer(action_step).data)


class ActionStepReflectionAPIView(APIView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.action_step_service = ActionStepService()

    @extend_schema(
        description="Records (or edits) the optional \"چطور بود؟\" reflection for an already-done "
                    "step (action_steps_spec_v2_2.md §8.1) -- stores it on the step row (`reflection`, "
                    "`answered_at`). The dashboard completes the step first, then calls this; "
                    "the skip path never does.",
        tags=["Action Steps"],
        request=ActionStepReflectionSerializer,
        responses={
            200: ActionStepSerializer,
            **error_responses(
                ActionStepNotFoundException, ActionStepAccessDeniedException, ActionStepNotDoneException,
            ),
        },
    )
    def post(self, request, action_step_id):
        ser = ActionStepReflectionSerializer(data=request.data)
        if not ser.is_valid():
            return ApiResponse.validation_error(data=ser.errors)

        action_step = self.action_step_service.record_reflection(
            action_step_id=action_step_id,
            user=request.user,
            reflection_text=ser.validated_data["reflection_text"],
        )

        return ApiResponse.success(data=ActionStepSerializer(action_step).data)


class ActionStepFollowupAPIView(APIView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.action_step_service = ActionStepService()

    @extend_schema(
        description="Records a notif-tap or dashboard-history followup response for a pending "
                    "action step (action_steps_spec_v2 §6.2/§7) -- result done/partial/not_done, "
                    "obstacle required iff not done, channel is notif/login/dashboard.",
        tags=["Action Steps"],
        request=ActionStepFollowupSerializer,
        responses={
            200: ActionStepSerializer,
            **error_responses(
                ActionStepNotFoundException, ActionStepAccessDeniedException,
                ActionStepNotPendingException, ActionStepObstacleRequiredException,
            ),
        },
    )
    def post(self, request, action_step_id):
        ser = ActionStepFollowupSerializer(data=request.data)
        if not ser.is_valid():
            return ApiResponse.validation_error(data=ser.errors)

        action_step = self.action_step_service.record_response(
            action_step_id=action_step_id, user=request.user, **ser.validated_data,
        )

        return ApiResponse.success(data=ActionStepSerializer(action_step).data)


class ActionStepReactivateAPIView(APIView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.action_step_service = ActionStepService()

    @extend_schema(
        description="Reactivates a not_done step (action_steps_spec_v2 §6.2): creates a new "
                    "action step with the same text/source and a fresh deadline; the original "
                    "row is left untouched so retry history is preserved.",
        tags=["Action Steps"],
        request=ActionStepReactivateSerializer,
        responses={
            200: ActionStepSerializer,
            **error_responses(
                ActionStepNotFoundException, ActionStepAccessDeniedException,
                ActionStepReactivateRequiresNotDoneException,
            ),
        },
    )
    def post(self, request, action_step_id):
        ser = ActionStepReactivateSerializer(data=request.data)
        if not ser.is_valid():
            return ApiResponse.validation_error(data=ser.errors)

        new_step = self.action_step_service.reactivate_step(
            action_step_id=action_step_id, user=request.user, **ser.validated_data,
        )

        return ApiResponse.success(
            message=get_message("created_successfully"),
            data=ActionStepSerializer(new_step).data,
        )
