from django.urls import path

from apps.action_steps.views.action_step_view import (
    ActionStepCompleteAPIView,
    ActionStepDetailAPIView,
    ActionStepFollowupAPIView,
    ActionStepHistoryAPIView,
    ActionStepListAPIView,
    ActionStepReactivateAPIView,
    ActionStepReflectionAPIView,
)

app_name = "action_steps"

urlpatterns = [
    path("", ActionStepListAPIView.as_view(), name="action_step_list"),
    path("history/", ActionStepHistoryAPIView.as_view(), name="action_step_history"),
    path("<uuid:action_step_id>/", ActionStepDetailAPIView.as_view(), name="action_step_detail"),
    path("<uuid:action_step_id>/complete/", ActionStepCompleteAPIView.as_view(), name="action_step_complete"),
    path("<uuid:action_step_id>/reflection/", ActionStepReflectionAPIView.as_view(), name="action_step_reflection"),
    path("<uuid:action_step_id>/followup/", ActionStepFollowupAPIView.as_view(), name="action_step_followup"),
    path(
        "<uuid:action_step_id>/reactivate/", ActionStepReactivateAPIView.as_view(), name="action_step_reactivate",
    ),
]
