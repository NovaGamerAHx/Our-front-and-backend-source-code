import uuid

from django.conf import settings
from django.db import models


class ActionStep(models.Model):
    """A single actionable step surfaced to the user (from a report recommendation or from
    chat) carrying a self-imposed deadline. `source` is a plain CharField rather than
    TextChoices, since `initial_report:rec_<id>` / `deep_report:action_<id>` are templated
    values, not fixed enum members -- validity is checked in ActionStepService (same convention
    as ChatSession.entry_source)."""

    class DeadlineType(models.TextChoices):
        TONIGHT = "tonight", "Tonight"
        TOMORROW_MORNING = "tomorrow_morning", "Tomorrow morning"
        TOMORROW_EVENING = "tomorrow_evening", "Tomorrow evening"
        WITHIN_24H = "within_24h", "Within 24h"

    class Status(models.TextChoices):
        PENDING = "pending", "Pending"
        DONE = "done", "Done"
        PARTIAL = "partial", "Partial"
        NOT_DONE = "not_done", "Not done"

    class Obstacle(models.TextChoices):
        """The "چه چیزی جلویش را گرفت؟" answer (action_steps_spec_v2_2.md §7). Same members as
        `ActionStepResponse.Obstacle` -- kept as a column on the step row too, since v2.2 makes
        the step row the single source of a step's whole story (§8.0)."""
        NO_TIME = "no_time", "No time"
        DIDNT_KNOW_WHERE_TO_START = "didnt_know_where_to_start", "Didn't know where to start"
        WANTED_TO_THINK_MORE = "wanted_to_think_more", "Wanted to think more"
        LOST_IMPORTANCE = "lost_importance", "Lost importance"
        OTHER = "other", "Other"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="action_steps")
    source = models.CharField(max_length=50)
    step_text = models.TextField()
    substeps = models.JSONField(null=True, blank=True)
    deadline_type = models.CharField(max_length=20, choices=DeadlineType.choices)
    deadline_at = models.DateTimeField()
    remind_at = models.DateTimeField()
    followup_at = models.DateTimeField()
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING)
    # The step row is the single source of a step's whole story (action_steps_spec_v2_2.md §8.0). Both of
    # these are the user's own account of how the step went -- one free text, one an enum --
    # and both are read straight off the row into chat's `action_context.recent` (chat_spec §1.4).
    reflection = models.TextField(null=True, blank=True)  # the optional "چطور بود؟" answer (§8.1)
    obstacle = models.CharField(max_length=30, choices=Obstacle.choices, blank=True)  # "چه چیزی جلویش را گرفت؟" (§7)
    # Set whenever a reflection or an obstacle answer is recorded -- distinct from
    # completed_at, which is only "when the step was marked done".
    answered_at = models.DateTimeField(null=True, blank=True)
    # overwrite, not versioning -- edit_step() replaces step_text in place; only the count and
    # timestamp of the last edit are kept, never prior text (see ActionStepService.edit_step).
    edit_count = models.PositiveIntegerField(default=0)
    edited_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "action_steps"
        indexes = [
            models.Index(fields=["user", "status"]),
            models.Index(fields=["deadline_at"]),
        ]

    def __str__(self):
        return f"ActionStep {self.id} for user #{self.user_id}"


class ActionStepResponse(models.Model):
    """A followup/checkin result for an ActionStep -- action_steps_spec_v2 §6.2/§7 (the
    dashboard's "why didn't you do it" flow, plus the notif-triggered reminder/followup taps).
    Mirrors `apps.chat.models.FollowupResponse` (same Result/Obstacle values, one extra Channel
    member) but targets `ActionStep` -- the self-serve "I did it" checkbox tick goes through
    ActionStepService.complete_step() instead and never creates a row here."""

    class Result(models.TextChoices):
        DONE = "done", "Done"
        PARTIAL = "partial", "Partial"
        NOT_DONE = "not_done", "Not done"

    class Obstacle(models.TextChoices):
        NO_TIME = "no_time", "No time"
        DIDNT_KNOW_WHERE_TO_START = "didnt_know_where_to_start", "Didn't know where to start"
        WANTED_TO_THINK_MORE = "wanted_to_think_more", "Wanted to think more"
        LOST_IMPORTANCE = "lost_importance", "Lost importance"
        OTHER = "other", "Other"

    class Channel(models.TextChoices):
        NOTIF = "notif", "Notification"
        LOGIN = "login", "Login"
        DASHBOARD = "dashboard", "Dashboard"

    action_step = models.ForeignKey(ActionStep, on_delete=models.CASCADE, related_name="responses")
    result = models.CharField(max_length=10, choices=Result.choices)
    obstacle = models.CharField(max_length=30, choices=Obstacle.choices, blank=True)
    channel = models.CharField(max_length=10, choices=Channel.choices)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "action_step_responses"

    def __str__(self):
        return f"ActionStepResponse #{self.id} for step #{self.action_step_id} ({self.result})"
