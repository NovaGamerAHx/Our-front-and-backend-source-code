from django.contrib import admin

from apps.action_steps.models import ActionStep, ActionStepResponse


@admin.register(ActionStep)
class ActionStepAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "source", "status", "deadline_type", "deadline_at", "created_at")
    list_filter = ("status", "deadline_type", "source")
    search_fields = ("user__phone_number", "step_text")
    readonly_fields = ("id", "created_at")


@admin.register(ActionStepResponse)
class ActionStepResponseAdmin(admin.ModelAdmin):
    list_display = ("id", "action_step", "result", "obstacle", "channel", "created_at")
    list_filter = ("result", "obstacle", "channel")
    readonly_fields = ("created_at",)
