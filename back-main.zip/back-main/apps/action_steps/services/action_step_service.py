import logging
import re
import uuid

from django.conf import settings
from django.utils import timezone

from apps.account.models import User
from apps.action_steps.models import ActionStep, ActionStepResponse
from apps.action_steps.repositories.action_step_repository import ActionStepRepository
from apps.action_steps.services import deadline_calculator
from apps.action_steps.services.exceptions import (
    ActionStepAccessDeniedException,
    ActionStepInvalidSourceException,
    ActionStepNotDoneException,
    ActionStepNotFoundException,
    ActionStepNotPendingException,
    ActionStepObstacleRequiredException,
    ActionStepReactivateRequiresNotDoneException,
)
from apps.notifications.services.notification_service import NotificationService

logger = logging.getLogger(__name__)

SOURCE_CHAT = "chat"
_INITIAL_REPORT_SOURCE_RE = re.compile(r"^initial_report:rec_\d+$")
_DEEP_REPORT_SOURCE_RE = re.compile(r"^deep_report:action_\d+$")


class ActionStepService:
    def __init__(self, action_step_repository=None, notification_service=None):
        self.action_step_repository = action_step_repository or ActionStepRepository()
        self.notification_service = notification_service or NotificationService()

    @staticmethod
    def is_valid_source(source: str) -> bool:
        return (
            source == SOURCE_CHAT
            or bool(_INITIAL_REPORT_SOURCE_RE.match(source))
            or bool(_DEEP_REPORT_SOURCE_RE.match(source))
        )

    @staticmethod
    def _normalize_deadline_type(deadline_type: str) -> str:
        if deadline_type not in ActionStep.DeadlineType.values:
            logger.warning("Invalid deadline_type %r, mapping to within_24h", deadline_type)
            return ActionStep.DeadlineType.WITHIN_24H
        return deadline_type

    def create_step(
        self,
        *,
        user: User,
        source: str,
        step_text: str,
        deadline_type: str,
        substeps: list | None = None,
    ) -> ActionStep:
        if not self.is_valid_source(source):
            raise ActionStepInvalidSourceException()

        deadline_type = self._normalize_deadline_type(deadline_type)
        deadline_type, deadline_at = deadline_calculator.compute_deadline_type_and_at(deadline_type)
        remind_at = deadline_calculator.compute_remind_at(deadline_at, remind_hour=settings.ACTION_STEP_REMIND_HOUR)
        followup_at = deadline_at

        action_step = self.action_step_repository.create(
            user=user,
            source=source,
            step_text=step_text,
            substeps=substeps,
            deadline_type=deadline_type,
            deadline_at=deadline_at,
            remind_at=remind_at,
            followup_at=followup_at,
        )
        # Every committed step gets its (up to) two notifications scheduled right here, so no
        # caller (report accept, chat accept-action, reactivate) can forget to (action_steps_spec_v2 §7).
        self.notification_service.schedule_for_step(action_step)
        return action_step

    def _get_owned(self, action_step_id: uuid.UUID, *, user: User) -> ActionStep:
        action_step = self.action_step_repository.get_by_id(action_step_id)
        if action_step is None:
            raise ActionStepNotFoundException()
        if action_step.user_id != user.id:
            raise ActionStepAccessDeniedException()
        return action_step

    def edit_step(
        self,
        *,
        action_step_id: uuid.UUID,
        user: User,
        step_text: str | None = None,
        deadline_type: str | None = None,
    ) -> ActionStep:
        """PATCH /api/action-steps/:id. Overwrites step_text in place (no versioning) and only
        recomputes deadline_at/remind_at/followup_at when the caller explicitly changes
        deadline_type -- otherwise editing text alone would silently push the deadline forward
        on every save, making the commitment meaningless. When the deadline does change, the
        step's still-scheduled reminder/followup notifications are cancelled and rescheduled
        against the new times too -- otherwise they'd keep firing at the stale, pre-edit moment."""
        action_step = self._get_owned(action_step_id, user=user)

        if step_text is not None:
            action_step.step_text = step_text

        deadline_changed = deadline_type is not None and deadline_type != action_step.deadline_type
        if deadline_changed:
            deadline_type, deadline_at = deadline_calculator.compute_deadline_type_and_at(deadline_type)
            action_step.deadline_type = deadline_type
            action_step.deadline_at = deadline_at
            action_step.remind_at = deadline_calculator.compute_remind_at(
                deadline_at, remind_hour=settings.ACTION_STEP_REMIND_HOUR
            )
            action_step.followup_at = deadline_at

        action_step.edit_count += 1
        action_step.edited_at = timezone.now()

        action_step = self.action_step_repository.save(action_step)
        if deadline_changed:
            self.notification_service.reschedule_for_step(action_step)
        return action_step

    def get_step(self, action_step_id: uuid.UUID, *, user: User) -> ActionStep:
        """GET /api/action-steps/:id -- also backs the checkin deep-link (notification tap) and
        the Step Detail sheet."""
        return self._get_owned(action_step_id, user=user)

    def list_pending(self, *, user: User, source: str | None = None) -> list[ActionStep]:
        """GET /api/action-steps/?source= -- action_steps_spec_v2 §6.1: "قدم‌های جاری", one
        shape for all, filterable by source."""
        return self.action_step_repository.list_pending(user=user, source=source)

    def list_history(self, *, user: User) -> list[ActionStep]:
        """GET /api/action-steps/history/ -- action_steps_spec_v2 §6.2."""
        return self.action_step_repository.list_history(user=user)

    def _record_reflection(self, action_step: ActionStep, reflection_text: str) -> None:
        """action_steps_spec_v2_2.md §8.1: the "چطور بود؟" answer is stored on the step row itself, not in
        memory. The row is the single source of a step's story (§8.0), and it goes to chat as
        `action_context.recent` (chat_spec §1.4) -- one behaviour paired with the user's own
        account of it, keyed to nothing else."""
        action_step.reflection = reflection_text
        action_step.answered_at = timezone.now()
        self.action_step_repository.save(action_step)

    def complete_step(
        self, *, action_step_id: uuid.UUID, user: User, reflection_text: str | None = None,
    ) -> ActionStep:
        """POST /api/action-steps/:id/complete/ -- the self-serve "I did it" button
        (action_steps_spec_v2 §8), distinct from record_response() below. `reflection_text` is
        accepted for a one-shot complete-and-reflect, but the dashboard flow completes here with
        no reflection and adds it afterwards via record_reflection()."""
        action_step = self._get_owned(action_step_id, user=user)
        if action_step.status != ActionStep.Status.PENDING:
            raise ActionStepNotPendingException()

        action_step.status = ActionStep.Status.DONE
        action_step.completed_at = timezone.now()
        if reflection_text:
            action_step.reflection = reflection_text
            action_step.answered_at = timezone.now()
        self.action_step_repository.save(action_step)

        self.notification_service.cancel_for_step(action_step)

        return action_step

    def record_reflection(
        self, *, action_step_id: uuid.UUID, user: User, reflection_text: str,
    ) -> ActionStep:
        """POST /api/action-steps/:id/reflection/ -- the optional "چطور بود؟" answer, collected
        after the step is already done (action_steps_spec_v2_2.md §8.1). Separate from complete_step()
        because the dashboard now completes on the "انجام دادم" tap and asks for the reflection
        in a second step; calling it again just overwrites the answer on the row."""
        action_step = self._get_owned(action_step_id, user=user)
        if action_step.status != ActionStep.Status.DONE:
            raise ActionStepNotDoneException()

        self._record_reflection(action_step, reflection_text)
        return action_step

    def record_response(
        self, *, action_step_id: uuid.UUID, user: User, result: str, obstacle: str | None, channel: str,
    ) -> ActionStep:
        """POST /api/action-steps/:id/followup/ -- notif-tap (reminder/followup) and the
        dashboard history's "بگو چرا انجام نشد" both land here (action_steps_spec_v2_2.md §6.2/§7),
        distinguished only by `channel`. No reflection prompt on this path (that's complete_step
        above, section 8's dedicated UI).

        The ActionStepResponse row is still written (it carries `channel`, for the obstacle
        distribution metric), but the obstacle answer is also merged onto the step row itself
        -- the row is the single source of a step's story now (§8.0) and is what chat reads."""
        obstacle = obstacle or ""
        obstacle_required = result != ActionStepResponse.Result.DONE
        if obstacle_required != bool(obstacle):
            raise ActionStepObstacleRequiredException()

        action_step = self._get_owned(action_step_id, user=user)
        if action_step.status != ActionStep.Status.PENDING:
            raise ActionStepNotPendingException()

        self.action_step_repository.create_response(
            action_step=action_step, result=result, obstacle=obstacle, channel=channel,
        )

        action_step.status = result
        if result == ActionStepResponse.Result.DONE:
            action_step.completed_at = timezone.now()
        else:
            action_step.obstacle = obstacle
            action_step.answered_at = timezone.now()
        self.action_step_repository.save(action_step)

        self.notification_service.cancel_for_step(action_step)

        return action_step

    def reactivate_step(self, *, action_step_id: uuid.UUID, user: User, deadline_type: str) -> ActionStep:
        """POST /api/action-steps/:id/reactivate/ -- action_steps_spec_v2 §6.2: creates a *new*
        step with the same text/source, fresh deadline; the original row is left untouched so
        the real history ("how many times was this tried") survives. Eligible rows are the ones
        Step History renders as "انجام‌نشده": explicit not_done/partial, or a still-`pending` row
        whose deadline has already passed without ever getting a response."""
        action_step = self._get_owned(action_step_id, user=user)
        is_overdue_unanswered = (
            action_step.status == ActionStep.Status.PENDING and action_step.deadline_at <= timezone.now()
        )
        eligible = action_step.status in (ActionStep.Status.NOT_DONE, ActionStep.Status.PARTIAL) or is_overdue_unanswered
        if not eligible:
            raise ActionStepReactivateRequiresNotDoneException()

        # create_step() already schedules this new step's notifications.
        return self.create_step(
            user=user, source=action_step.source, step_text=action_step.step_text,
            deadline_type=deadline_type, substeps=action_step.substeps,
        )
