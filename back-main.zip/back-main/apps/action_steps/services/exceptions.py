from rest_framework import status

from faraman_back.utils.exceptions import AppException


class ActionStepNotFoundException(AppException):
    """Raised when no action step exists for the given id."""
    status_code = status.HTTP_404_NOT_FOUND
    message_key = 'action_step_not_found'


class ActionStepAccessDeniedException(AppException):
    """Raised when the requesting user does not own the action step."""
    status_code = status.HTTP_403_FORBIDDEN
    message_key = 'action_step_access_denied'


class ActionStepInvalidSourceException(AppException):
    """Raised when `source` doesn't match one of the three allowed forms:
    initial_report:rec_<id> | deep_report:action_<id> | chat."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'action_step_invalid_source'


class ActionStepNotPendingException(AppException):
    """Raised by complete/followup when the step already has a terminal status -- not currently
    answerable a second time."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'action_step_not_pending'


class ActionStepNotDoneException(AppException):
    """Raised by record_reflection when the step isn't `done` -- a reflection ("چطور بود؟") only
    makes sense once the step has been completed (action_steps_spec_v2 §8.1)."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'action_step_not_done'


class ActionStepObstacleRequiredException(AppException):
    """`obstacle` must be provided iff result != done: required when partial/not_done, must be
    absent when done. Mirrors chat's FollowupObstacleRequiredException."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'action_step_obstacle_required'


class ActionStepReactivateRequiresNotDoneException(AppException):
    """Raised by reactivate_step when called on a step that isn't currently `not_done` --
    reactivating only makes sense for a step the user failed to complete (action_steps_spec_v2_2.md §6.2)."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'action_step_reactivate_requires_not_done'
