from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from django.utils import timezone

from apps.action_steps.models import ActionStep

TEHRAN = ZoneInfo("Asia/Tehran")


def compute_deadline_type_and_at(deadline_type: str, *, now: datetime | None = None) -> tuple[str, datetime]:
    """Maps a deadline_type to a concrete deadline_at in Iran time. Callers are expected to have
    already mapped anything outside DeadlineType.values to WITHIN_24H (ActionStepService does
    this -- the model has no clock and must never be given one, since that would break prompt
    caching). If the mapped moment has already passed relative to `now` (e.g. the user picks
    "tonight" at 23:59), falls back to within_24h -- this correction happens here in the
    backend, never in the prompt."""
    tehran_now = (now or timezone.now()).astimezone(TEHRAN)
    deadline_at = _map(deadline_type, tehran_now)

    if deadline_at <= tehran_now:
        deadline_type = ActionStep.DeadlineType.WITHIN_24H
        deadline_at = tehran_now + timedelta(hours=24)

    return deadline_type, deadline_at


def _map(deadline_type: str, tehran_now: datetime) -> datetime:
    if deadline_type == ActionStep.DeadlineType.TONIGHT:
        return tehran_now.replace(hour=23, minute=59, second=0, microsecond=0)
    if deadline_type == ActionStep.DeadlineType.TOMORROW_MORNING:
        return (tehran_now + timedelta(days=1)).replace(hour=12, minute=0, second=0, microsecond=0)
    if deadline_type == ActionStep.DeadlineType.TOMORROW_EVENING:
        return (tehran_now + timedelta(days=1)).replace(hour=23, minute=59, second=0, microsecond=0)
    return tehran_now + timedelta(hours=24)


def compute_remind_at(deadline_at: datetime, *, remind_hour: int, now: datetime | None = None) -> datetime:
    """remind_at defaults to the same calendar day as deadline_at (Tehran time), at
    settings.ACTION_STEP_REMIND_HOUR -- the exact hour is an open PM decision, so it's config
    rather than a literal here. If that moment has already passed relative to `now`, reminds
    immediately instead of scheduling something in the past."""
    tehran_deadline = deadline_at.astimezone(TEHRAN)
    remind_at = tehran_deadline.replace(hour=remind_hour, minute=0, second=0, microsecond=0)

    tehran_now = (now or timezone.now()).astimezone(TEHRAN)
    if remind_at <= tehran_now:
        return tehran_now
    return remind_at
