from datetime import datetime, timedelta
from unittest.mock import MagicMock
from zoneinfo import ZoneInfo

from django.test import TestCase
from django.utils import timezone

from apps.account.models import User
from apps.action_steps.models import ActionStep, ActionStepResponse
from apps.action_steps.repositories.action_step_repository import ActionStepRepository
from apps.action_steps.services import deadline_calculator
from apps.action_steps.services.action_step_service import ActionStepService
from apps.action_steps.services.exceptions import (
    ActionStepAccessDeniedException,
    ActionStepInvalidSourceException,
    ActionStepNotDoneException,
    ActionStepNotFoundException,
    ActionStepNotPendingException,
    ActionStepObstacleRequiredException,
    ActionStepReactivateRequiresNotDoneException,
)

TEHRAN = ZoneInfo("Asia/Tehran")


class DeadlineTypeMappingTests(TestCase):
    def test_tonight_maps_to_2359_same_day(self):
        now = datetime(2026, 8, 24, 10, 0, tzinfo=TEHRAN)

        deadline_type, deadline_at = deadline_calculator.compute_deadline_type_and_at(
            ActionStep.DeadlineType.TONIGHT, now=now
        )

        self.assertEqual(deadline_type, ActionStep.DeadlineType.TONIGHT)
        self.assertEqual(deadline_at, datetime(2026, 8, 24, 23, 59, tzinfo=TEHRAN))

    def test_tomorrow_morning_maps_to_noon_next_day(self):
        now = datetime(2026, 8, 24, 10, 0, tzinfo=TEHRAN)

        deadline_type, deadline_at = deadline_calculator.compute_deadline_type_and_at(
            ActionStep.DeadlineType.TOMORROW_MORNING, now=now
        )

        self.assertEqual(deadline_type, ActionStep.DeadlineType.TOMORROW_MORNING)
        self.assertEqual(deadline_at, datetime(2026, 8, 25, 12, 0, tzinfo=TEHRAN))

    def test_tomorrow_evening_maps_to_2359_next_day(self):
        now = datetime(2026, 8, 24, 10, 0, tzinfo=TEHRAN)

        deadline_type, deadline_at = deadline_calculator.compute_deadline_type_and_at(
            ActionStep.DeadlineType.TOMORROW_EVENING, now=now
        )

        self.assertEqual(deadline_type, ActionStep.DeadlineType.TOMORROW_EVENING)
        self.assertEqual(deadline_at, datetime(2026, 8, 25, 23, 59, tzinfo=TEHRAN))

    def test_within_24h_adds_24_hours(self):
        now = datetime(2026, 8, 24, 10, 0, tzinfo=TEHRAN)

        deadline_type, deadline_at = deadline_calculator.compute_deadline_type_and_at(
            ActionStep.DeadlineType.WITHIN_24H, now=now
        )

        self.assertEqual(deadline_type, ActionStep.DeadlineType.WITHIN_24H)
        self.assertEqual(deadline_at, datetime(2026, 8, 25, 10, 0, tzinfo=TEHRAN))

    def test_past_deadline_falls_back_to_within_24h(self):
        # "tonight" picked exactly at 23:59 -- the mapped deadline (23:59 same day) has already
        # arrived, so this must fall back to within_24h rather than storing a deadline in the past.
        now = datetime(2026, 8, 24, 23, 59, tzinfo=TEHRAN)

        deadline_type, deadline_at = deadline_calculator.compute_deadline_type_and_at(
            ActionStep.DeadlineType.TONIGHT, now=now
        )

        self.assertEqual(deadline_type, ActionStep.DeadlineType.WITHIN_24H)
        self.assertEqual(deadline_at, datetime(2026, 8, 25, 23, 59, tzinfo=TEHRAN))


class RemindAtTests(TestCase):
    def test_defaults_to_same_day_at_remind_hour(self):
        deadline_at = datetime(2026, 8, 25, 12, 0, tzinfo=TEHRAN)
        now = datetime(2026, 8, 24, 10, 0, tzinfo=TEHRAN)

        remind_at = deadline_calculator.compute_remind_at(deadline_at, remind_hour=9, now=now)

        self.assertEqual(remind_at, datetime(2026, 8, 25, 9, 0, tzinfo=TEHRAN))

    def test_fires_immediately_if_remind_hour_already_passed(self):
        deadline_at = datetime(2026, 8, 24, 23, 59, tzinfo=TEHRAN)
        now = datetime(2026, 8, 24, 15, 0, tzinfo=TEHRAN)

        remind_at = deadline_calculator.compute_remind_at(deadline_at, remind_hour=9, now=now)

        self.assertEqual(remind_at, now)


class ActionStepServiceSourceValidationTests(TestCase):
    def test_accepts_chat(self):
        self.assertTrue(ActionStepService.is_valid_source("chat"))

    def test_accepts_initial_report_recommendation(self):
        self.assertTrue(ActionStepService.is_valid_source("initial_report:rec_1"))

    def test_accepts_deep_report_action(self):
        self.assertTrue(ActionStepService.is_valid_source("deep_report:action_12"))

    def test_rejects_unknown_source(self):
        self.assertFalse(ActionStepService.is_valid_source("something_else"))


class ActionStepServiceCreateTests(TestCase):
    def setUp(self):
        self.repository = MagicMock()
        self.notification_service = MagicMock()
        self.service = ActionStepService(
            action_step_repository=self.repository, notification_service=self.notification_service,
        )

    def test_invalid_deadline_type_falls_back_to_within_24h(self):
        user = MagicMock(id=1)

        self.service.create_step(user=user, source="chat", step_text="t", deadline_type="bogus")

        _, kwargs = self.repository.create.call_args
        self.assertEqual(kwargs["deadline_type"], ActionStep.DeadlineType.WITHIN_24H)

    def test_raises_for_invalid_source(self):
        user = MagicMock(id=1)

        with self.assertRaises(ActionStepInvalidSourceException):
            self.service.create_step(
                user=user, source="bogus", step_text="t", deadline_type=ActionStep.DeadlineType.TONIGHT
            )
        self.repository.create.assert_not_called()

    def test_schedules_notifications_for_the_new_step(self):
        user = MagicMock(id=1)

        step = self.service.create_step(user=user, source="chat", step_text="t", deadline_type="tonight")

        self.notification_service.schedule_for_step.assert_called_once_with(step)


class ActionStepServiceEditTests(TestCase):
    def setUp(self):
        self.repository = MagicMock()
        self.notification_service = MagicMock()
        self.service = ActionStepService(
            action_step_repository=self.repository, notification_service=self.notification_service,
        )
        self.repository.save.side_effect = lambda step: step

    @staticmethod
    def _step(**overrides):
        defaults = dict(
            id="11111111-1111-1111-1111-111111111111",
            user_id=1,
            step_text="old text",
            deadline_type=ActionStep.DeadlineType.TOMORROW_MORNING,
            deadline_at=datetime(2026, 8, 25, 12, 0, tzinfo=TEHRAN),
            remind_at=datetime(2026, 8, 25, 9, 0, tzinfo=TEHRAN),
            followup_at=datetime(2026, 8, 25, 12, 0, tzinfo=TEHRAN),
            edit_count=0,
            edited_at=None,
        )
        defaults.update(overrides)
        return MagicMock(**defaults)

    def test_editing_text_only_does_not_touch_deadline(self):
        step = self._step()
        self.repository.get_by_id.return_value = step
        user = MagicMock(id=1)

        result = self.service.edit_step(action_step_id=step.id, user=user, step_text="new text")

        self.assertEqual(result.step_text, "new text")
        self.assertEqual(result.deadline_type, ActionStep.DeadlineType.TOMORROW_MORNING)
        self.assertEqual(result.deadline_at, step.deadline_at)
        self.assertEqual(result.edit_count, 1)
        self.assertIsNotNone(result.edited_at)
        self.notification_service.reschedule_for_step.assert_not_called()

    def test_editing_deadline_type_recomputes_all_three_timestamps(self):
        step = self._step()
        original_deadline_at = step.deadline_at
        original_remind_at = step.remind_at
        original_followup_at = step.followup_at
        self.repository.get_by_id.return_value = step
        user = MagicMock(id=1)

        result = self.service.edit_step(
            action_step_id=step.id, user=user, deadline_type=ActionStep.DeadlineType.TONIGHT
        )

        self.assertEqual(result.deadline_type, ActionStep.DeadlineType.TONIGHT)
        self.assertNotEqual(result.deadline_at, original_deadline_at)
        self.assertNotEqual(result.remind_at, original_remind_at)
        self.assertNotEqual(result.followup_at, original_followup_at)
        self.assertEqual(result.edit_count, 1)

    def test_editing_deadline_type_reschedules_notifications(self):
        step = self._step()
        self.repository.get_by_id.return_value = step
        user = MagicMock(id=1)

        result = self.service.edit_step(
            action_step_id=step.id, user=user, deadline_type=ActionStep.DeadlineType.TONIGHT
        )

        self.notification_service.reschedule_for_step.assert_called_once_with(result)

    def test_resending_same_deadline_type_does_not_recompute(self):
        step = self._step()
        original_deadline_at = step.deadline_at
        self.repository.get_by_id.return_value = step
        user = MagicMock(id=1)

        result = self.service.edit_step(
            action_step_id=step.id, user=user, deadline_type=ActionStep.DeadlineType.TOMORROW_MORNING
        )

        self.assertEqual(result.deadline_at, original_deadline_at)
        self.assertEqual(result.edit_count, 1)
        self.notification_service.reschedule_for_step.assert_not_called()

    def test_raises_not_found_when_step_missing(self):
        self.repository.get_by_id.return_value = None
        user = MagicMock(id=1)

        with self.assertRaises(ActionStepNotFoundException):
            self.service.edit_step(action_step_id="missing", user=user, step_text="t")

    def test_raises_access_denied_when_not_owner(self):
        step = self._step(user_id=2)
        self.repository.get_by_id.return_value = step
        user = MagicMock(id=1)

        with self.assertRaises(ActionStepAccessDeniedException):
            self.service.edit_step(action_step_id=step.id, user=user, step_text="t")
        self.repository.save.assert_not_called()


class ActionStepServiceCompleteTests(TestCase):
    def setUp(self):
        self.repository = MagicMock()
        self.notification_service = MagicMock()
        self.service = ActionStepService(
            action_step_repository=self.repository,
            notification_service=self.notification_service,
        )

    @staticmethod
    def _pending_step(**overrides):
        defaults = dict(
            id="s1", user_id=1, status=ActionStep.Status.PENDING, completed_at=None,
            reflection=None, answered_at=None,
        )
        defaults.update(overrides)
        user = MagicMock(id=defaults["user_id"])
        step = MagicMock(**defaults)
        step.user = user
        return step

    def test_marks_done_and_cancels_notifications(self):
        step = self._pending_step()
        self.repository.get_by_id.return_value = step
        user = MagicMock(id=1)

        result = self.service.complete_step(action_step_id=step.id, user=user)

        self.assertEqual(result.status, ActionStep.Status.DONE)
        self.assertIsNotNone(result.completed_at)
        self.notification_service.cancel_for_step.assert_called_once_with(step)

    def test_no_reflection_text_leaves_reflection_unset(self):
        step = self._pending_step()
        self.repository.get_by_id.return_value = step
        user = MagicMock(id=1)

        result = self.service.complete_step(action_step_id=step.id, user=user)

        self.assertIsNone(result.reflection)
        self.assertIsNone(result.answered_at)

    def test_reflection_text_is_stored_on_the_step_row(self):
        step = self._pending_step()
        self.repository.get_by_id.return_value = step
        user = MagicMock(id=1)

        result = self.service.complete_step(
            action_step_id=step.id, user=user, reflection_text="راحت‌تر از چیزی که فکر می‌کردم بود",
        )

        self.assertEqual(result.reflection, "راحت‌تر از چیزی که فکر می‌کردم بود")
        self.assertIsNotNone(result.answered_at)
        self.repository.save.assert_called_once_with(step)

    def test_raises_when_already_answered(self):
        step = self._pending_step(status=ActionStep.Status.DONE)
        self.repository.get_by_id.return_value = step
        user = MagicMock(id=1)

        with self.assertRaises(ActionStepNotPendingException):
            self.service.complete_step(action_step_id=step.id, user=user)


class ActionStepServiceRecordReflectionTests(TestCase):
    def setUp(self):
        self.repository = MagicMock()
        self.notification_service = MagicMock()
        self.service = ActionStepService(
            action_step_repository=self.repository,
            notification_service=self.notification_service,
        )

    @staticmethod
    def _step(**overrides):
        defaults = dict(id="s1", user_id=1, status=ActionStep.Status.DONE, reflection=None, answered_at=None)
        defaults.update(overrides)
        step = MagicMock(**defaults)
        step.user = MagicMock(id=defaults["user_id"])
        return step

    def test_writes_reflection_and_answered_at_on_the_row(self):
        step = self._step()
        self.repository.get_by_id.return_value = step

        result = self.service.record_reflection(
            action_step_id=step.id, user=MagicMock(id=1), reflection_text="بهتر از چیزی که فکر می‌کردم بود",
        )

        self.assertIs(result, step)
        self.assertEqual(step.reflection, "بهتر از چیزی که فکر می‌کردم بود")
        self.assertIsNotNone(step.answered_at)
        self.repository.save.assert_called_once_with(step)

    def test_raises_when_step_not_done(self):
        step = self._step(status=ActionStep.Status.PENDING)
        self.repository.get_by_id.return_value = step

        with self.assertRaises(ActionStepNotDoneException):
            self.service.record_reflection(
                action_step_id=step.id, user=MagicMock(id=1), reflection_text="هرچی",
            )
        self.repository.save.assert_not_called()


class ActionStepServiceRecordResponseTests(TestCase):
    def setUp(self):
        self.repository = MagicMock()
        self.notification_service = MagicMock()
        self.service = ActionStepService(
            action_step_repository=self.repository, notification_service=self.notification_service,
        )

    @staticmethod
    def _pending_step(**overrides):
        defaults = dict(id="s1", user_id=1, status=ActionStep.Status.PENDING, completed_at=None)
        defaults.update(overrides)
        return MagicMock(**defaults)

    def test_not_done_requires_obstacle(self):
        step = self._pending_step()
        self.repository.get_by_id.return_value = step
        user = MagicMock(id=1)

        with self.assertRaises(ActionStepObstacleRequiredException):
            self.service.record_response(
                action_step_id=step.id, user=user, result=ActionStepResponse.Result.NOT_DONE,
                obstacle=None, channel=ActionStepResponse.Channel.DASHBOARD,
            )

    def test_done_rejects_obstacle(self):
        step = self._pending_step()
        self.repository.get_by_id.return_value = step
        user = MagicMock(id=1)

        with self.assertRaises(ActionStepObstacleRequiredException):
            self.service.record_response(
                action_step_id=step.id, user=user, result=ActionStepResponse.Result.DONE,
                obstacle=ActionStepResponse.Obstacle.NO_TIME, channel=ActionStepResponse.Channel.NOTIF,
            )

    def test_not_done_records_response_and_cancels_notifications(self):
        step = self._pending_step()
        self.repository.get_by_id.return_value = step
        user = MagicMock(id=1)

        result = self.service.record_response(
            action_step_id=step.id, user=user, result=ActionStepResponse.Result.NOT_DONE,
            obstacle=ActionStepResponse.Obstacle.NO_TIME, channel=ActionStepResponse.Channel.DASHBOARD,
        )

        self.assertEqual(result.status, ActionStepResponse.Result.NOT_DONE)
        self.repository.create_response.assert_called_once()
        self.notification_service.cancel_for_step.assert_called_once_with(step)

    def test_done_via_followup_sets_completed_at(self):
        step = self._pending_step()
        self.repository.get_by_id.return_value = step
        user = MagicMock(id=1)

        result = self.service.record_response(
            action_step_id=step.id, user=user, result=ActionStepResponse.Result.DONE,
            obstacle=None, channel=ActionStepResponse.Channel.NOTIF,
        )

        self.assertIsNotNone(result.completed_at)

    def test_raises_when_not_pending(self):
        step = self._pending_step(status=ActionStep.Status.DONE)
        self.repository.get_by_id.return_value = step
        user = MagicMock(id=1)

        with self.assertRaises(ActionStepNotPendingException):
            self.service.record_response(
                action_step_id=step.id, user=user, result=ActionStepResponse.Result.DONE,
                obstacle=None, channel=ActionStepResponse.Channel.NOTIF,
            )


class ActionStepServiceReactivateTests(TestCase):
    def setUp(self):
        self.repository = MagicMock()
        self.notification_service = MagicMock()
        self.service = ActionStepService(
            action_step_repository=self.repository, notification_service=self.notification_service,
        )

    def test_creates_new_step_and_leaves_old_row_untouched(self):
        old_step = MagicMock(
            id="s1", user_id=1, status=ActionStep.Status.NOT_DONE, source="chat", step_text="قدم قدیمی",
            substeps=None,
        )
        self.repository.get_by_id.return_value = old_step
        user = MagicMock(id=1)

        new_step = self.service.reactivate_step(
            action_step_id=old_step.id, user=user, deadline_type=ActionStep.DeadlineType.TONIGHT,
        )

        self.assertIsNotNone(new_step)
        self.repository.save.assert_not_called()  # old_step is never mutated
        _, kwargs = self.repository.create.call_args
        self.assertEqual(kwargs["source"], old_step.source)
        self.assertEqual(kwargs["step_text"], old_step.step_text)

    def test_raises_when_step_is_still_pending_and_not_yet_due(self):
        step = MagicMock(
            id="s1", user_id=1, status=ActionStep.Status.PENDING,
            deadline_at=timezone.now() + timedelta(hours=1),
        )
        self.repository.get_by_id.return_value = step
        user = MagicMock(id=1)

        with self.assertRaises(ActionStepReactivateRequiresNotDoneException):
            self.service.reactivate_step(action_step_id=step.id, user=user, deadline_type="tonight")

    def test_raises_when_step_is_done(self):
        step = MagicMock(id="s1", user_id=1, status=ActionStep.Status.DONE)
        self.repository.get_by_id.return_value = step
        user = MagicMock(id=1)

        with self.assertRaises(ActionStepReactivateRequiresNotDoneException):
            self.service.reactivate_step(action_step_id=step.id, user=user, deadline_type="tonight")

    def test_allows_reactivating_an_overdue_unanswered_pending_step(self):
        step = MagicMock(
            id="s1", user_id=1, status=ActionStep.Status.PENDING,
            deadline_at=timezone.now() - timedelta(hours=1), source="chat", step_text="قدم قدیمی",
            substeps=None,
        )
        self.repository.get_by_id.return_value = step
        user = MagicMock(id=1)

        new_step = self.service.reactivate_step(action_step_id=step.id, user=user, deadline_type="tonight")

        self.assertIsNotNone(new_step)

    def test_allows_reactivating_a_partial_step(self):
        step = MagicMock(
            id="s1", user_id=1, status=ActionStep.Status.PARTIAL, source="chat", step_text="قدم قدیمی",
            substeps=None,
        )
        self.repository.get_by_id.return_value = step
        user = MagicMock(id=1)

        new_step = self.service.reactivate_step(action_step_id=step.id, user=user, deadline_type="tonight")

        self.assertIsNotNone(new_step)

class ActionStepRepositoryListRecentTests(TestCase):
    def setUp(self):
        self.repository = ActionStepRepository()
        self.user = User.objects.create(phone_number="09121110000")
        self.other = User.objects.create(phone_number="09121110001")

    def _step(self, user, **overrides):
        now = timezone.now()
        defaults = dict(
            user=user, source="chat", step_text="قدم", deadline_type=ActionStep.DeadlineType.TONIGHT,
            deadline_at=now, remind_at=now, followup_at=now,
        )
        defaults.update(overrides)
        return ActionStep.objects.create(**defaults)

    def test_returns_last_three_newest_first_regardless_of_status(self):
        for i in range(5):
            step = self._step(
                self.user,
                step_text=f"step-{i}",
                status=ActionStep.Status.PENDING if i % 2 else ActionStep.Status.DONE,
            )
            ActionStep.objects.filter(pk=step.pk).update(created_at=timezone.now() + timedelta(minutes=i))

        recent = self.repository.list_recent(user=self.user)

        self.assertEqual([s.step_text for s in recent], ["step-4", "step-3", "step-2"])

    def test_scoped_to_the_user(self):
        self._step(self.other)

        self.assertEqual(self.repository.list_recent(user=self.user), [])


class ActionStepRepositoryListPendingTests(TestCase):
    def setUp(self):
        self.repository = ActionStepRepository()
        self.user = User.objects.create(phone_number="09121110000")

    def _pending(self, *, step_text, deadline_at, created_at):
        step = ActionStep.objects.create(
            user=self.user, source="chat", step_text=step_text,
            deadline_type=ActionStep.DeadlineType.WITHIN_24H,
            deadline_at=deadline_at, remind_at=deadline_at, followup_at=deadline_at,
            status=ActionStep.Status.PENDING,
        )
        ActionStep.objects.filter(pk=step.pk).update(created_at=created_at)
        return step

    def test_ordered_by_nearest_deadline_first(self):
        now = timezone.now()
        self._pending(step_text="far", deadline_at=now + timedelta(hours=20), created_at=now)
        self._pending(step_text="near", deadline_at=now + timedelta(hours=2), created_at=now + timedelta(minutes=5))

        pending = self.repository.list_pending(user=self.user)

        self.assertEqual([s.step_text for s in pending], ["near", "far"])

    def test_same_deadline_falls_back_to_oldest_created_first(self):
        now = timezone.now()
        deadline = now + timedelta(hours=6)
        self._pending(step_text="older", deadline_at=deadline, created_at=now - timedelta(hours=2))
        self._pending(step_text="newer", deadline_at=deadline, created_at=now - timedelta(minutes=10))

        pending = self.repository.list_pending(user=self.user)

        self.assertEqual([s.step_text for s in pending], ["older", "newer"])
