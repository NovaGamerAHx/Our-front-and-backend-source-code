import uuid
from datetime import datetime

from django.db.models import Q
from django.utils import timezone

from apps.account.models import User
from apps.action_steps.models import ActionStep, ActionStepResponse

_HISTORY_STATUSES = (ActionStep.Status.DONE, ActionStep.Status.PARTIAL, ActionStep.Status.NOT_DONE)


class ActionStepRepository:
    def create(
        self,
        *,
        user: User,
        source: str,
        step_text: str,
        substeps: list | None,
        deadline_type: str,
        deadline_at: datetime,
        remind_at: datetime,
        followup_at: datetime,
    ) -> ActionStep:
        return ActionStep.objects.create(
            user=user,
            source=source,
            step_text=step_text,
            substeps=substeps,
            deadline_type=deadline_type,
            deadline_at=deadline_at,
            remind_at=remind_at,
            followup_at=followup_at,
        )

    def get_by_id(self, action_step_id: uuid.UUID) -> ActionStep | None:
        return ActionStep.objects.filter(id=action_step_id).first()

    def get_for_user(self, action_step_id: uuid.UUID, user: User) -> ActionStep | None:
        return ActionStep.objects.filter(id=action_step_id, user=user).first()

    def list_pending(self, *, user: User, source: str | None = None) -> list[ActionStep]:
        """action_steps_spec_v2 §6.1: "قدم‌های جاری" -- pending AND not deadline-passed. A pending
        step whose deadline has passed without ever getting a response moves to history instead
        (§6.2), not because its status changed (nothing changed it) but because it's now due for
        an answer.

        Ordered by deadline_at ascending -- the step whose deadline is closest sits on top of the
        dashboard list. deadline_at only ever takes a handful of discrete values (tonight 23:59,
        tomorrow 12:00, tomorrow 23:59, now+24h), so a `created_at` tiebreak is added to keep the
        order within one deadline bucket stable (oldest step first) instead of leaving it to
        Postgres' undefined row order."""
        qs = ActionStep.objects.filter(
            user=user, status=ActionStep.Status.PENDING, deadline_at__gt=timezone.now(),
        )
        if source:
            qs = qs.filter(source=source)
        return list(qs.order_by("deadline_at", "created_at"))

    def list_history(self, *, user: User) -> list[ActionStep]:
        """action_steps_spec_v2 §6.2: done/partial/not_done, plus any pending step whose deadline
        has already passed (the "needs an answer" row -- reactivate or say why not)."""
        return list(
            ActionStep.objects.filter(user=user)
            .filter(
                Q(status__in=_HISTORY_STATUSES)
                | Q(status=ActionStep.Status.PENDING, deadline_at__lte=timezone.now())
            )
            .order_by("-created_at")
        )

    def list_recent(self, *, user: User, limit: int = 3) -> list[ActionStep]:
        """chat_spec §1.4 / action_steps_spec_v2_2.md §8.0.1: the last `limit` steps for this user, with
        NO filter -- a still-`pending` step is information too. Newest first. Goes to chat as
        `action_context.recent` on every turn, replacing the old `action_outcome` memory type."""
        return list(ActionStep.objects.filter(user=user).order_by("-created_at")[:limit])

    def save(self, action_step: ActionStep) -> ActionStep:
        action_step.save()
        return action_step

    def create_response(
        self, *, action_step: ActionStep, result: str, obstacle: str, channel: str,
    ) -> ActionStepResponse:
        return ActionStepResponse.objects.create(
            action_step=action_step, result=result, obstacle=obstacle, channel=channel,
        )

    def get_response_for_step(self, action_step: ActionStep) -> ActionStepResponse | None:
        return ActionStepResponse.objects.filter(action_step=action_step).order_by("-created_at").first()
