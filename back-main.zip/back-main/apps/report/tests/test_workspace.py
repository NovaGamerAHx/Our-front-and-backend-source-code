from django.test import TestCase
from django.utils import timezone
from rest_framework.test import APIClient
from apps.account.models import User
from apps.assessment.models import Assessment, Attempt
from apps.report.models import Report, RejectedFinding
from apps.report.services.workspace_service import WorkspaceReportService
from apps.report.services.exceptions import ReportAccessDeniedException, ReportNotReadyException, SuggestedStepNotFoundException
from apps.chat.services.chat_service import ChatService
from apps.ai.chat_generation.chat_input import ChatRequest
from apps.ai.chat_generation.prompt import render_session_context


class WorkspaceContextTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(phone_number="09123450001")
        self.other = User.objects.create_user(phone_number="09123450002")
        self.assessment = Assessment.objects.create(slug="workspace-test", title="test")
        self.service = WorkspaceReportService()

    def report(self, kind="initial", status="ok"):
        attempt = Attempt.objects.create(user=self.user, assessment=self.assessment, status="completed", completed_at=timezone.now())
        return Report.objects.create(attempt=attempt, report_type=kind, status=status, report_version="report_v3" if kind=="initial" else "deep_report_v1", dimension_scores=[{"key": "openness", "score_percent": 71}], domain_scores=[{"code":"O", "index":63, "level":"mid"}], report_data={"findings":[{"what":"برداشت اول"},{"what":"برداشت دوم"}]} if kind=="initial" else {"blind_spots":{"items":[{"hypothesis":"برداشت عمیق"}]}})

    def test_empty(self):
        self.assertIsNone(self.service.context(self.user)["report"])

    def test_deep_preferred_even_when_initial_newer(self):
        deep=self.report("deep"); self.report()
        result=self.service.context(self.user)["report"]
        self.assertEqual(result["attempt_id"],deep.attempt_id)
        self.assertEqual(result["scores"][0]["score"],63)

    def test_initial_fallback_exact_numeric(self):
        self.report(); self.report("deep","awaiting_payment")
        result=self.service.context(self.user)["report"]
        self.assertEqual(result["report_type"],"initial")
        self.assertEqual(result["scores"][0]["score"],71)

    def test_rejection_persists_idempotently(self):
        report=self.report()
        for _ in range(2): self.service.reject(attempt_id=report.attempt_id,user=self.user,key="finding:0")
        self.assertEqual(RejectedFinding.objects.count(),1)
        result=WorkspaceReportService().context(self.user)["report"]
        self.assertEqual([f["key"] for f in result["findings"]],["finding:1"])

    def test_rejection_ownership(self):
        report=self.report()
        with self.assertRaises(ReportAccessDeniedException): self.service.reject(attempt_id=report.attempt_id,user=self.other,key="finding:0")

    def test_locked_rejected(self):
        report=self.report(status="awaiting_payment")
        with self.assertRaises(ReportNotReadyException): self.service.reject(attempt_id=report.attempt_id,user=self.user,key="finding:0")

    def test_invalid_key(self):
        report=self.report()
        with self.assertRaises(SuggestedStepNotFoundException): self.service.reject(attempt_id=report.attempt_id,user=self.user,key="made-up")

    def test_api_auth_and_roundtrip(self):
        report=self.report()
        client=APIClient()
        self.assertIn(client.get("/api/reports/workspace-context/").status_code,[401,403])
        client.force_authenticate(self.user)
        response=client.post(f"/api/reports/attempts/{report.attempt_id}/reject-finding/",{"key":"finding:0"},format="json")
        self.assertEqual(response.status_code,200)
        response=client.get("/api/reports/workspace-context/")
        self.assertEqual(len(response.data["data"]["report"]["findings"]),1)

    def test_context_entry_sources_validate_on_both_boundaries(self):
        for source,kind in [("report_context","initial"),("deep_report_context","deep")]:
            self.assertTrue(ChatService._is_valid_entry_source(source))
            self.assertTrue(ChatService._entry_source_requires_report(source))
            self.assertEqual(ChatService._expected_report_type(source),kind)
            ChatRequest(session_id="test",entry_source=source,user_message="test",report_type=kind,report={"test":1},report_version="report_v3" if kind=="initial" else None)
            self.assertIn("دفاع یا توجیه نکن",render_session_context(source))

    def test_context_session_binds_report_and_checks_owner(self):
        report=self.report()
        service=ChatService()
        session=service.create_session(user=self.user,entry_source="report_context",attempt_id=report.attempt_id)
        self.assertEqual(session.report_id,report.pk)
        with self.assertRaises(ReportAccessDeniedException):
            service.create_session(user=self.other,entry_source="report_context",attempt_id=report.attempt_id)

    def test_context_payload_masks_rejected_finding_without_mutating_report(self):
        report=self.report()
        self.service.reject(attempt_id=report.attempt_id,user=self.user,key="finding:0")
        service=ChatService()
        session=service.create_session(user=self.user,entry_source="report_context",attempt_id=report.attempt_id)
        payload=service._build_payload(session=session,user=self.user,user_message="این برداشت با من نمی‌خواند",history=[])
        self.assertNotIn("برداشت اول",str(payload["report"]))
        self.assertEqual(len(payload["report"]["findings"]),2)
        report.refresh_from_db()
        self.assertEqual(report.report_data["findings"][0]["what"],"برداشت اول")

    def test_context_never_selects_other_users_report(self):
        self.report()
        self.assertIsNone(self.service.context(self.other)["report"])

    def test_latest_successful_deep_excludes_newer_locked_and_deleted(self):
        old = self.report("deep")
        latest = self.report("deep")
        self.report("deep", "awaiting_payment")
        deleted = self.report("deep")
        deleted.attempt.is_deleted = True
        deleted.attempt.save(update_fields=["is_deleted"])
        self.report()
        self.assertNotEqual(old.attempt_id, latest.attempt_id)
        self.assertEqual(self.service.context(self.user)["report"]["attempt_id"], latest.attempt_id)

    def test_five_initial_scores_pass_through_without_level_conversion(self):
        report = self.report()
        keys = ["emotional_stability", "extraversion", "openness", "agreeableness", "conscientiousness"]
        expected = [0, 17.5, 43, 76, 100]
        report.dimension_scores = [{"key": key, "score_percent": value, "level": "medium"} for key, value in zip(keys, expected)]
        report.save(update_fields=["dimension_scores"])
        self.assertEqual([s["score"] for s in self.service.context(self.user)["report"]["scores"]], expected)

    def test_five_deep_indices_pass_through_exactly(self):
        report = self.report("deep")
        expected = [12, 31, 53, 77, 94]
        report.domain_scores = [{"code": code, "index": value, "level": "mid"} for code, value in zip("NEOAC", expected)]
        report.save(update_fields=["domain_scores"])
        self.assertEqual([s["score"] for s in self.service.context(self.user)["report"]["scores"]], expected)

    def test_deep_rejection_is_removed_from_chat_without_mutating_storage(self):
        report = self.report("deep")
        self.service.reject(attempt_id=report.attempt_id, user=self.user, key="blind_spots:0")
        chat = ChatService()
        session = chat.create_session(user=self.user, entry_source="deep_report_context", attempt_id=report.attempt_id)
        payload = chat._build_payload(session=session, user=self.user, user_message="نه", history=[])
        self.assertEqual(payload["report"]["blind_spots"]["items"], [])
        report.refresh_from_db()
        self.assertEqual(len(report.report_data["blind_spots"]["items"]), 1)

    def test_teaser_is_real_strongest_facet_without_paid_scores(self):
        from apps.report.services.report_service import ReportService
        from faraman_back.lang.utils import get_message
        report = self.report("deep", "awaiting_payment")
        report.facet_scores = [{"code": "O1", "provisional": 23, "level": "low"}, {"code": "C1", "provisional": 91, "level": "high"}]
        report.save(update_fields=["facet_scores"])
        result = ReportService()._shape(report, user=self.user)
        self.assertEqual(result["teaser"], {"title": get_message("deep_facet_title_c1"), "level": "high"})
        self.assertFalse({"domain_scores", "facet_scores", "report"}.intersection(result))

    def test_missing_teaser_stays_missing_not_fabricated(self):
        from apps.report.services.report_service import ReportService
        report = self.report("deep", "awaiting_payment")
        self.assertIsNone(ReportService()._shape(report, user=self.user)["teaser"])

    def test_progress_counts_only_active_questions_for_current_attempt(self):
        from apps.assessment.models import AssessmentSection, Question, Answer
        from apps.assessment.repositories.attempt_repository import AttemptRepository
        section = AssessmentSection.objects.create(assessment=self.assessment, title="test", order=1)
        active = Question.objects.create(section=section, order=1, text="one", question_type="likert")
        inactive = Question.objects.create(section=section, order=2, text="two", question_type="likert", is_active=False)
        attempt = Attempt.objects.create(user=self.user, assessment=self.assessment)
        other = Attempt.objects.create(user=self.other, assessment=self.assessment)
        for instance, question in [(attempt, active), (attempt, inactive), (other, active)]:
            Answer.objects.create(attempt=instance, question=question, value=3)
        repository = AttemptRepository()
        self.assertEqual(repository.progress_counts(attempt, {active.pk}), 1)
        self.assertEqual(repository.progress_counts(None, {active.pk}), 0)
