"""Production-readiness checks for the version-specific v3 PDF redesign.

No SMTP/provider calls: the attachment is rendered by real WeasyPrint and handed to an
injected email boundary. Historical reports must continue to select their own templates.
"""
import copy
import json
from html import escape
from unittest.mock import MagicMock, patch

from django.template.loader import render_to_string
from django.test import TestCase, override_settings

from apps.account.models import User
from apps.ai.tests import _fewshot_model_output, _v2_example
from apps.assessment.models import Assessment, Attempt
from apps.report.models import Report
from apps.report.services.pdf_service import ReportPdfService
from apps.report.services.report_service import ReportService
from apps.report.services import report_presentation
from apps.report.tests.test_report_v3 import _V3_DIMENSION_SCORES, _V3_REPORT_DATA


@override_settings(FRONTEND_URL="https://faraman.example")
class VersionedPdfDesignTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(phone_number="09123450999")
        self.assessment = Assessment.objects.create(slug="pdf-version-test", title="test")

    def make_report(self, version="report_v3", data=None):
        attempt = Attempt.objects.create(user=self.user, assessment=self.assessment)
        return Report.objects.create(
            attempt=attempt, report_type="initial", report_version=version, status="ok",
            dimension_scores=_V3_DIMENSION_SCORES,
            report_data=copy.deepcopy(data if data is not None else _V3_REPORT_DATA),
        )

    def test_v3_uses_dedicated_artwork_not_v2_artwork(self):
        images = ReportPdfService.image_context()["images"]
        for key in ("v3_hero", "v3_finding_1", "v3_finding_2"):
            self.assertTrue(images[key].startswith("data:image/jpeg;base64,"))
        self.assertNotEqual(images["v3_hero"], images["v2_hero"])
        report = self.make_report()
        html = render_to_string("report/pdf_initial_v3.html", {
            **ReportService._build_initial_v3_email_context(report), "images": images,
        })
        self.assertIn(images["v3_hero"], html)
        self.assertNotIn(images["v2_hero"], html)
        self.assertNotIn(images["v2_strength"], html)
        self.assertNotIn("نقطه‌ی کور", html)
        self.assertIn("چیزی که کمتر می‌بینی", html)

    def test_v3_radar_uses_actual_numeric_geometry_and_keeps_storage_unchanged(self):
        report = self.make_report()
        before = copy.deepcopy(report.report_data)
        context = ReportService._build_initial_v3_email_context(report)
        expected = report_presentation.initial_radar_polygon({d["key"]: d["score_percent"] for d in report.dimension_scores})
        self.assertEqual(context["radar_points"], expected)
        self.assertEqual(report.report_data, before)
        self.assertNotIn("system_data", context)
        self.assertNotIn("source_map", context)

    def test_v3_links_keep_the_matching_attempt_and_configured_host(self):
        report = self.make_report()
        context = ReportService._build_initial_v3_email_context(report)
        self.assertEqual(context["report_url"], f"https://faraman.example/report?attemptId={report.attempt_id}")
        self.assertEqual(context["goal_chat_url"], f"https://faraman.example/chat?entry_source=report_goal&attempt_id={report.attempt_id}")
        self.assertIn("entry_source=report_cta", context["chat_url"])
        self.assertEqual(context["deep_test_url"], "https://faraman.example/deep-test?source=initial_report")

    def test_ai_text_is_escaped_in_the_pdf_html(self):
        report = self.make_report()
        report.report_data["mirror"]["outer"] = '<script>alert("unsafe")</script>'
        html = render_to_string("report/pdf_initial_v3.html", {**ReportService._build_initial_v3_email_context(report), "images": {}})
        self.assertIn(escape(report.report_data["mirror"]["outer"]), html)
        self.assertNotIn('<script>alert', html)

    def test_real_v3_pdf_bytes_reach_the_email_attachment_boundary(self):
        report = self.make_report()
        email = MagicMock()
        email.send_html.return_value = True
        service = ReportService(
            email_service=email, pdf_service=ReportPdfService(),
            report_email_throttle_repository=MagicMock(**{"hit.return_value": False}),
            report_email_delivery_repository=MagicMock(),
        )
        service.email_report(attempt_id=report.attempt_id, user=self.user, email="reader@example.com")
        kwargs = email.send_html.call_args.kwargs
        self.assertTrue(kwargs["pdf_attachment"].startswith(b"%PDF-"))
        self.assertGreater(len(kwargs["pdf_attachment"]), 10000)
        self.assertEqual(kwargs["pdf_filename"], f"faraman-report-{report.attempt_id}.pdf")

    def test_all_stored_versions_select_their_own_email_pdf_templates(self):
        examples = [
            ("report_v1", json.loads(_fewshot_model_output(1))["report"], "report/pdf_initial.html"),
            ("report_v2", _v2_example("A")["report"], "report/pdf_initial_v2.html"),
            ("report_v3", _V3_REPORT_DATA, "report/pdf_initial_v3.html"),
        ]
        for version, data, expected in examples:
            with self.subTest(version=version):
                report = self.make_report(version, data)
                service = ReportService(
                    email_service=MagicMock(**{"send_html.return_value": True}),
                    pdf_service=MagicMock(**{"font_context.return_value": {}, "image_context.return_value": {"images": {}}, "render_pdf.return_value": b"%PDF-test"}),
                    report_email_throttle_repository=MagicMock(**{"hit.return_value": False}),
                    report_email_delivery_repository=MagicMock(),
                )
                with patch("apps.report.services.report_service.render_to_string", wraps=render_to_string) as render:
                    service.email_report(attempt_id=report.attempt_id, user=self.user, email="reader@example.com")
                self.assertEqual(render.call_args_list[0].args[0], expected)
                if version == "report_v3":
                    self.assertEqual(render.call_args_list[1].args[0], "report/email_pdf_notice_v3.html")
                    notice = render_to_string("report/email_pdf_notice_v3.html", render.call_args_list[1].args[1])
                    self.assertIn(f"https://faraman.example/report?attemptId={report.attempt_id}", notice)
