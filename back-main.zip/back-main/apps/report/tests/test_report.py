import json
from decimal import Decimal
from unittest.mock import MagicMock, patch

from django.test import TestCase
from django.utils import timezone

from apps.account.models import User
from apps.ai.deep_report_generation.client import MOCK_PATH
from apps.ai.deep_report_generation.schema import FACET_CODES
from apps.ai.deep_report_generation.structure import DOMAIN_ORDER
from apps.ai.models import ModelPricing
from apps.ai.tests import _DIMENSION_SCORES, _FakeOpenAIClient, _fewshot_model_output, _v2_example
from apps.assessment.models import Answer, Assessment, AssessmentSection, Attempt, Question
from apps.report.models import Report
from apps.report.repositories.report_repository import ReportRepository
from apps.report.services.ai_report_client import AiReportClient
from apps.report.services.exceptions import (
    ReportAccessDeniedException,
    ReportEmailDeliveryFailedException,
    ReportEmailThrottledException,
    ReportNotFoundException,
    ReportNotReadyException,
    ReportPdfGenerationFailedException,
    ReportRetryNotAllowedException,
    ScoreOutOfRangeException,
    SuggestedStepNotFoundException,
)
from apps.report.services.deep_report_service import DeepReportService
from apps.report.services.report_service import ReportService
from apps.report.services.scoring_service import ScoringService
from faraman_back.observability.testing import read_metric


class ScoringServiceTests(TestCase):
    """A question's dimension is its section's title (no per-question dimension field), so each
    dimension needs its own AssessmentSection here, titled exactly the dimension key."""

    def setUp(self):
        self.assessment = Assessment.objects.create(slug='big-five-test', title='Test', kind=Assessment.Kind.INITIAL)
        self.attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-1')
        self.service = ScoringService()
        self._sections = {}

    def _section_for(self, title):
        if title not in self._sections:
            self._sections[title] = AssessmentSection.objects.create(
                assessment=self.assessment, order=len(self._sections) + 1, title=title,
            )
        return self._sections[title]

    def _add_question(self, dimension, reverse, value):
        section = self._section_for(dimension)
        order = section.questions.count() + 1
        question = Question.objects.create(
            section=section, order=order, text=f'{dimension}-{order}', question_type=Question.QuestionType.LIKERT,
            reverse_scored=reverse,
        )
        Answer.objects.create(attempt=self.attempt, question=question, value=value)
        return question

    def test_is_complete_false_when_no_scored_questions(self):
        # 'General' isn't one of the 5 recognized dimension keys, so it never counts as scored.
        section = self._section_for('General')
        Question.objects.create(section=section, order=1, text='Q1', question_type=Question.QuestionType.LIKERT)

        self.assertFalse(self.service.is_complete(self.attempt))

    def test_is_complete_false_when_missing_answers(self):
        self._add_question('openness', False, 5)
        section = self._section_for('openness')
        Question.objects.create(section=section, order=2, text='Q2', question_type=Question.QuestionType.LIKERT)

        self.assertFalse(self.service.is_complete(self.attempt))

    def test_is_complete_true_when_all_scored_questions_answered(self):
        self._add_question('openness', False, 5)

        self.assertTrue(self.service.is_complete(self.attempt))

    def _fill_remaining_dimensions_neutrally(self, skip_dimension):
        """Answers every dimension except `skip_dimension` with 6 neutral (value=3) responses, so
        score_attempt() has a fully complete answer set to work with (its documented precondition)."""
        from apps.report.services.scoring_service import DIMENSION_ORDER

        for dimension in DIMENSION_ORDER:
            if dimension == skip_dimension:
                continue
            for _ in range(6):
                self._add_question(dimension, False, 3)

    def test_score_attempt_applies_reverse_scoring_and_maps_to_level(self):
        for value in (5, 5, 5, 5, 5, 5):
            self._add_question('openness', False, value)
        # all-5 answers -> factor_sum 30 -> score_percent 100 -> level 'high'
        self._fill_remaining_dimensions_neutrally(skip_dimension='openness')

        dimension_scores = self.service.score_attempt(self.attempt)

        openness = next(item for item in dimension_scores if item['key'] == 'openness')
        self.assertEqual(openness['score_percent'], 100)
        self.assertEqual(openness['level'], 'high')

    def test_level_for_raises_appexception_when_score_out_of_range(self):
        # A full valid answer set can only yield 0-100; anything else means corrupt data, and
        # must surface as an AppException (-> standard ApiResponse.error envelope), not a raw 500.
        with self.assertRaises(ScoreOutOfRangeException):
            self.service._level_for(101)
        with self.assertRaises(ScoreOutOfRangeException):
            self.service._level_for(-1)

    def test_score_attempt_reverse_flag_flips_value(self):
        self._add_question('extraversion', True, 1)  # adjusted = 6 - 1 = 5
        for _ in range(5):
            self._add_question('extraversion', False, 5)
        # factor_sum = 5 + 5*5 = 30 -> 100 -> high
        self._fill_remaining_dimensions_neutrally(skip_dimension='extraversion')

        dimension_scores = self.service.score_attempt(self.attempt)

        extraversion = next(item for item in dimension_scores if item['key'] == 'extraversion')
        self.assertEqual(extraversion['score_percent'], 100)


class ReportServiceGenerateForAttemptDispatchTests(TestCase):
    """generate_for_attempt() is a pure dispatcher for initial attempts now: it scores, writes a
    GENERATING row and queues report.generate_initial_report -- it never calls the AI itself.
    See ReportServiceGenerateInitialTests below for the worker-side AI-calling logic."""

    def setUp(self):
        self.report_repository = MagicMock()
        self.scoring_service = MagicMock()
        self.service = ReportService(
            report_repository=self.report_repository,
            scoring_service=self.scoring_service,
        )
        self.assessment = Assessment.objects.create(slug='big-five-test', title='Test', kind=Assessment.Kind.INITIAL)
        self.attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-1')

    def test_returns_existing_report_without_dispatching(self):
        existing = MagicMock()
        self.report_repository.get_by_attempt_id.return_value = existing

        result = self.service.generate_for_attempt(self.attempt)

        self.assertIs(result, existing)
        self.report_repository.create_generating_initial.assert_not_called()

    def test_returns_none_when_not_complete(self):
        self.report_repository.get_by_attempt_id.return_value = None
        self.scoring_service.is_complete.return_value = False

        result = self.service.generate_for_attempt(self.attempt)

        self.assertIsNone(result)
        self.report_repository.create_generating_initial.assert_not_called()

    def test_creates_generating_row_and_queues_the_task(self):
        self.report_repository.get_by_attempt_id.return_value = None
        self.scoring_service.is_complete.return_value = True
        dimension_scores = [{'key': 'openness', 'score_percent': 50, 'level': 'medium'}]
        self.scoring_service.score_attempt.return_value = dimension_scores
        generating_report = MagicMock()
        self.report_repository.create_generating_initial.return_value = generating_report

        with patch('apps.report.tasks.generate_initial_report.delay') as delay:
            with self.captureOnCommitCallbacks(execute=True):
                result = self.service.generate_for_attempt(self.attempt)

        self.assertIs(result, generating_report)
        self.report_repository.create_generating_initial.assert_called_once_with(
            attempt=self.attempt, dimension_scores=dimension_scores,
        )
        delay.assert_called_once_with(self.attempt.id)

    def test_generating_state_is_reported_to_the_client(self):
        self.report_repository.get_by_attempt_id.return_value = None
        self.scoring_service.is_complete.return_value = True
        self.scoring_service.score_attempt.return_value = []
        generating_report = MagicMock()
        generating_report.attempt = self.attempt
        generating_report.status = Report.Status.GENERATING
        generating_report.report_type = Report.ReportType.INITIAL
        generating_report.report_version = ''
        self.report_repository.create_generating_initial.return_value = generating_report

        with patch('apps.report.tasks.generate_initial_report.delay'):
            with self.captureOnCommitCallbacks(execute=True):
                self.service.generate_for_attempt(self.attempt)

        self.report_repository.get_by_attempt_id.return_value = generating_report
        data = self.service.get_report(attempt_id=self.attempt.id, user=None, anonymous_id='anon-1')

        self.assertEqual(data['status'], 'generating')
        self.assertEqual(data['report_type'], Report.ReportType.INITIAL)


class ReportServiceRetryGenerationTests(TestCase):
    def setUp(self):
        self.report_repository = MagicMock()
        self.service = ReportService(report_repository=self.report_repository)
        self.assessment = Assessment.objects.create(slug='big-five-test', title='Test', kind=Assessment.Kind.INITIAL)

    def test_raises_when_report_not_found(self):
        self.report_repository.get_by_attempt_id.return_value = None

        with self.assertRaises(ReportNotFoundException):
            self.service.retry_generation(attempt_id=1, user=None, anonymous_id='anon-1')

    def test_raises_when_requester_does_not_own_attempt(self):
        attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='someone-else')
        report = MagicMock(attempt=attempt, status=Report.Status.ERROR)
        self.report_repository.get_by_attempt_id.return_value = report

        with self.assertRaises(ReportAccessDeniedException):
            self.service.retry_generation(attempt_id=attempt.id, user=None, anonymous_id='anon-1')

    def test_raises_when_report_is_not_in_error_status(self):
        attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-1')
        report = MagicMock(attempt=attempt, status=Report.Status.GENERATING)
        self.report_repository.get_by_attempt_id.return_value = report

        with self.assertRaises(ReportRetryNotAllowedException):
            self.service.retry_generation(attempt_id=attempt.id, user=None, anonymous_id='anon-1')
        self.report_repository.retry.assert_not_called()

    def test_re_dispatches_initial_generation_and_returns_generating_shape(self):
        attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-1')
        report = MagicMock(
            id=9, attempt=attempt, attempt_id=attempt.id, status=Report.Status.ERROR,
            report_type=Report.ReportType.INITIAL, report_version='',
        )
        self.report_repository.get_by_attempt_id.return_value = report
        retried_report = MagicMock(
            attempt=attempt, attempt_id=attempt.id, status=Report.Status.GENERATING,
            report_type=Report.ReportType.INITIAL, report_version='',
        )
        self.report_repository.retry.return_value = retried_report

        with patch('apps.report.tasks.generate_initial_report.delay') as delay:
            with self.captureOnCommitCallbacks(execute=True):
                result = self.service.retry_generation(attempt_id=attempt.id, user=None, anonymous_id='anon-1')

        self.report_repository.retry.assert_called_once_with(report)
        delay.assert_called_once_with(attempt.id)
        self.assertEqual(result, {
            'status': 'generating', 'report_type': Report.ReportType.INITIAL, 'report_version': '',
        })

    def test_re_dispatches_deep_generation_for_a_deep_report(self):
        attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-2')
        report = MagicMock(
            id=10, attempt=attempt, attempt_id=attempt.id, status=Report.Status.ERROR,
            report_type=Report.ReportType.DEEP,
        )
        self.report_repository.get_by_attempt_id.return_value = report
        retried_report = MagicMock(
            attempt=attempt, attempt_id=attempt.id, status=Report.Status.GENERATING,
            report_type=Report.ReportType.DEEP, report_version='deep_v1',
        )
        self.report_repository.retry.return_value = retried_report

        with patch('apps.report.tasks.generate_deep_report.delay') as delay:
            with self.captureOnCommitCallbacks(execute=True):
                self.service.retry_generation(attempt_id=attempt.id, user=None, anonymous_id='anon-2')

        delay.assert_called_once_with(attempt.id)


class ReportServiceGenerateInitialTests(TestCase):
    """The worker-side AI-calling logic (generate_initial/_generate_initial), invoked by the
    report.generate_initial_report Celery task -- never by the request. Mirrors the assertions
    the old synchronous ReportServiceGenerateForAttemptTests made, just retargeted at the async
    entrypoint."""

    def setUp(self):
        self.report_repository = MagicMock()
        self.memory_repository = MagicMock()
        self.ai_client = MagicMock()
        self.demographics_service = MagicMock()
        self.generation_log_repository = MagicMock()
        self.demographics_service.get.return_value = {
            'birth_year': None, 'gender': None, 'life_situation': None, 'goal': None, 'answered': False,
        }
        self.service = ReportService(
            report_repository=self.report_repository,
            memory_repository=self.memory_repository,
            ai_client=self.ai_client,
            demographics_service=self.demographics_service,
            generation_log_repository=self.generation_log_repository,
        )
        self.assessment = Assessment.objects.create(slug='big-five-test', title='Test', kind=Assessment.Kind.INITIAL)
        self.attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-1')
        self.report = MagicMock()
        self.report.attempt = self.attempt
        self.report.dimension_scores = [{'key': 'openness', 'score_percent': 50, 'level': 'medium'}]
        self.report_repository.claim_for_generation.return_value = self.report

    def test_returns_existing_report_when_nothing_claimable(self):
        self.report_repository.claim_for_generation.return_value = None
        existing = MagicMock()
        self.report_repository.get_by_attempt_id.return_value = existing

        result = self.service.generate_initial(self.attempt.id)

        self.assertIs(result, existing)
        self.ai_client.generate.assert_not_called()

    def test_generate_includes_demographics_in_ai_payload(self):
        self.demographics_service.get.return_value = {
            'birth_year': 1370, 'gender': 'male', 'life_situation': 'employed', 'goal': 'stress', 'answered': True,
        }
        self.ai_client.generate.return_value = {
            'status': 'error',
            'report_version': 'report_v1',
            'error': {'code': 'generation_failed', 'user_message': 'failed'},
        }

        self.service.generate_initial(self.attempt.id)

        self.demographics_service.get.assert_called_once_with(user=self.attempt.user, anonymous_id='anon-1')
        payload = self.ai_client.generate.call_args.args[0]
        self.assertEqual(
            payload['demographics'],
            {'birth_year': 1370, 'gender': 'male', 'life_situation': 'employed', 'goal': 'stress'},
        )

    def test_stores_error_report_on_ai_error(self):
        self.ai_client.generate.return_value = {
            'status': 'error',
            'report_version': 'report_v1',
            'error': {'code': 'generation_failed', 'user_message': 'failed'},
        }
        error_report = MagicMock()
        self.report_repository.mark_error.return_value = error_report

        result = self.service.generate_initial(self.attempt.id)

        self.assertIs(result, error_report)
        self.report_repository.mark_error.assert_called_once_with(
            self.report, error_code='generation_failed', error_message='failed',
        )

    def test_logs_generation_meta_on_ai_error(self):
        # report_spec_v1.4 §4.2: attempts that reached the model still cost money even when
        # generation ultimately fails, so generation_meta must still be logged.
        self.ai_client.generate.return_value = {
            'status': 'error',
            'report_version': 'report_v1',
            'error': {'code': 'generation_failed', 'user_message': 'failed'},
            'generation_meta': {
                'model_used': None, 'attempts': 3, 'input_tokens': 300, 'output_tokens': 150, 'latency_s': 9.5,
            },
        }

        self.service.generate_initial(self.attempt.id)

        self.generation_log_repository.create.assert_called_once_with(
            attempt=self.attempt, user=None, model_used=None, attempts=3,
            input_tokens=300, cached_input_tokens=0, output_tokens=150, latency_s=9.5, cost=None,
        )

    def test_logs_generation_meta_on_success_with_computed_cost(self):
        ModelPricing.objects.create(
            model_name='gpt-5.4', input_price_per_million=Decimal('2.00'), output_price_per_million=Decimal('8.00'),
        )
        self.ai_client.generate.return_value = {
            'status': 'ok', 'report_version': 'report_v1', 'report': {}, 'system': {}, 'memory_candidates': [],
            'generation_meta': {
                'model_used': 'gpt-5.4', 'attempts': 1,
                'input_tokens': 500_000, 'output_tokens': 250_000, 'latency_s': 3.2,
            },
        }
        ok_report = MagicMock()
        ok_report.attempt = self.attempt
        ok_report.memory_candidates = []
        self.report_repository.mark_ok.return_value = ok_report

        self.service.generate_initial(self.attempt.id)

        self.generation_log_repository.create.assert_called_once_with(
            attempt=self.attempt, user=None, model_used='gpt-5.4', attempts=1,
            input_tokens=500_000, cached_input_tokens=0, output_tokens=250_000, latency_s=3.2,
            cost=Decimal('3.00'),
        )

    def test_skips_logging_when_generation_meta_absent(self):
        self.ai_client.generate.return_value = {
            'status': 'error', 'report_version': 'report_v1',
            'error': {'code': 'generation_failed', 'user_message': 'failed'},
        }

        self.service.generate_initial(self.attempt.id)

        self.generation_log_repository.create.assert_not_called()

    def test_stores_ok_report_and_persists_memories_when_attempt_has_user(self):
        user = User.objects.create(phone_number='09120000000')
        self.attempt.user = user
        self.attempt.save(update_fields=['user'])

        candidate = {
            'memory_type': 'core_pattern', 'text_memory': 'text', 'source': 'initial_report',
            'confidence': 'high', 'sensitivity_level': 'low', 'should_store': True,
        }
        self.ai_client.generate.return_value = {
            'status': 'ok', 'report_version': 'report_v1',
            'report': {'summary': {'one_line': 'x'}}, 'system': {'pattern_tags': []},
            'memory_candidates': [candidate],
        }
        ok_report = MagicMock()
        ok_report.attempt = self.attempt
        ok_report.memory_candidates = [candidate]
        self.report_repository.mark_ok.return_value = ok_report

        result = self.service.generate_initial(self.attempt.id)

        self.assertIs(result, ok_report)
        self.report_repository.mark_ok.assert_called_once_with(
            self.report, report_version='report_v1',
            report_data={'summary': {'one_line': 'x'}}, system_data={'pattern_tags': []},
            memory_candidates=[candidate],
        )
        self.memory_repository.upsert.assert_called_once_with(
            user=user, memory_type='core_pattern', text_memory='text', source='initial_report',
            confidence='high', sensitivity_level='low',
        )
        self.report_repository.mark_memories_persisted.assert_called_once_with(ok_report)

    def test_skips_memory_persistence_when_attempt_is_anonymous(self):
        self.ai_client.generate.return_value = {
            'status': 'ok', 'report_version': 'report_v1', 'report': {}, 'system': {},
            'memory_candidates': [{'memory_type': 'core_pattern', 'should_store': True}],
        }
        ok_report = MagicMock()
        ok_report.attempt = self.attempt  # attempt.user is None
        ok_report.memory_candidates = [{'memory_type': 'core_pattern', 'should_store': True}]
        self.report_repository.mark_ok.return_value = ok_report

        self.service.generate_initial(self.attempt.id)

        self.memory_repository.upsert.assert_not_called()
        self.report_repository.mark_memories_persisted.assert_not_called()


class ReportGenerationMetricsTests(TestCase):
    """faraman_report_generation_* -- the @observe decorator on ReportService.generate_initial
    and DeepReportService.generate. Metric objects are process-global, so assert on deltas."""

    def _count(self, report_type, outcome):
        return read_metric(
            "faraman_report_generation_duration_seconds_count",
            report_type=report_type, outcome=outcome,
        ) or 0.0

    def _in_progress(self, report_type):
        return read_metric("faraman_report_generation_in_progress", report_type=report_type) or 0.0

    def _initial_service(self):
        repo = MagicMock()
        demo = MagicMock()
        demo.get.return_value = {
            'birth_year': None, 'gender': None, 'life_situation': None, 'goal': None, 'answered': False,
        }
        svc = ReportService(
            report_repository=repo, memory_repository=MagicMock(), ai_client=MagicMock(),
            demographics_service=demo, generation_log_repository=MagicMock(),
        )
        report = MagicMock()
        report.attempt = self.attempt
        report.dimension_scores = [{'key': 'openness', 'score_percent': 50, 'level': 'medium'}]
        repo.claim_for_generation.return_value = report
        return svc, repo, report

    def setUp(self):
        self.assessment = Assessment.objects.create(slug='m', title='m', kind=Assessment.Kind.INITIAL)
        self.attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-m')

    def test_initial_ok_outcome(self):
        svc, repo, _ = self._initial_service()
        svc.ai_client.generate.return_value = {
            'status': 'ok', 'report_version': 'v1', 'report': {}, 'system': {}, 'memory_candidates': [],
        }
        ok = MagicMock(status=Report.Status.OK, memory_candidates=[])
        ok.attempt = self.attempt
        repo.mark_ok.return_value = ok

        before = self._count('initial', 'ok')
        base_gauge = self._in_progress('initial')
        svc.generate_initial(self.attempt.id)

        self.assertEqual(self._count('initial', 'ok') - before, 1.0)
        self.assertEqual(self._in_progress('initial'), base_gauge)

    def test_initial_error_outcome(self):
        svc, repo, _ = self._initial_service()
        svc.ai_client.generate.side_effect = RuntimeError('boom')
        repo.mark_error.return_value = MagicMock(status=Report.Status.ERROR)

        before = self._count('initial', 'error')
        svc.generate_initial(self.attempt.id)

        self.assertEqual(self._count('initial', 'error') - before, 1.0)

    def test_initial_noop_outcome_when_nothing_claimable(self):
        svc, repo, _ = self._initial_service()
        repo.claim_for_generation.return_value = None
        repo.get_by_attempt_id.return_value = None

        before = self._count('initial', 'noop')
        svc.generate_initial(self.attempt.id)

        self.assertEqual(self._count('initial', 'noop') - before, 1.0)

    @patch('apps.report.services.deep_report_service.build_memory_candidates', return_value=[])
    def test_deep_ok_outcome(self, _bmc):
        repo = MagicMock()
        demo = MagicMock()
        demo.get.return_value = {'answered': False}
        svc = DeepReportService(
            report_repository=repo, memory_repository=MagicMock(), ai_client=MagicMock(),
            deep_scoring_service=MagicMock(), demographics_service=demo,
            generation_log_repository=MagicMock(),
        )
        claimed = MagicMock()
        claimed.attempt = self.attempt
        repo.claim_for_generation.return_value = claimed
        svc.ai_client.generate.return_value = {
            'status': 'ok', 'report_version': 'deep_v1', 'report': {}, 'system': {},
        }
        ok = MagicMock(status=Report.Status.OK, memory_candidates=[])
        ok.attempt = self.attempt
        repo.mark_ok.return_value = ok

        before = self._count('deep', 'ok')
        svc.generate(self.attempt.id)

        self.assertEqual(self._count('deep', 'ok') - before, 1.0)

    def test_deep_error_outcome(self):
        repo = MagicMock()
        svc = DeepReportService(
            report_repository=repo, memory_repository=MagicMock(), ai_client=MagicMock(),
            deep_scoring_service=MagicMock(), demographics_service=MagicMock(),
            generation_log_repository=MagicMock(),
        )
        claimed = MagicMock()
        claimed.attempt = self.attempt
        repo.claim_for_generation.return_value = claimed
        svc.ai_client.generate.side_effect = RuntimeError('provider down')
        repo.mark_error.return_value = MagicMock(status=Report.Status.ERROR)

        before = self._count('deep', 'error')
        svc.generate(self.attempt.id)

        self.assertEqual(self._count('deep', 'error') - before, 1.0)


class ReportServicePersistPendingMemoriesTests(TestCase):
    def setUp(self):
        self.report_repository = MagicMock()
        self.memory_repository = MagicMock()
        self.service = ReportService(report_repository=self.report_repository, memory_repository=self.memory_repository)

    def test_persists_each_unpersisted_report_for_user(self):
        user = MagicMock()
        report_1, report_2 = MagicMock(memory_candidates=[]), MagicMock(memory_candidates=[])
        report_1.attempt.user = user
        report_2.attempt.user = user
        self.report_repository.get_unpersisted_for_user.return_value = [report_1, report_2]

        self.service.persist_pending_memories_for_user(user)

        self.report_repository.mark_memories_persisted.assert_any_call(report_1)
        self.report_repository.mark_memories_persisted.assert_any_call(report_2)


class ReportServiceGetReportTests(TestCase):
    def setUp(self):
        self.report_repository = MagicMock()
        self.service = ReportService(report_repository=self.report_repository)
        self.assessment = Assessment.objects.create(slug='big-five-test', title='Test', kind=Assessment.Kind.INITIAL)

    def test_raises_when_report_not_found(self):
        self.report_repository.get_by_attempt_id.return_value = None

        with self.assertRaises(ReportNotFoundException):
            self.service.get_report(attempt_id=1, user=None, anonymous_id='anon-1')

    def test_raises_when_requester_does_not_own_attempt(self):
        attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='someone-else')
        report = MagicMock(attempt=attempt)
        self.report_repository.get_by_attempt_id.return_value = report

        with self.assertRaises(ReportAccessDeniedException):
            self.service.get_report(attempt_id=attempt.id, user=None, anonymous_id='anon-1')

    def test_returns_error_shape_when_report_failed(self):
        attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-1')
        report = MagicMock(
            attempt=attempt, status=Report.Status.ERROR, report_version='report_v1',
            error_code='generation_failed', error_message='failed',
        )
        self.report_repository.get_by_attempt_id.return_value = report

        result = self.service.get_report(attempt_id=attempt.id, user=None, anonymous_id='anon-1')

        self.assertEqual(result['status'], 'error')
        self.assertEqual(result['error']['code'], 'generation_failed')
        self.assertFalse(result['error']['should_display_report'])

    def test_returns_preview_stage_for_anonymous_requester(self):
        attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-1')
        report_data = {
            'summary': {'one_line': 'summary'},
            'core_narrative': {'body': 'first paragraph\n\nsecond paragraph\n\nthird paragraph'},
            'key_strengths': [
                {'title': 'first strength', 'description': 'first strength description'},
                {'title': '2', 'description': 'desc 2'},
                {'title': '3', 'description': 'desc 3'},
            ],
            'growth_edges': [{}, {}],
            'growth_path': {'recommendations': [{}, {}, {}]},
            'preview': {'teaser_line': 'teaser'},
        }
        report = MagicMock(
            attempt=attempt, status=Report.Status.OK, report_version='report_v1', report_data=report_data,
            dimension_scores=[
                {'key': 'openness', 'score_percent': 90, 'level': 'high'},
                {'key': 'extraversion', 'score_percent': 40, 'level': 'medium'},
            ],
        )
        self.report_repository.get_by_attempt_id.return_value = report

        result = self.service.get_report(attempt_id=attempt.id, user=None, anonymous_id='anon-1')

        self.assertEqual(result['stage'], 'preview')
        self.assertEqual(result['preview']['summary_one_line'], 'summary')
        self.assertEqual(result['preview']['personality_pattern_first_paragraph'], 'first paragraph')
        self.assertEqual(
            result['preview']['first_strength'],
            {'title': 'first strength', 'description': 'first strength description'},
        )
        self.assertEqual(result['preview']['locked_counts'], {'strengths': 3, 'growth_edges': 2, 'recommendations': 3})
        # sorted descending by score_percent, no score_percent leaked
        self.assertEqual(
            result['preview']['dimension_scores'],
            [{'key': 'openness', 'level': 'high'}, {'key': 'extraversion', 'level': 'medium'}],
        )

    def test_returns_full_stage_for_authenticated_requester(self):
        user = User.objects.create(phone_number='09120000001')
        attempt = Attempt.objects.create(assessment=self.assessment, user=user)
        report = MagicMock(
            id=42, attempt=attempt, status=Report.Status.OK, report_version='report_v1',
            report_data={'summary': {'one_line': 'summary'}},
            dimension_scores=[{'key': 'openness', 'score_percent': 90, 'level': 'high'}],
        )
        self.report_repository.get_by_attempt_id.return_value = report

        result = self.service.get_report(attempt_id=attempt.id, user=user, anonymous_id=None)

        self.assertEqual(result['stage'], 'full')
        self.assertEqual(result['report_id'], 42)
        self.assertEqual(result['report'], {'summary': {'one_line': 'summary'}})
        self.assertEqual(result['dimension_scores'], [{'key': 'openness', 'score_percent': 90, 'level': 'high'}])

    def test_share_passes_through_unchanged_in_full_stage(self):
        # report_spec_v1.5 §4.1/§4.4: `share` is stored and returned verbatim to logged-in
        # requesters, with no backend transformation.
        user = User.objects.create(phone_number='09120000002')
        attempt = Attempt.objects.create(assessment=self.assessment, user=user)
        share = {'hook': 'قبل از تصمیم، همه‌چیز را می‌سنجم', 'line': 'همین دقت باعث می‌شود کمتر پشیمان شوم.'}
        report = MagicMock(
            id=43, attempt=attempt, status=Report.Status.OK, report_version='report_v1',
            report_data={'summary': {'one_line': 'summary'}, 'share': share},
            dimension_scores=[{'key': 'openness', 'score_percent': 90, 'level': 'high'}],
        )
        self.report_repository.get_by_attempt_id.return_value = report

        result = self.service.get_report(attempt_id=attempt.id, user=user, anonymous_id=None)

        self.assertEqual(result['report']['share'], share)

    def test_share_never_appears_in_preview_stage(self):
        # report_spec_v1.5 §4.5/§5.4: `share` is a post-login sharing artifact, never part
        # of the pre-login teaser.
        attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-2')
        report_data = {
            'summary': {'one_line': 'summary'},
            'core_narrative': {'body': 'first paragraph\n\nsecond paragraph\n\nthird paragraph'},
            'key_strengths': [
                {'title': 'first strength', 'description': 'first strength description'},
                {'title': '2', 'description': 'desc 2'},
                {'title': '3', 'description': 'desc 3'},
            ],
            'growth_edges': [{}, {}],
            'growth_path': {'recommendations': [{}, {}, {}]},
            'preview': {'teaser_line': 'teaser'},
            'share': {'hook': 'hook text', 'line': 'line text'},
        }
        report = MagicMock(
            attempt=attempt, status=Report.Status.OK, report_version='report_v1', report_data=report_data,
            dimension_scores=[{'key': 'openness', 'score_percent': 90, 'level': 'high'}],
        )
        self.report_repository.get_by_attempt_id.return_value = report

        result = self.service.get_report(attempt_id=attempt.id, user=None, anonymous_id='anon-2')

        self.assertNotIn('share', result['preview'])
        self.assertNotIn('share', result)


class ReportServiceAcceptStepTests(TestCase):
    def setUp(self):
        self.report_repository = MagicMock()
        self.action_step_service = MagicMock()
        self.service = ReportService(
            report_repository=self.report_repository, action_step_service=self.action_step_service,
        )
        self.assessment = Assessment.objects.create(slug='big-five-test-2', title='Test', kind=Assessment.Kind.INITIAL)
        self.user = User.objects.create(phone_number='09120000010')

    def test_raises_when_report_not_found(self):
        self.report_repository.get_by_attempt_id.return_value = None

        with self.assertRaises(ReportNotFoundException):
            self.service.accept_step(attempt_id=1, index=1, user=self.user)

    def test_raises_when_requester_does_not_own_attempt(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=User.objects.create(phone_number='09120000011'))
        report = MagicMock(attempt=attempt)
        self.report_repository.get_by_attempt_id.return_value = report

        with self.assertRaises(ReportAccessDeniedException):
            self.service.accept_step(attempt_id=attempt.id, index=1, user=self.user)
        self.action_step_service.create_step.assert_not_called()

    def test_raises_when_report_not_ok(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        report = MagicMock(attempt=attempt, status=Report.Status.GENERATING)
        self.report_repository.get_by_attempt_id.return_value = report

        with self.assertRaises(ReportNotReadyException):
            self.service.accept_step(attempt_id=attempt.id, index=1, user=self.user)
        self.action_step_service.create_step.assert_not_called()

    def test_raises_when_index_out_of_range(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        report = MagicMock(
            attempt=attempt, status=Report.Status.OK, report_type=Report.ReportType.INITIAL,
            report_data={'growth_path': {'recommendations': [{'suggested_step': {}}]}},
        )
        self.report_repository.get_by_attempt_id.return_value = report

        with self.assertRaises(SuggestedStepNotFoundException):
            self.service.accept_step(attempt_id=attempt.id, index=3, user=self.user)
        self.action_step_service.create_step.assert_not_called()

    def test_creates_action_step_from_initial_report_recommendation(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        report = MagicMock(
            attempt=attempt, status=Report.Status.OK, report_type=Report.ReportType.INITIAL,
            report_data={
                'growth_path': {
                    'recommendations': [
                        {'suggested_step': {
                            'text': 'first', 'deadline_text': 'امشب', 'deadline_type': 'tonight', 'substeps': None,
                        }},
                        {'suggested_step': {
                            'text': 'second', 'deadline_text': 'فردا صبح',
                            'deadline_type': 'tomorrow_morning', 'substeps': None,
                        }},
                    ],
                },
            },
        )
        self.report_repository.get_by_attempt_id.return_value = report

        self.service.accept_step(attempt_id=attempt.id, index=2, user=self.user)

        self.action_step_service.create_step.assert_called_once_with(
            user=self.user, source="initial_report:rec_2", step_text="second",
            deadline_type="tomorrow_morning", substeps=None,
        )

    def test_creates_action_step_from_deep_report_small_action(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        report = MagicMock(
            attempt=attempt, status=Report.Status.OK, report_type=Report.ReportType.DEEP,
            report_data={
                'closing': {
                    'small_actions': [
                        {'text': 'first', 'deadline_text': 'امشب', 'deadline_type': 'tonight', 'substeps': None},
                    ],
                },
            },
        )
        self.report_repository.get_by_attempt_id.return_value = report

        self.service.accept_step(attempt_id=attempt.id, index=1, user=self.user)

        self.action_step_service.create_step.assert_called_once_with(
            user=self.user, source="deep_report:action_1", step_text="first",
            deadline_type="tonight", substeps=None,
        )


class ReportServiceEmailReportTests(TestCase):
    """email_report: ownership/readiness (shared via _get_owned_ready_report), throttling,
    then a real render_to_string against the actual pdf/notice templates -- report_data
    fixtures here are real, schema-valid examples (not sparse MagicMock stubs) precisely so a
    broken template/context mismatch surfaces as a test failure, not just in prod. pdf_service
    is mocked (no real WeasyPrint render here -- that's covered by test_pdf_service.py)."""

    def setUp(self):
        self.report_repository = MagicMock()
        self.email_service = MagicMock()
        self.pdf_service = MagicMock()
        self.pdf_service.font_context.return_value = {}
        self.pdf_service.image_context.return_value = {'images': {}}
        self.pdf_service.render_pdf.return_value = b"%PDF-FAKE%"
        self.report_email_throttle_repository = MagicMock()
        self.report_email_throttle_repository.hit.return_value = False
        self.report_email_delivery_repository = MagicMock()
        self.service = ReportService(
            report_repository=self.report_repository, email_service=self.email_service,
            pdf_service=self.pdf_service,
            report_email_throttle_repository=self.report_email_throttle_repository,
            report_email_delivery_repository=self.report_email_delivery_repository,
        )
        self.assessment = Assessment.objects.create(slug='big-five-test-3', title='Test', kind=Assessment.Kind.INITIAL)
        self.user = User.objects.create(phone_number='09120000020')

    def test_raises_when_report_not_found(self):
        self.report_repository.get_by_attempt_id.return_value = None

        with self.assertRaises(ReportNotFoundException):
            self.service.email_report(attempt_id=1, user=self.user, email='a@b.com')
        self.email_service.send_html.assert_not_called()

    def test_raises_when_requester_does_not_own_attempt(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=User.objects.create(phone_number='09120000021'))
        report = MagicMock(attempt=attempt)
        self.report_repository.get_by_attempt_id.return_value = report

        with self.assertRaises(ReportAccessDeniedException):
            self.service.email_report(attempt_id=attempt.id, user=self.user, email='a@b.com')
        self.email_service.send_html.assert_not_called()

    def test_raises_when_report_not_ok(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        report = MagicMock(attempt=attempt, status=Report.Status.GENERATING)
        self.report_repository.get_by_attempt_id.return_value = report

        with self.assertRaises(ReportNotReadyException):
            self.service.email_report(attempt_id=attempt.id, user=self.user, email='a@b.com')
        self.email_service.send_html.assert_not_called()

    def test_raises_when_throttled(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        report = MagicMock(attempt=attempt, status=Report.Status.OK)
        self.report_repository.get_by_attempt_id.return_value = report
        self.report_email_throttle_repository.hit.return_value = True

        with self.assertRaises(ReportEmailThrottledException):
            self.service.email_report(attempt_id=attempt.id, user=self.user, email='a@b.com')
        self.email_service.send_html.assert_not_called()

    def test_raises_when_send_fails(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        report_data = json.loads(_fewshot_model_output(1))['report']
        report = MagicMock(
            attempt=attempt, status=Report.Status.OK, report_type=Report.ReportType.INITIAL,
            report_data=report_data, dimension_scores=_DIMENSION_SCORES,
        )
        self.report_repository.get_by_attempt_id.return_value = report
        self.email_service.send_html.return_value = False

        with self.assertRaises(ReportEmailDeliveryFailedException):
            self.service.email_report(attempt_id=attempt.id, user=self.user, email='a@b.com')
        self.report_email_delivery_repository.create.assert_called_once_with(
            user=self.user, attempt=attempt, report_type=Report.ReportType.INITIAL,
            email='a@b.com', sent=False,
        )

    def test_raises_when_pdf_generation_fails(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        report_data = json.loads(_fewshot_model_output(1))['report']
        report = MagicMock(
            attempt=attempt, status=Report.Status.OK, report_type=Report.ReportType.INITIAL,
            report_data=report_data, dimension_scores=_DIMENSION_SCORES,
        )
        self.report_repository.get_by_attempt_id.return_value = report
        self.pdf_service.render_pdf.side_effect = ReportPdfGenerationFailedException()

        with self.assertRaises(ReportPdfGenerationFailedException):
            self.service.email_report(attempt_id=attempt.id, user=self.user, email='a@b.com')
        self.email_service.send_html.assert_not_called()

    def test_sends_initial_report_email(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        report_data = json.loads(_fewshot_model_output(1))['report']
        report = MagicMock(
            attempt=attempt, status=Report.Status.OK, report_type=Report.ReportType.INITIAL,
            report_data=report_data, dimension_scores=_DIMENSION_SCORES,
        )
        self.report_repository.get_by_attempt_id.return_value = report
        self.email_service.send_html.return_value = True

        self.service.email_report(attempt_id=attempt.id, user=self.user, email='reader@example.com')

        self.pdf_service.render_pdf.assert_called_once()
        pdf_html = self.pdf_service.render_pdf.call_args[0][0]
        self.assertIn(report_data['summary']['one_line'], pdf_html)

        self.email_service.send_html.assert_called_once()
        to_email, subject, notice_html = self.email_service.send_html.call_args[0]
        self.assertEqual(to_email, 'reader@example.com')
        self.assertIn(report_data['summary']['one_line'], notice_html)
        self.report_email_delivery_repository.create.assert_called_once_with(
            user=self.user, attempt=attempt, report_type=Report.ReportType.INITIAL,
            email='reader@example.com', sent=True,
        )
        self.assertTrue(subject)
        self.assertEqual(
            self.email_service.send_html.call_args.kwargs,
            {'pdf_attachment': b"%PDF-FAKE%", 'pdf_filename': f"faraman-report-{attempt.id}.pdf"},
        )

    def test_sends_deep_report_email(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        deep_mock = json.loads(MOCK_PATH.read_text(encoding='utf-8'))['report']
        facet_scores = [{'code': code, 'domain': code[0], 'level': 'mid'} for code in FACET_CODES]
        domain_scores = [{'code': code, 'level': 'mid'} for code in DOMAIN_ORDER]
        report = MagicMock(
            attempt=attempt, status=Report.Status.OK, report_type=Report.ReportType.DEEP,
            report_data=deep_mock, facet_scores=facet_scores, domain_scores=domain_scores,
        )
        self.report_repository.get_by_attempt_id.return_value = report
        self.email_service.send_html.return_value = True

        self.service.email_report(attempt_id=attempt.id, user=self.user, email='reader@example.com')

        self.pdf_service.render_pdf.assert_called_once()
        pdf_html = self.pdf_service.render_pdf.call_args[0][0]
        self.assertIn(deep_mock['identity_line'], pdf_html)

        self.email_service.send_html.assert_called_once()
        to_email, subject, notice_html = self.email_service.send_html.call_args[0]
        self.assertEqual(to_email, 'reader@example.com')
        self.assertIn(deep_mock['identity_line'], notice_html)
        self.assertTrue(subject)
        self.assertEqual(
            self.email_service.send_html.call_args.kwargs,
            {'pdf_attachment': b"%PDF-FAKE%", 'pdf_filename': f"faraman-report-{attempt.id}.pdf"},
        )


class ReportServiceGetSuggestedStepTests(TestCase):
    """Read-only counterpart to accept_step -- same ownership/readiness checks (shared via
    _get_owned_ready_report), but never touches action_step_service."""

    def setUp(self):
        self.report_repository = MagicMock()
        self.action_step_service = MagicMock()
        self.service = ReportService(
            report_repository=self.report_repository, action_step_service=self.action_step_service,
        )
        self.assessment = Assessment.objects.create(slug='big-five-test-3', title='Test', kind=Assessment.Kind.INITIAL)
        self.user = User.objects.create(phone_number='09120000012')

    def test_raises_when_report_not_found(self):
        self.report_repository.get_by_attempt_id.return_value = None

        with self.assertRaises(ReportNotFoundException):
            self.service.get_suggested_step(attempt_id=1, index=1, user=self.user)

    def test_raises_when_requester_does_not_own_attempt(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=User.objects.create(phone_number='09120000013'))
        report = MagicMock(attempt=attempt)
        self.report_repository.get_by_attempt_id.return_value = report

        with self.assertRaises(ReportAccessDeniedException):
            self.service.get_suggested_step(attempt_id=attempt.id, index=1, user=self.user)

    def test_raises_when_report_not_ok(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        report = MagicMock(attempt=attempt, status=Report.Status.GENERATING)
        self.report_repository.get_by_attempt_id.return_value = report

        with self.assertRaises(ReportNotReadyException):
            self.service.get_suggested_step(attempt_id=attempt.id, index=1, user=self.user)

    def test_raises_when_index_out_of_range(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        report = MagicMock(
            attempt=attempt, status=Report.Status.OK, report_type=Report.ReportType.INITIAL,
            report_data={'growth_path': {'recommendations': [{'suggested_step': {}}]}},
        )
        self.report_repository.get_by_attempt_id.return_value = report

        with self.assertRaises(SuggestedStepNotFoundException):
            self.service.get_suggested_step(attempt_id=attempt.id, index=3, user=self.user)

    def test_returns_suggested_step_without_creating_anything(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        report = MagicMock(
            attempt=attempt, status=Report.Status.OK, report_type=Report.ReportType.INITIAL,
            report_data={
                'growth_path': {
                    'recommendations': [
                        {'suggested_step': {
                            'text': 'first', 'deadline_text': 'امشب', 'deadline_type': 'tonight', 'substeps': None,
                        }},
                    ],
                },
            },
        )
        self.report_repository.get_by_attempt_id.return_value = report

        result = self.service.get_suggested_step(attempt_id=attempt.id, index=1, user=self.user)

        self.assertEqual(result, {
            'text': 'first', 'deadline_text': 'امشب', 'deadline_type': 'tonight', 'substeps': None,
        })
        self.action_step_service.create_step.assert_not_called()


class ReportV2ServiceTests(TestCase):
    """report_v2 (report_spec_v2_0) through ReportService: preview gate, history line, suggested
    step, accept, and the emailed PDF. The v1 equivalents above stay as they were."""

    def setUp(self):
        self.report_repository = MagicMock()
        self.action_step_service = MagicMock()
        self.email_service = MagicMock()
        self.pdf_service = MagicMock()
        self.pdf_service.font_context.return_value = {}
        self.pdf_service.image_context.return_value = {'images': {}}
        self.pdf_service.render_pdf.return_value = b"%PDF-FAKE%"
        self.throttle = MagicMock()
        self.throttle.hit.return_value = False
        self.service = ReportService(
            report_repository=self.report_repository, action_step_service=self.action_step_service,
            email_service=self.email_service, pdf_service=self.pdf_service,
            report_email_throttle_repository=self.throttle,
            report_email_delivery_repository=MagicMock(),
        )
        self.assessment = Assessment.objects.create(slug='big-five-v2', title='Test', kind=Assessment.Kind.INITIAL)
        self.user = User.objects.create(phone_number='09120000077')
        self.data = _v2_example('A')['report']

    def _report(self, attempt, **overrides):
        fields = dict(
            id=5, attempt=attempt, status=Report.Status.OK, report_type=Report.ReportType.INITIAL,
            report_version='report_v2', report_data=self.data, dimension_scores=_DIMENSION_SCORES,
        )
        fields.update(overrides)
        report = MagicMock(**fields)
        self.report_repository.get_by_attempt_id.return_value = report
        return report

    def test_anonymous_preview_is_the_spec_5_4_shape(self):
        attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-9')
        self._report(attempt)

        result = self.service.get_report(attempt_id=attempt.id, user=None, anonymous_id='anon-9')

        first, second = self.data['findings']
        self.assertEqual(result['stage'], 'preview')
        self.assertEqual(result['report_version'], 'report_v2')
        self.assertEqual(result['preview'], {
            'hook': self.data['hook'],
            # Levels only, in stored order (not sorted by score), no score_percent.
            'dimension_scores': [{'key': d['key'], 'level': d['level']} for d in _DIMENSION_SCORES],
            'strength': self.data['strength'],
            'findings_heading': self.data['findings_heading'],
            'first_finding': {'area': first['area'], 'title': first['title'], 'what': first['what']},
            'second_finding': {'area': second['area'], 'title': second['title']},
        })

    def test_anonymous_preview_never_contains_locked_text(self):
        attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-9')
        self._report(attempt)

        result = self.service.get_report(attempt_id=attempt.id, user=None, anonymous_id='anon-9')

        blob = json.dumps(result, ensure_ascii=False)
        first, second = self.data['findings']
        for locked in (
            first['cost'], first['curiosity'], first['suggested_step']['text'],
            second['what'], second['cost'], second['curiosity'],
            self.data['open_question']['text'], self.data['exit']['bridge'], self.data['exit']['root_question'],
        ):
            self.assertNotIn(locked, blob)
        self.assertNotIn('score_percent', blob)

    def test_authenticated_request_gets_the_whole_stored_report(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        self._report(attempt)

        result = self.service.get_report(attempt_id=attempt.id, user=self.user, anonymous_id=None)

        self.assertEqual(result['stage'], 'full')
        self.assertEqual(result['report_version'], 'report_v2')
        self.assertEqual(result['report'], self.data)

    def test_history_line_is_the_hook(self):
        report = MagicMock(report_type=Report.ReportType.INITIAL, report_version='report_v2', report_data=self.data)

        self.assertEqual(ReportService._one_line(report), self.data['hook'])

    def test_history_line_of_a_v1_report_is_still_the_summary(self):
        report = MagicMock(
            report_type=Report.ReportType.INITIAL, report_version='report_v1',
            report_data={'summary': {'one_line': 'old'}},
        )

        self.assertEqual(ReportService._one_line(report), 'old')

    def test_suggested_step_is_the_first_findings_step(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        self._report(attempt)

        step = self.service.get_suggested_step(attempt_id=attempt.id, index=1, user=self.user)

        self.assertEqual(step, self.data['findings'][0]['suggested_step'])

    def test_only_index_one_exists_in_v2(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        self._report(attempt)

        for index in (0, 2, 3):
            with self.subTest(index=index), self.assertRaises(SuggestedStepNotFoundException):
                self.service.get_suggested_step(attempt_id=attempt.id, index=index, user=self.user)

    def test_accept_step_keeps_the_rec_1_source(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        self._report(attempt)
        step = self.data['findings'][0]['suggested_step']

        self.service.accept_step(attempt_id=attempt.id, index=1, user=self.user)

        self.action_step_service.create_step.assert_called_once_with(
            user=self.user, source='initial_report:rec_1', step_text=step['text'],
            deadline_type=step['deadline_type'], substeps=None,
        )

    def test_email_renders_the_v2_template_with_every_card_and_no_score_numbers(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        self._report(attempt)
        self.email_service.send_html.return_value = True

        self.service.email_report(attempt_id=attempt.id, user=self.user, email='reader@example.com')

        html = self.pdf_service.render_pdf.call_args[0][0]
        first, second = self.data['findings']
        # The hook is set in two halves (second one in lilac), so it isn't one contiguous string.
        hook_first, hook_rest = self.data['hook'].split('، ', 1)
        self.assertIn(hook_first, html)
        self.assertIn(hook_rest, html)
        for text in (
            self.data['strength']['text'], self.data['findings_heading'],
            first['title'], first['what'], first['cost'], first['curiosity'], first['suggested_step']['text'],
            second['title'], second['what'], second['cost'], second['curiosity'],
            self.data['open_question']['text'], self.data['exit']['bridge'], self.data['exit']['root_question'],
        ):
            self.assertIn(text, html)
        self.assertIn('کار', html)
        self.assertIn('رابطه', html)
        self.assertNotIn('٪', html)
        # Dark v2 design: radar with v2's level words, the numbered finding pills, no v1 cards.
        self.assertIn('<polygon points=', html)
        self.assertIn('نسبتاً بالا', html)
        self.assertIn('یافته‌ی اول · کار', html)
        self.assertIn('یافته‌ی دوم · رابطه', html)
        self.assertNotIn('مسیر رشد پیشنهادی تو', html)
        # The notice mail carries the hook, like the v1 one carried the summary line, in the v2 dark layout.
        notice_html = self.email_service.send_html.call_args[0][2]
        self.assertIn(self.data['hook'], notice_html)
        self.assertIn('#15121B', notice_html)

    def test_v1_report_still_emails_with_the_v1_template(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        v1 = json.loads(_fewshot_model_output(1))['report']
        self._report(attempt, report_version='report_v1', report_data=v1)
        self.email_service.send_html.return_value = True

        self.service.email_report(attempt_id=attempt.id, user=self.user, email='reader@example.com')

        html = self.pdf_service.render_pdf.call_args[0][0]
        self.assertIn(v1['summary']['one_line'], html)
        self.assertIn('مسیر رشد پیشنهادی تو', html)


class ReportServiceGetLatestForIdentityTests(TestCase):
    def setUp(self):
        self.report_repository = MagicMock()
        self.service = ReportService(report_repository=self.report_repository)
        self.assessment = Assessment.objects.create(slug='big-five-test', title='Test', kind=Assessment.Kind.INITIAL)

    def test_returns_none_when_no_report_exists(self):
        self.report_repository.get_latest_for_identity.return_value = None

        result = self.service.get_latest_for_identity(assessment=self.assessment, user=None, anonymous_id='anon-1')

        self.assertIsNone(result)
        self.report_repository.get_latest_for_identity.assert_called_once_with(
            assessment=self.assessment, user=None, anonymous_id='anon-1'
        )

    def test_returns_preview_shape_with_attempt_id_for_anonymous_requester(self):
        attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-1')
        report_data = {
            'summary': {'one_line': 'summary'},
            'core_narrative': {'body': 'first paragraph\n\nsecond paragraph\n\nthird paragraph'},
            'key_strengths': [{'title': 'first strength', 'description': 'first strength description'}],
            'growth_edges': [],
            'growth_path': {'recommendations': []},
            'preview': {'teaser_line': 'teaser'},
        }
        report = MagicMock(
            attempt=attempt, attempt_id=attempt.id, status=Report.Status.OK, report_version='report_v1',
            report_data=report_data, dimension_scores=[{'key': 'openness', 'score_percent': 90, 'level': 'high'}],
        )
        self.report_repository.get_latest_for_identity.return_value = report

        result = self.service.get_latest_for_identity(assessment=self.assessment, user=None, anonymous_id='anon-1')

        self.assertEqual(result['attempt_id'], attempt.id)
        self.assertEqual(result['stage'], 'preview')
        self.assertEqual(result['preview']['summary_one_line'], 'summary')

    def test_returns_full_shape_for_authenticated_requester(self):
        user = User.objects.create(phone_number='09120000007')
        attempt = Attempt.objects.create(assessment=self.assessment, user=user)
        report = MagicMock(
            id=42, attempt=attempt, attempt_id=attempt.id, status=Report.Status.OK, report_version='report_v1',
            report_data={'summary': {'one_line': 'summary'}},
            dimension_scores=[{'key': 'openness', 'score_percent': 90, 'level': 'high'}],
        )
        self.report_repository.get_latest_for_identity.return_value = report

        result = self.service.get_latest_for_identity(assessment=self.assessment, user=user, anonymous_id=None)

        self.assertEqual(result['stage'], 'full')
        self.assertEqual(result['report_id'], 42)


class ReportServiceGetHistoryTests(TestCase):
    def setUp(self):
        self.report_repository = MagicMock()
        self.service = ReportService(report_repository=self.report_repository)
        self.assessment = Assessment.objects.create(slug='big-five-test', title='Test', kind=Assessment.Kind.INITIAL)

    def test_returns_history_rows_newest_first_order_preserved_from_repository(self):
        user = User.objects.create(phone_number='09120000002')
        attempt = Attempt.objects.create(
            assessment=self.assessment, user=user, completed_at=timezone.now(),
        )
        report = MagicMock(
            id=7, attempt_id=attempt.id, attempt=attempt,
            report_type=Report.ReportType.INITIAL,
            report_data={'summary': {'one_line': 'a one line summary'}},
        )
        self.report_repository.get_history_for_user.return_value = [report]

        result = self.service.get_history(user)

        self.report_repository.get_history_for_user.assert_called_once_with(user)
        self.assertEqual(result, [{
            'attempt_id': attempt.id,
            'report_id': 7,
            # History mixes both products now, so each row says which one it is -- and the
            # summary sentence is read from whichever shape that type has.
            'report_type': Report.ReportType.INITIAL,
            'completed_at': attempt.completed_at,
            'summary_one_line': 'a one line summary',
        }])

    def test_returns_empty_list_when_user_has_no_reports(self):
        user = User.objects.create(phone_number='09120000003')
        self.report_repository.get_history_for_user.return_value = []

        result = self.service.get_history(user)

        self.assertEqual(result, [])


class ReportServiceGetAttemptsHistoryTests(TestCase):
    def setUp(self):
        self.report_repository = MagicMock()
        self.service = ReportService(report_repository=self.report_repository)
        self.assessment = Assessment.objects.create(slug='big-five-test', title='Test', kind=Assessment.Kind.INITIAL)

    def test_ok_row_includes_summary_and_blank_error(self):
        user = User.objects.create(phone_number='09120000010')
        attempt = Attempt.objects.create(assessment=self.assessment, user=user, completed_at=timezone.now())
        report = MagicMock(
            id=1, attempt_id=attempt.id, attempt=attempt, status=Report.Status.OK,
            report_type=Report.ReportType.INITIAL,
            report_data={'summary': {'one_line': 'a summary'}},
        )
        self.report_repository.get_attempts_history_for_user.return_value = [report]

        result = self.service.get_attempts_history(user)

        self.assertEqual(result, [{
            'attempt_id': attempt.id, 'report_id': 1, 'report_type': Report.ReportType.INITIAL,
            'status': Report.Status.OK, 'completed_at': attempt.completed_at,
            'summary_one_line': 'a summary', 'error_message': '',
        }])

    def test_error_row_includes_error_message_and_blank_summary(self):
        user = User.objects.create(phone_number='09120000011')
        attempt = Attempt.objects.create(assessment=self.assessment, user=user, completed_at=timezone.now())
        report = MagicMock(
            id=2, attempt_id=attempt.id, attempt=attempt, status=Report.Status.ERROR,
            report_type=Report.ReportType.INITIAL, error_message='چیزی اشتباه پیش رفت',
        )
        self.report_repository.get_attempts_history_for_user.return_value = [report]

        result = self.service.get_attempts_history(user)

        self.assertEqual(result[0]['summary_one_line'], '')
        self.assertEqual(result[0]['error_message'], 'چیزی اشتباه پیش رفت')

    def test_generating_row_has_blank_summary_and_error(self):
        user = User.objects.create(phone_number='09120000012')
        attempt = Attempt.objects.create(assessment=self.assessment, user=user, completed_at=timezone.now())
        report = MagicMock(
            id=3, attempt_id=attempt.id, attempt=attempt, status=Report.Status.GENERATING,
            report_type=Report.ReportType.INITIAL,
        )
        self.report_repository.get_attempts_history_for_user.return_value = [report]

        result = self.service.get_attempts_history(user)

        self.assertEqual(result[0]['summary_one_line'], '')
        self.assertEqual(result[0]['error_message'], '')


class ReportRepositoryRetryTests(TestCase):
    def setUp(self):
        self.repository = ReportRepository()
        self.assessment = Assessment.objects.create(slug='big-five-test', title='Test', kind=Assessment.Kind.INITIAL)

    def test_resets_error_report_to_generating_and_reclaimable(self):
        attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-1', completed_at=timezone.now())
        report = Report.objects.create(
            attempt=attempt, report_version='report_v1', status=Report.Status.ERROR,
            error_code='generation_failed', error_message='failed', generation_started_at=timezone.now(),
        )

        retried = self.repository.retry(report)

        self.assertEqual(retried.status, Report.Status.GENERATING)
        self.assertEqual(retried.error_code, '')
        self.assertEqual(retried.error_message, '')
        self.assertIsNone(retried.generation_started_at)
        # claim_for_generation requires generation_started_at IS NULL -- retry must actually
        # persist that reset, not just set it on the in-memory instance.
        self.assertIsNotNone(self.repository.claim_for_generation(attempt.id))


class ReportRepositoryGetAttemptsHistoryForUserTests(TestCase):
    def setUp(self):
        self.repository = ReportRepository()
        self.assessment = Assessment.objects.create(slug='big-five-test', title='Test', kind=Assessment.Kind.INITIAL)
        self.user = User.objects.create(phone_number='09120000013')

    def _create_report(self, *, status, completed_at):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user, completed_at=completed_at)
        kwargs = {'error_code': 'generation_failed', 'error_message': 'failed'} if status == Report.Status.ERROR else {}
        return Report.objects.create(attempt=attempt, report_version='report_v1', status=status, **kwargs)

    def test_includes_every_status_ordered_newest_first(self):
        older = self._create_report(status=Report.Status.OK, completed_at=timezone.now() - timezone.timedelta(days=1))
        newer_error = self._create_report(status=Report.Status.ERROR, completed_at=timezone.now())

        result = self.repository.get_attempts_history_for_user(self.user)

        self.assertEqual([report.id for report in result], [newer_error.id, older.id])

    def test_excludes_reports_for_other_users(self):
        other_user = User.objects.create(phone_number='09120000014')
        Attempt.objects.create(assessment=self.assessment, user=other_user, completed_at=timezone.now())
        own_report = self._create_report(status=Report.Status.OK, completed_at=timezone.now())

        result = self.repository.get_attempts_history_for_user(self.user)

        self.assertEqual([report.id for report in result], [own_report.id])


class ReportRepositoryGetHistoryForUserTests(TestCase):
    def setUp(self):
        self.repository = ReportRepository()
        self.assessment = Assessment.objects.create(slug='big-five-test', title='Test', kind=Assessment.Kind.INITIAL)
        self.user = User.objects.create(phone_number='09120000004')

    def _create_ok_report(self, *, completed_at):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user, completed_at=completed_at)
        return Report.objects.create(
            attempt=attempt, report_version='report_v1', status=Report.Status.OK,
            report_data={'summary': {'one_line': 'summary'}},
        )

    def test_orders_by_completed_at_descending(self):
        older = self._create_ok_report(completed_at=timezone.now() - timezone.timedelta(days=1))
        newer = self._create_ok_report(completed_at=timezone.now())

        result = self.repository.get_history_for_user(self.user)

        self.assertEqual([report.id for report in result], [newer.id, older.id])

    def test_excludes_reports_for_other_users(self):
        other_user = User.objects.create(phone_number='09120000005')
        Attempt.objects.create(assessment=self.assessment, user=other_user, completed_at=timezone.now())
        own_report = self._create_ok_report(completed_at=timezone.now())

        result = self.repository.get_history_for_user(self.user)

        self.assertEqual([report.id for report in result], [own_report.id])

    def test_excludes_error_reports(self):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user, completed_at=timezone.now())
        Report.objects.create(
            attempt=attempt, report_version='report_v1', status=Report.Status.ERROR,
            error_code='generation_failed', error_message='failed',
        )

        result = self.repository.get_history_for_user(self.user)

        self.assertEqual(result, [])


class ReportRepositoryGetLatestForIdentityTests(TestCase):
    def setUp(self):
        self.repository = ReportRepository()
        self.assessment = Assessment.objects.create(slug='big-five-test', title='Test', kind=Assessment.Kind.INITIAL)

    def _create_ok_report(self, *, user=None, anonymous_id=None, completed_at):
        attempt = Attempt.objects.create(
            assessment=self.assessment, user=user, anonymous_id=anonymous_id, completed_at=completed_at,
        )
        return Report.objects.create(
            attempt=attempt, report_version='report_v1', status=Report.Status.OK,
            report_data={'summary': {'one_line': 'summary'}},
        )

    def test_returns_none_when_no_report_exists(self):
        result = self.repository.get_latest_for_identity(assessment=self.assessment, user=None, anonymous_id='anon-1')

        self.assertIsNone(result)

    def test_returns_latest_report_for_anonymous_id(self):
        older = self._create_ok_report(anonymous_id='anon-1', completed_at=timezone.now() - timezone.timedelta(days=1))
        newer = self._create_ok_report(anonymous_id='anon-1', completed_at=timezone.now())

        result = self.repository.get_latest_for_identity(assessment=self.assessment, user=None, anonymous_id='anon-1')

        self.assertEqual(result.id, newer.id)

    def test_excludes_reports_for_other_identities(self):
        self._create_ok_report(anonymous_id='someone-else', completed_at=timezone.now())

        result = self.repository.get_latest_for_identity(assessment=self.assessment, user=None, anonymous_id='anon-1')

        self.assertIsNone(result)

    def test_returns_latest_report_for_user(self):
        user = User.objects.create(phone_number='09120000006')
        self._create_ok_report(user=user, completed_at=timezone.now() - timezone.timedelta(days=1))
        newer = self._create_ok_report(user=user, completed_at=timezone.now())

        result = self.repository.get_latest_for_identity(assessment=self.assessment, user=user, anonymous_id=None)

        self.assertEqual(result.id, newer.id)

    def test_excludes_error_reports(self):
        attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-1', completed_at=timezone.now())
        Report.objects.create(
            attempt=attempt, report_version='report_v1', status=Report.Status.ERROR,
            error_code='generation_failed', error_message='failed',
        )

        result = self.repository.get_latest_for_identity(assessment=self.assessment, user=None, anonymous_id='anon-1')

        self.assertIsNone(result)


@patch.dict('os.environ', {'REPORT_INITIAL_VERSION': 'report_v1'})
class AiReportClientGenerateTests(TestCase):
    """Exercises AiReportClient's own job: translating apps.report's payload shape into
    apps.ai.report_generation's contract. Generic pipeline mechanics (retry ladder, schema
    validation, success/failure) are covered in apps.ai.tests.ReportGenerationClientTests --
    not duplicated here."""

    def setUp(self):
        self.payload = {
            'assessment': {
                'user_id': '1', 'assessment_id': '1', 'test_version': 'big-five-v1', 'language': 'fa',
            },
            'demographics': {
                'birth_year': 1375, 'gender': 'male', 'life_situation': 'employed', 'goal': 'purpose',
            },
            'dimension_scores': [
                {'key': 'emotional_stability', 'score_percent': 72, 'level': 'medium_high'},
                {'key': 'extraversion', 'score_percent': 58, 'level': 'medium'},
                {'key': 'openness', 'score_percent': 84, 'level': 'high'},
                {'key': 'agreeableness', 'score_percent': 66, 'level': 'medium_high'},
                {'key': 'conscientiousness', 'score_percent': 88, 'level': 'high'},
            ],
            'answer_quality': {'completion_rate': 100},
        }

    def test_generate_returns_full_report_dict_through_the_adapter(self):
        fake_client = _FakeOpenAIClient([_fewshot_model_output(1)])

        result = AiReportClient(client=fake_client).generate(self.payload)

        self.assertEqual(result['status'], 'ok')
        self.assertEqual(result['report_version'], 'report_v1')
        self.assertIn('summary', result['report'])
        self.assertEqual(len(result['memory_candidates']), 4)

    def test_gender_never_reaches_the_model(self):
        fake_client = _FakeOpenAIClient([_fewshot_model_output(1)])

        AiReportClient(client=fake_client).generate(self.payload)

        for call in fake_client.completions.calls:
            for message in call['messages']:
                self.assertNotIn('gender', message['content'])
                self.assertNotIn('male', message['content'])

    def test_context_profile_maps_demographics_to_prompt_vocabulary(self):
        fake_client = _FakeOpenAIClient([_fewshot_model_output(1)])

        AiReportClient(client=fake_client).generate(self.payload)

        final_user_turn = json.loads(fake_client.completions.calls[0]['messages'][-1]['content'])
        context_profile = final_user_turn['context_profile']
        self.assertEqual(context_profile['life_situation'], 'employed')
        self.assertEqual(context_profile['current_goal'], 'purpose')
        self.assertIn('age', context_profile)

    @patch('apps.report.services.ai_report_client.timezone.localdate')
    def test_age_is_computed_from_the_jalali_year(self, localdate):
        # 2026-10-03 is 1405-07-11; a 1375 birth year is 30, not 2026 - 1375 = 651.
        localdate.return_value = timezone.datetime(2026, 10, 3).date()

        context_profile = AiReportClient._build_context_profile({'birth_year': 1375})

        self.assertEqual(context_profile['age'], '30')

    @patch('apps.report.services.ai_report_client.timezone.localdate')
    def test_jalali_year_rolls_over_at_nowruz(self, localdate):
        localdate.return_value = timezone.datetime(2026, 3, 20).date()
        self.assertEqual(AiReportClient._current_jalali_year(), 1404)

        localdate.return_value = timezone.datetime(2026, 3, 21).date()
        self.assertEqual(AiReportClient._current_jalali_year(), 1405)
