"""report_v3 integration tests for apps.report (docs/report_spec_v3_0.md).

Covers the parts the AI-layer tests (apps/ai/tests_report_v3.py) cannot: mapping real DB
rows onto q1..q30, version pinning across the queue, the anonymous preview allowlist, step
acceptance, the PDF/email branch, and the guarantee that stored v1/v2 reports still render
as themselves. No provider is ever contacted.
"""

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

from django.test import TestCase

from apps.account.models import User
from apps.ai.report_generation.question_map_v3 import V3_QUESTIONS
from apps.assessment.models import Answer, Assessment, AssessmentSection, Attempt, Question
from apps.report.models import Report
from apps.report.repositories.report_repository import ReportRepository
from apps.report.services.exceptions import (
    ReportAccessDeniedException,
    ReportV3AnswersIncompleteException,
    ReportV3QuestionMapMismatchException,
    SuggestedStepNotFoundException,
)
from apps.report.services.report_service import ReportService
from apps.report.services.report_v3_input_service import ReportV3InputService

_FEWSHOT_V3_DIR = (
    Path(__file__).resolve().parents[2] / "ai" / "report_generation" / "fewshot_v3"
)


def _golden(n: int, part: str) -> dict:
    return json.loads((_FEWSHOT_V3_DIR / f"golden_{n}_{part}.json").read_text(encoding="utf-8"))


_V3_REPORT_DATA = _golden(1, "output")["report"]
_V3_SYSTEM_DATA = _golden(1, "output")["system"]
_V3_DIMENSION_SCORES = [
    {"key": "emotional_stability", "score_percent": 21, "level": "low"},
    {"key": "extraversion", "score_percent": 50, "level": "medium"},
    {"key": "openness", "score_percent": 54, "level": "medium"},
    {"key": "agreeableness", "score_percent": 63, "level": "medium_high"},
    {"key": "conscientiousness", "score_percent": 92, "level": "high"},
]
# Same reconstruction as apps/ai/tests_report_v3.py, kept here so this module stands alone.
_GOLDEN_1_ANSWERS = "524154424242434343434532535515"


class _V3AssessmentMixin:
    """Builds an assessment whose 30 questions ARE the v3 contract, so the mapping succeeds."""

    def _build_v3_assessment(self, slug="initial-v3-30"):
        assessment = Assessment.objects.create(
            slug=slug, title="v3", kind=Assessment.Kind.INITIAL,
        )
        sections, questions = {}, {}
        for spec in V3_QUESTIONS:
            if spec.dim not in sections:
                sections[spec.dim] = AssessmentSection.objects.create(
                    assessment=assessment, order=len(sections) + 1, title=spec.dim,
                )
            questions[spec.id] = Question.objects.create(
                section=sections[spec.dim],
                order=(spec.num - 1) % 6 + 1,
                text=spec.text,
                question_type=Question.QuestionType.LIKERT,
                reverse_scored=spec.reverse,
            )
        return assessment, questions

    def _answer_all(self, attempt, questions, digits=_GOLDEN_1_ANSWERS):
        for i, digit in enumerate(digits, start=1):
            Answer.objects.create(
                attempt=attempt, question=questions[f"q{i}"], value=int(digit),
            )


class ReportV3InputServiceTests(_V3AssessmentMixin, TestCase):
    def setUp(self):
        self.assessment, self.questions = self._build_v3_assessment()
        self.attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id="anon-1")
        self.service = ReportV3InputService()

    def test_builds_the_thirty_answers_keyed_by_contract_id(self):
        self._answer_all(self.attempt, self.questions)

        answers = self.service.build_answers(self.attempt)

        self.assertEqual(len(answers), 30)
        self.assertEqual(sorted(answers), sorted(f"q{i}" for i in range(1, 31)))
        self.assertEqual(answers["q1"], 5)
        self.assertEqual(answers["q30"], 5)

    def test_question_ids_are_not_database_primary_keys(self):
        """The q-id space and the PK space are independent. Built here by creating a SECOND
        v3-shaped assessment, whose primary keys are all offset by 30: mapping it must still
        produce q1..q30 pointing at that assessment's own rows."""
        other_assessment, other_questions = self._build_v3_assessment(slug="initial-v3-30-b")
        other_attempt = Attempt.objects.create(assessment=other_assessment, anonymous_id="anon-2")
        self._answer_all(other_attempt, other_questions)

        answers = self.service.build_answers(other_attempt)

        self.assertEqual(len(answers), 30)
        # The second assessment's q1 is not primary key 1 -- that belongs to the first one.
        self.assertNotEqual(other_questions["q1"].id, 1)
        self.assertEqual(answers["q1"], 5)
        # And the first assessment's rows were not consulted.
        self.assertEqual(
            {q.id for q in other_questions.values()} & {q.id for q in self.questions.values()},
            set(),
        )

    def test_v3_scores_use_javascript_rounding_and_can_differ_from_scoring_service(self):
        """The reason v3 stores its own scores. These golden-1 answers land agreeableness on
        factor sum 21 -> 62.5%, where Python's bankers rounding gives 62 and the studio's
        Math.round gives 63. The page must show the number the report text was written from."""
        from apps.report.services.scoring_service import ScoringService

        self._answer_all(self.attempt, self.questions)
        v3_scores = self.service.dimension_scores(self.service.build_answers(self.attempt))
        v1_scores = ScoringService().score_attempt(self.attempt)

        by_key_v3 = {item["key"]: item["score_percent"] for item in v3_scores}
        by_key_v1 = {item["key"]: item["score_percent"] for item in v1_scores}
        self.assertEqual(by_key_v3["agreeableness"], 63)
        self.assertEqual(by_key_v1["agreeableness"], 62)
        # Everything else agrees; only the two half-tie sums can differ.
        self.assertEqual(
            {k: v for k, v in by_key_v3.items() if k != "agreeableness"},
            {k: v for k, v in by_key_v1.items() if k != "agreeableness"},
        )

    def test_the_stored_scores_match_the_scores_sent_to_the_model(self):
        from apps.ai.report_generation.profile_input_v3 import AnswerSheetV3

        self._answer_all(self.attempt, self.questions)
        answers = self.service.build_answers(self.attempt)
        payload = AnswerSheetV3(answers=answers).to_smart_payload()

        stored = {item["key"]: (item["score_percent"], item["level"])
                  for item in self.service.dimension_scores(answers)}
        for key, block in payload["profile"].items():
            self.assertEqual((block["score"], block["level"]), stored[key], key)

    def test_a_mismatched_assessment_refuses_instead_of_quoting_wrong_text(self):
        wrong = self.questions["q7"]
        wrong.text = "یک جمله‌ای که کاربر هرگز ندیده است."
        wrong.save(update_fields=["text"])
        self._answer_all(self.attempt, self.questions)

        with self.assertRaises(ReportV3QuestionMapMismatchException):
            self.service.build_answers(self.attempt)

    def test_a_flipped_reverse_flag_refuses(self):
        wrong = self.questions["q12"]
        wrong.reverse_scored = not wrong.reverse_scored
        wrong.save(update_fields=["reverse_scored"])
        self._answer_all(self.attempt, self.questions)

        with self.assertRaises(ReportV3QuestionMapMismatchException):
            self.service.build_answers(self.attempt)

    def test_a_missing_answer_is_an_error_not_a_neutral_default(self):
        self._answer_all(self.attempt, self.questions)
        Answer.objects.filter(attempt=self.attempt, question=self.questions["q9"]).delete()

        with self.assertRaises(ReportV3AnswersIncompleteException):
            self.service.build_answers(self.attempt)

    def test_an_out_of_range_or_non_integer_answer_is_an_error(self):
        # None is not in the list: Answer.value is NOT NULL, so it cannot be stored at all.
        for bad in (0, 6, "4", [4], True, 4.5):
            with self.subTest(value=bad):
                Answer.objects.filter(attempt=self.attempt).delete()
                self._answer_all(self.attempt, self.questions)
                answer = Answer.objects.get(attempt=self.attempt, question=self.questions["q4"])
                answer.value = bad
                answer.save(update_fields=["value"])

                with self.assertRaises(ReportV3AnswersIncompleteException):
                    self.service.build_answers(self.attempt)

    def test_mismatch_details_are_logged_but_never_in_the_exception_message(self):
        wrong = self.questions["q7"]
        wrong.text = "متن اشتباه"
        wrong.save(update_fields=["text"])
        self._answer_all(self.attempt, self.questions)

        with self.assertLogs("apps.report.services.report_v3_input_service", level="ERROR") as logs:
            with self.assertRaises(ReportV3QuestionMapMismatchException) as ctx:
                self.service.build_answers(self.attempt)

        self.assertIn("q7: text mismatch", "\n".join(logs.output))
        self.assertNotIn("q7", str(ctx.exception))

    def test_answers_are_never_logged(self):
        self._answer_all(self.attempt, self.questions)
        Answer.objects.filter(attempt=self.attempt, question=self.questions["q9"]).delete()

        with self.assertLogs("apps.report.services.report_v3_input_service", level="ERROR") as logs:
            with self.assertRaises(ReportV3AnswersIncompleteException):
                self.service.build_answers(self.attempt)

        blob = "\n".join(logs.output)
        self.assertIn("q9", blob)          # which question is missing: operational
        self.assertNotIn("q1: 5", blob)    # the person's actual answers: never


class ReportV3PayloadTests(_V3AssessmentMixin, TestCase):
    """_build_ai_payload: v3 adds `answers`, v1/v2 payloads are byte-identical to before."""

    def setUp(self):
        self.demographics_service = MagicMock()
        self.demographics_service.get.return_value = {
            "birth_year": 1375, "gender": "female", "life_situation": "employed",
            "goal": "decisions", "answered": True,
        }
        self.service = ReportService(
            report_repository=MagicMock(), memory_repository=MagicMock(), ai_client=MagicMock(),
            demographics_service=self.demographics_service,
            generation_log_repository=MagicMock(),
        )
        self.assessment, self.questions = self._build_v3_assessment()
        self.attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id="anon-1")
        self._answer_all(self.attempt, self.questions)

    def test_v3_payload_carries_the_answers_and_the_pinned_version(self):
        payload = self.service._build_ai_payload(self.attempt, _V3_DIMENSION_SCORES, "report_v3")

        self.assertEqual(len(payload["answers"]), 30)
        self.assertEqual(payload["report_version"], "report_v3")
        self.assertEqual(payload["dimension_scores"], _V3_DIMENSION_SCORES)

    def test_v1_and_v2_payloads_do_not_carry_answers(self):
        for version in ("", "report_v1", "report_v2"):
            with self.subTest(version=version):
                payload = self.service._build_ai_payload(self.attempt, _V3_DIMENSION_SCORES, version)
                self.assertNotIn("answers", payload)

    def test_the_payload_never_carries_identifiers(self):
        """gender/user id/phone must not reach the model. The payload still carries the
        demographics block v1/v2 built (AiReportClient drops gender), so assert at the
        boundary that actually talks to apps.ai."""
        from apps.report.services.ai_report_client import AiReportClient

        payload = self.service._build_ai_payload(self.attempt, _V3_DIMENSION_SCORES, "report_v3")
        context_profile = AiReportClient._build_context_profile(payload["demographics"])

        self.assertNotIn("gender", context_profile)
        self.assertEqual(set(context_profile), {"age", "life_situation", "current_goal"})

    def test_age_comes_from_the_existing_backend_calculation(self):
        """Requirement: reuse the current age logic, not the studio's hardcoded 1404."""
        from apps.report.services.ai_report_client import AiReportClient

        with patch.object(AiReportClient, "_current_jalali_year", staticmethod(lambda: 1404)):
            context_profile = AiReportClient._build_context_profile({"birth_year": 1375})
        self.assertEqual(context_profile["age"], "29")

        with patch.object(AiReportClient, "_current_jalali_year", staticmethod(lambda: 1405)):
            context_profile = AiReportClient._build_context_profile({"birth_year": 1375})
        self.assertEqual(context_profile["age"], "30")


class ReportV3VersionPinningTests(TestCase):
    """Requirement 6: the version is chosen in the request and survives the queue."""

    def setUp(self):
        self.assessment = Assessment.objects.create(
            slug="big-five-test", title="Test", kind=Assessment.Kind.INITIAL,
        )
        self.attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id="anon-1")
        self.repository = ReportRepository()

    def test_create_generating_initial_stores_the_version(self):
        report = self.repository.create_generating_initial(
            attempt=self.attempt, dimension_scores=[], report_version="report_v3",
        )
        report.refresh_from_db()
        self.assertEqual(report.report_version, "report_v3")
        self.assertEqual(report.status, Report.Status.GENERATING)

    def test_an_old_queued_row_with_no_version_still_generates(self):
        """Rows created before this change have report_version="". The worker must fall back
        to the configured version rather than crash on an empty pin."""
        from apps.ai.report_generation.generate import resolve_variant

        report = self.repository.create_generating_initial(attempt=self.attempt, dimension_scores=[])
        self.assertEqual(report.report_version, "")

        with patch.dict("os.environ", {"REPORT_INITIAL_VERSION": "report_v2"}):
            self.assertEqual(resolve_variant(report.report_version or None).version, "report_v2")

    def test_a_deploy_during_the_queue_does_not_change_an_already_queued_row(self):
        report = self.repository.create_generating_initial(
            attempt=self.attempt, dimension_scores=[], report_version="report_v2",
        )
        # Operator flips the env while the task sits in the queue.
        with patch.dict("os.environ", {"REPORT_INITIAL_VERSION": "report_v3"}):
            report.refresh_from_db()
            self.assertEqual(report.report_version, "report_v2")

    def test_only_one_worker_can_claim_a_row(self):
        self.repository.create_generating_initial(
            attempt=self.attempt, dimension_scores=[], report_version="report_v3",
        )
        first = self.repository.claim_for_generation(self.attempt.id)
        second = self.repository.claim_for_generation(self.attempt.id)

        self.assertIsNotNone(first)
        self.assertIsNone(second)

    def test_retry_re_pins_to_the_currently_configured_version(self):
        report = self.repository.create_generating_initial(
            attempt=self.attempt, dimension_scores=[], report_version="report_v3",
        )
        self.repository.mark_error(report, error_code="generation_failed", error_message="x")

        self.repository.retry(report, report_version="report_v2")

        report.refresh_from_db()
        self.assertEqual(report.report_version, "report_v2")
        self.assertEqual(report.status, Report.Status.GENERATING)
        self.assertIsNone(report.generation_started_at)

    def test_retry_without_a_version_leaves_the_stored_one_alone(self):
        report = self.repository.create_generating_initial(
            attempt=self.attempt, dimension_scores=[], report_version="report_v3",
        )
        self.repository.mark_error(report, error_code="generation_failed", error_message="x")

        self.repository.retry(report)

        report.refresh_from_db()
        self.assertEqual(report.report_version, "report_v3")

    def test_mark_ok_records_the_version_that_actually_produced_the_content(self):
        report = self.repository.create_generating_initial(
            attempt=self.attempt, dimension_scores=[], report_version="report_v3",
        )
        self.repository.mark_ok(
            report, report_version="report_v2", report_data={"hook": "x"},
            system_data={}, memory_candidates=[],
        )
        report.refresh_from_db()
        self.assertEqual(report.report_version, "report_v2")


class ReportV3ShapeTests(TestCase):
    """Requirement 5: preview / full / history / step, per stored version."""

    def setUp(self):
        self.user = User.objects.create(phone_number="09120000001")
        self.assessment = Assessment.objects.create(
            slug="big-five-test", title="Test", kind=Assessment.Kind.INITIAL,
        )
        self.attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        self.report = Report.objects.create(
            attempt=self.attempt,
            report_type=Report.ReportType.INITIAL,
            report_version="report_v3",
            status=Report.Status.OK,
            dimension_scores=_V3_DIMENSION_SCORES,
            report_data=_V3_REPORT_DATA,
            system_data=_V3_SYSTEM_DATA,
        )
        self.service = ReportService()

    def test_anonymous_preview_is_a_strict_allowlist(self):
        attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id="anon-9")
        report = Report.objects.create(
            attempt=attempt, report_type=Report.ReportType.INITIAL, report_version="report_v3",
            status=Report.Status.OK, dimension_scores=_V3_DIMENSION_SCORES,
            report_data=_V3_REPORT_DATA, system_data=_V3_SYSTEM_DATA,
        )

        shaped = self.service.get_report(attempt_id=attempt.id, user=None, anonymous_id="anon-9")

        self.assertEqual(shaped["stage"], "preview")
        # The keys of report_spec_v3_0 §5.3, exactly.
        self.assertEqual(
            set(shaped["preview"]),
            {"hook", "dimension_scores", "coins_front", "goal_card_title", "findings"},
        )
        self.assertEqual(len(shaped["preview"]["coins_front"]), 3)
        for coin in shaped["preview"]["coins_front"]:
            self.assertEqual(set(coin), {"front_title", "front_text"})
        self.assertEqual(len(shaped["preview"]["findings"]), 2)
        for finding in shaped["preview"]["findings"]:
            self.assertEqual(set(finding), {"area", "title"})
        # Levels only, never the numbers.
        for item in shaped["preview"]["dimension_scores"]:
            self.assertEqual(set(item), {"key", "level"})

        blob = json.dumps(shaped, ensure_ascii=False)
        for withheld in (
            # §5.2's locked column, every entry of it.
            _V3_REPORT_DATA["coins"][0]["back_title"],
            _V3_REPORT_DATA["coins"][0]["back_text"],
            _V3_REPORT_DATA["coins"][1]["back_text"],
            _V3_REPORT_DATA["coins"][2]["back_text"],
            _V3_REPORT_DATA["goal_card"]["bottleneck_insight"],
            _V3_REPORT_DATA["goal_card"]["helps"][0],
            _V3_REPORT_DATA["goal_card"]["hard"][0],
            _V3_REPORT_DATA["findings"][0]["what"],
            _V3_REPORT_DATA["findings"][0]["cost"],
            _V3_REPORT_DATA["findings"][0]["curiosity"],
            _V3_REPORT_DATA["findings"][0]["suggested_step"]["text"],
            _V3_REPORT_DATA["findings"][1]["what"],
            _V3_REPORT_DATA["exit"]["bridge"],
            _V3_REPORT_DATA["exit"]["root_question"],
            # Not ruled on by §5.2 because they are not in its §4.1 contract; withheld as the
            # conservative reading, and asserted here so the choice is visible if it changes.
            _V3_REPORT_DATA["mirror"]["outer"],
            _V3_REPORT_DATA["mirror"]["inner"],
            _V3_REPORT_DATA["mirror"]["blind_spot"],
            _V3_REPORT_DATA["dimension_insights"]["openness"],
        ):
            self.assertNotIn(withheld, blob)

        self.assertNotIn("source_map", blob)
        self.assertNotIn("pattern_tags", blob)
        self.assertNotIn(_V3_SYSTEM_DATA["source_map"]["coin_1"]["theme"], blob)

    def test_the_authenticated_full_report_carries_the_report_but_not_the_system_block(self):
        shaped = self.service.get_report(attempt_id=self.attempt.id, user=self.user, anonymous_id=None)

        self.assertEqual(shaped["stage"], "full")
        self.assertEqual(shaped["report_version"], "report_v3")
        self.assertEqual(shaped["report"], _V3_REPORT_DATA)
        self.assertNotIn("system", shaped)
        self.assertNotIn("source_map", json.dumps(shaped, ensure_ascii=False))

    def test_a_stranger_cannot_read_the_report(self):
        with self.assertRaises(ReportAccessDeniedException):
            self.service.get_report(attempt_id=self.attempt.id, user=None, anonymous_id="someone-else")

    def test_history_uses_the_v3_hook_as_its_one_line(self):
        history = self.service.get_history(self.user)

        self.assertEqual(len(history), 1)
        self.assertEqual(history[0]["summary_one_line"], _V3_REPORT_DATA["hook"])

    def test_suggested_step_is_the_first_finding_only(self):
        step = self.service.get_suggested_step(attempt_id=self.attempt.id, index=1, user=self.user)
        self.assertEqual(step["text"], _V3_REPORT_DATA["findings"][0]["suggested_step"]["text"])

        with self.assertRaises(SuggestedStepNotFoundException):
            self.service.get_suggested_step(attempt_id=self.attempt.id, index=2, user=self.user)

    def test_accepting_the_step_creates_an_action_step_with_the_v2_source_format(self):
        action_step = self.service.accept_step(attempt_id=self.attempt.id, index=1, user=self.user)

        self.assertEqual(action_step.source, "initial_report:rec_1")
        self.assertEqual(action_step.step_text, _V3_REPORT_DATA["findings"][0]["suggested_step"]["text"])

    def test_the_fake_suggested_step_patch_never_touches_a_v3_report(self):
        """_with_fake_suggested_steps only fills v1's growth_path; v3 produces a real step."""
        shaped = self.service.get_report(attempt_id=self.attempt.id, user=self.user, anonymous_id=None)
        self.assertNotIn("نمونه — نه یک قدمِ واقعی", json.dumps(shaped, ensure_ascii=False))

    def test_a_v3_error_row_reports_its_code_without_leaking_a_reason(self):
        self.report.status = Report.Status.ERROR
        self.report.error_code = "insufficient_evidence"
        self.report.error_message = "مشکلی در ساخت گزارش پیش آمد. چند لحظه‌ی دیگر دوباره تلاش کن."
        self.report.save()

        shaped = self.service.get_report(attempt_id=self.attempt.id, user=self.user, anonymous_id=None)

        self.assertEqual(shaped["status"], "error")
        self.assertEqual(shaped["error"]["code"], "insufficient_evidence")
        self.assertFalse(shaped["error"]["should_display_report"])
        self.assertNotIn("non-neutral", json.dumps(shaped, ensure_ascii=False))


class StoredV1AndV2StillRenderAsThemselvesTests(TestCase):
    """Requirement: no stored report changes shape because v3 exists."""

    def setUp(self):
        self.user = User.objects.create(phone_number="09120000002")
        self.assessment = Assessment.objects.create(
            slug="big-five-test", title="Test", kind=Assessment.Kind.INITIAL,
        )
        self.service = ReportService()

    def _report(self, version, data):
        attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        return Report.objects.create(
            attempt=attempt, report_type=Report.ReportType.INITIAL, report_version=version,
            status=Report.Status.OK, dimension_scores=_V3_DIMENSION_SCORES, report_data=data,
        )

    def test_a_stored_v2_report_keeps_the_v2_preview(self):
        from apps.ai.tests import _v2_example

        report = self._report("report_v2", _v2_example("A")["report"])
        shaped = self.service.get_report(
            attempt_id=report.attempt_id, user=None, anonymous_id=None,
        ) if False else self.service._build_preview(report)

        self.assertEqual(set(shaped["preview"]), {
            "hook", "dimension_scores", "strength", "findings_heading",
            "first_finding", "second_finding",
        })

    def test_a_stored_v1_report_keeps_the_v1_preview(self):
        from apps.ai.tests import _FEWSHOT_DIR

        data = json.loads((_FEWSHOT_DIR / "example_1.json").read_text(encoding="utf-8"))["report"]
        report = self._report("report_v1", data)

        shaped = self.service._build_preview(report)

        self.assertIn("summary_one_line", shaped["preview"])
        self.assertIn("locked_counts", shaped["preview"])


class ReportV3EmailTests(TestCase):
    """Requirement 5: the email/PDF branch is implemented for v3, not silently reused."""

    def setUp(self):
        self.user = User.objects.create(phone_number="09120000003")
        self.assessment = Assessment.objects.create(
            slug="big-five-test", title="Test", kind=Assessment.Kind.INITIAL,
        )
        self.attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        self.report = Report.objects.create(
            attempt=self.attempt, report_type=Report.ReportType.INITIAL, report_version="report_v3",
            status=Report.Status.OK, dimension_scores=_V3_DIMENSION_SCORES,
            report_data=_V3_REPORT_DATA, system_data=_V3_SYSTEM_DATA,
        )

    def test_the_v3_context_covers_every_v3_section(self):
        context = ReportService._build_initial_v3_email_context(self.report)

        self.assertEqual(context["mirror"], _V3_REPORT_DATA["mirror"])
        self.assertEqual(len(context["coins"]), 3)
        self.assertEqual(len(context["dimensions"]), 5)
        self.assertEqual(context["goal_card"], _V3_REPORT_DATA["goal_card"])
        self.assertEqual(len(context["findings"]), 2)
        self.assertEqual(context["summary_one_line"], _V3_REPORT_DATA["hook"])

    def test_the_v3_pdf_template_renders(self):
        from django.template.loader import render_to_string

        from apps.report.services.pdf_service import ReportPdfService

        pdf_service = ReportPdfService()
        html = render_to_string("report/pdf_initial_v3.html", {
            **ReportService._build_initial_v3_email_context(self.report),
            **pdf_service.font_context(),
            **pdf_service.image_context(),
        })

        self.assertIn(_V3_REPORT_DATA["goal_card"]["title"], html)
        self.assertIn(_V3_REPORT_DATA["coins"][0]["back_title"], html)
        self.assertIn(_V3_REPORT_DATA["exit"]["root_question"], html)
        # The internal block is not in the context at all, so it cannot reach the PDF.
        self.assertNotIn(_V3_SYSTEM_DATA["source_map"]["coin_1"]["theme"], html)

    def test_email_report_picks_the_v3_templates(self):
        service = ReportService(
            pdf_service=MagicMock(**{
                "font_context.return_value": {}, "image_context.return_value": {"images": {}},
                "render_pdf.return_value": b"%PDF-",
            }),
            email_service=MagicMock(**{"send_html.return_value": True}),
            report_email_throttle_repository=MagicMock(**{"hit.return_value": False}),
            report_email_delivery_repository=MagicMock(),
        )

        with patch("apps.report.services.report_service.render_to_string") as render:
            render.return_value = "<html></html>"
            service.email_report(attempt_id=self.attempt.id, user=self.user, email="a@b.c")

        templates = [call.args[0] for call in render.call_args_list]
        self.assertEqual(templates[0], "report/pdf_initial_v3.html")
        self.assertNotIn("report/pdf_initial_v2.html", templates)
        self.assertNotIn("report/pdf_initial.html", templates)


class ReportV3ChatTests(TestCase):
    """Requirement 5: chat entry sources and the renderer are v3-aware."""

    def setUp(self):
        self.user = User.objects.create(phone_number="09120000004")
        self.assessment = Assessment.objects.create(
            slug="big-five-test", title="Test", kind=Assessment.Kind.INITIAL,
        )
        self.attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        self.report = Report.objects.create(
            attempt=self.attempt, report_type=Report.ReportType.INITIAL, report_version="report_v3",
            status=Report.Status.OK, dimension_scores=_V3_DIMENSION_SCORES,
            report_data=_V3_REPORT_DATA, system_data=_V3_SYSTEM_DATA,
        )

    def test_a_v3_report_is_rendered_by_the_v3_renderer_not_the_v2_one(self):
        from apps.ai.chat_generation.prompt import render_report_initial

        rendered = render_report_initial(_V3_REPORT_DATA, "report_v3")
        self.assertIn(_V3_REPORT_DATA["goal_card"]["title"], rendered)
        self.assertIn(_V3_REPORT_DATA["coins"][0]["back_title"], rendered)

        # And inferred correctly when the caller does not say which version it holds: a v3
        # report has `findings` too, so inferring on that key alone would route it to v2.
        self.assertEqual(rendered, render_report_initial(_V3_REPORT_DATA))

    def test_the_renderer_withholds_steps_insights_and_the_system_block(self):
        from apps.ai.chat_generation.prompt import render_report_initial

        rendered = render_report_initial(_V3_REPORT_DATA, "report_v3")

        self.assertNotIn(_V3_REPORT_DATA["findings"][0]["suggested_step"]["text"], rendered)
        self.assertNotIn(_V3_REPORT_DATA["dimension_insights"]["openness"], rendered)
        self.assertNotIn("source_map", rendered)

    def test_chat_input_accepts_report_v3(self):
        from apps.ai.chat_generation.chat_input import ChatRequest

        request = ChatRequest(
            session_id="s1", entry_source="report_cta", user_message="سلام",
            report_type="initial", report_version="report_v3", report=_V3_REPORT_DATA,
        )
        self.assertEqual(request.report_version, "report_v3")

    def test_the_v3_report_cards_open_a_chat(self):
        """report_spec_v3_0 §9.1: the goal card and both finding cards, and report_cta."""
        from apps.chat.services.chat_service import ChatService

        service = ChatService()
        for entry_source in (
            "report_cta", "report_goal", "report_finding_focus:0", "report_finding_focus:1",
        ):
            with self.subTest(entry_source=entry_source):
                session = service.create_session(
                    user=self.user, entry_source=entry_source, attempt_id=self.attempt.id,
                )
                self.assertEqual(session.report_id, self.report.id)

    def test_report_open_question_is_refused_on_a_v3_report(self):
        """§9.1 removed it: v3 has no open question, so its mission would describe a card
        that is not on the page. A stale front-end build must fail loudly, not quietly."""
        from apps.chat.services.chat_service import ChatService
        from apps.chat.services.exceptions import ReportVersionMismatchException

        with self.assertRaises(ReportVersionMismatchException):
            ChatService().create_session(
                user=self.user, entry_source="report_open_question", attempt_id=self.attempt.id,
            )

    def test_report_goal_is_refused_on_a_v2_report(self):
        """The mirror image: a v2 report has no goal card."""
        from apps.chat.services.chat_service import ChatService
        from apps.chat.services.exceptions import ReportVersionMismatchException

        self.report.report_version = "report_v2"
        self.report.save(update_fields=["report_version"])

        with self.assertRaises(ReportVersionMismatchException):
            ChatService().create_session(
                user=self.user, entry_source="report_goal", attempt_id=self.attempt.id,
            )

    def test_those_entry_sources_are_still_refused_on_a_v1_report(self):
        from apps.chat.services.chat_service import ChatService
        from apps.chat.services.exceptions import ReportVersionMismatchException

        self.report.report_version = "report_v1"
        self.report.save(update_fields=["report_version"])

        for entry_source in ("report_goal", "report_open_question", "report_finding_focus:0"):
            with self.subTest(entry_source=entry_source):
                with self.assertRaises(ReportVersionMismatchException):
                    ChatService().create_session(
                        user=self.user, entry_source=entry_source, attempt_id=self.attempt.id,
                    )

    def test_the_goal_card_entry_quotes_the_card_in_the_chat_prompt(self):
        """§9.3: the session context names the card the person tapped, and the mission warns
        the model not to assume a report-suggested goal is the user's own concern."""
        from apps.ai.chat_generation.prompt import build_messages

        messages = build_messages(
            entry_source="report_goal", report=_V3_REPORT_DATA, report_type="initial",
            report_version="report_v3", user_memory=[], history=[], user_message="سلام",
        )
        blob = "\n".join(m["content"] for m in messages)

        self.assertIn(_V3_REPORT_DATA["goal_card"]["title"], blob)
        self.assertIn("درس نده", blob)
        self.assertIn("آن را دغدغه‌ی کاربر فرض نکن", blob)


class ReportV3GenerationFlowTests(_V3AssessmentMixin, TestCase):
    """The worker path end to end, with a fake provider."""

    def setUp(self):
        self.report_repository = MagicMock()
        self.memory_repository = MagicMock()
        self.ai_client = MagicMock()
        self.demographics_service = MagicMock()
        self.demographics_service.get.return_value = {
            "birth_year": None, "gender": None, "life_situation": None, "goal": None, "answered": False,
        }
        self.service = ReportService(
            report_repository=self.report_repository,
            memory_repository=self.memory_repository,
            ai_client=self.ai_client,
            demographics_service=self.demographics_service,
            generation_log_repository=MagicMock(),
        )
        self.assessment, self.questions = self._build_v3_assessment()
        self.attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id="anon-1")
        self._answer_all(self.attempt, self.questions)

        self.report = MagicMock()
        self.report.attempt = self.attempt
        self.report.report_version = "report_v3"
        self.report.dimension_scores = _V3_DIMENSION_SCORES
        self.report_repository.claim_for_generation.return_value = self.report

    def test_the_worker_sends_answers_and_the_pinned_version(self):
        self.ai_client.generate.return_value = {
            "status": "ok", "report_version": "report_v3",
            "report": _V3_REPORT_DATA, "system": _V3_SYSTEM_DATA, "memory_candidates": [],
            "generation_meta": {"model_used": "fake", "attempts": 1, "input_tokens": 1,
                                "output_tokens": 1, "latency_s": 0.1},
        }

        self.service.generate_initial(self.attempt.id)

        payload = self.ai_client.generate.call_args.args[0]
        self.assertEqual(payload["report_version"], "report_v3")
        self.assertEqual(len(payload["answers"]), 30)
        self.assertEqual(
            self.report_repository.mark_ok.call_args.kwargs["report_version"], "report_v3",
        )

    def test_a_mapping_failure_becomes_a_stored_error_not_a_crashed_task(self):
        wrong = self.questions["q7"]
        wrong.text = "متن اشتباه"
        wrong.save(update_fields=["text"])

        result = self.service.generate_initial(self.attempt.id)

        self.ai_client.generate.assert_not_called()
        self.report_repository.mark_error.assert_called_once()
        self.assertEqual(
            self.report_repository.mark_error.call_args.kwargs["error_code"], "generation_failed",
        )
        self.assertIs(result, self.report_repository.mark_error.return_value)

    def test_an_error_response_is_stored_with_its_code(self):
        self.ai_client.generate.return_value = {
            "status": "error", "report_version": "report_v3",
            "error": {"code": "insufficient_evidence", "user_message": "پیام عمومی",
                      "should_display_report": False},
            "generation_meta": None,
        }

        self.service.generate_initial(self.attempt.id)

        self.assertEqual(
            self.report_repository.mark_error.call_args.kwargs["error_code"], "insufficient_evidence",
        )
        self.report_repository.mark_ok.assert_not_called()
