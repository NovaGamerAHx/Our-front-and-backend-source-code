"""Tests for the deep (150-item) report pipeline.

Kept in their own module rather than appended to test_report.py, which is already ~700 lines
about the initial report. Filenames in this package must start with "test" for Django's
default discovery pattern (test*.py) to pick them up -- anything else is silently skipped by
`manage.py test` and only runs when pointed at directly.
"""

import json
from io import StringIO
from unittest.mock import MagicMock

from django.core.management import call_command
from django.test import TestCase, override_settings

from apps.account.models import User
from apps.ai.deep_report_generation.client import MOCK_PATH, DeepReportGenerationClient
from apps.ai.deep_report_generation.memory_candidates import SOURCE as DEEP_SOURCE
from apps.ai.deep_report_generation.memory_candidates import build_memory_candidates
from apps.ai.deep_report_generation.structure import EXACT_COUNTS, RANGE_COUNTS, SECTION_TOPICS
from apps.assessment.data.deep_150 import DEEP_150_ITEMS, FACET_ORDER, SECTION_SIZE
from apps.assessment.models import Answer, Assessment, AssessmentSection, Attempt, Question
from apps.payment.models import Product
from apps.report.models import Memory, Report
from apps.report.repositories.memory_repository import MemoryRepository
from apps.report.services.deep_ai_report_client import DeepAiReportClient
from apps.report.services.deep_patterns import PATTERN_RULES, detect_patterns
from apps.report.services.deep_report_service import DeepReportService
from apps.report.services.deep_scoring_service import DeepScoringService
from apps.report.services.report_service import ReportService
from apps.report.services.scoring_router import ScoringRouter


def _build_deep_assessment():
    """The real 150-item structure, seeded straight from the key module."""
    assessment = Assessment.objects.create(
        slug='deep-150-v1', title='Deep', kind=Assessment.Kind.SUPPLEMENTARY,
        scoring_profile=Assessment.ScoringProfile.FACET_150,
    )
    sections = {}
    questions = {}
    for position, text, reverse_scored, key in DEEP_150_ITEMS:
        section_order = (position - 1) // SECTION_SIZE + 1
        if section_order not in sections:
            sections[section_order] = AssessmentSection.objects.create(
                assessment=assessment, order=section_order, title=f'بخش {section_order}',
            )
        questions[position] = Question.objects.create(
            section=sections[section_order], order=(position - 1) % SECTION_SIZE + 1,
            text=text, question_type=Question.QuestionType.LIKERT,
            scoring=key, reverse_scored=reverse_scored,
        )
    return assessment, questions


class SeedDeepAssessmentCommandTests(TestCase):
    def setUp(self):
        call_command('seed_deep_assessment', stdout=StringIO())
        self.assessment = Assessment.objects.get(slug='deep-150-v1')

    def test_seeds_150_active_questions_in_six_sections(self):
        questions = Question.objects.filter(section__assessment=self.assessment, is_active=True)

        self.assertEqual(questions.count(), 150)
        self.assertEqual(AssessmentSection.objects.filter(assessment=self.assessment).count(), 6)
        self.assertEqual(self.assessment.scoring_profile, Assessment.ScoringProfile.FACET_150)
        self.assertFalse(self.assessment.requires_purchase)
        self.assertTrue(self.assessment.report_requires_purchase)

    def test_every_question_carries_a_scoring_key(self):
        facet_items = 0
        core_items = 0
        for question in Question.objects.filter(section__assessment=self.assessment, is_active=True):
            key = question.scoring
            self.assertIn(key.get('scale'), {'facet', 'core'})
            if key['scale'] == 'facet':
                facet_items += 1
                self.assertIn(key['facet'], FACET_ORDER)
            else:
                core_items += 1

        self.assertEqual(facet_items, 120)
        self.assertEqual(core_items, 30)

    def test_creates_the_paid_product(self):
        product = Product.objects.get(sku='deep-150-v1')

        self.assertTrue(product.is_active)
        self.assertEqual(product.assessment, self.assessment)

    def test_retires_the_placeholder(self):
        legacy = Assessment.objects.create(
            slug='deep-test-v1', title='old', kind=Assessment.Kind.SUPPLEMENTARY, requires_purchase=True,
        )
        Product.objects.create(
            sku='deep-test-v1', title='old', price=1, assessment=legacy, is_active=True,
        )

        call_command('seed_deep_assessment', stdout=StringIO())

        legacy.refresh_from_db()
        self.assertFalse(legacy.is_active)
        self.assertFalse(Product.objects.get(sku='deep-test-v1').is_active)

    def test_is_idempotent(self):
        call_command('seed_deep_assessment', stdout=StringIO())
        call_command('seed_deep_assessment', stdout=StringIO())

        self.assertEqual(
            Question.objects.filter(section__assessment=self.assessment, is_active=True).count(), 150
        )
        self.assertEqual(Assessment.objects.filter(slug='deep-150-v1').count(), 1)

    def test_seeded_questions_score_end_to_end(self):
        """The seed and the scorer have to agree -- a key written by one and read by the other
        is exactly where a silent mismatch would hide."""
        attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-seed')
        for question in Question.objects.filter(section__assessment=self.assessment, is_active=True):
            Answer.objects.create(attempt=attempt, question=question, value=3)

        service = DeepScoringService()
        self.assertTrue(service.is_complete(attempt))
        scores = service.score_attempt(attempt)

        self.assertEqual(len(scores['facet_scores']), 30)
        self.assertEqual({f['raw'] for f in scores['facet_scores']}, {12})
        self.assertEqual(scores['quality_metrics']['core_domain_raw'], {d: 18 for d in 'NEOAC'})


class DeepScoringServiceTests(TestCase):
    def setUp(self):
        self.assessment, self.questions = _build_deep_assessment()
        self.attempt = Attempt.objects.create(assessment=self.assessment, anonymous_id='anon-1')
        self.service = DeepScoringService()

    def _answer_all(self, value=3):
        for question in self.questions.values():
            Answer.objects.create(attempt=self.attempt, question=question, value=value)

    def test_is_complete_false_until_every_item_is_answered(self):
        self._answer_all()
        Answer.objects.filter(attempt=self.attempt).order_by('id').last().delete()

        self.assertFalse(self.service.is_complete(self.attempt))

    def test_is_complete_true_with_all_150(self):
        self._answer_all()

        self.assertTrue(self.service.is_complete(self.attempt))
        self.assertEqual(Answer.objects.filter(attempt=self.attempt).count(), 150)

    def test_scores_cover_exactly_30_facets_and_5_domains(self):
        self._answer_all()

        scores = self.service.score_attempt(self.attempt)

        self.assertEqual([f['code'] for f in scores['facet_scores']], FACET_ORDER)
        self.assertEqual([d['code'] for d in scores['domain_scores']], ['N', 'E', 'O', 'A', 'C'])

    def test_all_threes_land_mid_scale(self):
        """Every item answered 3 -> raw 12 of 4..20 -> provisional 50, for every facet.

        Also pins the reverse-scoring path: 6-3 is still 3, so a mis-set reverse flag would
        not show up here -- that is what the asymmetric test below is for.
        """
        self._answer_all(value=3)

        scores = self.service.score_attempt(self.attempt)

        self.assertEqual({f['raw'] for f in scores['facet_scores']}, {12})
        self.assertEqual({f['provisional'] for f in scores['facet_scores']}, {50})
        self.assertEqual({f['level'] for f in scores['facet_scores']}, {'mid'})
        self.assertEqual({d['index'] for d in scores['domain_scores']}, {50})

    def test_reverse_items_are_flipped(self):
        """Answer 5 to everything. Each facet has exactly 3 direct + 1 reverse item, so
        raw = 3*5 + (6-5) = 16, not the 20 an unflipped sum would give."""
        self._answer_all(value=5)

        scores = self.service.score_attempt(self.attempt)

        self.assertEqual({f['raw'] for f in scores['facet_scores']}, {16})
        self.assertEqual({f['provisional'] for f in scores['facet_scores']}, {75})
        self.assertEqual({f['level'] for f in scores['facet_scores']}, {'high'})

    def test_domain_index_is_the_mean_of_its_six_facets(self):
        self._answer_all(value=3)
        # Push N1's four items to the top of the scale; its reverse item takes a 1 so it also
        # adjusts to 5, giving raw 20 -> provisional 100.
        for position, _text, reverse_scored, key in DEEP_150_ITEMS:
            if key['scale'] == 'facet' and key['facet'] == 'N1':
                Answer.objects.filter(attempt=self.attempt, question=self.questions[position]).update(
                    value=1 if reverse_scored else 5
                )

        scores = self.service.score_attempt(self.attempt)
        by_code = {f['code']: f for f in scores['facet_scores']}
        n_domain = next(d for d in scores['domain_scores'] if d['code'] == 'N')

        self.assertEqual(by_code['N1']['provisional'], 100)
        self.assertEqual(by_code['N2']['provisional'], 50)
        # (100 + 50*5) / 6 = 58.33 -> 58
        self.assertEqual(n_domain['index'], 58)

    def test_core_items_feed_quality_metrics_only(self):
        self._answer_all(value=3)

        scores = self.service.score_attempt(self.attempt)

        # 6 core items x adjusted 3 = 18, for each of the five domains.
        self.assertEqual(scores['quality_metrics']['core_domain_raw'], {d: 18 for d in 'NEOAC'})
        # 18 of 6..30 rescales to 50, and the facet index is also 50 -> no gap.
        self.assertEqual(scores['quality_metrics']['core_facet_gap'], {d: 0.0 for d in 'NEOAC'})
        # And they contribute nothing to the facet side.
        self.assertEqual({f['raw'] for f in scores['facet_scores']}, {12})

    @override_settings(DEEP_LEVEL_LOW_MAX=60, DEEP_LEVEL_HIGH_MIN=80)
    def test_level_bands_come_from_settings_not_literals(self):
        """The same answers that are 'mid' at 35/65 must be 'low' at 60/80."""
        self._answer_all(value=3)

        scores = self.service.score_attempt(self.attempt)

        self.assertEqual({f['level'] for f in scores['facet_scores']}, {'low'})

    def test_band_boundaries_are_inclusive_at_the_top_of_mid(self):
        service = DeepScoringService()

        self.assertEqual(service._level_for(34), 'low')
        self.assertEqual(service._level_for(35), 'mid')
        self.assertEqual(service._level_for(65), 'mid')
        self.assertEqual(service._level_for(66), 'high')


class DeepPatternTests(TestCase):
    @staticmethod
    def _facets(**levels):
        return [{'code': code, 'level': levels.get(code, 'mid')} for code in FACET_ORDER]

    def test_no_patterns_on_a_flat_profile(self):
        self.assertEqual(detect_patterns(self._facets()), [])

    def test_every_rule_fires_on_its_own_conditions(self):
        for pattern_id, conditions in PATTERN_RULES.items():
            with self.subTest(pattern=pattern_id):
                facets = self._facets(**{code: level for code, level in conditions})

                self.assertIn(pattern_id, detect_patterns(facets))

    def test_partial_match_does_not_fire(self):
        # N1 high but C6 left at mid -- the rule needs both.
        self.assertEqual(detect_patterns(self._facets(N1='high')), [])

    def test_mid_satisfies_neither_side(self):
        self.assertEqual(detect_patterns(self._facets(O5='mid', C5='mid')), [])


class DeepAiPayloadTests(TestCase):
    def setUp(self):
        self.client = DeepAiReportClient(client=MagicMock())

    def _payload(self, **overrides):
        kwargs = {
            'facet_scores': [
                {'code': code, 'domain': code[0], 'raw': 12, 'provisional': 50, 'level': 'mid'}
                for code in FACET_ORDER
            ],
            'domain_scores': [
                {'code': d, 'index': 50, 'level': 'mid'} for d in 'NEOAC'
            ],
            'active_patterns': ['N1_high_C6_high'],
            'demographics': {'birth_year': 1374, 'gender': 'female', 'life_situation': 'employed', 'goal': 'purpose'},
        }
        kwargs.update(overrides)
        return self.client.build_payload(**kwargs)

    def test_payload_has_exactly_30_facets_and_5_domains(self):
        payload = self._payload()

        self.assertEqual(len(payload['facet_scores']), 30)
        self.assertEqual(len(payload['domain_scores']), 5)
        self.assertEqual(payload['report_type'], 'deep')

    def test_core_domain_raw_is_never_sent(self):
        """deep_report_spec_v1_2.md §2.3 -- the core cross-check is stored, never sent to the model."""
        serialized = json.dumps(self._payload())

        self.assertNotIn('core_domain_raw', serialized)
        self.assertNotIn('core_facet_gap', serialized)

    def test_gender_is_never_sent(self):
        serialized = json.dumps(self._payload())

        self.assertNotIn('gender', serialized)
        self.assertNotIn('female', serialized)

    def test_context_profile_carries_age_and_situation(self):
        payload = self._payload()

        self.assertIn('age', payload['context_profile'])
        self.assertEqual(payload['context_profile']['life_situation'], 'employed')
        self.assertEqual(payload['context_profile']['current_goal'], 'purpose')

    def test_empty_active_patterns_is_valid(self):
        self.assertEqual(self._payload(active_patterns=[])['active_patterns'], [])


class DeepMockFixtureTests(TestCase):
    """The mock stands in for the real generation, so the §6.1 counts have to be guarded here
    or the rest of the pipeline is being verified against a shape the real thing won't match."""

    @classmethod
    def setUpTestData(cls):
        cls.report = json.loads(MOCK_PATH.read_text(encoding='utf-8'))['report']

    def test_exact_counts(self):
        for field, expected in EXACT_COUNTS.items():
            with self.subTest(field=field):
                value = self.report
                for part in field.split('.'):
                    value = value[part]

                self.assertEqual(len(value), expected)

    def test_range_counts(self):
        for field, (low, high) in RANGE_COUNTS.items():
            with self.subTest(field=field):
                value = self.report
                for part in field.split('.'):
                    value = value[part]

                self.assertGreaterEqual(len(value), low)
                self.assertLessEqual(len(value), high)

    def test_thirty_facets_across_five_domains(self):
        self.assertEqual([d['code'] for d in self.report['domains']], ['N', 'E', 'O', 'A', 'C'])
        for domain in self.report['domains']:
            self.assertEqual(len(domain['facets']), 6)
        codes = [f['code'] for d in self.report['domains'] for f in d['facets']]
        self.assertEqual(codes, FACET_ORDER)

    def test_every_facet_is_written_in_both_directions(self):
        """§8: a facet described only as an asset teaches 'high = good', which is the one
        reading the whole instrument is built to avoid."""
        for domain in self.report['domains']:
            for facet in domain['facets']:
                with self.subTest(facet=facet['code']):
                    self.assertTrue(facet['when_it_works'].strip())
                    self.assertTrue(facet['when_it_costs'].strip())

    def test_section_topics_match_verbatim_and_in_order(self):
        for key, topics in SECTION_TOPICS.items():
            with self.subTest(section=key):
                self.assertEqual([row['topic'] for row in self.report[key]['rows']], topics)
                self.assertTrue(self.report[key]['closing'].strip())

    def test_every_strength_carries_its_overuse(self):
        for item in self.report['strengths']['items']:
            self.assertTrue(item['overuse'].strip())


class DeepMockClientTests(TestCase):
    def setUp(self):
        # These exercise the fixed-mock path explicitly; pin the flag off so a developer or
        # CI environment with DEEP_REPORT_AI_ENABLED=true does not turn them into real,
        # paid, eight-call API tests.
        import os
        from unittest.mock import patch
        patcher = patch.dict(os.environ, {'DEEP_REPORT_AI_ENABLED': 'false'})
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_real_levels_replace_the_fixture_placeholders(self):
        payload = {
            'facet_scores': [{'code': code, 'score': 90, 'level': 'high'} for code in FACET_ORDER],
            'domain_scores': [{'code': d, 'score': 90, 'level': 'high'} for d in 'NEOAC'],
            'active_patterns': [],
        }

        response = DeepReportGenerationClient().generate(payload)

        levels = {f['level'] for d in response['report']['domains'] for f in d['facets']}
        self.assertEqual(levels, {'high'})
        self.assertEqual({d['level'] for d in response['report']['domains_overview']}, {'high'})

    def test_mock_reports_zero_cost_honestly(self):
        response = DeepReportGenerationClient().generate({'facet_scores': [], 'domain_scores': []})

        self.assertEqual(response['status'], 'ok')
        self.assertEqual(response['generation_meta']['model_used'], 'mock')
        self.assertEqual(response['generation_meta']['input_tokens'], 0)


class DeepMemoryCandidateTests(TestCase):
    def setUp(self):
        self.report = {
            'identity_line': 'یک جمله',
            'top_strengths': ['قوت ۱', 'قوت ۲', 'قوت ۳'],
            'growth_priorities': ['رشد ۱', 'رشد ۲', 'رشد ۳'],
            'blind_spots': {'items': [{'hypothesis': 'نقطه کور'}]},
            'share': {'hook': 'قلاب', 'line': 'خط'},
        }

    def test_exactly_four_candidates_from_the_deep_source(self):
        candidates = build_memory_candidates(self.report)

        self.assertEqual(len(candidates), 4)
        self.assertEqual({c['source'] for c in candidates}, {DEEP_SOURCE})
        self.assertEqual(
            [c['memory_type'] for c in candidates],
            ['core_pattern', 'strength', 'growth_edge', 'growth_focus'],
        )

    def test_blind_spots_and_share_never_become_memories(self):
        """§6.3 -- blind spots are the report's most delicate content and injecting them into
        every chat turn risks opening on someone's weak point."""
        serialized = json.dumps(build_memory_candidates(self.report), ensure_ascii=False)

        self.assertNotIn('نقطه کور', serialized)
        self.assertNotIn('قلاب', serialized)

    def test_growth_focus_is_the_top_priority(self):
        focus = next(c for c in build_memory_candidates(self.report) if c['memory_type'] == 'growth_focus')

        self.assertEqual(focus['text_memory'], 'رشد ۱')

    def test_strengths_merge_into_one_row(self):
        strength = next(c for c in build_memory_candidates(self.report) if c['memory_type'] == 'strength')

        self.assertEqual(strength['text_memory'], '- قوت ۱\n- قوت ۲\n- قوت ۳')


class DeepMemorySupersessionTests(TestCase):
    """§6.3: supersession is keyed on (user, memory_type, source). Without the source in the
    key, generating a deep report would silently erase the initial report's memories."""

    def setUp(self):
        self.user = User.objects.create(phone_number='09120000001')
        self.repository = MemoryRepository()

    def _upsert(self, source, text):
        return self.repository.upsert(
            user=self.user, memory_type=Memory.MemoryType.CORE_PATTERN, text_memory=text,
            source=source, confidence='medium', sensitivity_level='low',
        )

    def test_a_different_source_starts_its_own_lineage(self):
        self._upsert('initial_report', 'از تست اولیه')
        self._upsert(DEEP_SOURCE, 'از تست عمیق')

        memories = Memory.objects.filter(user=self.user, memory_type=Memory.MemoryType.CORE_PATTERN)
        self.assertEqual(memories.count(), 2)
        self.assertEqual(
            set(memories.values_list('text_memory', flat=True)), {'از تست اولیه', 'از تست عمیق'}
        )

    def test_the_same_source_still_supersedes_in_place(self):
        self._upsert(DEEP_SOURCE, 'نسخه اول')
        self._upsert(DEEP_SOURCE, 'نسخه دوم')

        memories = Memory.objects.filter(user=self.user, memory_type=Memory.MemoryType.CORE_PATTERN)
        self.assertEqual(memories.count(), 1)
        self.assertEqual(memories.first().text_memory, 'نسخه دوم')


class ScoringRouterTests(TestCase):
    def test_routes_on_the_scoring_profile_field(self):
        router = ScoringRouter()
        initial = Assessment.objects.create(slug='initial-v1', title='I')
        deep = Assessment.objects.create(
            slug='deep-v1', title='D', scoring_profile=Assessment.ScoringProfile.FACET_150,
        )

        self.assertIsInstance(router.for_assessment(deep), DeepScoringService)
        self.assertNotIsInstance(router.for_assessment(initial), DeepScoringService)


class DeepReportGenerationFlowTests(TestCase):
    def setUp(self):
        # This class drives DeepReportService end to end against the fixed mock -- pin the
        # flag off so an environment with DEEP_REPORT_AI_ENABLED=true does not make these
        # hit the real eight-call pipeline over the network.
        import os
        from unittest.mock import patch
        patcher = patch.dict(os.environ, {'DEEP_REPORT_AI_ENABLED': 'false'})
        patcher.start()
        self.addCleanup(patcher.stop)

        self.assessment, self.questions = _build_deep_assessment()
        self.user = User.objects.create(phone_number='09120000002')
        self.attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        for question in self.questions.values():
            Answer.objects.create(attempt=self.attempt, question=question, value=3)

    def test_completing_a_deep_attempt_stores_scores_and_queues_the_task(self):
        service = ReportService()
        from unittest.mock import patch
        # The enqueue is deferred to transaction.on_commit, and TestCase never commits --
        # captureOnCommitCallbacks(execute=True) runs the callbacks the commit would have.
        with patch('apps.report.tasks.generate_deep_report.delay') as delay:
            with self.captureOnCommitCallbacks(execute=True):
                report = service.generate_for_attempt(self.attempt)

        self.assertEqual(report.report_type, Report.ReportType.DEEP)
        self.assertEqual(report.status, Report.Status.GENERATING)
        self.assertEqual(len(report.facet_scores), 30)
        self.assertEqual(len(report.domain_scores), 5)
        self.assertEqual(report.quality_metrics['core_domain_raw'], {d: 18 for d in 'NEOAC'})
        delay.assert_called_once_with(self.attempt.id)

    def test_generation_fills_in_the_row_and_persists_memories(self):
        service = ReportService()
        from unittest.mock import patch
        with patch('apps.report.tasks.generate_deep_report.delay'):
            report = service.generate_for_attempt(self.attempt)

        DeepReportService().generate(self.attempt.id)

        report.refresh_from_db()
        self.assertEqual(report.status, Report.Status.OK)
        self.assertEqual(report.report_version, 'deep_v1')
        self.assertEqual(len(report.memory_candidates), 4)
        self.assertIsNotNone(report.memories_persisted_at)
        self.assertEqual(Memory.objects.filter(user=self.user, source=DEEP_SOURCE).count(), 4)

    def test_generation_stores_an_error_instead_of_raising(self):
        service = ReportService()
        from unittest.mock import patch
        with patch('apps.report.tasks.generate_deep_report.delay'):
            report = service.generate_for_attempt(self.attempt)

        failing_client = MagicMock()
        failing_client.build_payload = DeepAiReportClient.build_payload
        failing_client.generate.side_effect = RuntimeError('provider down')
        DeepReportService(ai_client=failing_client).generate(self.attempt.id)

        report.refresh_from_db()
        self.assertEqual(report.status, Report.Status.ERROR)
        self.assertEqual(report.error_code, 'generation_failed')

    def test_api_response_leaks_no_number_and_no_facet_code(self):
        """§2.4 and §9: the stored row keeps raw/provisional for future norming, but the
        response is levels and Persian titles only."""
        service = ReportService()
        from unittest.mock import patch
        with patch('apps.report.tasks.generate_deep_report.delay'):
            service.generate_for_attempt(self.attempt)
        DeepReportService().generate(self.attempt.id)

        data = service.get_report(attempt_id=self.attempt.id, user=self.user, anonymous_id=None)

        for facet in data['facet_scores']:
            self.assertNotIn('raw', facet)
            self.assertNotIn('provisional', facet)
            self.assertIn(facet['level'], {'low', 'mid', 'high'})
        for domain in data['domain_scores']:
            self.assertNotIn('index', domain)
        serialized = json.dumps(data, ensure_ascii=False)
        self.assertNotIn('core_domain_raw', serialized)
        self.assertNotIn('core_facet_gap', serialized)

    def test_facet_titles_are_persian(self):
        service = ReportService()
        from unittest.mock import patch
        with patch('apps.report.tasks.generate_deep_report.delay'):
            service.generate_for_attempt(self.attempt)
        DeepReportService().generate(self.attempt.id)

        data = service.get_report(attempt_id=self.attempt.id, user=self.user, anonymous_id=None)
        titles = {f['code']: f['title'] for f in data['facet_scores']}

        self.assertEqual(titles['N1'], 'اضطراب')
        self.assertEqual(titles['C6'], 'سنجیدگی')
        self.assertEqual(data['title'], 'پروفایل توسعه فردی')

    def test_generating_state_is_reported_to_the_client(self):
        service = ReportService()
        from unittest.mock import patch
        with patch('apps.report.tasks.generate_deep_report.delay'):
            service.generate_for_attempt(self.attempt)

        data = service.get_report(attempt_id=self.attempt.id, user=self.user, anonymous_id=None)

        self.assertEqual(data['status'], 'generating')

    def test_history_uses_the_deep_identity_line(self):
        service = ReportService()
        from unittest.mock import patch
        with patch('apps.report.tasks.generate_deep_report.delay'):
            service.generate_for_attempt(self.attempt)
        DeepReportService().generate(self.attempt.id)
        Attempt.objects.filter(id=self.attempt.id).update(
            status=Attempt.Status.COMPLETED, completed_at='2026-01-01T00:00:00Z',
        )

        history = service.get_history(self.user)

        self.assertEqual(len(history), 1)
        self.assertEqual(history[0]['report_type'], 'deep')
        self.assertTrue(history[0]['summary_one_line'])


class DeepReportPayAfterTestTests(TestCase):
    """Assessment.report_requires_purchase: scores are stored at completion, but no AI call is
    queued and nothing leaves the service until a payment unlocks the report."""

    def setUp(self):
        import os
        from unittest.mock import patch
        patcher = patch.dict(os.environ, {'DEEP_REPORT_AI_ENABLED': 'false'})
        patcher.start()
        self.addCleanup(patcher.stop)

        self.assessment, self.questions = _build_deep_assessment()
        self.user = User.objects.create(phone_number='09120000003')
        self.attempt = Attempt.objects.create(assessment=self.assessment, user=self.user)
        for question in self.questions.values():
            Answer.objects.create(attempt=self.attempt, question=question, value=3)
        self.service = ReportService()

    def _complete_unpaid(self):
        from unittest.mock import patch
        with patch('apps.report.tasks.generate_deep_report.delay') as delay:
            with self.captureOnCommitCallbacks(execute=True):
                report = self.service.generate_for_attempt(self.attempt, awaiting_payment=True)
        return report, delay

    def test_unpaid_completion_stores_scores_but_queues_no_generation(self):
        report, delay = self._complete_unpaid()

        self.assertEqual(report.status, Report.Status.AWAITING_PAYMENT)
        self.assertEqual(len(report.facet_scores), 30)
        delay.assert_not_called()

    def test_locked_response_carries_no_scores(self):
        self._complete_unpaid()

        data = self.service.get_report(attempt_id=self.attempt.id, user=self.user, anonymous_id=None)

        self.assertEqual(data['status'], 'awaiting_payment')
        self.assertTrue(data['payment_required'])
        self.assertEqual(set(data), {'status', 'report_type', 'report_version', 'payment_required'})

    def test_locked_report_cannot_be_emailed_or_turned_into_a_step(self):
        from apps.report.services.exceptions import ReportNotReadyException
        self._complete_unpaid()

        with self.assertRaises(ReportNotReadyException):
            self.service.accept_step(attempt_id=self.attempt.id, index=1, user=self.user)
        with self.assertRaises(ReportNotReadyException):
            self.service.email_report(attempt_id=self.attempt.id, user=self.user, email='a@b.co')

    def test_unlock_after_payment_queues_generation_exactly_once(self):
        from unittest.mock import patch
        self._complete_unpaid()

        with patch('apps.report.services.report_service.generate_deep_report.delay') as delay:
            with self.captureOnCommitCallbacks(execute=True):
                self.service.unlock_after_payment(self.attempt.id)
            with self.captureOnCommitCallbacks(execute=True):
                self.service.unlock_after_payment(self.attempt.id)

        delay.assert_called_once_with(self.attempt.id)
        self.assertEqual(Report.objects.get(attempt=self.attempt).status, Report.Status.GENERATING)

    def test_unlocked_report_generates_and_is_then_served(self):
        from unittest.mock import patch
        self._complete_unpaid()
        with patch('apps.report.services.report_service.generate_deep_report.delay'):
            self.service.unlock_after_payment(self.attempt.id)

        DeepReportService().generate(self.attempt.id)
        data = self.service.get_report(attempt_id=self.attempt.id, user=self.user, anonymous_id=None)

        self.assertEqual(data['report_type'], 'deep')
        self.assertEqual(len(data['facet_scores']), 30)
