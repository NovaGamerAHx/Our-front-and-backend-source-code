from django.test import TestCase

from apps.report.services.pdf_service import ReportPdfService


class ReportPdfServiceTests(TestCase):
    """Real WeasyPrint integration test -- the one thing ReportServiceEmailReportTests can't
    cover, since it mocks pdf_service entirely. Needs WeasyPrint + its native libs (pango,
    cairo, gdk-pixbuf) actually installed wherever this runs -- same set the Dockerfile adds."""

    def test_render_pdf_returns_pdf_bytes(self):
        pdf_bytes = ReportPdfService().render_pdf("<html><body>سلام دنیا</body></html>")
        self.assertTrue(pdf_bytes.startswith(b"%PDF"))

    def test_font_context_returns_base64_strings(self):
        ctx = ReportPdfService().font_context()
        self.assertIn("vazirmatn_regular_b64", ctx)
        self.assertIn("vazirmatn_bold_b64", ctx)
        self.assertTrue(ctx["vazirmatn_regular_b64"])
        self.assertTrue(ctx["vazirmatn_bold_b64"])
