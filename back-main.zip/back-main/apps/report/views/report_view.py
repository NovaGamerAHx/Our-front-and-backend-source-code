from drf_spectacular.utils import extend_schema
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.views import APIView

from apps.action_steps.serializers.action_step_serializer import ActionStepSerializer
from apps.report.serializers.report_serializer import (
    ReportAttemptHistoryItemSerializer,
    ReportEmailRequestSerializer,
    ReportHistoryItemSerializer,
)
from apps.report.services.exceptions import (
    ReportAccessDeniedException,
    ReportEmailDeliveryFailedException,
    ReportEmailThrottledException,
    ReportNotFoundException,
    ReportNotReadyException,
    ReportPdfGenerationFailedException,
    ReportRetryNotAllowedException,
    SuggestedStepNotFoundException,
)
from apps.report.services.report_service import ReportService
from faraman_back.lang.utils import get_message
from faraman_back.utils.responses import ApiResponse
from faraman_back.utils.schema import error_responses


class ReportHistoryAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.report_service = ReportService()

    @extend_schema(
        description="Returns the authenticated user's report history: one row per completed, "
                    "scored attempt with a report, newest first.",
        tags=["Report"],
        responses=ReportHistoryItemSerializer(many=True),
    )
    def get(self, request):
        data = self.report_service.get_history(request.user)

        return ApiResponse.success(data=data)


class ReportAttemptsHistoryAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.report_service = ReportService()

    @extend_schema(
        description="Returns the authenticated user's full attempts history: one row per "
                    "attempt with a report of any status (generating/ok/error), newest first. "
                    "Unlike /history/ (ok-only), this surfaces a still-generating or failed "
                    "attempt so it can be retried without re-taking the test.",
        tags=["Report"],
        responses=ReportAttemptHistoryItemSerializer(many=True),
    )
    def get(self, request):
        data = self.report_service.get_attempts_history(request.user)

        return ApiResponse.success(data=data)


class ReportDetailAPIView(APIView):
    permission_classes = [AllowAny]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.report_service = ReportService()

    @extend_schema(
        description="Returns the initial personality report for a completed attempt. Gated "
                    "server-side : unauthenticated requests get only the "
                    "teaser `stage=preview` payload, authenticated requests get the full report.",
        tags=["Report"],
        responses=error_responses(ReportNotFoundException, ReportAccessDeniedException),
    )
    def get(self, request, attempt_id):
        user = request.user if request.user.is_authenticated else None

        data = self.report_service.get_report(
            attempt_id=attempt_id,
            user=user,
            anonymous_id=request.anonymous_id,
        )

        return ApiResponse.success(data=data)


class ReportRetryAPIView(APIView):
    permission_classes = [AllowAny]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.report_service = ReportService()

    @extend_schema(
        description="Re-dispatches generation for a report that ended in ERROR, reusing the "
                    "attempt's already-scored answers -- no re-test required. AllowAny, same "
                    "ownership gate as GET report detail (anonymous_id or user), since "
                    "generation can fail before the visitor has ever logged in. Returns the "
                    "`generating` shape so the caller can poll it the same way as a fresh "
                    "attempt.",
        tags=["Report"],
        request=None,
        responses=error_responses(
            ReportNotFoundException, ReportAccessDeniedException, ReportRetryNotAllowedException,
        ),
    )
    def post(self, request, attempt_id):
        user = request.user if request.user.is_authenticated else None

        data = self.report_service.retry_generation(
            attempt_id=attempt_id, user=user, anonymous_id=request.anonymous_id,
        )

        return ApiResponse.success(message=get_message("report_retry_started"), data=data)


class ReportStepAcceptAPIView(APIView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.report_service = ReportService()

    @extend_schema(
        description="Accepts the report's suggested_step/small_action at the given 1-based "
                    "index (1-3), creating a row in the action-steps table. No request body -- "
                    "the step's text/deadline/substeps come from the report itself.",
        tags=["Report"],
        request=None,
        responses={
            200: ActionStepSerializer,
            **error_responses(
                ReportNotFoundException, ReportAccessDeniedException,
                ReportNotReadyException, SuggestedStepNotFoundException,
            ),
        },
    )
    def post(self, request, attempt_id, index):
        action_step = self.report_service.accept_step(attempt_id=attempt_id, index=index, user=request.user)

        return ApiResponse.success(
            message=get_message("created_successfully"),
            data=ActionStepSerializer(action_step).data,
        )


class ReportEmailAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.report_service = ReportService()

    @extend_schema(
        description="Emails the report (initial or deep) to the given address. The address is "
                    "not persisted -- it's sent ad hoc, whatever the requester types into the "
                    "report page's email card each time.",
        tags=["Report"],
        request=ReportEmailRequestSerializer,
        responses={
            200: None,
            **error_responses(
                ReportNotFoundException, ReportAccessDeniedException, ReportNotReadyException,
                ReportEmailThrottledException, ReportEmailDeliveryFailedException,
                ReportPdfGenerationFailedException,
            ),
        },
    )
    def post(self, request, attempt_id):
        serializer = ReportEmailRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        self.report_service.email_report(
            attempt_id=attempt_id, user=request.user, email=serializer.validated_data["email"],
        )

        return ApiResponse.success(message=get_message("report_email_sent"))
