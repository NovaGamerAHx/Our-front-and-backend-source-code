from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from apps.report.serializers.workspace_serializer import RejectFindingSerializer
from apps.report.services.workspace_service import WorkspaceReportService
from faraman_back.utils.responses import ApiResponse


class WorkspaceContextAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        return ApiResponse.success(data=WorkspaceReportService().context(request.user))


class RejectFindingAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, attempt_id):
        serializer = RejectFindingSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        WorkspaceReportService().reject(attempt_id=attempt_id, user=request.user, key=serializer.validated_data["key"])
        return ApiResponse.success(data={"rejected": True})
