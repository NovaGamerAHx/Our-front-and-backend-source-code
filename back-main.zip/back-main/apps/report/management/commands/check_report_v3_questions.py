"""Pre-flight check for REPORT_INITIAL_VERSION=report_v3.

report_v3 quotes the user's own answers back at the model as evidence, so it can only be
switched on for an assessment whose 30 items are exactly the ones the v3 prompt describes --
same wording, same per-dimension order, same reverse flags. This command answers "is this
environment safe to switch?" without generating anything or spending a model call.

    python manage.py check_report_v3_questions
    python manage.py check_report_v3_questions --slug test-likert-v2

Exit code 0 = the assessment matches and report_v3 is safe to enable. Exit code 1 = it does
not, and every mismatch is listed. Run it before flipping REPORT_INITIAL_VERSION, and again
after any change to the question bank.
"""

from django.core.management.base import BaseCommand, CommandError

from apps.ai.report_generation.question_map_v3 import (
    MappedQuestion,
    QuestionMapError,
    V3_QUESTION_IDS,
    map_questions,
)
from apps.assessment.models import Assessment, Question

DEFAULT_SLUG = "test-likert-v2"


class Command(BaseCommand):
    help = (
        "Verifies that an assessment's 30 questions match the report_v3 question contract "
        "(wording, per-dimension order and reverse_scored flags). Run this before setting "
        "REPORT_INITIAL_VERSION=report_v3."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--slug",
            default=DEFAULT_SLUG,
            help=f"Assessment slug to check (default: {DEFAULT_SLUG}).",
        )

    def handle(self, *args, **options):
        slug = options["slug"]
        assessment = Assessment.objects.filter(slug=slug).first()
        if assessment is None:
            raise CommandError(f"No assessment with slug {slug!r}.")

        questions = [
            MappedQuestion(
                external_id=question.id,
                dimension=question.section.title,
                order=question.order,
                text=question.text,
                reverse_scored=question.reverse_scored,
            )
            for question in (
                Question.objects.filter(section__assessment=assessment, is_active=True)
                .select_related("section")
                .order_by("section__order", "order")
            )
        ]

        try:
            mapping = map_questions(questions)
        except QuestionMapError as e:
            self.stderr.write(
                self.style.ERROR(
                    f"Assessment {slug!r} does NOT match the report_v3 question contract "
                    f"({len(e.problems)} problem(s)). Do not set REPORT_INITIAL_VERSION=report_v3."
                )
            )
            for problem in e.problems:
                self.stderr.write(f"  - {problem}")
            raise CommandError("report_v3 question contract not satisfied")

        self.stdout.write(
            self.style.SUCCESS(
                f"Assessment {slug!r} matches the report_v3 question contract: "
                f"all {len(V3_QUESTION_IDS)} questions mapped."
            )
        )
        for qid in V3_QUESTION_IDS:
            self.stdout.write(f"  {qid} -> question id {mapping[qid]}")
