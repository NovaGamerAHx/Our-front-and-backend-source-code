from django import template

register = template.Library()


@register.filter
def get_item(mapping: dict, key: str):
    """Dict lookup by a key held in a template variable, which the built-in syntax can't do --
    the PDF templates use it to pick an embedded image by the key the context builder chose."""
    return mapping.get(key, "")
