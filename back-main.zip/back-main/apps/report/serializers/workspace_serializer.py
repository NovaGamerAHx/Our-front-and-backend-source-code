from rest_framework import serializers


class RejectFindingSerializer(serializers.Serializer):
    key = serializers.CharField(max_length=64)
