from rest_framework import serializers

from apps.report.models import Report


class ReportHistoryItemSerializer(serializers.Serializer):
    attempt_id = serializers.IntegerField()
    report_id = serializers.IntegerField()
    # History mixes both products, so the client needs to know which one a row is before it
    # decides where to link. `summary_one_line` comes from summary.one_line for an initial
    # report and identity_line for a deep one.
    report_type = serializers.ChoiceField(choices=Report.ReportType.choices)
    completed_at = serializers.DateTimeField()
    summary_one_line = serializers.CharField()


class ReportAttemptHistoryItemSerializer(serializers.Serializer):
    attempt_id = serializers.IntegerField()
    report_id = serializers.IntegerField()
    report_type = serializers.ChoiceField(choices=Report.ReportType.choices)
    # Unlike ReportHistoryItemSerializer (OK-only), this list mixes every status so a
    # generating/error row is visible -- the کاوش attempts-history page's whole point.
    status = serializers.ChoiceField(choices=Report.Status.choices)
    completed_at = serializers.DateTimeField()
    # Blank for anything other than status=ok/error respectively -- there's nothing to show yet.
    summary_one_line = serializers.CharField(allow_blank=True)
    error_message = serializers.CharField(allow_blank=True)


class ReportEmailRequestSerializer(serializers.Serializer):
    email = serializers.EmailField()
