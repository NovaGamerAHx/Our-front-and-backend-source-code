from django.urls import path

from apps.report.views.report_view import (
    ReportAttemptsHistoryAPIView,
    ReportDetailAPIView,
    ReportEmailAPIView,
    ReportHistoryAPIView,
    ReportRetryAPIView,
    ReportStepAcceptAPIView,
)

from apps.report.views.workspace_view import WorkspaceContextAPIView, RejectFindingAPIView

app_name = "report"

urlpatterns = [
    path("workspace-context/", WorkspaceContextAPIView.as_view(), name="workspace_context"),
    path("attempts/<int:attempt_id>/reject-finding/", RejectFindingAPIView.as_view(), name="reject_finding"),
    path("history/", ReportHistoryAPIView.as_view(), name="report_history"),
    path("attempts-history/", ReportAttemptsHistoryAPIView.as_view(), name="report_attempts_history"),
    path("attempts/<int:attempt_id>/", ReportDetailAPIView.as_view(), name="report_detail"),
    path("attempts/<int:attempt_id>/retry/", ReportRetryAPIView.as_view(), name="report_retry"),
    path(
        "attempts/<int:attempt_id>/steps/<int:index>/accept/",
        ReportStepAcceptAPIView.as_view(),
        name="report_step_accept",
    ),
    path("attempts/<int:attempt_id>/email/", ReportEmailAPIView.as_view(), name="report_email"),
]
