from celery import shared_task

from apps.report.services.deep_report_service import DeepReportService


@shared_task(name="report.generate_deep_report")
def generate_deep_report(attempt_id: int):
    """Fills in a deep report's GENERATING row (deep_report_spec_v1_2.md §5).

    No autoretry: DeepReportService.generate() already swallows failures into a stored `error`
    report, and the eight underlying calls have their own attempt ladder (§5.1). Retrying the
    whole task on top of that would re-pay for calls that already succeeded.
    """
    DeepReportService().generate(attempt_id)


@shared_task(name="report.generate_initial_report")
def generate_initial_report(attempt_id: int):
    """Fills in an initial report's GENERATING row (see ReportService._start_initial_generation).

    No autoretry: ReportService.generate_initial() already turns a failure into a stored `error`
    report, same reasoning as generate_deep_report above.
    """
    # Local import breaks a real cycle: report_service.py imports this module at the top (for
    # generate_deep_report/generate_initial_report), so importing ReportService up here would
    # make tasks.py <-> report_service.py circular.
    from apps.report.services.report_service import ReportService

    ReportService().generate_initial(attempt_id)
