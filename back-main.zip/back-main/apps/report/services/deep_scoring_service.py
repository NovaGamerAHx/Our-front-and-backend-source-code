"""Deterministic scoring for the 150-item deep test (deep_report_spec_v1_2.md §2, §3.2).

The hard rule this file exists to enforce: scoring happens entirely in the backend and is
fully deterministic. The AI produces no number and changes no number (§2 intro).

Reads each item's key off `Question.scoring` (written by seed_deep_assessment from
apps.assessment.data.deep_150) rather than from the section title, which is how the initial
30-item test works. Section titles are presentational here.
"""

from collections import defaultdict

from django.conf import settings

from apps.assessment.data.deep_150 import DOMAIN_ORDER, FACET_ORDER
from apps.assessment.models import Attempt
from apps.assessment.repositories.assessment_repository import AssessmentRepository

# Facet Raw spans 4..20 (4 items x 1..5); Core Domain Raw spans 6..30 (6 items x 1..5).
FACET_RAW_MIN, FACET_RAW_MAX = 4, 20
CORE_RAW_MIN, CORE_RAW_MAX = 6, 30

LEVEL_LOW = "low"
LEVEL_MID = "mid"
LEVEL_HIGH = "high"


class DeepScoringService:
    """Computes facet scores, domain indices and the core cross-check for one deep attempt.

    Pure computation: no storage, no AI, no user-facing strings. `score_attempt` returns
    everything DeepReportService needs to persist and to build the AI payload.
    """

    def __init__(self, assessment_repository=None):
        self.assessment_repository = assessment_repository or AssessmentRepository()

    @staticmethod
    def _level_for(provisional: float) -> str:
        """Three bands only (§2.4). The cut points are settings, never literals: no norming
        has been done, so they are provisional and get retuned after the pilot."""
        if provisional < settings.DEEP_LEVEL_LOW_MAX:
            return LEVEL_LOW
        if provisional <= settings.DEEP_LEVEL_HIGH_MIN:
            return LEVEL_MID
        return LEVEL_HIGH

    @staticmethod
    def _to_provisional(raw: int, raw_min: int, raw_max: int) -> int:
        """Linear rescale of a raw sum onto 0..100 (§2.2).

        NOT a percentage and NOT a percentile -- just a display transform. Calling it either
        of those in any user-facing text is exactly the claim §2.4 forbids.
        """
        return round((raw - raw_min) / (raw_max - raw_min) * 100)

    def get_required_question_ids(self, attempt: Attempt) -> set[int]:
        """Every active question on the assessment -- all 150 count, core items included.

        Unlike the initial test there is no "unscored section" concept here: a deep attempt is
        complete only when the whole instrument is answered.
        """
        return self.assessment_repository.get_active_question_ids(attempt.assessment)

    def is_complete(self, attempt: Attempt) -> bool:
        """§3.1: incompleteness is the ONLY thing that blocks generation.

        Behavioural quality flags (straight-lining, suspiciously short completion time,
        inconsistency pairs) are deliberately NOT implemented -- building a threshold before
        pilot data exists would be inventing a number, not measuring one (§3.1, §10).
        """
        required_ids = self.get_required_question_ids(attempt)
        if not required_ids:
            return False

        answered_ids = set(attempt.answers.values_list("question_id", flat=True))
        return required_ids.issubset(answered_ids)

    def score_attempt(self, attempt: Attempt) -> dict:
        """Returns {facet_scores, domain_scores, quality_metrics}.

        Assumes completeness (call `is_complete` first) -- with a full answer set every facet
        has exactly 4 answers and every domain exactly 6 core answers.
        """
        facet_sums = defaultdict(int)
        core_sums = defaultdict(int)

        for answer in attempt.answers.select_related("question"):
            question = answer.question
            key = question.scoring or {}
            adjusted = 6 - answer.value if question.reverse_scored else answer.value

            if key.get("scale") == "facet":
                facet_sums[key["facet"]] += adjusted
            elif key.get("scale") == "core":
                core_sums[key["domain"]] += adjusted

        facet_scores = []
        provisionals_by_domain = defaultdict(list)
        for code in FACET_ORDER:
            raw = facet_sums[code]
            provisional = self._to_provisional(raw, FACET_RAW_MIN, FACET_RAW_MAX)
            provisionals_by_domain[code[0]].append(provisional)
            facet_scores.append({
                "code": code,
                "domain": code[0],
                "raw": raw,
                "provisional": provisional,
                "level": self._level_for(provisional),
            })

        domain_scores = []
        core_domain_raw = {}
        core_facet_gap = {}
        for domain in DOMAIN_ORDER:
            provisionals = provisionals_by_domain[domain]
            # Domain Facet Index: the mean of the domain's six facets -- the basis of the whole
            # report (§2.3). Never mixed with the core index below.
            index = round(sum(provisionals) / len(provisionals))
            domain_scores.append({
                "code": domain,
                "index": index,
                "level": self._level_for(index),
            })

            raw = core_sums[domain]
            core_domain_raw[domain] = raw
            # §3.2: stored so the real distribution can be inspected later. Both sides are put
            # on the same 0..100 scale first, otherwise the difference is meaningless (6..30 vs
            # 0..100). No threshold is defined and this affects nothing in the report today.
            core_facet_gap[domain] = round(
                self._to_provisional(raw, CORE_RAW_MIN, CORE_RAW_MAX) - index, 1
            )

        return {
            "facet_scores": facet_scores,
            "domain_scores": domain_scores,
            # Never displayed and never sent to the AI (§2.3) -- DeepReportService builds the
            # AI payload from facet_scores/domain_scores only.
            "quality_metrics": {"core_domain_raw": core_domain_raw, "core_facet_gap": core_facet_gap},
        }
