"""Presentation constants and geometry for the emailed PDF reports.

The PDF templates mirror the frontend report pages (faraman-front: app/report/_components/
report-view.tsx, app/deep-report/_components/deep-report-view.tsx), so the labels, level colors
and radar math here are ports of lib/utils/report.ts and lib/utils/deep-report.ts. Keep them in
step with those files. Pure functions and constants only -- no Django, no storage.

The labels deliberately do NOT reuse the `score_level_*` message keys: the web report words the
levels differently from those keys ('کم' not 'پایین' for the initial scale, 'میانه' not 'متوسط'
for the deep one), and `low` means a different thing on the 5-band and the 3-band scale.
"""
import math

INITIAL_LEVEL_LABELS = {
    'high': 'بالا',
    'medium_high': 'نسبتاً بالا',
    'medium': 'متوسط',
    'low': 'کم',
    'very_low': 'خیلی کم',
}

# report_v2 words the levels as the web page does (faraman-front V2_LEVEL_LABELS), not like v1.
INITIAL_V2_LEVEL_LABELS = {
    'high': 'بالا',
    'medium_high': 'نسبتاً بالا',
    'medium': 'متوسط',
    'low': 'پایین',
    'very_low': 'خیلی پایین',
}

INITIAL_LEVEL_COLORS = {
    'high': {'color': '#2743C6', 'bg': '#E9EBF8'},
    'medium_high': {'color': '#2E8A5C', 'bg': '#E4F2EA'},
    'medium': {'color': '#8A6B2E', 'bg': '#FBF3E4'},
    'low': {'color': '#A85C2E', 'bg': '#F7E3D2'},
    'very_low': {'color': '#8F412C', 'bg': '#F9EAE5'},
}

# Web labels for the five dimensions (lib/utils/report.ts DIMENSION_LABELS).
INITIAL_DIMENSION_LABELS = {
    'emotional_stability': 'ثبات هیجانی',
    'extraversion': 'انرژی اجتماعی',
    'openness': 'ذهن رشدگرا',
    'agreeableness': 'همدلی و همکاری',
    'conscientiousness': 'مسئولیت‌پذیری',
}

# report_v2 finding areas (report_spec_v2_0 §8). The chat service renders the same four words.
FINDING_AREA_LABELS = {
    'work': 'کار',
    'relationship': 'رابطه',
    'decision': 'تصمیم',
    'stress': 'استرس',
}

INITIAL_DIMENSION_ICONS = {
    'emotional_stability': 'icon_dim_emotional',
    'extraversion': 'icon_dim_social',
    'openness': 'icon_dim_growth',
    'agreeableness': 'icon_dim_empathy',
    'conscientiousness': 'icon_dim_responsibility',
}

# Pentagon layout, top then clockwise -- each axis is tied to a point on the shape, not to rank.
INITIAL_RADAR_AXES = [
    ('emotional_stability', -90),
    ('extraversion', -18),
    ('openness', 54),
    ('agreeableness', 126),
    ('conscientiousness', 198),
]
INITIAL_RADAR_CENTER = 100
INITIAL_RADAR_RADIUS = 76
DEEP_LEVEL_LABELS = {'low': 'پایین', 'mid': 'میانه', 'high': 'بالا'}
_DEEP_LEVEL_SEGMENT = {'low': 0, 'mid': 1, 'high': 2}
DEEP_LEVEL_RADIUS_FRACTION = {'low': 0.42, 'mid': 0.68, 'high': 0.94}
DEEP_DOMAIN_ANGLES = {'N': -90, 'E': -18, 'O': 54, 'A': 126, 'C': 198}
DEEP_RADAR_CENTER = 100
DEEP_RADAR_INNER = 14
DEEP_RADAR_SPAN = 74

DEEP_DOMAIN_IMAGES = {
    'N': 'deep_domain_n',
    'E': 'deep_domain_e',
    'O': 'deep_domain_o',
    'A': 'deep_domain_a',
    'C': 'deep_domain_c',
}

DEEP_TOPIC_ORDER = (
    'decision_style', 'communication_style', 'work_style',
    'stress_and_energy', 'learning_and_growth', 'close_relationships',
)

DEEP_TOPIC_IMAGES = {
    'decision_style': 'deep_decision',
    'communication_style': 'deep_communication',
    'work_style': 'deep_work',
    'stress_and_energy': 'deep_stress',
    'learning_and_growth': 'deep_learning',
    'close_relationships': 'deep_relations',
}

# Section background bands, cycled by index (DomainSection in deep-report-view.tsx).
DEEP_DOMAIN_BANDS = ['#FBF6EC', '#F5F0FA', '#FBF3E4', '#F1F4FB', '#F7F1EA']


def _point(angle_deg: float, radius: float, center: float) -> tuple[float, float]:
    rad = math.radians(angle_deg)
    return center + radius * math.cos(rad), center + radius * math.sin(rad)


def _format_points(points) -> str:
    return ' '.join(f'{x:.1f},{y:.1f}' for x, y in points)


def initial_radar_polygon(scores_by_key: dict[str, int]) -> str:
    return _format_points(
        _point(angle, INITIAL_RADAR_RADIUS * scores_by_key.get(key, 0) / 100, INITIAL_RADAR_CENTER)
        for key, angle in INITIAL_RADAR_AXES
    )


def _v2_radius(percent: float) -> float:
    """The v2 shape never collapses to the centre: 14% of the radius is the floor, as on the web
    page (faraman-front report-v2-parts.tsx), so even a very low level stays visible."""
    return INITIAL_RADAR_RADIUS * (0.14 + 0.86 * percent / 100)


def initial_v2_radar_polygon(scores_by_key: dict[str, int]) -> str:
    return _format_points(
        _point(angle, _v2_radius(scores_by_key.get(key, 0)), INITIAL_RADAR_CENTER)
        for key, angle in INITIAL_RADAR_AXES
    )


def initial_radar_ring(scale: float) -> str:
    """One pentagon of the radar grid, at `scale` (0-1) of the outer radius."""
    return _format_points(
        _point(angle, INITIAL_RADAR_RADIUS * scale, INITIAL_RADAR_CENTER)
        for _key, angle in INITIAL_RADAR_AXES
    )


def _deep_point(angle_deg: float, fraction: float) -> tuple[float, float]:
    return _point(angle_deg, DEEP_RADAR_INNER + fraction * DEEP_RADAR_SPAN, DEEP_RADAR_CENTER)


def deep_radar_polygon(domain_levels: list[tuple[str, str]]) -> str:
    """`domain_levels` is [(domain code, level), ...] in report order."""
    return _format_points(
        _deep_point(DEEP_DOMAIN_ANGLES.get(code, 0), DEEP_LEVEL_RADIUS_FRACTION[level])
        for code, level in domain_levels
    )


def deep_radar_ring(domain_codes: list[str], fraction: float) -> str:
    return _format_points(_deep_point(DEEP_DOMAIN_ANGLES.get(code, 0), fraction) for code in domain_codes)


def deep_level_bands(level: str) -> list[bool]:
    """Three segments, exactly one lit -- a deep level is never shown as a number."""
    active = _DEEP_LEVEL_SEGMENT[level]
    return [i == active for i in range(3)]


_PERSIAN_DIGITS = str.maketrans('0123456789', '۰۱۲۳۴۵۶۷۸۹')


def to_persian_digits(value) -> str:
    return str(value).translate(_PERSIAN_DIGITS)
