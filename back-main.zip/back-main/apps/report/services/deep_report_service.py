"""Generates and stores the deep report for one completed attempt (deep_report_spec_v1_2.md §5-§7).

Runs inside the Celery task, not the request: §5.1's eight calls with a per-call attempt
ladder take far too long for the response `complete_attempt` has to return. The Report row
is written as GENERATING up front by ReportService, and this service fills it in.
"""

import logging

from apps.ai.deep_report_generation.memory_candidates import build_memory_candidates
from apps.ai.pricing import calculate_cost
from apps.account.services.demographics_service import DemographicsService
from apps.assessment.models import Attempt
from apps.report.models import Report
from apps.report.repositories.generation_log_repository import GenerationLogRepository
from apps.report.repositories.memory_repository import MemoryRepository
from apps.report.repositories.report_repository import ReportRepository
from apps.report.services.deep_ai_report_client import DeepAiReportClient
from apps.report.services.deep_patterns import detect_patterns
from apps.report.services.deep_scoring_service import DeepScoringService
from faraman_back.lang.utils import get_message
from faraman_back.observability.metrics import (
    REPORT_GENERATION_DURATION,
    REPORT_GENERATION_IN_PROGRESS,
    observe,
)

logger = logging.getLogger(__name__)


def report_generation_outcome(report: "Report | None") -> str:
    """Maps the value returned by ReportService.generate_initial / DeepReportService.generate
    to a metric `outcome` label. Both methods catch their own exceptions and still return a
    row, so the outcome is read from the row, not from an exception:

      - None / still GENERATING -> "noop" (task ran but the row was already claimed/gone)
      - status == ERROR         -> "error"
      - otherwise               -> "ok"

    Lives here (not report_service.py) because report_service imports this module, not the
    other way round.
    """
    if report is None or report.status == Report.Status.GENERATING:
        return "noop"
    return "error" if report.status == Report.Status.ERROR else "ok"


class DeepReportService:
    def __init__(
        self, report_repository=None, memory_repository=None, ai_client=None,
        deep_scoring_service=None, demographics_service=None, generation_log_repository=None,
    ):
        self.report_repository = report_repository or ReportRepository()
        self.memory_repository = memory_repository or MemoryRepository()
        self.ai_client = ai_client or DeepAiReportClient()
        self.deep_scoring_service = deep_scoring_service or DeepScoringService()
        self.demographics_service = demographics_service or DemographicsService()
        self.generation_log_repository = generation_log_repository or GenerationLogRepository()

    def score(self, attempt: Attempt) -> dict:
        """Scoring plus pattern detection -- everything deterministic, in one place.

        Called by ReportService before the row is even created, so the scores are durable even
        if generation later fails: they are the part worth keeping for norming (§7.3).
        """
        scores = self.deep_scoring_service.score_attempt(attempt)
        # §3.3: computed here, never by the model.
        scores["active_patterns"] = detect_patterns(scores["facet_scores"])
        return scores

    def _log_generation(self, attempt: Attempt, response: dict, *, call_key: str = "") -> None:
        """One GenerationLog row per AI call (§7.7). Written on success and failure alike --
        a call that reached the provider cost money either way."""
        generation_meta = response.get("generation_meta")
        if not generation_meta:
            return

        self.generation_log_repository.create(
            attempt=attempt,
            user=attempt.user,
            call_key=call_key,
            model_used=generation_meta.get("model_used"),
            attempts=generation_meta.get("attempts", 0),
            input_tokens=generation_meta.get("input_tokens", 0),
            cached_input_tokens=generation_meta.get("cached_input_tokens", 0),
            output_tokens=generation_meta.get("output_tokens", 0),
            latency_s=generation_meta.get("latency_s", 0.0),
            cost=calculate_cost(
                generation_meta.get("model_used"),
                generation_meta.get("input_tokens", 0),
                generation_meta.get("output_tokens", 0),
                cached_input_tokens=generation_meta.get("cached_input_tokens", 0),
            ),
        )

    def _persist_memories(self, report: Report) -> None:
        """§6.3. Keyed on (user, memory_type, source), so these land beside the initial
        report's memories instead of overwriting them."""
        user = report.attempt.user
        if user is None:
            return

        for candidate in report.memory_candidates:
            if not candidate.get("should_store"):
                continue
            self.memory_repository.upsert(
                user=user,
                memory_type=candidate["memory_type"],
                text_memory=candidate["text_memory"],
                source=candidate["source"],
                confidence=candidate["confidence"],
                sensitivity_level=candidate["sensitivity_level"],
            )

        self.report_repository.mark_memories_persisted(report)

    @observe(
        REPORT_GENERATION_DURATION,
        in_progress=REPORT_GENERATION_IN_PROGRESS,
        labels={"report_type": "deep"},
        outcome=report_generation_outcome,
    )
    def generate(self, attempt_id: int) -> Report | None:
        """Fills in the GENERATING row for this attempt. Returns None if there is nothing to do.

        Never raises into the task: a generation failure is a stored `error` report, not a
        retry storm. §5.1 -- if any part fails, the whole report fails; a half report is never
        shown. Claiming the row (rather than a plain status read) also makes a redelivered
        Celery task a no-op instead of a second paid AI call for the same report.
        """
        report = self.report_repository.claim_for_generation(attempt_id)
        if report is None:
            logger.warning(
                "deep generation skipped for attempt %s: no claimable report in GENERATING state", attempt_id
            )
            return self.report_repository.get_by_attempt_id(attempt_id)

        try:
            return self._generate(report)
        except Exception:
            # Broad on purpose: whatever went wrong -- demographics lookup, payload building,
            # the AI call itself, or an unexpected response shape -- the user gets a stored
            # error rather than a row stuck in GENERATING forever.
            logger.exception("deep generation raised for attempt %s", attempt_id)
            return self.report_repository.mark_error(
                report,
                error_code="generation_failed",
                error_message=get_message("report_generation_failed"),
            )

    def _generate(self, report: Report) -> Report:
        attempt = report.attempt
        demographics = self.demographics_service.get(user=attempt.user, anonymous_id=attempt.anonymous_id)
        payload = self.ai_client.build_payload(
            facet_scores=report.facet_scores,
            domain_scores=report.domain_scores,
            active_patterns=report.active_patterns,
            demographics=demographics,
        )
        response = self.ai_client.generate(payload)
        self._log_generation(attempt, response)

        if response["status"] == "error":
            logger.error(
                "deep report generation failed for attempt %s: code=%s meta=%s",
                attempt.id, response["error"]["code"], response.get("generation_meta"),
            )
            return self.report_repository.mark_error(
                report,
                error_code=response["error"]["code"],
                error_message=response["error"].get("user_message", ""),
            )

        report = self.report_repository.mark_ok(
            report,
            report_version=response["report_version"],
            report_data=response["report"],
            system_data=response.get("system", {}),
            memory_candidates=build_memory_candidates(response["report"]),
        )
        self._persist_memories(report)
        logger.info("deep report generated for attempt %s", report.attempt_id)
        return report
