"""Turns one completed attempt into the report_v3 answer sheet (docs/report_spec_v3_0.md §2).

report_v1/report_v2 send the model five dimension scores. report_v3 sends the *raw answers*,
because its whole contract is built on evidence: the prompt quotes question wording back at the
model, and the model answers with a `source_map` citing `qN` ids that must correspond to
questions this user actually answered non-neutrally.

That makes the mapping from database rows onto `q1..q30` the single riskiest step of the whole
feature, so it is deliberately isolated here and deliberately paranoid:

  * `qN` is a *semantic* id from the v3 question contract, never a database primary key and
    never a row index. The same 30 items have different ids in every environment.
  * Mapping is by dimension (= section title) + order, then every single item's text and
    reverse flag is verified against the contract (apps.ai.report_generation.question_map_v3).
    A single mismatch aborts the whole mapping -- see ReportV3QuestionMapMismatch.
  * A missing answer is an error, never the `currentAnswers[q.id] || 3` neutral default the
    studio prototype used: that silently turns "did not answer" into "feels neutral about it",
    and the model would then build evidence on an opinion the user never expressed.

The verification is not theoretical. The repository's own seed command
(apps.assessment.management.commands.seed_test_assessment) seeds a 30-item assessment whose
section titles match the contract but whose *wording and reverse flags do not* -- so pointing
report_v3 at that seeded assessment raises here, loudly, instead of quietly generating a
report grounded in sentences the user never read.
"""

import logging

from apps.ai.report_generation.profile_input_v3 import AnswerSheetV3
from apps.ai.report_generation.question_map_v3 import (
    DIMENSION_ORDER_V3,
    MappedQuestion,
    QuestionMapError,
    V3_QUESTION_IDS,
    map_questions,
)
from apps.assessment.models import Attempt
from apps.assessment.repositories.assessment_repository import AssessmentRepository
from apps.assessment.repositories.attempt_repository import AttemptRepository
from apps.report.services.exceptions import (
    ReportV3AnswersIncompleteException,
    ReportV3QuestionMapMismatchException,
)

logger = logging.getLogger(__name__)

# Answer.value is a JSONField (it holds scalars, lists or text depending on question_type).
# For the Likert items v3 consumes it must be a plain 1..5 integer; anything else is corrupt
# data for this assessment type, not a variant to be coerced.
VALID_ANSWER_VALUES = (1, 2, 3, 4, 5)


class ReportV3InputService:
    """Builds `{"q1": 4, ..., "q30": 2}` for one attempt. Raises rather than guessing."""

    def __init__(self, attempt_repository=None, assessment_repository=None):
        self.attempt_repository = attempt_repository or AttemptRepository()
        self.assessment_repository = assessment_repository or AssessmentRepository()

    def build_answers(self, attempt: Attempt) -> dict[str, int]:
        # The question bank and the answers are read separately, on purpose: deriving the
        # question list from the answers would report an unanswered item as a *question map*
        # failure ("this dimension has 5 questions"), which points an operator at the
        # assessment config when the real problem is one missing answer. Mapping is about the
        # assessment; completeness is about this attempt.
        questions = [
            MappedQuestion(
                external_id=question.id,
                dimension=question.section.title,
                order=question.order,
                text=question.text,
                reverse_scored=question.reverse_scored,
            )
            for question in self.assessment_repository.get_active_questions_for_sections(
                attempt.assessment, list(DIMENSION_ORDER_V3),
            )
        ]
        value_by_external_id = {
            answer.question_id: answer.value
            for answer in self.attempt_repository.get_scored_answers(attempt)
        }

        try:
            mapping = map_questions(questions)
        except QuestionMapError as e:
            # Configuration error: this assessment is not the one report_v3 was written for.
            # Logged in full (question metadata only -- no user answers), raised as a generic
            # message so the mismatch details never reach the user.
            logger.error(
                "report_v3 question map mismatch for assessment %s (attempt %s): %s",
                attempt.assessment.slug, attempt.id, "; ".join(e.problems),
            )
            raise ReportV3QuestionMapMismatchException() from e

        result: dict[str, int] = {}
        problems: list[str] = []
        for qid in V3_QUESTION_IDS:
            raw = value_by_external_id.get(mapping[qid])
            # bool is an int subclass in Python; True would otherwise pass as 1.
            if isinstance(raw, bool) or not isinstance(raw, int) or raw not in VALID_ANSWER_VALUES:
                problems.append(f"{qid}: {raw!r}")
                continue
            result[qid] = raw

        if problems:
            logger.error(
                "report_v3 answers unusable for attempt %s: %s",
                attempt.id, ", ".join(problems),
            )
            raise ReportV3AnswersIncompleteException()

        return result

    @staticmethod
    def dimension_scores(answers: dict[str, int]) -> list[dict]:
        """The five scores derived from the SAME numbers the model is given.

        v3 does not reuse ScoringService's output for the stored row: the two disagree by one
        point on two of the 25 reachable factor sums, because ScoringService uses Python's
        bankers rounding and the v3 contract uses JavaScript's Math.round (see
        profile_input_v3.js_round). One point is invisible to a user looking at one report --
        and glaring to a user comparing the number on the page with the band the text was
        written from. Requirement: for a v3 report the two must be the same number.
        ScoringService itself is untouched, so v1/v2 scoring does not move.
        """
        return AnswerSheetV3(answers=answers).dimension_scores()
