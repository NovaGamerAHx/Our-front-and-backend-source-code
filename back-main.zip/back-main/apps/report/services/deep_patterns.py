"""The eight combination patterns from the scoring manual §8 (deep_report_spec_v1_2.md §3.3).

Detected in the backend, never by the model. They are simple conditions over two facet
levels, and if the model were asked to spot them instead, two people with near-identical
scores could receive contradictory reports. The backend sends the list of active patterns;
the AI only writes their interpretation.

"high" and "low" here are exactly the bands from DeepScoringService -- a "mid" facet
satisfies neither side of any rule.

These are product hypotheses for personal development, NOT a validated NEO scale (manual §8
closing note), which is why the prompt has to phrase them tentatively.
"""

from apps.report.services.deep_scoring_service import LEVEL_HIGH, LEVEL_LOW

# id -> the conditions that must ALL hold, as (facet code, required level).
# Ids double as the interpretation keys the AI receives in `active_patterns`.
PATTERN_RULES = {
    # Strong risk analysis; may get stuck deliberating before deciding.
    "N1_high_C6_high": [("N1", LEVEL_HIGH), ("C6", LEVEL_HIGH)],
    # Curiosity and ideas outrun follow-through; many starts, fewer finishes.
    "O5_high_C5_low": [("O5", LEVEL_HIGH), ("C5", LEVEL_LOW)],
    # Strong drive to achieve, paired with performance pressure and thin satisfaction.
    "C4_high_N1_high": [("C4", LEVEL_HIGH), ("N1", LEVEL_HIGH)],
    # Assertive and influential; conflict can escalate.
    "E3_high_A4_low": [("E3", LEVEL_HIGH), ("A4", LEVEL_LOW)],
    # Not especially sociable, yet able to lead and take a position when needed.
    "E2_low_E3_high": [("E2", LEVEL_LOW), ("E3", LEVEL_HIGH)],
    # Quick trust with less vetting; risk of delegating too early.
    "A1_high_C6_low": [("A1", LEVEL_HIGH), ("C6", LEVEL_LOW)],
    # Drive plus a wish to be seen; an engine of impact that is sensitive to recognition.
    "A5_low_C4_high": [("A5", LEVEL_LOW), ("C4", LEVEL_HIGH)],
    # Pull toward immediate reward plus difficulty sustaining work; momentary decisions.
    "N5_high_C5_low": [("N5", LEVEL_HIGH), ("C5", LEVEL_LOW)],
}


def detect_patterns(facet_scores: list[dict]) -> list[str]:
    """Active pattern ids, in PATTERN_RULES order. May be empty -- that is a valid profile,
    not a failure (§4), and the prompt must handle an empty list."""
    levels = {facet["code"]: facet["level"] for facet in facet_scores}

    return [
        pattern_id
        for pattern_id, conditions in PATTERN_RULES.items()
        if all(levels.get(code) == level for code, level in conditions)
    ]
