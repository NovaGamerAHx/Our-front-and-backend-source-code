"""Picks the scoring service for an attempt, from `Assessment.scoring_profile`.

Two instruments now score in structurally different ways: the initial 30-item test derives a
dimension from the section title, while the deep 150-item test carries a per-question key and
has presentational sections. Anything that asks "is this attempt complete?" or "score this"
has to route first -- notably AttemptService.complete_attempt, which would otherwise reject a
fully answered deep attempt because ScoringService finds no dimension-titled sections in it.

Routing on the field rather than on the slug on purpose: a later deep-150-v2 is a different
slug under the same rules.
"""

from apps.assessment.models import Assessment, Attempt
from apps.report.services.deep_scoring_service import DeepScoringService
from apps.report.services.scoring_service import ScoringService


class ScoringRouter:
    def __init__(self, scoring_service=None, deep_scoring_service=None):
        self.scoring_service = scoring_service or ScoringService()
        self.deep_scoring_service = deep_scoring_service or DeepScoringService()

    def for_attempt(self, attempt: Attempt):
        return self.for_assessment(attempt.assessment)

    def for_assessment(self, assessment: Assessment):
        if assessment.scoring_profile == Assessment.ScoringProfile.FACET_150:
            return self.deep_scoring_service
        return self.scoring_service

    @staticmethod
    def is_deep(attempt: Attempt) -> bool:
        return attempt.assessment.scoring_profile == Assessment.ScoringProfile.FACET_150
