from rest_framework import status

from faraman_back.utils.exceptions import AppException


class ReportNotFoundException(AppException):
    """Raised when the requested attempt has no report yet (not completed, or not a scored assessment)."""
    status_code = status.HTTP_404_NOT_FOUND
    message_key = 'report_not_found'


class ReportAccessDeniedException(AppException):
    """Raised when the requester (user or anonymous_id) does not own the attempt behind the report."""
    status_code = status.HTTP_403_FORBIDDEN
    message_key = 'report_access_denied'


class ReportNotReadyException(AppException):
    """Raised when an entry_source that requires a report (report_cta/deep_report_cta/
    deep_report_focus:<section>) points at a report that is still GENERATING or ended in ERROR --
    there is no content to chat about yet."""
    status_code = status.HTTP_409_CONFLICT
    message_key = 'report_not_ready'


class ScoreOutOfRangeException(AppException):
    """Raised by ScoringService._level_for when a computed score_percent falls outside 0-100.
    A full, valid answer set can only ever produce 0-100 (report_spec_v1.3 §1), so this means
    corrupt data (out-of-range answer values, or a wrong answer count for a dimension) -- a
    server-side integrity failure, hence the 500 status, not a client error."""
    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    message_key = 'report_score_out_of_range'


class ReportRetryNotAllowedException(AppException):
    """Raised when a retry is requested for a report that isn't in ERROR status -- only a
    failed generation can be retried; OK and GENERATING reports have nothing to retry."""
    status_code = status.HTTP_409_CONFLICT
    message_key = 'report_retry_not_allowed'


class SuggestedStepNotFoundException(AppException):
    """Raised when there is no suggested_step/small_action at the requested 1-based index --
    either the report isn't OK yet, or the index is out of range (report_spec_v1_4 §4.3,
    deep_report_spec_v1_2.md §6.5 both fix the count at exactly 3)."""
    status_code = status.HTTP_404_NOT_FOUND
    message_key = 'suggested_step_not_found'


class EmailServiceMisconfiguredException(AppException):
    """Raised when Liara SMTP credentials are missing from the environment."""
    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    message_key = 'system_error'


class ReportEmailDeliveryFailedException(AppException):
    """Raised when EmailService.send_html reports a failed send for a report email."""
    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    message_key = 'report_email_send_failed'


class ReportPdfGenerationFailedException(AppException):
    """Raised when ReportPdfService.render_pdf (WeasyPrint) fails to render a report's PDF
    attachment. Kept distinct from ReportEmailDeliveryFailedException even though both are
    500s: this one is a build/template/font defect that recurs on every request, not a
    transient SMTP-provider failure -- the same reason EmailServiceMisconfiguredException and
    ReportEmailDeliveryFailedException are kept separate despite sharing a status code."""
    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    message_key = 'report_pdf_generation_failed'


class ReportEmailThrottledException(AppException):
    """Raised when the same user/attempt has requested a report email too many times within
    the throttle window (see ReportEmailThrottleRepository) -- the endpoint accepts an
    arbitrary address, so without a limit it's a spam/harassment vector."""
    status_code = status.HTTP_429_TOO_MANY_REQUESTS
    message_key = 'report_email_throttled'
class ReportV3QuestionMapMismatchException(AppException):
    """Raised when report_v3 is pointed at an assessment whose questions do not match the v3
    question contract (apps.ai.report_generation.question_map_v3) -- wrong wording, wrong
    per-dimension order, or a wrong reverse_scored flag.

    A configuration/deploy error, not a client one, hence the 500: generating anyway would
    send the model evidence sentences the user never actually read, and the resulting report
    would cite them as if they had. The specific mismatches are logged, never returned."""
    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    message_key = 'report_generation_failed'


class ReportV3AnswersIncompleteException(AppException):
    """Raised when an attempt does not carry a usable 1-5 answer for all 30 v3 questions.

    Deliberately an error rather than a neutral fill-in: the studio prototype's
    `currentAnswers[q.id] || 3` turns an unanswered item into "feels neutral about it", and
    report_v3 then builds evidence on an opinion the user never expressed (see
    docs/report_spec_v3_0.md section 2.2). Reaching this means the completeness check that
    gates generation disagreed with the answers actually stored, so it is a server-side
    integrity failure."""
    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    message_key = 'report_generation_failed'
