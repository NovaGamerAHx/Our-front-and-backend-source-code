"""apps.report's adapter onto the deep-report AI pipeline (deep_report_spec_v1_2.md §4 / §6).

Exactly parallel to ai_report_client.AiReportClient: it turns what DeepReportService has
(scores, demographics) into apps.ai's generic contract and hands back the response dict
unchanged. The prompt/schema/retry work lives on the other side of this boundary.
"""

from apps.ai.deep_report_generation.client import DeepReportGenerationClient
from apps.report.services.ai_report_client import AiReportClient


class DeepAiReportClient:
    def __init__(self, client=None):
        self._client = client or DeepReportGenerationClient()

    @staticmethod
    def build_payload(*, facet_scores: list[dict], domain_scores: list[dict],
                      active_patterns: list[str], demographics: dict) -> dict:
        """The §4 request body.

        `score` is `Facet Provisional` / `Domain Facet Index`. It is sent for one reason only:
        so the model can gauge intensity. §4 and §8 forbid it from appearing in any generated
        text, which is a prompt rule, not something this payload can enforce.

        Two things are deliberately absent:
          - `Core Domain Raw` -- stored for quality control, never sent (§2.3).
          - gender -- filtered out by _build_context_profile, same as the initial report.
        """
        return {
            "report_type": "deep",
            "facet_scores": [
                {"code": facet["code"], "score": facet["provisional"], "level": facet["level"]}
                for facet in facet_scores
            ],
            "domain_scores": [
                {"code": domain["code"], "score": domain["index"], "level": domain["level"]}
                for domain in domain_scores
            ],
            # May legitimately be empty (§4) -- not every profile trips a pattern.
            "active_patterns": active_patterns,
            # Reuses the initial report's rule set rather than restating it: age from
            # birth_year, life_situation, current_goal, and never gender.
            "context_profile": AiReportClient._build_context_profile(demographics) or {},
        }

    def generate(self, payload: dict) -> dict:
        """Returns a deep_report_spec_v1_2.md §6-shaped dict (status ok/error, report, system,
        generation_meta).

        No enable/disable flag here yet: there is only one path, the mock, so a toggle would
        select between the same thing twice. When the real generation lands it can add its own
        REPORT_AI_ENABLED-style switch, which is where that decision belongs.
        """
        return self._client.generate(payload)
