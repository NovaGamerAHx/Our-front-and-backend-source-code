import logging

from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.utils.html import strip_tags

from apps.report.services.exceptions import EmailServiceMisconfiguredException
from faraman_back.observability.metrics import (
    REPORT_EMAIL_DELIVERY_DURATION,
    delivery_outcome,
    observe,
)

logger = logging.getLogger(__name__)


class EmailService:
    """Liara SMTP client. Same shape as SMSService (apps/account/services/sms_service.py):
    credentials checked eagerly in __init__, the provider call wrapped in try/except, logging
    and returning False on failure rather than raising -- the caller decides what a failed
    send means."""

    def __init__(self):
        if not settings.EMAIL_HOST or not settings.EMAIL_HOST_USER:
            logger.error("Liara SMTP credentials missing")
            raise EmailServiceMisconfiguredException("Liara SMTP credentials missing")

    @observe(REPORT_EMAIL_DELIVERY_DURATION, outcome=delivery_outcome)
    def send_html(
        self, to_email: str, subject: str, html_body: str,
        *, pdf_attachment: bytes | None = None, pdf_filename: str | None = None,
    ) -> bool:
        try:
            message = EmailMultiAlternatives(
                subject=subject,
                body=strip_tags(html_body),
                from_email=f"{settings.EMAIL_FROM_NAME} <{settings.DEFAULT_FROM_EMAIL}>",
                to=[to_email],
            )
            message.attach_alternative(html_body, "text/html")
            if pdf_attachment is not None:
                message.attach(pdf_filename, pdf_attachment, "application/pdf")
            message.send()
            return True
        except Exception as e:
            logger.exception(f"Email send failed: {e}")
            return False
