from apps.report.models import Report
from apps.report.repositories.report_repository import ReportRepository
from apps.report.services.exceptions import ReportAccessDeniedException, ReportNotFoundException, ReportNotReadyException, SuggestedStepNotFoundException


DOMAIN_TITLES = {"emotional_stability": "ثبات هیجانی", "extraversion": "برون‌گرایی", "openness": "گشودگی", "agreeableness": "توافق‌پذیری", "conscientiousness": "وظیفه‌شناسی", "N": "حساسیت هیجانی", "E": "برون‌گرایی", "O": "گشودگی", "A": "توافق‌پذیری", "C": "وظیفه‌شناسی"}


class WorkspaceReportService:
    def __init__(self, repository=None):
        self.repository = repository or ReportRepository()

    @staticmethod
    def findings(report):
        data = report.report_data or {}
        if report.report_type == Report.ReportType.DEEP:
            blind_spots = data.get("blind_spots") or {}
            items = blind_spots.get("items", []) if isinstance(blind_spots, dict) else []
            findings = [
                {"key": f"blind_spots:{i}", "text": item["hypothesis"].strip()}
                for i, item in enumerate(items or [])
                if isinstance(item, dict) and isinstance(item.get("hypothesis"), str) and item["hypothesis"].strip()
            ]
            # Some older/incomplete reports lack blind-spot hypotheses. Use the report's
            # own identity line only in that case; never invent a user-specific insight.
            identity = data.get("identity_line")
            if not findings and isinstance(identity, str) and identity.strip():
                findings = [{"key": "identity_line", "text": identity.strip()}]
            return findings
        findings = data.get("findings", [])
        if findings:
            return [{"key": f"finding:{i}", "text": item.get("what") or item.get("title", "")} for i, item in enumerate(findings)]
        text = data.get("summary", {}).get("one_line", "")
        return [{"key": "summary", "text": text}] if text else []

    def owned(self, attempt_id, user):
        report = self.repository.get_by_attempt_id(attempt_id)
        if report is None or report.attempt.is_deleted:
            raise ReportNotFoundException()
        if report.attempt.user_id != user.pk:
            raise ReportAccessDeniedException()
        if report.status != Report.Status.OK:
            raise ReportNotReadyException()
        return report

    def context(self, user):
        reports = self.repository.get_history_for_user(user)
        report = next((r for r in reports if r.report_type == Report.ReportType.DEEP), reports[0] if reports else None)
        if report is None:
            return {"report": None}
        rejected = self.repository.rejected_keys(report)
        # Exact deterministic score values, no mapping of qualitative labels to invented numbers.
        scores = ([{"code": d["code"], "score": d["index"], "title": DOMAIN_TITLES.get(d["code"], d["code"])} for d in report.domain_scores]
                  if report.report_type == Report.ReportType.DEEP else
                  [{"code": d["key"], "score": d["score_percent"], "title": DOMAIN_TITLES.get(d["key"], d["key"])} for d in report.dimension_scores])
        return {"report": {"attempt_id": report.attempt_id, "report_type": report.report_type,
                           "completed_at": report.attempt.completed_at, "scores": scores,
                           "findings": [f for f in self.findings(report) if f["key"] not in rejected]}}

    def reject(self, *, attempt_id, user, key):
        report = self.owned(attempt_id, user)
        if key not in {f["key"] for f in self.findings(report)}:
            raise SuggestedStepNotFoundException()
        self.repository.reject_finding(report, key)
