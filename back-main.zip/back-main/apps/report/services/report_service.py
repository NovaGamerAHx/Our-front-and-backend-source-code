import copy
import logging
import time

from django.conf import settings
from django.db import transaction
from django.template.loader import render_to_string

from apps.account.models import User
from apps.account.services.demographics_service import DemographicsService
from apps.action_steps.models import ActionStep
from apps.action_steps.services.action_step_service import ActionStepService
from apps.ai.pricing import calculate_cost
from apps.assessment.models import Attempt
from apps.report.models import Report
from apps.report.repositories.generation_log_repository import GenerationLogRepository
from apps.report.repositories.memory_repository import MemoryRepository
from apps.report.repositories.report_email_delivery_repository import ReportEmailDeliveryRepository
from apps.report.repositories.report_email_throttle_repository import ReportEmailThrottleRepository
from apps.report.repositories.report_repository import ReportRepository
from apps.report.services.ai_report_client import AiReportClient
from apps.report.services.deep_report_service import (
    DeepReportService,
    report_generation_outcome,
)
from apps.report.services.email_service import EmailService
from apps.report.services.exceptions import (
    ReportAccessDeniedException,
    ReportEmailDeliveryFailedException,
    ReportEmailThrottledException,
    ReportNotFoundException,
    ReportNotReadyException,
    ReportRetryNotAllowedException,
    SuggestedStepNotFoundException,
)
from apps.report.services import report_presentation as presentation
from apps.report.services.pdf_service import ReportPdfService
from apps.report.services.scoring_router import ScoringRouter
from apps.report.services.scoring_service import ScoringService
from apps.report.tasks import generate_deep_report, generate_initial_report
from faraman_back.lang.utils import get_message
from faraman_back.observability.metrics import (
    REPORT_GENERATION_DURATION,
    REPORT_GENERATION_IN_PROGRESS,
    THROTTLE_REJECTED,
    observe,
)

logger = logging.getLogger(__name__)

DEEP_REPORT_VERSION = "deep_v1"
# report_spec_v2_0: the redesigned initial report. Rows written before it carry "report_v1" and
# keep their old shape everywhere below (preview, full, email, suggested step, history).
INITIAL_REPORT_V2 = "report_v2"

# ============================================================================
# TEMPORARY -- apps.ai.report_generation does not produce `suggested_step` yet (neither its
# prompt nor its fewshot examples ask for it), so a freshly generated report's
# growth_path.recommendations have no suggested_step at all -- accept_step()/the report page's
# "این را قدم امروز کن" button would have nothing to work with. Until that AI-side work lands,
# _with_fake_suggested_steps() below patches placeholder steps onto whatever report_data was
# actually generated -- ONLY in memory, for this request/response. It never touches the DB row
# (report.report_data on disk is left exactly as the AI produced it), so nothing needs
# backfilling once the real thing ships.
#
# DELETE: this constant, _with_fake_suggested_steps(), and its two call sites in _shape() and
# _suggested_step_at(), once apps.ai.report_generation actually emits suggested_step for real.
# ============================================================================

_FAKE_SUGGESTED_STEPS = [
    {
        "text": "[نمونه — نه یک قدمِ واقعی] امشب یک نفر را انتخاب کن و دربارهٔ همین موضوع باهاش حرف بزن.",
        "deadline_text": "امشب",
        "deadline_type": "tonight",
        "substeps": None,
    },
    {
        "text": "[نمونه — نه یک قدمِ واقعی] فردا صبح ۱۵ دقیقه وقت بگذار و اولین قدمِ کوچک را همان‌جا بردار.",
        "deadline_text": "فردا صبح",
        "deadline_type": "tomorrow_morning",
        "substeps": None,
    },
    {
        "text": "[نمونه — نه یک قدمِ واقعی] فردا عصر یک تصمیمِ کوچکِ مرتبط را بنویس و برایش مهلت بگذار.",
        "deadline_text": "فردا عصر",
        "deadline_type": "tomorrow_evening",
        "substeps": None,
    },
]


def _with_fake_suggested_steps(report_data: dict, *, report_type: str) -> dict:
    """See the TEMPORARY block above. Returns a patched copy; never mutates the input dict (the
    caller may still hold a reference to the real, unpatched report.report_data)."""
    data = copy.deepcopy(report_data) if report_data else {}

    if report_type == Report.ReportType.DEEP:
        small_actions = (data.get("closing") or {}).get("small_actions")
        if isinstance(small_actions, list):
            for i, action in enumerate(small_actions):
                if not isinstance(action, dict) or "deadline_type" not in action:
                    small_actions[i] = dict(_FAKE_SUGGESTED_STEPS[i % len(_FAKE_SUGGESTED_STEPS)])
    else:
        recommendations = (data.get("growth_path") or {}).get("recommendations")
        if isinstance(recommendations, list):
            for i, rec in enumerate(recommendations):
                if isinstance(rec, dict) and "suggested_step" not in rec:
                    rec["suggested_step"] = dict(_FAKE_SUGGESTED_STEPS[i % len(_FAKE_SUGGESTED_STEPS)])

    return data


_FINDING_ORDINALS = ("اول", "دوم")


def _is_initial_v2(report: Report) -> bool:
    return report.report_type == Report.ReportType.INITIAL and report.report_version == INITIAL_REPORT_V2


class ReportService:
    def __init__(
        self, report_repository=None, memory_repository=None, ai_client=None, scoring_service=None,
        demographics_service=None, generation_log_repository=None, scoring_router=None,
        deep_report_service=None, action_step_service=None, email_service=None,
        report_email_throttle_repository=None, pdf_service=None,
        report_email_delivery_repository=None,
    ):
        self.report_repository = report_repository or ReportRepository()
        self.memory_repository = memory_repository or MemoryRepository()
        self.ai_client = ai_client or AiReportClient()
        self.scoring_service = scoring_service or ScoringService()
        self.demographics_service = demographics_service or DemographicsService()
        self.generation_log_repository = generation_log_repository or GenerationLogRepository()
        # Built from self.scoring_service so an injected one still governs the initial-report
        # path -- otherwise the router would quietly construct a real ScoringService and
        # bypass the collaborator the caller handed in.
        self.scoring_router = scoring_router or ScoringRouter(scoring_service=self.scoring_service)
        self.deep_report_service = deep_report_service or DeepReportService()
        self.action_step_service = action_step_service or ActionStepService()
        self.report_email_throttle_repository = report_email_throttle_repository or ReportEmailThrottleRepository()
        self.report_email_delivery_repository = report_email_delivery_repository or ReportEmailDeliveryRepository()
        # Eager, unlike email_service below -- a broken WeasyPrint install is a permanent build
        # defect (identical on every worker, every request), not a per-environment runtime value
        # like SMTP credentials. `import weasyprint` already sits at pdf_service.py's module top
        # (hard rule 4), so a broken native-lib install crashes the whole process at boot either
        # way -- laziness here would only defer the constructor call, not the import, so it buys
        # nothing and would just delay the failure from deploy time to a user's first PDF email.
        self.pdf_service = pdf_service or ReportPdfService()
        # Lazy, not constructed here -- see the email_service property below. Every report view
        # builds a ReportService in __init__ (ReportHistoryAPIView, ReportDetailAPIView, ...),
        # so an eager EmailService() would 500 every one of them the moment Liara credentials
        # are unset, not just the email endpoint. Same reasoning as OtpService.sms_service.
        self._email_service = email_service

    @property
    def email_service(self):
        if self._email_service is None:
            self._email_service = EmailService()
        return self._email_service

    @staticmethod
    def _owns_attempt(attempt: Attempt, *, user: User | None, anonymous_id: str | None) -> bool:
        if attempt.user_id is not None:
            return user is not None and attempt.user_id == user.id
        return anonymous_id is not None and attempt.anonymous_id == anonymous_id

    def _build_ai_payload(self, attempt: Attempt, dimension_scores: list) -> dict:
        demographics = self.demographics_service.get(user=attempt.user, anonymous_id=attempt.anonymous_id)
        return {
            "assessment": {
                "user_id": str(attempt.user_id) if attempt.user_id else attempt.anonymous_id,
                "assessment_id": str(attempt.id),
                "test_version": attempt.assessment.slug,
                "language": "fa",
            },
            "demographics": {
                "birth_year": demographics["birth_year"],
                "gender": demographics["gender"],
                "life_situation": demographics["life_situation"],
                "goal": demographics["goal"],
            },
            "dimension_scores": dimension_scores,
            "answer_quality": {"completion_rate": 100},
        }

    def persist_memories(self, report: Report) -> None:
        """Stores should_store=true memory_candidates as Memory rows (report_spec_v1.3 §4.5)."""
        user = report.attempt.user
        if user is None:
            return

        for candidate in report.memory_candidates:
            if not candidate.get("should_store"):
                continue
            self.memory_repository.upsert(
                user=user,
                memory_type=candidate["memory_type"],
                text_memory=candidate["text_memory"],
                source=candidate["source"],
                confidence=candidate["confidence"],
                sensitivity_level=candidate["sensitivity_level"],
            )

        self.report_repository.mark_memories_persisted(report)

    def _log_generation(self, attempt: Attempt, response: dict) -> None:
        """Stores generation_meta (report_spec_v1.4 §4.1/§4.2) as its own GenerationLog row,
        for both the success and error response shapes -- an error response still carries
        generation_meta whenever an attempt reached the model, and that attempt still cost
        money. Never stored on the Report row itself: this is operational/analytics data,
        not part of the report, and never sent to the frontend (§4.4)."""
        generation_meta = response.get("generation_meta")
        if not generation_meta:
            return

        cost = calculate_cost(
            generation_meta.get("model_used"),
            generation_meta.get("input_tokens", 0),
            generation_meta.get("output_tokens", 0),
            cached_input_tokens=generation_meta.get("cached_input_tokens", 0),
        )
        self.generation_log_repository.create(
            attempt=attempt,
            user=attempt.user,
            model_used=generation_meta.get("model_used"),
            attempts=generation_meta.get("attempts", 0),
            input_tokens=generation_meta.get("input_tokens", 0),
            cached_input_tokens=generation_meta.get("cached_input_tokens", 0),
            output_tokens=generation_meta.get("output_tokens", 0),
            latency_s=generation_meta.get("latency_s", 0.0),
            cost=cost,
        )

    def persist_pending_memories_for_user(self, user: User) -> None:
        """Called after an anonymous attempt gets linked to a user on login, so a report generated
        while anonymous still ends up with its memories stored (report_spec_v1.3 §4.5)."""
        for report in self.report_repository.get_unpersisted_for_user(user):
            self.persist_memories(report)

    def _start_deep_generation(self, attempt: Attempt, *, awaiting_payment: bool = False) -> Report:
        """Deep reports generate asynchronously (deep_report_spec_v1_2.md §5.1): eight model calls, each
        with its own attempt ladder, is far more than the completing request can wait for.

        The deterministic part happens here and now, so the scores are durable regardless of
        what the AI does next; the row goes out as GENERATING and the task fills it in.

        With `awaiting_payment` (Assessment.report_requires_purchase) the scores are still stored
        now, but the row waits as AWAITING_PAYMENT and no model call is made until
        unlock_after_payment -- an unpaid completion costs nothing beyond this arithmetic.
        """
        scores = self.deep_report_service.score(attempt)
        report = self.report_repository.create_generating(
            attempt=attempt,
            report_version=DEEP_REPORT_VERSION,
            facet_scores=scores["facet_scores"],
            domain_scores=scores["domain_scores"],
            quality_metrics=scores["quality_metrics"],
            active_patterns=scores["active_patterns"],
            status=Report.Status.AWAITING_PAYMENT if awaiting_payment else Report.Status.GENERATING,
        )
        if awaiting_payment:
            return report
        # on_commit, not a bare delay(): the worker must not look for a row that a rolled-back
        # transaction never wrote. Autocommit is on today so this fires immediately -- it is
        # here so that wrapping this flow in atomic() later stays correct.
        # Closes over attempt_id, not attempt: on_commit retains this callback (and everything
        # it closes over) until commit, so binding just the id avoids keeping the full model
        # instance alive for that whole window.
        attempt_id = attempt.id
        transaction.on_commit(lambda: generate_deep_report.delay(attempt_id))
        return report

    def _start_initial_generation(self, attempt: Attempt) -> Report:
        """Initial reports also generate asynchronously: the AI call can take ~70s, and running
        it inside complete_attempt's request/response cycle blocked every other user on this
        app's single gunicorn worker, not just this requester.

        Scoring is fast and deterministic (pure DB read + arithmetic, no AI/network call), so it
        still happens here so the scores are durable even if generation later fails -- same
        reasoning as the deep report's split in _start_deep_generation above.
        """
        dimension_scores = self.scoring_service.score_attempt(attempt)
        logger.info("Initial report dimension_scores for attempt %s: %s", attempt.id, dimension_scores)
        report = self.report_repository.create_generating_initial(
            attempt=attempt, dimension_scores=dimension_scores,
        )
        attempt_id = attempt.id
        transaction.on_commit(lambda: generate_initial_report.delay(attempt_id))
        return report

    def unlock_after_payment(self, attempt_id: int) -> None:
        """Starts the paid generation for an AWAITING_PAYMENT deep report once its payment settled.
        Idempotent: only the call that flips the row enqueues the task (see
        ReportRepository.unlock_for_generation)."""
        if self.report_repository.unlock_for_generation(attempt_id):
            transaction.on_commit(lambda: generate_deep_report.delay(attempt_id))

    def generate_for_attempt(self, attempt: Attempt, *, awaiting_payment: bool = False) -> Report | None:
        """Dispatches report generation for the attempt. Returns None (no-op) if the assessment
        isn't a scored one, or the answer set isn't actually complete yet.

        Both report types return a GENERATING row immediately and fill it in on a Celery worker;
        see _start_deep_generation / _start_initial_generation.
        """
        existing = self.report_repository.get_by_attempt_id(attempt.id)
        if existing is not None:
            return existing

        scoring_service = self.scoring_router.for_attempt(attempt)
        if not scoring_service.is_complete(attempt):
            return None

        if self.scoring_router.is_deep(attempt):
            return self._start_deep_generation(attempt, awaiting_payment=awaiting_payment)

        return self._start_initial_generation(attempt)

    def retry_generation(
        self, *, attempt_id: int, user: User | None, anonymous_id: str | None,
    ) -> dict:
        """Re-dispatches generation for a report that ended in ERROR, reusing the attempt's
        already-scored answers -- the user never re-takes the test, exactly the "answers are
        safe, just retry" promise the failure screen makes. Returns the same `generating` shape
        get_report()/_shape() would, so the caller can poll it the same way as a fresh attempt.
        """
        report = self.report_repository.get_by_attempt_id(attempt_id)
        if report is None:
            raise ReportNotFoundException(f"No report found for attempt {attempt_id}")

        if not self._owns_attempt(report.attempt, user=user, anonymous_id=anonymous_id):
            raise ReportAccessDeniedException(f"Report for attempt {attempt_id} does not belong to this requester")

        if report.status != Report.Status.ERROR:
            raise ReportRetryNotAllowedException(f"Report {report.id} is not in error status")

        report = self.report_repository.retry(report)

        # Closes over ids, not the report/attempt instances -- same reasoning as
        # _start_deep_generation/_start_initial_generation above.
        attempt_id_captured = report.attempt_id
        if report.report_type == Report.ReportType.DEEP:
            transaction.on_commit(lambda: generate_deep_report.delay(attempt_id_captured))
        else:
            transaction.on_commit(lambda: generate_initial_report.delay(attempt_id_captured))

        return self._shape(report, user=user)

    @observe(
        REPORT_GENERATION_DURATION,
        in_progress=REPORT_GENERATION_IN_PROGRESS,
        labels={"report_type": "initial"},
        outcome=report_generation_outcome,
    )
    def generate_initial(self, attempt_id: int) -> Report | None:
        """Fills in the GENERATING row for an initial report. Called by the Celery task
        (report.generate_initial_report), not the request -- see _start_initial_generation.

        Never raises into the task: a generation failure becomes a stored `error` report.
        Claiming the row makes a redelivered Celery task a no-op instead of a second paid AI
        call for the same report -- same reasoning as DeepReportService.generate.
        """
        report = self.report_repository.claim_for_generation(attempt_id)
        if report is None:
            logger.warning(
                "initial generation skipped for attempt %s: no claimable report in GENERATING state",
                attempt_id,
            )
            return self.report_repository.get_by_attempt_id(attempt_id)

        try:
            return self._generate_initial(report)
        except Exception:
            logger.exception("initial generation raised for attempt %s", attempt_id)
            return self.report_repository.mark_error(
                report,
                error_code="generation_failed",
                error_message=get_message("report_generation_failed"),
            )

    def _generate_initial(self, report: Report) -> Report:
        attempt = report.attempt
        started = time.perf_counter()

        payload_started = time.perf_counter()
        payload = self._build_ai_payload(attempt, report.dimension_scores)
        payload_elapsed = time.perf_counter() - payload_started

        ai_started = time.perf_counter()
        response = self.ai_client.generate(payload)
        ai_elapsed = time.perf_counter() - ai_started

        logger.info(
            "generate_initial %s timing so far: payload(demographics)=%.2fs ai_call=%.2fs",
            attempt.id, payload_elapsed, ai_elapsed,
        )

        self._log_generation(attempt, response)

        if response["status"] == "error":
            report = self.report_repository.mark_error(
                report,
                error_code=response["error"]["code"],
                error_message=response["error"]["user_message"],
            )
            logger.info("generate_initial %s total=%.2fs (status=error)",
                        attempt.id, time.perf_counter() - started)
            return report

        db_started = time.perf_counter()
        report = self.report_repository.mark_ok(
            report,
            report_version=response["report_version"],
            report_data=response["report"],
            system_data=response.get("system", {}),
            memory_candidates=response.get("memory_candidates", []),
        )
        self.persist_memories(report)
        db_elapsed = time.perf_counter() - db_started

        logger.info(
            "generate_initial %s total=%.2fs (db_persist=%.2fs)",
            attempt.id, time.perf_counter() - started, db_elapsed,
        )
        return report

    def _build_full(self, report: Report) -> dict:
        return {
            "status": "ok",
            "stage": "full",
            "report_version": report.report_version,
            # The Report row's own PK — distinct from attempt_id. Exposed so the client can pass
            # it as target_id when submitting POST /api/feedback/ (target_type=report), which
            # looks up by this id, not by attempt_id.
            "report_id": report.id,
            "dimension_scores": report.dimension_scores,
            "report": report.report_data,
        }

    def _build_preview_v2(self, report: Report) -> dict:
        """report_spec_v2_0 §5.4. Everything the pre-login user sees is picked out here, field by
        field: cost/curiosity, the second finding's scene, open_question, suggested_step and exit
        are never copied, so they cannot reach the client even in dev tools (§5.4 gate)."""
        data = report.report_data
        first, second = data["findings"]
        return {
            "status": "ok",
            "stage": "preview",
            "report_version": report.report_version,
            "preview": {
                "hook": data["hook"],
                # Levels only, in the stored (fixed) order -- the v2 chart is not sorted by score.
                "dimension_scores": [
                    {"key": item["key"], "level": item["level"]} for item in report.dimension_scores
                ],
                "strength": {"title": data["strength"]["title"], "text": data["strength"]["text"]},
                "findings_heading": data["findings_heading"],
                "first_finding": {"area": first["area"], "title": first["title"], "what": first["what"]},
                "second_finding": {"area": second["area"], "title": second["title"]},
            },
        }

    def _build_preview(self, report: Report) -> dict:
        if _is_initial_v2(report):
            return self._build_preview_v2(report)

        report_data = report.report_data
        preview_scores = [
            {"key": item["key"], "level": item["level"]}
            for item in sorted(report.dimension_scores, key=lambda item: item["score_percent"], reverse=True)
        ]
        return {
            "status": "ok",
            "stage": "preview",
            "report_version": report.report_version,
            "preview": {
                "summary_one_line": report_data["summary"]["one_line"],
                "dimension_scores": preview_scores,
                "personality_pattern_first_paragraph": report_data["core_narrative"]["body"].split("\n\n")[0],
                "first_strength": {
                    "title": report_data["key_strengths"][0]["title"],
                    "description": report_data["key_strengths"][0]["description"],
                },
                "teaser_line": report_data["preview"]["teaser_line"],
                "locked_counts": {
                    "strengths": len(report_data["key_strengths"]),
                    "growth_edges": len(report_data["growth_edges"]),
                    "recommendations": len(report_data["growth_path"]["recommendations"]),
                },
            },
        }

    @staticmethod
    def _one_line(report: Report) -> str:
        """The single summary sentence, whichever report shape this row has.

        Falls back to "" if report_data is ever missing the expected key, so one malformed
        row degrades gracefully instead of taking down the requester's entire history list.
        """
        report_data = report.report_data or {}
        if report.report_type == Report.ReportType.DEEP:
            return report_data.get("identity_line", "")
        if _is_initial_v2(report):
            return report_data.get("hook", "")
        return report_data.get("summary", {}).get("one_line", "")

    def get_history(self, user: User) -> list[dict]:
        """One row per completed, scored attempt with a report, newest first."""
        reports = self.report_repository.get_history_for_user(user)
        return [
            {
                "attempt_id": report.attempt_id,
                "report_id": report.id,
                "report_type": report.report_type,
                "completed_at": report.attempt.completed_at,
                "summary_one_line": self._one_line(report),
            }
            for report in reports
        ]

    def get_attempts_history(self, user: User) -> list[dict]:
        """One row per attempt with a report of any status (generating/ok/error), newest first --
        unlike get_history (OK-only), this feeds the کاوش "history of attempts" page so a
        still-generating or failed attempt stays visible, and a failed one stays retryable,
        instead of silently disappearing once generation doesn't succeed on the first try."""
        reports = self.report_repository.get_attempts_history_for_user(user)
        return [
            {
                "attempt_id": report.attempt_id,
                "report_id": report.id,
                "report_type": report.report_type,
                "status": report.status,
                "completed_at": report.attempt.completed_at,
                "summary_one_line": self._one_line(report) if report.status == Report.Status.OK else "",
                "error_message": report.error_message if report.status == Report.Status.ERROR else "",
            }
            for report in reports
        ]

    @staticmethod
    def _build_deep(report: Report) -> dict:
        """The deep report as the client sees it.

        This is the boundary that enforces deep_report_spec_v1_2.md §2.4 and §9: levels only. `raw`,
        `provisional`, `core_domain_raw` and `core_facet_gap` are all stored on the row and
        none of them leave here — showing a number would turn a three-band description into a
        score, which is exactly the claim an un-normed instrument cannot make.

        Codes are still sent alongside the Persian titles: the client needs a stable key to
        match rows against `report_data`, and §9's rule is about what is *displayed*.
        """
        return {
            "status": "ok",
            "report_type": Report.ReportType.DEEP,
            "report_version": report.report_version,
            "report_id": report.id,
            "title": get_message("deep_report_title"),
            "disclaimer": get_message("deep_report_disclaimer"),
            "closing_reminder": get_message("deep_report_closing_reminder"),
            "domain_scores": [
                {
                    "code": domain["code"],
                    "title": get_message(f"deep_domain_title_{domain['code'].lower()}"),
                    "level": domain["level"],
                }
                for domain in report.domain_scores
            ],
            "facet_scores": [
                {
                    "code": facet["code"],
                    "domain": facet["domain"],
                    "title": get_message(f"deep_facet_title_{facet['code'].lower()}"),
                    "level": facet["level"],
                }
                for facet in report.facet_scores
            ],
            "report": report.report_data,
        }

    def _shape(self, report: Report, *, user: User | None) -> dict:
        if report.status == Report.Status.ERROR:
            return {
                "status": "error",
                "report_version": report.report_version,
                "error": {
                    "code": report.error_code,
                    "user_message": report.error_message,
                    "should_display_report": False,
                },
            }

        if report.status == Report.Status.AWAITING_PAYMENT:
            # Locked: nothing from the stored scores leaves the service.
            return {
                "status": "awaiting_payment",
                "report_type": report.report_type,
                "report_version": report.report_version,
                "payment_required": True,
            }

        if report.status == Report.Status.GENERATING:
            return {
                "status": "generating",
                "report_type": report.report_type,
                "report_version": report.report_version,
            }

        # TEMPORARY, see _with_fake_suggested_steps above -- in-memory only, never saved.
        if report.report_data:
            report.report_data = _with_fake_suggested_steps(report.report_data, report_type=report.report_type)

        if report.report_type == Report.ReportType.DEEP:
            # The deep test is purchase-gated, so its owner is always an authenticated user;
            # there is no anonymous preview tier to fall back to.
            if user is None:
                raise ReportAccessDeniedException("Deep reports require an authenticated user")
            return self._build_deep(report)

        return self._build_full(report) if user is not None else self._build_preview(report)

    def get_report(self, *, attempt_id: int, user: User | None, anonymous_id: str | None) -> dict:
        report = self.report_repository.get_by_attempt_id(attempt_id)
        if report is None:
            raise ReportNotFoundException(f"No report found for attempt {attempt_id}")

        if not self._owns_attempt(report.attempt, user=user, anonymous_id=anonymous_id):
            raise ReportAccessDeniedException(f"Report for attempt {attempt_id} does not belong to this requester")

        return self._shape(report, user=user)

    @staticmethod
    def _suggested_step_at(report: Report, index: int) -> dict:
        """The step data at 1-based `index`: the initial report's `growth_path.recommendations
        [i].suggested_step` (report_spec_v1_4 §4.3), or the deep report's `closing.small_actions
        [i]` directly -- deep_report_spec_v1_2.md §6.5 says each `small_actions` item already has exactly
        the `suggested_step` shape, not a nested field."""
        # TEMPORARY, see _with_fake_suggested_steps above -- in-memory only, never saved. This
        # method fetches its own `report` (accept_step doesn't go through _shape()), so it needs
        # its own patch too.
        report_data = _with_fake_suggested_steps(report.report_data or {}, report_type=report.report_type)
        try:
            if report.report_type == Report.ReportType.DEEP:
                return report_data["closing"]["small_actions"][index - 1]
            if _is_initial_v2(report):
                # report_spec_v2_0 §4.4: a single step, under the first finding. Its source stays
                # `initial_report:rec_1`, so only index 1 exists.
                if index != 1:
                    raise IndexError(index)
                step = report_data["findings"][0]["suggested_step"]
                if step is None:
                    raise KeyError("suggested_step")
                return step
            return report_data["growth_path"]["recommendations"][index - 1]["suggested_step"]
        except (KeyError, IndexError, TypeError):
            raise SuggestedStepNotFoundException(f"No suggested step at index {index} for report {report.id}")

    def _get_owned_ready_report(self, *, attempt_id: int, user: User) -> Report:
        """Shared preamble for accept_step/get_suggested_step: the report must exist, belong to
        this user, and be done generating before either one reads a suggested_step out of it."""
        report = self.report_repository.get_by_attempt_id(attempt_id)
        if report is None:
            raise ReportNotFoundException(f"No report found for attempt {attempt_id}")

        if not self._owns_attempt(report.attempt, user=user, anonymous_id=None):
            raise ReportAccessDeniedException(f"Report for attempt {attempt_id} does not belong to this requester")

        if report.status != Report.Status.OK:
            raise ReportNotReadyException()

        return report

    def accept_step(self, *, attempt_id: int, index: int, user: User) -> ActionStep:
        """Turns a report's suggested_step/small_action into a row in the action-steps table
        (action_steps_spec_v2 §3; report_spec_v1_4 §4.4; deep_report_spec_v1_2.md §6.5). `source` is built
        from the report type and the 1-based index -- `initial_report:rec_<n>` or
        `deep_report:action_<n>` -- matching ActionStepService's source validation."""
        report = self._get_owned_ready_report(attempt_id=attempt_id, user=user)
        step_data = self._suggested_step_at(report, index)

        source_prefix = "deep_report:action_" if report.report_type == Report.ReportType.DEEP else "initial_report:rec_"
        return self.action_step_service.create_step(
            user=user,
            source=f"{source_prefix}{index}",
            step_text=step_data["text"],
            deadline_type=step_data["deadline_type"],
            substeps=step_data.get("substeps"),
        )

    @staticmethod
    def _build_initial_v2_email_context(report: Report) -> dict:
        """report_v2 counterpart of _build_initial_email_context, laid out like the web page's
        dark design (faraman-front report-view-v2.tsx). No numbers anywhere (report_spec_v2_0 §2,
        §8): the radar labels carry the level word, and the polygon is the only place a score is
        drawn."""
        data = report.report_data
        scores_by_key = {item["key"]: item["score_percent"] for item in report.dimension_scores}
        levels_by_key = {item["key"]: item["level"] for item in report.dimension_scores}
        radar_labels = [
            {
                "title": presentation.INITIAL_DIMENSION_LABELS[key],
                "level": presentation.INITIAL_V2_LEVEL_LABELS[levels_by_key[key]],
            }
            for key, _angle in presentation.INITIAL_RADAR_AXES
            if key in levels_by_key
        ]
        findings = [
            {
                **finding,
                "area_label": presentation.FINDING_AREA_LABELS[finding["area"]],
                "pill": f"یافته‌ی {_FINDING_ORDINALS[i]} · {presentation.FINDING_AREA_LABELS[finding['area']]}",
            }
            for i, finding in enumerate(data["findings"])
        ]
        # The hook is two halves ("X، ولی Y."): the second is set apart in lilac, as on the page.
        hook = data["hook"]
        split_at = hook.find("، ")
        hook_first, hook_rest = (hook, "") if split_at == -1 else (hook[: split_at + 1], hook[split_at + 2:])
        frontend = settings.FRONTEND_URL.rstrip('/')
        return {
            "hook": hook,
            "hook_first": hook_first,
            "hook_rest": hook_rest,
            "summary_one_line": hook,
            "radar_points": presentation.initial_v2_radar_polygon(scores_by_key),
            "radar_rings": [presentation.initial_radar_ring(scale) for scale in (1, 2 / 3, 1 / 3)],
            "radar_labels": radar_labels,
            "strength": data["strength"],
            "findings_eyebrow": (
                f"{presentation.to_persian_digits(len(findings))} یافته · "
                + " و ".join(f["area_label"] for f in findings)
            ),
            "findings_heading": data["findings_heading"],
            "findings": findings,
            "open_question": data["open_question"]["text"],
            "exit": data["exit"],
            "explore_url": f"{frontend}/explore",
        }

    @staticmethod
    def _build_initial_email_context(report: Report) -> dict:
        """Precomputes everything the PDF template needs -- Persian labels, level colors, the
        radar geometry, the per-dimension notes joined on by key -- so the template itself stays
        pure presentation (Django templates can't do dict-by-dynamic-key lookups cleanly). The
        look mirrors the web report (report-view.tsx); the labels/colors/geometry come from
        report_presentation, a port of lib/utils/report.ts."""
        data = report.report_data
        notes_by_key = {item["key"]: item["text"] for item in data["snapshot_interpretations"]}
        scores_by_key = {item["key"]: item["score_percent"] for item in report.dimension_scores}
        levels_by_key = {item["key"]: item["level"] for item in report.dimension_scores}

        # Strongest first, like the web report's dimension cards.
        dimensions = [
            {
                "key": item["key"],
                "title": presentation.INITIAL_DIMENSION_LABELS[item["key"]],
                "icon": presentation.INITIAL_DIMENSION_ICONS[item["key"]],
                "score_percent": item["score_percent"],
                "score_text": presentation.to_persian_digits(item["score_percent"]),
                "level": presentation.INITIAL_LEVEL_LABELS[item["level"]],
                "color": presentation.INITIAL_LEVEL_COLORS[item["level"]]["color"],
                "bg": presentation.INITIAL_LEVEL_COLORS[item["level"]]["bg"],
                "note": notes_by_key.get(item["key"]),
            }
            for item in sorted(report.dimension_scores, key=lambda item: item["score_percent"], reverse=True)
        ]
        radar_labels = [
            {
                "title": presentation.INITIAL_DIMENSION_LABELS[key],
                "score_text": presentation.to_persian_digits(scores_by_key.get(key, 0)),
                "color": presentation.INITIAL_LEVEL_COLORS[levels_by_key[key]]["color"],
            }
            for key, _angle in presentation.INITIAL_RADAR_AXES
            if key in levels_by_key
        ]

        return {
            "summary_one_line": data["summary"]["one_line"],
            "dimension_scores": dimensions,
            "radar_points": presentation.initial_radar_polygon(scores_by_key),
            "radar_labels": radar_labels,
            "core_narrative_paragraphs": data["core_narrative"]["body"].split("\n\n"),
            "key_strengths": [
                {**strength, "icon": f"icon_strength_{i % 3 + 1}"}
                for i, strength in enumerate(data["key_strengths"])
            ],
            "growth_edges": data["growth_edges"],
            "life_pattern_cards": [
                {**card, "title": get_message(f"life_pattern_title_{card['key']}"), "number": presentation.to_persian_digits(i + 1)}
                for i, card in enumerate(data["life_pattern_cards"])
            ],
            "growth_path": {
                **data["growth_path"],
                "recommendations": [
                    {**rec, "number": presentation.to_persian_digits(i + 1)}
                    for i, rec in enumerate(data["growth_path"]["recommendations"])
                ],
            },
            "explore_url": f"{settings.FRONTEND_URL.rstrip('/')}/explore",
        }

    @staticmethod
    def _build_deep_email_context(report: Report) -> dict:
        """Same idea as _build_initial_email_context: resolves every code/level into its
        Persian label up front, and joins facet titles (only available on facet_scores) onto
        each domain's facets (only available on report_data.domains) so the template can just
        iterate report_data.domains directly instead of cross-referencing two lists itself.
        Mirrors deep-report-view.tsx; levels stay three-band strips, never numbers
        (deep_report_spec_v1_2.md §2.4)."""
        data = report.report_data
        facet_titles = {facet["code"]: get_message(f"deep_facet_title_{facet['code'].lower()}") for facet in report.facet_scores}
        domain_titles = {domain["code"]: get_message(f"deep_domain_title_{domain['code'].lower()}") for domain in report.domain_scores}
        domain_levels = {domain["code"]: domain["level"] for domain in report.domain_scores}
        level_label = presentation.DEEP_LEVEL_LABELS
        to_digits = presentation.to_persian_digits

        topic_pages = [
            {
                "title": get_message(f"topic_page_title_{key}"),
                "lead": get_message(f"deep_topic_lead_{key}"),
                "image": presentation.DEEP_TOPIC_IMAGES[key],
                "rows": [{**row, "number": to_digits(i + 1)} for i, row in enumerate(data[key]["rows"])],
                "closing": data[key]["closing"],
            }
            for key in presentation.DEEP_TOPIC_ORDER
        ]

        bands = presentation.DEEP_DOMAIN_BANDS
        domains = [
            {
                "code": domain["code"],
                "title": domain_titles[domain["code"]],
                "level": level_label[domain_levels[domain["code"]]],
                "image": presentation.DEEP_DOMAIN_IMAGES.get(domain["code"], "deep_domain_n"),
                "band": bands[i % len(bands)],
                "summary": domain["summary"],
                "facets": [
                    {
                        "title": facet_titles[facet["code"]],
                        "level": level_label[facet["level"]],
                        "bands": presentation.deep_level_bands(facet["level"]),
                        "when_it_works": facet["when_it_works"],
                        "when_it_costs": facet["when_it_costs"],
                    }
                    for facet in domain["facets"]
                ],
            }
            for i, domain in enumerate(data["domains"])
        ]

        domain_codes = [domain["code"] for domain in report.domain_scores]
        # In axis order (top, then clockwise) -- the template lays them around the chart.
        radar_labels = [
            {"title": domain_titles[domain["code"]], "level": level_label[domain["level"]]}
            for domain in report.domain_scores
        ]

        return {
            "title": get_message("deep_report_title"),
            "disclaimer": get_message("deep_report_disclaimer"),
            "closing_reminder": get_message("deep_report_closing_reminder"),
            "identity_line": data["identity_line"],
            "top_strengths": [{"text": text, "number": to_digits(i + 1)} for i, text in enumerate(data["top_strengths"])],
            "growth_priorities": [{"text": text, "number": to_digits(i + 1)} for i, text in enumerate(data["growth_priorities"])],
            "confidence_note": data["confidence_note"],
            "domains_overview": [
                {**overview, "level": level_label[overview["level"]], "bands": presentation.deep_level_bands(overview["level"])}
                for overview in data["domains_overview"]
            ],
            "radar_points": presentation.deep_radar_polygon([(d["code"], d["level"]) for d in report.domain_scores]),
            "radar_rings": [presentation.deep_radar_ring(domain_codes, fraction) for fraction in (0.94, 0.68, 0.42)],
            "radar_labels": radar_labels,
            "integrated_interpretation": data["integrated_interpretation"],
            "domains": domains,
            "strengths": {
                **data["strengths"],
                "items": [{**item, "number": to_digits(i + 1)} for i, item in enumerate(data["strengths"]["items"])],
            },
            "blind_spots": {
                **data["blind_spots"],
                "items": [{**item, "number": to_digits(i + 1)} for i, item in enumerate(data["blind_spots"]["items"])],
                "reflection_questions": [
                    {"text": text, "number": to_digits(i + 1)}
                    for i, text in enumerate(data["blind_spots"]["reflection_questions"])
                ],
            },
            "topic_pages": topic_pages,
            "closing": data["closing"],
            "explore_url": f"{settings.FRONTEND_URL.rstrip('/')}/explore",
        }

    def email_report(self, *, attempt_id: int, user: User, email: str) -> None:
        """Renders the report as a PDF and emails it to `email` as an attachment, with a short
        notice as the email body.

        Manual, on-demand action (the report page's "email me this report" card) -- the address
        isn't stored on User, but each send attempt is recorded in ReportEmailDelivery. There is
        deliberately no Celery task here: an SMTP send (and the PDF render that precedes it) is
        fast enough to do inline, same as OTP SMS delivery already does in this codebase.
        """
        report = self._get_owned_ready_report(attempt_id=attempt_id, user=user)

        if self.report_email_throttle_repository.hit(user.id, attempt_id):
            THROTTLE_REJECTED.labels(scope="report_email").inc()
            raise ReportEmailThrottledException()

        notice_template = "report/email_pdf_notice.html"
        if report.report_type == Report.ReportType.DEEP:
            pdf_template = "report/pdf_deep.html"
            context = self._build_deep_email_context(report)
            subject = get_message("report_email_subject_deep")
            summary_line = context["identity_line"]
        elif _is_initial_v2(report):
            pdf_template = "report/pdf_initial_v2.html"
            notice_template = "report/email_pdf_notice_v2.html"
            context = self._build_initial_v2_email_context(report)
            subject = get_message("report_email_subject_initial")
            summary_line = context["summary_one_line"]
        else:
            pdf_template = "report/pdf_initial.html"
            context = self._build_initial_email_context(report)
            subject = get_message("report_email_subject_initial")
            summary_line = context["summary_one_line"]

        try:
            pdf_html = render_to_string(pdf_template, {**context, **self.pdf_service.font_context(), **self.pdf_service.image_context()})
            notice_html = render_to_string(
                notice_template,
                {"heading": subject, "summary_line": summary_line, "explore_url": context["explore_url"]},
            )
        except (KeyError, TypeError, IndexError):
            # report_data is AI-validated on the way in (apps/ai/*/schema.py), so a missing/
            # malformed key here means corrupt data, not a client error -- same reasoning as
            # ScoreOutOfRangeException. Caught here, not left to bubble, so it turns into the
            # standard ApiResponse.error(...) envelope (hard rule 3) instead of a raw 500.
            logger.exception("report email template render failed for report %s", report.id)
            raise ReportEmailDeliveryFailedException()

        pdf_bytes = self.pdf_service.render_pdf(pdf_html)

        sent = self.email_service.send_html(
            email, subject, notice_html,
            pdf_attachment=pdf_bytes, pdf_filename=f"faraman-report-{attempt_id}.pdf",
        )
        self.report_email_delivery_repository.create(
            user=user, attempt=report.attempt, report_type=report.report_type, email=email, sent=sent,
        )
        if not sent:
            raise ReportEmailDeliveryFailedException()

    def get_suggested_step(self, *, attempt_id: int, index: int, user: User) -> dict:
        """Read-only counterpart to accept_step -- same ownership/readiness checks, but never
        writes an ActionStep row. Used by ChatService to build action_rejected's context_action
        from a report suggestion the user rejected before ever accepting it: action_steps_spec_v2_2.md §3
        says rejecting just enters chat, it doesn't register anything."""
        report = self._get_owned_ready_report(attempt_id=attempt_id, user=user)
        return self._suggested_step_at(report, index)

    def has_report_generating(self, *, assessment, user: User | None, anonymous_id: str | None) -> bool:
        """Whether this identity has a report (initial or deep) still generating for this
        assessment.

        Used to block starting a second attempt while the first's async generation is still
        in flight (deep_report_spec_v1_2.md §5.1's eight model calls are paid for once per attempt; the
        same reasoning applies to the initial report's single call).
        """
        return self.report_repository.exists_generating_for_identity(
            assessment=assessment, user=user, anonymous_id=anonymous_id
        )

    def get_latest_for_identity(
        self, *, assessment, user: User | None, anonymous_id: str | None
    ) -> dict | None:
        """The most recent report for this assessment/identity, shaped the same way get_report()
        does (preview for anonymous, full for authenticated). None if no report exists yet."""
        report = self.report_repository.get_latest_for_identity(
            assessment=assessment, user=user, anonymous_id=anonymous_id
        )
        if report is None:
            return None

        return {"attempt_id": report.attempt_id, **self._shape(report, user=user)}
