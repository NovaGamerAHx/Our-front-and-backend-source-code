from collections import defaultdict

from apps.assessment.models import Attempt
from apps.assessment.repositories.assessment_repository import AssessmentRepository
from apps.report.services.exceptions import ScoreOutOfRangeException

DIMENSION_ORDER = [
    "emotional_stability",
    "extraversion",
    "openness",
    "agreeableness",
    "conscientiousness",
]

# score_percent -> level, report_spec_v1.3 §1
LEVEL_BANDS = [
    (0, 19, "very_low"),
    (20, 39, "low"),
    (40, 59, "medium"),
    (60, 79, "medium_high"),
    (80, 100, "high"),
]


class ScoringService:
    """Computes Big Five dimension scores from an attempt's answers (report_spec_v1.3 §1).

    A question's dimension is its section's `title` — no separate per-question field. A section
    only counts toward scoring if its title is exactly one of DIMENSION_ORDER's keys, so
    non-scored assessments (e.g. placeholder test ones, with sections titled e.g. "General")
    simply have no scored questions and `is_complete` returns False for them.
    """

    def __init__(self, assessment_repository=None):
        self.assessment_repository = assessment_repository or AssessmentRepository()

    @staticmethod
    def _level_for(score_percent: int) -> str:
        for low, high, level in LEVEL_BANDS:
            if low <= score_percent <= high:
                return level
        raise ScoreOutOfRangeException(f"score_percent {score_percent} is out of the 0-100 range")

    def get_required_question_ids(self, attempt: Attempt) -> set[int]:
        return self.assessment_repository.get_active_question_ids_for_sections(attempt.assessment, DIMENSION_ORDER)

    def is_complete(self, attempt: Attempt) -> bool:
        required_ids = self.get_required_question_ids(attempt)
        if not required_ids:
            return False

        answered_ids = set(attempt.answers.values_list("question_id", flat=True))
        return required_ids.issubset(answered_ids)

    def score_attempt(self, attempt: Attempt) -> list[dict]:
        """Returns section 1's `dimension_scores`: exactly the 5 dimensions, in DIMENSION_ORDER.

        Assumes completeness (call `is_complete` first) — with a full answer set each dimension
        has exactly 6 answers, so no partial-dimension handling is needed here.
        """
        factor_sums = defaultdict(int)
        for answer in attempt.answers.select_related("question__section"):
            question = answer.question
            dimension = question.section.title
            if dimension not in DIMENSION_ORDER:
                continue
            factor_sums[dimension] += 6 - answer.value if question.reverse_scored else answer.value

        dimension_scores = []
        for dimension in DIMENSION_ORDER:
            score_percent = round((factor_sums[dimension] - 6) / 24 * 100)
            dimension_scores.append(
                {"key": dimension, "score_percent": score_percent, "level": self._level_for(score_percent)}
            )
        return dimension_scores
