"""HTTP-boundary client for the report-generation AI pipeline (report_spec_v1.3 §3 request /
§4 response contract).

The actual prompt/schema/retry-ladder logic lives in apps.ai.report_generation -- reusable
by any future AI feature, not just this one. This class is just apps.report's adapter: it
translates the payload ReportService builds (attempt/demographics/dimension_scores/
answer_quality) into apps.ai's generic dimension_scores + context_profile contract, and
back. The request/response dict shapes below are the contract ReportService/ReportRepository
depend on -- preserve them exactly.
"""

from django.utils import timezone

from apps.ai.report_generation.client import ReportGenerationClient


class AiReportClient:
    def __init__(self, client=None):
        # Optional injected OpenAI-shaped client -- lets tests avoid real network calls.
        self._report_generation_client = ReportGenerationClient(openai_client=client)

    @staticmethod
    def _current_jalali_year() -> int:
        """The Jalali (Solar Hijri) year today. Nowruz falls on March 20 or 21; treating
        March 21 as the boundary is off by at most a day, which is noise next to an age
        derived from a birth year alone (no birth month/day is collected)."""
        today = timezone.localdate()
        return today.year - 621 if (today.month, today.day) >= (3, 21) else today.year - 622

    @staticmethod
    def _build_context_profile(demographics: dict) -> dict | None:
        """payload["demographics"] -> apps.ai.report_generation's context_profile shape.

        `gender` is never included (report_spec_v1.3 §3.5 rule 1). `birth_year` becomes
        `age` as a string. birth_year is a Jalali year (DemographicsSerializer only accepts
        1300-1450), so it's subtracted from the current Jalali year, not the Gregorian one.
        """
        context_profile = {}

        birth_year = demographics.get("birth_year")
        if birth_year:
            context_profile["age"] = str(AiReportClient._current_jalali_year() - birth_year)

        life_situation = demographics.get("life_situation")
        if life_situation:
            context_profile["life_situation"] = life_situation

        goal = demographics.get("goal")
        if goal:
            context_profile["current_goal"] = goal

        return context_profile or None

    def generate(self, payload: dict) -> dict:
        """payload matches report_spec_v1.3 §3 (assessment/dimension_scores/answer_quality),
        plus the two keys report_v3 added (docs/report_spec_v3_0.md §3):

          * `answers`: {"q1".."q30": 1..5} in the v3 question contract's id space, built by
            ReportV3InputService. Absent for v1/v2 payloads, which do not need it.
          * `report_version`: the version pinned on the Report row, so a worker that picks up
            a row queued before a deploy still generates the shape that row promised.

        Both are read with .get(): a v1/v2 caller's payload is unchanged and keeps working.

        Returns report_spec_v1.3 §4.1 (status="ok") or §4.2 (status="error") shaped dict.
        """
        return self._report_generation_client.generate(
            dimension_scores=payload["dimension_scores"],
            context_profile=self._build_context_profile(payload["demographics"]),
            answers=payload.get("answers"),
            version=payload.get("report_version") or None,
        )
