import base64
import logging
from functools import lru_cache
from pathlib import Path

from weasyprint import HTML

from apps.report.services.exceptions import ReportPdfGenerationFailedException
from faraman_back.observability.metrics import REPORT_PDF_RENDER_DURATION, observe

logger = logging.getLogger(__name__)

_FONT_DIR = Path(__file__).resolve().parent.parent / "assets" / "fonts"
_FONT_FILES = {
    "vazirmatn_regular_b64": "Vazirmatn-Regular.woff2",
    "vazirmatn_bold_b64": "Vazirmatn-Bold.woff2",
}


_IMAGE_DIR = Path(__file__).resolve().parent.parent / "assets" / "images"
# Template-facing key -> file under assets/images. Resized copies of the frontend's
# public/deep-report and public/report-icons illustrations (the PDF ships them embedded, so they
# are kept small -- the originals are ~1MB each).
_IMAGE_FILES = {
    "deep_cover": "deep/deep-cover-hq.png",
    "deep_domain_n": "deep/deep-domain-n-v2.png",
    "deep_domain_e": "deep/deep-domain-e.png",
    "deep_domain_o": "deep/deep-domain-o.png",
    "deep_domain_a": "deep/deep-domain-a.png",
    "deep_domain_c": "deep/deep-domain-c.png",
    "deep_strengths": "deep/deep-strengths.jpg",
    "deep_blind": "deep/deep-blind.jpg",
    "deep_decision": "deep/deep-decision.png",
    "deep_communication": "deep/deep-communication.png",
    "deep_work": "deep/deep-work.png",
    "deep_stress": "deep/deep-stress.png",
    "deep_learning": "deep/deep-learning.png",
    "deep_relations": "deep/deep-relations.png",
    "deep_closing": "deep/deep-closing.png",
    "icon_dim_emotional": "icons/dim-emotional.png",
    "icon_dim_social": "icons/dim-social.png",
    "icon_dim_growth": "icons/dim-growth.png",
    "icon_dim_empathy": "icons/dim-empathy.png",
    "icon_dim_responsibility": "icons/dim-responsibility.png",
    "icon_personality": "icons/personality.png",
    "icon_personality_pattern": "icons/personality-pattern.png",
    "icon_key_strengths": "icons/key-strengths.png",
    "icon_watch_out": "icons/watch-out.png",
    "icon_real_situations": "icons/real-situations.png",
    "icon_growth_path": "icons/growth-path.png",
    "icon_strength_1": "icons/strength-1.png",
    "icon_strength_2": "icons/strength-2.png",
    "icon_strength_3": "icons/strength-3.png",
    # report_v2's four illustrations (the design's rv3-* slots), JPEG at 900px wide.
    "v2_hero": "report_v2/hero.jpg",
    "v2_strength": "report_v2/strength.jpg",
    "v2_finding_1": "report_v2/finding_1.jpg",
    "v2_finding_2": "report_v2/finding_2.jpg",
}
_IMAGE_MIME = {".png": "image/png", ".jpg": "image/jpeg"}


@lru_cache(maxsize=None)
def _read_image_data_uri(filename: str) -> str:
    path = _IMAGE_DIR / filename
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{_IMAGE_MIME[path.suffix]};base64,{encoded}"


@lru_cache(maxsize=None)
def _read_font_b64(filename: str) -> str:
    return base64.b64encode((_FONT_DIR / filename).read_bytes()).decode("ascii")


class ReportPdfService:
    """WeasyPrint wrapper -- same shape as EmailService/BaleService: a stateless external-
    library boundary with no DB/Redis access. Deliberately does not own template lookup or
    rendering -- ReportService still decides which template/context to render, exactly as it
    already does for the email body, so a broken template/context mismatch stays a plain
    Django error in a test that needs no WeasyPrint/native libs installed to run.
    """

    @staticmethod
    def font_context() -> dict:
        """Base64-encoded font bytes for the PDF templates' @font-face rules -- embedded
        directly rather than referenced by path/URL, since this project has no MEDIA_ROOT and
        STATIC_ROOT only exists post-collectstatic (never run in tests), so WeasyPrint never
        needs a resolvable base_url."""
        return {name: _read_font_b64(filename) for name, filename in _FONT_FILES.items()}

    @staticmethod
    def image_context() -> dict:
        """`images` -> {key: data URI} for the PDF templates' <img> tags, embedded for the same
        reason as the fonts. Templates only reference the keys they use; unused ones cost
        nothing in the rendered PDF."""
        return {"images": {key: _read_image_data_uri(filename) for key, filename in _IMAGE_FILES.items()}}

    @observe(REPORT_PDF_RENDER_DURATION)
    def render_pdf(self, html_string: str) -> bytes:
        try:
            return HTML(string=html_string).write_pdf()
        except Exception:
            logger.exception("WeasyPrint PDF render failed")
            raise ReportPdfGenerationFailedException()
