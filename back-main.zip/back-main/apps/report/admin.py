from django.contrib import admin

from apps.report.models import GenerationLog, Memory, Report, ReportEmailDelivery


@admin.register(Report)
class ReportAdmin(admin.ModelAdmin):
    list_display = ("id", "attempt", "report_type", "status", "report_version", "memories_persisted_at", "created_at")
    list_filter = ("report_type", "status", "report_version")
    search_fields = ("attempt__id", "attempt__user__phone_number", "attempt__anonymous_id")
    readonly_fields = [f.name for f in Report._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


@admin.register(Memory)
class MemoryAdmin(admin.ModelAdmin):
    # `source` is part of the identity of a memory, not a detail: (user, memory_type, source)
    # is what supersedes what, so a list without it looks like duplicate rows.
    list_display = ("id", "user", "memory_type", "source", "confidence", "sensitivity_level", "created_at")
    list_filter = ("memory_type", "source", "confidence", "sensitivity_level")
    search_fields = ("user__phone_number", "text_memory")
    readonly_fields = [f.name for f in Memory._meta.fields]

    def has_add_permission(self, request):
        return False


@admin.register(GenerationLog)
class GenerationLogAdmin(admin.ModelAdmin):
    list_display = ("id", "attempt", "user", "model_used", "attempts", "input_tokens", "cached_input_tokens", "output_tokens", "cost", "created_at")
    list_filter = ("model_used",)
    search_fields = ("attempt__id", "user__phone_number")
    readonly_fields = [f.name for f in GenerationLog._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


@admin.register(ReportEmailDelivery)
class ReportEmailDeliveryAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "attempt", "report_type", "email", "status", "created_at")
    list_filter = ("report_type", "status")
    search_fields = ("email", "user__phone_number", "attempt__id")
    readonly_fields = [f.name for f in ReportEmailDelivery._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
