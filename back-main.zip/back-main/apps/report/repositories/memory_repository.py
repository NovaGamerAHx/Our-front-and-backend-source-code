from django.utils import timezone

from apps.account.models import User
from apps.report.models import Memory


class MemoryRepository:
    def upsert(
        self, *, user: User, memory_type: str, text_memory: str, source: str, confidence: str,
        sensitivity_level: str,
    ) -> Memory:
        # `source` is part of the key, not the payload (deep_report_spec_v1_2.md §6.3): a newer report
        # from the same source supersedes its own row, but a different source (deep vs initial)
        # starts an independent lineage instead of overwriting the other one.
        memory, _ = Memory.objects.update_or_create(
            user=user,
            memory_type=memory_type,
            source=source,
            defaults={
                "text_memory": text_memory,
                "confidence": confidence,
                "sensitivity_level": sensitivity_level,
                "is_deleted": False,
                "deleted_at": None,
            },
        )
        return memory

    def get_for_user(self, user: User) -> list[Memory]:
        return list(Memory.objects.filter(user=user, is_deleted=False))

    def soft_delete_for_user(self, user: User) -> int:
        return Memory.objects.filter(user=user, is_deleted=False).update(is_deleted=True, deleted_at=timezone.now())
