from decimal import Decimal

from django.utils import timezone

from apps.account.models import User
from apps.assessment.models import Attempt
from apps.report.models import GenerationLog


class GenerationLogRepository:
    def create(
        self, *, attempt: Attempt, user: User | None, model_used: str | None, attempts: int,
        input_tokens: int, output_tokens: int, latency_s: float, cost: Decimal | None,
        call_key: str = "", cached_input_tokens: int = 0,
    ) -> GenerationLog:
        return GenerationLog.objects.create(
            attempt=attempt,
            user=user,
            call_key=call_key,
            model_used=model_used,
            attempts=attempts,
            input_tokens=input_tokens,
            cached_input_tokens=cached_input_tokens,
            output_tokens=output_tokens,
            latency_s=latency_s,
            cost=cost,
        )

    def soft_delete_for_user(self, user: User) -> int:
        return GenerationLog.objects.filter(user=user, is_deleted=False).update(
            is_deleted=True, deleted_at=timezone.now()
        )
