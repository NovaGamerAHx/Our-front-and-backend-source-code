import logging

import redis
from django.conf import settings

logger = logging.getLogger(__name__)

REPORT_EMAIL_LIMIT_COUNT = 3
REPORT_EMAIL_LIMIT_WINDOW_SECONDS = 60 * 60  # 1h


class ReportEmailThrottleRepository:
    """Fixed-window counter limiting how many times a user can email a given report.

    The endpoint accepts an arbitrary destination address, so without a limit it's a spam/
    harassment vector (repeatedly emailing a stranger). Fails open on Redis errors, same as
    AttemptThrottleRepository (apps/assessment/repositories/attempt_throttle_repository.py) --
    an outage shouldn't block a legitimate send."""

    def __init__(self):
        self._client = None

    @property
    def client(self):
        if self._client is None:
            self._client = redis.StrictRedis(
                host=getattr(settings, 'REDIS_HOST', 'localhost'),
                port=getattr(settings, 'REDIS_PORT', 6379),
                db=getattr(settings, 'REDIS_DB', 0),
                password=getattr(settings, 'REDIS_PASSWORD', ''),
                decode_responses=True,
            )
        return self._client

    @staticmethod
    def _key(user_id: int, attempt_id: int) -> str:
        return f"report_email_limit:{user_id}:{attempt_id}"

    def hit(self, user_id: int, attempt_id: int) -> bool:
        """Increments the counter for user_id/attempt_id and returns whether it is now over
        REPORT_EMAIL_LIMIT_COUNT within the current window."""
        try:
            key = self._key(user_id, attempt_id)
            count = self.client.incr(key)
            if count == 1:
                self.client.expire(key, REPORT_EMAIL_LIMIT_WINDOW_SECONDS)
            return count > REPORT_EMAIL_LIMIT_COUNT
        except Exception:
            logger.exception(f"Failed to check report email limit for user {user_id}/attempt {attempt_id}")
            return False
