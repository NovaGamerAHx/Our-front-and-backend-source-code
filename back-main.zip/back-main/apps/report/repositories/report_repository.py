from django.utils import timezone

from apps.account.models import User
from apps.assessment.models import Assessment, Attempt
from apps.report.models import Report, RejectedFinding


class ReportRepository:
    def rejected_keys(self, report):
        return set(RejectedFinding.objects.filter(report=report).values_list("key", flat=True))

    def reject_finding(self, report, key):
        RejectedFinding.objects.get_or_create(report=report, key=key)

    def get_by_attempt_id(self, attempt_id: int) -> Report | None:
        return Report.objects.select_related("attempt").filter(attempt_id=attempt_id).first()

    def get_by_id(self, report_id: int) -> Report | None:
        return Report.objects.select_related("attempt").filter(id=report_id).first()

    def create_ok(
        self, *, attempt: Attempt, report_version: str, dimension_scores: list, report_data: dict,
        system_data: dict, memory_candidates: list,
    ) -> Report:
        return Report.objects.create(
            attempt=attempt,
            report_version=report_version,
            status=Report.Status.OK,
            dimension_scores=dimension_scores,
            report_data=report_data,
            system_data=system_data,
            memory_candidates=memory_candidates,
        )

    def create_generating(
        self, *, attempt: Attempt, report_version: str, facet_scores: list, domain_scores: list,
        quality_metrics: dict, active_patterns: list, status: str = Report.Status.GENERATING,
    ) -> Report:
        """The deep report's row, written before its content exists (generation is async).

        The scores go in now rather than at completion on purpose: they are deterministic, they
        are what future norming needs (deep_report_spec_v1_2.md §7.3), and they should survive even if
        generation later fails.

        `status` is AWAITING_PAYMENT for a pay-after-test assessment: same stored scores, but
        no generation until unlock_for_generation flips it.
        """
        return Report.objects.create(
            attempt=attempt,
            report_type=Report.ReportType.DEEP,
            report_version=report_version,
            status=status,
            facet_scores=facet_scores,
            domain_scores=domain_scores,
            quality_metrics=quality_metrics,
            active_patterns=active_patterns,
        )

    def create_generating_initial(
        self, *, attempt: Attempt, dimension_scores: list, report_version: str = "",
    ) -> Report:
        """The initial report's row, written before its AI content exists (generation is async,
        same shape as create_generating above but for the initial type).

        report_version is now pinned at creation (it used to be left at its implicit ""
        default until mark_ok): the row is created in the request, and the Celery worker picks
        it up seconds-to-minutes later, possibly on a host that has already been redeployed
        with a different REPORT_INITIAL_VERSION. Without the pin, a deploy mid-queue makes the
        worker generate a shape nobody asked for, and -- with report_v3 -- feed the model an
        input built for a different version. mark_ok still overwrites it with whatever
        version actually produced the content, so a fallback inside the generator is still
        recorded truthfully.
        """
        return Report.objects.create(
            attempt=attempt,
            report_type=Report.ReportType.INITIAL,
            status=Report.Status.GENERATING,
            dimension_scores=dimension_scores,
            report_version=report_version,
        )

    def unlock_for_generation(self, attempt_id: int) -> bool:
        """Atomically flips an AWAITING_PAYMENT report to GENERATING. True only for the caller that
        actually flipped it, so a payment verified twice (callback + reconciliation, or a repeated
        browser hit) enqueues the paid AI generation once."""
        return bool(
            Report.objects.filter(attempt_id=attempt_id, status=Report.Status.AWAITING_PAYMENT)
            .update(status=Report.Status.GENERATING)
        )

    def claim_for_generation(self, attempt_id: int) -> Report | None:
        """Atomically claims a GENERATING report for processing exactly once.

        Celery's at-least-once delivery can redeliver `generate_deep_report` (worker restart,
        manual re-queue); a plain status read-then-write lets two workers both pass the check
        and both make the paid AI call. This is a single conditional UPDATE instead, so only
        the worker that actually flips `generation_started_at` from null gets a non-None result.
        """
        claimed = Report.objects.filter(
            attempt_id=attempt_id, status=Report.Status.GENERATING, generation_started_at__isnull=True,
        ).update(generation_started_at=timezone.now())
        if not claimed:
            return None
        return self.get_by_attempt_id(attempt_id)

    def mark_ok(
        self, report: Report, *, report_version: str, report_data: dict, system_data: dict,
        memory_candidates: list, dimension_scores: list | None = None,
    ) -> Report:
        """Fills in a finished generation. `dimension_scores` is optional and only passed by
        report_v3: v3 derives its scores with JavaScript-compatible rounding so the numbers the
        model was given and the numbers the page shows are the same ones (they can differ by a
        point from ScoringService's bankers rounding -- see ReportV3InputService
        .dimension_scores). Overwriting them here rather than at row-creation time is safe:
        a GENERATING report exposes nothing but its status, so no client has read the
        provisional values."""
        report.report_version = report_version
        report.status = Report.Status.OK
        report.report_data = report_data
        report.system_data = system_data
        report.memory_candidates = memory_candidates
        report.error_code = ""
        report.error_message = ""
        fields = [
            "report_version", "status", "report_data", "system_data", "memory_candidates",
            "error_code", "error_message",
        ]
        if dimension_scores is not None:
            report.dimension_scores = dimension_scores
            fields.append("dimension_scores")
        report.save(update_fields=fields)
        return report

    def mark_error(self, report: Report, *, error_code: str, error_message: str) -> Report:
        report.status = Report.Status.ERROR
        report.error_code = error_code
        report.error_message = error_message
        report.save(update_fields=["status", "error_code", "error_message"])
        return report

    def retry(self, report: Report, *, report_version: str | None = None) -> Report:
        """Resets an ERROR report back to GENERATING so it can be re-claimed by
        claim_for_generation -- the same atomic "flip generation_started_at from null" gate a
        fresh row goes through, so a redelivered/duplicate retry task still only pays for the
        AI call once.

        `report_version` re-pins the row (initial reports only, see ReportService
        .retry_generation). A retry means "try again now, under the configuration that is
        live now": if an operator rolled REPORT_INITIAL_VERSION back after a bad generation,
        the retry must follow that rollback instead of faithfully reproducing the failure.
        None leaves the stored version untouched (deep reports, which have exactly one)."""
        report.status = Report.Status.GENERATING
        report.error_code = ""
        report.error_message = ""
        report.generation_started_at = None
        fields = ["status", "error_code", "error_message", "generation_started_at"]
        if report_version is not None:
            report.report_version = report_version
            fields.append("report_version")
        report.save(update_fields=fields)
        return report

    def create_error(self, *, attempt: Attempt, report_version: str, error_code: str, error_message: str) -> Report:
        return Report.objects.create(
            attempt=attempt,
            report_version=report_version,
            status=Report.Status.ERROR,
            error_code=error_code,
            error_message=error_message,
        )

    def mark_memories_persisted(self, report: Report) -> None:
        report.memories_persisted_at = timezone.now()
        report.save(update_fields=["memories_persisted_at"])

    def get_unpersisted_for_user(self, user) -> list[Report]:
        return list(
            Report.objects.select_related("attempt")
            .filter(
                attempt__user=user, attempt__is_deleted=False, status=Report.Status.OK,
                memories_persisted_at__isnull=True,
            )
        )

    def get_history_for_user(self, user) -> list[Report]:
        return list(
            Report.objects.select_related("attempt")
            .filter(attempt__user=user, attempt__is_deleted=False, status=Report.Status.OK)
            .order_by("-attempt__completed_at")
        )

    def get_attempts_history_for_user(self, user) -> list[Report]:
        """Every report row for this user regardless of status (generating/ok/error), newest
        first -- unlike get_history_for_user (OK only), this backs the "history of attempts"
        page so a still-generating or failed attempt stays visible (and, for a failed one,
        retryable) instead of silently disappearing."""
        return list(
            Report.objects.select_related("attempt")
            .filter(attempt__user=user, attempt__is_deleted=False)
            .order_by("-attempt__completed_at")
        )

    def exists_generating_for_identity(
        self, *, assessment: Assessment, user: User | None, anonymous_id: str | None
    ) -> bool:
        queryset = Report.objects.filter(
            attempt__assessment=assessment, attempt__is_deleted=False, status=Report.Status.GENERATING,
        )
        if user is not None:
            return queryset.filter(attempt__user=user).exists()
        return queryset.filter(attempt__user__isnull=True, attempt__anonymous_id=anonymous_id).exists()

    def get_latest_for_identity(
        self, *, assessment: Assessment, user: User | None, anonymous_id: str | None
    ) -> Report | None:
        queryset = Report.objects.select_related("attempt").filter(
            attempt__assessment=assessment, attempt__is_deleted=False, status=Report.Status.OK
        ).order_by("-attempt__completed_at")
        if user is not None:
            return queryset.filter(attempt__user=user).first()
        return queryset.filter(attempt__user__isnull=True, attempt__anonymous_id=anonymous_id).first()
