from django.utils import timezone

from apps.account.models import User
from apps.assessment.models import Attempt
from apps.report.models import ReportEmailDelivery


class ReportEmailDeliveryRepository:
    def create(
        self, *, user: User, attempt: Attempt, report_type: str, email: str, sent: bool,
    ) -> ReportEmailDelivery:
        return ReportEmailDelivery.objects.create(
            user=user,
            attempt=attempt,
            report_type=report_type,
            email=email,
            status=ReportEmailDelivery.Status.SENT if sent else ReportEmailDelivery.Status.FAILED,
        )

    def soft_delete_for_user(self, user: User) -> int:
        return ReportEmailDelivery.objects.filter(user=user, is_deleted=False).update(
            is_deleted=True, deleted_at=timezone.now()
        )
