from django.conf import settings
from django.db import models

from apps.assessment.models import Attempt


class Report(models.Model):
    """A personality report for one completed Attempt -- initial or deep.

    One table with a `report_type` discriminator, not two (deep_report_spec_v1_2.md §7.1). The two types
    fill disjoint score fields:

      initial -> `dimension_scores` (report_spec_v1.3 §1)
      deep    -> `facet_scores` / `domain_scores` / `quality_metrics` / `active_patterns`

    All of them are computed by us and never touched by the AI. `report_data` / `system_data` /
    `memory_candidates` are the AI service's response verbatim (report_spec_v1.3 §4.1,
    deep_report_spec_v1_2.md §6) — stored as-is so future report_version changes don't break old rows.
    """

    class Status(models.TextChoices):
        # Both report types pass through this state: the row exists before its content does,
        # because generation runs on Celery for both (see ReportService._start_deep_generation
        # / _start_initial_generation).
        GENERATING = "generating", "Generating"
        # Deep report scored but not yet paid for (Assessment.report_requires_purchase): the
        # deterministic scores are stored, the paid AI generation has not started. No content
        # leaves the service in this state.
        AWAITING_PAYMENT = "awaiting_payment", "Awaiting payment"
        OK = "ok", "Ok"
        ERROR = "error", "Error"

    class ReportType(models.TextChoices):
        INITIAL = "initial", "Initial"
        DEEP = "deep", "Deep"

    attempt = models.OneToOneField(Attempt, on_delete=models.CASCADE, related_name="report")
    report_type = models.CharField(max_length=10, choices=ReportType.choices, default=ReportType.INITIAL)
    report_version = models.CharField(max_length=50)
    status = models.CharField(max_length=20, choices=Status.choices)
    dimension_scores = models.JSONField(default=list, blank=True)

    # --- deep only (deep_report_spec_v1_2.md §7) ---
    # 30 x {code, domain, raw, provisional, level}. `raw` and `provisional` are stored for the
    # future norming work (§7.3) and stripped before the response ever leaves the service.
    facet_scores = models.JSONField(default=list, blank=True)
    # 5 x {code, index, level} -- Domain Facet Index, the basis of the whole report (§2.3).
    domain_scores = models.JSONField(default=list, blank=True)
    # {core_domain_raw: {N: int, ...}, core_facet_gap: {N: float, ...}} -- the 30 core items'
    # cross-check (§7.4) and its distance from the facet index (§3.2, §7.5). Collected only;
    # no threshold is defined and it has no effect on the report until real data exists.
    quality_metrics = models.JSONField(default=dict, blank=True)
    # Backend-computed combination patterns (§3.3, §7.6). The AI interprets them, never detects
    # them -- otherwise two users with the same scores could get contradictory reports.
    active_patterns = models.JSONField(default=list, blank=True)

    report_data = models.JSONField(null=True, blank=True)
    system_data = models.JSONField(default=dict, blank=True)
    memory_candidates = models.JSONField(default=list, blank=True)
    # Deep only: set the moment a worker claims this row for generation (an atomic
    # UPDATE ... WHERE generation_started_at IS NULL), so Celery's at-least-once redelivery
    # can't have two workers both call the paid AI service for the same report.
    generation_started_at = models.DateTimeField(null=True, blank=True)
    memories_persisted_at = models.DateTimeField(null=True, blank=True)
    error_code = models.CharField(max_length=50, blank=True)
    error_message = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "reports"

    def __str__(self):
        return f"{self.report_type} report for attempt #{self.attempt_id} ({self.status})"


class Memory(models.Model):
    """A durable text memory derived from a report's memory_candidates (report_spec_v1.3 §4.5).

    Keyed by (user, memory_type, source): a later report from the SAME source overwrites the
    same row, but a different source starts its own lineage (deep_report_spec_v1_2.md §6.3). That last
    part matters -- the deep report must not erase the initial report's memories; both stay
    live and are injected into chat together, each labelled with where it came from.
    """

    class MemoryType(models.TextChoices):
        CORE_PATTERN = "core_pattern", "Core pattern"
        STRENGTH = "strength", "Strength"
        GROWTH_EDGE = "growth_edge", "Growth edge"
        GROWTH_FOCUS = "growth_focus", "Growth focus"

    class Confidence(models.TextChoices):
        LOW = "low", "Low"
        MEDIUM = "medium", "Medium"
        HIGH = "high", "High"

    class Sensitivity(models.TextChoices):
        LOW = "low", "Low"
        MEDIUM = "medium", "Medium"
        HIGH = "high", "High"

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="memories")
    memory_type = models.CharField(max_length=20, choices=MemoryType.choices)
    text_memory = models.TextField()
    source = models.CharField(max_length=50)
    confidence = models.CharField(max_length=10, choices=Confidence.choices)
    sensitivity_level = models.CharField(max_length=10, choices=Sensitivity.choices)
    created_at = models.DateTimeField(auto_now_add=True)
    # Bumped every time a newer report supersedes this row in place (same user/type/source).
    # Without it a re-generated memory is invisible in the table -- created_at stays at the
    # first-ever write and there is no new row.
    updated_at = models.DateTimeField(auto_now=True)
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "user_memories"
        constraints = [
            models.UniqueConstraint(
                fields=["user", "memory_type", "source"], name="unique_memory_per_user_type_source"
            ),
        ]

    def __str__(self):
        return f"{self.memory_type} memory for user #{self.user_id}"


class GenerationLog(models.Model):
    """One row per AI report-generation call, success or failure (report_spec_v1.4 §4.4).

    Operational/analytics data about the *call*, not the report -- kept out of the Report
    row on purpose. Written on both outcomes: a failed call that still reached the model
    still cost money, and undercounting that cost by only logging successes would hide the
    real spend. `cost` is computed from `model_used`/`input_tokens`/`output_tokens` against
    apps.ai.pricing's config-driven price table; it's `None` when `model_used` is `None`
    (every attempt failed) or when that model has no configured price.
    """

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True, related_name="generation_logs",
    )
    attempt = models.ForeignKey(Attempt, on_delete=models.CASCADE, related_name="generation_logs")
    # Which call within a multi-call generation this row is for (deep_report_spec_v1_2.md §5.1/§7.7): a
    # deep report is 8 separate paid calls, each logged on its own row. Empty for the initial
    # report, which is a single call and has nothing to disambiguate.
    call_key = models.CharField(max_length=30, blank=True)
    model_used = models.CharField(max_length=100, null=True, blank=True)
    attempts = models.PositiveIntegerField()
    input_tokens = models.PositiveIntegerField(default=0)
    # The slice of `input_tokens` served from the provider's prompt cache, priced at the
    # cached rate in `cost` (see apps.ai.pricing). 0 until report generation reports it.
    cached_input_tokens = models.PositiveIntegerField(default=0)
    output_tokens = models.PositiveIntegerField(default=0)
    latency_s = models.FloatField(default=0.0)
    cost = models.DecimalField(max_digits=12, decimal_places=6, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "report_generation_logs"

    def __str__(self):
        return f"GenerationLog for attempt #{self.attempt_id} ({self.model_used or 'failed'})"


class ReportEmailDelivery(models.Model):
    """One row per attempt to email a report (POST /api/report/attempts/<id>/email/).

    The address is whatever the requester typed into the "email me this report" card -- it isn't
    stored on User -- so this table is the only record of who a report was sent to. Written after
    the SMTP call on both outcomes (`sent` / `failed`); a request rejected earlier (not owned,
    not ready, throttled, render failure) never reaches the send and gets no row.
    """

    class Status(models.TextChoices):
        SENT = "sent", "Sent"
        FAILED = "failed", "Failed"

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="report_email_deliveries",
    )
    attempt = models.ForeignKey(Attempt, on_delete=models.CASCADE, related_name="report_email_deliveries")
    report_type = models.CharField(max_length=20, choices=Report.ReportType.choices)
    email = models.EmailField()
    status = models.CharField(max_length=10, choices=Status.choices)
    created_at = models.DateTimeField(auto_now_add=True)
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "report_email_deliveries"
        indexes = [
            models.Index(fields=["email"]),
            models.Index(fields=["user", "-created_at"]),
        ]

    def __str__(self):
        return f"ReportEmailDelivery for attempt #{self.attempt_id} ({self.status})"
