# Generated manually 2026-08-30

from django.db import migrations, models
from django.utils import timezone


def soft_delete_action_outcome_memories(apps, schema_editor):
    """`action_outcome` held an action step's reflection answer (chat_spec_v2 §1.2). v3 moves
    that onto the `action_steps` row itself (`ActionStep.reflection`), and chat now reads the
    last 3 steps as `action_context.recent` instead. The reflection text was copied onto each
    step row by `action_steps/0004_actionstep_reflection_obstacle_answered_at` (a dependency of
    this migration), so these rows are safe to retire -- same treatment `committed_action` got
    in 0008. `_build_user_memory` injects every non-deleted row into chat, so leaving them
    would keep feeding a type the flow no longer expects.
    """
    Memory = apps.get_model("report", "Memory")
    Memory.objects.filter(memory_type="action_outcome", is_deleted=False).update(
        is_deleted=True, deleted_at=timezone.now()
    )


class Migration(migrations.Migration):

    dependencies = [
        ("report", "0009_generationlog_cached_input_tokens"),
        ("action_steps", "0004_actionstep_reflection_obstacle_answered_at"),
    ]

    operations = [
        migrations.RunPython(soft_delete_action_outcome_memories, migrations.RunPython.noop),
        migrations.AlterField(
            model_name="memory",
            name="memory_type",
            field=models.CharField(
                choices=[
                    ("core_pattern", "Core pattern"),
                    ("strength", "Strength"),
                    ("growth_edge", "Growth edge"),
                    ("growth_focus", "Growth focus"),
                ],
                max_length=20,
            ),
        ),
    ]
