from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [("report", "0013_alter_report_status")]
    operations = [migrations.CreateModel(
        name="RejectedFinding",
        fields=[("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("key", models.CharField(max_length=64)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("report", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="rejected_findings", to="report.report"))],
        options={"constraints": [models.UniqueConstraint(fields=("report", "key"), name="unique_report_rejected_finding")]},
    )]
