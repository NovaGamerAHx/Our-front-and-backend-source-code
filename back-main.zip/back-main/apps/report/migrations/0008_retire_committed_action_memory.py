# Generated manually 2026-08-29

from django.db import migrations, models
from django.utils import timezone


def soft_delete_committed_action_memories(apps, schema_editor):
    """`committed_action` was the old chat "committed step" flow's memory type. That flow was
    removed in #105 and replaced by `action_outcome` (chat_spec_v2 §1.2). Legacy rows still
    sit in `user_memories`, and `_build_user_memory` injects every non-deleted row into chat
    -- the chat generation service's MemoryRow only accepts the current five types, so a
    single stale `committed_action` row makes every chat turn fail validation. They carry no
    meaning under the new model, so retire them.
    """
    Memory = apps.get_model("report", "Memory")
    Memory.objects.filter(memory_type="committed_action", is_deleted=False).update(
        is_deleted=True, deleted_at=timezone.now()
    )


class Migration(migrations.Migration):

    dependencies = [
        ('report', '0007_alter_memory_memory_type'),
    ]

    operations = [
        migrations.RunPython(soft_delete_committed_action_memories, migrations.RunPython.noop),
        migrations.AlterField(
            model_name='memory',
            name='memory_type',
            field=models.CharField(choices=[('core_pattern', 'Core pattern'), ('strength', 'Strength'), ('growth_edge', 'Growth edge'), ('growth_focus', 'Growth focus'), ('action_outcome', 'Action outcome')], max_length=20),
        ),
    ]
