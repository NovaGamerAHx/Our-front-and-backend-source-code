from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('report', '0012_report_email_delivery'),
    ]

    operations = [
        migrations.AlterField(
            model_name='report',
            name='status',
            field=models.CharField(choices=[('generating', 'Generating'), ('awaiting_payment', 'Awaiting payment'), ('ok', 'Ok'), ('error', 'Error')], max_length=20),
        ),
    ]
