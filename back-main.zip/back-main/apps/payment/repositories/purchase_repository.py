from django.utils import timezone

from apps.account.models import User
from apps.payment.models import Payment, Product, Purchase


class PurchaseRepository:
    def exists_for_user_sku(self, user: User, product_key: str) -> bool:
        return Purchase.objects.filter(user=user, product__sku=product_key, consumed_at__isnull=True).exists()

    def get_owned_skus_for_user(self, user: User) -> set[str]:
        return set(
            Purchase.objects.filter(user=user, consumed_at__isnull=True).values_list("product__sku", flat=True)
        )

    def grant_or_reactivate(self, *, user: User, product: Product, payment: Payment) -> Purchase:
        """Grants a Purchase for (user, product), or reactivates it if one already exists (e.g. a
        retake payment after the previous Purchase was consumed) -- always the same row, so
        unique_purchase_per_user_product never needs a second one."""
        purchase, _ = Purchase.objects.update_or_create(
            user=user, product=product, defaults={"payment": payment, "consumed_at": None},
        )
        return purchase

    def consume(self, *, user: User, product: Product) -> None:
        """Idempotent: no-ops if already consumed or no Purchase exists."""
        Purchase.objects.filter(user=user, product=product, consumed_at__isnull=True).update(
            consumed_at=timezone.now()
        )
