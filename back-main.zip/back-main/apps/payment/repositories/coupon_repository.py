from django.db.models import F

from apps.payment.models import Coupon


class CouponRepository:
    def get_locked_for_code(self, code: str) -> Coupon | None:
        """select_for_update variant, for use inside a transaction when redeeming a coupon --
        serializes concurrent redemptions of the same code so max_redemptions can't be
        oversold by a race."""
        return Coupon.objects.select_for_update().filter(code__iexact=code).first()

    def increment_redemptions(self, coupon: Coupon) -> None:
        Coupon.objects.filter(pk=coupon.pk).update(redemptions_count=F("redemptions_count") + 1)
