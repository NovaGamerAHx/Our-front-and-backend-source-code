from apps.assessment.models import Assessment
from apps.payment.models import Product


class ProductRepository:
    def get_active_by_sku(self, sku: str) -> Product | None:
        return Product.objects.filter(sku=sku, is_active=True).first()

    def get_active_for_assessment(self, assessment: Assessment) -> Product | None:
        return Product.objects.filter(assessment=assessment, is_active=True).first()

    def get_all_active(self) -> list[Product]:
        return list(Product.objects.filter(is_active=True).select_related("assessment"))
