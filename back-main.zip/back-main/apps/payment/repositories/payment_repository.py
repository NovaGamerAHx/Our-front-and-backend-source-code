from django.utils import timezone

from apps.account.models import User
from apps.assessment.models import Attempt
from apps.payment.models import Coupon, Payment, Product


class PaymentRepository:
    def create(
        self, *, user: User, product: Product, amount: int, coupon: Coupon | None = None,
        attempt: Attempt | None = None,
    ) -> Payment:
        return Payment.objects.create(user=user, product=product, amount=amount, coupon=coupon, attempt=attempt)

    def get_by_authority(self, authority: str) -> Payment | None:
        return Payment.objects.filter(authority=authority).first()

    def set_authority(self, payment: Payment, *, authority: str, gateway_response: dict) -> Payment:
        payment.authority = authority
        payment.gateway_response = {**payment.gateway_response, "request": gateway_response}
        payment.save(update_fields=["authority", "gateway_response"])
        return payment

    def mark_paid(self, payment: Payment, *, ref_id: str, gateway_response: dict) -> Payment:
        payment.status = Payment.Status.PAID
        payment.ref_id = str(ref_id)
        payment.paid_at = timezone.now()
        payment.gateway_response = {**payment.gateway_response, "verify": gateway_response}
        payment.save(update_fields=["status", "ref_id", "paid_at", "gateway_response"])
        return payment

    def mark_paid_by_coupon(self, payment: Payment, *, coupon_code: str) -> Payment:
        """A 100%-off coupon reduces the amount to zero -- there's nothing for Zarinpal to
        charge, so the payment is settled directly instead of going through request/verify."""
        payment.status = Payment.Status.PAID
        payment.paid_at = timezone.now()
        payment.gateway_response = {**payment.gateway_response, "coupon": coupon_code}
        payment.save(update_fields=["status", "paid_at", "gateway_response"])
        return payment

    def mark_failed(self, payment: Payment, *, status: str, gateway_response: dict | None = None) -> Payment:
        payment.status = status
        if gateway_response is not None:
            payment.gateway_response = {**payment.gateway_response, "verify": gateway_response}
        payment.save(update_fields=["status", "gateway_response"])
        return payment
