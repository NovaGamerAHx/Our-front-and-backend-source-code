from unittest.mock import MagicMock, patch

from django.test import TestCase

from apps.account.models import User
from apps.assessment.models import Assessment
from apps.assessment.services.exceptions import AssessmentNotFoundException
from apps.payment.models import Payment, Product, Purchase
from apps.payment.repositories.purchase_repository import PurchaseRepository
from apps.payment.services.exceptions import (
    AssessmentAlreadyPurchasedException,
    PaymentAttemptInvalidException,
    PaymentCancelledException,
    PaymentNotFoundException,
    PaymentVerificationFailedException,
    ProductNotFoundException,
)
from apps.payment.services.entitlement_service import EntitlementService
from apps.payment.services.payment_service import PaymentService
from apps.payment.services.zarinpal_client import ZarinpalClient
from apps.report.models import Report


class ZarinpalClientRequestPaymentTests(TestCase):
    def setUp(self):
        self.client = ZarinpalClient()

    @patch("apps.payment.services.zarinpal_client.requests.post")
    def test_mobile_is_sent_nested_under_metadata(self, mock_post):
        # Zarinpal only associates a buyer's remembered cards with a mobile number sent under
        # metadata.mobile -- a top-level `mobile` field is silently ignored for that lookup.
        mock_post.return_value.json.return_value = {"data": {"code": 100, "authority": "A00000AUTH"}}

        self.client.request_payment(
            amount=1000,
            description="desc",
            callback_url="https://example.com/callback",
            mobile="09121234567",
        )

        payload = mock_post.call_args.kwargs["json"]
        self.assertEqual(payload["metadata"], {"mobile": "09121234567"})
        self.assertNotIn("mobile", payload)

    @patch("apps.payment.services.zarinpal_client.requests.post")
    def test_no_metadata_when_mobile_omitted(self, mock_post):
        mock_post.return_value.json.return_value = {"data": {"code": 100, "authority": "A00000AUTH"}}

        self.client.request_payment(
            amount=1000,
            description="desc",
            callback_url="https://example.com/callback",
        )

        payload = mock_post.call_args.kwargs["json"]
        self.assertNotIn("metadata", payload)


class PaymentServiceInitiatePaymentTests(TestCase):
    def setUp(self):
        self.payment_repository = MagicMock()
        self.product_repository = MagicMock()
        self.purchase_repository = MagicMock()
        self.assessment_repository = MagicMock()
        self.zarinpal_client = MagicMock()
        self.entitlement_service = MagicMock()
        self.entitlement_service.has_access_to_assessment.return_value = False
        self.service = PaymentService(
            payment_repository=self.payment_repository,
            product_repository=self.product_repository,
            purchase_repository=self.purchase_repository,
            assessment_repository=self.assessment_repository,
            zarinpal_client=self.zarinpal_client,
            entitlement_service=self.entitlement_service,
        )
        self.user = MagicMock(phone_number='09123456789')

    def test_raises_when_no_active_assessment_for_slug(self):
        self.assessment_repository.get_active_by_slug.return_value = None

        with self.assertRaises(AssessmentNotFoundException):
            self.service.initiate_payment(user=self.user, assessment_slug='unknown-slug')

        self.product_repository.get_active_for_assessment.assert_not_called()
        self.payment_repository.create.assert_not_called()

    def test_raises_when_no_active_product_for_assessment(self):
        assessment = MagicMock(report_requires_purchase=False)
        self.assessment_repository.get_active_by_slug.return_value = assessment
        self.product_repository.get_active_for_assessment.return_value = None

        with self.assertRaises(ProductNotFoundException):
            self.service.initiate_payment(user=self.user, assessment_slug='deep-test-v1')

        self.payment_repository.create.assert_not_called()

    def test_returns_payment_url_on_success(self):
        assessment = MagicMock(report_requires_purchase=False)
        product = MagicMock(price=199_000, title='Deep Test')
        payment = MagicMock(attempt_id=None)
        self.assessment_repository.get_active_by_slug.return_value = assessment
        self.product_repository.get_active_for_assessment.return_value = product
        self.payment_repository.create.return_value = payment
        self.zarinpal_client.request_payment.return_value = {"authority": "A00000AUTH", "code": 100}
        self.zarinpal_client.start_pay_url.return_value = "https://sandbox.zarinpal.com/pg/StartPay/A00000AUTH"

        result = self.service.initiate_payment(user=self.user, assessment_slug='deep-test-v1')

        self.assertEqual(
            result,
            {"payment_url": "https://sandbox.zarinpal.com/pg/StartPay/A00000AUTH", "unlocked": False, "attempt_id": None},
        )
        self.payment_repository.create.assert_called_once_with(
            user=self.user, product=product, amount=199_000, attempt=None
        )
        self.payment_repository.set_authority.assert_called_once_with(
            payment, authority="A00000AUTH", gateway_response={"authority": "A00000AUTH", "code": 100}
        )

    def test_raises_when_user_already_has_access(self):
        assessment = MagicMock(report_requires_purchase=False)
        self.assessment_repository.get_active_by_slug.return_value = assessment
        self.entitlement_service.has_access_to_assessment.return_value = True

        with self.assertRaises(AssessmentAlreadyPurchasedException):
            self.service.initiate_payment(user=self.user, assessment_slug='deep-test-v1')

        self.entitlement_service.has_access_to_assessment.assert_called_once_with(user=self.user, assessment=assessment)
        self.product_repository.get_active_for_assessment.assert_not_called()
        self.payment_repository.create.assert_not_called()


class PaymentServiceVerifyPaymentTests(TestCase):
    def setUp(self):
        self.report_service = MagicMock()
        self.payment_repository = MagicMock()
        self.product_repository = MagicMock()
        self.purchase_repository = MagicMock()
        self.assessment_repository = MagicMock()
        self.zarinpal_client = MagicMock()
        self.service = PaymentService(
            payment_repository=self.payment_repository,
            product_repository=self.product_repository,
            purchase_repository=self.purchase_repository,
            assessment_repository=self.assessment_repository,
            zarinpal_client=self.zarinpal_client,
            entitlement_service=MagicMock(),
            attempt_repository=MagicMock(),
            report_repository=MagicMock(),
            report_service=self.report_service,
        )

    def test_raises_when_no_payment_for_authority(self):
        self.payment_repository.get_by_authority.return_value = None

        with self.assertRaises(PaymentNotFoundException):
            self.service.verify_payment(authority='unknown', status='OK')

        self.zarinpal_client.verify_payment.assert_not_called()

    def test_returns_early_when_already_paid(self):
        payment = MagicMock(status=Payment.Status.PAID)
        self.payment_repository.get_by_authority.return_value = payment

        result = self.service.verify_payment(authority='A1', status='OK')

        self.assertIs(result, payment)
        self.zarinpal_client.verify_payment.assert_not_called()
        self.purchase_repository.grant_or_reactivate.assert_not_called()

    def test_raises_and_marks_cancelled_when_status_not_ok(self):
        payment = MagicMock(status=Payment.Status.PENDING)
        self.payment_repository.get_by_authority.return_value = payment

        with self.assertRaises(PaymentCancelledException):
            self.service.verify_payment(authority='A1', status='NOK')

        self.payment_repository.mark_failed.assert_called_once_with(payment, status=Payment.Status.CANCELLED)
        self.zarinpal_client.verify_payment.assert_not_called()

    def test_raises_and_marks_failed_when_verify_code_is_neither_100_nor_101(self):
        payment = MagicMock(status=Payment.Status.PENDING, amount=199_000)
        self.payment_repository.get_by_authority.return_value = payment
        self.zarinpal_client.verify_payment.return_value = {"code": 50}

        with self.assertRaises(PaymentVerificationFailedException):
            self.service.verify_payment(authority='A1', status='OK')

        self.payment_repository.mark_failed.assert_called_once_with(
            payment, status=Payment.Status.FAILED, gateway_response={"code": 50}
        )
        self.purchase_repository.grant_or_reactivate.assert_not_called()

    def test_marks_paid_and_creates_purchase_on_first_verification(self):
        payment = MagicMock(
            status=Payment.Status.PENDING, amount=199_000, user=MagicMock(), product=MagicMock(), attempt_id=None,
        )
        self.payment_repository.get_by_authority.return_value = payment
        self.zarinpal_client.verify_payment.return_value = {"code": 100, "ref_id": 987654}
        self.payment_repository.mark_paid.return_value = payment

        result = self.service.verify_payment(authority='A1', status='OK')

        self.assertIs(result, payment)
        self.payment_repository.mark_paid.assert_called_once_with(
            payment, ref_id=987654, gateway_response={"code": 100, "ref_id": 987654}
        )
        self.purchase_repository.grant_or_reactivate.assert_called_once_with(
            user=payment.user, product=payment.product, payment=payment
        )

    def test_treats_already_verified_code_as_success(self):
        payment = MagicMock(
            status=Payment.Status.PENDING, amount=199_000, user=MagicMock(), product=MagicMock(), attempt_id=None,
        )
        self.payment_repository.get_by_authority.return_value = payment
        self.zarinpal_client.verify_payment.return_value = {"code": 101, "ref_id": 987654}
        self.payment_repository.mark_paid.return_value = payment

        self.service.verify_payment(authority='A1', status='OK')

        self.payment_repository.mark_failed.assert_not_called()
        self.purchase_repository.grant_or_reactivate.assert_called_once()

    def test_attempt_bound_payment_unlocks_the_report_instead_of_granting_a_purchase(self):
        payment = MagicMock(
            status=Payment.Status.PENDING, amount=199_000, user=MagicMock(), product=MagicMock(), attempt_id=42,
        )
        self.payment_repository.get_by_authority.return_value = payment
        self.zarinpal_client.verify_payment.return_value = {"code": 100, "ref_id": 987654}
        self.payment_repository.mark_paid.return_value = payment

        self.service.verify_payment(authority='A1', status='OK')

        self.report_service.unlock_after_payment.assert_called_once_with(42)
        self.purchase_repository.grant_or_reactivate.assert_not_called()


class PaymentServicePayAfterTestTests(TestCase):
    def setUp(self):
        self.payment_repository = MagicMock()
        self.product_repository = MagicMock()
        self.assessment_repository = MagicMock()
        self.attempt_repository = MagicMock()
        self.report_repository = MagicMock()
        self.report_service = MagicMock()
        self.zarinpal_client = MagicMock()
        self.service = PaymentService(
            payment_repository=self.payment_repository,
            product_repository=self.product_repository,
            purchase_repository=MagicMock(),
            coupon_repository=MagicMock(),
            assessment_repository=self.assessment_repository,
            zarinpal_client=self.zarinpal_client,
            entitlement_service=MagicMock(),
            attempt_repository=self.attempt_repository,
            report_repository=self.report_repository,
            report_service=self.report_service,
        )
        self.user = MagicMock(id=7, phone_number='09123456789')
        self.assessment = MagicMock(id=3, slug='deep-150-v1', report_requires_purchase=True)
        self.assessment_repository.get_active_by_slug.return_value = self.assessment

    def _attempt(self, **overrides):
        values = {"id": 42, "user_id": 7, "assessment_id": 3}
        values.update(overrides)
        return MagicMock(**values)

    def test_requires_an_attempt_id(self):
        with self.assertRaises(PaymentAttemptInvalidException):
            self.service.initiate_payment(user=self.user, assessment_slug='deep-150-v1')

        self.payment_repository.create.assert_not_called()

    def test_rejects_an_attempt_owned_by_someone_else(self):
        self.attempt_repository.get_by_id.return_value = self._attempt(user_id=99)

        with self.assertRaises(PaymentAttemptInvalidException):
            self.service.initiate_payment(user=self.user, assessment_slug='deep-150-v1', attempt_id=42)

        self.payment_repository.create.assert_not_called()

    def test_rejects_an_attempt_of_another_assessment(self):
        self.attempt_repository.get_by_id.return_value = self._attempt(assessment_id=4)

        with self.assertRaises(PaymentAttemptInvalidException):
            self.service.initiate_payment(user=self.user, assessment_slug='deep-150-v1', attempt_id=42)

    def test_rejects_an_attempt_without_a_report(self):
        self.attempt_repository.get_by_id.return_value = self._attempt()
        self.report_repository.get_by_attempt_id.return_value = None

        with self.assertRaises(PaymentAttemptInvalidException):
            self.service.initiate_payment(user=self.user, assessment_slug='deep-150-v1', attempt_id=42)

    def test_rejects_paying_for_an_already_unlocked_report(self):
        self.attempt_repository.get_by_id.return_value = self._attempt()
        self.report_repository.get_by_attempt_id.return_value = MagicMock(status=Report.Status.GENERATING)

        with self.assertRaises(AssessmentAlreadyPurchasedException):
            self.service.initiate_payment(user=self.user, assessment_slug='deep-150-v1', attempt_id=42)

        self.payment_repository.create.assert_not_called()

    def test_binds_the_payment_to_the_attempt(self):
        attempt = self._attempt()
        self.attempt_repository.get_by_id.return_value = attempt
        self.report_repository.get_by_attempt_id.return_value = MagicMock(status=Report.Status.AWAITING_PAYMENT)
        product = MagicMock(price=199_000, title='Deep Test')
        self.product_repository.get_active_for_assessment.return_value = product
        payment = MagicMock(attempt_id=42)
        self.payment_repository.create.return_value = payment
        self.zarinpal_client.request_payment.return_value = {"authority": "A1", "code": 100}
        self.zarinpal_client.start_pay_url.return_value = "https://pay/A1"

        result = self.service.initiate_payment(user=self.user, assessment_slug='deep-150-v1', attempt_id=42)

        self.assertEqual(result, {"payment_url": "https://pay/A1", "unlocked": False, "attempt_id": 42})
        self.payment_repository.create.assert_called_once_with(
            user=self.user, product=product, amount=199_000, attempt=attempt
        )

    def test_attempt_id_lookup_by_authority(self):
        self.payment_repository.get_by_authority.return_value = MagicMock(attempt_id=42)
        self.assertEqual(self.service.get_attempt_id_for_authority('A1'), 42)

        self.payment_repository.get_by_authority.return_value = None
        self.assertIsNone(self.service.get_attempt_id_for_authority('unknown'))


class EntitlementServiceHasAccessTests(TestCase):
    def setUp(self):
        self.product_repository = MagicMock()
        self.purchase_repository = MagicMock()
        self.service = EntitlementService(
            product_repository=self.product_repository, purchase_repository=self.purchase_repository,
        )

    def test_anonymous_user_never_has_access(self):
        result = self.service.has_access(user=None, product_key='deep-test-v1')

        self.assertFalse(result)
        self.purchase_repository.exists_for_user_sku.assert_not_called()

    def test_defers_to_purchase_existence_for_the_sku(self):
        user = MagicMock(id=1)
        self.purchase_repository.exists_for_user_sku.return_value = True

        result = self.service.has_access(user=user, product_key='deep-test-v1')

        self.assertTrue(result)
        self.purchase_repository.exists_for_user_sku.assert_called_once_with(user, 'deep-test-v1')

    def test_no_purchase_for_the_sku_means_no_access(self):
        user = MagicMock(id=1)
        self.purchase_repository.exists_for_user_sku.return_value = False

        self.assertFalse(self.service.has_access(user=user, product_key='deep-test-v1'))


class EntitlementServiceHasAccessToAssessmentTests(TestCase):
    def setUp(self):
        self.product_repository = MagicMock()
        self.purchase_repository = MagicMock()
        self.service = EntitlementService(
            product_repository=self.product_repository, purchase_repository=self.purchase_repository,
        )
        self.assessment = MagicMock(slug='deep-test-v1')

    def test_anonymous_user_never_has_access(self):
        result = self.service.has_access_to_assessment(user=None, assessment=self.assessment)

        self.assertFalse(result)
        self.product_repository.get_active_for_assessment.assert_not_called()

    def test_no_active_product_means_no_access(self):
        user = MagicMock(id=1)
        self.product_repository.get_active_for_assessment.return_value = None

        result = self.service.has_access_to_assessment(user=user, assessment=self.assessment)

        self.assertFalse(result)
        self.purchase_repository.exists_for_user_sku.assert_not_called()

    def test_resolves_product_then_checks_purchase_for_its_sku(self):
        user = MagicMock(id=1)
        product = MagicMock(sku='deep-test-v1')
        self.product_repository.get_active_for_assessment.return_value = product
        self.purchase_repository.exists_for_user_sku.return_value = True

        result = self.service.has_access_to_assessment(user=user, assessment=self.assessment)

        self.assertTrue(result)
        self.purchase_repository.exists_for_user_sku.assert_called_once_with(user, 'deep-test-v1')


class EntitlementServiceListEntitlementsTests(TestCase):
    def setUp(self):
        self.product_repository = MagicMock()
        self.purchase_repository = MagicMock()
        self.service = EntitlementService(
            product_repository=self.product_repository, purchase_repository=self.purchase_repository,
        )
        self.user = MagicMock(id=1)

    def test_shapes_active_products_with_owned_status(self):
        owned = MagicMock(sku='deep-test-v1', title='Deep Test', price=199000, assessment=MagicMock(slug='deep-test-v1'))
        unowned = MagicMock(sku='another-sku', title='Another', price=49000, assessment=MagicMock(slug='another-slug'))
        self.product_repository.get_all_active.return_value = [owned, unowned]
        self.purchase_repository.get_owned_skus_for_user.return_value = {'deep-test-v1'}

        result = self.service.list_entitlements(user=self.user)

        self.assertEqual(result, [
            {
                "product_key": "deep-test-v1", "title": "Deep Test",
                "assessment_slug": "deep-test-v1", "has_access": True, "price": 199000,
            },
            {
                "product_key": "another-sku", "title": "Another",
                "assessment_slug": "another-slug", "has_access": False, "price": 49000,
            },
        ])


class EntitlementServiceListProductPricesTests(TestCase):
    def test_shapes_active_products_without_user_specific_fields(self):
        product_repository = MagicMock()
        product_repository.get_all_active.return_value = [
            MagicMock(sku='deep-test-v1', title='Deep Test', price=199000, assessment=MagicMock(slug='deep-150-v1')),
        ]
        service = EntitlementService(product_repository=product_repository, purchase_repository=MagicMock())

        result = service.list_product_prices()

        self.assertEqual(result, [
            {"product_key": "deep-test-v1", "title": "Deep Test", "assessment_slug": "deep-150-v1", "price": 199000},
        ])


class ProductPriceListEndpointTests(TestCase):
    def test_is_reachable_without_authentication(self):
        response = self.client.get("/api/payment/products/")

        self.assertEqual(response.status_code, 200)
        self.assertIsInstance(response.json()["data"], list)


class EntitlementServiceConsumeForAssessmentTests(TestCase):
    def setUp(self):
        self.product_repository = MagicMock()
        self.purchase_repository = MagicMock()
        self.service = EntitlementService(
            product_repository=self.product_repository, purchase_repository=self.purchase_repository,
        )
        self.assessment = MagicMock(slug='deep-test-v1')

    def test_does_nothing_for_anonymous_user(self):
        self.service.consume_for_assessment(user=None, assessment=self.assessment)

        self.product_repository.get_active_for_assessment.assert_not_called()
        self.purchase_repository.consume.assert_not_called()

    def test_does_nothing_when_no_active_product(self):
        user = MagicMock(id=1)
        self.product_repository.get_active_for_assessment.return_value = None

        self.service.consume_for_assessment(user=user, assessment=self.assessment)

        self.purchase_repository.consume.assert_not_called()

    def test_consumes_purchase_for_the_resolved_product(self):
        user = MagicMock(id=1)
        product = MagicMock(sku='deep-test-v1')
        self.product_repository.get_active_for_assessment.return_value = product

        self.service.consume_for_assessment(user=user, assessment=self.assessment)

        self.purchase_repository.consume.assert_called_once_with(user=user, product=product)


class PurchaseRepositoryTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(phone_number='09123456789', password='pass1234')
        self.assessment = Assessment.objects.create(
            slug='deep-150-v1', title='Deep Test', kind=Assessment.Kind.SUPPLEMENTARY, requires_purchase=True,
        )
        self.product = Product.objects.create(
            sku='deep-150-v1', title='Deep Test', price=199_000, assessment=self.assessment,
        )
        self.repository = PurchaseRepository()

    def _make_paid_payment(self):
        return Payment.objects.create(
            user=self.user, product=self.product, amount=self.product.price, status=Payment.Status.PAID,
        )

    def test_grant_or_reactivate_creates_a_single_row_and_reactivates_on_repurchase(self):
        payment1 = self._make_paid_payment()
        payment2 = self._make_paid_payment()

        self.repository.grant_or_reactivate(user=self.user, product=self.product, payment=payment1)
        purchase = self.repository.grant_or_reactivate(user=self.user, product=self.product, payment=payment2)

        self.assertEqual(Purchase.objects.filter(user=self.user, product=self.product).count(), 1)
        self.assertEqual(purchase.payment_id, payment2.id)
        self.assertIsNone(purchase.consumed_at)

    def test_consume_marks_purchase_consumed_and_is_idempotent(self):
        payment = self._make_paid_payment()
        self.repository.grant_or_reactivate(user=self.user, product=self.product, payment=payment)

        self.repository.consume(user=self.user, product=self.product)
        purchase = Purchase.objects.get(user=self.user, product=self.product)
        self.assertIsNotNone(purchase.consumed_at)
        first_consumed_at = purchase.consumed_at

        self.repository.consume(user=self.user, product=self.product)
        purchase.refresh_from_db()
        self.assertEqual(purchase.consumed_at, first_consumed_at)

    def test_exists_for_user_sku_is_false_once_consumed(self):
        payment = self._make_paid_payment()
        self.repository.grant_or_reactivate(user=self.user, product=self.product, payment=payment)
        self.assertTrue(self.repository.exists_for_user_sku(self.user, self.product.sku))

        self.repository.consume(user=self.user, product=self.product)

        self.assertFalse(self.repository.exists_for_user_sku(self.user, self.product.sku))
        self.assertNotIn(self.product.sku, self.repository.get_owned_skus_for_user(self.user))

    def test_grant_or_reactivate_reopens_a_consumed_purchase(self):
        payment1 = self._make_paid_payment()
        self.repository.grant_or_reactivate(user=self.user, product=self.product, payment=payment1)
        self.repository.consume(user=self.user, product=self.product)

        payment2 = self._make_paid_payment()
        purchase = self.repository.grant_or_reactivate(user=self.user, product=self.product, payment=payment2)

        self.assertEqual(Purchase.objects.filter(user=self.user, product=self.product).count(), 1)
        self.assertIsNone(purchase.consumed_at)
        self.assertEqual(purchase.payment_id, payment2.id)
        self.assertTrue(self.repository.exists_for_user_sku(self.user, self.product.sku))
