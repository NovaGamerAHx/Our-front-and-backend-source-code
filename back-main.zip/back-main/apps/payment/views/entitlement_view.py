from drf_spectacular.utils import extend_schema
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.views import APIView

from apps.payment.services.entitlement_service import EntitlementService
from faraman_back.utils.responses import ApiResponse


class EntitlementListAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.entitlement_service = EntitlementService()

    @extend_schema(
        description="Every active product plus whether the authenticated user has access to it "
                    "(EntitlementService.has_access), for a UI entitlements/paywall panel.",
        tags=["Payment"],
    )
    def get(self, request):
        data = self.entitlement_service.list_entitlements(user=request.user)

        return ApiResponse.success(data=data)


class ProductPriceListAPIView(APIView):
    permission_classes = [AllowAny]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.entitlement_service = EntitlementService()

    @extend_schema(
        description="Public: every active product's key, title, assessment slug and price (Toman). "
                    "Nothing user-specific -- lets a logged-out visitor see the paywall's real price.",
        tags=["Payment"],
    )
    def get(self, request):
        data = self.entitlement_service.list_product_prices()

        return ApiResponse.success(data=data)
