from urllib.parse import urlencode

from django.conf import settings
from django.http import HttpResponseRedirect
from drf_spectacular.utils import extend_schema
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.views import APIView

from apps.assessment.services.exceptions import AssessmentNotFoundException
from apps.payment.serializers.payment_serializer import InitiatePaymentSerializer
from apps.payment.services.exceptions import (
    AssessmentAlreadyPurchasedException,
    InvalidCouponException,
    PaymentAttemptInvalidException,
    PaymentCancelledException,
    PaymentGatewayException,
    PaymentNotFoundException,
    PaymentVerificationFailedException,
    ProductNotFoundException,
)
from apps.payment.services.payment_service import PaymentService
from faraman_back.utils.responses import ApiResponse
from faraman_back.utils.schema import error_responses


class InitiatePaymentAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.payment_service = PaymentService()

    @extend_schema(
        description="Starts a Zarinpal payment to unlock a purchasable assessment, optionally "
                    "discounted by a coupon_code. Returns a payment_url the client must redirect "
                    "the browser to (Zarinpal's own hosted pay page can't be embedded) -- unless "
                    "a 100%-off coupon fully covers the price, in which case payment_url is null, "
                    "unlocked is true, and access has already been granted with no gateway hop.",
        tags=["Payment"],
        request=InitiatePaymentSerializer,
        responses=error_responses(
            AssessmentNotFoundException,
            ProductNotFoundException,
            PaymentGatewayException,
            AssessmentAlreadyPurchasedException,
            InvalidCouponException,
            PaymentAttemptInvalidException,
        ),
    )
    def post(self, request):
        ser = InitiatePaymentSerializer(data=request.data)
        if not ser.is_valid():
            return ApiResponse.validation_error(data=ser.errors)

        data = self.payment_service.initiate_payment(
            user=request.user,
            assessment_slug=ser.validated_data["assessment_slug"],
            coupon_code=ser.validated_data.get("coupon_code") or None,
            attempt_id=ser.validated_data.get("attempt_id"),
        )

        return ApiResponse.success(data=data)


class PaymentCallbackAPIView(APIView):
    """Verifies a Zarinpal payment by authority/status. This is Zarinpal's callback_url itself
    now (see PaymentService.initiate_payment) -- the buyer's own browser lands here directly,
    not a JSON API client, so the response has to be a browser redirect to the frontend's
    /payment/result page, not an ApiResponse envelope. That's why this view catches its
    service's exceptions itself instead of letting them reach app_exception_handler (hard rule
    3's one deliberate exception in this codebase): the global handler would format JSON, which
    is useless to a browser mid-redirect. Previously this endpoint returned JSON for the
    frontend's own /api/payment/callback route to relay server-to-server and turn into this same
    redirect -- collapsed into one hop now that the backend has a real domain (api.faraman.ai)
    to be Zarinpal's callback target directly, removing the frontend process as a dependency of
    the one call that actually has to succeed (see CLAUDE.md payment-flow discussion)."""

    permission_classes = [AllowAny]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.payment_service = PaymentService()

    @extend_schema(
        description="Verifies a Zarinpal payment by authority/status. This is Zarinpal's own "
                    "callback_url -- the buyer's browser is redirected here directly, and the "
                    "response is itself a redirect to the frontend's /payment/result page.",
        tags=["Payment"],
        responses=error_responses(
            PaymentNotFoundException, PaymentCancelledException, PaymentVerificationFailedException, PaymentGatewayException
        ),
    )
    def get(self, request):
        authority = request.GET.get("Authority", "")
        status_param = request.GET.get("Status", "")

        # Pay-after-test: every outcome carries the attempt back so the frontend can return to
        # that report's paywall (cancelled/failed) or open the report itself (success).
        attempt_id = self.payment_service.get_attempt_id_for_authority(authority)
        extra = {"attempt_id": str(attempt_id)} if attempt_id is not None else {}

        try:
            payment = self.payment_service.verify_payment(authority=authority, status=status_param)
        except PaymentCancelledException:
            return HttpResponseRedirect(self._result_url("cancelled", **extra))
        except (PaymentNotFoundException, PaymentVerificationFailedException, PaymentGatewayException):
            return HttpResponseRedirect(self._result_url("failed", **extra))

        return HttpResponseRedirect(
            self._result_url("success", assessment=payment.product.assessment.slug, **extra)
        )

    @staticmethod
    def _result_url(result_status: str, **extra: str) -> str:
        params = {"status": result_status, **extra}
        return f"{settings.FRONTEND_URL}/payment/result?{urlencode(params)}"
