from django.conf import settings
from django.db import transaction

from apps.account.models import User
from apps.assessment.repositories.assessment_repository import AssessmentRepository
from apps.assessment.repositories.attempt_repository import AttemptRepository
from apps.assessment.services.exceptions import AssessmentNotFoundException
from apps.payment.models import Payment, Product
from apps.payment.repositories.coupon_repository import CouponRepository
from apps.payment.repositories.payment_repository import PaymentRepository
from apps.payment.repositories.product_repository import ProductRepository
from apps.payment.repositories.purchase_repository import PurchaseRepository
from apps.payment.services.entitlement_service import EntitlementService
from apps.payment.services.exceptions import (
    AssessmentAlreadyPurchasedException,
    InvalidCouponException,
    PaymentAttemptInvalidException,
    PaymentCancelledException,
    PaymentNotFoundException,
    PaymentVerificationFailedException,
    ProductNotFoundException,
)
from apps.payment.services.zarinpal_client import ZarinpalClient
from apps.report.models import Report
from apps.report.repositories.report_repository import ReportRepository
from apps.report.services.report_service import ReportService


class PaymentService:
    def __init__(
        self,
        payment_repository=None,
        product_repository=None,
        purchase_repository=None,
        coupon_repository=None,
        assessment_repository=None,
        zarinpal_client=None,
        entitlement_service=None,
        attempt_repository=None,
        report_repository=None,
        report_service=None,
    ):
        self.payment_repository = payment_repository or PaymentRepository()
        self.product_repository = product_repository or ProductRepository()
        self.purchase_repository = purchase_repository or PurchaseRepository()
        self.coupon_repository = coupon_repository or CouponRepository()
        self.assessment_repository = assessment_repository or AssessmentRepository()
        self.zarinpal_client = zarinpal_client or ZarinpalClient()
        self.entitlement_service = entitlement_service or EntitlementService()
        self.attempt_repository = attempt_repository or AttemptRepository()
        self.report_repository = report_repository or ReportRepository()
        self.report_service = report_service or ReportService()

    def _get_payable_attempt(self, *, user: User, assessment, attempt_id: int | None):
        """Pay-after-test: the payment unlocks one specific completed attempt's report."""
        if attempt_id is None:
            raise PaymentAttemptInvalidException(f"attempt_id is required to pay for {assessment.slug}")

        attempt = self.attempt_repository.get_by_id(attempt_id)
        if attempt is None or attempt.user_id != user.id or attempt.assessment_id != assessment.id:
            raise PaymentAttemptInvalidException(f"Attempt {attempt_id} is not payable by user {user.id}")

        report = self.report_repository.get_by_attempt_id(attempt.id)
        if report is None:
            raise PaymentAttemptInvalidException(f"Attempt {attempt_id} has no report awaiting payment")
        if report.status != Report.Status.AWAITING_PAYMENT:
            raise AssessmentAlreadyPurchasedException(f"Attempt {attempt_id} is already unlocked")

        return attempt

    def _fulfill(self, payment: Payment) -> None:
        """A settled payment either unlocks the attempt it was bound to (pay-after-test), or grants
        the user's Purchase entitlement (legacy pay-before-test, no attempt on the payment)."""
        if payment.attempt_id is not None:
            self.report_service.unlock_after_payment(payment.attempt_id)
        else:
            self.purchase_repository.grant_or_reactivate(user=payment.user, product=payment.product, payment=payment)

    def get_attempt_id_for_authority(self, authority: str) -> int | None:
        payment = self.payment_repository.get_by_authority(authority)
        return payment.attempt_id if payment is not None else None

    def initiate_payment(
        self, *, user: User, assessment_slug: str, coupon_code: str | None = None, attempt_id: int | None = None,
    ) -> dict:
        assessment = self.assessment_repository.get_active_by_slug(assessment_slug)
        if assessment is None:
            raise AssessmentNotFoundException(f"No active assessment found for slug {assessment_slug}")

        attempt = None
        if assessment.report_requires_purchase:
            attempt = self._get_payable_attempt(user=user, assessment=assessment, attempt_id=attempt_id)
        elif self.entitlement_service.has_access_to_assessment(user=user, assessment=assessment):
            raise AssessmentAlreadyPurchasedException(f"User {user.id} already has access to assessment {assessment_slug}")

        product = self.product_repository.get_active_for_assessment(assessment)
        if product is None:
            raise ProductNotFoundException(f"No active product found for assessment {assessment_slug}")

        if coupon_code:
            return self._initiate_with_coupon(user=user, product=product, coupon_code=coupon_code, attempt=attempt)

        payment = self.payment_repository.create(user=user, product=product, amount=product.price, attempt=attempt)
        return self._start_zarinpal(user=user, product=product, payment=payment, amount=product.price)

    @transaction.atomic
    def _initiate_with_coupon(self, *, user: User, product: Product, coupon_code: str, attempt=None) -> dict:
        # select_for_update inside the atomic block serializes concurrent redemptions of the
        # same code so a limited-use coupon can't be oversold by a race.
        coupon = self.coupon_repository.get_locked_for_code(coupon_code)
        if coupon is None or not coupon.is_valid_for(product):
            raise InvalidCouponException(f"Coupon {coupon_code!r} is not valid for product {product.sku}")

        amount = product.price - (product.price * coupon.discount_percent // 100)
        payment = self.payment_repository.create(
            user=user, product=product, amount=amount, coupon=coupon, attempt=attempt,
        )
        self.coupon_repository.increment_redemptions(coupon)

        if amount <= 0:
            payment = self.payment_repository.mark_paid_by_coupon(payment, coupon_code=coupon.code)
            self._fulfill(payment)
            return {"payment_url": None, "unlocked": True, "attempt_id": payment.attempt_id}

        return self._start_zarinpal(user=user, product=product, payment=payment, amount=amount)

    def _start_zarinpal(self, *, user: User, product: Product, payment: Payment, amount: int) -> dict:
        # Zarinpal redirects the buyer's own browser straight to this callback_url -- it points
        # at this backend's own public domain (api.faraman.ai, via the delyar-front stack's
        # nginx-proxy/acme-companion) rather than the frontend, so PaymentCallbackAPIView's
        # verify call doesn't depend on the frontend process being reachable. See
        # PaymentCallbackAPIView for the redirect back to the frontend's /payment/result page.
        data = self.zarinpal_client.request_payment(
            amount=amount,
            description=product.title,
            callback_url=f"{settings.BACKEND_PUBLIC_URL}/api/payment/callback/",
            mobile=user.phone_number,
        )
        self.payment_repository.set_authority(payment, authority=data["authority"], gateway_response=data)

        return {
            "payment_url": self.zarinpal_client.start_pay_url(data["authority"]),
            "unlocked": False,
            "attempt_id": payment.attempt_id,
        }

    def verify_payment(self, *, authority: str, status: str) -> Payment:
        """Idempotent: Zarinpal (or a curious buyer) can hit this more than once for the same
        authority. An already-PAID payment is returned as-is rather than re-processed, and a
        second real verify call against Zarinpal itself comes back with code=101 rather than 100."""
        payment = self.payment_repository.get_by_authority(authority)
        if payment is None:
            raise PaymentNotFoundException(f"No payment found for authority {authority}")

        if payment.status == Payment.Status.PAID:
            return payment

        if status != "OK":
            self.payment_repository.mark_failed(payment, status=Payment.Status.CANCELLED)
            raise PaymentCancelledException(f"Payment {payment.id} was cancelled")

        data = self.zarinpal_client.verify_payment(amount=payment.amount, authority=authority)
        if data.get("code") not in (100, 101):
            self.payment_repository.mark_failed(payment, status=Payment.Status.FAILED, gateway_response=data)
            raise PaymentVerificationFailedException(
                f"Payment {payment.id} verification failed with code {data.get('code')}"
            )

        payment = self.payment_repository.mark_paid(payment, ref_id=data["ref_id"], gateway_response=data)
        self._fulfill(payment)

        return payment
