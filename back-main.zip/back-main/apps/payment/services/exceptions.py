from rest_framework import status

from faraman_back.utils.exceptions import AppException


class ProductNotFoundException(AppException):
    """Raised when no active Product exists for the requested assessment."""
    status_code = status.HTTP_404_NOT_FOUND
    message_key = 'product_not_found'


class PaymentNotFoundException(AppException):
    """Raised when no Payment exists for the given authority."""
    status_code = status.HTTP_404_NOT_FOUND
    message_key = 'payment_not_found'


class PaymentGatewayException(AppException):
    """Raised when Zarinpal can't be reached, or a payment-request call doesn't return a
    success code (there's no partial-progress state worth preserving for a failed request)."""
    status_code = status.HTTP_502_BAD_GATEWAY
    message_key = 'fail_to_connect_to_payment_gateway'


class PaymentCancelledException(AppException):
    """Raised when the buyer cancelled, or Zarinpal's callback reports Status=NOK."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'payment_cancelled'


class PaymentVerificationFailedException(AppException):
    """Raised when Zarinpal's verify call was reachable but returned neither 100 nor 101.
    Deliberately a different status code than PaymentCancelledException (both would otherwise be
    400) so the frontend's callback relay can tell "buyer cancelled" apart from "verification
    failed" by status code alone, without parsing the localized message text."""
    status_code = status.HTTP_422_UNPROCESSABLE_ENTITY
    message_key = 'payment_verification_failed'


class InvalidCouponException(AppException):
    """Raised when initiate_payment is given a coupon_code that doesn't exist, is inactive,
    expired, exhausted, or doesn't apply to the requested product."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'invalid_coupon'


class AssessmentAlreadyPurchasedException(AppException):
    """Raised when initiate_payment is called by a user who already holds an unconsumed Purchase
    for the assessment's product -- prevents paying twice while an entitlement (e.g. an
    in-progress attempt, or a completed one whose report hasn't been retaken yet) is still
    active. Once the Purchase is consumed at completion, has_access_to_assessment goes back to
    False and a retake payment is allowed through."""
    status_code = status.HTTP_409_CONFLICT
    message_key = 'assessment_already_purchased'


class PaymentAttemptInvalidException(AppException):
    """Raised when initiate_payment is called for a pay-after-test assessment
    (Assessment.report_requires_purchase) without an attempt_id, or with one that is not this
    user's own completed attempt of that assessment still awaiting payment. Missing and
    not-owned attempts share this one error so it can't be used to probe other users' ids."""
    status_code = status.HTTP_400_BAD_REQUEST
    message_key = 'payment_attempt_invalid'
