import logging

import requests
from django.conf import settings

from apps.payment.services.exceptions import PaymentGatewayException

logger = logging.getLogger(__name__)

REQUEST_TIMEOUT_SECONDS = 10


class ZarinpalClient:
    """Thin wrapper around Zarinpal's REST v4 payment gateway
    (https://www.zarinpal.com/docs/paymentGateway/connectToGateway.html). Not a repository --
    apps/payment touches no local storage here. Plays the same role apps/account's SMSService
    plays for Melipayamak: an external-HTTP-API collaborator injected into a service.
    """

    def __init__(self):
        self.merchant_id = settings.ZARINPAL_MERCHANT_ID
        self.host = "sandbox.zarinpal.com" if settings.ZARINPAL_SANDBOX else "payment.zarinpal.com"

    def _post(self, path: str, payload: dict) -> dict:
        """POSTs to /pg/v4/payment/{path} and returns the full response body ({"data": ...,
        "errors": ...}). Only raises PaymentGatewayException for network/format failures --
        callers decide what a given response shape means for their own endpoint. In particular,
        an empty `data` is NOT necessarily a gateway problem: verify.json legitimately responds
        that way (with the real error code under `errors`) for a plain unpaid/expired authority,
        which is a normal outcome for verify, not a network failure."""
        url = f"https://{self.host}/pg/v4/payment/{path}"
        try:
            response = requests.post(url, json=payload, timeout=REQUEST_TIMEOUT_SECONDS)
            return response.json()
        except (requests.RequestException, ValueError) as exc:
            logger.exception("Zarinpal request to %s failed: %s", path, exc)
            raise PaymentGatewayException(f"Zarinpal request to {path} failed") from exc

    def request_payment(self, *, amount: int, description: str, callback_url: str, mobile: str | None = None) -> dict:
        payload = {
            "merchant_id": self.merchant_id,
            "amount": amount,
            "currency": "IRT",
            "description": description,
            "callback_url": callback_url,
        }
        if mobile:
            # Zarinpal only associates a buyer's remembered cards with a mobile number sent
            # under `metadata.mobile` -- a top-level `mobile` field is accepted but ignored for
            # that lookup (https://www.zarinpal.com/docs/paymentGateway/moreFeatures/card-pan).
            payload["metadata"] = {"mobile": mobile}

        body = self._post("request.json", payload)
        data = body.get("data") or {}
        if not data or data.get("code") != 100:
            # No partial-progress state worth preserving for a failed *request* -- unlike
            # verify, there's no "buyer hasn't paid yet" reading of this response.
            logger.error("Zarinpal request.json returned an error response: %s", body)
            raise PaymentGatewayException(f"Zarinpal payment request failed: {body.get('errors')}")

        return data

    def verify_payment(self, *, amount: int, authority: str) -> dict:
        """Returns a normalized {"code": ..., ...} dict, whether Zarinpal put it under `data`
        (code 100 first verification, 101 already-verified repeat) or `errors` (the common shape
        for an authority that was never actually paid, expired, or amount-mismatched). The
        caller (PaymentService) decides what a given code means; only a network/format failure
        raises here."""
        payload = {
            "merchant_id": self.merchant_id,
            "amount": amount,
            "authority": authority,
        }
        body = self._post("verify.json", payload)
        data = body.get("data")
        if data:
            return data

        errors = body.get("errors") or {}
        return {"code": errors.get("code"), "message": errors.get("message")}

    def start_pay_url(self, authority: str) -> str:
        return f"https://{self.host}/pg/StartPay/{authority}"
