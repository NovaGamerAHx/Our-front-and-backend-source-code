from apps.account.models import User
from apps.assessment.models import Assessment
from apps.payment.repositories.product_repository import ProductRepository
from apps.payment.repositories.purchase_repository import PurchaseRepository


class EntitlementService:
    """has_access() is the single source of truth for access decisions -- no other service or
    view should query Purchase directly to decide whether a user can use a product."""

    def __init__(self, product_repository=None, purchase_repository=None):
        self.product_repository = product_repository or ProductRepository()
        self.purchase_repository = purchase_repository or PurchaseRepository()

    def has_access(self, *, user: User | None, product_key: str) -> bool:
        if user is None:
            return False

        return self.purchase_repository.exists_for_user_sku(user, product_key)

    def has_access_to_assessment(self, *, user: User | None, assessment: Assessment) -> bool:
        """Assessment-gated flows (AttemptService.start_attempt) don't have a product_key on
        hand, only the assessment -- this resolves its active product and still defers the
        actual decision to has_access(), so it's not a second access-decision path."""
        if user is None:
            return False

        product = self.product_repository.get_active_for_assessment(assessment)
        if product is None:
            return False

        return self.has_access(user=user, product_key=product.sku)

    def consume_for_assessment(self, *, user: User | None, assessment: Assessment) -> None:
        """Called by AttemptService.complete_attempt when a requires_purchase assessment's
        attempt completes. Retaking it needs a fresh payment: this consumes the user's Purchase
        for the assessment's active product, so has_access_to_assessment/has_access flip to False
        until a new payment reactivates it (PurchaseRepository.grant_or_reactivate)."""
        if user is None:
            return

        product = self.product_repository.get_active_for_assessment(assessment)
        if product is None:
            return

        self.purchase_repository.consume(user=user, product=product)

    def list_product_prices(self) -> list[dict]:
        """GET /api/payment/products/ (public): the same product shape as list_entitlements
        minus anything user-specific, so a logged-out visitor can see the paywall's real price
        before being asked to log in."""
        return [
            {
                "product_key": product.sku,
                "title": product.title,
                "assessment_slug": product.assessment.slug,
                "price": product.price,  # Toman
            }
            for product in self.product_repository.get_all_active()
        ]

    def list_entitlements(self, *, user: User) -> list[dict]:
        """GET /api/users/me/entitlements: every active product plus this user's access to it,
        for a UI entitlements/paywall panel. Uses get_owned_skus_for_user (one query for all
        products) rather than calling has_access per product -- same underlying Purchase table,
        just the bulk form."""
        products = self.product_repository.get_all_active()
        owned_skus = self.purchase_repository.get_owned_skus_for_user(user)

        return [
            {
                "product_key": product.sku,
                "title": product.title,
                "assessment_slug": product.assessment.slug,
                "has_access": product.sku in owned_skus,
                "price": product.price,  # Toman -- the paywall renders this as the real (post-discount) price
            }
            for product in products
        ]
