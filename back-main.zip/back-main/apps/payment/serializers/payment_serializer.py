from rest_framework import serializers


class InitiatePaymentSerializer(serializers.Serializer):
    assessment_slug = serializers.SlugField()
    coupon_code = serializers.CharField(required=False, allow_blank=True)
    attempt_id = serializers.IntegerField(required=False, min_value=1)
