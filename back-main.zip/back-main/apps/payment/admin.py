from django.contrib import admin

from apps.payment.models import Coupon, Payment, Product, Purchase


@admin.register(Coupon)
class CouponAdmin(admin.ModelAdmin):
    list_display = (
        "id", "code", "product", "discount_percent", "is_active",
        "redemptions_count", "max_redemptions", "expires_at", "created_at",
    )
    list_filter = ("is_active", "product")
    search_fields = ("code",)
    readonly_fields = ("redemptions_count", "created_at")


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("id", "sku", "kind", "title", "price", "assessment", "is_active", "created_at")
    list_filter = ("kind", "is_active")
    search_fields = ("sku", "title", "assessment__slug")


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    """Read-only: a Payment is an accounting record, not something to hand-edit."""

    list_display = ("id", "user", "product", "amount", "status", "authority", "ref_id", "created_at", "paid_at")
    list_filter = ("status",)
    search_fields = ("authority", "ref_id", "user__phone_number")
    readonly_fields = [f.name for f in Payment._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


@admin.register(Purchase)
class PurchaseAdmin(admin.ModelAdmin):
    """Read-only: an entitlement record, granted only by a verified Payment."""

    list_display = ("id", "user", "product", "payment", "granted_at")
    search_fields = ("user__phone_number", "product__sku")
    readonly_fields = [f.name for f in Purchase._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
