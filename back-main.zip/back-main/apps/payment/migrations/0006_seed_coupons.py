from django.db import migrations


def seed_coupons(apps, schema_editor):
    """Create/update the seeded coupons so they exist in every environment (incl. production)
    without a manual `seed_coupons` run or admin entry. Idempotent: safe to re-run via migrate.

    Values are frozen here (not read from settings/env) so the migration stays deterministic --
    changing a campaign later means editing settings + re-running `seed_coupons`, not rewriting
    history. `product` is intentionally left untouched (NULL for new rows = any product).
    """
    Coupon = apps.get_model("payment", "Coupon")
    Coupon.objects.update_or_create(
        code="FARAMAN100M",
        defaults={"discount_percent": 100, "final_price": None, "is_active": True},
    )
    Coupon.objects.update_or_create(
        code="FARAMAN75",
        defaults={"discount_percent": 75, "final_price": 99_000, "is_active": True},
    )


class Migration(migrations.Migration):

    dependencies = [
        ("payment", "0005_coupon_final_price"),
    ]

    operations = [
        migrations.RunPython(seed_coupons, migrations.RunPython.noop),
    ]
