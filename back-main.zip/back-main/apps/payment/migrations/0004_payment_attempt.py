import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('assessment', '0010_assessment_report_requires_purchase'),
        ('payment', '0003_coupon_payment_coupon'),
    ]

    operations = [
        migrations.AddField(
            model_name='payment',
            name='attempt',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='payments', to='assessment.attempt'),
        ),
    ]
