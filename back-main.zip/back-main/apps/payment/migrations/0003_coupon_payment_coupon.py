import django.core.validators
import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('payment', '0002_purchase_consumed_at'),
    ]

    operations = [
        migrations.CreateModel(
            name='Coupon',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('code', models.CharField(db_index=True, max_length=32, unique=True)),
                ('discount_percent', models.PositiveSmallIntegerField(validators=[django.core.validators.MinValueValidator(1), django.core.validators.MaxValueValidator(100)])),
                ('is_active', models.BooleanField(default=True)),
                ('max_redemptions', models.PositiveIntegerField(blank=True, help_text='Leave blank for unlimited.', null=True)),
                ('redemptions_count', models.PositiveIntegerField(default=0)),
                ('expires_at', models.DateTimeField(blank=True, null=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('product', models.ForeignKey(blank=True, help_text='Leave blank to allow this coupon on any product.', null=True, on_delete=django.db.models.deletion.PROTECT, related_name='coupons', to='payment.product')),
            ],
            options={
                'db_table': 'payment_coupons',
            },
        ),
        migrations.AddField(
            model_name='payment',
            name='coupon',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='payments', to='payment.coupon'),
        ),
    ]
