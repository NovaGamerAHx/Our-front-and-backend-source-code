import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('payment', '0004_payment_attempt'),
    ]

    operations = [
        migrations.AddField(
            model_name='coupon',
            name='final_price',
            field=models.PositiveIntegerField(blank=True, help_text='Exact payable amount (Toman) when set; overrides discount_percent math. Leave blank to charge by percent.', null=True),
        ),
    ]
