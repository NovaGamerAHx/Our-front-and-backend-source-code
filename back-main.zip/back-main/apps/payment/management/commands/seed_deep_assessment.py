from django.core.management.base import BaseCommand
from django.db import transaction

from apps.assessment.data.deep_150 import DEEP_150_ITEMS, FACET_ORDER, SECTION_SIZE
from apps.assessment.models import Assessment, AssessmentSection, Question
from apps.payment.models import Product
from faraman_back.lang.utils import get_message

DEEP_ASSESSMENT_SLUG = "deep-150-v1"
DEEP_PRODUCT_SKU = "deep-150-v1"
DEEP_PRODUCT_PRICE = 199_000  # Toman -- PM owns the final number (deep_report_spec_v1_2.md §11)

# The placeholder this replaces: a copy of the 30-item bank, seeded only so the Zarinpal flow
# had something purchasable before the real instrument existed.
LEGACY_ASSESSMENT_SLUG = "deep-test-v1"
LEGACY_PRODUCT_SKU = "deep-test-v1"


def _check_key_invariants():
    """Fail loudly on a transcription error in deep_150.py rather than skewing every score.

    These are the same structural properties the scoring manual's key has (§6.1/§6.2), checked
    against the actual data: a typo that moved an item between facets would otherwise produce
    plausible-looking but wrong numbers forever, and there is no norm data to catch it later.
    """
    positions = [item[0] for item in DEEP_150_ITEMS]
    assert sorted(positions) == list(range(1, 151)), "items must cover positions 1..150 exactly"

    facet_items = {}
    core_domains = {}
    for position, _text, reverse_scored, key in DEEP_150_ITEMS:
        if key["scale"] == "facet":
            assert key["facet"][0] == key["domain"], f"facet {key['facet']} disagrees with its domain"
            facet_items.setdefault(key["facet"], []).append(reverse_scored)
        else:
            core_domains[key["domain"]] = core_domains.get(key["domain"], 0) + 1

    assert set(facet_items) == set(FACET_ORDER), "facet items must cover exactly the 30 facets"
    for code, reverses in facet_items.items():
        assert len(reverses) == 4, f"facet {code} has {len(reverses)} items, expected 4"
        assert sum(reverses) == 1, f"facet {code} has {sum(reverses)} reverse items, expected 1"

    assert set(core_domains) == set("NEOAC"), "core items must cover all five domains"
    for domain, count in core_domains.items():
        assert count == 6, f"domain {domain} has {count} core items, expected 6"


class Command(BaseCommand):
    help = (
        "Creates (or updates) the real 'deep-150-v1' assessment: the 150-item deep personality "
        "test from docs/Personality_150_Test_Scoring_Manual_FA_Ravi_v1.2.docx, in 6 sections of "
        "25, each question carrying its facet/core key on Question.scoring. Also creates the "
        "matching paid Product and deactivates the old 'deep-test-v1' placeholder (assessment "
        "and product) so only one deep product is purchasable. Idempotent."
    )

    @transaction.atomic
    def handle(self, *args, **options):
        _check_key_invariants()

        assessment, created = Assessment.objects.update_or_create(
            slug=DEEP_ASSESSMENT_SLUG,
            defaults={
                "title": get_message("deep_report_title"),
                "kind": Assessment.Kind.SUPPLEMENTARY,
                "scoring_profile": Assessment.ScoringProfile.FACET_150,
                "version": 1,
                "is_active": True,
                # Pay-after-test: free to take, the finished report is what is paid for.
                "requires_purchase": False,
                "report_requires_purchase": True,
            },
        )

        section_count = -(-len(DEEP_150_ITEMS) // SECTION_SIZE)  # ceil
        sections = {}
        for section_order in range(1, section_count + 1):
            sections[section_order], _ = AssessmentSection.objects.update_or_create(
                assessment=assessment,
                order=section_order,
                defaults={
                    # Presentational only. Unlike the initial test, the title carries no scoring
                    # meaning here -- DeepScoringService reads Question.scoring instead.
                    "title": get_message("deep_section_title", number=section_order),
                    "interstitial_message": (
                        ""
                        if section_order == section_count
                        else get_message(
                            "deep_section_interstitial", done=section_order, total=section_count
                        )
                    ),
                },
            )

        seeded_ids = []
        for position, text, reverse_scored, key in DEEP_150_ITEMS:
            section_order = (position - 1) // SECTION_SIZE + 1
            question, _ = Question.objects.update_or_create(
                section=sections[section_order],
                order=(position - 1) % SECTION_SIZE + 1,
                defaults={
                    "text": text,
                    "question_type": Question.QuestionType.LIKERT,
                    "options": [],
                    # The scoring key: {"scale": "facet", "facet", "domain"} for the 120 facet
                    # items, {"scale": "core", "core_id", "domain"} for the 30 interleaved core
                    # items. Backend-only -- never serialized to the client.
                    "scoring": key,
                    "reverse_scored": reverse_scored,
                    "is_active": True,
                },
            )
            seeded_ids.append(question.id)

        # Anything else still attached to this assessment is a leftover from the placeholder
        # seed (5 dimension-titled sections of 6). Deactivate rather than delete: Answer.question
        # is a PROTECT FK and earlier attempts may already reference those rows.
        stale = Question.objects.filter(
            section__assessment=assessment, is_active=True,
        ).exclude(id__in=seeded_ids).update(is_active=False)

        product, _ = Product.objects.update_or_create(
            sku=DEEP_PRODUCT_SKU,
            defaults={
                "kind": Product.Kind.ASSESSMENT_UNLOCK,
                "title": assessment.title,
                "price": DEEP_PRODUCT_PRICE,
                "assessment": assessment,
                "is_active": True,
            },
        )

        # Retire the placeholder. Rows are kept (Purchase.product is a PROTECT FK, and any real
        # purchase of the old SKU still needs to resolve) -- they just stop being sellable and
        # startable. Migrating such an entitlement to the new SKU is a separate decision.
        retired_assessments = Assessment.objects.filter(
            slug=LEGACY_ASSESSMENT_SLUG, is_active=True
        ).update(is_active=False)
        retired_products = Product.objects.filter(
            sku=LEGACY_PRODUCT_SKU, is_active=True
        ).update(is_active=False)

        verb = "Created" if created else "Updated"
        self.stdout.write(self.style.SUCCESS(
            f"{verb} assessment '{assessment.slug}' with {section_count} sections and "
            f"{len(DEEP_150_ITEMS)} questions, product '{product.sku}' ({product.price} T)."
        ))
        if stale:
            self.stdout.write(f"Deactivated {stale} stale question(s) from an earlier seed.")
        if retired_assessments or retired_products:
            self.stdout.write(self.style.WARNING(
                f"Retired the '{LEGACY_ASSESSMENT_SLUG}' placeholder "
                f"({retired_assessments} assessment, {retired_products} product)."
            ))
