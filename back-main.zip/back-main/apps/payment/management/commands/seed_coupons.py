from django.core.management.base import BaseCommand

from apps.payment.models import Coupon

# Coupons are otherwise pure admin data (CouponAdmin, apps/payment/admin.py) with no seed path,
# so a fresh local/dev database never has the ones created by hand in production's admin. This
# seeds just the ones that need to exist consistently across environments. Idempotent.
SEEDED_COUPONS = [
    {"code": "FARAMAN100M", "discount_percent": 100, "is_active": True},
]


class Command(BaseCommand):
    help = (
        "Creates (or updates) the fixed set of coupons in SEEDED_COUPONS, so they exist in any "
        "environment without needing to be re-entered by hand in the Django admin. Idempotent."
    )

    def handle(self, *args, **options):
        for entry in SEEDED_COUPONS:
            code = entry["code"]
            coupon, created = Coupon.objects.update_or_create(
                code=code,
                defaults={k: v for k, v in entry.items() if k != "code"},
            )
            verb = "Created" if created else "Updated"
            self.stdout.write(self.style.SUCCESS(f"{verb} coupon '{coupon.code}' (-{coupon.discount_percent}%)."))
