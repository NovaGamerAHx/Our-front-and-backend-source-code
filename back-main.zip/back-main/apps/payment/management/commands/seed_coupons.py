from django.conf import settings
from django.core.management.base import BaseCommand

from apps.payment.models import Coupon

# Coupons are otherwise pure admin data (CouponAdmin, apps/payment/admin.py) with no seed path,
# so a fresh local/dev database never has the ones created by hand in production's admin. This
# seeds just the ones that need to exist consistently across environments. Idempotent.
#
# Codes/percents/final prices come from settings (env-configurable with safe defaults -- see
# faraman_back/settings.py "Deep-report pricing & coupons"), so changing a campaign never needs
# a code deploy: change the env var, restart, re-run `seed_coupons`. getattr() with the same
# defaults keeps this command working even if settings.py predates those names.
def _seeded_coupons():
    return [
        {
            "code": getattr(settings, "COUPON_100_CODE", "FARAMAN100M"),
            "discount_percent": getattr(settings, "COUPON_100_PERCENT", 100),
            "final_price": None,
            "is_active": True,
        },
        {
            "code": getattr(settings, "COUPON_75_CODE", "FARAMAN75"),
            "discount_percent": getattr(settings, "COUPON_75_PERCENT", 75),
            "final_price": getattr(settings, "COUPON_75_FINAL_PRICE_TOMAN", 99_000),
            "is_active": True,
        },
    ]


SEEDED_COUPONS = _seeded_coupons()


class Command(BaseCommand):
    help = (
        "Creates (or updates) the fixed set of coupons in SEEDED_COUPONS, so they exist in any "
        "environment without needing to be re-entered by hand in the Django admin. Idempotent."
    )

    def handle(self, *args, **options):
        # Re-read settings at call time (not import time) so a changed env var takes effect
        # on the next run without a code change.
        for entry in _seeded_coupons():
            code = entry["code"]
            coupon, created = Coupon.objects.update_or_create(
                code=code,
                defaults={k: v for k, v in entry.items() if k != "code"},
            )
            verb = "Created" if created else "Updated"
            if coupon.final_price is not None:
                detail = f"final price {coupon.final_price} T"
            else:
                detail = f"-{coupon.discount_percent}%"
            self.stdout.write(self.style.SUCCESS(f"{verb} coupon '{coupon.code}' ({detail})."))
