from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.utils import timezone

from apps.assessment.models import Assessment, Attempt


class Product(models.Model):
    class Kind(models.TextChoices):
        ASSESSMENT_UNLOCK = "assessment_unlock", "Assessment unlock"

    sku = models.SlugField(unique=True)
    kind = models.CharField(max_length=30, choices=Kind.choices, default=Kind.ASSESSMENT_UNLOCK)
    title = models.CharField(max_length=200)
    price = models.PositiveIntegerField()  # Toman
    assessment = models.ForeignKey(Assessment, on_delete=models.PROTECT, related_name="products")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "payment_products"

    def __str__(self):
        return f"{self.sku} ({self.price} T)"


class Coupon(models.Model):
    """A discount code, optionally scoped to one Product. A 100%-off coupon lets
    PaymentService.initiate_payment grant access directly, skipping Zarinpal entirely (see
    PaymentService)."""

    code = models.CharField(max_length=32, unique=True, db_index=True)
    product = models.ForeignKey(
        Product, on_delete=models.PROTECT, null=True, blank=True, related_name="coupons",
        help_text="Leave blank to allow this coupon on any product.",
    )
    discount_percent = models.PositiveSmallIntegerField(validators=[MinValueValidator(1), MaxValueValidator(100)])
    is_active = models.BooleanField(default=True)
    max_redemptions = models.PositiveIntegerField(null=True, blank=True, help_text="Leave blank for unlimited.")
    redemptions_count = models.PositiveIntegerField(default=0)
    expires_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "payment_coupons"

    def __str__(self):
        return f"{self.code} (-{self.discount_percent}%)"

    def is_valid_for(self, product: Product) -> bool:
        if not self.is_active:
            return False
        if self.product_id is not None and self.product_id != product.id:
            return False
        if self.expires_at is not None and self.expires_at <= timezone.now():
            return False
        if self.max_redemptions is not None and self.redemptions_count >= self.max_redemptions:
            return False
        return True


class Payment(models.Model):
    class Status(models.TextChoices):
        PENDING = "pending", "Pending"
        PAID = "paid", "Paid"
        FAILED = "failed", "Failed"
        CANCELLED = "cancelled", "Cancelled"

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="payments")
    product = models.ForeignKey(Product, on_delete=models.PROTECT, related_name="payments")
    coupon = models.ForeignKey(
        Coupon, on_delete=models.PROTECT, null=True, blank=True, related_name="payments",
    )
    # Set for pay-after-test assessments (Assessment.report_requires_purchase): the completed
    # attempt whose report this payment unlocks. Null for legacy pay-before-test payments.
    attempt = models.ForeignKey(
        Attempt, on_delete=models.PROTECT, null=True, blank=True, related_name="payments",
    )
    amount = models.PositiveIntegerField()  # snapshot of product.price at creation (post-coupon), Toman
    authority = models.CharField(max_length=64, null=True, blank=True, db_index=True)
    ref_id = models.CharField(max_length=64, null=True, blank=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING)
    gateway_response = models.JSONField(default=dict, blank=True)  # raw request/verify payloads, for audit
    created_at = models.DateTimeField(auto_now_add=True)
    paid_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "payments"
        indexes = [
            models.Index(fields=["authority"]),
            models.Index(fields=["user", "status"]),
        ]

    def __str__(self):
        return f"Payment #{self.id} for user #{self.user_id} ({self.status})"


class Purchase(models.Model):
    """The entitlement: proof the user unlocked a product.

    consumed_at marks a Purchase as spent: access checks (EntitlementService/PurchaseRepository)
    require it NULL. A completed requires_purchase attempt consumes its Purchase
    (AttemptService.complete_attempt -> EntitlementService.consume_for_assessment); a subsequent
    payment reactivates the same row (PurchaseRepository.grant_or_reactivate resets consumed_at
    to NULL and repoints payment) rather than creating a second one, so the
    unique_purchase_per_user_product constraint always holds."""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="purchases")
    product = models.ForeignKey(Product, on_delete=models.PROTECT, related_name="purchases")
    payment = models.OneToOneField(Payment, on_delete=models.PROTECT, related_name="purchase")
    granted_at = models.DateTimeField(auto_now_add=True)
    consumed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "purchases"
        constraints = [
            models.UniqueConstraint(fields=["user", "product"], name="unique_purchase_per_user_product"),
        ]

    def __str__(self):
        return f"Purchase of {self.product.sku} by user #{self.user_id}"
