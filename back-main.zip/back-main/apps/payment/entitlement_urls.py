from django.urls import path

from apps.payment.views.entitlement_view import EntitlementListAPIView

# Literal contract path under /api/users/me/... -- outside apps/payment/urls.py's own
# /api/payment/ convention, same rationale as apps/chat/checkin_urls.py.
app_name = "entitlements"

urlpatterns = [
    path("users/me/entitlements/", EntitlementListAPIView.as_view(), name="entitlement_list"),
]
