from django.urls import path

from apps.payment.views.entitlement_view import ProductPriceListAPIView
from apps.payment.views.payment_view import InitiatePaymentAPIView, PaymentCallbackAPIView

app_name = "payment"

urlpatterns = [
    path("initiate/", InitiatePaymentAPIView.as_view(), name="initiate_payment"),
    path("products/", ProductPriceListAPIView.as_view(), name="product_prices"),
    path("callback/", PaymentCallbackAPIView.as_view(), name="payment_callback"),
]
