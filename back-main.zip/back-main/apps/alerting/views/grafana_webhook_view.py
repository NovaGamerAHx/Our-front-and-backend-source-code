from drf_spectacular.utils import extend_schema
from rest_framework.permissions import AllowAny
from rest_framework.views import APIView

from apps.alerting.serializers.grafana_webhook_serializer import GrafanaWebhookSerializer
from apps.alerting.services.alert_service import AlertService
from apps.alerting.services.exceptions import (
    GrafanaAlertDeliveryFailedException,
    GrafanaWebhookUnauthorizedException,
)
from faraman_back.lang.utils import get_message
from faraman_back.utils.responses import ApiResponse
from faraman_back.utils.schema import error_responses


class GrafanaWebhookAPIView(APIView):
    """Contact point target for Grafana's generic Webhook integration -- relays alert
    notifications to a Bale messenger chat (apps/alerting/services/bale_service.py), since
    Grafana has no built-in Bale integration.

    Authenticated by GRAFANA_WEBHOOK_SECRET embedded in the URL path itself (`<secret>` below),
    not an Authorization header: the caller is Grafana's webhook notifier, which only lets
    provisioning set a small, version-specific set of header/auth fields, while `url` is the one
    field guaranteed stable across Grafana versions -- the same reason Slack/Discord incoming
    webhooks bake their secret into the URL too.
    """

    permission_classes = [AllowAny]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.alert_service = AlertService()

    @extend_schema(
        description="Receives a Grafana unified-alerting webhook notification and relays it to "
                    "the configured Bale messenger chat. `secret` is GRAFANA_WEBHOOK_SECRET.",
        tags=["Alerting"],
        request=GrafanaWebhookSerializer,
        responses={
            200: None,
            **error_responses(GrafanaWebhookUnauthorizedException, GrafanaAlertDeliveryFailedException),
        },
    )
    def post(self, request, secret):
        serializer = GrafanaWebhookSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        self.alert_service.deliver_grafana_alert(secret=secret, **serializer.validated_data)

        return ApiResponse.success(message=get_message("grafana_alert_delivered"))
