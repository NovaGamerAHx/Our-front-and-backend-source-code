from django.urls import path

from apps.alerting.views.grafana_webhook_view import GrafanaWebhookAPIView

app_name = "alerting"

urlpatterns = [
    # <secret> is GRAFANA_WEBHOOK_SECRET, embedded in the webhook URL itself -- see
    # GrafanaWebhookAPIView for why (same pattern Slack/Discord incoming webhooks use).
    path("grafana-webhook/<str:secret>/", GrafanaWebhookAPIView.as_view(), name="grafana_webhook"),
]
