from rest_framework import status

from faraman_back.utils.exceptions import AppException


class BaleServiceMisconfiguredException(AppException):
    """Raised when BALE_BOT_TOKEN or BALE_CHAT_ID is missing from the environment."""
    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    message_key = 'system_error'


class GrafanaWebhookUnauthorizedException(AppException):
    """Raised when the request's Authorization header doesn't match GRAFANA_WEBHOOK_SECRET.
    This endpoint has no user to authenticate (the caller is Grafana, not a logged-in user) --
    a shared secret is the only thing standing between it and anyone who can reach the URL."""
    status_code = status.HTTP_401_UNAUTHORIZED
    message_key = 'grafana_webhook_unauthorized'


class GrafanaAlertDeliveryFailedException(AppException):
    """Raised when BaleService.send_message reports a failed send for a relayed Grafana alert.
    502, not 500: the failure is upstream (Bale's API), and Grafana's own retry/notification
    history treats a non-2xx as a failed delivery it can retry -- exactly what we want for a
    transient Bale outage."""
    status_code = status.HTTP_502_BAD_GATEWAY
    message_key = 'grafana_alert_delivery_failed'
