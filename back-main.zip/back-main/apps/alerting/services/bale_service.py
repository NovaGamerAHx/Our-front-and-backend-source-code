import logging

import requests
from django.conf import settings

from apps.alerting.services.exceptions import BaleServiceMisconfiguredException
from faraman_back.observability.metrics import ALERT_DELIVERY_DURATION, delivery_outcome, observe

logger = logging.getLogger(__name__)

BALE_API_BASE = "https://tapi.bale.ai"
BALE_MESSAGE_MAX_LENGTH = 4096
BALE_REQUEST_TIMEOUT_SECONDS = 10


class BaleService:
    """Bale messenger Bot API client (https://docs.bale.ai) -- same shape as SMSService/
    EmailService: credentials checked eagerly in __init__, the HTTP call wrapped in try/except,
    returns bool rather than raising so the caller decides what a failed send means."""

    def __init__(self):
        self.bot_token = settings.BALE_BOT_TOKEN
        self.chat_id = settings.BALE_CHAT_ID

        if not self.bot_token or not self.chat_id:
            logger.error("Bale bot credentials missing")
            raise BaleServiceMisconfiguredException("Bale bot credentials missing")

    @observe(ALERT_DELIVERY_DURATION, outcome=delivery_outcome)
    def send_message(self, text: str) -> bool:
        try:
            response = requests.post(
                f"{BALE_API_BASE}/bot{self.bot_token}/sendMessage",
                json={"chat_id": self.chat_id, "text": text[:BALE_MESSAGE_MAX_LENGTH]},
                timeout=BALE_REQUEST_TIMEOUT_SECONDS,
            )
            body = response.json()

            if not response.ok or not body.get("ok"):
                logger.error(f"Bale send failed: {response.status_code} {body}")
                return False

            return True
        except Exception as e:
            logger.exception(f"Bale send failed: {e}")
            return False
