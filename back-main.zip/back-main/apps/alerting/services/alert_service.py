import hmac
import logging

from django.conf import settings

from apps.alerting.services.bale_service import BaleService
from apps.alerting.services.exceptions import (
    GrafanaAlertDeliveryFailedException,
    GrafanaWebhookUnauthorizedException,
)

logger = logging.getLogger(__name__)

STATUS_EMOJI = {"firing": "\U0001F534", "resolved": "✅"}


class AlertService:
    def __init__(self, bale_service=None):
        # Lazy, not constructed here -- same reasoning as ReportService.email_service: an eager
        # BaleService() would raise inside GrafanaWebhookAPIView.__init__, which DRF's exception
        # handler doesn't wrap (it only wraps the request-handler call), turning a missing bot
        # token into a raw 500 instead of the standard ApiResponse.error(...) envelope.
        self._bale_service = bale_service

    @property
    def bale_service(self):
        if self._bale_service is None:
            self._bale_service = BaleService()
        return self._bale_service

    @staticmethod
    def _verify_secret(secret: str) -> None:
        expected = settings.GRAFANA_WEBHOOK_SECRET
        if not expected or not hmac.compare_digest(secret, expected):
            raise GrafanaWebhookUnauthorizedException()

    @staticmethod
    def _format_message(*, status: str, title: str, message: str) -> str:
        header = f"{STATUS_EMOJI.get(status, chr(0x26A0))} {title}".strip()
        return f"{header}\n\n{message}".strip() if message else header

    def deliver_grafana_alert(self, *, secret: str, status: str, title: str, message: str) -> None:
        """Relays a Grafana unified-alerting webhook notification to the Bale chat configured
        via BALE_CHAT_ID. No Celery task, same reasoning as ReportService.email_report: a single
        HTTP call to Bale's Bot API is fast enough to do inline."""
        self._verify_secret(secret)

        text = self._format_message(status=status, title=title, message=message)
        if not self.bale_service.send_message(text):
            raise GrafanaAlertDeliveryFailedException()
