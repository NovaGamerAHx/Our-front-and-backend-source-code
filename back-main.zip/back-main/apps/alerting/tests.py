from unittest.mock import MagicMock, patch

from django.test import TestCase, override_settings
from rest_framework.test import APIClient

from apps.alerting.services.alert_service import AlertService
from apps.alerting.services.bale_service import BaleService
from apps.alerting.services.exceptions import (
    BaleServiceMisconfiguredException,
    GrafanaAlertDeliveryFailedException,
    GrafanaWebhookUnauthorizedException,
)


@override_settings(GRAFANA_WEBHOOK_SECRET="topsecret")
class AlertServiceDeliverGrafanaAlertTests(TestCase):
    def setUp(self):
        self.bale_service = MagicMock()
        self.service = AlertService(bale_service=self.bale_service)

    def test_raises_when_secret_does_not_match(self):
        with self.assertRaises(GrafanaWebhookUnauthorizedException):
            self.service.deliver_grafana_alert(secret="wrong", status="firing", title="t", message="m")
        self.bale_service.send_message.assert_not_called()

    @override_settings(GRAFANA_WEBHOOK_SECRET="")
    def test_raises_when_secret_unconfigured(self):
        with self.assertRaises(GrafanaWebhookUnauthorizedException):
            self.service.deliver_grafana_alert(secret="anything", status="firing", title="t", message="m")
        self.bale_service.send_message.assert_not_called()

    def test_raises_when_bale_send_fails(self):
        self.bale_service.send_message.return_value = False

        with self.assertRaises(GrafanaAlertDeliveryFailedException):
            self.service.deliver_grafana_alert(secret="topsecret", status="firing", title="t", message="m")

    def test_formats_and_sends_firing_alert(self):
        self.bale_service.send_message.return_value = True

        self.service.deliver_grafana_alert(
            secret="topsecret", status="firing",
            title="High error rate", message="5xx rate above 5% for 5m",
        )

        self.bale_service.send_message.assert_called_once()
        (text,) = self.bale_service.send_message.call_args[0]
        self.assertIn("High error rate", text)
        self.assertIn("5xx rate above 5% for 5m", text)

    def test_formats_resolved_alert_without_message(self):
        self.bale_service.send_message.return_value = True

        self.service.deliver_grafana_alert(secret="topsecret", status="resolved", title="High error rate", message="")

        (text,) = self.bale_service.send_message.call_args[0]
        self.assertIn("High error rate", text)


class BaleServiceTests(TestCase):
    @override_settings(BALE_BOT_TOKEN="", BALE_CHAT_ID="123")
    def test_raises_when_bot_token_missing(self):
        with self.assertRaises(BaleServiceMisconfiguredException):
            BaleService()

    @override_settings(BALE_BOT_TOKEN="tok", BALE_CHAT_ID="")
    def test_raises_when_chat_id_missing(self):
        with self.assertRaises(BaleServiceMisconfiguredException):
            BaleService()

    @override_settings(BALE_BOT_TOKEN="tok", BALE_CHAT_ID="123")
    def test_send_message_returns_true_on_ok_response(self):
        service = BaleService()
        with patch("apps.alerting.services.bale_service.requests.post") as mock_post:
            mock_post.return_value = MagicMock(ok=True, json=lambda: {"ok": True})
            self.assertTrue(service.send_message("hello"))

    @override_settings(BALE_BOT_TOKEN="tok", BALE_CHAT_ID="123")
    def test_send_message_returns_false_on_api_error(self):
        service = BaleService()
        with patch("apps.alerting.services.bale_service.requests.post") as mock_post:
            mock_post.return_value = MagicMock(ok=True, json=lambda: {"ok": False, "description": "bad chat_id"})
            self.assertFalse(service.send_message("hello"))

    @override_settings(BALE_BOT_TOKEN="tok", BALE_CHAT_ID="123")
    def test_send_message_returns_false_on_exception(self):
        service = BaleService()
        with patch("apps.alerting.services.bale_service.requests.post", side_effect=Exception("timeout")):
            self.assertFalse(service.send_message("hello"))


@override_settings(GRAFANA_WEBHOOK_SECRET="topsecret", BALE_BOT_TOKEN="tok", BALE_CHAT_ID="123")
class GrafanaWebhookAPIViewTests(TestCase):
    def setUp(self):
        self.client = APIClient()

    def test_wrong_secret_returns_401(self):
        response = self.client.post(
            "/api/alerting/grafana-webhook/wrong-secret/", data={"status": "firing"}, format="json",
        )
        self.assertEqual(response.status_code, 401)

    def test_valid_request_relays_to_bale(self):
        with patch("apps.alerting.services.bale_service.requests.post") as mock_post:
            mock_post.return_value = MagicMock(ok=True, json=lambda: {"ok": True})
            response = self.client.post(
                "/api/alerting/grafana-webhook/topsecret/",
                data={"status": "firing", "title": "High error rate", "message": "5xx above threshold"},
                format="json",
            )
        self.assertEqual(response.status_code, 200)
        mock_post.assert_called_once()

    def test_bale_failure_returns_502(self):
        with patch("apps.alerting.services.bale_service.requests.post") as mock_post:
            mock_post.return_value = MagicMock(ok=False, json=lambda: {"ok": False})
            response = self.client.post(
                "/api/alerting/grafana-webhook/topsecret/",
                data={"status": "firing", "title": "t", "message": "m"},
                format="json",
            )
        self.assertEqual(response.status_code, 502)
