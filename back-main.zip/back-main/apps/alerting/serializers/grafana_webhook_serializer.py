from rest_framework import serializers


class GrafanaWebhookSerializer(serializers.Serializer):
    """Grafana's unified-alerting generic webhook payload (Grafana docs: Alerting > Configure
    notifications > Webhook notifier). Only `status`/`title`/`message` are used -- `title`/
    `message` are Grafana's own default-template renders of the whole alert group, so relaying
    them as-is avoids re-implementing alert formatting (and per-alert label/annotation parsing)
    here. Every other field Grafana sends (alerts, commonLabels, orgId, ...) is ignored."""

    status = serializers.ChoiceField(choices=["firing", "resolved"], default="firing")
    title = serializers.CharField(required=False, allow_blank=True, default="")
    message = serializers.CharField(required=False, allow_blank=True, default="")
