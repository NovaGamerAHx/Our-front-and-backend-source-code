import os

from celery import Celery

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "faraman_back.settings")

app = Celery("faraman_back")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()

# Registers the worker_init / worker_process_shutdown handlers that serve the worker tier's
# Prometheus metrics on :9809 -- see faraman_back/observability/celery_metrics.py.
from faraman_back.observability import celery_metrics  # noqa: E402,F401
