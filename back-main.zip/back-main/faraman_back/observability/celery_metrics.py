"""Exposes the Celery worker tier's Prometheus metrics over HTTP.

The web tier gets a ``/metrics`` endpoint for free (``django-prometheus`` +
``entrypoint.sh`` sets up multiprocess mode). Celery has neither, so this module:

1. On ``worker_init`` (once, in the parent process, before the prefork pool forks):
   wipes any stale per-pid mmap files, then starts a tiny HTTP server on
   :``METRICS_PORT`` backed by a ``MultiProcessCollector`` -- which aggregates the files
   written by every child.
2. On ``worker_process_shutdown`` (in each child, on graceful exit): retires that child's
   mmap files so its counters/gauges stop being counted.

Prefork safety
--------------
The HTTP server thread lives only in the parent (which supervises, never runs tasks).
``fork()`` doesn't copy threads, so children never touch the server, its registry, or the
collector -- they only append to their own per-pid files via the ``multiprocess`` Value
class (a separate file lock). ``--pool=solo`` would break this (no separate parent); don't
use it.

A ``SIGKILL`` / OOM kill skips ``worker_process_shutdown``, leaving stale files behind --
bounded to one container lifetime by the wipe in step 1. ``livesum`` gauges still drop a
dead pid on the next scrape (liveness-checked), so ``*_in_progress`` can only briefly
over-report.

``PROMETHEUS_MULTIPROC_DIR`` is set on the ``celery`` / ``celery2`` services in
``docker-compose.yml`` (not ``.env.example`` -- an empty ``render_env.sh`` line would still
trip ``prometheus_client``'s "is the key present" check, CLAUDE.md #24). The
``setdefault`` below is only a convenience for a local ``make worker``.
"""

import logging
import os
import shutil

from celery.signals import worker_init, worker_process_shutdown

logger = logging.getLogger(__name__)

METRICS_PORT = 9809
_DEFAULT_MULTIPROC_DIR = "/tmp/prometheus-multiproc"


@worker_init.connect
def _start_metrics_server(**_):
    mp_dir = os.environ.setdefault("PROMETHEUS_MULTIPROC_DIR", _DEFAULT_MULTIPROC_DIR)
    try:
        from prometheus_client import CollectorRegistry, multiprocess, start_http_server

        shutil.rmtree(mp_dir, ignore_errors=True)
        os.makedirs(mp_dir, exist_ok=True)

        registry = CollectorRegistry()
        multiprocess.MultiProcessCollector(registry)
        start_http_server(METRICS_PORT, registry=registry)
        logger.info("celery metrics server listening on :%d (multiproc dir %s)", METRICS_PORT, mp_dir)
    except Exception:
        # A metrics endpoint that fails to bind must never stop the worker from starting.
        logger.warning("could not start celery metrics server", exc_info=True)


@worker_process_shutdown.connect
def _retire_child_metrics(**_):
    try:
        from prometheus_client import multiprocess

        multiprocess.mark_process_dead(os.getpid())
    except Exception:
        logger.warning("could not retire child metrics for pid %s", os.getpid(), exc_info=True)
