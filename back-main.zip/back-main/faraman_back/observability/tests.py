"""Unit tests for the observe / observe_block helpers, against throwaway registries so they
don't touch the real app metrics."""

from prometheus_client import CollectorRegistry, Gauge, Histogram
from django.test import SimpleTestCase

from faraman_back.observability.metrics import observe, observe_block


def _make(registry):
    hist = Histogram(
        "thing_duration_seconds", "t", ["kind", "outcome"], buckets=(1, 5), registry=registry,
    )
    gauge = Gauge("thing_in_progress", "g", ["kind"], registry=registry)
    return hist, gauge


class ObserveDecoratorTests(SimpleTestCase):
    def setUp(self):
        self.reg = CollectorRegistry()
        self.hist, self.gauge = _make(self.reg)

    def _count(self, **labels):
        return self.reg.get_sample_value("thing_duration_seconds_count", labels) or 0.0

    def _gauge(self, **labels):
        return self.reg.get_sample_value("thing_in_progress", labels) or 0.0

    def test_sync_success_records_ok_and_returns_value(self):
        @observe(self.hist, in_progress=self.gauge, labels={"kind": "a"})
        def f(x):
            return x + 1

        self.assertEqual(f(1), 2)
        self.assertEqual(self._count(kind="a", outcome="ok"), 1.0)
        self.assertEqual(self._gauge(kind="a"), 0.0)

    def test_sync_exception_records_error_and_reraises(self):
        @observe(self.hist, in_progress=self.gauge, labels={"kind": "a"})
        def f():
            raise ValueError("boom")

        with self.assertRaises(ValueError):
            f()
        self.assertEqual(self._count(kind="a", outcome="error"), 1.0)
        self.assertEqual(self._gauge(kind="a"), 0.0)

    def test_outcome_callable_reads_return_value(self):
        @observe(self.hist, labels={"kind": "a"}, outcome=lambda r: r["state"])
        def f():
            return {"state": "noop"}

        f()
        self.assertEqual(self._count(kind="a", outcome="noop"), 1.0)

    def test_labels_callable_gets_call_args(self):
        @observe(self.hist, labels=lambda *, kind: {"kind": kind})
        def f(*, kind):
            return kind

        f(kind="b")
        self.assertEqual(self._count(kind="b", outcome="ok"), 1.0)

    def test_generator_normal_iteration(self):
        @observe(self.hist, in_progress=self.gauge, labels={"kind": "a"})
        def g():
            yield 1
            yield 2

        self.assertEqual(list(g()), [1, 2])
        self.assertEqual(self._count(kind="a", outcome="success"), 1.0)
        self.assertEqual(self._gauge(kind="a"), 0.0)

    def test_generator_client_disconnect(self):
        @observe(self.hist, in_progress=self.gauge, labels={"kind": "a"})
        def g():
            yield 1
            yield 2

        it = g()
        next(it)
        it.close()  # -> GeneratorExit
        self.assertEqual(self._count(kind="a", outcome="client_disconnect"), 1.0)
        self.assertEqual(self._gauge(kind="a"), 0.0)

    def test_generator_exception_records_error_and_reraises(self):
        @observe(self.hist, in_progress=self.gauge, labels={"kind": "a"})
        def g():
            yield 1
            raise RuntimeError("mid-stream")

        with self.assertRaises(RuntimeError):
            list(g())
        self.assertEqual(self._count(kind="a", outcome="error"), 1.0)
        self.assertEqual(self._gauge(kind="a"), 0.0)


class ObserveBlockTests(SimpleTestCase):
    def setUp(self):
        self.reg = CollectorRegistry()
        self.hist = Histogram("phase_seconds", "p", ["phase"], buckets=(1,), registry=self.reg)

    def test_records_even_on_exception(self):
        with self.assertRaises(ValueError):
            with observe_block(self.hist, phase="x"):
                raise ValueError()
        self.assertEqual(
            self.reg.get_sample_value("phase_seconds_count", {"phase": "x"}), 1.0
        )
