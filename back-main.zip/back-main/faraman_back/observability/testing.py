"""Test helper for asserting on metric values.

Metric objects live on the process-global default registry, so their values accumulate
across tests in one process -- assert on **deltas** (read before, act, read after), not
absolutes. Tests always run single-process (``faraman_back/settings.py`` pops
``PROMETHEUS_MULTIPROC_DIR`` when ``manage.py test`` runs), so the default ``REGISTRY``
holds the real values.
"""


def read_metric(name, **labels):
    """Current value of a single metric sample, or ``None`` if that name+labelset has no
    sample yet.

    ``name`` is the fully-qualified sample name including any suffix, e.g.
    ``"faraman_report_generation_duration_seconds_count"`` or
    ``"faraman_chat_answer_ttft_seconds_bucket"`` (pass ``le=...`` in that case).
    """
    from prometheus_client import REGISTRY

    return REGISTRY.get_sample_value(name, labels or None)
