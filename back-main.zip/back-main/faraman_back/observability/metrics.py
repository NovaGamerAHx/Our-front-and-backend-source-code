"""Application-level Prometheus metrics + declarative instrumentation helpers.

Why this module exists
----------------------
``celery-exporter`` (monitoring/) already reports queue depth and per-task runtime for the
two ``report.generate_*`` Celery tasks, and ``django-prometheus`` reports per-view request
latency -- but neither covers what we actually want to watch:

* how long an *initial* vs *deep* report takes, and how many fail, and
* how long a *chat turn* takes end to end, its time-to-first-token, and whether the client
  hung up mid-stream (``django-prometheus``'s histogram stops the moment the view returns
  the ``StreamingHttpResponse`` -- before a single token is generated), and
* how long one AI provider call attempt takes within a report's attempt ladder (a report's
  own duration histogram only sees the whole generation, not which rung of the ladder it
  landed on), and
* whether a third-party delivery (Bale, SMTP) actually succeeded -- previously invisible:
  ``BaleService``/``EmailService`` swallow their own exceptions and return ``bool``, so a
  string of failures produced no signal anywhere, and
* how often a per-user rate limit actually rejects a request (OTP, chat, report email,
  assessment attempts) -- signal for "cap too strict" vs "cap is working as intended", and
* whether a scheduled push notification actually sent, and why not when it didn't (no active
  subscription vs. every token invalid vs. a provider error) -- previously a ``Notification``
  could only be observed as ``status=failed`` in the DB, with no log line for the two common
  failure paths and no metric at all.

Import-safety
-------------
Only ``prometheus_client`` + stdlib are imported here (no Django), so services and
``faraman_back/celery.py`` can import this at module top (CLAUDE.md hard rule 4).

Multiprocess
------------
``web`` runs 3 gunicorn gevent workers per container and ``celery`` runs a prefork pool, so
a plain in-process counter is not scrape-safe. ``prometheus_client`` multiprocess mode
(per-pid mmap files, aggregated at scrape time) is wired up in ``entrypoint.sh`` +
``gunicorn.conf.py`` (web) and ``faraman_back/observability/celery_metrics.py`` (celery).
This module doesn't need to know about any of that -- it just declares metric objects on
the default registry.

Counting convention
-------------------
There is deliberately **no** standalone ``_total`` Counter *for an event a histogram already
counts*. Every histogram already exposes a ``_count`` series broken down by ``outcome`` --
e.g. ``faraman_report_generation_duration_seconds_count{report_type="deep",outcome="error"}``
-- which is exactly "how many, split by success/failure". A parallel Counter for the same
event would be a second source of truth that can silently drift from the histogram.

``THROTTLE_REJECTED`` is the one Counter below, and it's not an exception to this: a rejected
request never reaches the code path any histogram instruments (no report is generated, no
chat turn streams, no email is sent), so there is no histogram for it to duplicate. Its
"how many" has no matching "how long" to hang off.

Cardinality
-----------
Every label value below comes from a closed set (a model enum, a literal, or a branch of
control flow). Never add a label whose value can come from user input or an unbounded space
(``attempt_id``, ``session_id``, ``user_id``, ``model_used``, ``error_code``, a version
string): each distinct combination is a permanent time series.
"""

import functools
import inspect
import time
from contextlib import contextmanager

from prometheus_client import Counter, Gauge, Histogram

# --- report generation (incremented in the Celery worker) --------------------------------

# initial report is one AI call (~70s); deep is 7 parallel + 1 sequential (minutes).
_REPORT_BUCKETS = (5, 10, 20, 30, 45, 60, 90, 120, 180, 300, 450, 600)

REPORT_GENERATION_DURATION = Histogram(
    "faraman_report_generation_duration_seconds",
    "Wall time of a full report generation, from the Celery task claiming the row to the "
    "row being marked ok/error.",
    ["report_type", "outcome"],  # report_type: initial|deep  outcome: ok|error|noop
    buckets=_REPORT_BUCKETS,
)
REPORT_GENERATION_IN_PROGRESS = Gauge(
    "faraman_report_generation_in_progress",
    "Report generations currently running across all workers.",
    ["report_type"],
    multiprocess_mode="livesum",
)

# --- chat answering (incremented in the gunicorn worker, from the streaming generator) ---

# a chat turn is 5-25s of model streaming; gunicorn's hard timeout is 300s.
_CHAT_BUCKETS = (0.5, 1, 2, 4, 8, 15, 30, 60, 120, 300)
_TTFT_BUCKETS = (0.2, 0.5, 1, 2, 3, 5, 8, 13, 21)

CHAT_ANSWER_DURATION = Histogram(
    "faraman_chat_answer_duration_seconds",
    "Wall time of a chat turn, from the SSE generator starting to the last token / error / "
    "client disconnect.",
    ["kind", "outcome"],  # kind: send|regenerate  outcome: success|error|client_disconnect
    buckets=_CHAT_BUCKETS,
)
CHAT_ANSWER_TTFT = Histogram(
    "faraman_chat_answer_ttft_seconds",
    "Time from the SSE generator starting to the first token reaching the client.",
    ["kind"],
    buckets=_TTFT_BUCKETS,
)
CHAT_ANSWER_IN_PROGRESS = Gauge(
    "faraman_chat_answer_in_progress",
    "Chat turns currently streaming across all workers.",
    ["kind"],
    multiprocess_mode="livesum",
)

# --- AI provider calls (one rung of a report's attempt ladder) ---------------------------

# one call attempt, not a whole generation: seconds, not minutes.
_AI_CALL_BUCKETS = (1, 2, 4, 8, 15, 30, 45, 60, 90)

AI_CALL_DURATION = Histogram(
    "faraman_ai_call_duration_seconds",
    "Wall time of one AI provider call attempt -- one rung of a report generation's "
    "model/provider attempt ladder, not the whole generation (see "
    "faraman_report_generation_duration_seconds for that).",
    # purpose: report_initial|report_deep
    # call: report_initial always has one attempt shape ("report"); report_deep has its
    #   eight named sub-calls (domain_<code>|topics_a|topics_b|closing, all code-defined
    #   constants, not user input)
    # provider: openai|avalai
    # outcome: ok|validation_error|error
    ["purpose", "call", "provider", "outcome"],
    buckets=_AI_CALL_BUCKETS,
)

# --- third-party delivery (Bale bot API, SMTP) --------------------------------------------

_DELIVERY_BUCKETS = (0.1, 0.25, 0.5, 1, 2, 5, 10, 20)

ALERT_DELIVERY_DURATION = Histogram(
    "faraman_alert_delivery_duration_seconds",
    "Wall time of one Bale Bot API sendMessage call (apps/alerting/services/bale_service.py), "
    "relaying a Grafana alert notification.",
    ["outcome"],  # outcome: ok|error
    buckets=_DELIVERY_BUCKETS,
)
REPORT_EMAIL_DELIVERY_DURATION = Histogram(
    "faraman_report_email_delivery_duration_seconds",
    "Wall time of one SMTP send (apps/report/services/email_service.py), emailing a "
    "completed report to the address the user typed into the report page's email card.",
    ["outcome"],  # outcome: ok|error
    buckets=_DELIVERY_BUCKETS,
)
REPORT_PDF_RENDER_DURATION = Histogram(
    "faraman_report_pdf_render_duration_seconds",
    "Wall time of one WeasyPrint HTML->PDF render (apps/report/services/pdf_service.py), "
    "building the PDF attachment for a report email. Runs synchronously in the request "
    "(no Celery), same as the SMTP send it precedes.",
    ["outcome"],  # outcome: ok|error
    buckets=_DELIVERY_BUCKETS,
)


def delivery_outcome(sent: bool) -> str:
    """`outcome=` for @observe on BaleService.send_message / EmailService.send_html -- both
    swallow their own exceptions and return bool rather than raising, so success/failure has
    to be read from the return value, same idea as report_generation_outcome."""
    return "ok" if sent else "error"


# --- per-user rate limits (rejections only -- the request never reaches any of the above) --

THROTTLE_REJECTED = Counter(
    "faraman_throttle_rejected_total",
    "A per-user rate limit rejected a request before it did any real work. See the "
    "'Counting convention' note above for why this one metric is a Counter, not a histogram.",
    # scope: otp_request|otp_verify_lockout|chat_message|report_email|assessment_attempt --
    # a closed set matching this codebase's existing throttle repositories, not free text.
    ["scope"],
)

# --- notification sending (incremented in the Celery worker) -----------------------------

_NOTIFICATION_BUCKETS = (0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10)

NOTIFICATION_SEND_DURATION = Histogram(
    "faraman_notification_send_duration_seconds",
    "Wall time of sending one due notification to all of a user's active push subscriptions.",
    # kind: reminder|followup
    # outcome: sent|no_subscriptions|all_tokens_invalid|send_error
    ["kind", "outcome"],
    buckets=_NOTIFICATION_BUCKETS,
)


def _resolve_labels(labels, args, kwargs):
    if labels is None:
        return {}
    if callable(labels):
        return dict(labels(*args, **kwargs))
    return dict(labels)


def observe(histogram, *, in_progress=None, labels=None, outcome=None):
    """Time a function and record the result on ``histogram`` (which must have an ``outcome``
    label plus whatever ``labels`` supplies).

    Parameters
    ----------
    histogram : prometheus_client.Histogram
    in_progress : prometheus_client.Gauge, optional
        Incremented for the duration of the call. Must carry the same non-``outcome`` labels.
    labels : dict | callable, optional
        The non-``outcome`` label values. A callable receives the wrapped call's
        ``*args, **kwargs`` (so a method can pull a label out of its own arguments) and is
        resolved once, at call entry.
    outcome : callable, optional
        ``fn(return_value) -> str``. Used by callers (e.g. the report services) that catch
        their own exceptions and still *return* a value describing what happened. When
        omitted: no exception -> ``"ok"``, exception -> ``"error"``. Ignored for generator
        functions, where the outcome comes from how iteration ended.

    Works on both plain functions and generator functions. For a generator the timing spans
    the *entire* iteration -- which, for a streamed HTTP response, runs after the view has
    already returned. ``GeneratorExit`` (client disconnect) is recorded as
    ``outcome="client_disconnect"`` and re-raised.
    """

    def decorator(fn):
        is_gen = inspect.isgeneratorfunction(fn)

        if is_gen:
            @functools.wraps(fn)
            def gen_wrapper(*args, **kwargs):
                resolved = _resolve_labels(labels, args, kwargs)
                status = "success"
                if in_progress is not None:
                    in_progress.labels(**resolved).inc()
                start = time.perf_counter()
                try:
                    yield from fn(*args, **kwargs)
                except GeneratorExit:
                    status = "client_disconnect"
                    raise
                except BaseException:
                    status = "error"
                    raise
                finally:
                    if in_progress is not None:
                        in_progress.labels(**resolved).dec()
                    histogram.labels(outcome=status, **resolved).observe(
                        time.perf_counter() - start
                    )

            return gen_wrapper

        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            resolved = _resolve_labels(labels, args, kwargs)
            status = "error"
            if in_progress is not None:
                in_progress.labels(**resolved).inc()
            start = time.perf_counter()
            try:
                result = fn(*args, **kwargs)
            except BaseException:
                status = "error"
                raise
            else:
                status = outcome(result) if outcome is not None else "ok"
                return result
            finally:
                if in_progress is not None:
                    in_progress.labels(**resolved).dec()
                histogram.labels(outcome=status, **resolved).observe(
                    time.perf_counter() - start
                )

        return wrapper

    return decorator


@contextmanager
def observe_block(histogram, **labels):
    """Time the ``with`` body and record it on ``histogram`` (labelled by ``**labels``),
    including when the body raises. For sub-phase timing inside an already-``observe``d
    function. Not wired to any call site yet -- kept as a ready-to-use building block.
    """
    start = time.perf_counter()
    try:
        yield
    finally:
        histogram.labels(**labels).observe(time.perf_counter() - start)
