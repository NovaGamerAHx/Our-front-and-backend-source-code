from django.test import SimpleTestCase

from apps.account.services.exceptions import OtpRequestThrottledException
from faraman_back.utils.exception_handler import app_exception_handler
from faraman_back.utils.responses import ApiResponse


class HealthCheckMiddlewareTest(SimpleTestCase):
    """faraman_back.middleware.HealthCheckMiddleware -- the liveness route used by the
    docker-compose healthcheck (see CLAUDE.md known issue #16)."""

    def test_returns_ok_with_trailing_slash(self):
        response = self.client.get("/health/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"status": "ok"})

    def test_returns_ok_without_trailing_slash(self):
        response = self.client.get("/health")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"status": "ok"})

    def test_bypasses_host_validation(self):
        # The healthcheck reaches the container by IP, so the Host header is never a
        # name in ALLOWED_HOSTS -- the middleware must answer before that check runs.
        response = self.client.get("/health/", HTTP_HOST="10.0.0.5:8000")
        self.assertEqual(response.status_code, 200)

    def test_does_not_shadow_other_paths(self):
        response = self.client.get("/health/nope/")
        self.assertEqual(response.status_code, 404)


class AppExceptionHandlerMessageKeyTest(SimpleTestCase):
    def test_app_exception_response_carries_message_key(self):
        response = app_exception_handler(OtpRequestThrottledException(), {})

        self.assertEqual(response.status_code, 429)
        self.assertEqual(response.data["message_key"], "otp_request_throttled")

    def test_success_response_has_no_message_key(self):
        self.assertNotIn("message_key", ApiResponse.success().data)
