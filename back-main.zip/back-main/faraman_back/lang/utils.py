from importlib import import_module

from faraman_back.lang import get_language


def get_from_source(source: dict, key: str, **kwargs):
    """
    General-purpose retriever for language resources (templates, prompts, etc.).
    """
    template = source.get(key)
    if not template:
        raise ValueError(f"No entry found for key '{key}'")

    if callable(template):
        template = template(**kwargs)

    if isinstance(template, str):
        try:
            return template.format(**kwargs)
        except KeyError as e:
            raise ValueError(f"Missing variable for key '{key}': {e}")

    raise TypeError(f"Invalid entry type for key '{key}': {type(template)}")


def get_message(key: str, **kwargs):
    lang_code = get_language()
    module = import_module(f"faraman_back.lang.{lang_code}.messages")
    return module.get_message(key, **kwargs)


def get_template(key: str, **kwargs):
    lang_code = get_language()
    module = import_module(f"faraman_back.lang.{lang_code}.templates")
    return module.get_template(key, **kwargs)


def get_prompt(key: str, **kwargs):
    lang_code = get_language()
    module = import_module(f"faraman_back.lang.{lang_code}.prompts")
    return module.get_prompt(key, **kwargs)


def get_prompt_prefix():
    lang_code = get_language()
    module = import_module(f"faraman_back.lang.{lang_code}.prompts")
    return module.get_prompt_prefix()
