ACTIVE_LANG = "fa"

def set_language(lang_code: str):
    global ACTIVE_LANG
    ACTIVE_LANG = lang_code

def get_language():
    return ACTIVE_LANG
