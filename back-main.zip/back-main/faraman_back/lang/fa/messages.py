from faraman_back.lang.utils import get_from_source

MESSAGES = {
    'success': 'عملیات موفقیت آمیز بود.',
    'system_error': 'خطای سیستمی رخ داده است.',
    'validation_error': 'فرمت داده های ارسالی صحیح نیست.',
    '404': 'یافت نشد.',

    'sms_sent': 'پیامک با موفقیت ارسال شد.',
    'sms_send_failed': 'ارسال پیامک با خطا مواجه شد. لطفا دقایقی دیگر تلاش کنید.',
    'sms_bulk_sent': 'پیامک‌ها با موفقیت ارسال شدند.',
    'sms_bulk_failed': 'ارسال پیامک گروهی با خطا مواجه شد.',

    'fetched_successfully': 'اطلاعات با موفقیت بازیابی شد.',
    'created_successfully': 'اطلاعات با موفقیت ذخیره شد.',
    'updated_successfully': 'اطلاعات با موفقیت به روزرسانی شد.',
    'deleted_successfully': 'عملیات حذف موفقیت آمیز بود.',

    'user_not_found': 'کاربر یافت نشد.',
    'invalid_code': 'کد وارد شده معتبر نمی باشد.',
    'otp_request_throttled': 'کد قبلی هنوز معتبر است. لطفا پس از پایان اعتبار آن دوباره تلاش کنید.',
    'invalid_token': 'نشست شما نامعتبر یا منقضی شده است. لطفا دوباره وارد شوید.',
    'successful_login': 'ورود موفقیت آمیز بود.',
    'logout_successfully': 'با موفقیت از سیستم خارج شدید. منتظر بازگشت دوباره شما هستیم.',
    'terms_accepted_successfully': 'قوانین و حریم خصوصی با موفقیت پذیرفته شد.',
    'account_deleted_successfully': 'حساب کاربری شما با موفقیت حذف شد.',

    'invalid_phone_number': 'شماره موبایل وارد شده معتبر نیست.',
    'invalid_otp_code': 'کد وارد شده باید ۵ رقم و فقط شامل عدد باشد.',
    'missing_fields': 'برخی از فیلدهای ضروری ارسال نشده‌اند.',

    'session_started_successfully': 'جلسه با موفقیت شروع شد.',
    'session_has_started_before': 'این جلسه قبلا شروع شده است.',
    'session_stopped_successfully': 'جلسه با موفقیت متوقف شد.',
    'need_to_purchase': 'موجودی زمان شما به پایان رسیده است، برای ادامه صحبت، زمان خریداری فرمایید.',

    'fail_to_start_paying': 'خطا در شروع فرآیند پرداخت',
    'fail_to_connect_to_payment_gateway': 'خطا در ارتباط با درگاه پرداخت',
    'invalid_cafebazar_token': 'توکن خرید نامعتبر یا تایید موفقیت‌آمیز نبود.',
    'product_not_found': 'محصول مورد نظر یافت نشد.',
    'payment_not_found': 'تراکنش مورد نظر یافت نشد.',
    'payment_cancelled': 'پرداخت لغو شد.',
    'payment_verification_failed': 'تایید پرداخت با خطا مواجه شد.',
    'assessment_already_purchased': 'شما قبلاً به این آزمون دسترسی دارید.',
    'purchase_required': 'برای شروع این آزمون ابتدا باید آن را خریداری کنید.',
    'invalid_coupon': 'این کد تخفیف معتبر نیست.',
    'payment_attempt_invalid': 'برای پرداخت باید یک آزمون تکمیل‌شده و در انتظار پرداخت مشخص شود.',

    'text_or_voice_is_required': 'پیام ارسال شده باید به شکل متن و یا صوت باشد.',
    'text_and_voice_are_duplicate': 'یکی از فرمت های ارسال پیام امکان پذیر است. لطفا یکی از فرمت های متن یا صوت را ارسال فرمایید.',
    'unsupported_audio_format': 'فرمت صوت ارسال شده صحیح نیست. باید به یکی از فرمت های MP3, WAV, M4A باشد.',
    'stt_error': 'خطای سیستمی در پردازش صوت رخ داده است. لطفا دقایقی دیگر این سرویس را استفاده نمایید.',
    'tts_error': 'خطای سیستمی در تبدیل متن به صوت رخ داده است. لطفا دقایقی دیگر این سرویس را استفاده نمایید.',

    'event_tracked': 'رویداد با موفقیت ثبت شد.',

    'assessment_not_found': 'آزمون مورد نظر یافت نشد.',
    'attempt_not_found': 'تلاش مورد نظر یافت نشد.',
    'attempt_access_denied': 'شما به این تلاش دسترسی ندارید.',
    'attempt_already_completed': 'این تلاش قبلا تکمیل یا متوقف شده است.',
    'attempt_incomplete': 'برای پایان دادن به تست باید به همه سؤالات پاسخ دهید.',
    'question_not_found': 'سوال مورد نظر یافت نشد.',
    'invalid_answer_value': 'مقدار پاسخ ارسال شده معتبر نیست.',
    'answer_not_found': 'پاسخی برای این سؤال ثبت نشده است.',
    'attempt_limit_exceeded': 'شما به سقف مجاز شروع این آزمون در این بازه زمانی رسیده‌اید. لطفا بعدا تلاش کنید.',
    'report_generation_in_progress': 'گزارش تلاش قبلی شما هنوز در حال ساخته شدن است. لطفا تا اتمام آن صبر کنید.',

    'report_not_found': 'گزارش مورد نظر یافت نشد.',
    'report_access_denied': 'شما به این گزارش دسترسی ندارید.',
    'report_generation_failed': 'مشکلی در ساخت گزارش پیش آمد. چند لحظه‌ی دیگر دوباره تلاش کن.',
    'report_not_ready': 'گزارش هنوز آماده نیست.',
    'report_retry_not_allowed': 'فقط گزارش‌هایی که با خطا مواجه شده‌اند قابل تلاش دوباره هستند.',
    'report_retry_started': 'در حال تلاش دوباره برای ساخت گزارش هستیم.',
    'report_score_out_of_range': 'خطایی در محاسبه‌ی نتایج آزمون رخ داد. لطفا با پشتیبانی تماس بگیرید.',
    'report_email_subject_initial': 'گزارش شخصیت‌شناسی شما در فرامن',
    'report_email_subject_deep': 'پروفایل توسعه فردی شما در فرامن',
    'report_email_sent': 'گزارش با موفقیت به ایمیل شما ارسال شد.',
    'report_email_send_failed': 'ارسال گزارش به ایمیل با خطا مواجه شد. لطفا دقایقی دیگر دوباره تلاش کنید.',
    'report_email_throttled': 'شما اخیرا این گزارش را ایمیل کرده‌اید. لطفا کمی بعد دوباره تلاش کنید.',
    'report_pdf_generation_failed': 'خطا در تولید فایل PDF گزارش. لطفاً دوباره تلاش کنید.',

    # Initial report's five Big Five dimensions -- used only when rendering the email template
    # (apps/report/services/email_service.py); the API response itself sends raw `key`s and
    # leaves translation to the frontend, same reasoning as the deep domain/facet titles below.
    'dimension_title_emotional_stability': 'ثبات هیجانی',
    'dimension_title_extraversion': 'برون‌گرایی',
    'dimension_title_openness': 'گشودگی',
    'dimension_title_agreeableness': 'توافق‌پذیری',
    'dimension_title_conscientiousness': 'وظیفه‌شناسی',

    # Score level labels, email template only. Initial reports use the 5-band scale
    # (scoring_service.LEVEL_BANDS); deep reports use the separate 3-band low/mid/high
    # vocabulary (deep_report_spec_v1_2.md §2.4) -- 'mid' is intentionally a distinct key from 'medium'.
    'score_level_very_low': 'خیلی پایین',
    'score_level_low': 'پایین',
    'score_level_medium': 'متوسط',
    'score_level_medium_high': 'نسبتاً بالا',
    'score_level_high': 'بالا',
    'score_level_mid': 'متوسط',

    # Initial report's life_pattern_cards keys (report_spec §schema.LifePatternKey), email
    # template only -- same reasoning as the dimension/score-level labels above.
    'life_pattern_title_decision_style': 'سبک تصمیم‌گیری',
    'life_pattern_title_relationship_style': 'سبک ارتباطی',
    'life_pattern_title_work_learning_style': 'سبک کار و یادگیری',
    'life_pattern_title_stress_energy_pattern': 'استرس و انرژی',

    # Deep report's six themed pages (deep_report_spec_v1_2.md §9 pages 11-16), email template only.
    'topic_page_title_decision_style': 'سبک تصمیم‌گیری',
    'topic_page_title_communication_style': 'سبک ارتباطی',
    'topic_page_title_work_style': 'سبک کاری و رهبری',
    'topic_page_title_stress_and_energy': 'استرس، انرژی و بازیابی',
    'topic_page_title_learning_and_growth': 'یادگیری و رشد',
    'topic_page_title_close_relationships': 'روابط نزدیک',

    # One-line lead under each themed page's title (same wording as the web report's
    # DEEP_TOPIC_LEADS in faraman-front lib/utils/deep-report.ts), email template only.
    'deep_topic_lead_decision_style': 'چطور بین گزینه‌ها انتخاب می‌کنی — از سرعت گرفته تا اینکه چقدر جا برای تجدیدنظر می‌گذاری.',
    'deep_topic_lead_communication_style': 'الگوی حضور تو در گفتگو — چیزهایی که دیگران احتمالاً از تعامل با تو تجربه می‌کنند.',
    'deep_topic_lead_work_style': 'ریتم کار و رهبری‌ات — از ساختار و نظم تا واگذاری و اعتماد به دیگران.',
    'deep_topic_lead_stress_and_energy': 'چه چیزی انرژی‌ات را می‌گیرد، از کجا دوباره پرش می‌کنی، و چطور از فشار برمی‌گردی.',
    'deep_topic_lead_learning_and_growth': 'شیوهٔ یادگیری‌ات — از پذیرش تجربهٔ تازه تا تبدیل آموخته‌ها به اقدام.',
    'deep_topic_lead_close_relationships': 'الگوی تو در نزدیک‌ترین رابطه‌هایت — نزدیکی، اعتماد و مرزبندی.',

    # Deep report (deep_report_spec_v1_2.md). The product name is fixed by §"سه محدودیت" rule 2: this is a
    # «پروفایل توسعه فردی», never a «نتیجه‌ی تست» and never a «تشخیص».
    'deep_report_title': 'پروفایل توسعه فردی',
    # §6.2: the two texts the AI never writes. Draft wording from the report template; final
    # wording is owned by the domain expert / legal (§11). Per §9 neither may be shrunk or faded.
    'deep_report_disclaimer': (
        'این گزارش یک ابزار توسعه فردی است و برای تشخیص اختلال روان‌شناختی، تصمیم درمانی '
        'یا تصمیم استخدامی معتبر نیست.'
    ),
    'deep_report_closing_reminder': (
        'این گزارش یک نقشه احتمالات رفتاری است، نه تعریف نهایی هویت شما.'
    ),

    # Domain titles (§9 page 3). Note N is emotional REACTIVITY, not stability.
    'deep_domain_title_n': 'واکنش‌پذیری هیجانی',
    'deep_domain_title_e': 'برون‌گرایی',
    'deep_domain_title_o': 'گشودگی',
    'deep_domain_title_a': 'توافق‌پذیری',
    'deep_domain_title_c': 'وظیفه‌شناسی',

    # Facet titles (scoring manual §6.2). §9: the user sees «اضطراب», never «N1» -- the codes
    # exist only inside the backend and the AI payload.
    'deep_facet_title_n1': 'اضطراب',
    'deep_facet_title_n2': 'خشم و تحریک‌پذیری',
    'deep_facet_title_n3': 'گرایش به دلسردی',
    'deep_facet_title_n4': 'حساسیت به قضاوت اجتماعی',
    'deep_facet_title_n5': 'تکانشگری',
    'deep_facet_title_n6': 'آسیب‌پذیری در برابر فشار',
    'deep_facet_title_e1': 'گرمی و صمیمیت',
    'deep_facet_title_e2': 'معاشرت‌جویی',
    'deep_facet_title_e3': 'ابراز وجود',
    'deep_facet_title_e4': 'سطح فعالیت',
    'deep_facet_title_e5': 'هیجان‌خواهی',
    'deep_facet_title_e6': 'هیجان‌های مثبت',
    'deep_facet_title_o1': 'تخیل',
    'deep_facet_title_o2': 'حساسیت زیبایی‌شناختی',
    'deep_facet_title_o3': 'گشودگی به احساسات',
    'deep_facet_title_o4': 'تنوع در تجربه',
    'deep_facet_title_o5': 'کنجکاوی فکری',
    'deep_facet_title_o6': 'انعطاف در باورها',
    'deep_facet_title_a1': 'اعتماد',
    'deep_facet_title_a2': 'صراحت',
    'deep_facet_title_a3': 'نوع‌دوستی',
    'deep_facet_title_a4': 'سبک مواجهه با تعارض',
    'deep_facet_title_a5': 'فروتنی',
    'deep_facet_title_a6': 'حساسیت انسانی',
    'deep_facet_title_c1': 'احساس کفایت',
    'deep_facet_title_c2': 'نظم',
    'deep_facet_title_c3': 'تعهد و وظیفه‌شناسی',
    'deep_facet_title_c4': 'پیشرفت‌طلبی',
    'deep_facet_title_c5': 'خودانضباطی',
    'deep_facet_title_c6': 'سنجیدگی',

    # Section interstitials for the 150-item form (6 blocks of 25). Placeholder copy.
    'deep_section_title': 'بخش {number}',
    'deep_section_interstitial': 'بخش {done} از {total} تمام شد. ادامه بده.',

    'feedback_submitted': 'بازخورد شما با موفقیت ثبت شد.',
    'feedback_target_not_found': 'مورد مورد نظر برای ثبت بازخورد یافت نشد.',
    'feedback_target_access_denied': 'شما اجازه ثبت بازخورد برای این مورد را ندارید.',

    'chat_session_not_found': 'گفتگوی مورد نظر یافت نشد.',
    'chat_invalid_entry_source': 'ورودی نامعتبر است.',
    'chat_report_required_for_entry_source': 'برای این نوع گفتگو، گزارش مربوطه ارسال نشده است.',
    'chat_report_type_mismatch': 'گزارشِ این آزمون با نوعِ این گفتگو سازگار نیست.',
    'chat_report_version_mismatch': 'این گزارش سؤال بازی برای گفتگو ندارد.',
    'chat_action_required_for_entry_source': 'برای این نوع گفتگو، قدمِ مربوطه ارسال نشده است.',
    'chat_action_step_not_missed': 'این قدم در وضعیت «انجام‌نشده» نیست.',
    'chat_action_step_not_active': 'این قدم در وضعیتِ «در انتظار» نیست.',
    'chat_message_too_long': 'پیام ارسالی بیش از حد مجاز طولانی است.',
    'chat_proposed_action_unavailable': 'قدمِ پیشنهادی برای این پیام در دسترس نیست یا قبلاً پذیرفته شده است.',
    'chat_generation_failed': 'الان کمی شلوغ است. چند لحظه‌ی دیگر دوباره بفرست.',
    'chat_message_not_found': 'پیام مورد نظر یافت نشد.',
    'chat_regenerate_not_allowed': 'فقط می‌توانید پاسخِ آخرِ گفتگو را دوباره بسازید.',
    'chat_message_limit_exceeded': 'به سقفِ روزانه‌ی ارسالِ پیام در گفتگو رسیده‌اید. فردا دوباره تلاش کنید.',

    'message_bookmarked': 'پیام بوکمارک شد.',
    'message_bookmark_removed': 'بوکمارک پیام حذف شد.',
    'message_feedback_removed': 'بازخورد شما حذف شد.',

    'push_subscription_registered': 'اعلان‌ها با موفقیت فعال شد.',
    'push_subscription_removed': 'اعلان‌ها غیرفعال شد.',

    'action_step_not_found': 'قدم مورد نظر یافت نشد.',
    'action_step_access_denied': 'شما به این قدم دسترسی ندارید.',
    'action_step_invalid_source': 'مبدأ قدم نامعتبر است.',
    'action_step_not_pending': 'برای این قدم قبلاً پاسخ ثبت شده یا مهلت آن به پایان رسیده است.',
    'action_step_not_done': 'ثبت بازتاب فقط برای قدم‌های انجام‌شده ممکن است.',
    'action_step_obstacle_required': 'مقدار obstacle برای این نتیجه نامعتبر است.',
    'action_step_reactivate_requires_not_done': 'فقط قدم‌های انجام‌نشده را می‌توان دوباره فعال کرد.',
    'suggested_step_not_found': 'قدمِ پیشنهادی مورد نظر یافت نشد.',

    'grafana_alert_delivered': 'هشدار با موفقیت به بله ارسال شد.',
    'grafana_alert_delivery_failed': 'ارسال هشدار به بله با خطا مواجه شد.',
    'grafana_webhook_unauthorized': 'دسترسی به این webhook مجاز نیست.',
}


def get_message(key: str, **kwargs):
    return get_from_source(MESSAGES, key, **kwargs)
