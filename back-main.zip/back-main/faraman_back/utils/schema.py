from collections import defaultdict

from drf_spectacular.types import OpenApiTypes
from drf_spectacular.utils import OpenApiExample, OpenApiResponse

from faraman_back.utils.exceptions import AppException


def error_responses(*exception_classes: type[AppException]) -> dict:
    """Build drf-spectacular responses (grouped by status code) from AppException subclasses."""
    grouped = defaultdict(list)
    for exception_class in exception_classes:
        instance = exception_class()
        grouped[instance.status_code].append(instance)

    return {
        status_code: OpenApiResponse(
            response=OpenApiTypes.OBJECT,
            description="Error",
            examples=[
                OpenApiExample(
                    name=exception.__class__.__name__,
                    value={'code': exception.code, 'message': exception.message, 'data': None},
                )
                for exception in exceptions
            ],
        )
        for status_code, exceptions in grouped.items()
    }
