from rest_framework.views import exception_handler as drf_exception_handler

from faraman_back.utils.exceptions import AppException
from faraman_back.utils.responses import ApiResponse


def app_exception_handler(exc, context):
    if isinstance(exc, AppException):
        return ApiResponse.error(
            message=exc.message, status_code=exc.status_code, code=exc.code, message_key=exc.message_key
        )

    return drf_exception_handler(exc, context)
