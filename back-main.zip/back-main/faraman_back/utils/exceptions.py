from rest_framework import status

from faraman_back.lang.utils import get_message


class AppException(Exception):
    """Base for exceptions that should be turned into an ApiResponse by app_exception_handler."""

    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    code = 0
    message_key = 'system_error'

    def __init__(self, detail: str = None, *, message_key: str = None, **format_kwargs):
        self.message_key = message_key or self.message_key
        self.format_kwargs = format_kwargs
        super().__init__(detail or self.message_key)

    @property
    def message(self) -> str:
        return get_message(self.message_key, **self.format_kwargs)
