from rest_framework.response import Response
from rest_framework import status

from faraman_back.lang.utils import get_message


class ApiResponse(Response):
    def __init__(self, data=None, message='', code=1, status_code=status.HTTP_200_OK, message_key=None, **kwargs):
        response_data = {
            'code': code,
            'message': message,
            'data': data
        }
        if message_key:
            # Stable machine-readable error identifier, so clients can branch on the cause
            # without parsing the localized `message`.
            response_data['message_key'] = message_key
        super().__init__(response_data, status=status_code, **kwargs)

    @classmethod
    def success(cls, data=None, message=get_message('success'), status_code=status.HTTP_200_OK):
        return cls(data=data, message=message, code=1, status_code=status_code)

    @classmethod
    def error(
        cls,
        message=get_message('system_error'),
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        code=0,
        message_key=None,
    ):
        return cls(message=message, code=code, status_code=status_code, message_key=message_key)

    @classmethod
    def validation_error(cls, data=None, message=get_message('validation_error')):
        return cls(data=data, message=message, code=0, status_code=status.HTTP_406_NOT_ACCEPTABLE)

    @classmethod
    def error_404(cls):
        return cls(message=get_message('404'), code=0, status_code=status.HTTP_404_NOT_FOUND)
