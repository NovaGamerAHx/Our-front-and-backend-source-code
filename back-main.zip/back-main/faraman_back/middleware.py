import uuid

from django.conf import settings
from django.http import JsonResponse

ANONYMOUS_ID_COOKIE_NAME = "anonymous_id"
ANONYMOUS_ID_COOKIE_MAX_AGE = 60 * 60 * 24 * 365 * 2  # 2 years

HEALTH_CHECK_PATHS = frozenset({"/health", "/health/"})


class HealthCheckMiddleware:
    """Liveness probe, answered before host validation / auth / metrics.

    Registered as the first entry in ``MIDDLEWARE`` so a ``GET /health/`` is
    served even when the request's ``Host`` header isn't in ``ALLOWED_HOSTS``
    (the docker-compose healthcheck and any future load balancer reach the
    container by IP), and without adding a tick to django-prometheus's request
    histogram every few seconds.

    Deliberately dependency-free: it reports only that *this gunicorn worker* is
    up and processing requests. It must not touch Postgres or Redis -- a
    container healthcheck that flipped to unhealthy on a transient DB blip would
    pull every ``web`` replica out of rotation at once, turning a recoverable
    hiccup into an outage (see CLAUDE.md known issue #19's passive-failover
    note). A readiness check that does probe dependencies can be added later for
    an orchestrator that knows to treat it as such.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.path in HEALTH_CHECK_PATHS:
            return JsonResponse({"status": "ok"})
        return self.get_response(request)


class AnonymousIdMiddleware:
    """Ensures every request carries a stable anonymous_id, issued by the backend as a cookie."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        anonymous_id = request.COOKIES.get(ANONYMOUS_ID_COOKIE_NAME)
        is_new = not anonymous_id
        if is_new:
            anonymous_id = uuid.uuid4().hex
        request.anonymous_id = anonymous_id

        response = self.get_response(request)

        if is_new:
            response.set_cookie(
                ANONYMOUS_ID_COOKIE_NAME,
                anonymous_id,
                max_age=ANONYMOUS_ID_COOKIE_MAX_AGE,
                httponly=True,
                secure=not settings.DEBUG,
                samesite="Lax",
            )

        return response
