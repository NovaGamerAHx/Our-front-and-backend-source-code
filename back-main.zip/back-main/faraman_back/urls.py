"""
URL configuration for faraman_back project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path, include
from drf_spectacular.views import SpectacularAPIView, SpectacularRedocView, SpectacularSwaggerView

urlpatterns = [
    path("admin/", admin.site.urls),
    path('', include('django_prometheus.urls')),
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),
    path('api/docs/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),
    path('api/redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),

    path(f"api/account/", include("apps.account.urls")),
    path("api/events/", include("apps.events.urls")),
    path("api/assessments/", include("apps.assessment.urls")),
    path("api/reports/", include("apps.report.urls")),
    path("api/feedback/", include("apps.feedback.urls")),
    path("api/chat/", include("apps.chat.urls")),
    path("api/messages/", include("apps.chat.message_urls")),
    path("api/notifications/", include("apps.notifications.urls")),
    path("api/payment/", include("apps.payment.urls")),
    path("api/", include("apps.payment.entitlement_urls")),
    path("api/action-steps/", include("apps.action_steps.urls")),
    path("api/alerting/", include("apps.alerting.urls")),
]
