# backend-Django
Faraman Backend: AI therapist support stack. Real-time convo orchestration, user sessions, and safety enforcements. API layer, model abstraction, and data management. Auth, observability, and CI/CD. Focus on privacy, crisis-safe workflows, and modular integration with AI providers.
