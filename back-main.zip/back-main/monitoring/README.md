# Monitoring stack

Grafana + Prometheus + Loki + Promtail, in a separate compose file from the main app
(`docker-compose.yml`) so it can be deployed and restarted independently. See
`.gitlab-ci.yml`'s `monitoring` stage: it only runs on pushes to `main` that touch this
folder.

## What's here

- **Prometheus** — scrapes host metrics (`node-exporter`), Postgres
  (`postgres-exporter`), Redis (`redis-exporter`), Celery (`celery-exporter`), Django on
  both replicas (`web:8000/metrics` + `web2:8000/metrics`, via `django-prometheus`), and
  the Celery workers' own app-metrics endpoint (`celery:9809/metrics` + `celery2:9809`).
  Config: `prometheus/prometheus.yml`. Per-container metrics (`cadvisor`) are commented out
  for now — see "Images" below.
- **Application metrics** — `faraman_back/observability/` emits `faraman_report_generation_*`
  (from the Celery workers) and `faraman_chat_answer_*` incl. time-to-first-token (from the
  web tier). `prometheus_client` runs in multiprocess mode (`PROMETHEUS_MULTIPROC_DIR` on
  `web`/`web2`/`celery`/`celery2` in the app's `docker-compose.yml`) so the per-worker
  registries aggregate at scrape time. See CLAUDE.md "Application metrics". Build a Grafana
  dashboard in the UI (nothing vendored, same policy as the Celery ones).
- **Celery** — `celery-exporter` (danihodovic/celery-exporter) connects to the Redis
  broker, listens to the Celery task-event stream, and exposes `celery_queue_length`,
  per-task `celery_task_{started,succeeded,failed,retried}_total`, runtime histograms and
  `celery_worker_up` on `:9808`. Needs `CELERY_WORKER_SEND_TASK_EVENTS` +
  `CELERY_TASK_SEND_SENT_EVENT` in `faraman_back/settings.py` (both set). For dashboards,
  import grafana.com IDs **17509** ("Celery / Tasks / Overview" — queue length + fleet-wide
  task rates) and **17508** ("Celery / Tasks / By Task") — see Grafana below.
- **Loki + Promtail** — Promtail discovers every container on the host via the Docker
  socket and ships its logs to Loki. No app-side log shipping config needed; anything a
  container writes to stdout/stderr (which is everything in this project — see
  `faraman_back/settings.py`'s `LOGGING`) shows up in Grafana's Explore view labeled by
  `compose_service`. Config: `promtail/promtail-config.yml`, `loki/loki-config.yml`.
- **Grafana** — served at `https://$GRAFANA_DOMAIN` (default `grafana.faraman.ai`) through delyar-front's nginx-proxy only (no published host port), own admin login (`GRAFANA_ADMIN_USER` /
  `GRAFANA_ADMIN_PASSWORD` in `.env`). Prometheus and Loki datasources are
  auto-provisioned (`grafana/provisioning/datasources`). No dashboard JSON is vendored in
  this repo (`grafana/dashboards/*.json` is git-ignored) — the `dashboards.yml` provider
  still auto-loads any JSON present in `grafana/dashboards/` on the host, so the workflow
  is: **Dashboards → New → Import**, entering a grafana.com ID (17509 / 17508 for Celery,
  see above) or searching by name for the host side ("Node Exporter Full", "PostgreSQL",
  "Redis"). Anything you then save through the UI is written to `grafana/dashboards/` on
  the host and reloaded on the next container start — it just isn't committed back here.
  The Celery dashboards bind to the default Prometheus datasource; the mixin's `cluster` /
  `namespace` template vars resolve to empty and match our unlabelled series fine.
- **Alerting → Bale messenger** — Grafana has no built-in Bale contact point, so
  `grafana/provisioning/alerting/contactpoints.yml` provisions a generic **webhook** contact
  point (`bale`) pointing at `GrafanaWebhookAPIView` (`apps/alerting/` in the main app), which
  relays to Bale's Bot API. This is why `grafana` also joins the `app` network below — the
  webhook URL is the internal `http://web:8000/...` address, not a public one through nginx.
  The shared secret (`GRAFANA_WEBHOOK_SECRET`) is embedded in that URL and expanded from the
  `grafana` container's own environment (its `GRAFANA_WEBHOOK_SECRET` env var, set from the
  root `.env`) — see CLAUDE.md "Grafana alerting" for the full design and how to point an
  alert rule's notification policy at this contact point.

## Images

All images here are Docker Hub-hosted and pulled via ArvanCloud's mirror
(`docker.arvancloud.ir/<image>`) -- same reason as the root `Dockerfile`: this server's
IP gets a 403 from `registry-1.docker.io` directly.

`cadvisor` is commented out in `docker-compose.yml` (and its scrape job in
`prometheus/prometheus.yml`) because it's only published on `gcr.io` (now
`ghcr.io/google/cadvisor` after Google shut down GCR in 2025), neither of which is
reachable from here, and ArvanCloud only mirrors Docker Hub. `node-exporter` still
covers host-level CPU/memory/disk/network. To bring per-container metrics back later,
either try `ghcr.io/google/cadvisor` directly (untested from this server) or route
through a community Docker Hub re-upload via the Arvan mirror -- the latter means
trusting a third-party rebuild of the image, not Google's own, so weigh that before
using it in production.

## Networking

The main `docker-compose.yml` puts all app services on a network explicitly named
`faraman_net` (see its `networks:` block). This compose file joins that network as
`external: true` so `postgres-exporter`/`redis-exporter`/`prometheus` can reach
`db`/`redis`/`web` by service name -- and now `grafana` too, so its Bale contact point can
reach `web:8000` (see "Alerting → Bale messenger" above). Everything else (Loki, Promtail,
node-exporter, cadvisor) only needs the internal `monitoring` network.

## Metabase (product dashboards)

Business/product dashboards (users, attempts, reports, payments), next to Grafana's ops metrics.

- **URL:** `https://$METABASE_DOMAIN` (default `metabase.faraman.ai`) via delyar-front's
  nginx-proxy (TLS from acme-companion) only -- no published host port. The data includes phone numbers,
  so enable Metabase's admin 2FA and never leave the setup wizard unfinished on a public URL.
- **Its own state is in Postgres**, not H2: database `metabase`, role `METABASE_DB_USER` (default `metabase`), on the real
  `postgres` service (not pgbouncer/`db`). Dashboards survive container recreation.
- **Read-only data access:** Metabase reads the product DB as `METABASE_RO_USER` (default `metabase_ro`; SELECT only,
  `default_transaction_read_only=on`, 30s `statement_timeout`; no access to token/session/push
  tables). Never give Metabase the app's `DB_USERNAME`.

One-time setup (before the first `make monitoring-up` that starts Metabase):

1. Set `METABASE_DB_USER`, `METABASE_DB_PASSWORD`, `METABASE_RO_USER` and `METABASE_RO_PASSWORD` in `.env` (and as GitLab CI/CD
   variables -- `render_env.sh` writes an empty line otherwise, and compose refuses to start).
2. `make metabase-init-db` (idempotent; creates both roles + the `metabase` DB).
3. `make monitoring-up`, open the tunnel, finish the setup wizard (skip its "add your data" step).
4. Admin -> Databases -> Add: PostgreSQL, host `postgres`, port `5432`, database = `DB_NAME`,
   user `METABASE_RO_USER`, password `METABASE_RO_PASSWORD`. Set the connection pool small (~5).
5. In Admin -> Table Metadata, hide `users.phone_number` and chat message content unless needed
   (the DB role can still read them; hiding is a Metabase-level control only).

New tables from migrations are readable automatically (`ALTER DEFAULT PRIVILEGES`).

## Public domains (Grafana, Metabase)

Both join delyar-front's `delyar-front_default` network (`proxy`, `external: true`) and carry
`VIRTUAL_HOST`/`VIRTUAL_PORT`/`LETSENCRYPT_HOST`, exactly like `api.faraman.ai` in the root
compose file. DNS: one A record per domain pointing at the server's IP (the same one
`faraman.ai`/`api.faraman.ai` use) must exist *before* deploy, or acme-companion's cert issuance
fails. Override the names with `GRAFANA_DOMAIN`/`METABASE_DOMAIN`. Prometheus (`9090`) is not
proxied.

## Running it

```
make monitoring-up      # start the stack
make monitoring-reload  # reload Prometheus after editing prometheus.yml
make monitoring-logs    # tail logs
make monitoring-down    # stop it
```

These wrap `docker compose --env-file .env -f monitoring/docker-compose.yml ...` — run
from the repo root so the `--env-file` points at the root `.env` (needed for
`DB_PASSWORD`, `REDIS_PASSWORD`, `GRAFANA_ADMIN_PASSWORD`, etc. to interpolate into this
compose file). The main app stack (`db`, `redis`, `web`) must already be up first.

**Editing `prometheus/prometheus.yml`:** `make monitoring-up` (and the `monitoring` CI
stage) will **not** recreate the container for a contents-only change — `docker compose up
-d` only recreates on image/env/command/mounts changes. Run `make monitoring-reload` after
(the CI stage does this automatically); it POSTs to Prometheus's `/-/reload`
(`--web.enable-lifecycle` in the compose command), falling back to `up -d --force-recreate
prometheus` if the endpoint is unreachable.

The config dirs (`prometheus/`, `loki/`, `promtail/`) are mounted as **directories**, not
single files. A single-file bind mount pins the file's inode at container-create time, and
`git checkout` on the CI runner replaces the file with a *new* inode — so the running
container (and `/-/reload`) would keep reading the stale one even though the host file
changed. A directory mount resolves the filename on each read, so the reload actually
works. Loki and Promtail have no reload endpoint wired — `docker compose ... restart
loki` / `restart promtail` after editing their configs (the directory mount makes that
re-read the new file).

## One-time setup on the GitLab side

`GRAFANA_ADMIN_USER` / `GRAFANA_ADMIN_PASSWORD` follow the same pattern as every other
secret here (see `scripts/render_env.sh`): add them as CI/CD variables in
**Settings → CI/CD → Variables** on the project — they're already listed in
`.env.example` so `render_env.sh` will pick them up automatically.

## Retention

- Prometheus: 15 days (`--storage.tsdb.retention.time` in `docker-compose.yml`)
- Loki: 7 days (`limits_config.retention_period` in `loki/loki-config.yml`)

Adjust either if you need longer history — check available disk on the production host
first, since both are backed by local docker volumes.
