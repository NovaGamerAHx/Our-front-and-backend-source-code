-- One-off, idempotent bootstrap for Metabase. Run via `make metabase-init-db` (passwords come
-- from .env as psql variables, never from this file). Postgres init scripts only fire on an
-- empty data dir, and prod's is not empty, so this is run by hand before Metabase first starts.
--
-- Variables: app_user/app_pass (Metabase's own DB owner), ro_user/ro_pass (read-only data role),
-- app_db (the Django DB), app_owner (the role Django migrates as).

-- Metabase's own application DB (dashboards, questions) -- owner `metabase`.
SELECT format('CREATE ROLE %I LOGIN PASSWORD %L', :'app_user', :'app_pass')
 WHERE NOT EXISTS (SELECT FROM pg_roles WHERE rolname = :'app_user') \gexec
SELECT format('ALTER ROLE %I PASSWORD %L', :'app_user', :'app_pass') \gexec
SELECT format('CREATE DATABASE metabase OWNER %I', :'app_user')
 WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'metabase') \gexec
REVOKE ALL ON DATABASE metabase FROM PUBLIC;

-- Read-only role used as Metabase's *data source* for the product DB.
SELECT format('CREATE ROLE %I LOGIN PASSWORD %L NOSUPERUSER NOCREATEDB NOCREATEROLE', :'ro_user', :'ro_pass')
 WHERE NOT EXISTS (SELECT FROM pg_roles WHERE rolname = :'ro_user') \gexec
SELECT format('ALTER ROLE %I PASSWORD %L', :'ro_user', :'ro_pass') \gexec
ALTER ROLE :"ro_user" SET default_transaction_read_only = on;
ALTER ROLE :"ro_user" SET statement_timeout = '30s';
REVOKE ALL ON DATABASE metabase FROM :"ro_user";

\connect :app_db

REVOKE ALL ON DATABASE :"app_db" FROM :"ro_user";
GRANT CONNECT ON DATABASE :"app_db" TO :"ro_user";
GRANT USAGE ON SCHEMA public TO :"ro_user";
GRANT SELECT ON ALL TABLES IN SCHEMA public TO :"ro_user";
-- Tables created by future migrations (run as app_owner) are readable too.
ALTER DEFAULT PRIVILEGES FOR ROLE :"app_owner" IN SCHEMA public GRANT SELECT ON TABLES TO :"ro_user";

-- Credentials/secrets that have no analytics value: keep them out of reach entirely.
-- (Guarded: a table that doesn't exist yet in this environment is skipped, not an error.)
-- psql doesn't interpolate inside $$ quoting, so hand the role name over as a session setting.
SELECT set_config('mb.ro_user', :'ro_user', false);
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'token_blacklist_outstandingtoken', 'token_blacklist_blacklistedtoken',
    'push_subscriptions', 'django_session', 'django_admin_log'
  ] LOOP
    IF to_regclass('public.' || t) IS NOT NULL THEN
      EXECUTE format('REVOKE ALL ON public.%I FROM %I', t, current_setting('mb.ro_user'));
    END IF;
  END LOOP;
END $$;
