# Database Design for the Self-Knowledge Companion Pivot

## 1. Where you are vs. where the roadmap goes

Your current schema is built for one loop: *pay for minutes → chat*. The roadmap replaces that with two new loops:

- **Phase 1:** anonymous test → Profile Lite → free report → recommendations → action preview → scoped chat → paid deep test/report.
- **Phase 2:** check-in → active goal → daily question / instant help / guided session / journal → streaks → weekly report → reminders.

Almost every Phase 1/2 card needs a table that doesn't exist yet. The good news: your `User`, `Session`, and `Transaction` foundations survive — they just need to be *extended*, not rewritten.

Five cross-cutting design decisions drive everything below:

1. **Anonymous-first identity.** The test starts without signup ("دریافت Lead و ساخت حساب کاربری سبک"), so pre-auth activity must be keyed by an `anon_id` (UUID cookie/device id) and later attached to a `User` at lead capture. Don't make `user` NOT NULL on assessment tables.
2. **Versioned, JSON-flexible profile.** Profile Lite's fields are explicitly "قابل تحقیق و تغییر" (subject to research and change). Store trait payloads in `JSONField`, but keep the *identity and lineage* (which attempt produced which profile version) relational. Never mutate a profile in place — write a new version so reports stay reproducible.
3. **Messages need identity.** Message actions (like/dislike/save/report/delete) and bookmarks require per-message references. Either bring messages into Postgres or keep Mongo for content and store `mongo_message_id` + a **content snapshot** in the action/bookmark rows so nothing dangles.
4. **Separate payment from entitlement.** Today `Transaction` hard-codes minutes. Phase 1 sells a *product* (deep test + report); later you may sell subscriptions. Introduce `Product` and `Purchase` (entitlement) and let `Transaction` be purely a payment record.
5. **Stop CASCADE-deleting money and consent.** "کنترل کاربر روی داده" promises account deletion — but transactions are accounting records and consent logs are legal records. Use `on_delete=PROTECT` there and soft-delete/anonymize users instead of hard delete.

---

## 2. Proposed app & entity map

```
accounts    User (extended) · UserSettings · ConsentLog · Lead(optional)
assessment  Assessment · AssessmentSection · Question · Attempt · Answer
profiles    ProfileVersion (Profile Lite / Deep) · CompanionStyleFeedback
reports     Report · Recommendation · ActionStep · ShareCard
chat        Session (extended) · MessageAction · SavedItem
growth      Goal · CheckIn · PromptTemplate · PromptResponse
            GuidedSessionTemplate · GuidedSessionRun
            JournalTemplate · JournalEntry
            Streak · Badge · UserBadge · WeeklyReport
notify      NotificationTemplate · Notification · NotificationPreference
wallet      Transaction (kept) · Product · Purchase · DiscountCode
analytics   Event (append-only funnel events)
```

Relationship overview (★ = new):

```
anon_id ─┐
User ────┼──< Attempt ──< Answer                (assessment) ★
  │      └──< Event                              (analytics)  ★
  ├──< ProfileVersion ──< Report ──< Recommendation ──< ActionStep ★
  ├──< Session ──< ChatHistory (kept)
  │        └──< MessageAction / SavedItem ★
  ├──< Goal ──< CheckIn ──< PromptResponse ★
  ├──< GuidedSessionRun / JournalEntry / Streak / UserBadge / WeeklyReport ★
  ├──< Notification  +  1:1 NotificationPreference ★
  ├──< Transaction (kept) ──1:1── Purchase >── Product ★
  ├──< Feedback (generalized)
  └──1:1 UserSettings ★
```

---

## 3. accounts — extend, don't bloat

`User` already carries auth + profile + wallet + referral. Don't add more columns for every new feature; split concerns:

```python
class User(AbstractBaseUser, PermissionsMixin):
    # ... existing fields ...
    is_lead = models.BooleanField(default=False)   # light account from lead capture
    deleted_at = models.DateTimeField(null=True, blank=True)  # soft delete
    # DEPRECATE gradually: disorder (clinical framing conflicts with the
    # roadmap's explicit "no diagnostic language" rule), free_chat_used,
    # available_minutes (move to entitlements once Purchase ships)

class UserSettings(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="settings")
    companion_style = models.CharField(  # عمل‌گرا / حمایتی / تحلیلی / چالشی
        max_length=20,
        choices=[("action", "Action-oriented"), ("supportive", "Supportive"),
                 ("analytical", "Analytical"), ("coach", "Challenging/Coach")],
        null=True, blank=True)
    voice_enabled = models.BooleanField(default=True)
    preferred_reminder_time = models.TimeField(null=True, blank=True)
    timezone = models.CharField(max_length=50, default="Asia/Tehran")

class ConsentLog(models.Model):
    """Legal record: ToS/privacy acceptance, messaging opt-in, voice consent."""
    user = models.ForeignKey(User, on_delete=models.PROTECT, related_name="consents")
    kind = models.CharField(max_length=30)      # tos, privacy, messaging, voice
    version = models.CharField(max_length=20)   # policy version accepted
    granted = models.BooleanField()
    created_at = models.DateTimeField(auto_now_add=True)
```

**Lead capture flow:** the test runs against `anon_id` only. When the user gives a phone number to unlock/save the report, create the `User` (your phone-as-username model already fits perfectly), set `is_lead=True`, and run an *attach* step: `Attempt.objects.filter(anon_id=X, user__isnull=True).update(user=new_user)` — same for `Event` rows. No separate `Lead` table needed unless you want to capture email-only leads without creating a `User`.

**Referral cleanup (low priority):** `recommender`/`used_reference_code` are strings pointing at other users' codes. When convenient, replace with `referred_by = FK('self', null=True)` for real join-ability.

---

## 4. assessment — the Phase 1 core

Cards covered: تست اولیه ۱۸–۲۴ سؤالی, Gamified Assessment Flow, Paywall تست تکمیلی.

Model the test as **data, not code** — the roadmap says questions will iterate (IPIP/HEXACO-inspired items), and the paid supplementary test is just another `Assessment` row.

```python
class Assessment(models.Model):
    slug = models.SlugField(unique=True)          # "initial-v1", "deep-v1"
    title = models.CharField(max_length=200)
    kind = models.CharField(max_length=20,
        choices=[("initial", "Initial"), ("supplementary", "Supplementary")])
    version = models.PositiveIntegerField(default=1)
    is_active = models.BooleanField(default=True)
    requires_purchase = models.BooleanField(default=False)  # paywall flag

class AssessmentSection(models.Model):
    """Gamified flow: سبک فکر کردن، سبک تصمیم‌گیری، دغدغه فعلی، ..."""
    assessment = models.ForeignKey(Assessment, on_delete=models.CASCADE, related_name="sections")
    title = models.CharField(max_length=200)
    order = models.PositiveSmallIntegerField()
    interstitial_message = models.TextField(blank=True)  # «بخش اول کامل شد...»
    class Meta:
        unique_together = [("assessment", "order")]

class Question(models.Model):
    section = models.ForeignKey(AssessmentSection, on_delete=models.CASCADE, related_name="questions")
    order = models.PositiveSmallIntegerField()
    text = models.TextField()
    question_type = models.CharField(max_length=20,
        choices=[("likert", "Likert"), ("single", "Single choice"),
                 ("multi", "Multi choice"), ("text", "Free text")])
    options = models.JSONField(default=list)     # [{value, label, weight...}]
    scoring = models.JSONField(default=dict)     # trait weights — iterate freely
    is_active = models.BooleanField(default=True)

class Attempt(models.Model):
    class Status(models.TextChoices):
        IN_PROGRESS = "in_progress"; COMPLETED = "completed"; ABANDONED = "abandoned"
    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
                             on_delete=models.SET_NULL, related_name="attempts")
    anon_id = models.UUIDField(null=True, blank=True, db_index=True)  # pre-signup key
    assessment = models.ForeignKey(Assessment, on_delete=models.PROTECT)
    status = models.CharField(max_length=15, choices=Status.choices, default=Status.IN_PROGRESS)
    current_section = models.ForeignKey(AssessmentSection, null=True, blank=True,
                                        on_delete=models.SET_NULL)
    started_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    source = models.JSONField(default=dict)      # utm / landing variant
    class Meta:
        indexes = [models.Index(fields=["anon_id"]), models.Index(fields=["user", "status"])]

class Answer(models.Model):
    attempt = models.ForeignKey(Attempt, on_delete=models.CASCADE, related_name="answers")
    question = models.ForeignKey(Question, on_delete=models.PROTECT)
    value = models.JSONField()                   # scalar, list, or text
    answered_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        unique_together = [("attempt", "question")]
```

Why this shape:

- **Per-section drop-off** for the funnel dashboard ("نرخ رهاکردن تست در هر بخش") falls out of `Attempt.current_section` + `Answer` timestamps for free.
- **Resume half-finished tests** (a Phase 1 notification trigger) = `status="in_progress"` + `current_section`.
- **Paywall** = `requires_purchase=True` on the supplementary assessment; access check goes through `Purchase` (§9).
- `question` uses `PROTECT` and an `is_active` flag instead of deleting questions — old attempts must remain scoreable.

---

## 5. profiles — versioned Profile Lite

Cards covered: ساخت Profile Lite, حافظه اولیه کاربر, تکمیل سبک‌های همراه.

```python
class ProfileVersion(models.Model):
    class Depth(models.TextChoices):
        LITE = "lite"; DEEP = "deep"   # deep = after supplementary test
    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
                             on_delete=models.CASCADE, related_name="profile_versions")
    anon_id = models.UUIDField(null=True, blank=True, db_index=True)
    source_attempt = models.ForeignKey("assessment.Attempt", on_delete=models.PROTECT)
    depth = models.CharField(max_length=10, choices=Depth.choices, default=Depth.LITE)
    version = models.PositiveIntegerField(default=1)
    is_current = models.BooleanField(default=True)
    traits = models.JSONField(default=dict)
    # traits keys (from the card, deliberately schemaless while you iterate):
    #   dominant_pattern, current_concern, decision_style, action_style,
    #   growth_blocker, main_strength, blind_spot, suggested_path,
    #   confidence_level (low/medium/high), dimension_scores {…} for deep
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        constraints = [models.UniqueConstraint(
            fields=["user"], condition=models.Q(is_current=True, user__isnull=False),
            name="one_current_profile_per_user")]
```

The `traits` JSON is the single personalization payload that report generation, chat context, recommendations, exercises, daily questions, and notifications all read. Keeping it in one place is what makes "اتصال هدف به Profile Lite فاز ۱" trivial in Phase 2.

Companion style *preference* lives in `UserSettings`; per-style satisfaction ("ثبت رضایت از سبک") goes through the generalized `Feedback` model (§11) with `target_type="companion_style"`.

---

## 6. reports — report → recommendation → action step

Cards covered: گزارش اولیه خودشناسی, گزارش رایگان, توصیه‌های شخصی‌سازی‌شده, Action Preview, کارت قابل اشتراک‌گذاری, گزارش پولی.

```python
class Report(models.Model):
    class Kind(models.TextChoices):
        FREE = "free"; DEEP = "deep"
    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
                             on_delete=models.CASCADE, related_name="reports")
    anon_id = models.UUIDField(null=True, blank=True, db_index=True)
    profile_version = models.ForeignKey("profiles.ProfileVersion", on_delete=models.PROTECT)
    kind = models.CharField(max_length=10, choices=Kind.choices)
    sections = models.JSONField(default=dict)
    # free report = max 5-6 sections per the card:
    #   main_pattern, strength, blind_spot, current_concern, growth_path, first_step
    # deep report adds: dimension_scores, more blind_spots, growth_style,
    #   applied domains (work/relationship/learning)
    locked_sections = models.JSONField(default=list)  # teaser keys behind paywall
    generated_at = models.DateTimeField(auto_now_add=True)
    first_viewed_at = models.DateTimeField(null=True, blank=True)

class Recommendation(models.Model):
    report = models.ForeignKey(Report, on_delete=models.CASCADE, related_name="recommendations")
    order = models.PositiveSmallIntegerField()
    linked_trait = models.CharField(max_length=50)   # "چون نشانه X دیده شد..."
    situation = models.CharField(max_length=200)     # "...در موقعیت Y..."
    text = models.TextField()                        # "...این کار کوچک را انجام بده"
    shown_at = models.DateTimeField(null=True, blank=True)

class ActionStep(models.Model):
    """Action Preview in P1; grows into the exercise/next-step object in P2."""
    class Status(models.TextChoices):
        SUGGESTED = "suggested"; ACCEPTED = "accepted"; DONE = "done"; SKIPPED = "skipped"
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                             related_name="action_steps")
    recommendation = models.ForeignKey(Recommendation, null=True, blank=True,
                                       on_delete=models.SET_NULL)
    source = models.CharField(max_length=30, default="recommendation")
    # recommendation | chat | guided_session | journal | instant_help  (P2 reuse!)
    text = models.TextField()
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.SUGGESTED)
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)

class ShareCard(models.Model):
    """Shareable, non-sensitive insight cards — track organic growth."""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    report = models.ForeignKey(Report, null=True, on_delete=models.SET_NULL)
    card_type = models.CharField(max_length=30)   # decision_pattern, strength, ...
    content = models.JSONField()                   # rendered text (never raw answers)
    created_at = models.DateTimeField(auto_now_add=True)
    shared_at = models.DateTimeField(null=True, blank=True)
```

`ActionStep` is intentionally the **one** "small step" object across both phases. Recommendations, chat replies ("تبدیل این پاسخ به تمرین"), guided sessions, journals, and instant help all emit `ActionStep`s — which gives the funnel dashboard a single "نرخ انجام تمرین" query and gives Phase 2 reminders a single "تمرین نیمه‌تمام" query.

---

## 7. chat — extend Session, add message identity

Cards covered: اولین گفت‌وگوی شخصی, اکشن‌های ساده روی پیام‌ها, Saved Insights, حالت کمک فوری, سشن‌های کوتاه (context), Voice Lite/V2.

Extend `Session` rather than replacing it:

```python
class Session(models.Model):
    # ... existing fields (session_id_metis, session_id_mongo, ...) ...
    session_type = models.CharField(max_length=20, default="free_chat",
        choices=[("free_chat", "Free chat"), ("report_chat", "Report chat"),
                 ("instant_help", "Instant help"), ("guided", "Guided session")])
    profile_version = models.ForeignKey("profiles.ProfileVersion", null=True, blank=True,
                                        on_delete=models.SET_NULL)   # context binding
    report = models.ForeignKey("reports.Report", null=True, blank=True,
                               on_delete=models.SET_NULL)
    companion_style = models.CharField(max_length=20, null=True, blank=True)
```

`report_chat` implements the Phase 1 rule that post-report chat "نباید چت آزاد عمومی باشد" — the type + FK is what your backend uses to build the constrained prompt context.

Message content stays in Mongo (no need to migrate), but actions and bookmarks live in Postgres **with a snapshot**:

```python
class MessageAction(models.Model):
    class Action(models.TextChoices):
        LIKE = "like"; DISLIKE = "dislike"; SAVE = "save"; COPY = "copy"
        EXPLAIN_MORE = "explain_more"; SIMPLIFY = "simplify"
        MAKE_PRACTICAL = "make_practical"; TO_EXERCISE = "to_exercise"
        REPORT = "report"; DELETE = "delete"
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    session = models.ForeignKey(Session, on_delete=models.CASCADE, related_name="message_actions")
    mongo_message_id = models.CharField(max_length=100, db_index=True)
    action = models.CharField(max_length=20, choices=Action.choices)
    dislike_reason = models.CharField(max_length=30, null=True, blank=True)
    # too_generic | not_me | too_long | wrong  (per the card)
    created_at = models.DateTimeField(auto_now_add=True)

class SavedItem(models.Model):
    """Bookmarks across the whole product (P2 card: Saved Insights)."""
    class ItemType(models.TextChoices):
        CHAT_MESSAGE = "chat_message"; INSIGHT = "insight"; EXERCISE = "exercise"
        NEXT_STEP = "next_step"; JOURNAL_SUMMARY = "journal_summary"
        SESSION_OUTPUT = "session_output"; REMINDER_LINE = "reminder_line"
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                             related_name="saved_items")
    item_type = models.CharField(max_length=20, choices=ItemType.choices)
    ref_id = models.CharField(max_length=100, blank=True)  # mongo id or row pk
    content_snapshot = models.JSONField()   # copy of the content at save time
    created_at = models.DateTimeField(auto_now_add=True)
```

The `content_snapshot` is the important decision: Mongo messages can be deleted (the user has a delete action!), so a bookmark that only stores a Mongo id is a dangling pointer waiting to happen. The snapshot also enables "تبدیل saved item به reminder یا تمرین" without a Mongo round-trip.

Voice needs almost no schema — store transcripts as normal messages; add `input_mode = "text" | "voice"` on `CheckIn`, `JournalEntry`, and (in Mongo) message metadata. Per the privacy card, decide explicitly whether raw audio is retained; if it is, add a `VoiceRecording(user, storage_key, duration, deleted_at)` table so deletion is auditable.

---

## 8. growth — the Phase 2 loop

Cards covered: ثبت حال, هدف فعال, سؤال روزانه, کمک فوری, سشن‌های مرحله‌به‌مرحله, ژورنال‌ها, Streak/Badge, گزارش هفتگی.

```python
class Goal(models.Model):
    class Status(models.TextChoices):
        ACTIVE = "active"; PAUSED = "paused"; COMPLETED = "completed"; ARCHIVED = "archived"
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                             related_name="goals")
    category = models.CharField(max_length=30, choices=[
        ("decision", "تصمیم‌گیری بهتر"), ("discipline", "نظم شخصی"),
        ("confidence", "اعتمادبه‌نفس"), ("career", "مسیر شغلی"),
        ("learning", "یادگیری"), ("relationship", "رابطه"),
        ("calm_mind", "ذهن آرام‌تر"), ("procrastination", "کاهش تعلل"),
        ("perfectionism", "مدیریت کمال‌گرایی")])
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.ACTIVE)
    profile_version = models.ForeignKey("profiles.ProfileVersion", null=True,
                                        on_delete=models.SET_NULL)  # P1↔P2 bridge
    started_at = models.DateTimeField(auto_now_add=True)
    ended_at = models.DateTimeField(null=True, blank=True)
    class Meta:
        constraints = [models.UniqueConstraint(
            fields=["user"], condition=models.Q(status="active"),
            name="one_active_goal_per_user")]   # the card: ONE active goal

class CheckIn(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                             related_name="checkins")
    goal = models.ForeignKey(Goal, null=True, blank=True, on_delete=models.SET_NULL)
    mood = models.CharField(max_length=30, null=True, blank=True)
    energy = models.PositiveSmallIntegerField(null=True, blank=True)  # 1–5
    mind_state = models.CharField(max_length=30, null=True, blank=True, choices=[
        ("busy_mind", "ذهنم شلوغه"), ("no_motivation", "انگیزه ندارم"),
        ("hard_decision", "تصمیم سخت دارم"), ("no_focus", "تمرکز ندارم"),
        ("self_critical", "از خودم ناراضیم"), ("need_plan", "نیاز به برنامه دارم"),
        ("just_writing", "فقط می‌خوام بنویسم")])
    note = models.TextField(blank=True)
    wants_suggestion = models.BooleanField(default=False)
    input_mode = models.CharField(max_length=10, default="text")  # text | voice
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        indexes = [models.Index(fields=["user", "created_at"])]

class PromptTemplate(models.Model):
    """Daily-question bank keyed by goal × mind_state."""
    goal_category = models.CharField(max_length=30, null=True, blank=True)
    mind_state = models.CharField(max_length=30, null=True, blank=True)
    text = models.TextField()
    is_active = models.BooleanField(default=True)

class PromptResponse(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    checkin = models.ForeignKey(CheckIn, null=True, blank=True, on_delete=models.SET_NULL)
    prompt = models.ForeignKey(PromptTemplate, on_delete=models.PROTECT)
    answer = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

class GuidedSessionTemplate(models.Model):
    """روشن‌کردن تصمیم، کوچک‌کردن نگرانی، شروع کار عقب‌افتاده، ..."""
    slug = models.SlugField(unique=True)
    title = models.CharField(max_length=200)
    kind = models.CharField(max_length=20, default="guided")  # guided | instant_help
    steps = models.JSONField(default=list)   # 3–5 staged questions
    is_active = models.BooleanField(default=True)

class GuidedSessionRun(models.Model):
    class Status(models.TextChoices):
        IN_PROGRESS = "in_progress"; COMPLETED = "completed"; ABANDONED = "abandoned"
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    template = models.ForeignKey(GuidedSessionTemplate, on_delete=models.PROTECT)
    chat_session = models.ForeignKey("chat.Session", null=True, blank=True,
                                     on_delete=models.SET_NULL)
    status = models.CharField(max_length=15, choices=Status.choices, default=Status.IN_PROGRESS)
    answers = models.JSONField(default=list)
    summary = models.TextField(blank=True)         # جمع‌بندی کوتاه
    next_step = models.ForeignKey("reports.ActionStep", null=True, blank=True,
                                  on_delete=models.SET_NULL)
    helped = models.BooleanField(null=True)        # instant help: کمک کرد یا نه
    started_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)

class JournalTemplate(models.Model):
    slug = models.SlugField(unique=True)  # decision, busy_mind, procrastination, relationship, learning
    title = models.CharField(max_length=200)
    fields = models.JSONField(default=list)   # ordered prompts of the template
    is_active = models.BooleanField(default=True)

class JournalEntry(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                             related_name="journal_entries")
    template = models.ForeignKey(JournalTemplate, null=True, blank=True,
                                 on_delete=models.SET_NULL)   # null = free journal later
    content = models.JSONField(default=dict)   # {field_slug: answer}
    summary = models.TextField(blank=True)
    input_mode = models.CharField(max_length=10, default="text")
    created_at = models.DateTimeField(auto_now_add=True)
    deleted_at = models.DateTimeField(null=True, blank=True)  # user-controlled delete

class Streak(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    kind = models.CharField(max_length=20)   # checkin | exercise
    current_count = models.PositiveIntegerField(default=0)
    longest_count = models.PositiveIntegerField(default=0)
    last_activity_date = models.DateField(null=True)
    class Meta:
        unique_together = [("user", "kind")]

class Badge(models.Model):
    slug = models.SlugField(unique=True)  # first_step, three_days, clear_decision,
                                          # start_over_delay, one_week, comeback
    title = models.CharField(max_length=100)
    criteria = models.JSONField(default=dict)

class UserBadge(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    badge = models.ForeignKey(Badge, on_delete=models.PROTECT)
    earned_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        unique_together = [("user", "badge")]

class WeeklyReport(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    week_start = models.DateField()
    stats = models.JSONField(default=dict)  # checkin_count, top_mind_state,
                                            # exercises_done, active_goal, pattern
    insight = models.TextField(blank=True)
    suggestion = models.TextField(blank=True)
    viewed_at = models.DateTimeField(null=True, blank=True)
    class Meta:
        unique_together = [("user", "week_start")]
```

Note the "comeback" badge in the card ("برگشت بعد از وقفه") — that's why `Streak` stores `longest_count` separately and why losing a streak must *not* delete history.

---

## 9. wallet — payment vs. product vs. entitlement

Cards covered: Paywall, and future subscription flexibility.

Keep `Transaction` as the money ledger (Zarinpal/Cafebazaar authority, ref id, amounts). Add:

```python
class Product(models.Model):
    class Kind(models.TextChoices):
        DEEP_ASSESSMENT = "deep_assessment"   # Phase 1 paywall
        MINUTES_PACK = "minutes_pack"          # legacy chat minutes
        SUBSCRIPTION = "subscription"          # future
    sku = models.SlugField(unique=True)
    kind = models.CharField(max_length=20, choices=Kind.choices)
    title = models.CharField(max_length=200)
    price = models.PositiveIntegerField()
    config = models.JSONField(default=dict)   # e.g. {"minutes": 60} / {"assessment": "deep-v1"}
    is_active = models.BooleanField(default=True)

class DiscountCode(models.Model):
    code = models.CharField(max_length=25, unique=True)
    percent_off = models.PositiveSmallIntegerField(default=0)
    amount_off = models.PositiveIntegerField(default=0)
    max_uses = models.PositiveIntegerField(null=True)
    used_count = models.PositiveIntegerField(default=0)
    expires_at = models.DateTimeField(null=True)
    is_active = models.BooleanField(default=True)

class Purchase(models.Model):
    """The entitlement: what the user now owns."""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT,
                             related_name="purchases")
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    transaction = models.OneToOneField("wallet.Transaction", on_delete=models.PROTECT)
    granted_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField(null=True, blank=True)  # for subscriptions
```

Then the paywall check is one query: *does the user have a non-expired `Purchase` whose product unlocks `deep-v1`?* — and adding a subscription later is a new `Product.kind`, not a schema change.

Changes to `Transaction`: change `user` to `on_delete=PROTECT`, add `product = FK(Product, null=True, PROTECT)`, and point `discount_code` at `DiscountCode` (keep the old CharField during migration). `minutes`/`minute_rate` can stay for backward compatibility and eventually deprecate in favor of `Product.config`.

---

## 10. notify — from empty app to a real system

Cards covered: Notification & Follow-up MVP, پیام انگیزشی ۷ روزه, یادآوری‌های شخصی‌سازی‌شده, opt-out everywhere.

```python
class NotificationTemplate(models.Model):
    slug = models.SlugField(unique=True)
    kind = models.CharField(max_length=40, choices=[
        ("resume_test", "Resume unfinished test"),
        ("report_ready", "Report ready"), ("view_report", "View report reminder"),
        ("post_report_chat", "Talk about your result"),
        ("exercise_reminder", "Exercise reminder"),
        ("motivation_7day", "7-day motivational"),        # + day index in payload
        ("checkin_reminder", "Check-in reminder"),         # Phase 2
        ("journal_reminder", "Journal reminder"),
        ("goal_reminder", "Active goal reminder"),
        ("weekly_report", "Weekly report ready"),
        ("feedback_request", "Report accuracy feedback")])
    channel = models.CharField(max_length=10,
        choices=[("push", "Push"), ("sms", "SMS"), ("email", "Email"), ("inapp", "In-app")])
    body_template = models.TextField()   # may vary by concern/goal via payload
    is_active = models.BooleanField(default=True)

class Notification(models.Model):
    class Status(models.TextChoices):
        SCHEDULED = "scheduled"; SENT = "sent"; FAILED = "failed"; CANCELLED = "cancelled"
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                             related_name="notifications")
    template = models.ForeignKey(NotificationTemplate, on_delete=models.PROTECT)
    payload = models.JSONField(default=dict)   # concern, day_index, deep link target
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.SCHEDULED)
    scheduled_for = models.DateTimeField(db_index=True)
    sent_at = models.DateTimeField(null=True, blank=True)
    opened_at = models.DateTimeField(null=True, blank=True)   # KPI: open rate
    clicked_at = models.DateTimeField(null=True, blank=True)  # KPI: return-from-notif

class NotificationPreference(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                related_name="notification_prefs")
    enabled = models.BooleanField(default=True)               # global mute
    kinds_muted = models.JSONField(default=list)              # per-kind opt-out
    channels_enabled = models.JSONField(default=dict)         # {"push": true, "sms": false}
    motivation_7day_opted_in = models.BooleanField(default=False)  # explicit opt-in per card
    preferred_time = models.TimeField(null=True, blank=True)
```

The 7-day motivational program is just 7 `Notification` rows scheduled at opt-in time (kind `motivation_7day`, `payload={"day": n, "concern": ...}`) — cancel remaining rows on opt-out. `FCMDevice` stays as the push delivery mechanism underneath.

---

## 11. Generalize Feedback + add analytics events

The current `Feedback` (user, rate, comment) can't serve the roadmap, which wants feedback on: report accuracy, chat messages, exercises, instant help, journals, guided sessions, notifications, and companion style. Generalize with a target enum (simpler and more queryable than GenericForeignKey):

```python
class Feedback(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
                             on_delete=models.SET_NULL, related_name="feedbacks")
    target_type = models.CharField(max_length=30, choices=[
        ("app", "App (legacy)"), ("report", "Report"), ("chat_message", "Chat message"),
        ("exercise", "Exercise"), ("guided_session", "Guided session"),
        ("instant_help", "Instant help"), ("journal", "Journal"),
        ("notification", "Notification"), ("companion_style", "Companion style")])
    target_id = models.CharField(max_length=100, blank=True)  # pk or mongo id
    rate = models.SmallIntegerField(null=True, validators=[MinValueValidator(0), MaxValueValidator(5)])
    reason = models.CharField(max_length=40, blank=True)   # too_generic / not_me / too_long / ...
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
```

Migrate existing rows with `target_type="app"`.

For the funnel/retention dashboards, add a thin append-only event table (or wire PostHog/Amplitude — either way the shape is the same):

```python
class Event(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
                             on_delete=models.SET_NULL)
    anon_id = models.UUIDField(null=True, blank=True, db_index=True)
    name = models.CharField(max_length=50, db_index=True)
    # landing_view, test_start, section_complete, test_complete, lead_captured,
    # report_view, chat_start, voice_used, exercise_done, paywall_view,
    # paywall_click, purchase, checkin, goal_set, session_complete, notif_open, ...
    properties = models.JSONField(default=dict)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
```

Keep it out of hot request paths (write async), partition or prune by date, and every metric on both dashboard cards becomes a GROUP BY. Both `Attempt` and `Event` carrying `anon_id` + nullable `user` is what makes the *full* funnel (including pre-signup drop-off) measurable — the single most important structural change for Phase 1's validation goal.

---

## 12. Migration order

Each step is independently shippable and maps to roadmap order:

1. **Foundation:** `UserSettings`, `ConsentLog`, `Event`, generalized `Feedback`; switch `Transaction.user` to `PROTECT`; add `User.deleted_at`.
2. **Assessment core (P1 launch):** `assessment` app, `ProfileVersion`, `Report`, `Recommendation`, `ActionStep`, `ShareCard` — all with `anon_id` support.
3. **Chat extension:** `Session.session_type/profile_version/report/companion_style`, `MessageAction`, `SavedItem`.
4. **Monetization:** `Product`, `DiscountCode`, `Purchase`; paywall reads entitlements.
5. **Notify:** `NotificationTemplate`, `Notification`, `NotificationPreference`; keep `FCMDevice` for delivery.
6. **Phase 2:** the whole `growth` app (`Goal` → `CheckIn` → prompts → sessions → journals → streaks → weekly reports).

## 13. Design principles recap

- **User stays the hub**, but `anon_id` runs parallel to it until lead capture, then gets attached.
- **JSONField for content that will iterate** (traits, report sections, question scoring, template steps); **relational columns for anything you filter, join, or count** (statuses, categories, timestamps, FKs).
- **Templates-as-data** (assessments, questions, prompts, journals, guided sessions, notifications) so product iteration never needs a migration.
- **One reusable `ActionStep`** across recommendations, chat, sessions, journals, and instant help.
- **Snapshots over dangling references** wherever Postgres points at Mongo.
- **PROTECT money, consent, and templates; CASCADE personal content; soft-delete users** — this is what makes the "delete my account/data" promise implementable without destroying accounting records.
