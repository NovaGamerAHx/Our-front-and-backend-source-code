# Infrastructure & Deployment

Where this app runs, how a merge becomes a deploy, and the plan for removing the single points
of failure that come with today's one-VM setup. See CLAUDE.md's Known Issues (#16-#24) for the
individual findings this document ties together.

## Current topology (as of 2026-09-04)

One VM runs everything, via `docker-compose.yml`:

| Service | Replicas | Notes |
|---|---|---|
| `web` | 2 (`web`, `web2`) | gunicorn, `GUNICORN_WORKERS`/`GUNICORN_THREADS` each (`.env` / `entrypoint.sh`) |
| `celery` | 2 (`celery`, `celery2`) | worker, pulls from the same Redis-backed queue |
| `celery-beat` | **1, always** | never scale this — two would double-fire every `CELERY_BEAT_SCHEDULE` entry (`settings.py`) |
| `nginx` | 1 | reverse proxy, `upstream web { server web:8000; server web2:8000; }` (`nginx/nginx.conf`) with `max_fails`/`fail_timeout` for passive failover |
| `db` | 1 | `postgres:16-alpine`, local volume, no replica |
| `redis` | 1 | OTP/throttle storage + Celery broker/result backend, no replica |

`web`/`web2` and `celery`/`celery2` are separate named services rather than `docker compose
--scale` — nginx resolves upstream hostnames once at startup, so a static, named pair avoids
having to make that resolution dynamic.

`web`/`web2` also have a Docker `healthcheck` (added 2026-09-06, CLAUDE.md #16) hitting the
in-app **liveness** route `GET /health/` — `faraman_back.middleware.HealthCheckMiddleware`,
first in the stack, answers before host validation and outside the Prometheus histogram. It's
liveness only (no DB/Redis probe) on purpose: a healthcheck that failed on a DB blip would
mark both `web` replicas unhealthy at once. nginx serves its own `location = /health` for the
front proxy; nginx's `depends_on` stays plain ordering so an unhealthy `web` at boot doesn't
hold nginx back from the healthy one.

## Deploy pipeline

`.gitlab-ci.yml` runs on hamgit.ir (self-hosted GitLab):

- `build`: `make build` (`docker compose build`), on MRs and on `main`.
- `test`: **currently commented out.** Nothing automated runs `manage.py check`/`migrate`/the
  test suite against a rendered `.env` before `deploy` does — on production, live. Re-enabling
  this is tracked as part of known issue #24.
- `deploy`: only on push to `main`, on a **shell executor** runner that runs directly on the
  production host. It does `source scripts/render_env.sh && make up && make migrate && make
  ensure-superuser && make seed-deep-assessment`.

**There is no staging environment.** Merging an MR to `main` immediately rebuilds/restarts
containers and runs migrations against production. Treat any settings/config change as
higher-risk than it would be with a staging gate in front of it.

`scripts/render_env.sh` renders `.env` from GitLab CI/CD variables using `.env.example` as the
list of expected keys — **it writes a line for every key, using the CI/CD variable's value or
an empty string if that variable isn't set. It never omits the line.** This means
`os.getenv(key, default)` never falls back to `default` for any key listed in `.env.example` —
only `os.getenv(key) or default` is safe. Getting this wrong is exactly what broke the
2026-09-04 deploy (`DB_CONN_MAX_AGE` rendered as `DB_CONN_MAX_AGE=`, and
`int(os.getenv('DB_CONN_MAX_AGE', '60'))` evaluated `int('')` and crashed `settings.py` on
import — which meant every gunicorn worker failed to boot, invisibly, since `web` had no
healthcheck at the time — it does now, see below). See CLAUDE.md items #20 and #24. **Any new numeric/boolean setting added to
`.env.example` must use the `x or default` idiom** (already used in
`apps/ai/openai_client.py` for this same reason).

## Hosting decisions

- The production VM is **not** hosted on ArvanCloud. ArvanCloud appears in this repo only as a
  Docker Hub registry mirror workaround (`Dockerfile`'s `FROM docker.arvancloud.ir/...` — the
  GitLab runner's IP gets a 403 from `registry-1.docker.io` directly). That's unrelated to
  where the app itself runs.
- **ArvanCloud's managed services (Postgres, Redis, load balancer, Kubernetes) are ruled out**
  for the redundancy work below — network instability on their infrastructure. Don't propose
  them again without checking first.
- Direction instead: **self-managed HA** on infrastructure already in use — more ops work, no
  new vendor.

## Redundancy roadmap (known issue #19)

Staged deliberately so the riskiest part (automatic database failover) isn't attempted first.

**Phase A — process-level redundancy, one VM, no new infra. Shipped and verified live in
production 2026-09-04**: `docker ps` on the host showed both `web` and `web2` containers up,
and each had independently handled a distinct real chat request in its own logs (different
message content/token counts, not the same request logged twice) — confirming nginx was
actually distributing traffic across both, not just that both containers existed. `web`/`web2`
and `celery`/`celery2` as described above. Removes "one process crashes or is mid-redeploy" as
a cause of downtime. Does **not** protect against the VM itself, Postgres, Redis, or nginx
going down — those are Phases B and C.

**Phase B — Postgres and Redis redundancy. Not started.**
- *Stage B1 (do first):* Postgres streaming replication with a standby, **manual** failover —
  a documented runbook, not automation. Also gives a natural place to run backups from
  (`pg_dump`/`pg_basebackup` off the standby instead of the primary), closing most of known
  issue #18 along the way.
- *Stage B2 (later, needs a 3rd witness VM):* automatic failover via **pg_auto_failover**
  (preferred over Patroni here — one monitor node instead of a separate etcd/Consul cluster;
  if the monitor dies, the existing primary/standby keep serving, only automatic promotion
  pauses). Automatic failover with only 2 DB nodes risks split-brain, hence the witness node.
- *Redis:* add a plain replica first (lower priority than Postgres — smaller blast radius,
  since Redis here only backs OTP/throttling/the Celery broker). Defer Sentinel (also wants 3
  nodes for safe quorum) until the witness VM from B2 exists.

**Phase C — take the VM itself off the single-point-of-failure list. Not started.** A second
VM running the same `web`/`celery` stack (plus the Postgres standby / Redis replica from Phase
B). Needs a way to route traffic to whichever VM is currently up:
- **keepalived + a floating/virtual IP (VRRP)** — fast failover, but depends on the hosting
  provider supporting IP failover between instances (not yet confirmed for the current
  provider), or
- **DNS-based failover** with a low TTL — slower (tens of seconds), but provider-independent.

Either way, each VM's nginx would need its `web` upstream to include the *other* VM's `web`
containers too, which means exposing them over the VMs' network rather than Docker's default
per-host bridge.

If growth eventually justifies it, the point of provisioning a second VM + load balancer is
also the natural point to re-ask whether to move to managed Kubernetes instead of hand-rolling
this — see the capacity/scaling discussion referenced from CLAUDE.md's production-readiness
review.
