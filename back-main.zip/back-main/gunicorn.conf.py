# gunicorn's gevent worker (entrypoint.sh) monkey-patches Python's socket/threading/ssl
# modules automatically, but psycopg2 talks to Postgres through libpq's C code, which never
# goes through those modules -- so a DB query would otherwise still block the whole worker
# process's event loop, not just the calling greenlet. post_fork runs once per forked worker
# process, before it starts handling requests, so every psycopg2 connection it opens is
# gevent-cooperative from the start.
from psycogreen.gevent import patch_psycopg


def post_fork(server, worker):
    patch_psycopg()


def child_exit(server, worker):
    # Runs in the master when a gevent worker exits (crash or max-requests recycle). Retire
    # that worker's prometheus_client multiprocess files so its counter/gauge contributions
    # stop being scraped -- see entrypoint.sh for the multiproc setup. Imported here, not at
    # module top, so prometheus_client is only touched once PROMETHEUS_MULTIPROC_DIR is set.
    try:
        from prometheus_client import multiprocess

        multiprocess.mark_process_dead(worker.pid)
    except Exception:
        pass
