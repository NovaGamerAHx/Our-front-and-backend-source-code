#!/bin/sh

if [ "$#" -gt 0 ]; then
    echo "Running: $@"
    exec "$@"
fi

# prometheus_client multiprocess mode (3 gunicorn gevent workers share one dir). Wipe it on
# every start: child_exit (gunicorn.conf.py) retires a worker's per-pid files on a graceful
# exit, but a SIGKILL/OOM'd worker from a previous container run would leave files behind
# that keep contributing to counters forever. PROMETHEUS_MULTIPROC_DIR is set on web/web2 in
# docker-compose.yml; the default here is only for a bare `docker run`.
PROMETHEUS_MULTIPROC_DIR="${PROMETHEUS_MULTIPROC_DIR:-/tmp/prometheus-multiproc}"
export PROMETHEUS_MULTIPROC_DIR
rm -rf "$PROMETHEUS_MULTIPROC_DIR"
mkdir -p "$PROMETHEUS_MULTIPROC_DIR"

echo "Starting server..."
exec gunicorn faraman_back.wsgi:application --config gunicorn.conf.py --bind 0.0.0.0:8000 --timeout 300 \
    --workers "${GUNICORN_WORKERS:-3}" --worker-class gevent \
    --worker-connections "${GUNICORN_WORKER_CONNECTIONS:-100}"
