"""Hands out one phone number per simulated user, never reused within a run.

Every per-identity throttle in the app (chat/24h, report-email/hour, assessment-attempt/24h, plus
OTP's own "already requested" guard) is keyed on phone number / user, not IP -- see
loadtest/README.md. Reusing a small pool would make those throttles the bottleneck instead of real
infra capacity, so each Locust user gets a distinct number from a pre-generated pool
(data/generate_phone_pool.py) for the lifetime of the run.

Plain list + index under a lock, not itertools.cycle: gevent's cooperative scheduling means no
context switch happens mid-index-increment (no I/O in between), so this is safe without extra
locking in Locust's single-process model, but the lock costs nothing and removes the need to
reason about it.
"""
import itertools
import os
import threading

_POOL_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "phone_pool.txt")
_lock = threading.Lock()
_counter = itertools.count()
_numbers = None


def _load():
    global _numbers
    if _numbers is None:
        with open(_POOL_PATH) as f:
            _numbers = [line.strip() for line in f if line.strip()]
        if not _numbers:
            raise RuntimeError(
                f"{_POOL_PATH} is empty -- run `python data/generate_phone_pool.py` first "
                "(see loadtest/README.md)."
            )
    return _numbers


def next_phone_number() -> str:
    numbers = _load()
    with _lock:
        i = next(_counter)
    if i >= len(numbers):
        raise RuntimeError(
            f"Phone pool exhausted ({len(numbers)} numbers for {i + 1}+ simulated users) -- "
            "regenerate a bigger pool with data/generate_phone_pool.py and update "
            "TEST_OTP_PHONE_NUMBERS in compose.override.app.yml."
        )
    return numbers[i]
