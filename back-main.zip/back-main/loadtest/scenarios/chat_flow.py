"""Chat send + regenerate -- the known critical path (CLAUDE.md known issue #23/#25): each
in-progress turn used to hold a whole gunicorn worker thread; #22's fix moved web to gevent, but
the new ceiling was never measured under real load, which is what this scenario is for.

_sse_response() (apps/chat/views/chat_view.py) streams raw `event: delta` / `event: done` /
`event: error` lines, not an ApiResponse envelope, and Locust's auto-instrumentation only times up
to headers-received for a streamed request -- so both time-to-first-byte and full-stream-close are
timed manually here and fired as separate named requests via environment.events.request.fire().

CHAT_MESSAGE_LIMIT_COUNT (faraman_back/settings.py, env-configurable, default 50) caps messages
per identity per rolling 24h, shared between send and regenerate
(apps/chat/repositories/chat_message_throttle_repository.py) -- each simulated user stops once it
hits that cap, same reasoning as assessment_flow.py's ATTEMPT_LIMIT_PER_IDENTITY. Keep
CHAT_MESSAGE_LIMIT_PER_IDENTITY below in sync with whatever the running stack is actually
configured to -- a mismatch just means the client either stops early (harmless) or the server
starts rejecting with 429s that get logged as failures without a real infra signal behind them.

With CHAT_AI_ENABLED=false (loadtest/compose.override.app.yml), the reply is a single instant
mock chunk (apps/ai/chat_generation/generate.py's _mock_stream()) -- this measures pure infra
overhead (DB writes, SSE plumbing, gevent scheduling), not sustained-hold-duration effects. See
loadtest/README.md for the optional CHAT_MOCK_STREAM_DELAY_MS/_CHUNK_COUNT knobs if that matters.
"""
import json
import random
import time

CHAT_MESSAGE_LIMIT_PER_IDENTITY = 50
REGENERATE_PROBABILITY = 0.2  # rest are ordinary sends -- regenerate is the rarer real-world case
CHAT_ENTRY_SOURCE = "manual"
USER_MESSAGE = "چه کارهایی می‌توانم برای بهبود روزم انجام دهم؟"


class ChatFlowMixin:
    def init_chat_state(self):
        self._chat_messages_used = 0
        self._chat_session_id = None
        self._last_assistant_message_id = None

    def _ensure_chat_session(self):
        if self._chat_session_id is not None:
            return self._chat_session_id

        resp = self.client.post(
            "/api/chat/sessions/",
            json={"entry_source": CHAT_ENTRY_SOURCE},
            headers=self.auth_headers(),
            name="POST /api/chat/sessions/ (create)",
        )
        if resp.status_code == 200:
            self._chat_session_id = resp.json()["data"]["session_id"]
        return self._chat_session_id

    def _stream_sse(self, path, *, method, json_body, metric_prefix):
        headers = self.auth_headers()
        t0 = time.monotonic()
        ttft = None

        try:
            with self.client.request(
                method, path, json=json_body, headers=headers, name=path, stream=True, catch_response=True,
            ) as resp:
                if resp.status_code != 200:
                    resp.failure(f"{path} returned {resp.status_code}")
                    return

                last_assistant_message_id = None
                # Wire format is exactly two lines per SSE message (chat_service.py's _sse()):
                # "event: <name>" then "data: <json>", in that order -- so the terminal event's
                # payload (holding message_id, apps/chat/services/chat_service.py:513) always
                # arrives on the *next* line after "event: done"/"event: error", never on the
                # same line. Only break once that following data line has been read.
                #
                # FastHttpUser's response has no requests-style iter_lines() -- only readline()
                # (delegating straight to the underlying geventhttpclient response), returning b""
                # at EOF. Caught by actually running this scenario: the first attempt used
                # iter_lines() and every chat request raised AttributeError.
                awaiting_terminal_data = False
                while True:
                    raw_line = resp.readline()
                    if not raw_line:
                        break  # b"" means the stream closed without a terminal event -- give up
                    raw_line = raw_line.rstrip(b"\r\n")
                    if not raw_line:
                        continue
                    line = raw_line.decode("utf-8") if isinstance(raw_line, bytes) else raw_line
                    if ttft is None:
                        ttft = time.monotonic() - t0
                        self.environment.events.request.fire(
                            request_type="SSE", name=f"{metric_prefix}_ttft",
                            response_time=ttft * 1000, response_length=0, exception=None,
                        )
                    if line.startswith("event: done") or line.startswith("event: error"):
                        awaiting_terminal_data = True
                        continue
                    if line.startswith("data:"):
                        if awaiting_terminal_data:
                            try:
                                payload = json.loads(line[len("data:"):].strip())
                                last_assistant_message_id = payload.get("message_id")
                            except ValueError:
                                pass
                            break
                        continue

                total = time.monotonic() - t0
                self.environment.events.request.fire(
                    request_type="SSE", name=f"{metric_prefix}_total",
                    response_time=total * 1000, response_length=0, exception=None,
                )
                resp.success()
                if last_assistant_message_id is not None:
                    self._last_assistant_message_id = last_assistant_message_id
        except Exception as exc:  # network-level failure mid-stream
            self.environment.events.request.fire(
                request_type="SSE", name=f"{metric_prefix}_total",
                response_time=(time.monotonic() - t0) * 1000, response_length=0, exception=exc,
            )

    def chat_send_or_regenerate(self):
        if self._chat_messages_used >= CHAT_MESSAGE_LIMIT_PER_IDENTITY:
            return

        session_id = self._ensure_chat_session()
        if session_id is None:
            return

        want_regenerate = self._last_assistant_message_id is not None and random.random() < REGENERATE_PROBABILITY
        if want_regenerate:
            self._stream_sse(
                f"/api/chat/sessions/{session_id}/messages/{self._last_assistant_message_id}/regenerate/",
                method="POST", json_body=None, metric_prefix="chat_regenerate",
            )
        else:
            self._stream_sse(
                f"/api/chat/sessions/{session_id}/messages/",
                method="POST", json_body={"user_message": USER_MESSAGE}, metric_prefix="chat_send",
            )
        self._chat_messages_used += 1
