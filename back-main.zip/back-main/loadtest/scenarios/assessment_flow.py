"""Start -> 30x submit-answer -> complete, against the seeded 30-item 'test-likert-v2' assessment
(apps/assessment/management/commands/seed_test_assessment.py, requires_purchase=False so no
payment is needed first -- run `make seed-test-assessment` before load testing).

The one call worth timing precisely is `complete`: CompleteAttemptAPIView just writes to the DB
and enqueues generate_initial_report.delay() inside transaction.on_commit (apps/report/services/
report_service.py) -- the HTTP response returns before generation runs, so this measures
dispatch latency, not generation. It's fired as its own named request so its stat line doesn't
get averaged in with the answer-submission calls around it.

ATTEMPT_LIMIT_COUNT is 2 per identity per 24h (apps/assessment/repositories/
attempt_throttle_repository.py) -- each simulated user (its own phone number, see phone_pool.py)
stops running this flow once it hits that cap rather than generating throttle-rejection noise.
"""
import random

ASSESSMENT_SLUG = "test-likert-v2"
LIKERT_MIN, LIKERT_MAX = 1, 5
ATTEMPT_LIMIT_PER_IDENTITY = 2


class AssessmentFlowMixin:
    def init_assessment_state(self):
        self._attempts_completed = 0
        self.completed_attempt_ids = []
        self._question_ids = None

    def _question_ids_for_assessment(self):
        if self._question_ids is None:
            resp = self.client.get(
                f"/api/assessments/{ASSESSMENT_SLUG}/",
                headers=self.auth_headers(),
                name="GET /api/assessments/<slug>/ (fetch questions)",
            )
            self._question_ids = [q["id"] for q in resp.json()["data"]["questions"]]
        return self._question_ids

    def run_assessment_flow(self):
        if self._attempts_completed >= ATTEMPT_LIMIT_PER_IDENTITY:
            return

        headers = self.auth_headers()

        resp = self.client.post(
            "/api/assessments/attempts/",
            json={"assessment_slug": ASSESSMENT_SLUG},
            headers=headers,
            name="POST /api/assessments/attempts/ (start)",
        )
        if resp.status_code != 200:
            return
        attempt_id = resp.json()["data"]["id"]

        for question_id in self._question_ids_for_assessment():
            self.client.post(
                f"/api/assessments/attempts/{attempt_id}/answers/",
                json={"question_id": question_id, "value": random.randint(LIKERT_MIN, LIKERT_MAX)},
                headers=headers,
                name="POST /api/assessments/attempts/<id>/answers/",
            )

        with self.client.post(
            f"/api/assessments/attempts/{attempt_id}/complete/",
            headers=headers,
            name="attempt_complete_dispatch",
            catch_response=True,
        ) as resp:
            if resp.status_code == 200:
                self._attempts_completed += 1
                self.completed_attempt_ids.append(attempt_id)
            else:
                resp.failure(f"complete failed: {resp.status_code} {resp.text}")
