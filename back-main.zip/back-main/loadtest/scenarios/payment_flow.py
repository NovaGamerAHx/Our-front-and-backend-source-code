"""POST /api/payment/initiate/ only -- dispatch latency of PaymentService.initiate_payment()
(apps/payment/services/payment_service.py). Never scenario-tests `verify`/`callback`: those need
a real browser on Zarinpal's hosted pay page, which Locust can't script (see loadtest/README.md
and CLAUDE.md's "Later: moving to production" notes on this endpoint).

Tagged "payment" so it's excluded by default (`make loadtest-run` passes --exclude-tags payment)
-- ZARINPAL_SANDBOX defaults True so no real money moves, but this is still a real network call
out to sandbox.zarinpal.com, not something to run at full scenario volume by default.

Targets deep-150-v1 (requires_purchase=True, apps/payment/management/commands/
seed_deep_assessment.py) since test-likert-v2 is free and has nothing to purchase.
"""
PURCHASABLE_ASSESSMENT_SLUG = "deep-150-v1"


class PaymentFlowMixin:
    def initiate_payment(self):
        with self.client.post(
            "/api/payment/initiate/",
            json={"assessment_slug": PURCHASABLE_ASSESSMENT_SLUG},
            headers=self.auth_headers(),
            name="POST /api/payment/initiate/",
            catch_response=True,
        ) as resp:
            # AssessmentAlreadyPurchasedException is 409 (apps/payment/services/exceptions.py) and
            # expected once a simulated user has already bought it in an earlier iteration --
            # not a real failure, don't skew the error rate.
            if resp.status_code in (200, 409):
                resp.success()
            else:
                resp.failure(f"payment initiate failed: {resp.status_code} {resp.text}")
