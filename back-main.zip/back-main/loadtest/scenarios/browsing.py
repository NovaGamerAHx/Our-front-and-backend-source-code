"""Read-heavy authenticated CRUD -- report/chat history, assessment detail. Models ordinary
browsing traffic to give a baseline for django_http_requests_latency_seconds under load,
independent of the heavier write/streaming paths.
"""
import random

READ_ENDPOINTS = [
    ("/api/reports/history/", "GET /api/reports/history/"),
    ("/api/reports/attempts-history/", "GET /api/reports/attempts-history/"),
    ("/api/chat/sessions/", "GET /api/chat/sessions/"),
    ("/api/account/profile/", "GET /api/account/profile/"),
    ("/api/assessments/test-likert-v2/", "GET /api/assessments/test-likert-v2/"),
]


class BrowsingMixin:
    def browse_random(self):
        path, name = random.choice(READ_ENDPOINTS)
        self.client.get(path, headers=self.auth_headers(), name=name)
