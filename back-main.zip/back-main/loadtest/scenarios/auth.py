"""OTP request+verify -> JWT, plus a refresh helper for runs longer than the 30-minute access
token lifetime (SIMPLE_JWT['ACCESS_TOKEN_LIFETIME'], faraman_back/settings.py).

Relies on the TEST_OTP_PHONE_NUMBERS / TEST_OTP_CODE bypass (apps/account/services/otp_service.py)
being active -- set by loadtest/compose.override.app.yml, never in a normal deploy. Real OTP
delivery (Melipayamak SMS) is never exercised by this load test.
"""
import time

from scenarios.phone_pool import next_phone_number

TEST_OTP_CODE = "12345"  # must match TEST_OTP_CODE in loadtest/compose.override.app.yml
ACCESS_TOKEN_LIFETIME_S = 30 * 60
REFRESH_MARGIN_S = 5 * 60  # refresh a bit before expiry, not exactly at it


class AuthMixin:
    def init_auth_state(self):
        self.phone_number = None
        self.access_token = None
        self.refresh_token = None
        self._token_issued_at = 0

    def login(self):
        # Reuse the number already drawn for this user, if any -- login() is retried from
        # _maybe_refresh()'s fallback whenever otp/send, otp/verify, or token/refresh fails for
        # any reason (a transient blip, not just real expiry). Drawing a fresh number on every
        # retry would exhaust the whole pool in seconds the first time the backend hiccups, since
        # a failed login never sets _token_issued_at, so every subsequent task call re-triggers
        # this same path -- caught by actually running it (a 45s/5-user smoke run burned through
        # a 30-number pool from one bad stretch of requests).
        if self.phone_number is None:
            self.phone_number = next_phone_number()

        with self.client.post(
            "/api/account/otp/send/",
            json={"phone_number": self.phone_number},
            name="/api/account/otp/send/",
            catch_response=True,
        ) as resp:
            if resp.status_code != 200:
                resp.failure(f"otp/send failed: {resp.status_code} {resp.text}")
                return

        with self.client.post(
            "/api/account/otp/verify/",
            json={"phone_number": self.phone_number, "code": TEST_OTP_CODE},
            name="/api/account/otp/verify/",
            catch_response=True,
        ) as resp:
            if resp.status_code != 200:
                resp.failure(f"otp/verify failed: {resp.status_code} {resp.text}")
                return
            body = resp.json()
            self.access_token = body["data"]["access"]
            self.refresh_token = body["data"]["refresh"]
            self._token_issued_at = time.monotonic()

    def auth_headers(self):
        self._maybe_refresh()
        return {"Authorization": f"Bearer {self.access_token}"}

    def _maybe_refresh(self):
        if self.access_token is None:
            # Never successfully logged in yet -- go straight to login() rather than wasting a
            # request on refreshing a token that doesn't exist (self.refresh_token is also None).
            self.login()
            return
        if time.monotonic() - self._token_issued_at < ACCESS_TOKEN_LIFETIME_S - REFRESH_MARGIN_S:
            return

        with self.client.post(
            "/api/account/token/refresh/",
            json={"refresh": self.refresh_token},
            name="/api/account/token/refresh/",
            catch_response=True,
        ) as resp:
            if resp.status_code == 200:
                # TokenRefreshAPIView returns the bare access token string as `data`, not a dict
                # (apps/account/views/user_view.py), unlike otp/verify's {access, refresh, user}.
                self.access_token = resp.json()["data"]
                self._token_issued_at = time.monotonic()
            else:
                # Fall back to a fresh login rather than grinding on an expired/invalid token.
                resp.failure(f"token refresh failed: {resp.status_code} {resp.text}")
                self.login()
