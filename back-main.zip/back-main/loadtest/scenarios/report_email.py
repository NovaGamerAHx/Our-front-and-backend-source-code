"""POST .../email/ -- the one endpoint left that does real synchronous work in-request: WeasyPrint
PDF rendering (apps/report/services/pdf_service.py) plus an SMTP send (redirected to the console
backend by loadtest/compose.override.app.yml, so no real email goes out). Flagged in
faraman_back/observability/metrics.py's own docstring as the one delivery path that blocks a
gunicorn worker for its whole duration.

REPORT_EMAIL_LIMIT_COUNT is 3 per identity per hour (apps/report/repositories/
report_email_throttle_repository.py) -- capped per simulated user like the other per-identity
throttles.

Needs an attempt whose report has already finished generating (status == "ok"). With
REPORT_AI_ENABLED=false the mock report resolves almost immediately, but the Celery dispatch from
assessment_flow.py is still async, so this polls once rather than assuming it's ready.
"""
REPORT_EMAIL_LIMIT_PER_IDENTITY = 3
LOAD_TEST_EMAIL = "loadtest@example.invalid"


class ReportEmailMixin:
    def init_report_email_state(self):
        self._reports_emailed = 0

    def email_latest_report(self):
        if self._reports_emailed >= REPORT_EMAIL_LIMIT_PER_IDENTITY:
            return
        if not getattr(self, "completed_attempt_ids", None):
            return  # assessment_flow.py hasn't completed an attempt for this user yet

        attempt_id = self.completed_attempt_ids[-1]
        headers = self.auth_headers()

        status_resp = self.client.get(
            f"/api/reports/attempts/{attempt_id}/",
            headers=headers,
            name="GET /api/reports/attempts/<id>/ (poll before email)",
        )
        if status_resp.status_code != 200 or status_resp.json()["data"].get("status") != "ok":
            return  # still generating -- try again on a later iteration

        with self.client.post(
            f"/api/reports/attempts/{attempt_id}/email/",
            json={"email": LOAD_TEST_EMAIL},
            headers=headers,
            name="POST /api/reports/attempts/<id>/email/",
            catch_response=True,
        ) as resp:
            if resp.status_code == 200:
                self._reports_emailed += 1
            else:
                resp.failure(f"report email failed: {resp.status_code} {resp.text}")
