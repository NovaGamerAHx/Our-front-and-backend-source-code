# Load testing

Locust-based load test for the local Docker Compose stack (`docker-compose.yml` at repo root),
mirroring production's actual topology (web/web2 gevent workers, celery/celery2, nginx, db,
redis) since there's no staging environment (`docs/infrastructure.md`). See CLAUDE.md's
"Known issues" #23/#25/#26 for the capacity questions this is meant to answer, and its "Later:
moving to production" section for why this can't simply be re-pointed at `faraman.ai` as-is.

Kept entirely separate from the app image (own `Dockerfile`/`requirements.txt`, own compose
file) — Locust's dependencies must never land in `web`/`celery`, same reasoning as `monitoring/`.

## One-time setup

1. Generate a phone-number pool — each simulated user needs its own number, or the per-phone-number
   OTP-throttle guard (`apps/account/services/otp_service.py`) will dominate the run instead of
   real infra capacity:
   ```
   python data/generate_phone_pool.py --count 1000
   ```
   Paste the printed comma-joined string into `compose.override.app.yml`'s `TEST_OTP_PHONE_NUMBERS`
   value. Pick `--count` at least as large as the peak concurrent-user count you intend to test —
   the run fails loudly (not silently) if the pool runs out.
2. Seed the assessments the scenarios exercise: `make seed-test-assessment` (free, 30-item, used by
   the chat/assessment/email scenarios) and `make seed-deep-assessment` (paid, used only by the
   tag-gated payment scenario).
3. `make up && make monitoring-up` — the full stack + Grafana/Prometheus.

## Running

```
make loadtest-build       # first build compiles gevent's bundled libev from source, can take a while
make loadtest-app-up      # restarts web/web2/celery/celery2/celery-beat with AI/SMS/SMTP stubbed
make loadtest-ui          # http://localhost:8089, or:
make loadtest-run USERS=200 RATE=10 DURATION=10m   # headless, writes results/run.html + run*.csv
make loadtest-app-down    # revert the app stack to normal (real) config when done
```

Do a small manual run first (10 users, a minute or two, via the UI) to shake out scenario bugs
before a real headless run — Locust surfaces per-request failure reasons in the UI immediately,
which is much faster to debug against than a CSV after the fact.

The payment scenario (`scenarios/payment_flow.py`) is tagged `payment` and excluded by default
(`loadtest-run`'s `--exclude-tags payment`, wired into the Makefile target) since it's a real
network call to Zarinpal's sandbox even though `ZARINPAL_SANDBOX` means no real money moves. To
include it: `make loadtest-run USERS=... RATE=... DURATION=... TAGS="--tags payment"` — note this
*replaces* the default exclude-tags, so payment becomes the *only* scenario running unless you
also list the others (`--tags payment,browsing,...`); simplest is to just run it separately at low
volume.

## What each scenario validates

| Scenario | Weight | File | Validates |
|---|---|---|---|
| Browsing (report/chat history, profile, assessment detail) | 40 | `scenarios/browsing.py` | baseline authenticated read latency |
| Chat send + regenerate (SSE) | 30 | `scenarios/chat_flow.py` | the known critical path — CLAUDE.md #23/#25 |
| Assessment complete flow | 15 | `scenarios/assessment_flow.py` | dispatch latency (DB write + Celery `.delay()`), not generation itself |
| Report email (PDF render + SMTP-to-console) | 5 | `scenarios/report_email.py` | the one endpoint that blocks a worker in-request |
| Payment initiate (tag-gated, off by default) | 2 | `scenarios/payment_flow.py` | dispatch latency only; real sandbox network |

Every scenario runs as `@task` methods on one `FaramanUser` (`locustfile.py`) — each simulated
identity logs in once and then runs a realistic mix, rather than each scenario using a disconnected
identity.

## Why external calls are stubbed, and how

`loadtest/compose.override.app.yml` sets, only on the app containers, only for this run:

| Var | Effect | Why safe |
|---|---|---|
| `REPORT_AI_ENABLED=false` | initial-report generation returns a fixed mock (`apps/ai/report_generation/generate.py`) | existing flag, already used for exactly this |
| `DEEP_REPORT_AI_ENABLED=false` | same for deep reports (`apps/ai/deep_report_generation/client.py`) — already the default | ditto |
| `CHAT_AI_ENABLED=false` | chat replies with a fixed mock (`apps/ai/chat_generation/generate.py`) | ditto |
| `TEST_OTP_PHONE_NUMBERS`, `TEST_OTP_CODE` | OTP send/verify skips Redis + real SMS for these numbers (`apps/account/services/otp_service.py`) | existing bypass, scoped per-number |
| `EMAIL_BACKEND=...console.EmailBackend` | report-email prints to the container log instead of sending real SMTP | new override — see `faraman_back/settings.py`'s `EMAIL_BACKEND` line |

None of these are set in the repo's `.env.example` — see the comment at the top of
`compose.override.app.yml` for why that matters (CLAUDE.md known issue #24).

Payment is **not** stubbed: `ZARINPAL_SANDBOX` already defaults `True` in every environment, so
`initiate` always hits Zarinpal's sandbox, never real money, with or without this load test.

## Chat's mock reply is (deliberately) near-instant by default

`_mock_stream()` (`apps/ai/chat_generation/generate.py`) yields its one reply almost immediately —
right for finding the pure *infra* ceiling (DB writes, SSE plumbing, gevent scheduling under
concurrent connections), but it doesn't exercise the failure mode of many *long-held* SSE
connections eating into `GUNICORN_WORKER_CONNECTIONS`. If that matters for a given run, that needs
a small addition to `_mock_stream()` (env-gated delay/chunking knobs, defaulting to today's exact
instant behavior everywhere except this overlay) — not built yet; ask before adding it, since it
touches production code even though the mock path itself only ever runs when `CHAT_AI_ENABLED=false`.

## What to watch during a run

Both `make up` and `make monitoring-up` should already be running.

- Grafana at `:3000` — `faraman-app-generation` dashboard, or query Prometheus directly at `:9090`.
- `faraman_chat_answer_ttft_seconds` / `_duration_seconds` / `_in_progress` — the direct answer to #23.
- `django_http_requests_latency_seconds` (django-prometheus) — overall latency/error rate.
- **Postgres connection count vs. `max_connections=200`** (postgres-exporter) — the key number for
  #26 (whether a pooler needs to move up in priority): if it approaches 200 well before request
  latency degrades, that's the signal.
- celery-exporter's queue depth during the assessment-completion bursts — relevant to #21 (one
  undivided queue shared with `notifications.send_due_notifications`).
- `faraman_throttle_rejected_total{scope=...}` — a sharp climb means the per-identity throttle caps
  are dominating the run, not real capacity (usually means the phone pool from setup step 1 is too
  small for the concurrency being tested).
- gunicorn's `--timeout 300` (`entrypoint.sh`) — treat anything approaching it as a hard failure.

No existing SLO doc in this repo — starting thresholds, tune after a first exploratory run: chat
send p95 TTFT < 500ms, p95 total < 2s, error rate < 0.1%; assessment-complete dispatch p95 < 300ms;
report email p95 < 5s, error rate < 1%; Postgres connections under ~80% of 200 at target
concurrency; no 5xx/timeouts at target concurrency (report the actual breaking point beyond that,
don't just treat it as a failure).

## Known gaps / first-run checks

- **`make loadtest-build` was not verified end-to-end** in the environment this was built in (no
  package-index access there to actually resolve/build gevent). It did catch one real issue before
  that — `python:3.10-slim` has no C toolchain, and gevent compiles its bundled libev from source
  on install, so the `Dockerfile` installs `build-essential` first (same reasoning as the root
  `Dockerfile`'s own `build-essential`/`gcc` for psycopg2). Run `make loadtest-build` for real on a
  normal machine before the first `make loadtest-ui`/`loadtest-run` and fix forward if anything
  else surfaces — the same "caught by actually building the image" situation as the WeasyPrint
  `libgdk-pixbuf` fix noted elsewhere in CLAUDE.md.
- **Locust's exact `FastHttpSession` streaming call shape** (`stream=True`, `.iter_lines()` on the
  response in `scenarios/chat_flow.py`) was written against Locust's documented API but not
  verified against the exact pinned version in this environment (no package-index access when this
  was built) — the first UI run against the chat scenario is the real check; if it errors on the
  streaming calls, check `locust.contrib.fasthttp`'s source for the installed version.
- After that first run, tune the scenario weights in `locustfile.py` against real traffic
  patterns if any exist, rather than the estimated 40/30/15/5/2 split here.

## After a run

Revert the app stack (`make loadtest-app-down`) so it's not left running with mocked AI/email.
Write the actual observed numbers (chat TTFT p95, Postgres connection peak, the concurrency where
things started degrading) back into CLAUDE.md's Known Issues as the resolution/update to #23.
