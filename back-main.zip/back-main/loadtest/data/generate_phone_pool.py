#!/usr/bin/env python3
"""Generates a pool of fake 09XXXXXXXXX phone numbers for TEST_OTP_PHONE_NUMBERS
(apps/account/services/otp_service.py's test-phone bypass) -- one per simulated Locust user, so
the per-phone-number OTP-throttle guard never dominates a load-test run (see loadtest/README.md).

Usage:
    python data/generate_phone_pool.py --count 1000

Writes data/phone_pool.txt (one number per line, read by scenarios/phone_pool.py at run time) and
prints the same numbers as a comma-joined string on stdout -- paste that into
compose.override.app.yml's TEST_OTP_PHONE_NUMBERS value.

099 prefix used deliberately: apps/account/serializers/otp_serializer.py's validator only checks
the shape (^09\\d{9}$), and 099 isn't allocated to any real Iranian carrier, so these numbers can
never collide with a real user's phone number even by chance.
"""
import argparse
import os
from typing import List

OUTPUT_PATH = os.path.join(os.path.dirname(__file__), "phone_pool.txt")


def generate(count: int, offset: int = 0) -> List[str]:
    return [f"099{i:08d}" for i in range(offset, offset + count)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--count", type=int, default=1000, help="how many numbers to generate")
    parser.add_argument(
        "--offset", type=int, default=0,
        help="start numbering from here instead of 0 -- use a fresh offset for each repeated "
             "test run against the same local stack, since ATTEMPT_LIMIT_COUNT/CHAT_MESSAGE_LIMIT_COUNT "
             "etc. are per-identity-per-24h: reusing numbers 0..N across multiple same-day runs "
             "means later runs start out already throttled from the earlier ones.",
    )
    args = parser.parse_args()

    numbers = generate(args.count, args.offset)

    with open(OUTPUT_PATH, "w") as f:
        f.write("\n".join(numbers) + "\n")

    print(f"Wrote {len(numbers)} numbers to {OUTPUT_PATH}\n")
    print("Paste this into loadtest/compose.override.app.yml's TEST_OTP_PHONE_NUMBERS value:\n")
    print(",".join(numbers))


if __name__ == "__main__":
    main()
