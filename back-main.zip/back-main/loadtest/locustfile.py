"""Entrypoint for `make loadtest-ui` / `make loadtest-run` (see loadtest/README.md).

One User class with weighted @task methods (rather than separate User classes per scenario) --
each simulated identity logs in once (its own phone number, see scenarios/phone_pool.py) and then
runs a realistic mix of read/write traffic against that one session, the way a real user would,
instead of every scenario spinning up its own disconnected identity.

Run against the local stack with AI/SMS/SMTP stubbed (make loadtest-app-up first) -- see
loadtest/README.md for the full workflow and CLAUDE.md's "Later: moving to production" section
for why this can't simply be re-pointed at faraman.ai as-is.
"""
from locust import FastHttpUser, between, tag, task

from scenarios.assessment_flow import AssessmentFlowMixin
from scenarios.auth import AuthMixin
from scenarios.browsing import BrowsingMixin
from scenarios.chat_flow import ChatFlowMixin
from scenarios.payment_flow import PaymentFlowMixin
from scenarios.report_email import ReportEmailMixin


class FaramanUser(
    AuthMixin, BrowsingMixin, AssessmentFlowMixin, ChatFlowMixin, ReportEmailMixin, PaymentFlowMixin,
    FastHttpUser,
):
    wait_time = between(1, 3)

    def on_start(self):
        self.init_auth_state()
        self.init_assessment_state()
        self.init_chat_state()
        self.init_report_email_state()
        self.login()

    @task(40)
    def browsing(self):
        self.browse_random()

    @task(30)
    def chat(self):
        self.chat_send_or_regenerate()

    @task(15)
    def assessment(self):
        self.run_assessment_flow()

    @task(5)
    def report_email(self):
        self.email_latest_report()

    @tag("payment")
    @task(2)
    def payment(self):
        self.initiate_payment()
